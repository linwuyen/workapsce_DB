

#include "ti_msp_dl_config.h"


int main(void)
{
    SYSCFG_DL_init();

    DL_TimerG_startCounter(PWM_0_INST);

    while (1) {

        __WFI();
    }
}
