/*
 * Check_EEPROM.c
 *
 *  Created on: 2023�~12��7��
 *      Author: roger_lin
 */
//
#include <stdint.h>
#include "emu_eeprom.h"
#include "CheckEEPROM.h"

//==================EEPROM=================//

ST_EEPROM EEPROMWrite;

void EEPROMWriteAction()
{
    EEPROMWrite.WriteAction = true;
    EEPROMWrite.u32TimeOutCnt = 100000;
}

void writesuccess()
{
    EEPROMWrite.u32writesuccess++;
}

void CalcuTimeOut()
{
    EEPROMWrite.TimeOut500 = (EEPROMWrite.u32TimeOutCnt == 1);
    EEPROMWrite.u32TimeOutCnt--;
}

void tstEEPROMWrite()
{

    switch (EEPROMWrite.fsm)
    {

    case _EV_init_RAM:

        if (EEPROMWrite.WriteAction == true)
        {
            CalcuTimeOut();
            if (EEPROMWrite.TimeOut500)
            {
                EEPROMWrite.fsm = _EV_Program_RAM;
                EEPROMWrite.WriteAction = false;
            }
        }
        break;

    case _EV_Program_RAM:

        setProgramEmuEeprom();
        EEPROMWrite.fsm = _EV_init_RAM;
        break;

    case _EV_waitting_Receive_RAM:
        if (waittingEmuEeprom() == true)
        {
            EEPROMWrite.fsm = _EV_Get_RAM_Status;
        }
        else
        {
            EEPROMWrite.fsm = _EV_waitting_Receive_RAM;
        }
        break;

    case _EV_Get_RAM_Status:

        if (getEepromErrorStatus())
        {
            EEPROMWrite.fsm |= _MASK_EERPROM_ERROR;
        }
        else
        {
            EEPROMWrite.fsm = _EV_Verify_RAM;
        }
        break;

    case _EV_Verify_RAM:

        if (setVerifyEmuEeprom())
        {
            writesuccess();
            EEPROMWrite.u32writesuccess++;
            EEPROMWrite.fsm = _EV_Verify_RAM;
        }
        else
        {
            EEPROMWrite.fsm |= _MASK_EERPROM_ERROR;
        }
        break;

    case _MASK_EERPROM_ERROR:
    default:
        break;
    }
}
//====================I2C========================//

ST_I2CBus I2C_BUS;

void RE_resetPower()
{
    DL_GPIO_reset(GPIOA);
    DL_GPIO_enablePower(GPIOA);
    DL_I2C_reset(I2C_EEPROM_INST);
    DL_I2C_enablePower(I2C_EEPROM_INST);
}

void RE_initGPIO()
{
    DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SDA,
    GPIO_I2C_EEPROM_IOMUX_SDA_FUNC,DL_GPIO_INVERSION_DISABLE,
    DL_GPIO_RESISTOR_NONE,DL_GPIO_HYSTERESIS_DISABLE,DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SCL,
    GPIO_I2C_EEPROM_IOMUX_SCL_FUNC,DL_GPIO_INVERSION_DISABLE,
    DL_GPIO_RESISTOR_NONE,DL_GPIO_HYSTERESIS_DISABLE,DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SDA);
    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SCL);
}

static const DL_I2C_ClockConfig gI2C_EEPROMClockConfig = {
        .clockSel = DL_I2C_CLOCK_BUSCLK,
        .divideRatio = DL_I2C_CLOCK_DIVIDE_1, };

void RE_initI2C()
{
    DL_I2C_setClockConfig(I2C_EEPROM_INST,(DL_I2C_ClockConfig*) &gI2C_EEPROMClockConfig);
    DL_I2C_setAnalogGlitchFilterPulseWidth(I2C_EEPROM_INST, DL_I2C_ANALOG_GLITCH_FILTER_WIDTH_50NS);
    DL_I2C_enableAnalogGlitchFilter(I2C_EEPROM_INST);
    DL_I2C_setDigitalGlitchFilterPulseWidth(I2C_EEPROM_INST, DL_I2C_DIGITAL_GLITCH_FILTER_WIDTH_CLOCKS_1);

    /* Configure Target Mode */
    DL_I2C_setTargetOwnAddress(I2C_EEPROM_INST, I2C_EEPROM_TARGET_OWN_ADDR);
    DL_I2C_setTargetTXFIFOThreshold(I2C_EEPROM_INST,DL_I2C_TX_FIFO_LEVEL_BYTES_1);
    DL_I2C_setTargetRXFIFOThreshold(I2C_EEPROM_INST,DL_I2C_RX_FIFO_LEVEL_BYTES_1);
    DL_I2C_enableTargetTXEmptyOnTXRequest(I2C_EEPROM_INST);

    DL_I2C_enableTargetClockStretching(I2C_EEPROM_INST);
    /* Configure Interrupts */
    DL_I2C_enableInterrupt(I2C_EEPROM_INST,
    DL_I2C_INTERRUPT_TARGET_RXFIFO_TRIGGER |
    DL_I2C_INTERRUPT_TARGET_START |
    DL_I2C_INTERRUPT_TARGET_STOP |
    DL_I2C_INTERRUPT_TIMEOUT_A);

    /* Enable module */
    DL_I2C_enableController(I2C_EEPROM_INST);
    DL_I2C_enableTarget(I2C_EEPROM_INST);
}

void I2CWriteAction()
{
    I2C_BUS.u8WriteAction = true;
    I2C_BUS.u32I2CTimeOutcount = 20000;
}

void CalcuI2CTimeOut()
{
    I2C_BUS.u32TimeOutActive = (I2C_BUS.u32I2CTimeOutcount == 1);
    I2C_BUS.u32I2CTimeOutcount--;
}

void checkI2CBus(void)
{

    switch (I2C_BUS.fsm)
    {

    case _EV_IDIE_I2C:

        I2C_BUS.CONTROLLER_SCL = (DL_I2C_getSCLStatus(I2C_EEPROM_INST));

        if (I2C_BUS.CONTROLLER_SCL == I2C_MBMON_SCL_CLEARED)
        {
            I2C_BUS.u32CONTROLLER_SCL_Cnt++;
        }
        else
        {
            I2C_BUS.u32CONTROLLER_SCL_Cnt = 0;
        }

        if (I2C_BUS.u32CONTROLLER_SCL_Cnt >= CONTROLLER_SCL_CNT_TIMEOUT)
        {
            I2C_BUS.fsm = _EV_Reset_I2C;
        }
        break;

    case _EV_Reset_I2C:

        if (I2C_BUS.UsedReset == true)
        {
            I2C_BUS.UsedReset = false;
            I2C_BUS.fsm = _EV_disable_Stretching;

        }
        else
        {
            RE_resetPower();
            RE_initGPIO();
            RE_initI2C();
            I2C_BUS.UsedReset = true;
            I2C_BUS.fsm = _EV_IDIE_I2C;
        }

        break;

    case _EV_disable_Stretching:

        DL_I2C_disableTargetClockStretching(I2C_EEPROM_INST);
        I2C_BUS.fsm = _EV_IDIE_I2C;
        break;

    case _MASK_I2C_BUS_ERROR:

    default:
        I2C_BUS.fsm = _EV_IDIE_I2C;
        break;
    }
}
