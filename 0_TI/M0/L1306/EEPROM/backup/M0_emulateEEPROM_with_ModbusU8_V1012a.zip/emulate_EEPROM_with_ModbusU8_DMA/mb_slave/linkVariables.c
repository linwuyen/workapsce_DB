/*
 *  File Name: linkVariables.c
 *
 *  Created on: 9/8/2023
 *  Author: POWER2-54FD92
 */

#include "ModbusCommon.h"
#include "ModbusSlave.h"


void initRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	p->pReg->s16VOLtageREFerence = MB_SFtoQ15(0); 
	p->pReg->u16CONstantCURrentREFerence = 7; 
}

void readRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
}

void writeReg(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	switch(p->info.rwfrom) {
	default:
	    break;
	}
}

void writeRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
}

