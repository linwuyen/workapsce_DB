/*
 * Check_EEPROM.c
 *
 *  Created on: 2023�~12��7��
 *      Author: roger_lin
 */
//
#include <stdint.h>
#include "emu_eeprom.h"
#include "CheckEEPROM.h"

//--------------------EEPROM----------------------///

UART_CALLBACK UARTEmuEE;

void EEPROMWriteAction(){
    UARTEmuEE.u8WriteAction = WRITE_ACTION_ENABLED;
    UARTEmuEE.TimeOutCnt = 100000;

}

void writesuccess(){
    UARTEmuEE.u32writesuccess++;
}

void CalcuTimeOut(){
    //1.�p��TIMEOUT

    HAL_UART_CALBACK p = &UARTEmuEE;
//    uint32_t delta_t = 0;
//    uint32_t u32Cnt = SWTIMER_CNT;
//
//    if(p->TimeOutCnt > u32Cnt) {
//        delta_t = u32Cnt + SW_TIMER - p->TimeOutCnt ;
//    }
//    else {
//        delta_t = u32Cnt - p->TimeOutCnt ;
//    }

     p->TimeOut500  = (p->TimeOutCnt == 1);
     p->TimeOutCnt--;
}

void EEPROM_State(){

    HAL_UART_CALBACK p = &UARTEmuEE;

    switch(p->fsm){

            case _EV_init_RAM:
                if(p->u8WriteAction == WRITE_ACTION_ENABLED) {
                    CalcuTimeOut();
                    if(p->TimeOut500){
                        //2.����TIMEOUT����A�NRAM DATA MOVE FLASH
                        p->fsm =_EV_Program_RAM;
                        p->u8WriteAction = WRITE_ACTION_DISABLED;
                    }
                }

            break;

            case _EV_Program_RAM:
                    setProgramEmuEeprom();
                    p->fsm = _EV_init_RAM;
            break;

            case _EV_waitting_Receive_RAM:
                if(WRITE_ACTION_ENABLED == waittingEmuEeprom()) {
                    p->fsm = _EV_Get_RAM_Status;
                }else{
                    p->fsm = _EV_waitting_Receive_RAM;
                }
            break;

            case _EV_Get_RAM_Status:
                if(getEepromErrorStatus()){
                    p->fsm |= _MASK_EERPROM_ERROR;
                }else{
                    p->fsm = _EV_Verify_RAM;
                }
            break;

            case _EV_Verify_RAM:
                if(setVerifyEmuEeprom()){
                    writesuccess();
                    p->fsm =_EV_Verify_RAM;
                }else{
                    p->fsm |= _MASK_EERPROM_ERROR;
                }
            break;


            case _MASK_EERPROM_ERROR:


            default:
            break;
  }
}
//------------------------I2C--------------------------//

I2C_BUS_CALLBACK Check_I2C_BUS;


void initGPIOtoI2C()
{
     DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SDA,
        GPIO_I2C_EEPROM_IOMUX_SDA_FUNC, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
     DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SCL,
        GPIO_I2C_EEPROM_IOMUX_SCL_FUNC, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
     DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SDA);
     DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SCL);
}

void initI2CtoGPIO()
{
    DL_GPIO_initDigitalInput(GPIO_I2C_EEPROM_IOMUX_SDA);
    DL_GPIO_initDigitalInput(GPIO_I2C_EEPROM_IOMUX_SCL);

    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SDA);
    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SCL);
}

void rstI2C()
{
    Check_I2C_BUS.fsm = _EV_INIT_I2C_TO_GPIO;
}

void disableI2C()
{

     DL_I2C_disableTargetClockStretching(I2C_EEPROM_INST);
     /* Configure Interrupts */
     DL_I2C_disableInterrupt(I2C_EEPROM_INST,
                            DL_I2C_INTERRUPT_TARGET_RXFIFO_TRIGGER |
                            DL_I2C_INTERRUPT_TARGET_START |
                            DL_I2C_INTERRUPT_TARGET_STOP |
                            DL_I2C_INTERRUPT_TIMEOUT_A);


     /* Enable module */
     DL_I2C_disableTarget(I2C_EEPROM_INST);

     DL_I2C_disableTimeoutA(I2C_EEPROM_INST);

     DL_I2C_reset(I2C_EEPROM_INST);
}

void I2C_BUS_State(void){

    HAL_I2C_BUS_CALLBACK   p =   &Check_I2C_BUS;

    switch (p->fsm) {
            case _EV_IDIE_I2C:

            break;

            case _EV_INIT_I2C_TO_GPIO:
                initI2CtoGPIO();
                disableI2C();
                p->Resetcount++;
                p->fsm =_EV_POWER_UP_I2C;
                break;

            case _EV_POWER_UP_I2C:
                DL_I2C_enablePower(I2C_EEPROM_INST);
                p->fsm =_EV_GET_PIN_STATE;
                break;

            case _EV_GET_PIN_STATE:
                p->SDA_state = (DL_GPIO_readPins(GPIO_I2C_EEPROM_SDA_PORT, GPIO_I2C_EEPROM_SDA_PIN)? 1:0);
                p->SLK_state = (DL_GPIO_readPins(GPIO_I2C_EEPROM_SCL_PORT, GPIO_I2C_EEPROM_SCL_PIN)? 1:0);
                if(p->SDA_state == I2C_HIGH && p->SLK_state == I2C_HIGH) {
                    //p->fsm = _EV_INIT_I2C_CONFIG;
                }
                break;

            case _EV_INIT_I2C_CONFIG:
                SYSCFG_DL_I2C_EEPROM_init();
                p->fsm = _EV_INIT_GPIO_TO_I2C;
                break;

            case _EV_INIT_GPIO_TO_I2C:
                initGPIOtoI2C();
                p->fsm=_EV_IDIE_I2C;
            break;


             case _MASK_I2C_BUS_ERROR:

        default:
            break;
 }
}
