/*
 * i2c_eeprom.h
 *
 *  Created on: 2023�~6��5��
 *      Author: cody_chen
 */

#ifndef I2C_EEPROM_H_
#define I2C_EEPROM_H_

extern void execI2cSlave(void);



#endif /* I2C_EEPROM_H_ */
