/*
 * Check_EEPROM.h
 *
 *  Created on: 2023�~12��7��
 *      Author: roger_lin
 */

#ifndef I2C_EEPROM_CHECKEEPROM_H_
#define I2C_EEPROM_CHECKEEPROM_H_

//-----------------------EEPROM---------------------
#define DISABLED 0
#define ENABLED 1

typedef enum {
     _EV_init_RAM                 =  0x0000,
     _EV_Program_RAM              = (0x0001<<0),
     _EV_waitting_Receive_RAM     = (0x0001<<1),
     _EV_Get_RAM_Status           = (0x0001<<2),
     _EV_Verify_RAM               = (0x0001<<3),
    _MASK_EERPROM_ERROR           =  0x8000
} FSM_EEPROM;

typedef struct {
    FSM_EEPROM fsm;

    uint32_t   u32writesuccess;
    uint8_t      u8WriteAction;
    uint32_t        TimeOutCnt;
    bool            TimeOut500;
    void (*fn) ();

} UART_CALLBACK;

typedef UART_CALLBACK  *HAL_UART_CALBACK;
extern UART_CALLBACK UARTEmuEE;

extern void EEPROM_State();
extern void EEPROMWriteAction();
extern void writesuccess();


//------------------------I2C---------------------

#define I2C_LOW  0
#define I2C_HIGH 1

typedef enum {
     _EV_IDIE_I2C           =     0x0000,
     _EV_Reset_I2C          =    (0x0001<<0),
     _EV_GPIO_config        =    (0x0001<<1),
     _EV_I2C_CONFIG         =    (0x0001<<2),
     _EV_Calce_timeout           =(0x0001<<3),
    _MASK_I2C_BUS_ERROR     =     0x8000
} FSM_I2C_BUS;

typedef struct {
    FSM_I2C_BUS          fsm;

    I2C_Regs            *i2c;

    uint8_t        SLK_state;
    uint8_t        SDA_state;

    uint32_t      Resetcount;
    uint32_t    TimeOutcountEnable;
    uint32_t   I2CTimeOutcount;
    uint32_t         delta_t;
    uint32_t          u32Cnt;
    uint32_t             cnt;
    uint32_t             max;

    uint32_t    TimeOutActive;
    bool     u8WriteAction;
    bool     TimeOut_Enabled;
} I2C_BUS_CALLBACK;

typedef I2C_BUS_CALLBACK  *HAL_I2C_BUS_CALLBACK;

extern void I2C_BUS_State();
extern void rstI2flag();
extern void enableTimeoutA();
extern void I2CWriteAction();
#endif /* I2C_EEPROM_CHECKEEPROM_H_ */
