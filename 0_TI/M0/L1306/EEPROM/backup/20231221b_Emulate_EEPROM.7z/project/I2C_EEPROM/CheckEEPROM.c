/*
 * Check_EEPROM.c
 *
 *  Created on: 2023�~12��7��
 *      Author: roger_lin
 */
//
#include <stdint.h>
#include "emu_eeprom.h"
#include "CheckEEPROM.h"

//--------------------EEPROM----------------------///

UART_CALLBACK UARTEmuEE;

void EEPROMWriteAction(){
    UARTEmuEE.u8WriteAction = ENABLED;
    UARTEmuEE.TimeOutCnt = 100000;
}

void writesuccess(){
    UARTEmuEE.u32writesuccess++;
}

void CalcuTimeOut(){

    //1.�p��TIMEOUT

    HAL_UART_CALBACK p = &UARTEmuEE;
//    uint32_t delta_t = 0;
//    uint32_t u32Cnt = SWTIMER_CNT;
//
//    if(p->TimeOutCnt > u32Cnt) {
//        delta_t = u32Cnt + SW_TIMER - p->TimeOutCnt ;
//    }
//    else {
//        delta_t = u32Cnt - p->TimeOutCnt ;
//    }

     p->TimeOut500  = (p->TimeOutCnt == 1);
     p->TimeOutCnt--;
}

void EEPROM_State(){

    HAL_UART_CALBACK p = &UARTEmuEE;

    switch(p->fsm){

            case _EV_init_RAM:
                if(p->u8WriteAction == ENABLED) {
                    CalcuTimeOut();
                    if(p->TimeOut500){

                        p->fsm =_EV_Program_RAM;
                        p->u8WriteAction = DISABLED;
                    }
                }

            break;

            case _EV_Program_RAM:
                    setProgramEmuEeprom();
                    p->fsm = _EV_init_RAM;
            break;

            case _EV_waitting_Receive_RAM:
                if(ENABLED == waittingEmuEeprom()) {
                    p->fsm = _EV_Get_RAM_Status;
                }else{
                    p->fsm = _EV_waitting_Receive_RAM;
                }
            break;

            case _EV_Get_RAM_Status:
                if(getEepromErrorStatus()){
                    p->fsm |= _MASK_EERPROM_ERROR;
                }else{
                    p->fsm = _EV_Verify_RAM;
                }
            break;

            case _EV_Verify_RAM:
                if(setVerifyEmuEeprom()){
                    writesuccess();
                    p->fsm =_EV_Verify_RAM;
                }else{
                    p->fsm |= _MASK_EERPROM_ERROR;
                }
            break;

            case _MASK_EERPROM_ERROR:

            default:
            break;
  }
}
//------------------------I2C--------------------------//

I2C_BUS_CALLBACK Check_I2C_BUS;

void rstI2flag(){
    Check_I2C_BUS.fsm = _EV_Reset_I2C;
}

void RE_resetPower(){
    DL_GPIO_reset(GPIOA);
    DL_GPIO_enablePower(GPIOA);
    DL_I2C_reset(I2C_EEPROM_INST);
    DL_I2C_enablePower(I2C_EEPROM_INST);
}

void RE_initGPIO(){
    DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SDA,
        GPIO_I2C_EEPROM_IOMUX_SDA_FUNC, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SCL,
        GPIO_I2C_EEPROM_IOMUX_SCL_FUNC, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SDA);
    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SCL);
}

static const DL_I2C_ClockConfig gI2C_EEPROMClockConfig = {
    .clockSel = DL_I2C_CLOCK_BUSCLK,
    .divideRatio = DL_I2C_CLOCK_DIVIDE_1,
};

void RE_initI2C(){
    DL_I2C_setClockConfig(I2C_EEPROM_INST,
        (DL_I2C_ClockConfig *) &gI2C_EEPROMClockConfig);
    DL_I2C_setAnalogGlitchFilterPulseWidth(I2C_EEPROM_INST,
        DL_I2C_ANALOG_GLITCH_FILTER_WIDTH_50NS);
    DL_I2C_enableAnalogGlitchFilter(I2C_EEPROM_INST);
    DL_I2C_setDigitalGlitchFilterPulseWidth(I2C_EEPROM_INST,
        DL_I2C_DIGITAL_GLITCH_FILTER_WIDTH_CLOCKS_1);

    /* Configure Target Mode */
    DL_I2C_setTargetOwnAddress(I2C_EEPROM_INST, I2C_EEPROM_TARGET_OWN_ADDR);
    DL_I2C_setTargetTXFIFOThreshold(I2C_EEPROM_INST, DL_I2C_TX_FIFO_LEVEL_BYTES_1);
    DL_I2C_setTargetRXFIFOThreshold(I2C_EEPROM_INST, DL_I2C_RX_FIFO_LEVEL_BYTES_1);
    DL_I2C_enableTargetTXEmptyOnTXRequest(I2C_EEPROM_INST);

    DL_I2C_enableTargetClockStretching(I2C_EEPROM_INST);
    /* Configure Interrupts */
    DL_I2C_enableInterrupt(I2C_EEPROM_INST,
                           DL_I2C_INTERRUPT_TARGET_RXFIFO_TRIGGER |
                           DL_I2C_INTERRUPT_TARGET_START |
                           DL_I2C_INTERRUPT_TARGET_STOP |
                           DL_I2C_INTERRUPT_TIMEOUT_A);

    /* Enable module */
    DL_I2C_enableTarget(I2C_EEPROM_INST);
}

void I2CWriteAction(){
    Check_I2C_BUS.u8WriteAction = ENABLED;
    Check_I2C_BUS.I2CTimeOutcount = 100000;
}

void CalcuI2CTimeOut(){

    HAL_I2C_BUS_CALLBACK   p =   &Check_I2C_BUS;

    p->TimeOutActive  = (p->I2CTimeOutcount == 1);
    p->I2CTimeOutcount--;

}

void I2C_BUS_State(void){

    HAL_I2C_BUS_CALLBACK   p =   &Check_I2C_BUS;

    switch (p->fsm) {
            case _EV_IDIE_I2C:

                p->TimeOut_Enabled = DL_I2C_isTimeoutAEnabled(I2C_EEPROM_INST);
                p->TimeOutcountEnable = DL_I2C_getCurrentTimeoutACounter(I2C_EEPROM_INST);
                if(p->u8WriteAction == ENABLED) {
                    CalcuI2CTimeOut();
                    if(p->TimeOutActive){
                        DL_GPIO_togglePins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED_1_PIN );

                        p->fsm =_EV_Reset_I2C;
                        p->TimeOutActive=0;
                        Check_I2C_BUS.I2CTimeOutcount = 100000;
                        p->u8WriteAction = DISABLED;
                    }
                }
            break;

            case _EV_Reset_I2C:
                RE_resetPower();
                p->Resetcount++;
                p->fsm =_EV_GPIO_config;
            break;

            case _EV_GPIO_config :
                DL_GPIO_initDigitalInput(GPIO_I2C_EEPROM_IOMUX_SDA);
                DL_GPIO_initDigitalInput(GPIO_I2C_EEPROM_IOMUX_SCL);
                p->SDA_state = (DL_GPIO_readPins(GPIO_I2C_EEPROM_SDA_PORT, GPIO_I2C_EEPROM_SDA_PIN)? 1:0);
                p->SLK_state = (DL_GPIO_readPins(GPIO_I2C_EEPROM_SCL_PORT, GPIO_I2C_EEPROM_SCL_PIN)? 1:0);
                if(p->SDA_state == I2C_HIGH && p->SLK_state == I2C_HIGH) {
                    RE_initGPIO();
                    p->fsm =_EV_I2C_CONFIG;
                }else{
                p->fsm = _EV_Reset_I2C;
                }
             break;


            case _EV_I2C_CONFIG:
                RE_initI2C();
                p->fsm = _EV_IDIE_I2C;
             break;

            case _EV_Calce_timeout:
                break;

             case _MASK_I2C_BUS_ERROR:

        default:
            break;
 }
}
