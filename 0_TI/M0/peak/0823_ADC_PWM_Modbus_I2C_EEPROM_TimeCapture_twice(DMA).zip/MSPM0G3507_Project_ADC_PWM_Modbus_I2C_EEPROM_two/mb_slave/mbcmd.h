/*
 *  File Name: mbcmd.h
 *
 *  Created on: 2024/8/23
 *  Author: POWER2-CB6139
 */

#ifndef MBCMD_H_
#define MBCMD_H_



typedef enum {
	_g0_MODE = 0,
    _END_OF_MODE
} ID_MODE;


enum {
	_muNTCbuckmos1 = 0,                     // #0  T_U16                
	_muNTCbuckmos2 = 1,                     // #1  T_U16                
	_muNTCbuckshunt1 = 2,                   // #2  T_U16                
	_muNTCbuckpcb = 3,                      // #3  T_U16                
	_muNTCdabmos2 = 4,                      // #4  T_U16                
	_muNTCdabmos1 = 5,                      // #5  T_U16                
	_muNTCbuckshunt2 = 6,                   // #6  T_U16                
	_muREServed0 = 7,                       // #7  T_U16                
	_muFANpwmsec0 = 8,                      // #8  T_F32                
	_muFANpwmsec1 = 9,                      // #9  T_F32                
	_muFANpwmduty0 = 10,                    // #10  T_F32               
	_muFANpwmduty1 = 11,                    // #11  T_F32               
	_muFANtachosec0 = 12,                   // #12  T_F32               
	_muFANtachosec1 = 13,                   // #13  T_F32               
	_muFANtachopulse = 14,                  // #14  T_U16               
	_muFANtachomaxspeed = 15,               // #15  T_U16               
	_muFANtachodesiredspeed = 16,           // #16  T_U16               
	_muREServed1 = 17,                      // #17  T_U16               
	_muFANtachoactualspeed0 = 18,           // #18  T_F32               
	_muFANtachoactualspeed1 = 19,           // #19  T_F32               
	_muFANtachomanual = 20,                 // #20  T_U16               
	_muADC1waringparameters = 21,           // #21  T_U16               
	_muADC2waringparameters = 22,           // #22  T_U16               
	_muADC1stopparameters = 23,             // #23  T_U16               
	_muADC2stopparameters = 24,             // #24  T_U16               
	_muGD1enable = 25,                      // #25  T_U16               
	_muGD2enable = 26,                      // #26  T_U16               
    _end_of_0_id = 23
};

typedef union { 
    uint16_t u16MbusData[27];
    struct { 
		uint16_t u16NTCbuckmos1;
		uint16_t u16NTCbuckmos2;
		uint16_t u16NTCbuckshunt1;
		uint16_t u16NTCbuckpcb;
		uint16_t u16NTCdabmos2;
		uint16_t u16NTCdabmos1;
		uint16_t u16NTCbuckshunt2;
		uint16_t u16REServed0;
		float32_t f32FANpwmsec;
		float32_t f32FANpwmduty;
		float32_t f32FANtachosec;
		uint16_t u16FANtachopulse;
		uint16_t u16FANtachomaxspeed;
		uint16_t u16FANtachodesiredspeed;
		uint16_t u16REServed1;
		float32_t f32FANtachoactualspeed;
		uint16_t u16FANtachomanual;
		uint16_t u16ADC1waringparameters;
		uint16_t u16ADC2waringparameters;
		uint16_t u16ADC1stopparameters;
		uint16_t u16ADC2stopparameters;
		uint16_t u16GD1enable;
		uint16_t u16GD2enable;
    }; 
} REG_MBUSDATA;
extern REG_MBUSDATA regMbusData;
extern int chkValidAddress(uint16_t addr);
extern uint16_t getModbusData(uint16_t addr);
extern uint16_t setModbusData(uint16_t addr, uint16_t data);




#endif /* MBCMD_H_ */

