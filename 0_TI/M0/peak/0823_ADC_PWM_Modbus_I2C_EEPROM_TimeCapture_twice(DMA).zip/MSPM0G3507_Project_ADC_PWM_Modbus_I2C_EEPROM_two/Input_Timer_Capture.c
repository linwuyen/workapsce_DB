///*
// * Input_Timer_Capture.c
// *
// *  Created on: 2024�~8��5��
// *      Author: feng_hsu
// */
//
#include "ti_msp_dl_config.h"
#include "common.h"
#include "Input_Time_Capture.h"

//#define CLOCK 1000000.00 /*Source Time�G1M*/
#define CLOCK 100000.00  /*Source Time�G100K*/
#define COUNT_1K (CLOCK / 1000)
#define COUNT_500 (CLOCK / 500 )
#define COUNT_100 (CLOCK / 100)
#define COUNT_95 (CLOCK / 95)

typedef enum{
    Input_Timer_Capture = 0,
    Input_Capture = 1,
    Capture_Error_Rest = 2
}Input_Capture_Order;

Input_Capture_Order input_capture_order = Input_Timer_Capture;

typedef struct{

    uint32_t zero;
    float32_t speed;
    uint8_t buffer_count;
    uint8_t buffer_freq_count;
    uint8_t buffer_speed_count;
    float32_t average_speed_buff[10];
    float32_t average_freq_buff[30];
    float32_t value_all;
    float32_t get_value;
    float32_t add_value;
    float32_t final_value;
    float32_t average_buffer[30];
    float32_t correction_value;
    float32_t freq_value;
    bool get_ten;
    bool haven_zero;
    bool have_freq;
    bool calculated_freq;

}Input_Frequency_Need;

typedef Input_Frequency_Need* frequency_point;

Input_Frequency_Need freq_parameters = {
.speed = 0,
.add_value = 0.00,
.get_value = 0.00,
.zero = 0,
.buffer_count = 0,
.value_all = 0.00,
.average_buffer = 0.00,
.correction_value = 0.00,
.final_value = 0.0,
.freq_value = 0.0,
.get_ten = true,
.haven_zero = false,
.have_freq = false,
.buffer_speed_count = 0,
.average_speed_buff = 0,
.average_freq_buff = 0.0,
.buffer_freq_count = 0,
.calculated_freq = false
};

frequency_point v = & freq_parameters;

float32_t get_average_value(){
    uint8_t i;
    float32_t total = 0.00;

    for(i=0;i<30;i++){
        if(v->average_buffer[i]==0) break;
        total += v->average_buffer[i];
//        if(v->average_buffer[i] == 0 ){
//            v->get_ten = false;
//        }else{
//            v->get_ten = true;
//        }
    }
//    if(v->get_ten == true) total = (total /30.00);
//    else total = 0.0;
    if(i==0) return 0.0;
    if(total == 0) return 0.0;
    else return (total/i);

//    return total;
}

void get_correction_value(frequency_point v){

    if(v->add_value >= COUNT_1K && v->add_value < COUNT_500 || v->add_value < COUNT_1K){
//        v->correction_value = 0.9964625;     /* Source time 1M parameters*/
        v->correction_value = 0.9930563;       /* Source time 100K parameters*/
    }else if(v->add_value >= COUNT_500 && v->add_value < COUNT_100){
//        v->correction_value = 0.9947526;    /* Source time 1M parameters*/
        v->correction_value = 0.9930563;      /* Source time 100K parameters*/
    }else if(v->add_value >= COUNT_100 && v->add_value < COUNT_95){
        v->correction_value = 0.9928522;
    }else if(v->add_value >= COUNT_95){
//        v->correction_value = 0.9931472;    /* Source time 1M parameters*/
        v->correction_value = 0.9828652;      /* Source time 100K parameters*/
    }
}

void Time_capture_init(){

    DL_TimerG_setClockConfig(CAPTURE_0_INST,(DL_TimerG_ClockConfig *) &TACHO_CAPTURE_0ClockConfig);
    DL_TimerG_initCaptureCombinedMode(CAPTURE_0_INST,(DL_TimerG_CaptureCombinedConfig *) &TACHO_CAPTURE_0CaptureConfig);
    DL_TimerG_enableInterrupt(CAPTURE_0_INST , DL_TIMERG_INTERRUPT_CC1_DN_EVENT |DL_TIMERG_INTERRUPT_ZERO_EVENT);
    DL_TimerG_enableClock(CAPTURE_0_INST);
}

void Error_Rest(){

    DL_Timer_disableInterrupt(CAPTURE_0_INST , DL_TIMERG_INTERRUPT_CC1_DN_EVENT |DL_TIMERG_INTERRUPT_ZERO_EVENT);
    DL_Timer_clearInterruptStatus(CAPTURE_0_INST , DL_TIMERG_INTERRUPT_CC1_DN_EVENT |DL_TIMERG_INTERRUPT_ZERO_EVENT);
    DL_Timer_disableClock(CAPTURE_0_INST);

}

float32_t calculate_Speed(){

    v->speed = 0.0;
    v->speed = (sDrv.f32input_frequency*120.0) / (sDrv.motor.u16motor_pulse * 2.0);  /*Get MODBUS pulse parameters to calculate motor poles and according to (N = 120*f / P) to calculate motor speed*/
    return v->speed;
}

float32_t average_speed_value(){

    uint16_t i = 0;
    float32_t total = 0;

    for(i= 0 ; i<10 ; i++){
        if(v->average_speed_buff[i] == 0.0) break;
        total += v->average_speed_buff[i];
    }

    return (total/i);
}

float32_t average_freq_value(){
    uint8_t i = 0;
    float32_t total = 0.00;

    for(i=0;i<30;i++){
        if(v->average_freq_buff[i] == 0)  break;
        total += v->average_freq_buff[i];
    }
    if(i==0) return 0.0;
    if(total == 0) return 0.0;
    else return (total/i);
}

void Input_Timercapture(){

    switch(input_capture_order){

    case Input_Timer_Capture:

        SYSCFG_DL_CAPTURE_0_init(); /*Built-in initialization*/
//        Time_capture_init();    /*Initialization*/
        DL_TimerG_setCoreHaltBehavior(CAPTURE_0_INST, DL_TIMER_CORE_HALT_IMMEDIATE);    /*Configures timer behavior when the core is halted,this choose immediately stop*/
        NVIC_EnableIRQ(CAPTURE_0_INST_INT_IRQN);
        DL_TimerG_startCounter(CAPTURE_0_INST);     /*Start time count*/
        v->value_all = DL_TimerG_getLoadValue(CAPTURE_0_INST);  /*Gets the timer LOAD register value,this mean maximum time value about desired time period*/
        input_capture_order = Input_Capture;

        break;

    case Input_Capture:

        if(v->have_freq == true){                                   /*If have frequency input*/
        v->get_value = get_average_value();                         /*Calculate get value to average*/
        v->add_value = (v->value_all -  v->get_value);              /*Maximum time value sub average get value*/
        get_correction_value(v);                                    /*Decide which correction parameters to use*/
        v->final_value = (v->add_value * v->correction_value);      /*Calculate final value,like source time was 1M and input frequency 1KHz,in this under condition the final value will be 1000(1M/1K)
                                                                      the other frequency like 500Hz the final value will be 2000(1M/500Hz),but notice ** The final value can't big than maximum time(desired time period)**/
                                                                    /*If the final value big than maximum time value , must to think how to solve,maybe like change source time or used software maybe like (period + (period - get value))*/
        v->freq_value = ( CLOCK / v->final_value );                 /*Calculate really frequency,if have error value big or small,to calculate correction parameters like desired final value is 1000 but actually get 1005,the correction value is (1000/1005) be float*/
        v->have_freq = false;
        }else if(v->have_freq == false && v->haven_zero == true){   /*If don't have CC1_DN interrupt and have time up interrupt,mean doesn't have frequency to input*/
            v->freq_value = 0.00;
            v->haven_zero = false;
        }

         v->average_freq_buff[v->buffer_freq_count++] = v->freq_value;                    /*For MODBUS register*/
//         if(v->buffer_freq_count >= 30){
             sDrv.f32input_frequency = average_freq_value();
             if(v->buffer_freq_count >= 30) v->buffer_freq_count = 0;
//             v->calculated_freq = true;
//         }

//         if(v->calculated_freq == true){
//             sDrv.motor.u16motor_speed = calculate_Speed();
//             v->calculated_freq = false;
//         }
//         if(v->calculated_freq == true){
//             v->average_speed_buff[v->buffer_speed_count++] = calculate_Speed();              /*Calculate speed*/
//             if(v->buffer_speed_count >= 10){
//                 sDrv.motor.f32motor_speed = average_speed_value();
                 sDrv.motor.f32motor_speed =  calculate_Speed();
//                 v->buffer_speed_count = 0;
//             }
//             v->calculated_freq = false;
//         }

        break;

    case Capture_Error_Rest:
        Error_Rest();
        input_capture_order = Input_Timer_Capture;
        break;

    default:
        break;
    }

}

void CAPTURE_0_INST_IRQHandler(void){

    switch(DL_TimerG_getPendingInterrupt(CAPTURE_0_INST)){

    case DL_TIMER_IIDX_CC0_DN:

        break;
    case DL_TIMER_IIDX_ZERO:        /*Time up and doesn't have frequency to input will happened time zero interrupt */
//        v->zero++;
        v->haven_zero = true;
        DL_Timer_clearInterruptStatus(CAPTURE_0_INST,DL_TIMER_INTERRUPT_ZERO_EVENT);
        break;
    case DL_TIMER_IIDX_CC1_DN:      /*If decide have frequency to input and it's down event interrupt*/
        v->have_freq = true;
        v->average_buffer[v->buffer_count++] = DL_TimerG_getCaptureCompareValue(CAPTURE_0_INST, DL_TIMER_CC_1_INDEX); /*Build buffer to receive vale*/

//        f32SpeedAcc += (float32_t)DL_TimerG_getCaptureCompareValue(CAPTURE_0_INST, DL_TIMER_CC_1_INDEX) * 0.0004f; /*Build buffer to receive vale*/
        if(v->buffer_count >=  30){
            v->buffer_count = 0;
//            v->have_freq = true;
        }
        DL_TimerG_setTimerCount(CAPTURE_0_INST, v->value_all);      /*Rest time count*/
        DL_Timer_clearInterruptStatus(CAPTURE_0_INST,DL_TIMER_INTERRUPT_CC1_DN_EVENT);

        break;
    default:
        input_capture_order = Capture_Error_Rest;
        break;
    }
}

