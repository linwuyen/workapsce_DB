/*
 * PWM_auto.c
 *
 *  Created on: 2024�~7��30��
 *      Author: feng_hsu
 */
#include "ti_msp_dl_config.h"
#include "common.h"

#define CLOCK 40000

DL_TimerG_PWMConfig PWM_Parameter;

typedef struct{
    uint32_t first_time;
    uint32_t twice_time;
    uint32_t add_time;
    uint32_t limit_time;
    bool one_take;
    bool comp_valuel;
}TIME_CORRECT;

TIME_CORRECT Time_correct = {
     .one_take = true,
     .comp_valuel = false,
     .limit_time = 3905   //100ms
//     .limit_time = 19525    //500ms
//     .limit_time = 1950   //50ms
};

typedef struct{
    bool ones;
    float32_t f32change_freq;
    float32_t f32change_duty;
    float32_t f32change2_duty;
    uint16_t u16pwm_period_count;
    uint16_t u16pwm_duty;
}PWM_Value;

PWM_Value pwm_value = {
   .ones = true,
   .f32change_freq = 0,
   .f32change_duty = 0.0,
   .f32change2_duty = 0.0,
   .u16pwm_period_count = 0,
   .u16pwm_duty = 0
};


typedef enum {
    PWM_init = 0,
    PWM_choose = 1,
}PWM_order;

enum{
    STOP_PWM = 0
};
PWM_order pwm_order = PWM_init;

void pwm_init(){
    DL_TimerG_setCaptureCompareOutCtl(PWM_0_INST, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
        DL_TIMERG_CAPTURE_COMPARE_0_INDEX);
    DL_TimerG_setCaptCompUpdateMethod(PWM_0_INST, DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, DL_TIMERG_CAPTURE_COMPARE_0_INDEX);
}

uint16_t Freq_calculated(){

    uint16_t clock_all = CLOCK;                 /*Have to notice calculated clock frequency in the environment configuration*/
    uint16_t count = 0;
    if(sDrv.f32Freq <= 10000 && sDrv.f32Freq >= 1){                 /*MODBUS register data buffer input 1 to 10000,this mean 1 is 1KHZ ,10 is 10KHZ*/
        count = clock_all / sDrv.f32Freq;      /*The frequency range is 1KHZ to 10MHZ is stabilizing*/
    }else if(sDrv.f32Freq > 10000){
       count = 4;
    }else if(sDrv.f32Freq < 1){
        count = 40000;
    }
    return count;
}

uint16_t Duty_calculated(uint16_t period){    /*If want to change duty,must to change frequency first*/
                                                            /*If not change frequency first,will no PWM output*/
    float32_t duty_add = 0.0;

    if(sDrv.f32Duty < 100.0 && sDrv.f32Duty > 0){                         /*Just the unsigned*/
        duty_add = (100.0 - sDrv.f32Duty)/100.0;
        duty_add = period * duty_add;
    }
    else if (sDrv.f32Duty >= 100){
        duty_add = 0;
    }

    return (uint16_t)duty_add;
}

void Correct_Duty_Value(ST_DRV* k){

    float32_t Kp = 0.001;
    float32_t u = 0.00;

    if(k->motor.u16motor_desired_speed > 0){
        if(k->motor.u16motor_desired_speed > k->motor.f32motor_speed){
//            if((k->motor.u16motor_desired_speed - k->motor.f32motor_speed) >= 20 ) Kp = 0.001;
            if((k->motor.u16motor_desired_speed - k->motor.f32motor_speed) < 50 ) Kp = 0.0001;
            u = Kp * (k->motor.u16motor_desired_speed - k->motor.f32motor_speed);
            k->f32Duty += u ;
        }else if(k->motor.u16motor_desired_speed < k->motor.f32motor_speed) {
//            if((k->motor.f32motor_speed - k->motor.u16motor_desired_speed) >= 20 ) Kp = 0.001;
            if((k->motor.f32motor_speed - k->motor.u16motor_desired_speed) < 50) Kp = 0.0001;
            u = Kp * (k->motor.f32motor_speed - k->motor.u16motor_desired_speed);
            k->f32Duty -= u;
            if(k->f32Duty <= 0){
                k->f32Duty = 0.1;
            }
        }
    }else{
        k->f32Duty = 0.0;
    }
    if(k->f32Duty >= 100.0){
        k->f32Duty = 100.0;
    }

}

void waiting_time(TIME_CORRECT* time){

    time->twice_time = DL_Timer_getTimerCount(TIMER_1_INST);

    if(time->first_time < time->twice_time){
        time->add_time = (TIMER_1_INST_LOAD_VALUE - time->twice_time) + time->first_time;
    }else{
        time->add_time = time->first_time - time->twice_time;
    }

    if(time->add_time >=  time->limit_time){
        time->first_time = DL_Timer_getTimerCount(TIMER_1_INST);
        time->comp_valuel = true;
    }

}

void PWM_Configuration(DL_TimerG_PWMConfig* p,PWM_Value* n,TIME_CORRECT* time){

    if(sDrv.f32Freq == STOP_PWM || sDrv.f32Duty == STOP_PWM){      /*MODBUS register data input 0*/
        if(n->ones == true){
            DL_Timer_stopCounter(PWM_0_INST);   /*Stop PWM*/
            n->ones = false;
//            sDrv.motor.u16motor_desired_speed = 0;
//            n->f32change_freq = STOP_PWM;
        }
    }else{                                          /*If MODBUS register data frequency not zero will start PWM,this is first condition*/
        if(sDrv.f32Freq != n->f32change_freq ){

            DL_Timer_stopCounter(PWM_0_INST);                                                   /*Only when the first condition is the met,can check the duty haven't different*/
            DL_Timer_disableClock(PWM_0_INST);                                                  /*Have to initialization PWM ,so first need to disable(close)*/
            n->u16pwm_period_count = Freq_calculated();                                        /*Calculate the function need frequency value*/
            p->pwmMode = DL_TIMER_PWM_MODE_EDGE_ALIGN;
            p->period = (uint32_t)n->u16pwm_period_count;
            p->startTimer = DL_TIMER_STOP;
            DL_TimerG_initPWMMode(PWM_0_INST, p);                                               /*It's control the PWM output frequency*/
            n->u16pwm_duty = Duty_calculated(n->u16pwm_period_count);                         /*Calculate the function need duty value*/
            DL_TimerG_setCaptureCompareValue(PWM_0_INST, (uint32_t)n->u16pwm_duty, DL_TIMER_CC_0_INDEX);    /*It's control the PWM compare value(duty)*/
            sDrv.motor.u16motor_desired_speed = (uint16_t)((sDrv.f32Duty/100) * sDrv.motor.u16MAX_Speed);
            n->f32change_duty = sDrv.f32Duty;

        }else if((sDrv.f32Duty != n->f32change_duty) && sDrv.motor.u16MANUAL != 0){

                n->u16pwm_duty = Duty_calculated(n->u16pwm_period_count);                         /*Calculate the function need duty value*/
                DL_TimerG_setCaptureCompareValue(PWM_0_INST, (uint32_t)n->u16pwm_duty, DL_TIMER_CC_0_INDEX);    /*It's control the PWM compare value(duty)*/
                sDrv.motor.u16motor_desired_speed = (uint16_t)((sDrv.f32Duty/100) * sDrv.motor.u16MAX_Speed);
//        }
//            }else if((sDrv.motor.u16motor_desired_speed != sDrv.motor.f32motor_speed) && sDrv.motor.u16MANUAL == 0){
            }else if(((sDrv.motor.u16motor_desired_speed - sDrv.motor.f32motor_speed) > 1 ||
                        (sDrv.motor.u16motor_desired_speed - sDrv.motor.f32motor_speed) < -1)
                        && sDrv.motor.u16MANUAL == 0){

                    if(time->one_take == true){
                        time->first_time = DL_Timer_getTimerCount(TIMER_1_INST);
                        time->one_take = false;
                    }
//                    if((sDrv.motor.u16motor_desired_speed - sDrv.motor.f32motor_speed) < 50 && (sDrv.motor.u16motor_desired_speed - sDrv.motor.f32motor_speed) > -50) Time_correct.limit_time = 19525;
//                    else Time_correct.limit_time = 3905;
                    waiting_time(time);
                    if(time->comp_valuel == true){
                        Correct_Duty_Value(&sDrv);
                        n->u16pwm_duty = Duty_calculated(n->u16pwm_period_count);
                        DL_TimerG_setCaptureCompareValue(PWM_0_INST, (uint32_t)n->u16pwm_duty, DL_TIMER_CC_0_INDEX);
                        time->comp_valuel = false;
//                        n->f32change_duty = sDrv.f32Duty;
                    }
                }

    DL_Timer_enableClock(PWM_0_INST);
    DL_Timer_startCounter(PWM_0_INST);      /*Start PWM*/
    n->ones = true;
    }

    n->f32change_freq = sDrv.f32Freq;      /*Give to value mean the effect is to control just set ones not always come here set parameters until change frequency or duty*/
    n->f32change_duty = n->f32change2_duty = sDrv.f32Duty;
}


void PWM_auto(){

    switch(pwm_order){
    case PWM_init:
//        pwm_init();
//        sDrv.f32Freq = 0;              /*Initialization MODBUS register data buffer,because the data is set not read*/
//        sDrv.f32Duty = 50;
        pwm_order = PWM_choose;
        break;

    case PWM_choose:

        PWM_Configuration(&PWM_Parameter,&pwm_value,&Time_correct);



        break;

    default:
        break;

    }

}
