/*
 * Check_GPIO_Pin.c
 *
 *  Created on: 2024�~8��20��
 *      Author: feng_hsu
 */
#include "ti_msp_dl_config.h"
#include "common.h"



void Chk_Pin(){

    if(DL_GPIO_readPins(GPIO_GRP_0_GD_nPG1_PIN_26_PORT,GPIO_GRP_0_GD_nPG1_PIN_26_PIN | GPIO_GRP_0_GD_nPG2_PIN_27_PIN) == 0 ){



    }

}



