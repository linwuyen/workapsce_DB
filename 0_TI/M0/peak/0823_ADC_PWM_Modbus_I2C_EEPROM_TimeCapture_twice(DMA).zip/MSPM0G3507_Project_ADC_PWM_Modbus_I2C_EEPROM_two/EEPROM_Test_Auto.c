/*
 * EEPROM_Test_Auto.c
 *
 *  Created on: 2024�~8��9��
 *      Author: feng_hsu
 */

#include "ti_msp_dl_config.h"
#include "common.h"

extern void write_to_ram();
extern void write_to_eeprom();
extern void chk_flash_and_ram();
extern void rest_ram();
extern void callback_flashtoram();

#define COUNT 200

uint32_t time_count = 100000;
bool_t ones = true;
bool_t can_write = true;
bool_t can_callback = true;
bool_t can_chk = true;
uint16_t change_next = 0 ;

void autoEEPROM_test(HAL_UART_CALBACK v){

    if(ones == true){
        write_to_ram();
        ones = false;
    }

    time_count--;

    if(change_next == 0){
        if(time_count == 1){
            time_count = 30000;
            if(can_write == true){
                write_to_eeprom();
//                DL_GPIO_togglePins(GPIOA,DL_GPIO_PIN_16);
                change_next = 1;
            }
        }
    }

    if(change_next == 1){
        if(time_count == 1){
            time_count = 10000;
            if(can_chk == true){
                chk_flash_and_ram();
//                DL_GPIO_togglePins(GPIOA,DL_GPIO_PIN_16);
                change_next = 2;
            }
        }
    }

    if(change_next == 2){
        if(time_count == 1){
            time_count = 10000;
                rest_ram();
//                DL_GPIO_togglePins(GPIOA,DL_GPIO_PIN_16);
                change_next = 3;
        }
    }

    if(change_next == 3){
        if(time_count == 1){
            time_count = 30000;
            if(can_callback == true){
                callback_flashtoram();
//                DL_GPIO_togglePins(GPIOA,DL_GPIO_PIN_16);
                change_next = 0;
            }
        }
    }

    if(can_write == true){
        if(v->u32writesuccess >= COUNT){
            can_write = false;
        }
    }

    if(can_chk == true){
        if(v->u32varifyFlashByRAM >= COUNT){
            can_chk = false;
        }
    }

    if(can_callback == true){
        if(v->u32callbackFromFlash >= COUNT){
            can_callback = false;
        }
    }

}


