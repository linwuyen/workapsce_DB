/*
 * Check_EEPROM.c
 *
 *  Created on: 2023�~12��7��
 *      Author: roger_lin
 */
//
#include <stdint.h>
#include "emu_eeprom.h"
#include "CheckEEPROM.h"
#include "mb_slave/ModbusSlave.h"

#define TM30  (prd*0.03)
#define TM15  (prd*0.015)

//==================EEPROM=================//

ST_EEPROM EEPROMWrite;

void EEPROMWriteAction()
{
    EEPROMWrite.WriteAction = true;                             /*�N EEPROM �g�J�ʧ@�]�m���ҰʡA���ܭn�i�� EEPROM ���g�J�ާ@�C*/
    EEPROMWrite.u32TimeOutCnt = 10000;                         //��F�o�̱q�Q�U���@�U������/*�]�m�F EEPROM �g�J�ާ@���W�ɭp�ƾ��� 100000�A�T�O�b�W�ɤ��e�����g�J�ʧ@�C*/
    EEPROMWrite.u32enable = 10000;
}

void writesuccess()
{
    EEPROMWrite.u32writesuccess++;
}

void CalcuTimeOut()
{
//    EEPROMWrite.TimeOut500 = (EEPROMWrite.u32TimeOutCnt == 1);
//    EEPROMWrite.u32TimeOutCnt--;
    EEPROMWrite.start_time = (EEPROMWrite.u32enable == 1);
    EEPROMWrite.u32enable--;
    if(EEPROMWrite.u32enable == 0){
        EEPROMWrite.u32enable = 1;
    }
}
typedef struct {
    uint64_t one_time;
    uint64_t two_time;
    uint64_t add_time;
    uint64_t cycle_time;
    uint16_t several;
    bool_t ones_vaild;
    bool_t back_time;
}Timer;

typedef Timer* do_timer;

Timer timer = {
     .one_time = 0,
     .two_time = 0,
     .add_time = 0,
     .cycle_time = 0,
     .several = 0,
     .ones_vaild = true,
     .back_time = false
};

void wait_time_to_eeprom(do_timer v){

    if( v->several >= 600){
        v->cycle_time = TM30;           //30ms
    }else if( v->several < 600 ){
        v->cycle_time = TM15;            //15ms
    }

    v->two_time = DL_Timer_getTimerCount(TIMER_1_INST);
    if(v->one_time < v->two_time){
        v->add_time = v->one_time  + (prd - v->two_time);
    }else{
        v->add_time  = v->one_time - v->two_time;
    }
    if(v->add_time > v->cycle_time ){
        EEPROMWrite.TimeOut500 = true;
        v->ones_vaild = true;
//        DL_GPIO_clearPins(GPIOA,DL_GPIO_PIN_18);
    }
}
extern void rstModbusTimeout(volatile SCI_MODBUS* mbus);
void Back_time(){
    do_timer v  = &timer;
    v->back_time = true;
}

extern uint16_t find_valid_value();
extern bool_t do_ones();
extern void be_zero();

uint16_t www = 0;

void tstEEPROMWrite()
{

    do_timer v  = &timer;

    switch (EEPROMWrite.fsm)
    {

    case _EV_init_RAM_i2c:

            if (EEPROMWrite.WriteAction == true)
            {
//                    DL_GPIO_setPins(GPIOA,DL_GPIO_PIN_18);
                    if(v->ones_vaild == true){
//                        v->one_time = DL_Timer_getTimerCount(SWTIMER_INST);
                        v->several = find_valid_value();                     //��Xram�����ļƶq
                        v->ones_vaild = false;
                        EEPROMWrite.TimeOut500 = false;
                    }

                    if(v->back_time == true){
                        v->one_time = DL_Timer_getTimerCount(TIMER_1_INST);
                        v->back_time = false;
                    }

                    wait_time_to_eeprom(v);

    //                CalcuTimeOut();
                    if (EEPROMWrite.TimeOut500)
                    {
                        EEPROMWrite.fsm = _EV_Program_RAM_i2c;
                        EEPROMWrite.WriteAction = false;
                        EEPROMWrite.TimeOut500 = false;
                        www++;
                    }
            }

        break;

    case _EV_Program_RAM_i2c:

        setProgramEmuEeprom();                          //�o��i��g�Jeeprom
//        be_zero();
        EEPROMWrite.fsm = _EV_init_RAM_i2c;
        break;

    case _EV_waitting_Receive_RAM_i2c:
        if (waittingEmuEeprom() == true)
        {
            EEPROMWrite.fsm = _EV_Get_RAM_Status_i2c;
        }
        else
        {
            EEPROMWrite.fsm = _EV_waitting_Receive_RAM_i2c;
        }
        break;

    case _EV_Get_RAM_Status_i2c:

        if (getEepromErrorStatus())
        {
            EEPROMWrite.fsm |= _MASK_EERPROM_ERROR;
        }
        else
        {
            EEPROMWrite.fsm = _EV_Verify_RAM_i2c;
        }
        break;

    case _EV_Verify_RAM_i2c:

        if (setVerifyEmuEeprom())
        {
            writesuccess();
            EEPROMWrite.u32writesuccess++;
            EEPROMWrite.fsm = _EV_Verify_RAM_i2c;
        }
        else
        {
            EEPROMWrite.fsm |= _MASK_EERPROM_ERROR;
        }
        break;

    case _MASK_EERPROM_ERROR:
    default:
        break;
    }
}
//====================I2C========================//

ST_I2CBus I2C_BUS;

void RE_resetPower()
{
    DL_GPIO_reset(GPIOA);                               /*����GPIO�^���l��*/
    DL_GPIO_enablePower(GPIOA);                         /*����GPIO���q��*/
    DL_I2C_reset(I2C_EEPROM_INST);                      /*����i2c�^���l��*/
    DL_I2C_enablePower(I2C_EEPROM_INST);                /*����i2c���q��*/
}

void RE_initGPIO()
{
    DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SDA,
    GPIO_I2C_EEPROM_IOMUX_SDA_FUNC,DL_GPIO_INVERSION_DISABLE,
    DL_GPIO_RESISTOR_NONE,DL_GPIO_HYSTERESIS_DISABLE,DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_I2C_EEPROM_IOMUX_SCL,
    GPIO_I2C_EEPROM_IOMUX_SCL_FUNC,DL_GPIO_INVERSION_DISABLE,
    DL_GPIO_RESISTOR_NONE,DL_GPIO_HYSTERESIS_DISABLE,DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SDA);
    DL_GPIO_enableHiZ(GPIO_I2C_EEPROM_IOMUX_SCL);
}

static const DL_I2C_ClockConfig gI2C_EEPROMClockConfig = {
        .clockSel = DL_I2C_CLOCK_BUSCLK,
        .divideRatio = DL_I2C_CLOCK_DIVIDE_1, };

void RE_initI2C()
{
    DL_I2C_setClockConfig(I2C_EEPROM_INST,(DL_I2C_ClockConfig*) &gI2C_EEPROMClockConfig);
    DL_I2C_setAnalogGlitchFilterPulseWidth(I2C_EEPROM_INST, DL_I2C_ANALOG_GLITCH_FILTER_WIDTH_50NS);
    DL_I2C_enableAnalogGlitchFilter(I2C_EEPROM_INST);
    DL_I2C_setDigitalGlitchFilterPulseWidth(I2C_EEPROM_INST, DL_I2C_DIGITAL_GLITCH_FILTER_WIDTH_CLOCKS_1);

    /* Configure Target Mode */
    DL_I2C_setTargetOwnAddress(I2C_EEPROM_INST, I2C_EEPROM_TARGET_OWN_ADDR);
    DL_I2C_setTargetTXFIFOThreshold(I2C_EEPROM_INST,DL_I2C_TX_FIFO_LEVEL_BYTES_1);
    DL_I2C_setTargetRXFIFOThreshold(I2C_EEPROM_INST,DL_I2C_RX_FIFO_LEVEL_BYTES_1);
    DL_I2C_enableTargetTXEmptyOnTXRequest(I2C_EEPROM_INST);

    DL_I2C_enableTargetClockStretching(I2C_EEPROM_INST);
    /* Configure Interrupts */
    DL_I2C_enableInterrupt(I2C_EEPROM_INST,
    DL_I2C_INTERRUPT_TARGET_RXFIFO_TRIGGER |
    DL_I2C_INTERRUPT_TARGET_START |
    DL_I2C_INTERRUPT_TARGET_STOP |
    DL_I2C_INTERRUPT_TIMEOUT_A);

    /* Enable module */
    DL_I2C_enableController(I2C_EEPROM_INST);
    DL_I2C_enableTarget(I2C_EEPROM_INST);
}

void I2CWriteAction()
{
    I2C_BUS.u8WriteAction = true;                                   /*�N I2C �g�J�ʧ@�]�m���ҰʡA���ܭn�i�� I2C ���g�J�ާ@�C*/
    I2C_BUS.u32I2CTimeOutcount = 20000;                             /*�]�m�F I2C �g�J�ާ@���W�ɭp�ƾ��� 20000�A�T�O�b�W�ɤ��e�����g�J�ʧ@�C*/
}

void CalcuI2CTimeOut()
{
    I2C_BUS.u32TimeOutActive = (I2C_BUS.u32I2CTimeOutcount == 1);
    I2C_BUS.u32I2CTimeOutcount--;
}

void checkI2CBus(void)
{

    switch (I2C_BUS.fsm)
    {

    case _EV_IDIE_I2C:

        I2C_BUS.CONTROLLER_SCL = (DL_I2C_getSCLStatus(I2C_EEPROM_INST));    /*�q�~���w��]�q�`�OI2C����^��Ū��SCL�H�������A�A�åH�S�w���榡��^�Ӫ��A*/

        if (I2C_BUS.CONTROLLER_SCL == I2C_MBMON_SCL_CLEARED)                /*�p�G������M�����A�A�p�ƾ��[�@*/
        {
            I2C_BUS.u32CONTROLLER_SCL_Cnt++;
        }
        else
        {                                                                   /*���O�M�����A�A�p�ƾ��k�s*/
            I2C_BUS.u32CONTROLLER_SCL_Cnt = 0;
        }

        if (I2C_BUS.u32CONTROLLER_SCL_Cnt >= CONTROLLER_SCL_CNT_TIMEOUT)    /*�p�G�p�ƾ��W�L���w�W�ɭȡAswitch���A�����U�@���q*/
        {
            I2C_BUS.fsm = _EV_Reset_I2C;
        }
        break;

    case _EV_Reset_I2C:

        if (I2C_BUS.UsedReset == true)                                      /*�p�G�ιL���m*/
        {
            I2C_BUS.UsedReset = false;                                      /*�����ϥέ��m�A�ä������A��U�@���q*/
            I2C_BUS.fsm = _EV_disable_Stretching;

        }
        else
        {                                                                   /*�p�G�S�ιL���m*/
            RE_resetPower();                                                /*����gpio��i2c*/
            RE_initGPIO();                                                  /*GPIO���]�w���l�ơApin�}�n�����I���D*/
            RE_initI2C();                                                   /*i2c����l��*/
            I2C_BUS.UsedReset = true;                                       /*�����m�L*/
            I2C_BUS.fsm = _EV_IDIE_I2C;                                     /*�N�������m�L�A�i�H�i��U�@���q�F*/
        }

        break;

    case _EV_disable_Stretching:

        DL_I2C_disableTargetClockStretching(I2C_EEPROM_INST);               /*�T�ή������Ԥ�*/
        I2C_BUS.fsm = _EV_IDIE_I2C;
        break;

    case _MASK_I2C_BUS_ERROR:

    default:
        I2C_BUS.fsm = _EV_IDIE_I2C;
        break;
    }
}
