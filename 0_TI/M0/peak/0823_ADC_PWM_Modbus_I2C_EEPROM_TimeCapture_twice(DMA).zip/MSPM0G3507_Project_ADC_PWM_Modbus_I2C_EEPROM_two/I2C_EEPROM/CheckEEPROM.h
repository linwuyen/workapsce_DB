/*
 * Check_EEPROM.h
 *
 *  Created on: 2023�~12��7��
 *      Author: roger_lin
 */

#ifndef I2C_EEPROM_CHECKEEPROM_H_
#define I2C_EEPROM_CHECKEEPROM_H_

//===================EEPROM=========================

typedef enum {
     _EV_init_RAM_i2c                 =  0x0000,
     _EV_Program_RAM_i2c             = (0x0001<<0),
     _EV_waitting_Receive_RAM_i2c     = (0x0001<<1),
     _EV_Get_RAM_Status_i2c           = (0x0001<<2),
     _EV_Verify_RAM_i2c               = (0x0001<<3),
    _MASK_EERPROM_ERROR_i2c           =  0x8000
} FSM_EEPROM_i2c;

typedef struct {
    FSM_EEPROM_i2c fsm;

    uint32_t    u32writesuccess;
    uint32_t      u32TimeOutCnt;
    uint32_t    u32enable;
    bool    start_time;

    bool             TimeOut500;
    bool            WriteAction;
} ST_EEPROM;

typedef ST_EEPROM * EEPROM_CALBACK;
extern  ST_EEPROM      EEPROMWrite;

extern void tstEEPROMWrite();
extern void EEPROMWriteAction();
extern void writesuccess();

//===================I2C========================\\

#define CONTROLLER_SCL_CNT_TIMEOUT  500000

typedef enum {
    _EV_IDIE_I2C            =        0x0000,
    _EV_Reset_I2C           =   (0x0001<<0),
    _EV_disable_Stretching  =   (0x0001<<1),
    _MASK_I2C_BUS_ERROR     =        0x8000
} FSM_I2C_BUS;

typedef struct {
    DL_I2C_CONTROLLER_SCL CONTROLLER_SCL;
    FSM_I2C_BUS          fsm;

    uint32_t         u32TimeOutActive;
    uint32_t       u32I2CTimeOutcount;
    uint32_t    u32CONTROLLER_SCL_Cnt;
    uint32_t                   u32SDA;
    uint32_t                   u32SLK;

    bool                    UsedReset;
    bool                u8WriteAction;
    bool              TimeOut_Enabled;
} ST_I2CBus;

typedef ST_I2CBus   *HAL_I2C_BUS;
extern  ST_I2CBus        I2C_BUS;

extern void checkI2CBus();
extern void I2CWriteAction();

#endif /* I2C_EEPROM_CHECKEEPROM_H_ */
