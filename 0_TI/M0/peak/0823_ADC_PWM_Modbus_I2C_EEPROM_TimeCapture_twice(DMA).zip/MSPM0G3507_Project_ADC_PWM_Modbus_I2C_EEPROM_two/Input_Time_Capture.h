/*
 * Input_Time_Capture.h
 *
 *  Created on: 2024�~8��8��
 *      Author: feng_hsu
 */
#include "ti_msp_dl_config.h"

#ifndef INPUT_TIME_CAPTURE_H_
#define INPUT_TIME_CAPTURE_H_

DL_TimerG_ClockConfig TACHO_CAPTURE_0ClockConfig = {
    .clockSel    = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_4,
    .prescale = 99U
};

DL_TimerG_CaptureCombinedConfig TACHO_CAPTURE_0CaptureConfig = {
    .captureMode    = DL_TIMER_CAPTURE_COMBINED_MODE_PULSE_WIDTH_AND_PERIOD,
    .period         = CAPTURE_0_INST_LOAD_VALUE,
    .startTimer     = DL_TIMER_STOP,
    .inputChan      = DL_TIMER_INPUT_CHAN_0,
    .inputInvMode   = DL_TIMER_CC_INPUT_INV_NOINVERT,
};



#endif /* INPUT_TIME_CAPTURE_H_ */
