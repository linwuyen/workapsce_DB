/*
 * common.h
 *
 *  Created on: 2022�~3��9��
 *      Author: cody_chen
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "ti_msp_dl_config.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdint.h>
#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#include "ctypedef.h"


#define RAMFUNC \
    __attribute__((section(".TI.ramfunc"))) __attribute__((noinline))

//#define SW_TIMER        250000
#define SW_TIMER        52287
//#define SW_TIMER        39062

#define T_500US         (SW_TIMER/2000)
#define T_1MS           (SW_TIMER/1000)
#define T_2MS           (SW_TIMER/500)
#define T_2D5MS         (SW_TIMER/400)
#define T_5MS           (SW_TIMER/200)
#define T_10MS          (SW_TIMER/100)
#define T_20MS          (SW_TIMER/50)
#define T_25MS          (SW_TIMER/40)
#define T_50MS          (SW_TIMER/20)
#define T_100MS         (SW_TIMER/10)
#define T_200MS         (SW_TIMER/5)
#define T_500MS         (SW_TIMER/2)
#define T_1S            (SW_TIMER/1)


#define SWTIMER_CNT     SW_TIMER - (uint32_t)DL_TimerG_getTimerCount(TIMER_2_INST)

#define FG_GET(x, src)   ((src & (x)) == (x)) //((src & (x)) == (x))  src ��and x �o�X�Ӫ��Ȧp�G�Px�۵��A�h��true(1)�n���N��false(0)�C
#define FG_GETn(x, src)  (!FG_GET(x, src)) //!((src & (x)) == (x))
#define FG_AND(x, src)   (src & (x))
#define FG_SET(x, src)   {src |= (x);}
#define FG_RST(x, src)   {src &= ~(x);}
#define FG_SWTO(x, src)  {src = (x);}

typedef enum {
     _EV_Receive_RAM                 =   0x0000,
     _EV_waitting_Receive_RAM     = (0x0001<<0),
     _EV_Get_RAM_Status           = (0x0001<<1),
     _EV_Verify_RAM               = (0x0001<<2),
    _MASK_EERPROM_ERROR          =      0x8000
} FSM_EEPROM;

typedef struct {
    FSM_EEPROM fsm;

    uint32_t    u32writesuccess ;
    uint32_t    u32varifyFlashByRAM;
    uint32_t    u32callbackFromFlash;
    uint8_t     u8WriteAction;
} UART_CALLBACK;

typedef UART_CALLBACK  *HAL_UART_CALBACK;
UART_CALLBACK  UARTEmuEE;

typedef struct{
    uint16_t u16MOS1_value;
    uint16_t u16MOS2_value;
    uint16_t u16SHUNT1_value;
    uint16_t u16SHUNT2_value;
}ADC0_CONVERT_Value;

typedef ADC0_CONVERT_Value * HAL_ADC0_CONVERT_Value;

typedef struct{
    uint16_t u16PCB_value;
    uint16_t u16MOSB2_value;
    uint16_t u16MOSB1_value;
}ADC1_CONVERT_Value;

typedef ADC1_CONVERT_Value * HAL_ADC1_CONVERT_Value;

typedef struct{
    uint16_t u16motor_pulse;
    float32_t f32motor_speed;
    uint16_t u16motor_desired_speed;
    uint16_t u16MAX_Speed;
    uint16_t u16MANUAL;
}Motor_Return_Value;

typedef struct{
    uint16_t u16adc1_GD1_Waring;
    uint16_t u16adc2_GD2_Waring;
    uint16_t u16adc1_GD1_STOP;
    uint16_t u16adc2_GD2_STOP;

}Waring_Stop_Parameters;

typedef struct{
    bool GD1_enable;
    bool GD2_enable;
}Output_Enable;

typedef struct {
    ADC1_CONVERT_Value adc1;
    ADC0_CONVERT_Value adc0;
    Motor_Return_Value motor;
    Waring_Stop_Parameters limit_parameters;
    Output_Enable chk_enable;
    float32_t f32Duty;
    float32_t f32Freq;
    float32_t f32input_frequency;
}ST_DRV;


extern ST_DRV sDrv;

#endif /* COMMON_H_ */
