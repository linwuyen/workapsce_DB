
#include "ti_msp_dl_config.h"
#include "common.h"
#include "mb_slave/ModbusSlave.h"

extern void ADC0_auto();
extern void ADC1_auto();
extern void PWM_auto();
extern void Input_frequency();
extern void Input_Timercapture();
extern void execEmuEeprom();
extern void tstEmuEeprom();
extern void autoEEPROM_test(UART_CALLBACK*);
extern void execI2cSlave();
extern void tstEEPROMWrite();
extern void Chk_Pin();

typedef struct{
    uint32_t first;
    uint32_t second;
    uint32_t addtime;
}TIME_value;

TIME_value time_value;

ST_DRV sDrv ;

void delay_time(TIME_value* v){

    v->second = DL_Timer_getTimerCount(TIMER_1_INST);

    if(v->first < v->second){
        v->addtime = (TIMER_1_INST_LOAD_VALUE - v->second) + v->first;
    }else{
        v->addtime = v->first - v->second;
    }

    if(v->addtime > 195){
        DL_GPIO_togglePins(GPIOB, GPIO_GRP_0_PIN_15_PIN);
        v->first = DL_Timer_getTimerCount(TIMER_1_INST);
    }
}

int main(void)
{
    SYSCFG_DL_init();

    time_value.first = time_value.second = DL_Timer_getTimerCount(TIMER_1_INST);

    while(1){

        /*Check whether the MUC status abnormal*/
        delay_time(&time_value);
        /*ADC*/
        ADC0_auto();
        ADC1_auto();
        /*MODBUS*/
        exeModbusSlave((SCI_MODBUS *)&mbcomm);
        /*PWM*/
        PWM_auto();
        /*What is the input frequency detected*/
        Input_Timercapture();

        /*EEPROM*/
        execEmuEeprom();
        /*Manual test EEPROM*/
        tstEmuEeprom();
        /*Auto test EEPROM , notice COUNT*/
//        autoEEPROM_test(&UARTEmuEE);
        /*I2C*/
        execI2cSlave();
        /*If time up will write data to FLASH ( EEPROM ) form I2C*/
        tstEEPROMWrite();

//        Chk_Pin();

    }

}
