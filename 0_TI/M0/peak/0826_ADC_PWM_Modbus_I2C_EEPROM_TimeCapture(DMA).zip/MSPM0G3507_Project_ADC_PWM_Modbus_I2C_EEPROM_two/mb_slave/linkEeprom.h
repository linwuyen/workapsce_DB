/*
 *  File Name: linkEeprom.h
 *
 *  Created on: 2024/8/23
 *  Author: POWER2-CB6139
 */

typedef struct {
    uint16_t size;
    void *ptr;
} EE_REG;
typedef EE_REG * HAL_EEREG;

#define _BLK16_AA	3
uint16_t blkaa[_BLK16_AA];
const EE_REG regaa[2] = {
              {2, (void*)&sDrv.adc0.u16MOS1_value},
              {1, (void*)&blkaa[2]}};
#define _TABLE_AA	2

