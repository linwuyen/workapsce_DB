/*
 *  File Name: tbmenu.c
 *
 *  Created on: 2024/8/23
 *  Author: POWER2-CB6139
 */

#include "ModbusSlave.h"
#include "mbcmd.h"


REG_MBUSDATA regMbusData;

int chkValidAddress(uint16_t addr) {
    switch(addr) {
	    case _muNTCbuckmos1:                                            
	    case _muNTCbuckmos2:                                            
	    case _muNTCbuckshunt1:                                          
	    case _muNTCbuckpcb:                                             
	    case _muNTCdabmos2:                                             
	    case _muNTCdabmos1:                                             
	    case _muNTCbuckshunt2:                                          
	    case _muREServed0:                                              
	    case _muFANpwmsec0:                                             
	    case _muFANpwmsec1:                                             
	    case _muFANpwmduty0:                                            
	    case _muFANpwmduty1:                                            
	    case _muFANtachosec0:                                           
	    case _muFANtachosec1:                                           
	    case _muFANtachopulse:                                          
	    case _muFANtachomaxspeed:                                       
	    case _muFANtachodesiredspeed:                                   
	    case _muREServed1:                                              
	    case _muFANtachoactualspeed0:                                   
	    case _muFANtachoactualspeed1:                                   
	    case _muFANtachomanual:                                         
	    case _muADC1waringparameters:                                   
	    case _muADC2waringparameters:                                   
	    case _muADC1stopparameters:                                     
	    case _muADC2stopparameters:                                     
	    case _muGD1enable:                                              
	    case _muGD2enable:                                              
        return 0;
    default:
        return MB_ERROR_ILLEGALADDR;
    }
}

uint16_t getModbusData(uint16_t addr) {
    switch(addr) {
	    case _muNTCbuckmos1: return regMbusData.u16MbusData[0];                            
	    case _muNTCbuckmos2: return regMbusData.u16MbusData[1];                            
	    case _muNTCbuckshunt1: return regMbusData.u16MbusData[2];                            
	    case _muNTCbuckpcb: return regMbusData.u16MbusData[3];                            
	    case _muNTCdabmos2: return regMbusData.u16MbusData[4];                            
	    case _muNTCdabmos1: return regMbusData.u16MbusData[5];                            
	    case _muNTCbuckshunt2: return regMbusData.u16MbusData[6];                            
	    case _muREServed0: return regMbusData.u16MbusData[7];                            
	    case _muFANpwmsec0: return regMbusData.u16MbusData[8];                            
	    case _muFANpwmsec1: return regMbusData.u16MbusData[9];                            
	    case _muFANpwmduty0: return regMbusData.u16MbusData[10];                            
	    case _muFANpwmduty1: return regMbusData.u16MbusData[11];                            
	    case _muFANtachosec0: return regMbusData.u16MbusData[12];                            
	    case _muFANtachosec1: return regMbusData.u16MbusData[13];                            
	    case _muFANtachopulse: return regMbusData.u16MbusData[14];                            
	    case _muFANtachomaxspeed: return regMbusData.u16MbusData[15];                            
	    case _muFANtachodesiredspeed: return regMbusData.u16MbusData[16];                            
	    case _muREServed1: return regMbusData.u16MbusData[17];                            
	    case _muFANtachoactualspeed0: return regMbusData.u16MbusData[18];                            
	    case _muFANtachoactualspeed1: return regMbusData.u16MbusData[19];                            
	    case _muFANtachomanual: return regMbusData.u16MbusData[20];                            
	    case _muADC1waringparameters: return regMbusData.u16MbusData[21];                            
	    case _muADC2waringparameters: return regMbusData.u16MbusData[22];                            
	    case _muADC1stopparameters: return regMbusData.u16MbusData[23];                            
	    case _muADC2stopparameters: return regMbusData.u16MbusData[24];                            
	    case _muGD1enable: return regMbusData.u16MbusData[25];                            
	    case _muGD2enable: return regMbusData.u16MbusData[26];                            
    default:
        return 0xFFFF;
    }
}

uint16_t setModbusData(uint16_t addr, uint16_t data) {
    switch(addr) {
	    case _muNTCbuckmos1: regMbusData.u16MbusData[0] = data; break;                            
	    case _muNTCbuckmos2: regMbusData.u16MbusData[1] = data; break;                            
	    case _muNTCbuckshunt1: regMbusData.u16MbusData[2] = data; break;                            
	    case _muNTCbuckpcb: regMbusData.u16MbusData[3] = data; break;                            
	    case _muNTCdabmos2: regMbusData.u16MbusData[4] = data; break;                            
	    case _muNTCdabmos1: regMbusData.u16MbusData[5] = data; break;                            
	    case _muNTCbuckshunt2: regMbusData.u16MbusData[6] = data; break;                            
	    case _muREServed0: regMbusData.u16MbusData[7] = data; break;                            
	    case _muFANpwmsec0: regMbusData.u16MbusData[8] = data; break;                            
	    case _muFANpwmsec1: regMbusData.u16MbusData[9] = data; break;                            
	    case _muFANpwmduty0: regMbusData.u16MbusData[10] = data; break;                            
	    case _muFANpwmduty1: regMbusData.u16MbusData[11] = data; break;                            
	    case _muFANtachosec0: regMbusData.u16MbusData[12] = data; break;                            
	    case _muFANtachosec1: regMbusData.u16MbusData[13] = data; break;                            
	    case _muFANtachopulse: regMbusData.u16MbusData[14] = data; break;                            
	    case _muFANtachomaxspeed: regMbusData.u16MbusData[15] = data; break;                            
	    case _muFANtachodesiredspeed: regMbusData.u16MbusData[16] = data; break;                            
	    case _muREServed1: regMbusData.u16MbusData[17] = data; break;                            
	    case _muFANtachoactualspeed0: regMbusData.u16MbusData[18] = data; break;                            
	    case _muFANtachoactualspeed1: regMbusData.u16MbusData[19] = data; break;                            
	    case _muFANtachomanual: regMbusData.u16MbusData[20] = data; break;                            
	    case _muADC1waringparameters: regMbusData.u16MbusData[21] = data; break;                            
	    case _muADC2waringparameters: regMbusData.u16MbusData[22] = data; break;                            
	    case _muADC1stopparameters: regMbusData.u16MbusData[23] = data; break;                            
	    case _muADC2stopparameters: regMbusData.u16MbusData[24] = data; break;                            
	    case _muGD1enable: regMbusData.u16MbusData[25] = data; break;                            
	    case _muGD2enable: regMbusData.u16MbusData[26] = data; break;                            
    default:
        return 0xFFFF;
    }
    return data;
}



