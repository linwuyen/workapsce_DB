/*
 *  File Name: linkVariables.c
 *
 *  Created on: 2024/8/23
 *  Author: POWER2-CB6139
 */

#include "ModbusCommon.h"
#include "ModbusSlave.h"


void initRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	sDrv.adc0.u16MOS1_value = 0; 
	sDrv.adc0.u16MOS2_value = 0; 
	sDrv.adc0.u16SHUNT1_value = 0; 
	sDrv.adc1.u16PCB_value = 0; 
	sDrv.adc1.u16MOSB2_value = 0; 
	sDrv.adc1.u16MOSB1_value = 0; 
	sDrv.adc0.u16SHUNT2_value = 0; 
	p->pReg->u16REServed0 = 0; 
	sDrv.f32Freq = 0; 
	sDrv.f32Duty = 50; 
	sDrv.f32input_frequency = 0; 
	sDrv.motor.u16motor_pulse = 2; 
	sDrv.motor.u16MAX_Speed = 7500; 
	sDrv.motor.u16motor_desired_speed = 0; 
	p->pReg->u16REServed1 = 0; 
	sDrv.motor.f32motor_speed = 0; 
	sDrv.motor.u16MANUAL = 0; 
	sDrv.limit_parameters.u16adc1_GD1_Waring = 3100; 
	sDrv.limit_parameters.u16adc2_GD2_Waring = 3100; 
	sDrv.limit_parameters.u16adc1_GD1_STOP = 3700; 
	sDrv.limit_parameters.u16adc2_GD2_STOP = 3700; 
	sDrv.chk_enable.GD1_enable = 0; 
	sDrv.chk_enable.GD2_enable = 0; 
}

void readRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	p->pReg->u16NTCbuckmos1 = sDrv.adc0.u16MOS1_value; 
	p->pReg->u16NTCbuckmos2 = sDrv.adc0.u16MOS2_value; 
	p->pReg->u16NTCbuckshunt1 = sDrv.adc0.u16SHUNT1_value; 
	p->pReg->u16NTCbuckpcb = sDrv.adc1.u16PCB_value; 
	p->pReg->u16NTCdabmos2 = sDrv.adc1.u16MOSB2_value; 
	p->pReg->u16NTCdabmos1 = sDrv.adc1.u16MOSB1_value; 
	p->pReg->u16NTCbuckshunt2 = sDrv.adc0.u16SHUNT2_value; 
	p->pReg->f32FANpwmsec = sDrv.f32Freq; 
	p->pReg->f32FANpwmduty = sDrv.f32Duty; 
	p->pReg->f32FANtachosec = sDrv.f32input_frequency; 
	p->pReg->u16FANtachopulse = sDrv.motor.u16motor_pulse; 
	p->pReg->u16FANtachomaxspeed = sDrv.motor.u16MAX_Speed; 
	p->pReg->u16FANtachodesiredspeed = sDrv.motor.u16motor_desired_speed; 
	p->pReg->f32FANtachoactualspeed = sDrv.motor.f32motor_speed; 
	p->pReg->u16FANtachomanual = sDrv.motor.u16MANUAL; 
	p->pReg->u16ADC1waringparameters = sDrv.limit_parameters.u16adc1_GD1_Waring; 
	p->pReg->u16ADC2waringparameters = sDrv.limit_parameters.u16adc2_GD2_Waring; 
	p->pReg->u16ADC1stopparameters = sDrv.limit_parameters.u16adc1_GD1_STOP; 
	p->pReg->u16ADC2stopparameters = sDrv.limit_parameters.u16adc2_GD2_STOP; 
	p->pReg->u16GD1enable = sDrv.chk_enable.GD1_enable; 
	p->pReg->u16GD2enable = sDrv.chk_enable.GD2_enable; 
}

void writeReg(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	switch(p->info.rwfrom) {
	case _muNTCbuckmos1 :   sDrv.adc0.u16MOS1_value = p->pReg->u16NTCbuckmos1; break;
	case _muNTCbuckmos2 :   sDrv.adc0.u16MOS2_value = p->pReg->u16NTCbuckmos2; break;
	case _muNTCbuckshunt1 :   sDrv.adc0.u16SHUNT1_value = p->pReg->u16NTCbuckshunt1; break;
	case _muNTCbuckpcb :   sDrv.adc1.u16PCB_value = p->pReg->u16NTCbuckpcb; break;
	case _muNTCdabmos2 :   sDrv.adc1.u16MOSB2_value = p->pReg->u16NTCdabmos2; break;
	case _muNTCdabmos1 :   sDrv.adc1.u16MOSB1_value = p->pReg->u16NTCdabmos1; break;
	case _muNTCbuckshunt2 :   sDrv.adc0.u16SHUNT2_value = p->pReg->u16NTCbuckshunt2; break;
	case _muFANpwmsec0 :   sDrv.f32Freq = p->pReg->f32FANpwmsec; break;
	case _muFANpwmduty0 :   sDrv.f32Duty = p->pReg->f32FANpwmduty; break;
	case _muFANtachosec0 :   sDrv.f32input_frequency = p->pReg->f32FANtachosec; break;
	case _muFANtachopulse :   sDrv.motor.u16motor_pulse = p->pReg->u16FANtachopulse; break;
	case _muFANtachomaxspeed :   sDrv.motor.u16MAX_Speed = p->pReg->u16FANtachomaxspeed; break;
	case _muFANtachodesiredspeed :   sDrv.motor.u16motor_desired_speed = p->pReg->u16FANtachodesiredspeed; break;
	case _muFANtachoactualspeed0 :   sDrv.motor.f32motor_speed = p->pReg->f32FANtachoactualspeed; break;
	case _muFANtachomanual :   sDrv.motor.u16MANUAL = p->pReg->u16FANtachomanual; break;
	case _muADC1waringparameters :   sDrv.limit_parameters.u16adc1_GD1_Waring = p->pReg->u16ADC1waringparameters; break;
	case _muADC2waringparameters :   sDrv.limit_parameters.u16adc2_GD2_Waring = p->pReg->u16ADC2waringparameters; break;
	case _muADC1stopparameters :   sDrv.limit_parameters.u16adc1_GD1_STOP = p->pReg->u16ADC1stopparameters; break;
	case _muADC2stopparameters :   sDrv.limit_parameters.u16adc2_GD2_STOP = p->pReg->u16ADC2stopparameters; break;
	case _muGD1enable :   sDrv.chk_enable.GD1_enable = p->pReg->u16GD1enable; break;
	case _muGD2enable :   sDrv.chk_enable.GD2_enable = p->pReg->u16GD2enable; break;
	default:
	    break;
	}
}

void writeRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	sDrv.adc0.u16MOS1_value = p->pReg->u16NTCbuckmos1; 
	sDrv.adc0.u16MOS2_value = p->pReg->u16NTCbuckmos2; 
	sDrv.adc0.u16SHUNT1_value = p->pReg->u16NTCbuckshunt1; 
	sDrv.adc1.u16PCB_value = p->pReg->u16NTCbuckpcb; 
	sDrv.adc1.u16MOSB2_value = p->pReg->u16NTCdabmos2; 
	sDrv.adc1.u16MOSB1_value = p->pReg->u16NTCdabmos1; 
	sDrv.adc0.u16SHUNT2_value = p->pReg->u16NTCbuckshunt2; 
	sDrv.f32Freq = p->pReg->f32FANpwmsec; 
	sDrv.f32Duty = p->pReg->f32FANpwmduty; 
	sDrv.f32input_frequency = p->pReg->f32FANtachosec; 
	sDrv.motor.u16motor_pulse = p->pReg->u16FANtachopulse; 
	sDrv.motor.u16MAX_Speed = p->pReg->u16FANtachomaxspeed; 
	sDrv.motor.u16motor_desired_speed = p->pReg->u16FANtachodesiredspeed; 
	sDrv.motor.f32motor_speed = p->pReg->f32FANtachoactualspeed; 
	sDrv.motor.u16MANUAL = p->pReg->u16FANtachomanual; 
	sDrv.limit_parameters.u16adc1_GD1_Waring = p->pReg->u16ADC1waringparameters; 
	sDrv.limit_parameters.u16adc2_GD2_Waring = p->pReg->u16ADC2waringparameters; 
	sDrv.limit_parameters.u16adc1_GD1_STOP = p->pReg->u16ADC1stopparameters; 
	sDrv.limit_parameters.u16adc2_GD2_STOP = p->pReg->u16ADC2stopparameters; 
	sDrv.chk_enable.GD1_enable = p->pReg->u16GD1enable; 
	sDrv.chk_enable.GD2_enable = p->pReg->u16GD2enable; 
}

