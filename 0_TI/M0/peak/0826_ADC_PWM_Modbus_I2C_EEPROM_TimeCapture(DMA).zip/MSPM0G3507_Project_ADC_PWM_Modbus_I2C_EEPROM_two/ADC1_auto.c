/*
 * ADC1_auto.c
 *
 *  Created on: 2024�~7��26��
 *      Author: feng_hsu
 */
#include "ti_msp_dl_config.h"
#include "common.h"

//extern REG_MBUSDATA regMbusData;        /*This is MODBUS register data buffer*/
//typedef REG_MBUSDATA* modbusdata_point;

typedef enum {
    ADC_init = 0,
    Timer_Event_Start = 1,
    ADC_Convert_Finish = 2,
    ADC_Error = 3
}ADC1_ORDER;

ADC1_ORDER adc1_order = 0;


void adc1_value_init(HAL_ADC1_CONVERT_Value v){
    v->u16MOSB1_value = 0;
    v->u16MOSB2_value = 0;
    v->u16PCB_value = 0;
}

void ADC1_parmeter_init(){

    DL_ADC12_initSeqSample(ADC12_1_INST,
        DL_ADC12_REPEAT_MODE_DISABLED, DL_ADC12_SAMPLING_SOURCE_AUTO, DL_ADC12_TRIG_SRC_SOFTWARE,
        DL_ADC12_SEQ_START_ADDR_00, DL_ADC12_SEQ_END_ADDR_02, DL_ADC12_SAMP_CONV_RES_12_BIT,
        DL_ADC12_SAMP_CONV_DATA_FORMAT_UNSIGNED);
    DL_ADC12_configConversionMem(ADC12_1_INST, ADC12_1_ADCMEM_NTC_BUCK_PCB,
        DL_ADC12_INPUT_CHAN_2, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    DL_ADC12_configConversionMem(ADC12_1_INST, ADC12_1_ADCMEM_NTC_DAB_MOS2,
        DL_ADC12_INPUT_CHAN_1, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    DL_ADC12_configConversionMem(ADC12_1_INST, ADC12_1_ADCMEM_NTC_DAB_MOS1,
        DL_ADC12_INPUT_CHAN_0, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    DL_ADC12_setSampleTime0(ADC12_1_INST,16);
    DL_ADC12_setSubscriberChanID(ADC12_1_INST,ADC12_1_INST_SUB_CH);
    /* Enable ADC12 interrupt */
    DL_ADC12_clearInterruptStatus(ADC12_1_INST,(DL_ADC12_INTERRUPT_MEM2_RESULT_LOADED));
    DL_ADC12_enableInterrupt(ADC12_1_INST,(DL_ADC12_INTERRUPT_MEM2_RESULT_LOADED));
    DL_ADC12_enableConversions(ADC12_1_INST);
}

void ADC1_Error_Rest(){

    /*Stop time count continue*/
    DL_Timer_stopCounter(TIMER_0_INST);
    /*Stop convert (Register CTL1)*/
    DL_ADC12_stopConversion(ADC12_1_INST);
    /*Disable convert function*//*By the way if want stop repeat mode,type this function*/
    DL_ADC12_disableConversions(ADC12_1_INST);
    /*Disable interrupt and clear interrupt status*/
    DL_ADC12_disableInterrupt(ADC12_1_INST,DL_ADC12_INTERRUPT_MEM2_RESULT_LOADED);
    DL_ADC12_disableEvent(ADC12_1_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
    DL_ADC12_clearInterruptStatus(ADC12_1_INST,DL_ADC12_INTERRUPT_MEM2_RESULT_LOADED);
    DL_ADC12_clearEventsStatus(ADC12_1_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
}

void ADC1_auto(){

    switch(adc1_order){
    case ADC_init:

        SYSCFG_DL_ADC12_1_init();
//        ADC1_parmeter_init();
        adc1_value_init(&sDrv.adc1);                      /*Initialization MODBUS register data buffer*/
        NVIC_EnableIRQ(ADC12_1_INST_INT_IRQN);
        adc1_order = Timer_Event_Start;
        break;

    case Timer_Event_Start:
//        DL_Timer_startCounter(TIMER_0_INST);  /*The function will delete,because in the ADC0 has to do*/
        adc1_order = ADC_Convert_Finish;        /*ADC0 and ADC1 is used same timer*/
        break;

    case ADC_Convert_Finish:

        break;

    case ADC_Error:
        ADC1_Error_Rest();
        adc1_order = ADC_init;
        break;

    default:
        break;
    }
}

void ADC12_1_INST_IRQHandler(void){

    switch(DL_ADC12_getPendingInterrupt(ADC12_1_INST)){
    case DL_ADC12_IIDX_MEM2_RESULT_LOADED:

//        DL_GPIO_togglePins(GPIOA, GPIO_GRP_0_PIN_27_PIN);                                       /*Check timer event trigger happened need time*/
        sDrv.adc1.u16MOSB1_value = DL_ADC12_getMemResult(ADC12_1_INST,ADC12_1_ADCMEM_NTC_DAB_MOS1);    /*Get ADC value*/
        sDrv.adc1.u16MOSB2_value = DL_ADC12_getMemResult(ADC12_1_INST,ADC12_1_ADCMEM_NTC_DAB_MOS2);
        sDrv.adc1.u16PCB_value = DL_ADC12_getMemResult(ADC12_1_INST,ADC12_1_ADCMEM_NTC_BUCK_PCB);
        DL_ADC12_clearInterruptStatus(ADC12_1_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);
        DL_ADC12_clearEventsStatus(ADC12_1_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
        DL_ADC12_enableConversions(ADC12_1_INST);   /*In the timer event trigger operate,can't enable repeat mode,so need add this function*/

        break;

    default:
        adc1_order = ADC_Error;
        break;

    }
}






