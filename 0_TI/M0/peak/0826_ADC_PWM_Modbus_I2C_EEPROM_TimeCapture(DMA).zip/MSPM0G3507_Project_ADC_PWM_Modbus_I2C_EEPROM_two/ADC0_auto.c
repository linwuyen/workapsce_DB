/*
 * ADC_auto.c
 *
 *  Created on: 2024�~7��26��
 *      Author: feng_hsu
 */
#include "ti_msp_dl_config.h"
#include "common.h"

//extern REG_MBUSDATA regMbusData;        /*This is MODBUS register data buffer*/
//typedef REG_MBUSDATA* modbusdata_point;

typedef enum {
    ADC_init = 0,
    Timer_Event_Start = 1,
    ADC_Convert_Finish = 2,
    ADC_Error = 3
}ADC_ORDER;

ADC_ORDER adc0_order = 0;

void ADC0_parmeter_init(){
    DL_ADC12_initSeqSample(ADC12_0_INST,
        DL_ADC12_REPEAT_MODE_DISABLED, DL_ADC12_SAMPLING_SOURCE_AUTO, DL_ADC12_TRIG_SRC_EVENT,
        DL_ADC12_SEQ_START_ADDR_00, DL_ADC12_SEQ_END_ADDR_03, DL_ADC12_SAMP_CONV_RES_12_BIT,
        DL_ADC12_SAMP_CONV_DATA_FORMAT_UNSIGNED);
    DL_ADC12_configConversionMem(ADC12_0_INST, ADC12_0_ADCMEM_NTC_BUCK_MOS1,
        DL_ADC12_INPUT_CHAN_2, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    DL_ADC12_configConversionMem(ADC12_0_INST, ADC12_0_ADCMEM_NTC_BUCK_MOS2,
        DL_ADC12_INPUT_CHAN_3, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    DL_ADC12_configConversionMem(ADC12_0_INST, ADC12_0_ADCMEM_NTC_BUCK_SHUNT1,
        DL_ADC12_INPUT_CHAN_7, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    DL_ADC12_configConversionMem(ADC12_0_INST, ADC12_0_ADCMEM_NTC_BUCK_SHUNT2,
        DL_ADC12_INPUT_CHAN_12, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    DL_ADC12_setSampleTime0(ADC12_0_INST,16);
    DL_ADC12_setSubscriberChanID(ADC12_0_INST,ADC12_0_INST_SUB_CH);
    /* Enable ADC12 interrupt */
    DL_ADC12_clearInterruptStatus(ADC12_0_INST,(DL_ADC12_INTERRUPT_MEM3_RESULT_LOADED));
    DL_ADC12_enableInterrupt(ADC12_0_INST,(DL_ADC12_INTERRUPT_MEM3_RESULT_LOADED));
    DL_ADC12_enableConversions(ADC12_0_INST);
}

void adc0_value_init(HAL_ADC0_CONVERT_Value v){

    v->u16MOS1_value = 0;
    v->u16MOS2_value = 0;
    v->u16SHUNT1_value = 0;
    v->u16SHUNT2_value = 0;

}

void ADC0_Error_Rest(){

    /*Stop time count continue*/
    DL_Timer_stopCounter(TIMER_0_INST);
    /*Stop convert (Register CTL1)*/
    DL_ADC12_stopConversion(ADC12_0_INST);
    /*Disable convert function*//*By the way if want stop repeat mode,type this function*/
    DL_ADC12_disableConversions(ADC12_0_INST);
    /*Disable interrupt and clear interrupt status*/
    DL_ADC12_disableInterrupt(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM3_RESULT_LOADED);
    DL_ADC12_disableEvent(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
    DL_ADC12_clearInterruptStatus(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM3_RESULT_LOADED);
    DL_ADC12_clearEventsStatus(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
}


void ADC0_auto(){

    switch(adc0_order){
    case ADC_init:

        SYSCFG_DL_ADC12_0_init();
//        ADC0_parmeter_init();
        adc0_value_init(&sDrv.adc0);                         /*Initialization MODBUS register data buffer*/
        NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
        adc0_order = Timer_Event_Start;
        break;
    case Timer_Event_Start:

        DL_Timer_startCounter(TIMER_0_INST);        /*Because the project is timer event trigger*/
        adc0_order = ADC_Convert_Finish;

        break;
    case ADC_Convert_Finish:                        /*Just wait for interrupt,in the this way don't do anything*/

        break;

    case ADC_Error:
        ADC0_Error_Rest();
        adc0_order = ADC_init;
        break;
    default:
        break;
    }
}

void ADC12_0_INST_IRQHandler(void){


    switch(DL_ADC12_getPendingInterrupt(ADC12_0_INST)){
    case DL_ADC12_IIDX_MEM3_RESULT_LOADED:

//        DL_GPIO_togglePins(GPIOB, GPIO_GRP_0_PIN_15_PIN);   /*Check timer event trigger happened need time*/
        /*The function used sequence not single*/
        sDrv.adc0.u16MOS1_value = DL_ADC12_getMemResult(ADC12_0_INST,ADC12_0_ADCMEM_NTC_BUCK_MOS1);    /*Get ADC value*/
        sDrv.adc0.u16MOS2_value = DL_ADC12_getMemResult(ADC12_0_INST,ADC12_0_ADCMEM_NTC_BUCK_MOS2);
        sDrv.adc0.u16SHUNT1_value = DL_ADC12_getMemResult(ADC12_0_INST,ADC12_0_ADCMEM_NTC_BUCK_SHUNT1);
        sDrv.adc0.u16SHUNT2_value = DL_ADC12_getMemResult(ADC12_0_INST,ADC12_0_ADCMEM_NTC_BUCK_SHUNT2);
        DL_ADC12_clearInterruptStatus(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);
        DL_ADC12_clearEventsStatus(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
        DL_ADC12_enableConversions(ADC12_0_INST);   /*In the timer event trigger operate,can't enable repeat mode,so need add this function*/

        break;
    default:
        adc0_order = ADC_Error;
        break;
    }
}


