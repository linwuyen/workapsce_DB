#include "ti_msp_dl_config.h"
#include <string.h>
#include "CAN_Parameter.h"
#define ID 256
#define DLC_DATA 9
#define Rxfifo 64


volatile uint32_t gInterruptLine1Status;
uint16_t Fifo_to_buffer();
void REST_CAN0_Clear_ERROR();
//void INIT_CAN_MODE();
//extern DL_MCAN_InitParams MCAN0InitParams;
//extern DL_MCAN_BitTimingParams MCAN0BitTimes;

uint64_t irq,success;
DL_MCAN_RxBufElement rxMsg[Rxfifo];     /*rxMsg struct is take for save receiver can data*/
DL_MCAN_RxFIFOStatus rxFS;              /*rxFs struct is take for save FIFO status*/
DL_MCAN_TxBufElement txMsg0;            /*txMsg0 struct is take for transmission can need struct*/
typedef DL_MCAN_RxBufElement* msgpoint; /*Rx message point*/
typedef DL_MCAN_TxBufElement* outpoint; /*Tx message point*/

typedef struct{
    uint64_t Status;
    uint8_t count;
    uint8_t number;
    uint8_t mush;
    uint16_t u16wait_data;
    uint8_t u8init_can;
}Use;

typedef Use* usepoint;
Use usethis = { .u8init_can = 1 };

void INIT_CAN_MODE(usepoint v);

typedef union {
    uint32_t value;
    struct {
        uint32_t reserved : 18;
        uint32_t id : 11;
        uint32_t other_bits : 3;
    } bits;
}Rx_id;

typedef Rx_id* rx_id;
Rx_id get_id;

typedef struct{
    uint16_t data[8];
}Buffer_save;

typedef Buffer_save* bufferpoint;
Buffer_save buffer_save[256];

enum{
    work = 1,
    call_back = 2,
    id_to_mush = 3333,
    fifo_error = 8888,
    data_error = 6666

};

enum{
    first_set_init_mode          = 1,
    wait_init_mode               = 2,
    set_can_parameter            = 3,
    second_set_normal_mode       = 4,
    wait_normal_mode             = 5,
    set_can_interrupt            = 6,
    finsh_init                   = 7
};

typedef enum{
    INIT_CAN = 0,
    START_RXTX =1,
    REST_INIT = 2

}can_go;

can_go can_do = INIT_CAN;

void init_tx_struct(){

    txMsg0.id = ((uint32_t)(0x4)) << 18U;
    txMsg0.rtr = 0U;
    txMsg0.xtd = 0U;
    txMsg0.esi = 0U;
    txMsg0.brs = 0U;
    txMsg0.fdf = 0U;
    txMsg0.efc = 1U;
    txMsg0.mm = 0xAAU;
    usethis.Status = 0;
    usethis.count = 0;
    usethis.number = 0;
    usethis.mush = 0;
    usethis.u16wait_data = 0;
}



void can_tx_rx(void)
{
    usepoint v = &usethis;
    rx_id rxid = 0;// = &get_id;
    outpoint tx = &txMsg0;


    switch(can_do){

    case INIT_CAN :

        gInterruptLine1Status = 0;

        INIT_CAN_MODE(v);

        NVIC_EnableIRQ(MCAN0_INST_INT_IRQN);
        /*IF can mode ready normal and initialization is finish*/
        if(DL_MCAN_OPERATION_MODE_NORMAL == DL_MCAN_getOpMode(MCAN0_INST) && v->u8init_can == finsh_init){
            init_tx_struct();
            can_do = START_RXTX;
        }
        break;
    case START_RXTX:

        while(v->u16wait_data > v->count){          /*The FIFO and polling can't be same time happened*/
            msgpoint rx = &rxMsg[v->count];         /*This is FIFO way*/
            rxid = (rx_id)&rx->id;                  /*This is union struct can solve id*/
            if(rxid->bits.id < ID){
                bufferpoint rx_buffer = &buffer_save[rxid->bits.id];    /*This is long save buffer,have 256*/
                if(rx->rtr != 1){                                       /*If not remote,else save to long buffer*/
//                    rx_buffer = *((bufferpoint)rx->data);
                    memcpy(rx_buffer->data, rx->data, (sizeof(rx->data[0]) * rx->dlc)); /*This function is copy rx->data to rx_buffer->data and size is dlc multiply one data*/
                }else{                                                                  /*Because if size don't do this way,will copy 64 size to rx_buffer->data,and will be error because the data just size for 8*/
                    tx->id = rx->id;                                                     /*If is remote , prepare tx struct need parameter*/
                    tx->dlc = rx->dlc;                                                   /*DLC can to DLC,but the id have to warning ,the id need << 18 or choose also same type id*/
                    memcpy(tx->data, rx_buffer->data, (sizeof(rx_buffer->data[0]) * tx->dlc));  /*The function is copy rx_buffer to tx,and need choose size*/
                    DL_MCAN_writeMsgRam(MCAN0_INST, DL_MCAN_MEM_TYPE_BUF, 0, &txMsg0);  /*Write message to ram from txMsg0*/
                    DL_MCAN_TXBufAddReq(MCAN0_INST, 0);                                 /*Send request to can bus*/
                }
            }else{
                v->Status = id_to_mush;
            }
            v->count++;
            if(v->u16wait_data == v->count) v->u16wait_data = v->count = 0; /*This FIFO operate*/
        }
        break;

    case REST_INIT:
        REST_CAN0_Clear_ERROR();
        v->u8init_can = first_set_init_mode;
        can_do = INIT_CAN;
        break;

    default:
        break;
    }
}

void MCAN0_INST_IRQHandler(void)
{
    switch (DL_MCAN_getPendingInterrupt(MCAN0_INST)) {
        case DL_MCAN_IIDX_LINE1:
            /* Check MCAN interrupts fired during TX/RX of CAN package */
            gInterruptLine1Status |= DL_MCAN_getIntrStatus(MCAN0_INST);
            DL_MCAN_clearIntrStatus(MCAN0_INST, gInterruptLine1Status,
                DL_MCAN_INTR_SRC_MCAN_LINE_1);
            usethis.Status = Fifo_to_buffer();

            break;
        default:
            break;
    }
}

uint16_t Fifo_to_buffer(){

    usepoint v = &usethis;

    if((gInterruptLine1Status & MCAN_IR_RF1N_MASK) == MCAN_IR_RF1N_MASK){   /*If check the data is FIFO1*/
        rxFS.num = DL_MCAN_RX_FIFO_NUM_1;                                   /*Choose the FIFO1*/
        DL_MCAN_getRxFIFOStatus(MCAN0_INST, &rxFS);                         /*Get FIFO status to rxFS*/
        if(rxFS.fillLvl != 0){                                              /*IF have data*/
            DL_MCAN_readMsgRam(MCAN0_INST, DL_MCAN_MEM_TYPE_FIFO, 0U, rxFS.num, &rxMsg[v->u16wait_data++]); /*Get data message from FIFO ram to rxMsg save*/
            DL_MCAN_writeRxFIFOAck(MCAN0_INST, rxFS.num, rxFS.getIdx);  /*Write ACK to CAN control and tell them the data is read and used can cover*/
            gInterruptLine1Status &= ~(MCAN_IR_RF1N_MASK);
            return work;
        }else{
            gInterruptLine1Status &= ((uint32_t)0x00000000U);
            can_do = REST_INIT;
            return data_error;
        }
    }else{
        gInterruptLine1Status &= ((uint32_t)0x00000000U);
        can_do = REST_INIT;
        return fifo_error;
    }
}

void REST_CAN0_Clear_ERROR(){

    /*This is for clear Error Status and happened on error have to do way */

    /*Disable Interrupt*/
    DL_MCAN_enableIntrLine(MCAN0_INST, DL_MCAN_INTR_LINE_NUM_1, 0U);
    DL_MCAN_disableInterrupt(MCAN0_INST,(DL_MCAN_MSP_INTERRUPT_LINE1));
    NVIC_DisableIRQ(MCAN0_INST_INT_IRQN);

    /*clear_Error_Interrupt_for_find_Interrupt error . For Error Status*/
    DL_MCAN_eccClearErrorStatus(MCAN0_INST, DL_MCAN_ECC_ERR_TYPE_DED);
    /*clear_Error_Interrupt_for find Interrupt error. For Interrupt Status*/
    DL_MCAN_eccClearIntrStatus(MCAN0_INST, DL_MCAN_ECC_ERR_TYPE_DED);
    /*Clear happened on error after also wait the Interrupt. Register ICLR*/
    DL_MCAN_clearInterruptStatus(MCAN0_INST,DL_MCAN_MSP_INTERRUPT_LINE1);

}

void INIT_CAN_MODE(usepoint v){

    if(v->u8init_can == first_set_init_mode ){
        /*set INIT mode*/
        DL_MCAN_setOpMode(MCAN0_INST, DL_MCAN_OPERATION_MODE_SW_INIT);
        v->u8init_can = wait_init_mode;
    }
    if(v->u8init_can == wait_init_mode){
        /* Wait to be INIT mode */
        if(DL_MCAN_OPERATION_MODE_SW_INIT != DL_MCAN_getOpMode(MCAN0_INST)){
            v->u8init_can = wait_init_mode;
        }else{ v->u8init_can = set_can_parameter;}
    }
    if(v->u8init_can == set_can_parameter){
        /*Init_Can_Mode_example_CANFD*/
        DL_MCAN_init(MCAN0_INST, (DL_MCAN_InitParams *) &MCAN0InitParams);
        /*set_BAUD_RATE_Register_MCAN_NBTP*/
        DL_MCAN_setBitTime(MCAN0_INST, (DL_MCAN_BitTimingParams*) &MCAN0BitTimes);
        /*set_no_Filters|all_id_receiver*//*not_find_StdMask*//*Register_ MCAN_XIDAM*/
        DL_MCAN_setExtIDAndMask(MCAN0_INST, MCAN0_INST_MCAN_EXT_ID_AND_MASK );
        v->u8init_can = second_set_normal_mode;
    }
    if(v->u8init_can == second_set_normal_mode){
        /*selecet_set_Normal_can_mode*/
        DL_MCAN_setOpMode(MCAN0_INST, DL_MCAN_OPERATION_MODE_NORMAL);
        v->u8init_can = wait_normal_mode;
    }
    if(v->u8init_can == wait_normal_mode){
        /*wait to be Normal mode*/
        if(DL_MCAN_OPERATION_MODE_NORMAL != DL_MCAN_getOpMode(MCAN0_INST)){
            v->u8init_can = wait_normal_mode;
        }else{v->u8init_can = set_can_interrupt;}
    }
    if(v->u8init_can == set_can_interrupt){
        /*MCAN0_Interrupt_Register_MCAN_IE( Enable_interrupt )*/
        DL_MCAN_enableIntr(MCAN0_INST, MCAN0_INST_MCAN_INTERRUPTS, 1U);
        /*select_Interrupt_Line1*/
        DL_MCAN_selectIntrLine(MCAN0_INST, DL_MCAN_INTR_MASK_ALL, DL_MCAN_INTR_LINE_NUM_1);
        /*Enable_Interrupt_Line1_Register_MCAN_ILE*/
        DL_MCAN_enableIntrLine(MCAN0_INST, DL_MCAN_INTR_LINE_NUM_1, 1U);

        /*MCAN0_Interrupt_Register_IMASK(Line 1)*/
        /*clear_Interrupt_Line1_Status*/
        DL_MCAN_clearInterruptStatus(MCAN0_INST,(DL_MCAN_MSP_INTERRUPT_LINE1));
        /*Enable_Interrupt_Line1_Register_IMASK*/
        DL_MCAN_enableInterrupt(MCAN0_INST,(DL_MCAN_MSP_INTERRUPT_LINE1));
        v->u8init_can = finsh_init;
    }
}
