/*
 * adc_auto.c
 *
 *  Created on: 2024�~6��25��
 *      Author: feng_hsu
 */
#include "ti_msp_dl_config.h"
#include <stdbool.h>
#include <stdint.h>
#include <COMP_OPA_Parameter.h>

#define High_value 1800
#define Low_value  650

typedef struct{
    bool adc_convert;
    bool adc_convert_finish;
    uint32_t u8comp_dac_value;
    uint32_t u64adcvalue;
//    uint8_t u8software_count;
    uint32_t u32adc_event_status;
    uint32_t u32adc_irq_status;
    uint32_t u32high;
    uint32_t u32low;

}Value;

Value need_value;
typedef Value* value_point;

Value need_value = {
  .adc_convert = true,
  .adc_convert_finish = false,
  .u64adcvalue = 0,
  .u8comp_dac_value = 0,
  .u32adc_event_status = 0,
  .u32adc_irq_status = 0,
  .u32high = High_value,
  .u32low = Low_value
};

typedef enum{
    ADC_INIT = 0,
    ADC_TIME_CONVERT = 1,
    ADC_CONVERT_FINISH = 3,
    ADC_REST = 4
}ADC_order;

ADC_order adc_order = ADC_INIT;

void Adc_init(){

    /*Set repeat mode and sample mode and trigger and bit choose and choose binary unsigned or signed*/
    DL_ADC12_initSingleSample(ADC12_0_INST,
        DL_ADC12_REPEAT_MODE_DISABLED, DL_ADC12_SAMPLING_SOURCE_AUTO, DL_ADC12_TRIG_SRC_EVENT,
        DL_ADC12_SAMP_CONV_RES_12_BIT, DL_ADC12_SAMP_CONV_DATA_FORMAT_UNSIGNED);
    /*Set Register MEMCTL*/
    DL_ADC12_configConversionMem(ADC12_0_INST, ADC12_0_ADCMEM_0,
        DL_ADC12_INPUT_CHAN_0, DL_ADC12_REFERENCE_VOLTAGE_VDDA, DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0, DL_ADC12_AVERAGING_MODE_ENABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED, DL_ADC12_TRIGGER_MODE_AUTO_NEXT, DL_ADC12_WINDOWS_COMP_MODE_DISABLED);
    /*Enable Averaging Mode for result value stabilize,by the way if average select big number the result value more stabilize*/
    /*But too big number average need more time than select small number average spend time to convert*/
    /*If used averaging need choose binary unsigned*/
    DL_ADC12_configHwAverage(ADC12_0_INST,DL_ADC12_HW_AVG_NUM_ACC_8,DL_ADC12_HW_AVG_DEN_DIV_BY_8);
    /*Sample time 32 = 10us*/
    DL_ADC12_setSampleTime0(ADC12_0_INST,32);
    /*Set event subscriberChanID*/
    DL_ADC12_setSubscriberChanID(ADC12_0_INST,ADC12_0_INST_SUB_CH);
    /*Enalbe event,but not find can use way interrupt switch function*/
    DL_ADC12_enableEvent(ADC12_0_INST,(DL_ADC12_EVENT_MEM0_RESULT_LOADED));
    /*Clear interrupt status and enable ADC interrupt*/
    DL_ADC12_clearInterruptStatus(ADC12_0_INST,(DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED));
    DL_ADC12_enableInterrupt(ADC12_0_INST,(DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED));
    /*Enable convert function*/
    DL_ADC12_enableConversions(ADC12_0_INST);
    /*Enable IRQN interrupt*/
//    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    /*If need save power,can choose turn off power or turn on power by function
     * But if choose save power operate,have to warning adc wake up time need 1.22us + duration for sample window
     * DL_ADC12_enablePower(ADC12_0_INST);
     * DL_ADC12_disablePower(ADC12_0_INST);
     */
}

void COMPdac_OPA_init(){
    /*COMP configuration initialization*/
    DL_COMP_init(COMP_0_INST, (DL_COMP_Config *) &new_COMP_0Config);
    DL_COMP_refVoltageInit(COMP_0_INST, (DL_COMP_RefVoltageConfig *) &new_COMP_0VRefConfig);
    DL_COMP_setDACCode0(COMP_0_INST, COMP_0_DACCODE0);
    DL_COMP_enable(COMP_0_INST);
    /*OPA configuration initialization*/
    DL_OPA_init(OPA_0_INST, (DL_OPA_Config *) &new_OPA_0Config0);
    DL_OPA_enableRailToRailInput(OPA_0_INST);
    DL_OPA_setGainBandwidth(OPA_0_INST, DL_OPA_GBW_HIGH);
    DL_OPA_enable(OPA_0_INST);
}
void ADC_Error_Rest(){

    /*Stop time count continue*/
    DL_Timer_stopCounter(TIMER_0_INST);
    /*Stop convert (Register CTL1)*/
    DL_ADC12_stopConversion(ADC12_0_INST);
    /*Disable convert function*//*By the way if want stop repeat mode,type this function*/
    DL_ADC12_disableConversions(ADC12_0_INST);
    /*Disable interrupt and clear interrupt status*/
    DL_ADC12_disableInterrupt(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);
    DL_ADC12_disableEvent(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
    DL_ADC12_clearInterruptStatus(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);
    DL_ADC12_clearEventsStatus(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
}

void COMPdac_OPA_Rest(){

    DL_COMP_disable(COMP_0_INST);
    DL_OPA_disable(OPA_0_INST);
    DL_COMP_reset(COMP_0_INST);
    DL_OPA_reset(OPA_0_INST);

}

void adc_auto(){
    value_point v = &need_value;

    switch(adc_order){
    case ADC_INIT:

        /*Check any event flag have pending,forget doesn't enable*/
        v->u32adc_event_status = DL_ADC12_getRawEventsStatus(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
        /*Check any interrupt flag have pending,forget doesn't have enable*/
        v->u32adc_irq_status = DL_ADC12_getRawInterruptStatus(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);
        /*If have flag,clear all*/
        if(v->u32adc_event_status != 0 || v->u32adc_irq_status != 0){
            DL_ADC12_clearInterruptStatus(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);
            DL_ADC12_clearEventsStatus(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);
        }

//        Adc_init();
//        COMPdac_OPA_init();
        NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
        adc_order = ADC_TIME_CONVERT;
        break;

    case ADC_TIME_CONVERT:
        /*Start time count*/
        DL_Timer_startCounter(TIMER_0_INST);
        adc_order = ADC_CONVERT_FINISH;
        break;

    case ADC_CONVERT_FINISH:
        /*
         * In the communication ( Like CAN or I2C ..),we don't want lost any message data
         * so when happened interrupt ,first time to get message data in the temporary buffer
         * second wait time until have free time to process message data in the long buffer or other thing by software.
         * But in the ADC or DAC,this function need immediately (now) to process , so if happened interrupt
         * must be immediately to process in the interrupt, maybe for get value or trigger something or other thing.
         * So this code , in software switch don't to do anything,let's wait trigger by timer event happened interrupt.
         */

        break;
    case ADC_REST:
        ADC_Error_Rest();
        COMPdac_OPA_Rest();
        adc_order = ADC_INIT;
    default:
        break;
    }
}

void ADC12_0_INST_IRQHandler(void) {            /*This is Timer Event trigger (Set 1s trigger)*/
    value_point v = &need_value;

    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)){
    case DL_ADC12_IIDX_MEM0_RESULT_LOADED:

//        DL_GPIO_togglePins(GPIOA,DL_GPIO_PIN_0);    /*To see how second to trigger*/

        v->u64adcvalue = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);   /*Get ADC value */

        v->u8comp_dac_value = v->u64adcvalue >> 4;
        /*The ADC input value to DAC output value
         * And the ADC value is 12 bit ( 0xFFF ) , But the DAC value is 8 bit ( 0xFF )
         * So,need to move right for 4 bit
         * Like 4095 >> 255 is 16 multiple,so move right for 4 bit = 16 multiple
         */

        DL_COMP_setDACCode0(COMP_0_INST, v->u8comp_dac_value);  /*Set value to DACCode0 for OPA need DAC8.xOUT be input*/

        DL_ADC12_clearInterruptStatus(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);  /*Clear interrupt*/

        DL_ADC12_clearEventsStatus(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);         /*Clear event interrupt*/


        /*Because disable repeat mode ,so have to enable convert function*/
        /*The function will repeat convert*/
        DL_ADC12_enableConversions(ADC12_0_INST);

        break;

    default:
        adc_order = ADC_REST;   /*If error will go to switch ADC_REST to clear error*/
        break;
    }
}

