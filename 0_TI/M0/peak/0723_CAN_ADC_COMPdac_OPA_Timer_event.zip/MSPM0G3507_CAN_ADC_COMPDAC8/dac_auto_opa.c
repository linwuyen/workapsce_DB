///*
// * dac_auto.c
// *
// *  Created on: 2024�~7��16��
// *      Author: feng_hsu
// */
//#include "ti_msp_dl_config.h"
//#include "DAC_OPA_Parameter.h"
//
//typedef enum{
//    DAC_OPA_INIT = 1,
//    DAC_WAIT_TRIGGER = 2,
//    REST_ERROR = 3
//}DAC_ORDER;
//
//DAC_ORDER dac_order = DAC_OPA_INIT;
//
//typedef struct{
//    uint16_t set_dac_value[32];
//    uint16_t list_count;
//    uint16_t size_rang;
//}DAC_NEED;
//
//DAC_NEED dac_need = {
//    .set_dac_value = {
//    2048, 2447, 2831, 3185, 3496, 3750,3940, 4056, 4095, 4056,
//    3940, 3750, 3496, 3185, 2831, 2447, 2048, 1648,1264, 910,
//    599, 345, 155, 39, 0,39, 155, 345, 599, 910, 1264, 1648
//    },
//    .list_count = 0,
//    .size_rang = (sizeof(dac_need.set_dac_value)/sizeof(uint16_t))
//};
//
//typedef DAC_NEED* dac_point;
//
//void dac_parameter_init(){
//
//    DL_DAC12_init(DAC0, (DL_DAC12_Config *) &dac_parameter);
//    DL_DAC12_output12(DAC0, 4095);
//    DL_DAC12_enableInterrupt(DAC0, (DL_DAC12_INTERRUPT_FIFO_TWO_QTRS_EMPTY));
//    DL_DAC12_enable(DAC0);
//
//}
//
//void opa_parameter_init(){
//
//    DL_OPA_init(OPA_0_INST, (DL_OPA_Config *) &opa_parameter);
//    DL_OPA_enableRailToRailInput(OPA_0_INST);
//    DL_OPA_setGainBandwidth(OPA_0_INST, DL_OPA_GBW_HIGH);
//    DL_OPA_enable(OPA_0_INST);
//
//}
//
//void Rest_Error(){
//
//    DL_DAC12_disableSampleTimeGenerator(DAC0);
//    DL_DAC12_disableInterrupt(DAC0,DL_DAC12_INTERRUPT_FIFO_TWO_QTRS_EMPTY);
//    DL_DAC12_clearInterruptStatus(DAC0,DL_DAC12_INTERRUPT_FIFO_TWO_QTRS_EMPTY);
//    DL_DAC12_disableFIFO(DAC0);
//    DL_DAC12_disableOutputPin(DAC0);
//    DL_OPA_disable(OPA_0_INST);
//    DL_DAC12_disable(DAC0);
//
//}
//
//void dac_auto_opa(){
//
//    switch(dac_order){
//
//        case DAC_OPA_INIT:
//            dac_parameter_init();
//            opa_parameter_init();
//            NVIC_EnableIRQ(DAC12_INT_IRQN);
//            dac_order = DAC_WAIT_TRIGGER;
//            break;
//        case DAC_WAIT_TRIGGER:
//
//            break;
//        case REST_ERROR:
//            Rest_Error();
//            dac_order = DAC_OPA_INIT;
//            break;
//        default:
//            break;
//    }
//}
//
//void DAC12_IRQHandler(void){
//    dac_point v = &dac_need;
//
//    switch(DL_DAC12_getPendingInterrupt(DAC0)){
//    case DL_DAC12_IIDX_FIFO_1_2_EMPTY:
//        DL_DAC12_output12(DAC0,v->set_dac_value[v->list_count++]);
//        if(v->list_count >= v->size_rang){
//            v->list_count = 0;
//        }
//        break;
//    default:
//        dac_order = REST_ERROR;
//        break;
//    }
//
//
//}
