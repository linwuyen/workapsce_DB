/*
 * COMP_OPA_Parameter.h
 *
 *  Created on: 2024�~7��22��
 *      Author: feng_hsu
 */

#ifndef COMP_OPA_PARAMETER_H_
#define COMP_OPA_PARAMETER_H_
#include "ti_msp_dl_config.h"

/*COMP configuration*/

DL_COMP_Config new_COMP_0Config ={
    .channelEnable = DL_COMP_ENABLE_CHANNEL_NONE,
    .mode          = DL_COMP_MODE_FAST,
    .negChannel    = DL_COMP_IMSEL_CHANNEL_0,
    .posChannel    = DL_COMP_IPSEL_CHANNEL_0,
    .hysteresis    = DL_COMP_HYSTERESIS_20,
    .polarity      = DL_COMP_POLARITY_NON_INV
};

DL_COMP_RefVoltageConfig new_COMP_0VRefConfig ={
    .mode           = DL_COMP_REF_MODE_STATIC,
    .source         = DL_COMP_REF_SOURCE_VDDA_DAC,
    .terminalSelect = DL_COMP_REF_TERMINAL_SELECT_NEG,
    .controlSelect  = DL_COMP_DAC_CONTROL_SW,
    .inputSelect    = DL_COMP_DAC_INPUT_DACCODE0
};

/*OPA configuration*/

DL_OPA_Config new_OPA_0Config0 ={
    .pselChannel    = DL_OPA_PSEL_DAC8_OUT,
    .nselChannel    = DL_OPA_NSEL_RTOP,
    .mselChannel    = DL_OPA_MSEL_OPEN,
    .gain           = DL_OPA_GAIN_N0_P1,
    .outputPinState = DL_OPA_OUTPUT_PIN_ENABLED,
    .choppingMode   = DL_OPA_CHOPPING_MODE_DISABLE,
};









#endif /* COMP_OPA_PARAMETER_H_ */
