/*
 * G3507_main.c
 *
 *  Created on: 2024�~6��25��
 *      Author: feng_hsu
 */
#include "ti_msp_dl_config.h"
extern void can_tx_rx();
extern void adc_auto();
extern void dac_auto_opa();
uint64_t timenow;
int main(void){

    SYSCFG_DL_init();

    while(1){
    can_tx_rx();
    adc_auto();
//    dac_auto_opa();


    }


}



