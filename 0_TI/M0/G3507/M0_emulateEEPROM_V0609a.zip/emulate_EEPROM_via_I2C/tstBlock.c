/*
 * tstBlock.c
 *
 *  Created on: 2023�~5��24��
 *      Author: cody_chen
 */


#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"

typedef enum {
    _INIT_TEST_BLOCK_RAM = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _FREE_TEST_EEPROM
} TEST_EVENT;

TEST_EVENT tstfsm = _FREE_TEST_EEPROM;
int initValue = 0;

void initBlockRam(void)
{
    for(int i=initValue; i<EMU_KBYTES; i++) {
        writeEmuEeprom(i, i%0xFF);
    }
}

void resetBlockRam(void)
{
    for(int i=initValue; i<EMU_KBYTES; i++) {
        writeEmuEeprom(i, 0xFF);
    }
}

void tstEmuEeprom(void)
{


    switch(tstfsm) {
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
        break;
    case _FREE_TEST_EEPROM:
    default:

        break;
    }

    tstfsm = _FREE_TEST_EEPROM;
}

