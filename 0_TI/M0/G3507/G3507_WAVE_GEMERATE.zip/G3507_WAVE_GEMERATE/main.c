

#include "ti_msp_dl_config.h"

/* This results in approximately 0.5s of delay assuming 32MHz CPU_CLK */
#define DELAY (10)

uint32_t DAC_value;

void rampwave(void){

    for(DAC_value =0 ;DAC_value<4095;DAC_value++){
    DL_DAC12_output12(DAC0, DAC_value);
    }

}


#define WAVE_POINTS 128
uint16_t triangle_wave[WAVE_POINTS];

void triangle_wave_table(void)
{
    const int half = WAVE_POINTS / 2;
    const int span = half - 1;
    for (int i = 0; i < half; i++)
        triangle_wave[i] = (uint16_t)((4095UL * i) / span);
    for (int i = 0; i < half; i++)
        triangle_wave[half + i] = 4095U - triangle_wave[i];
}

void triWave(void)
{
    static uint16_t wave_index = 0;

    DL_DAC12_output12(DAC0, triangle_wave[wave_index]);

    wave_index++;
    if (wave_index >= WAVE_POINTS)
        wave_index = 0;
}

int main(void)
{
    /* Power on GPIO, initialize pins as digital outputs */
    SYSCFG_DL_init();

    /* Default: LED1 and LED3 ON, LED2 OFF */

    triangle_wave_table();

    while (1) {
//        delaycycles(DELAY);
//        DL_GPIO_togglePins(GPIO_LEDS_PORT,GPIO_LEDS_USER_LED_1_PIN );


//        triWave();
        rampwave();
    }
}
