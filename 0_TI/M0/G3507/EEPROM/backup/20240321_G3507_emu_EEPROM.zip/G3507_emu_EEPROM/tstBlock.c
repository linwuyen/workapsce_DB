/*
 * tstBlock.c
 *
 *  Created on: 2023¦~5¤ë24¤é
 *      Author: cody_chen
 */


#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"

typedef enum {
    _INIT_TEST_BLOCK_RAM = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _VARIFY_BLOCK_DATA,
    _Load_emu_DATA,
    _FREE_TEST_EEPROM
} TEST_EVENT;

TEST_EVENT tstfsm = _FREE_TEST_EEPROM;
int beginAddress = 0;
int ptrAddress = 0;
int endAddress = 0;
int procBytes = 0;
int testBytes = EMU_KBYTES;

typedef enum {
    _EV_GET_ADDRESS = 0,
    _EV_UPLOAD_DATA,
    _EV_END_OF_UPLOAD,
    _EV_END_OF_INIT_TESTBLOCK
}REG_INIT_TSTBLOCK;

typedef REG_INIT_TSTBLOCK REG_RST_TSTBLOCK;

REG_INIT_TSTBLOCK regInitTstBlock = _EV_GET_ADDRESS;

void initBlockRam(void)
{
        switch(regInitTstBlock) {
            case _EV_GET_ADDRESS:
                endAddress = beginAddress + testBytes;
                ptrAddress = beginAddress;
                procBytes = 0;
                regInitTstBlock = _EV_UPLOAD_DATA;
            break;

          case _EV_UPLOAD_DATA:
                if(procBytes < testBytes) {
                     writeEmuEeprom(ptrAddress, ptrAddress%0xFF);
                     ptrAddress++;
                     procBytes++;
                     ptrAddress&=0x3FF;
                     if(EMU_SIZE_OF_SECTOR <= ptrAddress) ptrAddress -= EMU_SIZE_OF_SECTOR;
                }
                else {
                    ptrAddress = beginAddress;
                    regInitTstBlock = _EV_END_OF_UPLOAD;
                }

            break;

          case _EV_END_OF_UPLOAD:
                tstfsm = _FREE_TEST_EEPROM;
                regInitTstBlock = _EV_GET_ADDRESS;
            break;

            default:
            break;
        }
}




REG_RST_TSTBLOCK regRESTstBlock = _EV_GET_ADDRESS;

void resetBlockRam(void)
{
        switch(regRESTstBlock) {
            case _EV_GET_ADDRESS:
                endAddress = beginAddress + testBytes;
                ptrAddress = beginAddress;
                procBytes = 0;
                regRESTstBlock = _EV_UPLOAD_DATA;
            break;

          case _EV_UPLOAD_DATA:
              if(procBytes < testBytes) {
                     writeEmuEeprom(ptrAddress, 0xFF);
                     ptrAddress++;
                     procBytes++;
                     if(EMU_SIZE_OF_SECTOR <= ptrAddress) ptrAddress -= EMU_SIZE_OF_SECTOR;
                }
                else {
                    ptrAddress = beginAddress;
                    regRESTstBlock = _EV_END_OF_UPLOAD;
                }

            break;

          case _EV_END_OF_UPLOAD:
                tstfsm = _FREE_TEST_EEPROM;
                regRESTstBlock = _EV_GET_ADDRESS;
            break;

            default:

            break;

        }
}

void varifyBlockFlash(void)
{

}


void tstEmuEeprom(void)
{
    switch(tstfsm) {
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
                tstfsm = _FREE_TEST_EEPROM;
        break;

    case _VARIFY_BLOCK_DATA:
        setVerifyEmuEeprom();
            tstfsm = _FREE_TEST_EEPROM;
        break;

    case _FREE_TEST_EEPROM:
    default:

    case _Load_emu_DATA:
        Load_EEPROM_Data_G();
        tstfsm = _FREE_TEST_EEPROM;
        break;
    }


}

