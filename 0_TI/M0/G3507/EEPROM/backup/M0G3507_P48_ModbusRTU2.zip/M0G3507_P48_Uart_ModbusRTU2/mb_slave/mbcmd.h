/*
 *  File Name: mbcmd.h
 *
 *  Created on: 3/25/2024
 *  Author: POWER2-54FD92
 */

#ifndef MBCMD_H_
#define MBCMD_H_



typedef enum {
	_g0_MODE = 0,
	_g1000_MODE,
	_g9000_MODE,
    _END_OF_MODE
} ID_MODE;


enum {
	_muCOMmonHEAder = 0,                    // #0  T_U16                
	_muCOMmonLENgth = 1,                    // #1  T_U16                
	_muMAChineINFOrmationOFFSet = 2,        // #2  T_U16                
	_muUSERPARameterOFFSet = 3,             // #3  T_U16                
	_muADVAncePARameterOFFSet = 4,          // #4  T_U16                
	_muCOMmonCHEcksum = 5,                  // #5  T_U16                
    _end_of_0_id = 6
};

enum {
	_muREAdFROmADDRess0 = 1000,             // #1000  T_U32             
	_muREAdFROmADDRess1 = 1001,             // #1001  T_U32             
	_muGETDATa0 = 1002,                     // #1002  T_U32             
	_muGETDATa1 = 1003,                     // #1003  T_U32             
	_muREAdSTAtus = 1004,                   // #1004  T_U16             
	_muREAdACTIon = 1005,                   // #1005  T_U16             
    _end_of_1000_id = 4
};

enum {
	_muCOUntryCODe = 9000,                  // #9000  T_U16             
	_muVENderid = 9001,                     // #9001  T_U16             
	_muBUIldDATe0 = 9002,                   // #9002  T_U32             
	_muBUIldDATe1 = 9003,                   // #9003  T_U32             
    _end_of_9000_id = 3
};

typedef union { 
    uint16_t u16MbusData[16];
    struct { 
		uint16_t u16COMmonHEAder;
		uint16_t u16COMmonLENgth;
		uint16_t u16MAChineINFOrmationOFFSet;
		uint16_t u16USERPARameterOFFSet;
		uint16_t u16ADVAncePARameterOFFSet;
		uint16_t u16COMmonCHEcksum;
		uint32_t u32REAdFROmADDRess;
		uint32_t u32GETDATa;
		uint16_t u16REAdSTAtus;
		uint16_t u16REAdACTIon;
		uint16_t u16COUntryCODe;
		uint16_t u16VENderid;
		uint32_t u32BUIldDATe;
    }; 
} REG_MBUSDATA;
extern REG_MBUSDATA regMbusData;
extern int chkValidAddress(uint16_t addr);
extern uint16_t getModbusData(uint16_t addr);
extern uint16_t setModbusData(uint16_t addr, uint16_t data);




#endif /* MBCMD_H_ */

