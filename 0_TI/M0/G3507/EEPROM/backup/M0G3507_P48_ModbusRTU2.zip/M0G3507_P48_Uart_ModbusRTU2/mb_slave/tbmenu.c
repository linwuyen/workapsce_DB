/*
 *  File Name: tbmenu.c
 *
 *  Created on: 3/25/2024
 *  Author: POWER2-54FD92
 */

#include "ModbusSlave.h"
#include "mbcmd.h"


REG_MBUSDATA regMbusData;

int chkValidAddress(uint16_t addr) {
    switch(addr) {
	    case _muCOMmonHEAder:                                           
	    case _muCOMmonLENgth:                                           
	    case _muMAChineINFOrmationOFFSet:                               
	    case _muUSERPARameterOFFSet:                                    
	    case _muADVAncePARameterOFFSet:                                 
	    case _muCOMmonCHEcksum:                                         
	    case _muREAdFROmADDRess0:                                       
	    case _muREAdFROmADDRess1:                                       
	    case _muGETDATa0:                                               
	    case _muGETDATa1:                                               
	    case _muREAdSTAtus:                                             
	    case _muREAdACTIon:                                             
	    case _muCOUntryCODe:                                            
	    case _muVENderid:                                               
	    case _muBUIldDATe0:                                             
	    case _muBUIldDATe1:                                             
        return 0;
    default:
        return MB_ERROR_ILLEGALADDR;
    }
}

uint16_t getModbusData(uint16_t addr) {
    switch(addr) {
	    case _muCOMmonHEAder: return regMbusData.u16MbusData[0];                            
	    case _muCOMmonLENgth: return regMbusData.u16MbusData[1];                            
	    case _muMAChineINFOrmationOFFSet: return regMbusData.u16MbusData[2];                            
	    case _muUSERPARameterOFFSet: return regMbusData.u16MbusData[3];                            
	    case _muADVAncePARameterOFFSet: return regMbusData.u16MbusData[4];                            
	    case _muCOMmonCHEcksum: return regMbusData.u16MbusData[5];                            
	    case _muREAdFROmADDRess0: return regMbusData.u16MbusData[6];                            
	    case _muREAdFROmADDRess1: return regMbusData.u16MbusData[7];                            
	    case _muGETDATa0: return regMbusData.u16MbusData[8];                            
	    case _muGETDATa1: return regMbusData.u16MbusData[9];                            
	    case _muREAdSTAtus: return regMbusData.u16MbusData[10];                            
	    case _muREAdACTIon: return regMbusData.u16MbusData[11];                            
	    case _muCOUntryCODe: return regMbusData.u16MbusData[12];                            
	    case _muVENderid: return regMbusData.u16MbusData[13];                            
	    case _muBUIldDATe0: return regMbusData.u16MbusData[14];                            
	    case _muBUIldDATe1: return regMbusData.u16MbusData[15];                            
    default:
        return 0xFFFF;
    }
}

uint16_t setModbusData(uint16_t addr, uint16_t data) {
    switch(addr) {
	    case _muCOMmonHEAder: regMbusData.u16MbusData[0] = data; break;                            
	    case _muCOMmonLENgth: regMbusData.u16MbusData[1] = data; break;                            
	    case _muMAChineINFOrmationOFFSet: regMbusData.u16MbusData[2] = data; break;                            
	    case _muUSERPARameterOFFSet: regMbusData.u16MbusData[3] = data; break;                            
	    case _muADVAncePARameterOFFSet: regMbusData.u16MbusData[4] = data; break;                            
	    case _muCOMmonCHEcksum: regMbusData.u16MbusData[5] = data; break;                            
	    case _muREAdFROmADDRess0: regMbusData.u16MbusData[6] = data; break;                            
	    case _muREAdFROmADDRess1: regMbusData.u16MbusData[7] = data; break;                            
	    case _muGETDATa0: regMbusData.u16MbusData[8] = data; break;                            
	    case _muGETDATa1: regMbusData.u16MbusData[9] = data; break;                            
	    case _muREAdSTAtus: regMbusData.u16MbusData[10] = data; break;                            
	    case _muREAdACTIon: regMbusData.u16MbusData[11] = data; break;                            
	    case _muCOUntryCODe: regMbusData.u16MbusData[12] = data; break;                            
	    case _muVENderid: regMbusData.u16MbusData[13] = data; break;                            
	    case _muBUIldDATe0: regMbusData.u16MbusData[14] = data; break;                            
	    case _muBUIldDATe1: regMbusData.u16MbusData[15] = data; break;                            
    default:
        return 0xFFFF;
    }
    return data;
}



