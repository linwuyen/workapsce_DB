/*
 *  File Name: linkVariables.c
 *
 *  Created on: 3/25/2024
 *  Author: POWER2-54FD92
 */

#include "ModbusCommon.h"
#include "ModbusSlave.h"


void initRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	p->pReg->u16COMmonHEAder = 1234; 
	p->pReg->u16COMmonLENgth = 4; 
	p->pReg->u16MAChineINFOrmationOFFSet = 9000; 
	p->pReg->u16USERPARameterOFFSet = 1000; 
	p->pReg->u16ADVAncePARameterOFFSet = 2000; 
	p->pReg->u16COMmonCHEcksum = 13238; 
	p->pReg->u16COUntryCODe = 886; 
	p->pReg->u16VENderid = 2423; 
	p->pReg->u32BUIldDATe = 2023083110; 
}

void readRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	p->pReg->u32REAdFROmADDRess = sRead.u32Addr; 
	p->pReg->u32GETDATa = sRead.u32Data; 
	p->pReg->u16REAdSTAtus = sRead.u16Status; 
	p->pReg->u16REAdACTIon = sRead.u16Action; 
}

void writeReg(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	switch(p->info.rwfrom) {
	case _muREAdFROmADDRess0 :   sRead.u32Addr = p->pReg->u32REAdFROmADDRess; break;
	case _muGETDATa0 :   sRead.u32Data = p->pReg->u32GETDATa; break;
	case _muREAdSTAtus :   sRead.u16Status = p->pReg->u16REAdSTAtus; break;
	case _muREAdACTIon :   sRead.u16Action = p->pReg->u16REAdACTIon; break;
	default:
	    break;
	}
}

void writeRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	sRead.u32Addr = p->pReg->u32REAdFROmADDRess; 
	sRead.u32Data = p->pReg->u32GETDATa; 
	sRead.u16Status = p->pReg->u16REAdSTAtus; 
	sRead.u16Action = p->pReg->u16REAdACTIon; 
}

