#include "ti_msp_dl_config.h"
#include "emu_eeprom.h"

int main(void)
{
    SYSCFG_DL_init();

    while (1)
    {
        execEmuEeprom();
    }
}
