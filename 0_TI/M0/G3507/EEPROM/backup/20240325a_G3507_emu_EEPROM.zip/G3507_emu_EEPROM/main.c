#include "common.h"
#include "emu_eeprom.h"
#include "ModbusSlave.h"
#include "i2c_eeprom.h"

Modbus_tstpackage pkg;

void task25msec(void *s)
{
    DL_GPIO_togglePins(GPIO_LEDS_PORT, GPIO_LEDS_USER_TEST_PIN);
}

void task50msec(void *s)
{
    switch(pkg.u16Action){
    case 1:
        pkg.u32AddrData = L.gData64_0;
        pkg.u16Status = pkg.u32Data;
        pkg.u16Action = 0;
        break;
    default:
        break;
    }
}

typedef struct _ST_TIMETASK
{
    void (*fn)(void *s);
    uint32_t cnt;
    uint32_t max;
} ST_TIMETASK;

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] =
{
  { task25msec,    0,  T_25MS},
  {task50msec,     0,  T_50MS},
  {          0,    0,       0}
};

bool_t scanTimeTask(ST_TIMETASK *t, void *s)
{
    uint32_t delta_t;
    uint32_t u32Cnt = SWTIMER_CNT;

    if (t->cnt > u32Cnt)
    {
        delta_t = u32Cnt + SW_TIMER - t->cnt;
    }
    else
    {
        delta_t = u32Cnt - t->cnt;
    }

    if (delta_t >= t->max)
    {
        t->fn(s);
        t->cnt = u32Cnt;
        return true;
    }
    else
    {
        return false;
    }
}

RAMFUNC void ramMainLoop(void)
{
    while (1)
    {
    }
}

int main(void)
{
    SYSCFG_DL_init();

    DL_SYSCTL_clearECCErrorStatus();

    while (1)
    {
        scanTimeTask(&time_task[id_ttask++], (void*) 0);
        if (0 == time_task[id_ttask].fn)id_ttask = 0;

        exeModbusSlave((SCI_MODBUS *)&mbcomm);

        execEmuEeprom();

        tstEmuEeprom();

        execI2cSlave();

        //�ˬdRAM�PFLASH�g�J
        tstWrite();

        //�ˬdI2CBUS
        checkI2CBus();
    }
}
