
#include "ti_msp_dl_config.h"

volatile uint16_t AdcResult;

#define Resolution  4095
#define Vref   3.3

float corrected_voltage;

uint16_t offset;
uint16_t gain;


int main(void)
{
    SYSCFG_DL_init();

    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
    DL_ADC12_startConversion(ADC12_0_INST);
    DL_TimerG_startCounter(TIMER_0_INST);

    while (1) {
    }
}

void TIMER_0_INST_IRQHandler(void)
{
    switch (DL_TimerG_getPendingInterrupt(TIMER_0_INST)) {
        case DL_TIMER_IIDX_ZERO:

//           AdcResult = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
           AdcResult;
//            corrected_voltage =  (float)AdcResult * step * gain;

            corrected_voltage = AdcResult/(float)Resolution * Vref;

            DL_GPIO_togglePins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED_1_PIN);

            break;
        default:
            break;
    }
}

