
#include "ti_msp_dl_config.h"

//  Measurement Calibration Calculate

#define Vref   3.3
#define Max_V 66.49204
#define ADC_Max_Value   4095

//IF 30v
uint16_t u16ADCvalue;
//----------------------------------
float  sMinV = 5;   //10%
float  sMaxV = 25;       //90%
uint16_t sMinD = 300 ;
uint16_t sMaxD = 1528;
//---------------------------------
float sgain;
float soffset;
float Voltage;

float fDivider_Resistor;
float fScale;

uint16_t ema_value;
float actual_V;
uint32_t u32HeartBeat;

void Calculate (void){
    fDivider_Resistor = 4.7/94.7;
    fScale = Vref / fDivider_Resistor;
}

void s_Offset_Gain(void) {

    u16ADCvalue = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);

    ema_value = (u16ADCvalue * 0.1) + (ema_value * 0.9); // ���ƥ����o�i

    actual_V = ((float)u16ADCvalue / 2046) * 3.3;

    // �p�� GAIN
    sgain = (sMaxV - sMinV) / (sMaxD - sMinD);

    // �p�� OFFSET
    soffset = (float)sMinD - (sMinV / sgain);
    Voltage = sgain * ((float)ema_value - soffset);
}



int main(void){
    SYSCFG_DL_init();

    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);

    Calculate();
    while (1) {
    }
}



void ADC12_0_INST_IRQHandler (void){
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)){
    case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
        s_Offset_Gain();
        u32HeartBeat++;

        DL_ADC12_clearInterruptStatus(ADC12_0_INST,DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);  /*Clear interrupt*/
        DL_ADC12_clearEventsStatus(ADC12_0_INST,DL_ADC12_EVENT_MEM0_RESULT_LOADED);         /*Clear event interrupt*/
        DL_ADC12_enableConversions(ADC12_0_INST);

    default:
        break;
    }
}
