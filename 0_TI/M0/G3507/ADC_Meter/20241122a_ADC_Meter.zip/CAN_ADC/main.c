
#include "ti_msp_dl_config.h"


#define Resolution  4095
#define Vref   3.3


float Corrected_voltage;
uint16_t Aver_AdcResult;
uint16_t Real_AdcResult;
uint16_t AdcResult;
uint16_t Cali_AdcResult;

uint16_t offset;
//  4.7/94.7 = 0.04963
//  3.3/0.04963 = 66.49204
uint16_t gain = 66.49204/3.3;

void Calcu_filter(void){
    uint32_t sum_AdcResult = 0;

    for(int i = 0; i < 100; i++) {
         sum_AdcResult += DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
     }
     Aver_AdcResult = (uint16_t)(sum_AdcResult / 100);
}

void Get_Calibration_adc_value() {
    Real_AdcResult = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
    Cali_AdcResult  = Aver_AdcResult/Real_AdcResult;
    AdcResult  = Cali_AdcResult *gain;
}

int main(void){
    SYSCFG_DL_init();
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
    DL_ADC12_startConversion(ADC12_0_INST);
    while (1) {

    }
}



uint16_t u16ADC = 0;
int32_t s32Sum = 0;

int32_t s32K = 100;
int32_t s32Err = 0;

//30V = 1.4889123548
//Measurement
//Calibration
//Calculate
void TIMER_0_INST_IRQHandler(void)
{




    switch (DL_TimerG_getPendingInterrupt(TIMER_0_INST)) {
        case DL_TIMER_IIDX_ZERO:

            u16ADC = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
            s32Err = u16ADC - s32Sum;
            s32Sum += ((s32Err * s32K) >> 16);

//         Calcu_filter();
//
//          Get_Calibration_adc_value();
//
////        Corrected_voltage = (AdcResult * Vref) / Resolution;
//        Corrected_voltage = (Aver_AdcResult * Vref) / Resolution;


//          DL_GPIO_togglePins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED_1_PIN);
//          DL_GPIO_togglePins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED_2_PIN);
            break;
        default:
            break;
    }
}



