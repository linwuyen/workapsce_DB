/*
 * cdebug.h
 *
 *  Created on: 2022�~9��5��
 *      Author: cody_chen
 */

#ifndef CDEBUG_H_
#define CDEBUG_H_

#if ENABLE_DEBUG_DAC
// Debug unsigned int
#define DAC_U16(u16value, base)          DAC_setShadowValue(base, u16value);
// Debug unsigned pu
#define DAC_UPU(f32value, base)          DAC_setShadowValue(base, (uint16_t)(4095.0f * f32value));
// Debug signed pu
#define DAC_SPU(f32value, base)          DAC_setShadowValue(base, (uint16_t)(4095.0f * ((f32value*0.5f)+0.5f)));
// Debug absolute pu
#define DAC_ABS(f32value, base)          DAC_setShadowValue(base, (uint16_t)(4095.0f * f32value *(0.0 <= f32value? 1.0f: -1.0f)));

#else
// Debug unsigned int
#define DAC_U16(u16value, base)
// Debug unsigned pu
#define DAC_UPU(f32value, base)
// Debug signed pu
#define DAC_SPU(f32value, base)
// Debug absolute pu
#define DAC_ABS(f32value, base)

#endif //ENABLE_DEBUG_DAC


#define CPU1_LED852_GPIO84         84
#define CPU2_LED851_GPIO85         85

#define GPIO_PIN_SCIRXDA           85
#define DEBUG_SCI_SCIRX_GPIO       85
#define DEBUG_SCI_SCIRX_PIN_CONFIG GPIO_85_SCIRXDA
#define GPIO_PIN_SCITXDA           84
#define DEBUG_SCI_SCITX_GPIO       84
#define DEBUG_SCI_SCITX_PIN_CONFIG GPIO_84_SCITXDA

#define DEBUG_SCI_BASE             SCIA_BASE
#define DEBUG_SCI_BAUDRATE         115200
#define DEBUG_SCI_CONFIG_WLEN      SCI_CONFIG_WLEN_8
#define DEBUG_SCI_CONFIG_STOP      SCI_CONFIG_STOP_ONE
#define DEBUG_SCI_CONFIG_PAR       SCI_CONFIG_PAR_EVEN

#define TEST_DUAL_CORE_COMM     0
#define TEST_TIMETASK_STABLE    (0x00000001 << 0)
#define TEST_ISR_TIME_MARGIN    (0x00000001 << 1)
#define TEST_MODBUS_ONLY        (0x00000001 << 2)
#define TEST_MODE               (TEST_DUAL_CORE_COMM)

extern void runDebug(void);


#endif /* CDEBUG_H_ */
