/*
 * cali_remote.h
 *
 *  Created on: Aug 2, 2024
 *      Author: User
 */

#ifndef CALI_REMOTE_H_
#define CALI_REMOTE_H_

typedef enum {
    _NO_CMD_FOR_CALI = 0,

    _VIN_CALI_MODE = 0x0100,
    _RUN_VIN_CALI,
    _ADJUST_VIN_BY_10_PERCENT,
    _ENTER_VIN_FIRST_POINT,
    _ADJUST_VIN_BY_90_PERCENT,
    _ENTER_VIN_SECOND_POINT,
    _WAIT_FOR_NO_VIN,

    _VO_CALI_MODE = 0x0200,
    _RUN_VO_CALI,
    _ADJUST_VO_BY_10_PERCENT,
    _ENTER_VO_FIRST_POINT,
    _ADJUST_VO_BY_90_PERCENT,
    _ENTER_VO_SECOND_POINT,
    _WAIT_FOR_NO_VO,

    _IO_CALI_MODE = 0x0400,
    _RUN_IO_CALI,
    _GET_THE_OFFSET_OF_ZERO_IO,
    _RECORD_THE_ZERO_OF_OFFSET_IO,
    _ADJUST_IO_BY_90_PERCENT,
    _ENTER_IO_GAIN_POINT,
    _WAIT_FOR_NO_IO,

    _IL_CALI_MODE = 0x0800,
    _RUN_IL_CALI,
    _GET_THE_OFFSET_OF_ZERO_IL,
    _RECORD_THE_ZERO_OF_OFFSET_IL,
    _ADJUST_IL_BY_90_PERCENT,
    _ENTER_IL_GAIN_POINT,
    _WAIT_FOR_NO_IL,

    _SAVE_CALI_TO_BBOX = 0x4000,


    _MARK_ERROR_CALI = 0x8000


} CALI_CMD;

typedef enum {
    _RECEIVE_CALI_CMD = 0x0001<<0,
    _PROCESS_CALI_CMD = 0x0001<<1,
    _MARK_ERROR_CALI_CMD = 0x8000
} FSM_RMTCALI;

typedef struct {
    uint16_t u16Fsm;
    uint16_t u16Status;
    uint16_t u16Command;
    uint16_t u16CmdAck;
    float32_t f32Data;
    float32_t f32Return;
}ST_RMTCALI;

extern ST_RMTCALI sRmtCal;

extern void runRemoteCali(void);


#endif /* CALI_REMOTE_H_ */
