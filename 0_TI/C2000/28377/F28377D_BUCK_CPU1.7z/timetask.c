/*
 * timetask.c
 *
 *  Created on: May 17, 2024
 *      Author: User
 */

#include "common.h"
#include "shareram.h"

void recalParameters(void)
{
    sDrv.f32TargetHwOvp = OVP_PU;
    VO_OVP_CMPDAC(sDrv.f32HwOvp, sDrv.f32TargetHwOvp);
    sDrv.f32RemoteHwOvp = sDrv.f32TargetHwOvp;

    sDrv.f32RemoteHwOcpIO = sDrv.f32TargetHwOcpIO = OCP_PU;
    IO_OCP_CMPDAC(sDrv.f32HwSourceOcpIO, sDrv.f32HwSinkOcpIO, sDrv.f32TargetHwOcpIO);


    sDrv.f32TargetHwVinOvp = VIN_OVP_PU;
    VIN_OVP_CMPDAC(sDrv.f32HwVinOvp, sDrv.f32TargetHwVinOvp);
    sDrv.f32RemoteHwVinOvp = sDrv.f32TargetHwVinOvp;

    sDrv.f32TargetHwOcpIL = OCP_PU;
    IL_OCP_CMPDAC(sDrv.f32HwSourceOcpIL, sDrv.f32HwSinkOcpIL, sDrv.f32TargetHwOcpIL);
    sDrv.f32RemoteHwOcpIL = sDrv.f32TargetHwOcpIL;

}


void pollOcpParam(void);
void pollOvpParam(void);
void pollILOcpParam(void);
void pollVinOvpParam(void);
void (*pollParams)(void) = pollOvpParam;

void pollOcpParam(void)
{
    if(sDrv.f32TargetHwOcpIO != sDrv.f32RemoteHwOcpIO) {
        sDrv.f32TargetHwOcpIO = sDrv.f32RemoteHwOcpIO;
        IO_OCP_CMPDAC(sDrv.f32HwSourceOcpIO, sDrv.f32HwSinkOcpIO, sDrv.f32TargetHwOcpIO);
    }
    pollParams = pollOvpParam;
}

void pollOvpParam(void)
{
    if(sDrv.f32TargetHwOvp != sDrv.f32RemoteHwOvp) {
        sDrv.f32TargetHwOvp = sDrv.f32RemoteHwOvp;
        VO_OVP_CMPDAC(sDrv.f32HwOvp, sDrv.f32TargetHwOvp);
    }

    pollParams = pollILOcpParam;
}

void pollILOcpParam(void)
{
    if(sDrv.f32TargetHwOcpIL != sDrv.f32RemoteHwOcpIL) {
        sDrv.f32TargetHwOcpIL = sDrv.f32RemoteHwOcpIL;
        IL_OCP_CMPDAC(sDrv.f32HwSourceOcpIL, sDrv.f32HwSinkOcpIL, sDrv.f32TargetHwOcpIL);
    }
    pollParams = pollVinOvpParam;
}

void pollVinOvpParam(void)
{
    if(sDrv.f32TargetHwVinOvp != sDrv.f32RemoteHwVinOvp) {
        sDrv.f32TargetHwVinOvp = sDrv.f32RemoteHwVinOvp;
        VIN_OVP_CMPDAC(sDrv.f32HwVinOvp, sDrv.f32TargetHwVinOvp);
    }

    pollParams = pollOcpParam;
}



void task25msec(void * s)
{
    pollParams();

    if(GETn_STAT(_CSTAT_INIT_SUCCESS, sDrv)) {
        if(isCallbackReady()) {
            recalParameters();

            sAccessCPU1.f32Cpu1VinScale = VIN_SCALE;
            sAccessCPU1.f32Cpu1IoutScale = IO_SCALE;

            SET_STAT(_CSTAT_INIT_PARAMS, sDrv);
        }

        if((0 != sDrv.u32HeartBeat)&&(0 != sCLA.u32HeartBeat)) {
            SET_STAT(_CSTAT_THREAD_READY, sDrv);
        }
    }



    runRemoteCali();
}

void task2D5msec(void * s)
{
#if (TEST_TIMETASK_STABLE == TEST_MODE)
        GPIO_togglePin(CPU1_LED852_GPIO84);
#endif //TEST_TIMETASK_STABLE

    if(GET_STAT(_CSTAT_INIT_SUCCESS, sDrv)) {
        scanWarning();
    }
}

void asapTask(void *s)
{
    runDebug();
    runManualFlashApi();
    runFlashStorage();
}

ST_TIMETASK time_task[] = {
        {task2D5msec,         0,   T_2D5MS},
        {task25msec,          0,   T_25MS},
        {asapTask,            0,        0},
        {0, 0, 0}
};


void pollTimeTask(void)
{
    scanTimeTask(time_task, (void *)0);
}
