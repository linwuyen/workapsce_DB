/*
 * HwConfig.h
 *
 *  Created on: Mar 18, 2024
 *      Author: cody_chen
 *      BuildDate_Version: Comment
 *
 *      310_10116: Modify shareram.h vin & iout
 *      308_10115: Modify HwConfig, Vout Lp from 3.5k to 1k, because I would get 10V when DAB start to switch.
 *      294_10114: Remove to the initial Vref via Modbus
 *                 Modify Modbus, If receive other ID, then wait for crc equal to zero, then reset Modbus Registers
 *      291_10113: Modify C#.net Simple Modbus Poll
 *      291_10112: Modify Modbus, save memory, increase the processing speed of Modbus.
 *      290_10111: Merge DAB, and modify Modbus Table to be clean and simple
 *      269_10110: Modify Open Loop Gain Control
 *      268_10109: Modify VIN_SCALE from 110.44f to 120.458f
 *      267_10108: Restore the sigmoid control.
 *      267_10107: Remove the sigmoid control and replace it with a ramp control.
 *                 Added f32GainEnable to control feedforward ratio.
 */

#ifndef HWCONFIG_H_
#define HWCONFIG_H_

#define FW_BUILDDATE                     310               // Start from 2024/1/1, refer to https://onlinealarmkur.com/date/zh-tw/
#define FW_VERSION                       10116             // CPU1 Version Start from 10000

#define CPUCLK_FREQUENCY                 (DEVICE_SYSCLK_FREQ/1000000UL)       /* 200 MHz System frequency */

#define EPWMCLK_FREQ                     (DEVICE_SYSCLK_FREQ / 2)

#define PWM_FREQ_HZ                      100000.0f

#define T_BUCK_PWM_DEADBAND_NSEC         500UL   // (nsec)

#define VIN_SCALE                        120.458f  // [Vpeak]
#define IO_SCALE                         42.874f   // [Apeak]
#define IL_SCALE                         42.874f   // [Apeak]
#define VOUT_SCALE                       84.053f   // [Vpeak]

#define V2I_SCALE                        (VOUT_SCALE/IL_SCALE)
#define VIN2VOUT_SCALE                   (VIN_SCALE/VOUT_SCALE)

#define VREF_TARGET_AT_IMAX              50.0f      // [V]
#define VREF_TARGET_AT_IMAX_PU           (VREF_TARGET_AT_IMAX/VOUT_SCALE)

#define VREF_LPF_K1                      CAL_LPF_K1(1000, ((float)PWM_FREQ_HZ))
#define DEFAULT_VREF_LPF                 (ST_LPF){.f32K1 = VREF_LPF_K1, .f32Out = 0.0f}

#define RATED_POWER                      2000.0f   // [W]
#define MAX_POWER_TIMES                  1.6       // [Ratio]
#define RATED_IOUT_PU                    (RATED_POWER*MAX_POWER_TIMES/VREF_TARGET_AT_IMAX/IO_SCALE)
#define RATED_IOUT_P_PU                  RATED_IOUT_PU
#define RATED_IOUT_N_PU                  -RATED_IOUT_PU

#define VIN_BROWN_IN                     40.0f //90.0f     // [Vrms]
#define VIN_BROWN_OUT                    30.0f //80.0f     // [Vrms]
#define VIN_BROWN_IN_PU                 (VIN_BROWN_IN/VIN_SCALE)
#define VIN_BROWN_OUT_PU                (VIN_BROWN_OUT/VIN_SCALE)

#define VIN_OVP                          105.00f    // [V]
#define VIN_OVP_PU                      (VIN_OVP/VIN_SCALE)

#define OVP_TARGET                       82.40f    // [V]
#define OVP_PU                          (OVP_TARGET/VOUT_SCALE)

#define OCP_TARGET                       41.20f    // [A]
#define OCP_PU                          (OCP_TARGET/IO_SCALE)

#define VIN_LPF_K1                       DEFAULT_VREF_LPF
#define VO_LPF_K1                        DEFAULT_VREF_LPF
#define IO_LPF_K1                        CAL_LPF_K1(10000.0f, PWM_FREQ_HZ)
#define DEFAULT_IO_LPF                   (ST_LPF){.f32K1 = IO_LPF_K1, .f32Out = 0.0f}
#define IL_LPF_K1                        CAL_LPF_K1(10000.0f, PWM_FREQ_HZ)
#define DEFAULT_IL_LPF                   (ST_LPF){.f32K1 = IL_LPF_K1, .f32Out = 0.0f}


// @ ADC_RESULT_Xy(X, y)
// X:= ADCA/B/C, y:= SOC0-15
#define ADC_12BITS_RESULT_Xy(X, y)       (((float)HWREGH(ADC ## X ##RESULT_BASE + y))*0.0002442f)
#define ADC_16BITS_SPU_Xy(X, y)          (((float)HWREGH(ADC ## X ##RESULT_BASE + y))*0.0000305f-1.0f)
#define ADC_16BITS_UPU_Xy(X, y)          (((float)HWREGH(ADC ## X ##RESULT_BASE + y))*0.0000152f)
#define ADC_RESULT_Xy(X,y)               ADC_12BITS_RESULT_Xy(X, y)

#define A14P_A15N_SOC0_IL_SENSE          ADC_16BITS_SPU_Xy(A, 0)
#define A2P_A2N_SOC1_VIN_SENSE           ADC_16BITS_UPU_Xy(A, 1)
#define A4P_A4N_SOC2_VO_SENSE            ADC_16BITS_UPU_Xy(A, 2)

#define B2P_B2N_SOC0_IO_SENSE            ADC_16BITS_SPU_Xy(B, 0)
#define B2P_B2N_SOC1_IO_SENSE            ADC_16BITS_SPU_Xy(B, 1)
#define B2P_B2N_SOC2_IO_SENSE            ADC_16BITS_SPU_Xy(B, 2)

#define IL_SENSE                         ((A14P_A15N_SOC0_IL_SENSE)*1.00000f)
#define IO_SENSE                         ((B2P_B2N_SOC0_IO_SENSE+B2P_B2N_SOC1_IO_SENSE+B2P_B2N_SOC2_IO_SENSE)*0.333333f)
#define VO_SENSE                         ((A4P_A4N_SOC2_VO_SENSE)*1.00000f)
#define VIN_SENSE                        ((A2P_A2N_SOC1_VIN_SENSE)*1.00000f)

#define _V_LOOP_KP                       (1.0f)
#define _V_LOOP_KI                       (0.0001f)

#define _I_LOOP_KP                       (1.0f)
#define _I_LOOP_KI                       (0.001f)

#define ENABLE_DEBUG_DAC                 1
#define ENABLE_CYCLE_PROTECTION          1
#define ENABLE_ELOAD                     0

#define CMP_DACMAX                       4095.0f
#define CMP_STATUS(cmp, base)            (CMPSS_STS_## cmp ##_FILTOUT & CMPSS_getStatus(base))
#define VIN_OVP_STATUS()                 CMP_STATUS(HI, CMP1_VIN_OVP_BASE)
#define VO_OVP_STATUS()                  CMP_STATUS(HI, CMP2_VO_OVP_BASE)
#define IO_OCP_STATUS()                  (CMP_STATUS(HI, CMP3_IO_OCP_BASE) || CMP_STATUS(LO, CMP3_IO_OCP_BASE))
#define IL_OCP_STATUS()                  (CMP_STATUS(HI, CMP4_IL_OCP_BASE) || CMP_STATUS(LO, CMP4_IL_OCP_BASE))

#define CMPSS_HI_DAC(data, base)         CMPSS_setDACValueHigh(base, (uint16_t)data)
#define CMPSS_LO_DAC(data, base)         CMPSS_setDACValueLow(base, (uint16_t)data)

#define SET_CMP_BDAC(hout, lout, in, cal, cmp) \
                                         hout = ((+in * 0.5f + 0.5f)*cal.f32Gain + cal.f32Offset) * CMP_DACMAX; \
                                         CMPSS_HI_DAC(hout, cmp); \
                                         lout = ((-in * 0.5f + 0.5f)*cal.f32Gain + cal.f32Offset) * CMP_DACMAX; \
                                         CMPSS_LO_DAC(lout, cmp);

#define SET_CMPH_DAC(out, in, cal, cmp)  out = (in * cal.f32Gain + cal.f32Offset) * CMP_DACMAX; \
                                         CMPSS_HI_DAC(out, cmp);
#define SET_CMPL_DAC(out, in, cal, cmp)  out = (in * cal.f32Gain + cal.f32Offset) * CMP_DACMAX; \
                                         CMPSS_LO_DAC(out, cmp);

#define VIN_OVP_CMPDAC(out, in)          SET_CMPH_DAC(out, in, sDrv.sVIN.sCali, CMP1_VIN_OVP_BASE)
#define IO_OCP_CMPDAC(hout, lout, in)    SET_CMP_BDAC(hout, lout, in, sDrv.sIO.sCali, CMP3_IO_OCP_BASE)
#define VO_OVP_CMPDAC(out, in)           SET_CMPH_DAC(out, in, sDrv.sVO.sCali, CMP2_VO_OVP_BASE)
#define IL_OCP_CMPDAC(hout, lout, in)    SET_CMP_BDAC(hout, lout, in, sDrv.sIL.sCali, CMP4_IL_OCP_BASE)



#endif /* HWCONFIG_H_ */
