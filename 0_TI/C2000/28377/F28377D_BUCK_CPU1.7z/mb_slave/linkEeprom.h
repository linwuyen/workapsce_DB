/*
 *  File Name: linkEeprom.h
 *
 *  Created on: 2024/10/28
 *  Author: CODY
 */

typedef struct {
    uint16_t size;
    void *ptr;
} EE_REG;
typedef EE_REG * HAL_EEREG;

#define _BLK16_USERPARAMS	9
uint16_t blkUserParams[_BLK16_USERPARAMS];
const EE_REG regUserParams[5] = {
              {2, (void*)&sDrv.f32IrefLimitP},
              {2, (void*)&sDrv.f32IrefLimitN},
              {2, (void*)&sDrv.f32RemoteHwOcpIO},
              {2, (void*)&sDrv.f32RemoteHwOvp},
              {1, (void*)&blkUserParams[8]}};
#define _TABLE_USERPARAMS	5

#define _BLK16_ADVPARAMS	21
uint16_t blkAdvParams[_BLK16_ADVPARAMS];
const EE_REG regAdvParams[6] = {
              {4, (void*)&sDrv.sLoopV.f32Kp},
              {4, (void*)&sDrv.sLoopV.f32Ki},
              {4, (void*)&sDrv.sLoopI.f32Kp},
              {4, (void*)&sDrv.sLoopI.f32Ki},
              {4, (void*)&sDrv.f32OpenGain},
              {1, (void*)&blkAdvParams[20]}};
#define _TABLE_ADVPARAMS	6

