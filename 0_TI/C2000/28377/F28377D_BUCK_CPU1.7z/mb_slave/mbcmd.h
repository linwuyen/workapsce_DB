/*
 *  File Name: mbcmd.h
 *
 *  Created on: 2024/10/28
 *  Author: CODY
 */

#ifndef MBCMD_H_
#define MBCMD_H_



typedef enum {
	_g0_MODE = 0,
    _END_OF_MODE
} ID_MODE;


enum {
	_muCOMmonHEAder = 0,                    // #0  T_U16                
	_muCOMmonLENgth = 1,                    // #1  T_U16                
	_muMAChineINFOrmationOFFSet = 2,        // #2  T_U16                
	_muUSERPARameterOFFSet = 3,             // #3  T_U16                
	_muADVAncePARameterOFFSet = 4,          // #4  T_U16                
	_muCOMmonCHEcksum = 5,                  // #5  T_U16                
	_muMAChineLENgth = 6,                   // #6  T_U16                
	_muCOUntryCODe = 7,                     // #7  T_U16                
	_muVENderid = 8,                        // #8  T_U16                
	_muPROductid = 9,                       // #9  T_U16                // 1: PBL
	_muPARtid = 10,                         // #10  T_U16               // 1: PFC, 2: DAB, 3:BUCK
	_muMODuleid = 11,                       // #11  T_U16               
	_muVERsion = 12,                        // #12  T_U16               
	_muBUIldDATe = 13,                      // #13  T_U16               
	_muUSERPARameterLENgth = 14,            // #14  T_U16               
	_muMAInCONtrolSTAtus = 15,              // #15  T_U16               
	_muMAInERROrSTAtus = 16,                // #16  T_U16               
	_muENABlePWM = 17,                      // #17  T_U16               
	_muVOLtageREFerence = 18,               // #18  T_Q15               
	_muPOSitiveCURrentLIMit = 19,           // #19  T_Q15               
	_muNEGativeCURrentLIMit = 20,           // #20  T_Q15               
	_muOVERCURrentPROtection = 21,          // #21  T_Q15               
	_muOVERVOLtagePROtection = 22,          // #22  T_Q15               
	_muMEAsureTEMperature = 23,             // #23  T_Q15               
	_muMEAsureVOLtageOUTPut = 24,           // #24  T_Q15               
	_muMEAsureVOLtageINPUt = 25,            // #25  T_Q15               
	_muMEAsureCURrentOUTPut = 26,           // #26  T_Q15               
	_muMEAsureINDUctorCURrent = 27,         // #27  T_Q15               
	_muADVAncePARameterLENgth = 28,         // #28  T_U16               
	_muADVAncePASsword = 29,                // #29  T_U16               
	_muVOLtageLOOpkp0 = 30,                 // #30  T_F32               
	_muVOLtageLOOpkp1 = 31,                 // #31  T_F32               
	_muVOLtageLOOpki0 = 32,                 // #32  T_F32               
	_muVOLtageLOOpki1 = 33,                 // #33  T_F32               
	_muCURrentLOOpkp0 = 34,                 // #34  T_F32               
	_muCURrentLOOpkp1 = 35,                 // #35  T_F32               
	_muCURrentLOOpki0 = 36,                 // #36  T_F32               
	_muCURrentLOOpki1 = 37,                 // #37  T_F32               
	_muOPENLOOpGAIn0 = 38,                  // #38  T_F32               
	_muOPENLOOpGAIn1 = 39,                  // #39  T_F32               
	_muHEArtbeatC280 = 40,                  // #40  T_U32               
	_muHEArtbeatC281 = 41,                  // #41  T_U32               
	_muHEArtbeatCLA0 = 42,                  // #42  T_U32               
	_muHEArtbeatCLA1 = 43,                  // #43  T_U32               
	_murdMODe0 = 44,                        // #44  T_U32               // _FORCE_OUTPUT=1,   _OPEN_LOOP=2,  _CLOSE_LOOP=4
	_murdMODe1 = 45,                        // #45  T_U32               // _FORCE_OUTPUT=1,   _OPEN_LOOP=2,  _CLOSE_LOOP=4
	_muHARdwareSLEwrate0 = 46,              // #46  T_F32               // usec
	_muHARdwareSLEwrate1 = 47,              // #47  T_F32               // usec
	_muCALibrationCOMmand = 48,             // #48  T_U16               // SaveFlash=0x4000, Vin=0x100, Vo=0x200, Io=0x400, IL=0x800
	_muCALibrationACK = 49,                 // #49  T_U16               
	_muCALibrationDATa0 = 50,               // #50  T_F32               
	_muCALibrationDATa1 = 51,               // #51  T_F32               
	_muCALibrationRETurn0 = 52,             // #52  T_F32               
	_muCALibrationRETurn1 = 53,             // #53  T_F32               
	_muRECordWORkingSTAtus = 54,            // #54  T_U16               
	_muRECordERROrSTAtus = 55,              // #55  T_U16               
	_muBROwninVOLtage = 56,                 // #56  T_Q15               
	_muBROwnOUTVOLtage = 57,                // #57  T_Q15               
	_muGAInENABle0 = 58,                    // #58  T_F32               
	_muGAInENABle1 = 59,                    // #59  T_F32               
	_muviGAIn0 = 60,                        // #60  T_F32               
	_muviGAIn1 = 61,                        // #61  T_F32               
    _end_of_0_id = 49
};

typedef union { 
    uint16_t u16MbusData[62];
    struct { 
		uint16_t u16COMmonHEAder;
		uint16_t u16COMmonLENgth;
		uint16_t u16MAChineINFOrmationOFFSet;
		uint16_t u16USERPARameterOFFSet;
		uint16_t u16ADVAncePARameterOFFSet;
		uint16_t u16COMmonCHEcksum;
		uint16_t u16MAChineLENgth;
		uint16_t u16COUntryCODe;
		uint16_t u16VENderid;
		uint16_t u16PROductid;
		uint16_t u16PARtid;
		uint16_t u16MODuleid;
		uint16_t u16VERsion;
		uint16_t u16BUIldDATe;
		uint16_t u16USERPARameterLENgth;
		uint16_t u16MAInCONtrolSTAtus;
		uint16_t u16MAInERROrSTAtus;
		uint16_t u16ENABlePWM;
		int16_t s16VOLtageREFerence;
		int16_t s16POSitiveCURrentLIMit;
		int16_t s16NEGativeCURrentLIMit;
		int16_t s16OVERCURrentPROtection;
		int16_t s16OVERVOLtagePROtection;
		int16_t s16MEAsureTEMperature;
		int16_t s16MEAsureVOLtageOUTPut;
		int16_t s16MEAsureVOLtageINPUt;
		int16_t s16MEAsureCURrentOUTPut;
		int16_t s16MEAsureINDUctorCURrent;
		uint16_t u16ADVAncePARameterLENgth;
		uint16_t u16ADVAncePASsword;
		float32_t f32VOLtageLOOpkp;
		float32_t f32VOLtageLOOpki;
		float32_t f32CURrentLOOpkp;
		float32_t f32CURrentLOOpki;
		float32_t f32OPENLOOpGAIn;
		uint32_t u32HEArtbeatC28;
		uint32_t u32HEArtbeatCLA;
		uint32_t u32rdMODe;
		float32_t f32HARdwareSLEwrate;
		uint16_t u16CALibrationCOMmand;
		uint16_t u16CALibrationACK;
		float32_t f32CALibrationDATa;
		float32_t f32CALibrationRETurn;
		uint16_t u16RECordWORkingSTAtus;
		uint16_t u16RECordERROrSTAtus;
		int16_t s16BROwninVOLtage;
		int16_t s16BROwnOUTVOLtage;
		float32_t f32GAInENABle;
		float32_t f32viGAIn;
    }; 
} REG_MBUSDATA;
extern REG_MBUSDATA regMbusData;
extern int chkValidAddress(uint16_t addr);
extern uint16_t getModbusData(uint16_t addr);
extern uint16_t setModbusData(uint16_t addr, uint16_t data);




#endif /* MBCMD_H_ */

