/*
 * isr.c
 *
 *  Created on: Mar 18, 2024
 *      Author: cody_chen
 */

#include <math.h>
#include "common.h"
#include "shareram.h"
#include "cali_param.h"
#include "cali_system.h"
#include "c28protection.h"


ST_DRV sDrv = {
        .fgStatus = _CSTAT_INIT_DRV_PARAM,
        .sVO =  { .sLPF = DEFAULT_VREF_LPF, .sCali = {.f32Gain = 1.0f, .f32Offset = 0.0f, .f32Base = VOUT_SCALE }},
        .sVIN = { .sLPF = DEFAULT_VREF_LPF, .sCali = {.f32Gain = 1.0f, .f32Offset = 0.0f, .f32Base = VIN_SCALE}},
        .sIO =  { .sLPF = DEFAULT_IO_LPF, .sCali = {.f32Gain = 1.0f, .f32Offset = 0.0f, .f32Base = IO_SCALE }},
        .sIL =  { .sLPF = DEFAULT_IL_LPF, .sCali = {.f32Gain = 1.0f, .f32Offset = 0.0f, .f32Base = IL_SCALE }},
        .f32BrownInPU = VIN_BROWN_IN_PU,
        .f32BrownOutPU = VIN_BROWN_OUT_PU,
        .regPwm = { .u16Enable = false },

        .sLoopV = { .f32Ki = _V_LOOP_KI, .f32Kp = _V_LOOP_KP,
                    .f32Min = -1.0f, .f32Max = 1.0f, .f32Itemp = 0.0f, .f32Out = 0.0f, .u16StopUi = false},

        .sLoopI = { .f32Ki = _I_LOOP_KI, .f32Kp = _I_LOOP_KP,
                    .f32Min = -1.0f, .f32Max = 1.0f, .f32Itemp = 0.0f, .f32Out = 0.0f, .u16StopUi = false},

        .f32VIgain = 1.0f,

        .f32IrefLimitP = RATED_IOUT_P_PU,
        .f32IrefLimitN = RATED_IOUT_N_PU,
        .f32Ovp = OVP_PU,
        .f32HwOvp = (CMP_DACMAX*OVP_PU),

        .f32Ocp = OCP_PU,
        .f32HwOcpIO = (CMP_DACMAX*OCP_PU),

        .f32ILOcp = OCP_PU,
        .f32HwOcpIL = (CMP_DACMAX*OCP_PU),

        .f32VinOvp = VIN_OVP_PU,
        .f32HwOvp = (CMP_DACMAX*VIN_OVP_PU),
        .u32HeartBeat = 0,
        .sSigmoid = DEFAULT_SIGMOID,
        .sCaliSys = DEFAULT_ST_CALI_SYSTEM,
        .regPwm = { .all = 0 },

        .u32RdMode = _OPEN_LOOP_CONTROL,
        .f32OpenGain = 0.0f,
        .f32GainEnable = 0.0f
};


#ifdef _FLASH
#pragma SET_CODE_SECTION(".TI.ramfunc")
#endif //_FLASH


static inline void scanMeasurement(void)
{
    sDrv.sVO.f32Adc = VO_SENSE;
    getCaliData(sDrv.sVO.f32Adc, &sDrv.sVO.sCali);
    mLPF(sDrv.sVO.sCali.f32Out, &sDrv.sVO.sLPF);

    sDrv.sVIN.f32Adc = VIN_SENSE;
    getCaliData(sDrv.sVIN.f32Adc, &sDrv.sVIN.sCali);
    mLPF(sDrv.sVIN.sCali.f32Out, &sDrv.sVIN.sLPF);

    sDrv.sIO.f32Adc = IO_SENSE;
    getAcCaliData(sDrv.sIO.f32Adc, &sDrv.sIO.sCali);
    mLPF(sDrv.sIO.sCali.f32Out, &sDrv.sIO.sLPF);

    sDrv.sIL.f32Adc = IL_SENSE;
    getAcCaliData(sDrv.sIL.f32Adc, &sDrv.sIL.sCali);
    mLPF(sDrv.sIL.sCali.f32Out, &sDrv.sIL.sLPF);


    sAccessCPU1.f32Cpu1Vin= sDrv.sVIN.sCali.f32Out;
    sAccessCPU1.f32Cpu1Iout = sDrv.sIO.sCali.f32Out;

}



static inline void scanBrownInOut(void)
{
    if(false == GET_STAT(_CSTAT_BROWN_IN, sDrv)) {
        if((sDrv.f32BrownInPU < sDrv.sVIN.sLPF.f32Out)||(0.0f == sDrv.f32BrownInPU)) {
            sDrv.f32OpenGain = 0.0f;
            rstError();
            SET_STAT(_CSTAT_BROWN_IN, sDrv);
        }
    }
    else {

        if((sDrv.f32BrownOutPU > sDrv.sVIN.sLPF.f32Out)&&(0.0f < sDrv.f32BrownOutPU)) {
            SET_ERR(_ERR_VIN_UVP, sDrv);
            RST_STAT(_CSTAT_OUTPUT_READY, sDrv);
        }
    }
}

static inline void ctrlPwmEnable(void)
{
    // Control OpenGain
    if(true == GET_STAT(_CSTAT_BROWN_IN, sDrv)) {
        if (sDrv.sSigmoid.f32Youtput != sDrv.sSigmoid.f32Ytarget) {
            sDrv.f32OpenGain = sDrv.f32GainEnable * sDrv.sSigmoid.f32Youtput  / (sDrv.sVIN.sLPF.f32Out * VIN2VOUT_SCALE);
        }
        else {
            sDrv.f32OpenGain = sDrv.f32GainEnable * sDrv.sVO.sLPF.f32Out / (sDrv.sVIN.sLPF.f32Out * VIN2VOUT_SCALE);
        }
//        sDrv.f32OpenGain = sDrv.f32GainEnable * sDrv.sSigmoid.f32Youtput * sDrv.sVO.sLPF.f32Out / (sDrv.sVIN.sLPF.f32Out * VIN2VOUT_SCALE);
        // sDrv.f32OpenGain = sDrv.f32GainEnable * sDrv.sVO.sLPF.f32Out / (sDrv.sVIN.sLPF.f32Out * VIN2VOUT_SCALE);
    }
    else {
        sDrv.f32OpenGain = 0.0f;
    }

    // Initial the control loop of V/I, and update & detect the status pwm
    if(sDrv.regPwm.u16Enable != sDrv.regPwm.u16Remote) {
        if(0 == sDrv.regPwm.u16Remote) {
            RST_STAT(_CSTAT_ENABLE_PWM, sDrv);
            sDrv.regPwm.u16Enable = 0;
        }
        else {
            if(true == GET_STAT(_CSTAT_BROWN_IN, sDrv)) {
                sDrv.sLoopV.f32Itemp = 0.0f;
                sDrv.sLoopI.f32Itemp = cnvUpu2Spu(sDrv.f32OpenGain);
                SET_STAT(_CSTAT_ENABLE_PWM, sDrv);
                sDrv.regPwm.u16Enable = 1;

            }
            else {
                sDrv.sLoopV.f32Itemp = 0.0f;
                sDrv.sLoopI.f32Itemp = -1.0f;
                RST_STAT(_CSTAT_ENABLE_PWM, sDrv);
                sDrv.regPwm.u16Remote = 0;
            }
        }
    }

    // Control Sigmoid
    if(0 == sDrv.regPwm.u16Enable) {
        sDrv.f32RemoteVref = sDrv.sVO.sLPF.f32Out;
        rstSigmoidRamp(sDrv.sVO.sLPF.f32Out, &sDrv.sSigmoid);
    }
    else {

        if(sDrv.f32RemoteVref != sDrv.sSigmoid.f32Ytarget) {
            sDrv.f32OutputVref = setSigmoidStep(sDrv.f32RemoteVref, &sDrv.sSigmoid);
            sDrv.f32RemoteVref = sDrv.f32OutputVref;
        }
        else {
            sDrv.f32OutputVref = runSigmoidRamp(&sDrv.sSigmoid);
        }

        sDrv.u32DacVref = (uint32_t)(sDrv.f32OutputVref * 4095.0f);
        DAC_setShadowValue(myDAC0_BASE, sDrv.u32DacVref);
    }

    sDrv.f32Vref = sDrv.sSigmoid.f32Youtput;

#if ENABLE_CYCLE_PROTECTION
    if(AND_ERR(_ALL_ERROR, sDrv)) {
        if(true == sDrv.regPwm.u16Enable) {
            sDrv.sRecord.fgStatus = sDrv.fgStatus;
            sDrv.sRecord.fgError = sDrv.fgError;
            sDrv.regPwm.u16Enable = sDrv.regPwm.u16Remote = false;
            saveDataToFlash();
        }

        RST_STAT(_CSTAT_ENABLE_PWM, sDrv);
        DAC_setShadowValue(myDAC0_BASE, 0UL);
    }
#endif //#if ENABLE_CYCLE_PROTECTION
}

__interrupt void INT_CPU1_ADCA_1_ISR (void)
{
#if (TEST_ISR_TIME_MARGIN == TEST_MODE)
    GPIO_writePin(CPU1_LED852_GPIO84, 1);
#endif //TEST_TIMETASK_STABLE

    if(_FORCE_OUTPUT_PWM == sDrv.u32RdMode) {
        uint32_t u32Duty = (uint32_t)(((float32_t) COUNTING_MAX) * sDrv.f32RemoteVref);
        SET_HRPWMAB_DUTY(u32Duty, PWM_BASE);
    }
    else {
        scanMeasurement();

        runCalibration(&sDrv.sCaliSys);
        if(GET_STAT(_CSTAT_INIT_SUCCESS, sDrv)) {
            scanProtection();

            scanBrownInOut();

            ctrlPwmEnable();

			if(GET_STAT(_CSTAT_OUTPUT_READY, sDrv)) {
				sDrv.u32Duty = (uint32_t)(((float32_t) COUNTING_MAX) * sDrv.f32Vref);
				SET_HRPWMAB_DUTY(sDrv.u32Duty, PWM_BASE);
			}
			else {
				RST_HRPWMAB_DUTY(PWM_BASE);
			}

        }
        else {
            RST_HRPWMAB_DUTY(PWM_BASE);
        }
    }

    sDrv.u32HeartBeat++;
    sDrv.u32HeartBeat &= 0x7FFFFFFF;

    // Clear the interrupt flag
    ADC_clearInterruptStatus(CPU1_ADCA_BASE, ADC_INT_NUMBER1);

    // Acknowledge the interrupt
    Interrupt_clearACKGroup(INT_CPU1_ADCA_1_INTERRUPT_ACK_GROUP);

#if (TEST_ISR_TIME_MARGIN == TEST_MODE)
    GPIO_writePin(CPU1_LED852_GPIO84, 0);
#endif //TEST_TIMETASK_STABLE
}



#ifdef _FLASH
#pragma SET_CODE_SECTION()
#endif //_FLASH



