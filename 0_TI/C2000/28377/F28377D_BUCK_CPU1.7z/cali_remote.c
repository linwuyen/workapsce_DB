/*
 * cali_remote.c
 *
 *  Created on: Aug 2, 2024
 *      Author: User
 */

#include "common.h"

ST_RMTCALI sRmtCal = {
                      .u16Fsm = _RECEIVE_CALI_CMD,
                      .u16Command = _NO_CMD_FOR_CALI
};

#define SW_CALSTEP(x)  FG_SWTO(x, sRmtCal.u16Fsm)
#define GET_CALSTEP(x) FG_GET(x, sRmtCal.u16Fsm)
#define SET_CALSTEP(x) FG_SET(x, sRmtCal.u16Fsm)
#define RST_CALSTEP(x) FG_RST(x, sRmtCal.u16Fsm)

//void rmtVINCali(void)
//{
//    switch(sRmtCal.u16CmdAck) {
//    case _VIN_CALI_MODE:
//        sRmtCal.u16CmdAck = _RUN_VIN_CALI;
//
//        break;
//
//    case _RUN_VIN_CALI:
//        sDrv.sCaliSys.fsm = _RUN_VIN_CALIBRATION;
//        sRmtCal.f32Data = sRmtCal.f32Return = 0.0f;
//        sRmtCal.u16CmdAck = _ADJUST_VIN_BY_10_PERCENT;
//        break;
//
//
//    case _ADJUST_VIN_BY_10_PERCENT:
//    case _ENTER_VIN_FIRST_POINT:
//        if(sRmtCal.f32Data != sRmtCal.f32Return) {
//            sDrv.sCaliSys.sLine.p1.y = sRmtCal.f32Return = sRmtCal.f32Data;
//            sDrv.sCaliSys.fsm = _RECORD_VIN_POINT1;
//            sRmtCal.u16CmdAck = _ADJUST_VIN_BY_90_PERCENT;
//        }
//        break;
//
//    case _ADJUST_VIN_BY_90_PERCENT:
//    case _ENTER_VIN_SECOND_POINT:
//        if(sRmtCal.f32Data != sRmtCal.f32Return) {
//            sDrv.sCaliSys.sLine.p2.y = sRmtCal.f32Return = sRmtCal.f32Data;
//            sDrv.sCaliSys.fsm = _RECORD_VIN_POINT2;
//            sRmtCal.u16CmdAck = _WAIT_FOR_NO_VIN;
//        }
//        break;
//
//    case _WAIT_FOR_NO_VIN:
//        if(_WAIT_FOR_VIN_SET_ZERO == sDrv.sCaliSys.fsm) {
//            sDrv.sCaliSys.fsm = _EXIT_CALI;
//            sRmtCal.u16CmdAck = _NO_CMD_FOR_CALI;
//        }
//        break;
//    default:
//        sRmtCal.u16CmdAck |= _MARK_ERROR_CALI;
//        break;
//    }
//}


#define RMT_DC_CALI(name) \
void rmt## name ##Cali(void) \
{ \
    switch(sRmtCal.u16CmdAck) { \
    case _## name ##_CALI_MODE: \
        sRmtCal.u16CmdAck = _RUN_## name ##_CALI; \
        break; \
    case _RUN_## name ##_CALI: \
        sDrv.sCaliSys.fsm = _RUN_## name ##_CALIBRATION; \
        sRmtCal.f32Data = sRmtCal.f32Return = 0.0f; \
        sRmtCal.u16CmdAck = _ADJUST_## name ##_BY_10_PERCENT; \
        break; \
    case _ADJUST_## name ##_BY_10_PERCENT: \
    case _ENTER_## name ##_FIRST_POINT: \
        if(sRmtCal.f32Data != sRmtCal.f32Return) { \
            sDrv.sCaliSys.sLine.p1.y = sRmtCal.f32Return = sRmtCal.f32Data; \
            sDrv.sCaliSys.fsm = _RECORD_## name ##_POINT1; \
            sRmtCal.u16CmdAck = _ADJUST_## name ##_BY_90_PERCENT; \
        } \
        break; \
    case _ADJUST_## name ##_BY_90_PERCENT: \
    case _ENTER_## name ##_SECOND_POINT: \
        if(sRmtCal.f32Data != sRmtCal.f32Return) { \
            sDrv.sCaliSys.sLine.p2.y = sRmtCal.f32Return = sRmtCal.f32Data; \
            sDrv.sCaliSys.fsm = _RECORD_## name ##_POINT2; \
            sRmtCal.u16CmdAck = _WAIT_FOR_NO_## name ; \
        } \
        break; \
    case _WAIT_FOR_NO_## name : \
        if(_WAIT_FOR_## name ##_SET_ZERO == sDrv.sCaliSys.fsm) { \
            sDrv.sCaliSys.fsm = _EXIT_CALI; \
            sRmtCal.u16CmdAck = _NO_CMD_FOR_CALI; \
        } \
        break; \
    default: \
        sRmtCal.u16CmdAck |= _MARK_ERROR_CALI; \
        break; \
    } \
}

#define RMT_AC_CALI(name) \
void rmt## name ##Cali(void) \
{ \
    switch(sRmtCal.u16CmdAck) { \
    case _## name ##_CALI_MODE: \
        sRmtCal.u16CmdAck = _RUN_## name ##_CALI; \
        break; \
    case _RUN_## name ##_CALI: \
        sDrv.sCaliSys.fsm = _RUN_## name ##_CALIBRATION; \
        sRmtCal.f32Data = sRmtCal.f32Return = 0.0f; \
        sRmtCal.u16CmdAck = _GET_THE_OFFSET_OF_ZERO_## name ; \
        break; \
    case _GET_THE_OFFSET_OF_ZERO_## name: \
    case _RECORD_THE_ZERO_OF_OFFSET_## name: \
        if(sRmtCal.f32Data != sRmtCal.f32Return) { \
            sDrv.sCaliSys.sPoint.y = sRmtCal.f32Return = sRmtCal.f32Data; \
            sDrv.sCaliSys.fsm = _RECORD_## name ##_ADC_OFFSET; \
            sRmtCal.u16CmdAck = _ADJUST_## name ##_BY_90_PERCENT; \
        } \
        break; \
    case _ADJUST_## name ##_BY_90_PERCENT: \
    case _ENTER_## name ##_GAIN_POINT: \
        if(sRmtCal.f32Data != sRmtCal.f32Return) { \
            sDrv.sCaliSys.sPoint.y = sRmtCal.f32Return = sRmtCal.f32Data; \
            sDrv.sCaliSys.fsm = _RECORD_## name ##_ADC_GAIN; \
            sRmtCal.u16CmdAck = _WAIT_FOR_NO_## name ; \
        } \
        break; \
    case _WAIT_FOR_NO_## name : \
        if(_WAIT_FOR_## name ##_SET_ZERO == sDrv.sCaliSys.fsm) { \
            sDrv.sCaliSys.fsm = _EXIT_CALI; \
            sRmtCal.u16CmdAck = _NO_CMD_FOR_CALI; \
        } \
        break; \
    default: \
        sRmtCal.u16CmdAck |= _MARK_ERROR_CALI; \
        break; \
    } \
}


RMT_DC_CALI(VIN);
RMT_DC_CALI(VO);
RMT_AC_CALI(IO);
RMT_AC_CALI(IL);

void runRemoteCali(void)
{
    switch(sRmtCal.u16Fsm) {
    case _RECEIVE_CALI_CMD:
        if(_NO_CMD_FOR_CALI != sRmtCal.u16Command) {
            sRmtCal.u16CmdAck = sRmtCal.u16Command;
            sRmtCal.u16Command = _NO_CMD_FOR_CALI;
            SW_CALSTEP(_PROCESS_CALI_CMD);
        }
        break;

    case _PROCESS_CALI_CMD:
        if(sRmtCal.u16CmdAck & _MARK_ERROR_CALI) {
            SW_CALSTEP(_MARK_ERROR_CALI_CMD);
        }
        else if(sRmtCal.u16CmdAck & _VIN_CALI_MODE) {
            rmtVINCali();
        }
        else if(sRmtCal.u16CmdAck & _VO_CALI_MODE) {
            rmtVOCali();
        }
        else if(sRmtCal.u16CmdAck & _IO_CALI_MODE) {
            rmtIOCali();
        }
        else if(sRmtCal.u16CmdAck & _IL_CALI_MODE) {
            rmtILCali();
        }
        else if(sRmtCal.u16CmdAck &_SAVE_CALI_TO_BBOX) {
            saveDataToFlash();
            SW_CALSTEP(_RECEIVE_CALI_CMD);
        }
        else {
            SW_CALSTEP(_RECEIVE_CALI_CMD);
        }
        break;

    case _MARK_ERROR_CALI_CMD:

        break;

    default:
        SW_CALSTEP(_MARK_ERROR_CALI_CMD);
        break;
    }
}
