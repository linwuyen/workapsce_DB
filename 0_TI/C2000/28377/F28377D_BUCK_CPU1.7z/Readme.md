![Test LanuchPad with BoosterPack](https://github.com/yanbai7/F28379D_DualCore_ZWT337_DAB_BUCK/blob/main/screenshot/TestLanuchPadWithBoosterPack.jpg) \
DSO CH1(Yallow): Measure Vout, CH2(Blue): Measure Vref \
DC Input: 9V, Measure Output with GDM-3255A \
Control Vref via Modbus: Switch from 0V to 5V \
![Test Result for Switch PWM from 0 to 90%](https://github.com/yanbai7/F28379D_DualCore_ZWT337_DAB_BUCK/blob/main/screenshot/TestResult1.png) \
DSO CH1(Yallow): Measure Vout, CH2(Blue): Measure Vref \
DC Input: 9V, Measure Output with GDM-3255A \
Control Vref via Modbus: Switch from 1V to 5V \
![Test Result for Sigmoid Image](https://github.com/yanbai7/F28379D_DualCore_ZWT337_DAB_BUCK/blob/main/screenshot/TestResult.png) \
DSO CH1(Yallow): ADC Interrupt, CH2(Blue): PWMH \
![Test Result for showing the pwm trigger position](https://github.com/yanbai7/F28379D_DualCore_ZWT337_DAB_BUCK/blob/main/screenshot/TestResult2.png) \
Remote control by ModbusPoll \
![Test Result for showing Remote control by ModbusPoll](https://github.com/yanbai7/F28379D_DualCore_ZWT337_DAB_BUCK/blob/main/screenshot/RemoteResult.png) \
Test by the external Eload \
![Test Result for testing by the external Eload](https://github.com/yanbai7/F28379D_DualCore_ZWT337_DAB_BUCK/blob/main/screenshot/TestByExternalEload.jpg)