/*
 * f021Bbox.c
 *
 *  Created on: Apr 16, 2024
 *      Author: Cody
 */
#include "common.h"
#include "f021Bbox.h"

typedef struct {
    uint32_t u32Address;
    uint16_t u16Words;
    uint16_t u16Chksum;
} ST_BLACKBOX;

#define BBOX_VAR(name)   {(uint32_t)&name, sizeof(name), 0}
#define END_OF_BBOX_VAR  {0, 0, 0}


typedef union {
    uint32_t u32All;
    struct {
        uint16_t u16Length:8;
        uint16_t u16Version:8;
        uint16_t u16BuildDate:16; // start from 1/1/2024, Calculate by https://onlinealarmkur.com/date/zh-tw/
    };
}REG_VERSION;


REG_VERSION u32Version = {
     .u16BuildDate = FW_BUILDDATE,
     .u16Version = FW_VERSION,
     .u16Length = 0
};

ST_BLACKBOX sBBoxTable[] = {
                       BBOX_VAR(u32Version.u32All),
                       BBOX_VAR(sDrv.sVO.sCali.f32Gain),
                       BBOX_VAR(sDrv.sVO.sCali.f32Offset),
                       BBOX_VAR(sDrv.sVIN.sCali.f32Gain),
                       BBOX_VAR(sDrv.sVIN.sCali.f32Offset),
                       BBOX_VAR(sDrv.sIL.sCali.f32Gain),
                       BBOX_VAR(sDrv.sIL.sCali.f32Offset),
                       BBOX_VAR(sDrv.sIO.sCali.f32Gain),
                       BBOX_VAR(sDrv.sIO.sCali.f32Offset),
                       BBOX_VAR(sDrv.sLoopV.f32Kp),
                       BBOX_VAR(sDrv.sLoopV.f32Ki),
                       BBOX_VAR(sDrv.sLoopI.f32Kp),
                       BBOX_VAR(sDrv.sLoopI.f32Ki),
                       BBOX_VAR(sDrv.u32RdMode),
                       BBOX_VAR(sDrv.sRecord.u32all),
                       BBOX_VAR(sDrv.f32GainEnable),
                       END_OF_BBOX_VAR
};

typedef enum {
    _NO_ACTION_FOR_BBOX        = (0x00000000),
    _BBOX_FREE,
    _BBOX_CALLBACK_SUCCESS,

    _RESERVED_FOR_BBOX         = (0x00010000<<0),

    _READ_BACK_FROM_BBOX       = (0x00010000<<1),
    _GET_THE_AMMOUNT_OF_BBOX_VAR,
    _IS_VALID_BBOX_VAR_IN_FLASH,

    _WRITE_BBOX_INTO_FLASH     = (0x00010000<<2),
    _PREPARE_DATA_BLOCK_INFO,
    _ENABLE_FLASH_PUMP_FOR_BBOX,
    _WAIT_FOR_BBOX_PUMP_UP,
    _INIT_FLASH_FOR_BBOX,
    _INIT_BANK0_FOR_BBOX,
    _ERASE_THE_FLASH_SPACE_FOR_BBOX,
    _WAIT_FOR_ERASING_BBOX_READY,
    _PROGRAM_BBOX_VAR_INTO_FLASH,
    _WAIT_FOR_PROGRAM_BBOX_READY,

    _MARK_ERROR_FOR_BBOX        = (0x80000000)
}FSM_BBOX;


typedef union {
    uint16_t all[8];
    struct {
        uint16_t chksum;
        uint16_t size;
        uint16_t data[4];
        uint32_t address;
    };
}DATA_128BITS;

typedef DATA_128BITS * HAL_128BITS;

typedef struct {
    FSM_BBOX fsm;
    FSM_BBOX stat;
    uint32_t u32Ammount;
    uint32_t u32Index;
    HAL_128BITS pFlashData;
    DATA_128BITS regTempData;
    uint32_t u32DelayCnt;
    uint32_t u32Address;
    uint32_t u32PageAddress[4];
    Fapi_StatusType oReturnCheck;
}ST_BBOX;

#define BBOX_PAGE_0     C28_STORE_ADDRESS+0x000
#define BBOX_PAGE_1     C28_STORE_ADDRESS+0x400
#define BBOX_PAGE_2     C28_STORE_ADDRESS+0x800
#define BBOX_PAGE_3     C28_STORE_ADDRESS+0xC00


ST_BBOX sBbox =  {
     .fsm = _READ_BACK_FROM_BBOX,
     .stat = _NO_ACTION_FOR_BBOX,
     .u32Ammount = 0,
     .u32DelayCnt = FAPI_DELAY_CNTS,
     .pFlashData = (HAL_128BITS)C28_STORE_ADDRESS,
     .u32PageAddress = {
           BBOX_PAGE_0,
           BBOX_PAGE_1,
           BBOX_PAGE_2,
           BBOX_PAGE_3
     }
};




uint16_t isBboxFree(void)
{
    return (_BBOX_FREE == sBbox.fsm);
}

uint16_t isCallbackReady(void)
{
    return ((sBbox.stat & (_BBOX_CALLBACK_SUCCESS)) == (_BBOX_CALLBACK_SUCCESS));
}

void saveDataToFlash(void)
{
    sBbox.fsm = _WRITE_BBOX_INTO_FLASH;
}



#ifdef _FLASH
#pragma SET_CODE_SECTION(".fapi_ram")
#endif //_FLASH

uint32_t getEmptyAddress(void)
{
    uint32_t u32Address = 0;

    if(*((uint32_t*)sBbox.u32PageAddress[0]) == 0xFFFFFFFF) u32Address = BBOX_PAGE_0;
    else if(*((uint32_t*)sBbox.u32PageAddress[1]) == 0xFFFFFFFF) u32Address = BBOX_PAGE_1;
    else if(*((uint32_t*)sBbox.u32PageAddress[2]) == 0xFFFFFFFF) u32Address = BBOX_PAGE_2;
    else if(*((uint32_t*)sBbox.u32PageAddress[3]) == 0xFFFFFFFF) u32Address = BBOX_PAGE_3;

    return u32Address;
}

uint32_t getFinalAddress(void)
{
    uint32_t u32Address = 0;
    if(*((uint32_t*)sBbox.u32PageAddress[0]) != 0xFFFFFFFF) u32Address = BBOX_PAGE_0;
    if(*((uint32_t*)sBbox.u32PageAddress[1]) != 0xFFFFFFFF) u32Address = BBOX_PAGE_1;
    if(*((uint32_t*)sBbox.u32PageAddress[2]) != 0xFFFFFFFF) u32Address = BBOX_PAGE_2;
    if(*((uint32_t*)sBbox.u32PageAddress[3]) != 0xFFFFFFFF) u32Address = BBOX_PAGE_3;

    if(0 == u32Address) u32Address = BBOX_PAGE_0;

    return u32Address ;
}

void runFlashStorage(void)
{
    if(_BBOX_FREE == sBbox.fsm) return;


    EALLOW;
    switch(sBbox.fsm) {
    case _NO_ACTION_FOR_BBOX:
        break;

    case _READ_BACK_FROM_BBOX:
        sBbox.u32Address = getFinalAddress();
        sBbox.pFlashData = (HAL_128BITS)sBbox.u32Address;

    case _GET_THE_AMMOUNT_OF_BBOX_VAR:
        if((0xFF != sBbox.pFlashData[0].size) && (0 < sBbox.pFlashData[0].size)) {
            uint16_t u16chksum = sBbox.pFlashData[0].chksum;
            for(uint16_t i = 1; i<8; i++) {
                u16chksum -= sBbox.pFlashData[0].all[i];
            }

            if(0 == u16chksum) {
                uint16_t *pu16 = (uint16_t *)sBBoxTable[0].u32Address;
                for(uint16_t i = 0; i<sBbox.pFlashData[0].size; i++) {
                    pu16[i] = sBbox.pFlashData[0].data[i];
                }

                sBbox.u32Ammount = u32Version.u16Length;
                sBbox.u32Index = 1;
                sBbox.fsm = _IS_VALID_BBOX_VAR_IN_FLASH;
            }
            else {
                sBbox.fsm |= _MARK_ERROR_FOR_BBOX;
            }
        }
        else {
            sBbox.fsm |= _MARK_ERROR_FOR_BBOX;
        }
        break;

    case _IS_VALID_BBOX_VAR_IN_FLASH:
        if(sBbox.u32Index < sBbox.u32Ammount) {
            uint16_t u16chksum = sBbox.pFlashData[sBbox.u32Index].chksum;
            for(uint16_t i = 1; i<8; i++) {
                u16chksum -= sBbox.pFlashData[sBbox.u32Index].all[i];
            }

            if((0 == u16chksum)&&(sBbox.pFlashData[sBbox.u32Index].size == sBBoxTable[sBbox.u32Index].u16Words)) {
                uint16_t *pu16 = (uint16_t *)sBBoxTable[sBbox.u32Index].u32Address;
                for(uint16_t i = 0; i<sBbox.pFlashData[sBbox.u32Index].size; i++) {
                    pu16[i] = sBbox.pFlashData[sBbox.u32Index].data[i];
                }

                sBbox.stat |= _BBOX_CALLBACK_SUCCESS;
            }
            sBbox.u32Index++;
        }
        else {
            sBbox.fsm = _BBOX_FREE;
        }
        break;


    case _WRITE_BBOX_INTO_FLASH:
        sBbox.u32Ammount = 0;
        sBbox.fsm = _PREPARE_DATA_BLOCK_INFO;

    case _PREPARE_DATA_BLOCK_INFO:
        if(0 != sBBoxTable[sBbox.u32Ammount].u32Address) {
            sBbox.u32Ammount++;
        }
        else {
            u32Version.u16Length = sBbox.u32Ammount;
            sBbox.fsm = _ENABLE_FLASH_PUMP_FOR_BBOX;
        }
        break;

    case _ENABLE_FLASH_PUMP_FOR_BBOX:
        Flash_claimPumpSemaphore(FLASHPUMPSEMAPHORE_BASE, FLASH_PUMP_FOR_CPUX);
        sBbox.u32DelayCnt = FAPI_DELAY_CNTS;
        sBbox.fsm = _WAIT_FOR_BBOX_PUMP_UP;
        break;
    case _WAIT_FOR_BBOX_PUMP_UP:
        if(0<sBbox.u32DelayCnt) {
            sBbox.u32DelayCnt--;
        }
        else {
            sBbox.fsm = _INIT_FLASH_FOR_BBOX;
        }
        break;

    case _INIT_FLASH_FOR_BBOX:
        sBbox.oReturnCheck = Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, CPUCLK_FREQUENCY);
        if(Fapi_Status_Success == sBbox.oReturnCheck) {
            sBbox.fsm = _INIT_BANK0_FOR_BBOX;
        }
        break;

    case _INIT_BANK0_FOR_BBOX:
        sBbox.oReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);
        if(Fapi_Status_Success == sBbox.oReturnCheck) {
            sBbox.fsm = _ERASE_THE_FLASH_SPACE_FOR_BBOX;
        }
        break;

    case _ERASE_THE_FLASH_SPACE_FOR_BBOX:
        sBbox.u32Address = getEmptyAddress();
        sBbox.pFlashData = (HAL_128BITS)sBbox.u32Address;
        if(0 == sBbox.u32Address) {
            sBbox.pFlashData = (HAL_128BITS)BBOX_PAGE_0;
            sBbox.oReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector, (uint32 *)sBbox.pFlashData);
            sBbox.fsm = _WAIT_FOR_ERASING_BBOX_READY;
        }
        else {
            sBbox.u32Index = 0;
            sBbox.fsm = _PROGRAM_BBOX_VAR_INTO_FLASH;
            break;
        }


    case _WAIT_FOR_ERASING_BBOX_READY:
        sBbox.oReturnCheck = Fapi_checkFsmForReady();
        if(Fapi_Status_FsmReady == sBbox.oReturnCheck) {
            sBbox.u32Index = 0;
            sBbox.fsm = _PROGRAM_BBOX_VAR_INTO_FLASH;
        }
        break;

    case _PROGRAM_BBOX_VAR_INTO_FLASH:
        if(sBbox.u32Index < sBbox.u32Ammount) {
            uint16_t *pu16 = (uint16_t *)sBBoxTable[sBbox.u32Index].u32Address;
            sBbox.regTempData.address = sBBoxTable[sBbox.u32Index].u32Address;
            sBbox.regTempData.size = sBBoxTable[sBbox.u32Index].u16Words;
            sBbox.regTempData.chksum = sBbox.regTempData.size + sBbox.regTempData.address;
            for(uint16_t i = 0; i<4; i++) {
                if(i<sBBoxTable[sBbox.u32Index].u16Words) {
                    sBbox.regTempData.data[i] = pu16[i];
                    sBbox.regTempData.chksum += pu16[i];
                }
                else {
                    sBbox.regTempData.data[i] = 0;
                }
            }

            Fapi_issueProgrammingCommand((uint32 *)&sBbox.pFlashData[sBbox.u32Index], (uint16 *)sBbox.regTempData.all, ALIGN_WORD_ADDRESS_BY,
                                         0, 0, Fapi_AutoEccGeneration);
            sBbox.fsm = _WAIT_FOR_PROGRAM_BBOX_READY;
        }
        else {
            Flash_releasePumpSemaphore(FLASHPUMPSEMAPHORE_BASE);

            sBbox.fsm = _READ_BACK_FROM_BBOX;
        }
        break;
    case _WAIT_FOR_PROGRAM_BBOX_READY:
        sBbox.oReturnCheck = Fapi_checkFsmForReady();
        if(Fapi_Status_FsmReady == sBbox.oReturnCheck) {
            sBbox.u32Index++;
            sBbox.fsm = _PROGRAM_BBOX_VAR_INTO_FLASH;
        }
    default:
        break;
    }

    EDIS;
}

#ifdef _FLASH
#pragma SET_CODE_SECTION()
#endif //_FLASH
//
// End of File
//
