/*
 * tstBlock.c
 *
 *  Created on: 2023¦~5¤ë24¤é
 *      Author: cody_chen
 */


#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"

typedef enum {
    _INIT_TEST_BLOCK_RAM = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _VARIFY_BLOCK_DATA,
    _FREE_TEST_EEPROM
} TEST_EVENT;

TEST_EVENT tstfsm = _FREE_TEST_EEPROM;
int beginAddress = 0;
int ptrAddress = 0;
int endAddress = 0;
int procBytes = 0;
int testBytes = EMU_KBYTES;

typedef enum {
    _EV_GET_ADDRESS = 0,
    _EV_UPLOAD_DATA,
    _EV_END_OF_UPLOAD,
    _EV_END_OF_INIT_TESTBLOCK
}REG_INIT_TSTBLOCK;

typedef REG_INIT_TSTBLOCK REG_RST_TSTBLOCK;

REG_INIT_TSTBLOCK regInitTstBlock = _EV_GET_ADDRESS;

//void initBlockRam(void)
//{
//        switch(regInitTstBlock) {
//            case _EV_GET_ADDRESS:
//                endAddress = beginAddress + testBytes;
//                ptrAddress = beginAddress;
//                procBytes = 0;
//                regInitTstBlock = _EV_UPLOAD_DATA;
//            break;
//
//          case _EV_UPLOAD_DATA:
//                if(procBytes < testBytes) {
//                     writeEmuEeprom(ptrAddress, ptrAddress%0xFF);
//                     ptrAddress++;
//                     procBytes++;
//                     ptrAddress&=0x3FF;
//                     if(EMU_SIZE_OF_SECTOR <= ptrAddress) ptrAddress -= EMU_SIZE_OF_SECTOR;
//                }
//                else {
//                    ptrAddress = beginAddress;
//                    regInitTstBlock = _EV_END_OF_UPLOAD;
//                }
//
//            break;
//
//          case _EV_END_OF_UPLOAD:
//                tstfsm = _FREE_TEST_EEPROM;
//                regInitTstBlock = _EV_GET_ADDRESS;
//            break;
//
//            default:
//            break;
//        }
//}

//uint16 SW = 0;
//uint16 xx = 0x1234;
//uint16 pu16DataBuffer[]= {0x1234,0x2345,0x1234,0x2345,0x0D05,0x0E06,0x0F07,0x0108};
//uint16 u16Dword = 4;
//Fapi_FlashStatusType  oFlashStatus;
//Fapi_FlashStatusWordType  oFlashStatusWord;

//void testFlash()
//{
////    HAL_EMUEE p = &stEmuEE;
//
//    if (SW == 1)
//    {
//      Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector, (uint32 *)p->u32BoundaryAddress);
//        SW = 0;
//    }
//    else if (SW == 2)
//    {
//      Fapi_issueProgrammingCommand((uint32*)p->u32BoundaryAddress,(uint16 *)pu16DataBuffer,u16Dword,0,0,Fapi_AutoEccGeneration);
//        SW = 0;
//    }
//    else if (SW == 3)
//    {
//      Fapi_issueProgrammingCommand((uint32*)p->u32BoundaryAddress,(uint16_t *)&xx,2,0,0,Fapi_AutoEccGeneration);
//        SW = 0;
//    }
//    else if(SW == 4)
//    {
//      Fapi_issueProgrammingCommand((uint32*)p->u32BoundaryAddress,(uint16_t *)&p->regData32.info,2,0,0,Fapi_AutoEccGeneration);
//        SW = 0;
//    }
//}


void initBlockRam(void)
{
        switch(regInitTstBlock) {
            case _EV_GET_ADDRESS:
                endAddress = beginAddress + testBytes;
                ptrAddress = beginAddress;
                procBytes = 0;
                regInitTstBlock = _EV_UPLOAD_DATA;
            break;

          case _EV_UPLOAD_DATA:
                if(procBytes < testBytes) {
                     writeEmuEeprom(ptrAddress, ptrAddress%0xFF);
                     ptrAddress++;
                     procBytes++;
                     ptrAddress&=0xFF;
                     if(EMU_SIZE_OF_SECTOR <= ptrAddress) ptrAddress -= EMU_SIZE_OF_SECTOR;
                }
                else {
                    ptrAddress = beginAddress;
                    regInitTstBlock = _EV_END_OF_UPLOAD;
                }

            break;

          case _EV_END_OF_UPLOAD:
                tstfsm = _FREE_TEST_EEPROM;
                regInitTstBlock = _EV_GET_ADDRESS;
            break;

            default:
            break;
        }
}


REG_RST_TSTBLOCK regRESTstBlock = _EV_GET_ADDRESS;

void resetBlockRam(void)
{
        switch(regRESTstBlock) {
            case _EV_GET_ADDRESS:
                endAddress = beginAddress + testBytes;
                ptrAddress = beginAddress;
                procBytes = 0;
                regRESTstBlock = _EV_UPLOAD_DATA;
            break;

          case _EV_UPLOAD_DATA:
              if(procBytes < testBytes) {
                     writeEmuEeprom(ptrAddress, 0xFF);
                     ptrAddress++;
                     procBytes++;
                     if(EMU_SIZE_OF_SECTOR <= ptrAddress) ptrAddress -= EMU_SIZE_OF_SECTOR;
                }
                else {
                    ptrAddress = beginAddress;
                    regRESTstBlock = _EV_END_OF_UPLOAD;
                }

            break;

          case _EV_END_OF_UPLOAD:
                tstfsm = _FREE_TEST_EEPROM;
                regRESTstBlock = _EV_GET_ADDRESS;
            break;

            default:

            break;

        }
}

void varifyBlockFlash(void)
{

}

uint32_t u32TestTimes = 100;
uint32_t u32TestTimeout = T_100MS;
uint32_t u32TestStep = 0;


void tstEmuEeprom(void)
{

   //   loopWriteBlock();

    switch(tstfsm) {
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
                tstfsm = _FREE_TEST_EEPROM;
        break;

    case _VARIFY_BLOCK_DATA:
        setVerifyEmuEeprom();
            tstfsm = _FREE_TEST_EEPROM;
        break;

    case _FREE_TEST_EEPROM:
    default:

        break;
    }


}

