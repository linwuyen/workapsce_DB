/*
 * Test.c
 *
 *  Created on: 2023�~12��21��
 *      Author: roger_lin
 */

#include "common.h"
#include "Test.h"

BUS_State_struct BUS_State;

#define SET_EE(bit)  FG_SET(bit, p->fgStat);

//const EE_PACK packTest = {
////       .pu16Block = &u16EEHeader[0],//
////       .u16StartOfBlock = 0x00,
////       .u16SizeOfBlock = 0x400, //1024 byte
////       .pregTable = (void*)&sEE.testCommonHeader[0],
////       .u16SizeOfTable = 0x400, //1024 byte
////       .u16BlockType = _BLKTYP_CONTINUE_VAR_BLOCK
//
//};

void EEPROM_Reset(){
    EALLOW;

    GPIO_setPinConfig(EEPROM_I2CSDA_PIN_CONFIG);
    GPIO_setPadConfig(EEPROM_I2CSDA_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(EEPROM_I2CSDA_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(EEPROM_I2CSCL_PIN_CONFIG);
    GPIO_setPadConfig(EEPROM_I2CSCL_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(EEPROM_I2CSCL_GPIO, GPIO_QUAL_ASYNC);

    EEPROM_init();
    EDIS;
//    *sEE.pu16BlockStep =_I2C_EEPROM_FREE;
}

//      //   �P�_ 0x1466||0x1400 �NReset
//      // if(TimeOutCrtl.I2C_status == 0x1466||0x1400){
//      //! - \b I2C_INTSRC_NO_ACK


//static inline bool CPUTimer_isTimerEnable(uint32_t base)
//{
//    // Get TSS bit of register TCR
//
//    return (HWREGH(base + CPUTIMER_O_TCR) &CPUTIMER_TCR_TSS? false: true);
//}


//void Check_I2C_Status(){
    //get Timer_Count
  //  TimerCnt = CPUTimer_getTimerCount(Cool_CPUTIMER_BASE);
//
//    //get I2C_Status
//    I2C_status = I2C_getStatus(EEPROM_BASE);
//
//
////   1.I2C�}�l�ǿ�RUNtime0
//    if (*v->pu16BlockStep ==_I2C_SEND_MEM_ADDRESS){
//        //time0_start
//        CPUTimer_startTimer(Cool_CPUTIMER_BASE);
//
//    }
//    if(CPUTimer_isTimerEnable(Cool_CPUTIMER_BASE)) {
//        TIF_UP= CPUTimer_getTimerOverflowStatus(Cool_CPUTIMER_BASE);
//
//        if(CPUTimer_getTimerOverflowStatus(Cool_CPUTIMER_BASE)){
//            //3.�S������ACK�ATIF�԰_ �u�୫�m
//            EEPROMReset();
//            Resetcounter++;
//        }else{
//            //2.����ACK           time0_reload
//            CPUTimer_reloadTimerCounter(Cool_CPUTIMER_BASE);
//            reloadcounter++;
//        }
//    }
//}


//void trgTestMode(){
//    //p->fgStat = _TEST_EEPROM;
//}

uint8_t Random_data(){
    uint8_t i;

        for (i = 0; i < 1024; ++i) {
           // sEE.testCommonHeader[i] = (uint8_t)CPUTimer_getTimerCount(SWTIRMER_BASE) % 0xff;
   }
        return 0;
}

uint8_t Sequencedata(){

    uint8_t i;

    for(i = 0; i < 1024; i++) {
         // sEE.testCommonHeader[i] = i + 1;
      }
    return 0;
}

void I2C_Bus_Detect(){

}

//uint16_t testBoard(HAL_EEPROM v){
//        if(&v->u16SetBoardInfo != v->pu16BlockStep) {
//            v->pu16BlockStep = &v->u16SetBoardInfo;
//            v->pPack = (HAL_PACK)&packTest;
//        }
//        return setBlock(v);
//}


void I2C_test_EEPROM(){

    HALBUS_State p = &BUS_State;

    switch(p->EEPROM_Status) {

        case _Prepare_Data:
//           Random_data();
//           Sequence_data();
//           p->fgStat = _FREE_EEPROM;
            break;

        case _FREE_EEPROM:
            break;

        case _Send_Data:
            break;

        case _BUS_DETECT:
            I2C_Bus_Detect();
//            Random_data();
//            Sequencedata();
//            getCommonHeader(p);
//            p->fgStat = _TEST_EEPROM;
            break;

        case _Error_EEPROM:
            break;

        case _TEST_EEPROM:
         //    testBoard(p);
             break;

        default:

            break;
    }
}

