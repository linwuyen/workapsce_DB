/*
 * Test.h
 *
 *  Created on: 2023�~12��21��
 *      Author: roger_lin
 */

#ifndef TEST_EEPROM_TEST_H_
#define TEST_EEPROM_TEST_H_

#include "common.h"

typedef enum{
    _Prepare_Data       =    (0x0000),
    _FREE_EEPROM       = (0x0001<<0),
    _Send_Data         = (0x0001<<1),
    _BUS_DETECT        = (0x0001<<2),
    _TEST_EEPROM       = (0x0001<<3),
    _Error_EEPROM      =    (0x8000)
}EV_EEPROM_state;


typedef struct{
    EV_EEPROM_state              fsm;
    uint32_t           reloadcounter;
    uint32_t            Resetcounter;
    uint32_t                TimerCnt;
    uint32_t              EEPROM_Status;
    bool                      TIF_UP;
}BUS_State_struct;

typedef BUS_State_struct * HALBUS_State;
extern BUS_State_struct BUS_State;
extern void I2C_test_EEPROM(void);





#endif /* TEST_EEPROM_TEST_H_ */
