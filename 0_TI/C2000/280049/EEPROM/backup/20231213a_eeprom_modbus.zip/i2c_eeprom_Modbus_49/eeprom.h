/*
 * eeprom.h
 *
 *  Created on: 2023�~4��18��
 *      Author: cody_chen
 */

#ifndef EEPROM_H_
#define EEPROM_H_


#include "common.h"


#define EEPROM_SRC      EEPROM_BASE
#define EEPROM_ADDR     EEPROM_TARGET_ADDRESS



extern void execEEPROM(void);

typedef uint16_t FG_EEPROM;

typedef union {
    uint16_t u16Block[8];
    struct {
        uint16_t format_version;
        uint16_t internal_user_area;
        uint16_t chassis_info_area;
        uint16_t board_info_area;
        uint16_t product_info_area;
        uint16_t multi_record_area;
        uint16_t pad_reserved_area;
        uint16_t checksum;
    };
} BLK_COMMON_HEADER;

typedef struct{
    uint16_t *pu16Block;
    uint16_t u16StartOfBlock;
    uint16_t u16SizeOfBlock;
    void     *pregTable;
    uint16_t u16SizeOfTable;
    uint16_t u16BlockType;
} EE_PACK;
typedef EE_PACK * HAL_PACK;

typedef struct {
    uint32_t  u32Base;
    uint16_t  u16SlaveID;
    FG_EEPROM fgStat;

    uint16_t  u16GetHeader;
    uint16_t  u16SetHeader;

    BLK_COMMON_HEADER blkCommonHeader;
    uint16_t  testCommonHeader[1024];

    uint16_t  u16GetBoardInfo;
    uint16_t  u16SetBoardInfo;

    uint16_t  u16timeact;
    uint32_t  u32timetick;
    uint32_t  u32timestamp;
    uint32_t  u32timecnt;
    uint32_t  u32timeout;

    uint16_t  u16MemAddr;
    uint16_t  u16PageAddr;
    uint16_t  u16RemainSize;
    uint16_t  u16WriteSize;
    uint16_t  u16ReadSize;
    uint16_t  u16Index;
    uint16_t  u16Offset;
    uint16_t  u16Rsize;
    uint16_t  u16Checksum;

    uint16_t  *pu16BlockStep;
    HAL_PACK  pPack;


} ST_EEPROM;


extern ST_EEPROM sEE;

#endif /* EEPROM_H_ */
