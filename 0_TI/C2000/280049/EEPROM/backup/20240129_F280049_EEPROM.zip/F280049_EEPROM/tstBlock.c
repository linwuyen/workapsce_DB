/*
 * tstBlock.c
 *
 *  Created on: 2023¦~5¤ë24¤é
 *      Author: cody_chen
 */

#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"

typedef enum
{
    _INIT_TEST_BLOCK_RAM = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _VARIFY_BLOCK_DATA,
    _FREE_TEST_EEPROM
} TEST_EVENT;

typedef enum
{
    _EV_GET_ADDRESS = 0,
    _EV_UPLOAD_DATA,
    _EV_END_OF_UPLOAD,
    _EV_END_OF_INIT_TESTBLOCK
} REG_INIT_TSTBLOCK;

typedef struct
{
    REG_INIT_TSTBLOCK regInitTstBlock;
    TEST_EVENT tstfsm;
    int beginAddress;
    int ptrAddress;
    int endAddress;
    int procBytes;
    int testBytes;
} st_tst;

st_tst sttst = { .testBytes = EMU_KBYTES, .regInitTstBlock = _EV_GET_ADDRESS,
                 .tstfsm = _FREE_TEST_EEPROM, };

typedef REG_INIT_TSTBLOCK REG_RST_TSTBLOCK;

st_tst *p = &sttst;

void initBlockRam(void)
{
    switch (p->regInitTstBlock)
    {
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;
        p->regInitTstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, p->ptrAddress % 0xFFFF);
            p->ptrAddress++;
            p->procBytes++;
            p->ptrAddress &= 0xFFFF;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            p->regInitTstBlock = _EV_END_OF_UPLOAD;
        }
        break;

    case _EV_END_OF_UPLOAD:
        p->tstfsm = _FREE_TEST_EEPROM;
        p->regInitTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}

REG_RST_TSTBLOCK regRESTstBlock = _EV_GET_ADDRESS;

void resetBlockRam(void)
{
    switch (regRESTstBlock)
    {
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;
        regRESTstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, 0xFFFF);
            p->ptrAddress++;
            p->procBytes++;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            regRESTstBlock = _EV_END_OF_UPLOAD;
        }

        break;

    case _EV_END_OF_UPLOAD:
        p->tstfsm = _FREE_TEST_EEPROM;
        regRESTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}

void tstEmuEeprom(void)
{
    //   loopWriteBlock();
    switch (p->tstfsm)
    {
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _VARIFY_BLOCK_DATA:
        setVerifyEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _FREE_TEST_EEPROM:

    default:
        break;
    }
}
//======================================================================

#define RAMSize  10

typedef enum
{
    _EV_IDLE                   = (0x0000),
    _EV_INIT_EEPROM            = (0x0001),
    _EV_WRITE_EEPROM           = (0x0002),
    _EV_READ_EEPROM            = (0x0003),
    _EV_RESET_EEPORM           = (0x0004),
    _MASK_EMU_EEPROM_ERROR     = (0x8000)
}tst_FUN_FSM;

typedef struct
{
    tst_FUN_FSM tstFSM;
    uint16 u16Addr;
    uint16 u16Data;
    uint16 u16Size;
    uint64 u64DataRam[RAMSize];
}ST_fun;

typedef ST_fun *HAL_fun;

ST_fun STFUN =
{
       .tstFSM = _EV_IDLE,
};

int16_t initEEPROM (u16Addr,u16Data,u16Size)
{
    int16_t x;
    x = 16;
    return  x ;
}

int16_t writeEEPROM (u16Addr,u16Data,u16Size)
{
    int16_t x;
    x = 16;
    return  x ;
}

int16_t readEEPROM (u16Addr,u16Data,u16Size)
{
    int16_t x;
    x = 16;
    return  x ;
}

void TstFunction(void)
{

    switch(STFUN.tstFSM){
    //��l��
    case _EV_INIT_EEPROM:
        break;

    //write EEPROM ���ݳ̫�@��
    case _EV_WRITE_EEPROM:
        break;
    //Read EEPROM
    case _EV_READ_EEPROM:
        break;
    case _MASK_EMU_EEPROM_ERROR:

    default:
        break;
    }
}
