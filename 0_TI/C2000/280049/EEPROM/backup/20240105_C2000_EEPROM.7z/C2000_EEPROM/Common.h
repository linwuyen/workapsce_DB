/*
 * Common.h
 *
 *  Created on: 2024�~1��5��
 *      Author: roger_lin
 */

#ifndef COMMON_H_
#define COMMON_H_

#define SW_TIMER            50000000


#define T_100MS            (SW_TIMER/5)

typedef bool bool_t;


#endif /* COMMON_H_ */
