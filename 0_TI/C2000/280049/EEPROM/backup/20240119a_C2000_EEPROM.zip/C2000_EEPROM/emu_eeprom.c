/*
 * emu_eeprom.c
 *
 *  Created on: 2023�~5��15��
 *      Author: cody_chen
 */


#include "emu_eeprom.h"


Fapi_StatusType ReturnCheck;
typedef enum {
    _INIT_EMU_EEPROM        = (0x0000),
    _CALL_BACK_EMU_EEPROM   = (0x0001<<0),
    _FREE_EMU_EEPROM        = (0x0001<<1),
    _BUSY_EMU_EEPROM        = (0x0001<<2),
    _PROGRAM_EMU_EEPROM     = (0x0001<<3),
    _VERIFY_EMU_EEPORM      = (0x0001<<4),
    _MASK_EMU_EEPROM_ERROR  = (0x8000)
} FS_EMUEE;
typedef uint16_t REG_EMUEE;  // Refer to FS_EMUEE

typedef union {
    uint16_t all[BYTES_OF_FLASH_WORD];
    uint64_t u64;
    struct {
        uint32_t Lo;
        uint32_t Hi;
    } u32;
} FLASH_WORD;

const FLASH_WORD DEFAULT_FLASH_WORD = {0xFFFF,0xFFFF,0xFFFF,0xFFFF};


typedef union {
    FLASH_WORD block;
    struct {
        uint32_t start;       // the data of start address
        uint32_t next;        // the data of next address
    } info;
} REG_HEADER_CONTENT; // Data Range
typedef REG_HEADER_CONTENT * HAL_HEADER_CONTENT;

typedef union {
    uint32_t all;
    struct {
        uint16_t idno;
        uint16_t  databyte;
    } info;
} REG_DATA32;
typedef REG_DATA32 * HAL_DATA32;

typedef union {
    FLASH_WORD block;
    struct {
        REG_DATA32 lo;
        REG_DATA32 hi;
    } info;
} REG_DATA64_CONTENT;
typedef REG_DATA64_CONTENT * HAL_DATA64_CONTENT;


typedef enum {
    _READ_HEADER_INDEX           = 0x0000,
    _GET_HEADER_INDEX            = (0x0001<<0),
    _PARSE_HEADER_CONTENT        = (0x0001<<1),
    _READ_FROM_FLASH_TO_RAM      = (0x0001<<2),
    _VERIFY_FLASH_BY_RAM         = (0x0001<<3),
    _MARK_ERROR_FOR_CALLBACK_FSM = 0x8000
} FSM_CALBACK;

typedef struct {
    FSM_CALBACK fsm;
    uint16_t    i;
    uint16_t    *ptr;
    uint32_t    u32Debug;
} ST_CALBACK;



typedef enum {
    _PREPARE_HEADER_INFORMATION     = 0x0000,
    _SCAN_VALID_DATA_IN_RAM         = (0x0001<<0),
    _PROGRAM_VALID_DATA64_TO_FLASH  = (0x0001<<1),
    _ERASE_DATA_SECTION             = (0x0001<<2),
    _RECORD_VALID_DATA_TO_HEADER    = (0x0001<<3),
    _REMARK_HEADER_INDEX            = (0x0001<<4),
    _ERASE_HEADER_SECTION           = (0x0001<<5),
    _END_OF_PROGRAM_EMU_EEPROM      = (0x0001<<6),
    _MASK_ERROR_FOR_PROG_EEPROM     = 0x8000
} FSM_PROGRAM;

typedef struct {
    FSM_PROGRAM fsm;
    uint16_t    i;
    uint8_t     *ptr;
    uint32_t    u32Debug;
} ST_PROGRAM;

typedef struct{
    REG_EMUEE           fgEmuEE;
    FLASH_WORD          HeaderSectionMark;
    uint16_t            u16HeaderIndex;
    uint32_t            u32HeaderAddress;
    uint8_t             u8HeaderChecksum;
    uint32_t            u32DataAddress;
    uint8_t             u8DataChecksum;
    HAL_DATA32          pDataContent;
    REG_HEADER_CONTENT  regHeader;
    REG_DATA64_CONTENT  regData64;
    uint16_t            u16RamCount;
    uint16_t            u16RAM[EMU_SIZE_OF_EEPROM];
    uint32_t            u32BoundaryAddress;
    uint32_t            u32EraseAddress;
    uint32_t            u32OddEven;

    ST_CALBACK          sCB;
    ST_PROGRAM          sPG;


} ST_EMUEE;

typedef ST_EMUEE * HAL_EMUEE;


// 1. After power on, need to initial all of RAM and set by 0xFF for formating this area.
// 2. Call back the first 64bits of first section of flash, to parsing where is the entry pointer.
// 3. Jump to the entry pointer to get the package of header, before parsing the package need to checksum correctly first.
// 4. After get the correct package of header, then jump to the start address of flash which is mention in the header.
// 5. Start to read from flash to ram, during reading you need to check each the package of data whether is corrected.
// If the content of Ram is not equal to 0xFF, then need to save the index, data and checksum to the flash.

#define SET_EE(bit)  FG_SET(bit, stEmuEE.fgEmuEE);
#define RST_EE(bit)  FG_RST(bit, stEmuEE.fgEmuEE);
#define SWTO_EE(bit) FG_SWTO(bit, stEmuEE.fgEmuEE);
#define GET_EE(bit)  FG_GET(bit, stEmuEE.fgEmuEE)
#define AND_EE(bit)  FG_AND(bit, stEmuEE.fgEmuEE)



ST_EMUEE stEmuEE;

uint16_t getEepromErrorStatus(void)
{
    return (stEmuEE.sPG.fsm & _MASK_ERROR_FOR_PROG_EEPROM);
}

uint8_t getChecksum(uint8_t * pByte, uint8_t length)
{
    uint8_t i;
    uint8_t chksum;
    for(i=0, chksum=0; i<length; i++) {
        chksum += (pByte[i]);
    }

    chksum = 0xFF- chksum;
    chksum = chksum + 0x01;

    return chksum;
}

void clearBit(uint8_t array[], int bitIndex) {
    int byteIndex = bitIndex / 8;         // Find the index of the byte containing the bit
    int bitOffset = bitIndex % 8;         // Find the offset of the bit within the byte

    uint8_t mask = ~(1u << bitOffset);    // Create a mask with the bit at bitOffset set to 0
    array[byteIndex] &= mask;             // Perform bitwise AND with the mask to clear the bit
}

void markBit(uint8_t array[], int bitIndex) {
    int byteIndex = bitIndex / 8;         // Find the index of the byte containing the bit
    int bitOffset = bitIndex % 8;         // Find the offset of the bit within the byte

    uint8_t mask = 1u << bitOffset;       // Create a mask with the bit at bitOffset set to 1
    array[byteIndex] |= mask;             // Perform bitwise OR with the mask to mark the bit
}


void getMask(uint8_t * pMask, int bitIndex) {
    for(int i = 0; i < bitIndex; i++) {
        pMask[0] |= (0x01 <<i);
    }
}

uint16_t getAddressSection(uint16_t address) {
    uint16_t section = address / EMU_SIZE_OF_SECTOR;  // Calculate the section index
    return section;
}



int16_t writeEmuEepromBlock(uint16_t u16addr, uint8_t *pSrcByte, uint8_t length)
{
    uint16_t u16TempAddr = 0;
    uint16_t i = 0;
    if(_FREE_EMU_EEPROM == stEmuEE.fgEmuEE) {
        for(i=0; i<length; i++) {
            u16TempAddr = u16addr+i;
            if(EMU_KBYTES <= u16TempAddr) u16TempAddr -= EMU_KBYTES;
            stEmuEE.u16RAM[u16TempAddr] = pSrcByte[i];
        }

        SWTO_EE(_PROGRAM_EMU_EEPROM);
        return i;

    }
    else {
        return -1;
    }
}

int16_t writeEmuEeprom(uint16_t u16addr, uint8_t u8Data)
{
    uint16_t u16TempAddr = 0;
    if(EMU_KBYTES <= u16addr) u16TempAddr = u16addr - EMU_KBYTES;
    else                      u16TempAddr = u16addr;
    stEmuEE.u16RAM[u16TempAddr] = u8Data;

    return 1;
}

int16_t setProgramEmuEeprom(void)
{
    if(_FREE_EMU_EEPROM == stEmuEE.fgEmuEE) {
        SWTO_EE(_PROGRAM_EMU_EEPROM);
        return 1;
    }
    else {
        return 0;
    }
}

int16_t setVerifyEmuEeprom(void)
{
    if(_FREE_EMU_EEPROM == stEmuEE.fgEmuEE) {
        SWTO_EE(_VERIFY_EMU_EEPORM);
        return 1;
    }
    else {
        return 0;
    }
}

int8_t waittingEmuEeprom(void)
{

        return (_FREE_EMU_EEPROM == stEmuEE.fgEmuEE);
}


uint8_t * readEmuEeprom(uint16_t u16addr)
{
    uint16_t u16TempAddr = 0;
    if(_FREE_EMU_EEPROM == stEmuEE.fgEmuEE) {
        u16TempAddr = u16addr;
        if(EMU_KBYTES <= u16TempAddr) u16TempAddr -= EMU_KBYTES;
        return &stEmuEE.u16RAM[u16TempAddr];
    }
    else {
        return 0;
    }
}



void initEmuEeprom(HAL_EMUEE p)
{
    if(EMU_SIZE_OF_EEPROM > p->u16RamCount) {
        p->u16RAM[p->u16RamCount++] = 0xFFFF;
    }
    else {
        p->HeaderSectionMark = DEFAULT_FLASH_WORD;

        p->pDataContent = 0;
        p->sCB.fsm = _READ_HEADER_INDEX;
        p->sCB.ptr = (uint16_t *)EMU_START_OF_HEADER;

        p->sPG.fsm = _PREPARE_HEADER_INFORMATION;
        p->sPG.ptr = (uint16_t *)EMU_START_OF_EEPROM;
        SWTO_EE(_CALL_BACK_EMU_EEPROM);
    }
}
int16_t isEmuEepromFree(void)
{
    return GET_EE(_FREE_EMU_EEPROM);
}

int builtin_ctz64(uint64_t x) {
    if (x == 0) {
        // Special case: x is zero, which has no trailing zeros.
        return 64;
    }

    int count = 0;
    while ((x & 1) == 0) {
        // Keep shifting x to the right until the least significant bit becomes 1.
        x >>= 1;
        count++;
    }

    return count;
}

void callbackFromFlash(HAL_EMUEE p)
{
    switch (p->sCB.fsm) {
    case _READ_HEADER_INDEX:

        // Copy the header mark in flash to the header mark in ram.
        for(int i = 0; i<BYTES_OF_FLASH_WORD; i++) {
            p->HeaderSectionMark.all[i] = p->sCB.ptr[i];
        }

        // Reset Header Index
        p->u16HeaderIndex = 0;
        p->sCB.fsm =_GET_HEADER_INDEX;
        break;

    case _GET_HEADER_INDEX:
        // Get the position of the least significant set bit
        p->u16HeaderIndex = builtin_ctz64(p->HeaderSectionMark.u64);

        if(0 == p->u16HeaderIndex) {
            // emuEEPROM is empty.
            p->regHeader.info.start = EMU_START_OF_EEPROM;
            p->regHeader.info.next = EMU_START_OF_EEPROM;
            p->sCB.fsm =_READ_HEADER_INDEX;
            SWTO_EE(_FREE_EMU_EEPROM);
        }
        else {
            p->u32HeaderAddress = (uint32_t)(p->sCB.ptr + p->u16HeaderIndex * BYTES_OF_FLASH_WORD);
            p->sCB.fsm =_PARSE_HEADER_CONTENT;
        }
        break;

    case _PARSE_HEADER_CONTENT:
        p->regHeader = *((HAL_HEADER_CONTENT)p->u32HeaderAddress);
        p->u32DataAddress = (uint32_t)(p->regHeader.info.start);
        p->sCB.fsm =_READ_FROM_FLASH_TO_RAM;

        break;

    case _READ_FROM_FLASH_TO_RAM:
        if(p->u32DataAddress != p->regHeader.info.next) {
            // Get a 32bits from the data section.
            p->u8DataChecksum = getChecksum((uint8_t *)p->u32DataAddress, 4);
            if(0 == p->u8DataChecksum) {
                p->pDataContent = (HAL_DATA32)p->u32DataAddress;
                p->u16RAM[p->pDataContent->info.idno] = p->pDataContent->info.databyte;
                // Go to the next data
                p->u32DataAddress += 4;
                if(EMU_END_OF_FLASH <= p->u32DataAddress) {
                    // If over the range of emulation, then need to roll over the data address.
                    p->u32DataAddress -= EMU_SIZE_OF_DATA;
                }

            }
            else {
                p->sCB.fsm |=_MARK_ERROR_FOR_CALLBACK_FSM;
            }
        }
        else {
            // Reset fsm for entry next time.
            p->sCB.fsm =_READ_HEADER_INDEX;
            SWTO_EE(_FREE_EMU_EEPROM);
        }
        break;

    default:
        break;
    }
}

void varifyFlashByRAM(HAL_EMUEE p)
{
    switch (p->sCB.fsm) {
    case _READ_HEADER_INDEX:

        // Copy the header mark in flash to the header mark in ram.
        for(int i = 0; i<BYTES_OF_FLASH_WORD; i++) {
            p->HeaderSectionMark.all[i] = p->sCB.ptr[i];
        }

        // Reset Header Index
        p->u16HeaderIndex = 0;
        p->sCB.fsm =_GET_HEADER_INDEX;
        break;

    case _GET_HEADER_INDEX:
        p->u16HeaderIndex = builtin_ctz64(p->HeaderSectionMark.u64);

        if(0 == p->u16HeaderIndex) {
            // emuEEPROM is empty.
            p->regHeader.info.start = EMU_START_OF_EEPROM;
            p->regHeader.info.next = EMU_START_OF_EEPROM;
            p->sCB.fsm =_READ_HEADER_INDEX;
            SWTO_EE(_FREE_EMU_EEPROM);
        }
        else {
            p->u32HeaderAddress = (uint32_t)(p->sCB.ptr + p->u16HeaderIndex * BYTES_OF_FLASH_WORD);
            p->sCB.fsm =_PARSE_HEADER_CONTENT;
        }
        break;

    case _PARSE_HEADER_CONTENT:
        p->regHeader = *((HAL_HEADER_CONTENT)p->u32HeaderAddress);
        p->u32DataAddress = (uint32_t)(p->regHeader.info.start);
        p->sCB.fsm =_VERIFY_FLASH_BY_RAM;

        break;

    case _VERIFY_FLASH_BY_RAM:
        if(p->u32DataAddress != p->regHeader.info.next) {
            // Get a 32bits from the data section.
            p->u8DataChecksum = getChecksum((uint8_t *)p->u32DataAddress, 4);
            if(0 == p->u8DataChecksum) {
                p->pDataContent = (HAL_DATA32)p->u32DataAddress;

                if(p->u16RAM[p->pDataContent->info.idno] != p->pDataContent->info.databyte) {
                    p->sCB.fsm |=_MARK_ERROR_FOR_CALLBACK_FSM;
                }
                else {
                    // Go to the next data
                    p->u32DataAddress += 4;
                    if(EMU_END_OF_FLASH <= p->u32DataAddress) {
                        // If over the range of emulation, then need to roll over the data address.
                        p->u32DataAddress -= EMU_SIZE_OF_DATA;
                    }
                }
            }
            else {
                p->sCB.fsm |=_MARK_ERROR_FOR_CALLBACK_FSM;
            }
        }
        else {
            // Reset fsm for entry next time.
            p->sCB.fsm =_READ_HEADER_INDEX;
            SWTO_EE(_FREE_EMU_EEPROM);
        }
        break;

    default:
        break;
    }
}

Fapi_StatusType DL_FlashCTL_programMemoryFromRAM64WithECCGenerated(uint32_t u32Addr, uint64_t u64Data) {

    uint16_t u16Temp[] = {
                          (u64Data>>0)&0x0000'0000'0000'00FF ,
                          (u64Data>>8)&0x0000'0000'0000'00FF ,
                          (u64Data>>16)&0x0000'0000'0000'00FF ,
                          (u64Data>>24)&0x0000'0000'0000'00FF ,
                          (u64Data>>32)&0x0000'0000'0000'00FF ,
                          (u64Data>>40)&0x0000'0000'0000'00FF ,
                          (u64Data>>48)&0x0000'0000'0000'00FF ,
                          (u64Data>>56)&0x0000'0000'0000'00FF

    };


    return Fapi_issueProgrammingCommand((uint32 *)(0x080000|u32Addr), (uint16 *)u16Temp,8,0,0,Fapi_AutoEccGeneration);

}

void progEmuEeprom(HAL_EMUEE p)
{
//    DL_FLASHCTL_COMMAND_STATUS FlashAPIState;
    Fapi_StatusType  FlashAPIState;

    switch(p->sPG.fsm) {
    case _PREPARE_HEADER_INFORMATION:
        p->u16RamCount = 0;
        p->regHeader.info.start = p->regHeader.info.next;
        p->sPG.fsm = _SCAN_VALID_DATA_IN_RAM;

        break;

    case _SCAN_VALID_DATA_IN_RAM:
        if(EMU_SIZE_OF_EEPROM > p->u16RamCount) {
            // Scan from 0 to EMU_SIZE_OF_EEPROM
            if(0xFF != p->u16RAM[p->u16RamCount]) {
                FLASH_WORD * p64 = 0;
                uint32_t *p32 = 0;
                p->u32OddEven = p->regHeader.info.next % BYTES_OF_FLASH_WORD;
                p->u32BoundaryAddress = p->regHeader.info.next - p->u32OddEven;
                p64 = (FLASH_WORD *)p->u32BoundaryAddress;
                if(p->u32OddEven) {
                    // Recording a byte of odd address.
                    p->regData64.info.hi.info.idno = p->u16RamCount;
                    p->regData64.info.hi.info.databyte = p->u16RAM[p->u16RamCount];
                    p->regData64.info.lo.all = 0xFFFFFFFF;
                    p32 = &p64->u32.Hi;
                }
                else {
                    // Recording a byte of even address.
                    p->regData64.info.lo.info.idno = p->u16RamCount;
                    p->regData64.info.lo.info.databyte = p->u16RAM[p->u16RamCount];
                    p->regData64.info.hi.all = 0xFFFFFFFF;
                    p32 = &p64->u32.Lo;
                }

                // Check the content in Flash whether is empty.
                if(0xFFFFFFFF != *p32) {
                   p->sPG.fsm = _ERASE_DATA_SECTION;

                }
                else {
                    p->sPG.fsm = _PROGRAM_VALID_DATA64_TO_FLASH;
                }
            }
            p->u16RamCount++;
        }
        else {
            p->sPG.fsm = _RECORD_VALID_DATA_TO_HEADER;
        }
        break;

    case _PROGRAM_VALID_DATA64_TO_FLASH:

        FlashAPIState = Fapi_issueProgrammingCommand((uint32 *)p->u32BoundaryAddress, (uint16 *)&p->regData64.block.u64, 4,0,0,Fapi_AutoEccGeneration);
        p->regHeader.info.next += 4;

        if(EMU_END_OF_FLASH <= p->regHeader.info.next) {
            // If over the range of emulation, then need to roll over the data address.
            p->regHeader.info.next -= EMU_SIZE_OF_DATA;
        }
        p->sPG.fsm = _SCAN_VALID_DATA_IN_RAM;
        break;

    case _ERASE_DATA_SECTION:
        p->u32EraseAddress = (uint32_t)(getAddressSection(p->u32BoundaryAddress) * EMU_SIZE_OF_SECTOR);
        FlashAPIState =  Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector, (uint32 *)p->u32EraseAddress);

        if (Fapi_Error_Fail == FlashAPIState) {
            p->sPG.fsm |= _MASK_ERROR_FOR_PROG_EEPROM;
        }
        else {
            p->sPG.fsm = _PROGRAM_VALID_DATA64_TO_FLASH;

        }
        break;

    case _RECORD_VALID_DATA_TO_HEADER:
        if(63 < p->u16HeaderIndex) {
            // Over the section of header, need to format this section, restart from one, remark header index by 0xFFFF,FFFF,FFFF,FFFE.
            p->sPG.fsm = _ERASE_HEADER_SECTION;
        }
        else {
            // Get the address of next package of header.
            p->u32HeaderAddress = (uint32_t)(EMU_START_OF_HEADER + (p->u16HeaderIndex + 1) * BYTES_OF_FLASH_WORD);
            // Save the data information into the section of header about start, stop of data and this package of checksum.
            FlashAPIState = Fapi_issueProgrammingCommand((uint32 *)p->u32BoundaryAddress, (uint16 *)&p->regHeader.block.u64 ,4,0,0,Fapi_AutoEccGeneration);

            if (Fapi_Error_Fail == FlashAPIState) {
                p->sPG.fsm |= _MASK_ERROR_FOR_PROG_EEPROM;
            }
            else {
                p->sPG.fsm = _REMARK_HEADER_INDEX;
            }
        }
        break;

    case _REMARK_HEADER_INDEX:
        clearBit(&p->HeaderSectionMark.all[0] ,p->u16HeaderIndex++);
        FlashAPIState = Fapi_issueProgrammingCommand((uint32 *)p->u32BoundaryAddress, (uint16 *)p->HeaderSectionMark.all[0],4,0,0,Fapi_AutoEccGeneration);
        if (Fapi_Error_Fail == FlashAPIState) {
            p->sPG.fsm |= _MASK_ERROR_FOR_PROG_EEPROM;
        }
        else {
            p->sPG.fsm = _END_OF_PROGRAM_EMU_EEPROM;
        }
        break;

    case _ERASE_HEADER_SECTION:
        FlashAPIState = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,(uint32 *) p->u32EraseAddress);
        if (Fapi_Error_Fail == FlashAPIState) {
            p->sPG.fsm |= _MASK_ERROR_FOR_PROG_EEPROM;
        }
        else {
            p->u16HeaderIndex = 0;
            p->HeaderSectionMark.u64 = 0xFFFFFFFFFFFFFFFF;
            p->sPG.fsm = _RECORD_VALID_DATA_TO_HEADER;
        }
        break;

    case _END_OF_PROGRAM_EMU_EEPROM:

        p->sPG.fsm = _PREPARE_HEADER_INFORMATION;
        SWTO_EE(_FREE_EMU_EEPROM);
        break;

    default:
        break;

    }
}



void execEmuEeprom(void)
{
    HAL_EMUEE p = &stEmuEE;

    switch(p->fgEmuEE) {
    case _INIT_EMU_EEPROM:
        initEmuEeprom(p);
        break;

    case _CALL_BACK_EMU_EEPROM:
        callbackFromFlash(p);
        break;

    case _FREE_EMU_EEPROM:

        break;


    case _PROGRAM_EMU_EEPROM:
        progEmuEeprom(p);
        break;

    case _VERIFY_EMU_EEPORM:
        varifyFlashByRAM(p);
        break;



    default:
        SET_EE(_MASK_EMU_EEPROM_ERROR);
        break;
    }
}

