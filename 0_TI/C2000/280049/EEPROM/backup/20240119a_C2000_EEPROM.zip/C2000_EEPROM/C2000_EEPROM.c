// initAPI�n���?
//
// Included Files
//

#include "Common.h"
#include "emu_eeprom.h"
#include "tst.h"



void taskT_100msec(void * s)

{
    GPIO_togglePin(myBoardLED0_GPIO);
}

typedef struct _ST_TIMETASK
{
    void (*fn) (void * s);
    uint32_t cnt;
    uint32_t max;
} ST_TIMETASK;

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = {
        {taskT_100msec,      0,  T_100MS},
        {0, 0, 0}
};

bool scanTimeTask(ST_TIMETASK *t, void *s)
{
    uint32_t u32Cnt;
    uint32_t delta_t;

    u32Cnt = SW_TIMER - (uint32_t) CPUTimer_getTimerCount(SWTIMER_BASE);

    if(t->cnt > u32Cnt) {
        delta_t = u32Cnt + SW_TIMER - t->cnt;
    }
    else {
        delta_t = u32Cnt - t->cnt;
    }

    if(delta_t >= t->max) {
        t->fn(s);
        t->cnt = u32Cnt;
        return true;
    }
    else {
        return false;
    }
}
//
// Main
//
void main(void)
{
	
    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Configure ePWM1, ePWM2, and TZ GPIOs/Modules
    //
    Board_init();

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 100);
    Fapi_setActiveFlashBank(Fapi_FlashBank0);

    //
    // IDLE loop. Just sit and loop forever (optional):
    //
    for(;;)
    {
        scanTimeTask(&time_task[id_ttask++], (void *)0);
        if(0 == time_task[id_ttask].fn)
        {
            id_ttask = 0;
        }

        execEmuEeprom();
        tstEmuEeprom();
    }
}
//
// End of File
//
