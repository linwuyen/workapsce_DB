/*
 * tst.h
 *
 *  Created on: 2023�~5��24��
 *      Author: cody_chen
 */

#ifndef TST_H_
#define TST_H_


extern void tstEmuEeprom(void);
extern void Example_CallFlashAPI(void);

#endif /* TST_H_ */
