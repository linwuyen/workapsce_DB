/*
 * tstBlock.c
 *
 *  Created on: 2023¦~5¤ë24¤é
 *      Author: cody_chen
 */

#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"

typedef enum {
    _INIT_TEST_BLOCK_RAM = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _VARIFY_BLOCK_DATA,
    _FREE_TEST_EEPROM,
} TEST_EVENT;

typedef struct{
    TEST_EVENT tstfsm;
    int beginAddress ;
    int ptrAddress ;
    int endAddress ;
    int procBytes ;
    int testBytes ;
}ST_TEST;

ST_TEST p_TEST;
//TEST_EVENT tstfsm = _FREE_TEST_EEPROM;

typedef enum {
    _EV_GET_ADDRESS = 0,
    _EV_UPLOAD_DATA,
    _EV_END_OF_UPLOAD,
    _EV_END_OF_INIT_TESTBLOCK
}REG_INIT_TSTBLOCK;
typedef REG_INIT_TSTBLOCK REG_RST_TSTBLOCK;


typedef enum{
    _FLASH_NO_ACTION = 0x0000,
    _FLASH_INITIAL   = (0x0001<<0),
    _FLASH_ERASE     = (0x0001<<1),
    _FLASH_PROGRAM   = (0x0001<<2),
    _FLASH_TEST      = (0x0001<<3),
    _OUT_OF_FLASH_ACTION
}FSM_FACTION;

typedef struct{
    FSM_FACTION fsm;
    Fapi_StatusType  oReturnCheck;
    Fapi_FlashStatusType  oFlashStatus;
    Fapi_FlashStatusWordType  oFlashStatusWord;
    Fapi_FlashProgrammingCommandsType evType;

    uint32_t u32Index;
    uint32_t u32Offset;
    uint16_t u16Ram[32];
    uint16_t u16Length;
}ST_FLASH;

#pragma SET_CODE_SECTION(".TI.ramfunc")

ST_FLASH sFlash = {
         .fsm = _FLASH_INITIAL,
         .u16Ram = {0x1234,0x2345,0x3456,0x4567,0x5678,0x6789,0x9876,0x8765,
                    0x1111,0x2222,0x3333,0x4444,0x5555,0x6666,0x7777,0x8888,
                    0xFFFF,0xFFFF,0xFFFF,0xFFFE,0xFFFF,0xFFFF,0xFFFF,0xFFFF,
                    0x1111,0x2222,0x3333,0x4444,0x5555,0x6666,0x7777,0x8888
         },
         .u16Length = 4,
         .evType = Fapi_DataOnly
};

void Example_Error(Fapi_StatusType status)
{
    //  Error code will be in the status parameter
        __asm("    ESTOP0");
}

void programFlash(ST_FLASH *v)
{
    v->oReturnCheck = Fapi_issueProgrammingCommand((uint32 *)v->u32Index, &v->u16Ram[v->u32Offset], v->u16Length,
                                                                             0, 0, v->evType);

    // Wait until the Flash program operation is over
    while(Fapi_checkFsmForReady() == Fapi_Status_FsmBusy);

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }
}

void eraseFlash(ST_FLASH *v)
{
    // Erase Flash Bank0 sector6
    v->oReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,(uint32 *)EMU_START_OF_FLASH);

    // Wait until FSM is done with erase sector operation
    while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }
}

void initFlash(ST_FLASH *v)
{
    // This function must also be called whenever System frequency or RWAIT is changed.
    v->oReturnCheck = Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 100);

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }
    v->oReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }

    v->u32Index = EMU_START_OF_FLASH;
    v->fsm = _FLASH_NO_ACTION;
}

REG_INIT_TSTBLOCK regInitTstBlock = _EV_GET_ADDRESS;

void initBlockRam(void)
{
        switch(regInitTstBlock)
        {
            case _EV_GET_ADDRESS:
                endAddress = beginAddress + testBytes;
                ptrAddress = beginAddress;
                procBytes = 0;
                regInitTstBlock = _EV_UPLOAD_DATA;
            break;

            case _EV_UPLOAD_DATA:
                if(procBytes < testBytes)
                {
                     writeEmuEeprom(ptrAddress, ptrAddress%0xFF);
                     ptrAddress++;
                     procBytes++;
                     ptrAddress&=0xFF;
                     if(EMU_SIZE_OF_SECTOR <= ptrAddress) ptrAddress -= EMU_SIZE_OF_SECTOR;
                }
                else
                {
                    ptrAddress = beginAddress;
                    regInitTstBlock = _EV_END_OF_UPLOAD;
                }
            break;

          case _EV_END_OF_UPLOAD:
                tstfsm = _FREE_TEST_EEPROM;
                regInitTstBlock = _EV_GET_ADDRESS;
            break;

            default:
            break;
        }
}


REG_RST_TSTBLOCK regRESTstBlock = _EV_GET_ADDRESS;

void resetBlockRam(void)
{
        switch(regRESTstBlock)
        {
            case _EV_GET_ADDRESS:
                endAddress = beginAddress + testBytes;
                ptrAddress = beginAddress;
                procBytes = 0;
                regRESTstBlock = _EV_UPLOAD_DATA;
            break;

          case _EV_UPLOAD_DATA:
              if(procBytes < testBytes)
              {
                     writeEmuEeprom(ptrAddress, 0xFF);
                     ptrAddress++;
                     procBytes++;
                     if(EMU_SIZE_OF_SECTOR <= ptrAddress) ptrAddress -= EMU_SIZE_OF_SECTOR;
              }
              else
              {
                    ptrAddress = beginAddress;
                    regRESTstBlock = _EV_END_OF_UPLOAD;
              }
            break;

          case _EV_END_OF_UPLOAD:
                tstfsm = _FREE_TEST_EEPROM;
                regRESTstBlock = _EV_GET_ADDRESS;
            break;

            default:

            break;
        }
}



void tstEmuEeprom(void)
{
   //   loopWriteBlock();
    switch(tstfsm) {
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
                tstfsm = _FREE_TEST_EEPROM;
        break;

    case _VARIFY_BLOCK_DATA:
        setVerifyEmuEeprom();
            tstfsm = _FREE_TEST_EEPROM;
        break;

    case _FREE_TEST_EEPROM:

    default:
        break;
    }
}

void Example_CallFlashAPI()
{
    ST_FLASH *v = &sFlash;
    while(1) {
        switch(v->fsm) {
        case _FLASH_INITIAL:
            initFlash(v);
            v->fsm = _FLASH_NO_ACTION;
            break;

        case _FLASH_ERASE:
            eraseFlash(v);
            v->fsm = _FLASH_NO_ACTION;
            break;

        case _FLASH_PROGRAM:
            programFlash(v);
            v->fsm = _FLASH_NO_ACTION;
            break;



        default:
            break;
        }


    }
}

