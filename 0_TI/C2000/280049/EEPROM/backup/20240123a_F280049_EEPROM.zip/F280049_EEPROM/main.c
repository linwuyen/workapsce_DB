
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"

#include "F021_F28004x_C28x.h"

uint16_t u16Dword = 4;
Fapi_FlashStatusType FlashStatus;
uint16 SW = 0;
uint32 u32StartAddress = 0x08F000;
uint16 pu16DataBuffer[]= {0x0901,0x0A02,0x0B03,0x0C04,0x0D05,0x0E06,0x0F07,0x0108};
uint16 pu16DataBufferARR[1024]= {};

typedef struct{
    uint16 a;
    uint16 b;
    uint16 c;
    uint16 d;
    uint16 e;
    uint16 f;
}pu16Data;

pu16Data pu16DataBufferstr = {
           .a=1,
           .b=2,
           .c=3,
           .d=4,
           .e=5,
           .f=6
};


#pragma SET_CODE_SECTION(".TI.ramfunc")
void testFlash()
{
    FlashStatus = Fapi_getFsmStatus();
    if (SW == 1)
    {
        Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector, (uint32 *)u32StartAddress);
        SW = 0;
    }
    else if (SW == 2)
    {
        FlashStatus = Fapi_issueProgrammingCommand((uint32*)u32StartAddress,(uint16 *)pu16DataBuffer,u16Dword,0,0,Fapi_DataOnly);
        SW = 0;
    }
    else if(SW == 3)
    {
        Fapi_issueProgrammingCommand((uint32*)u32StartAddress+8,(uint16 *)pu16DataBufferARR,8,0,0,Fapi_AutoEccGeneration);
        SW = 0;
    }
    else if(SW == 4)
    {
        Fapi_issueProgrammingCommand((uint32*)u32StartAddress+12,(uint16 *)&pu16DataBufferstr,8,0,0,Fapi_AutoEccGeneration);
        SW = 0;
    }
}
#pragma SET_CODE_SECTION()

// Main
//
void main(void)
{
	
    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Configure ePWM1, ePWM2, and TZ GPIOs/Modules
    //
    Board_init();

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    // Enter code here
    Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 100);
    Fapi_setActiveFlashBank(Fapi_FlashBank0);



    //
    // IDLE loop. Just sit and loop forever (optional):
    //
    for(;;)
    {
        testFlash();
    }
}

//
// End of File
//
