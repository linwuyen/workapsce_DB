/*
 * tstBlock.c
 *
 *  Created on: 2023¦~5¤ë24¤é
 *      Author: cody_chen
 */

#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"

typedef enum
{
    _INIT_TEST_BLOCK_RAM = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _VARIFY_BLOCK_DATA,
    _FREE_TEST_EEPROM
} TEST_EVENT;

typedef enum
{
    _EV_GET_ADDRESS = 0,
    _EV_UPLOAD_DATA,
    _EV_END_OF_UPLOAD,
    _EV_END_OF_INIT_TESTBLOCK
} REG_INIT_TSTBLOCK;

typedef struct
{
    REG_INIT_TSTBLOCK regInitTstBlock;
    TEST_EVENT tstfsm;
    int beginAddress;
    int ptrAddress;
    int endAddress;
    int procBytes;
    int testBytes;
} st_tst;

st_tst sttst = { .testBytes = EMU_KBYTES,
                 .regInitTstBlock = _EV_GET_ADDRESS,
                 .tstfsm = _FREE_TEST_EEPROM, };

typedef REG_INIT_TSTBLOCK REG_RST_TSTBLOCK;
typedef st_tst *HAL_sttst;
st_tst *p = &sttst;

void initBlockRam(void)
{
    switch (p->regInitTstBlock)
    {
        case _EV_GET_ADDRESS:
            p->endAddress = p->beginAddress + p->testBytes;
            p->ptrAddress = p->beginAddress;
            p->procBytes = 0;
            p->regInitTstBlock = _EV_UPLOAD_DATA;
        break;

        case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, p->ptrAddress % 0xFFFF);
            p->ptrAddress++;
            p->procBytes++;
            p->ptrAddress &= 0xFFFF;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            p->regInitTstBlock = _EV_END_OF_UPLOAD;
        }
        break;

        case _EV_END_OF_UPLOAD:
            p->tstfsm = _FREE_TEST_EEPROM;
            p->regInitTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}

REG_RST_TSTBLOCK regRESTstBlock = _EV_GET_ADDRESS;

void resetBlockRam(void)
{
    switch (regRESTstBlock)
    {
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;
        regRESTstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, 0xFFFF);
            p->ptrAddress++;
            p->procBytes++;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            regRESTstBlock = _EV_END_OF_UPLOAD;
        }

        break;

    case _EV_END_OF_UPLOAD:
        p->tstfsm = _FREE_TEST_EEPROM;
        regRESTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}


void tstEmuEeprom(void)
{
    //   loopWriteBlock();
    switch (p->tstfsm)
    {
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _VARIFY_BLOCK_DATA:
        setVerifyEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _FREE_TEST_EEPROM:
    default:

        break;
    }

}

