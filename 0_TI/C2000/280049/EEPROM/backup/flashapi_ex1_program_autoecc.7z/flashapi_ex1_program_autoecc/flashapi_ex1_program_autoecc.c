//
// Included Files
//
#include "driverlib.h"
#include "device.h"

//
// Include Flash API include file
//
#include "F021_F28004x_C28x.h"

//
// Include Flash API example header file
//
#include "flash_programming_f28004x.h"


//
// Defines
//

//
// Globals
//

////Data Buffers used for program operation using the flash API program function
//#pragma  DATA_SECTION(Buffer,"DataBufferSection");
//uint16   Buffer[WORDS_IN_FLASH_BUFFER + 1];
//uint32   *Buffer32 = (uint32 *)Buffer;


//
// Prototype of the functions used in this example
//
void Example_Error(Fapi_StatusType status);
void Example_Done(void);
void Example_CallFlashAPI(void);
void FMSTAT_Fail(void);

//
// Main
//
void main(void)
{

	//
    // Initialize device clock and peripherals
	// Copy the Flash initialization code from Flash to RAM
    // Copy the Flash API from Flash to RAM
    // Configure Flash wait-states, fall back power mode, performance features and ECC
    //
    Device_init();

    //
    // Initialize GPIO
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    //
    EINT;
    ERTM;

    //
    //  Notice that Flash API functions are mapped to RAM for execution in this example.
    //  In F28004x devices that have two banks, Flash API functions may be executed from
    //  one bank to perform Flash erase and program operations on the other bank.
    //  Flash API functions should not be executed from the same bank on which erase/
    //  program operations are in progress.
    //  Also, note that there should not be any access to the Flash bank on which erase/
    //  program operations are in progress.  Hence below function is mapped to RAM for
    //  execution.
    //
    Example_CallFlashAPI();

}

typedef enum {
    _FLASH_NO_ACTION = 0x0000,
    _FLASH_INITIAL   = (0x0001<<0),
    _FLASH_ERASE     = (0x0001<<1),
    _FLASH_PROGRAM   = (0x0001<<2),
    _OUT_OF_FLASH_ACTION
}FSM_FACTION;


typedef struct {
    FSM_FACTION fsm;
    Fapi_StatusType  oReturnCheck;
    Fapi_FlashStatusType  oFlashStatus;
    Fapi_FlashStatusWordType  oFlashStatusWord;

    uint32_t u32Index;
    uint32_t u32Offset;
    uint16_t u16Ram[32];
    uint16_t u16Length;

    Fapi_FlashProgrammingCommandsType evType;

}ST_FLASH;


//*****************************************************************************
//  Example_CallFlashAPI
//
//  This function will interface to the flash API.
//  Flash API functions used in this function are executed from RAM in this
//  example.
//*****************************************************************************
#pragma SET_CODE_SECTION(".TI.ramfunc")

ST_FLASH sFlash = {
         .fsm = _FLASH_INITIAL,
         .u16Ram = {0x1234,0x2345,0x3456,0x4567,0x5678,0x6789,0x9876,0x8765,
                    0x1111,0x2222,0x3333,0x4444,0x5555,0x6666,0x7777,0x8888,
                    0xFFFF,0xFFFF,0xFFFF,0xFFFE,0xFFFF,0xFFFF,0xFFFF,0xFFFF,
                    0x1111,0x2222,0x3333,0x4444,0x5555,0x6666,0x7777,0x8888
         },
         .u16Length = 4,
         .evType = Fapi_DataOnly
};

void programFlash(ST_FLASH *v)
{
    // A data buffer of max 8 16-bit words can be supplied to the program function.
    // Each word is programmed until the whole buffer is programmed or a
    // problem is found. However to program a buffer that has more than 8
    // words, program function can be called in a loop to program 8 words for
    // each loop iteration until the whole buffer is programmed.
    //
    // Remember that the main array flash programming must be aligned to
    // 64-bit address boundaries and each 64 bit word may only be programmed
    // once per write/erase cycle.  Meaning the length of the data buffer
    // (3rd parameter for Fapi_issueProgrammingCommand() function) passed
    // to the program function can only be either 4 or 8.
    //
    // Program data in Flash using "AutoEccGeneration" option.
    // When AutoEccGeneration opton is used, Flash API calculates ECC for the given
    // 64-bit data and programs it along with the 64-bit main array data.
    // Note that any unprovided data with in a 64-bit data slice
    // will be assumed as 1s for calculating ECC and will be programmed.
    //
    // Note that data buffer (Buffer) is aligned on 64-bit boundary for verify reasons.
    v->oReturnCheck = Fapi_issueProgrammingCommand((uint32 *)v->u32Index, &v->u16Ram[v->u32Offset], v->u16Length,
                                                                             0, 0, v->evType);

    // Wait until the Flash program operation is over
    while(Fapi_checkFsmForReady() == Fapi_Status_FsmBusy);

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }
}

void eraseFlash(ST_FLASH *v)
{
    // Erase Flash Bank0 sector6
    v->oReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,
                                        (uint32 *)Bzero_Sector6_start);

    // Wait until FSM is done with erase sector operation
    while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }
}

void initFlash(ST_FLASH *v)
{
    //
    // Note that wait-states are already configured in the Device_init().
    // However, if INTOSC is used as the clock source and
    // if the CPUCLK falls in the range (97,100] (check other ranges given in DS),
    // then an extra wait state is needed for FSM operations (erase/program).
    // Hence, below function call should be uncommented in case INTOSC is used.
    // At 100MHz, execution wait-states for external oscillator is 4 and hence
    // in this example, a wait-state of 5 is used below.
    // This example is using external oscillator as the clock source and hence
    // below is commented.
    //
    // This wait-state setting impacts both Flash banks. Applications which
    // perform simultaneous READ/FETCH of one bank and PROGRAM or ERASE of the other
    // bank must use the higher RWAIT setting during the PROGRAM or ERASE operation. OR
    // use a clock source or frequency with a common wait state setting
    // Example: Use 97MHz instead of 100MHz if it is acceptable for the application.
    //
    // In case, if user application increments wait-state before using API,
    // then remember to revert back to the original wait-state after the API usage
    // to avoid extra wait-state during application execution from Flash.
    //
    //
    // Flash_setWaitstates(FLASH0CTRL_BASE, 5);

    // Initialize the Flash API by providing the Flash register base address
    // and operating frequency.
    // This function is required to initialize the Flash API based on System frequency
    // before any other Flash API operation can be performed.
    // This function must also be called whenever System frequency or RWAIT is changed.
    v->oReturnCheck = Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 100);

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }

    // Initialize the Flash banks and FMC for erase and program operations.
    // Fapi_setActiveFlashBank() function sets the Flash banks and FMC for further
    // Flash operations to be performed on the banks.
    // Note: It does not matter which bank is passed as the parameter to initialize.
    //       Both Banks and FMC get initialized with one function call unlike F2837xS.
    //       Hence there is no need to execute Fapi_setActiveFlashBank() for each bank.
    //       Executing for one bank is enough.
    v->oReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);

    if(v->oReturnCheck != Fapi_Status_Success)
    {
        // Check Flash API documentation for possible errors
        Example_Error(v->oReturnCheck);
    }

    v->u32Index = Bzero_Sector6_start;


    v->fsm = _FLASH_NO_ACTION;
}


void Example_CallFlashAPI()
{
    ST_FLASH *v = &sFlash;
    while(1) {
        switch(v->fsm) {
        case _FLASH_INITIAL:
            initFlash(v);
            v->fsm = _FLASH_NO_ACTION;
            break;

        case _FLASH_ERASE:
            eraseFlash(v);
            v->fsm = _FLASH_NO_ACTION;
            break;

        case _FLASH_PROGRAM:
            programFlash(v);
            v->fsm = _FLASH_NO_ACTION;
            break;

        default:
            break;
        }


    }
}

//******************************************************************************
// For this example, just stop here if an API error is found
//******************************************************************************
void Example_Error(Fapi_StatusType status)
{
    //  Error code will be in the status parameter
        __asm("    ESTOP0");
}

//******************************************************************************
//  For this example, once we are done just stop here
//******************************************************************************
void Example_Done(void)
{
    __asm("    ESTOP0");
}

//******************************************************************************
// For this example, just stop here if FMSTAT fail occurs
//******************************************************************************
void FMSTAT_Fail(void)
{
    //  Error code will be in the status parameter
        __asm("    ESTOP0");
}


#pragma SET_CODE_SECTION()

//
// End of File
//
