/*
 * tstBlock.c
 *
 *  Created on: 2023¦~5¤ë24¤é
 *      Author: cody_chen
 */

#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"



typedef enum
{
    _INIT_TEST_BLOCK_RAM = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _VARIFY_BLOCK_DATA,
    _FREE_TEST_EEPROM
} TEST_EVENT;

typedef enum
{
    _EV_GET_ADDRESS = 0,
    _EV_UPLOAD_DATA,
    _EV_END_OF_UPLOAD,
    _EV_END_OF_INIT_TESTBLOCK
} REG_INIT_TSTBLOCK;
typedef REG_INIT_TSTBLOCK REG_RST_TSTBLOCK;
REG_RST_TSTBLOCK regRESTstBlock = _EV_GET_ADDRESS;

typedef struct
{
    REG_INIT_TSTBLOCK regInitTstBlock;
    TEST_EVENT tstfsm;

    uint16_t WriteData[EMU_KBYTES];
    uint16_t dataIndex;

    uint16_t beginAddress;
    uint16_t ptrAddress;
    uint16_t endAddress;
    uint16_t procBytes;
    uint16_t testBytes;
} ST_tst;

ST_tst TEST_ST =
{
                 .testBytes = EMU_KBYTES,
                 .regInitTstBlock = _EV_GET_ADDRESS,
                 .tstfsm = _FREE_TEST_EEPROM,
                 .WriteData = {0x12,0x25,0x4567,0x5678,0x6789,0x9876,0x8765,0x4444,0x5555,0x6666}
};
ST_tst *p = &TEST_ST;

void initBlockRam(void)
{
    switch (p->regInitTstBlock)
    {
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;
        p->regInitTstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, p->ptrAddress % 0xFFFFFFFF);
            p->ptrAddress++;
            p->procBytes++;
            p->ptrAddress &= 0xFFFF;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            p->regInitTstBlock = _EV_END_OF_UPLOAD;
        }
        break;

    case _EV_END_OF_UPLOAD:
        p->tstfsm = _FREE_TEST_EEPROM;
        p->regInitTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}

void resetBlockRam(void)
{
    switch (regRESTstBlock)
    {
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;
        regRESTstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, 0xFFFF);
            p->ptrAddress++;
            p->procBytes++;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            regRESTstBlock = _EV_END_OF_UPLOAD;
        }
        break;

    case _EV_END_OF_UPLOAD:
        p->tstfsm = _FREE_TEST_EEPROM;
        regRESTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}

void tstEmuEeprom(void)
{
    //   loopWriteBlock();
    switch (p->tstfsm)
    {
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _VARIFY_BLOCK_DATA:
        setVerifyEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;



    case _FREE_TEST_EEPROM:

    default:
        break;
    }
}

//==============================================================

typedef enum
{
    _EV_IDLE              = (0x0000),
    _EV_RESET             = (0x0002),
    _EV_WRITE             = (0x0003),
    _EV_callback          = (0x0004),
    _EV_FLASH_emuEEPORM     = (0x0006),
    _MASK_EMU_EEPROM_ERROR  = (0x8000)
} FUN_State;


typedef struct
{
    FUN_State Function_FSM;
} ST_FUN;

ST_FUN Function_St =
{
      .Function_FSM = _EV_IDLE,
};

ST_FUN *v = &Function_St;


uint16_t write_RAM()
{
    switch (p->regInitTstBlock)
      {
      case _EV_GET_ADDRESS:
          p->endAddress = p->beginAddress + p->testBytes;
          p->ptrAddress = p->beginAddress;
          p->procBytes = 0;
          p->regInitTstBlock = _EV_UPLOAD_DATA;
          break;

      case _EV_UPLOAD_DATA:
          if (p->procBytes < p->testBytes)
          {
              writeEmuEeprom(p->ptrAddress, p->WriteData[p->dataIndex]);
              p->ptrAddress++;
              p->procBytes++;
              p->dataIndex = (p->dataIndex + 1) % EMU_KBYTES;
              p->ptrAddress &= 0xFFFF;
              if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                  p->ptrAddress -= EMU_SIZE_OF_SECTOR;
          }
          else
          {
              p->ptrAddress = p->beginAddress;
              p->regInitTstBlock = _EV_END_OF_UPLOAD;
          }
          break;

      case _EV_END_OF_UPLOAD:
          p->tstfsm = _FREE_TEST_EEPROM;
          p->regInitTstBlock = _EV_GET_ADDRESS;
          break;

      default:
          break;
      }
    return 0;
};

uint16_t *ptr;
uint16_t callback[EMU_KBYTES];
uint16_t u16addr;
uint32_t COUTER;
uint16_t SW_FLAG;
uint16_t callback_RAM ()
{
    ptr  = readEmuEeprom(u16addr);
        int i;
        for ( i= 0; i < EMU_KBYTES; ++i)
        {
            callback[i] = ptr[i];
        }
    return 0;
}

void TstFunction(void)
{
    switch (v->Function_FSM)
    {
    case _EV_IDLE:
        if(SW_FLAG == true){
            COUTER--;
            if(COUTER == 0){
            v->Function_FSM = _EV_FLASH_emuEEPORM;
            SW_FLAG = false;
            }
        }
        break;

    case _EV_RESET:
        resetBlockRam();
        break;

    case _EV_WRITE:
        write_RAM();
        SW_FLAG = true;
        COUTER = 9999999;
        break;

    case _EV_callback:
        callback_RAM();
        break;

    case _EV_FLASH_emuEEPORM:
        setProgramEmuEeprom();
        v->Function_FSM = _EV_IDLE;
        break;

    case _MASK_EMU_EEPROM_ERROR:

    default:
        break;
    }
}
