/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

#define GPIO_PIN_EPWM1_A 0
#define GPIO_PIN_EPWM1_B 1
#define GPIO_PIN_EPWM2_A 2
#define GPIO_PIN_EPWM5_B 9
#define GPIO_PIN_EPWM5_A 8
#define GPIO_PIN_I2CA_SDA 26
#define GPIO_PIN_I2CA_SCL 27
#define GPIO_PIN_OUTPUTXBAR1 58
#define GPIO_PIN_SCIA_RX 28
#define GPIO_PIN_SCIA_TX 29
#define GPIO_PIN_SPIA_SIMO 16
#define GPIO_PIN_SPIA_SOMI 17
#define GPIO_PIN_SPIA_CLK 56
#define GPIO_PIN_SPIA_STE 57
#define GPIO_PIN_SPIB_SIMO 30
#define GPIO_PIN_SPIB_SOMI 31
#define GPIO_PIN_SPIB_CLK 14
#define GPIO_PIN_SPIB_STE 15

#define ADCA_BASE_BASE ADCA_BASE
#define ADCA_BASE_RESULT_BASE ADCARESULT_BASE
#define ADCB_BASE_BASE ADCB_BASE
#define ADCB_BASE_RESULT_BASE ADCBRESULT_BASE
#define ADCC_BASE_BASE ADCC_BASE
#define ADCC_BASE_RESULT_BASE ADCCRESULT_BASE

#define PCMC_BASE CMPSS1_BASE
#define OVP_SENSE_BASE CMPSS2_BASE
#define OCP_SENSE_BASE CMPSS7_BASE

#define SWTIRMER_BASE CPUTIMER2_BASE

#define DEBUG_DAC_BASE DACA_BASE
#define IL_COMMAND_BASE DACB_BASE

#define PWM_PEAK_CURR_BASE EPWM1_BASE
#define PWM_FAN_BASE EPWM2_BASE
#define PWM_VIN_COMMAND_BASE EPWM5_BASE
#define PWM_BLEEDER_BASE EPWM5_BASE

#define FAULT_LED 39
#define CV_LED 7
#define CC_LED 40
#define AC_SENSE1 13
#define AC_SENSE2 12
#define AC_SENSE3 11
#define PS 25
#define FAN_SENSE 33
#define SPIB_CS_ICMD 59
#define DEBUG_IO3 10
#define NB0_DIO1 4
#define NB1_DIO2 3

#define I2CA_MASTER_BASE I2CA_BASE
#define I2CA_MASTER_BITRATE 400000
#define I2CA_MASTER_SLAVE_ADDRESS 80
#define I2CA_MASTER_OWN_SLAVE_ADDRESS 0


// Interrupt Setings for INT_ADCA_BASE_1
#define INT_ADCA_BASE_1 INT_ADCA1
#define INT_ADCA_BASE_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_ADCA_BASE_1_ISR(void);


#define DEBUG_SCI_BASE SCIA_BASE
#define DEBUG_SCI_BAUDRATE 115200
#define DEBUG_SCI_CONFIG_WLEN SCI_CONFIG_WLEN_8
#define DEBUG_SCI_CONFIG_STOP SCI_CONFIG_STOP_ONE
#define DEBUG_SCI_CONFIG_PAR SCI_CONFIG_PAR_EVEN

#define SPIA_SLAVE_BASE SPIA_BASE
#define SPIA_SLAVE_BITRATE 1250000
#define SPIB_MASTER_BASE SPIB_BASE
#define SPIB_MASTER_BITRATE 1250000

void	Board_init();
void	ADC_init();
void	ASYSCTL_init();
void	CMPSS_init();
void	CPUTIMER_init();
void	DAC_init();
void	EPWM_init();
void	EPWMXBAR_init();
void	GPIO_init();
void	I2C_init();
void	INPUTXBAR_init();
void	INTERRUPT_init();
void	OUTPUTXBAR_init();
void	SCI_init();
void	SPI_init();
void	SYNC_init();
void	PinMux_init();

#endif  // end of BOARD_H definition
