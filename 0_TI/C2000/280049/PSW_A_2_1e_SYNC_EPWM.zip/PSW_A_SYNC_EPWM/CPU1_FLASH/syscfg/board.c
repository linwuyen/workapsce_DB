/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"

void Board_init()
{
	EALLOW;

	PinMux_init();
	INPUTXBAR_init();
	SYNC_init();
	ASYSCTL_init();
	ADC_init();
	CMPSS_init();
	CPUTIMER_init();
	DAC_init();
	EPWM_init();
	EPWMXBAR_init();
	GPIO_init();
	I2C_init();
	OUTPUTXBAR_init();
	SCI_init();
	SPI_init();
	INTERRUPT_init();

	EDIS;
}

void PinMux_init()
{
	//
	// EPWM1 -> PWM_PEAK_CURR Pinmux
	//
	GPIO_setPinConfig(GPIO_0_EPWM1_A);
	GPIO_setPinConfig(GPIO_1_EPWM1_B);
	//
	// EPWM2 -> PWM_FAN Pinmux
	//
	GPIO_setPinConfig(GPIO_2_EPWM2_A);
	//
	// EPWM5 -> PWM_VIN_COMMAND Pinmux
	//
	GPIO_setPinConfig(GPIO_9_EPWM5_B);
	//
	// EPWM5 -> PWM_BLEEDER Pinmux
	//
	GPIO_setPinConfig(GPIO_8_EPWM5_A);
	// GPIO39 -> FAULT_LED Pinmux
	GPIO_setPinConfig(GPIO_39_GPIO39);
	// GPIO7 -> CV_LED Pinmux
	GPIO_setPinConfig(GPIO_7_GPIO7);
	// GPIO40 -> CC_LED Pinmux
	GPIO_setPinConfig(GPIO_40_GPIO40);
	// GPIO13 -> AC_SENSE1 Pinmux
	GPIO_setPinConfig(GPIO_13_GPIO13);
	// GPIO12 -> AC_SENSE2 Pinmux
	GPIO_setPinConfig(GPIO_12_GPIO12);
	// GPIO11 -> AC_SENSE3 Pinmux
	GPIO_setPinConfig(GPIO_11_GPIO11);
	// GPIO25 -> PS Pinmux
	GPIO_setPinConfig(GPIO_25_GPIO25);
	// GPIO33 -> FAN_SENSE Pinmux
	GPIO_setPinConfig(GPIO_33_GPIO33);
	// GPIO59 -> SPIB_CS_ICMD Pinmux
	GPIO_setPinConfig(GPIO_59_GPIO59);
	// GPIO10 -> DEBUG_IO3 Pinmux
	GPIO_setPinConfig(GPIO_10_GPIO10);
	// GPIO4 -> NB0_DIO1 Pinmux
	GPIO_setPinConfig(GPIO_4_GPIO4);
	// GPIO3 -> NB1_DIO2 Pinmux
	GPIO_setPinConfig(GPIO_3_GPIO3);
	//
	// I2CA -> I2CA_MASTER Pinmux
	//
	GPIO_setPinConfig(GPIO_26_I2CA_SDA);
	GPIO_setPadConfig(26, GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(26, GPIO_QUAL_ASYNC);
	GPIO_setPinConfig(GPIO_27_I2CA_SCL);
	GPIO_setPadConfig(27, GPIO_PIN_TYPE_PULLUP);
	GPIO_setQualificationMode(27, GPIO_QUAL_ASYNC);
	//
	// OUTPUTXBAR1 -> PCMC_OUTPUTXBAR0 Pinmux
	//
	GPIO_setPinConfig(GPIO_58_OUTPUTXBAR1);
	//
	// SCIA -> DEBUG_SCI Pinmux
	//
	GPIO_setPinConfig(GPIO_28_SCIA_RX);
	GPIO_setPinConfig(GPIO_29_SCIA_TX);
	//
	// SPIA -> SPIA_SLAVE Pinmux
	//
	GPIO_setPinConfig(GPIO_16_SPIA_SIMO);
	GPIO_setPinConfig(GPIO_17_SPIA_SOMI);
	GPIO_setPinConfig(GPIO_56_SPIA_CLK);
	GPIO_setPinConfig(GPIO_57_SPIA_STE);
	//
	// SPIB -> SPIB_MASTER Pinmux
	//
	GPIO_setPinConfig(GPIO_30_SPIB_SIMO);
	GPIO_setPinConfig(GPIO_31_SPIB_SOMI);
	GPIO_setPinConfig(GPIO_14_SPIB_CLK);
	GPIO_setPinConfig(GPIO_15_SPIB_STE);

}

void ADC_init(){
	//ADCA_BASE initialization

	// ADC Initialization: Write ADC configurations and power up the ADC
	// Configures the ADC module's offset trim
	ADC_setOffsetTrimAll(ADC_REFERENCE_INTERNAL,ADC_REFERENCE_3_3V);
	// Configures the analog-to-digital converter module prescaler.
	ADC_setPrescaler(ADCA_BASE_BASE, ADC_CLK_DIV_1_0);
	// Sets the timing of the end-of-conversion pulse
	ADC_setInterruptPulseMode(ADCA_BASE_BASE, ADC_PULSE_END_OF_CONV);
	// Powers up the analog-to-digital converter core.
	ADC_enableConverter(ADCA_BASE_BASE);
	// Delay for 1ms to allow ADC time to power up
	DEVICE_DELAY_US(5000);

	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	// Disables SOC burst mode.
	ADC_disableBurstMode(ADCA_BASE_BASE);
	// Sets the priority mode of the SOCs.
	ADC_setSOCPriority(ADCA_BASE_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	// Start of Conversion 0 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN10
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCA_BASE_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN10, 1U);
	ADC_setInterruptSOCTrigger(ADCA_BASE_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 1 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN4
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCA_BASE_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN4, 1U);
	ADC_setInterruptSOCTrigger(ADCA_BASE_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 2 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCA_BASE_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN2, 1U);
	ADC_setInterruptSOCTrigger(ADCA_BASE_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 3 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCA_BASE_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN3, 1U);
	ADC_setInterruptSOCTrigger(ADCA_BASE_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 4 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCA_BASE_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN5, 1U);
	ADC_setInterruptSOCTrigger(ADCA_BASE_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);
	// ADC Interrupt 1 Configuration
	// 		SOC/EOC number	: 4
	// 		Interrupt Source: enabled
	// 		Continuous Mode	: disabled
	ADC_setInterruptSource(ADCA_BASE_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER4);
	ADC_enableInterrupt(ADCA_BASE_BASE, ADC_INT_NUMBER1);
	ADC_clearInterruptStatus(ADCA_BASE_BASE, ADC_INT_NUMBER1);
	ADC_disableContinuousMode(ADCA_BASE_BASE, ADC_INT_NUMBER1);

	//ADCB_BASE initialization

	// ADC Initialization: Write ADC configurations and power up the ADC
	// Configures the ADC module's offset trim
	ADC_setOffsetTrimAll(ADC_REFERENCE_INTERNAL,ADC_REFERENCE_3_3V);
	// Configures the analog-to-digital converter module prescaler.
	ADC_setPrescaler(ADCB_BASE_BASE, ADC_CLK_DIV_1_0);
	// Sets the timing of the end-of-conversion pulse
	ADC_setInterruptPulseMode(ADCB_BASE_BASE, ADC_PULSE_END_OF_CONV);
	// Powers up the analog-to-digital converter core.
	ADC_enableConverter(ADCB_BASE_BASE);
	// Delay for 1ms to allow ADC time to power up
	DEVICE_DELAY_US(5000);

	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	// Disables SOC burst mode.
	ADC_disableBurstMode(ADCB_BASE_BASE);
	// Sets the priority mode of the SOCs.
	ADC_setSOCPriority(ADCB_BASE_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	// Start of Conversion 0 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN8
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCB_BASE_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN8, 1U);
	ADC_setInterruptSOCTrigger(ADCB_BASE_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 1 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCB_BASE_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN1, 1U);
	ADC_setInterruptSOCTrigger(ADCB_BASE_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 2 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCB_BASE_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN2, 1U);
	ADC_setInterruptSOCTrigger(ADCB_BASE_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 3 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN4
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCB_BASE_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN4, 1U);
	ADC_setInterruptSOCTrigger(ADCB_BASE_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 4 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN0
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCB_BASE_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN0, 1U);
	ADC_setInterruptSOCTrigger(ADCB_BASE_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);

	//ADCC_BASE initialization

	// ADC Initialization: Write ADC configurations and power up the ADC
	// Configures the ADC module's offset trim
	ADC_setOffsetTrimAll(ADC_REFERENCE_INTERNAL,ADC_REFERENCE_3_3V);
	// Configures the analog-to-digital converter module prescaler.
	ADC_setPrescaler(ADCC_BASE_BASE, ADC_CLK_DIV_1_0);
	// Sets the timing of the end-of-conversion pulse
	ADC_setInterruptPulseMode(ADCC_BASE_BASE, ADC_PULSE_END_OF_CONV);
	// Powers up the analog-to-digital converter core.
	ADC_enableConverter(ADCC_BASE_BASE);
	// Delay for 1ms to allow ADC time to power up
	DEVICE_DELAY_US(5000);

	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	// Disables SOC burst mode.
	ADC_disableBurstMode(ADCC_BASE_BASE);
	// Sets the priority mode of the SOCs.
	ADC_setSOCPriority(ADCC_BASE_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	// Start of Conversion 0 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCC_BASE_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN1, 1U);
	ADC_setInterruptSOCTrigger(ADCC_BASE_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 1 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCC_BASE_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN5, 1U);
	ADC_setInterruptSOCTrigger(ADCC_BASE_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 2 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN8
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCC_BASE_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN8, 1U);
	ADC_setInterruptSOCTrigger(ADCC_BASE_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 3 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 3
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN6
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCC_BASE_BASE, ADC_SOC_NUMBER3, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN6, 1U);
	ADC_setInterruptSOCTrigger(ADCC_BASE_BASE, ADC_SOC_NUMBER3, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 4 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 4
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN10
	//	 	Sample Window	: 1 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(ADCC_BASE_BASE, ADC_SOC_NUMBER4, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN10, 1U);
	ADC_setInterruptSOCTrigger(ADCC_BASE_BASE, ADC_SOC_NUMBER4, ADC_INT_SOC_TRIGGER_NONE);

}
void ASYSCTL_init(){
	// asysctl initialization
	// Disables the temperature sensor output to the ADC.
	ASysCtl_disableTemperatureSensor();
	// Set the analog voltage reference selection to internal.
	ASysCtl_setAnalogReferenceInternal( ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC );
	// Set the internal analog voltage reference selection to 1.65V.
	ASysCtl_setAnalogReference1P65( ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC );
}
 
void CMPSS_init(){
	// Select the value for CMPHNMXSEL.
	ASysCtl_selectCMPHNMux(ASYSCTL_CMPHNMUX_SELECT_1 | ASYSCTL_CMPHNMUX_SELECT_2 | ASYSCTL_CMPHNMUX_SELECT_7);
	// Select the value for CMPLNMXSEL.
	ASysCtl_selectCMPLNMux(ASYSCTL_CMPLNMUX_SELECT_1 | ASYSCTL_CMPLNMUX_SELECT_2 | ASYSCTL_CMPLNMUX_SELECT_7);
	// Select the value for CMPHPM[object Object]SEL.
	ASysCtl_selectCMPHPMux(ASYSCTL_CMPHPMUX_SELECT_1,3U);
	// Select the value for CMPLPM[object Object]SEL.
	ASysCtl_selectCMPLPMux(ASYSCTL_CMPLPMUX_SELECT_1,0U);
	// Select the value for CMPHPM[object Object]SEL.
	ASysCtl_selectCMPHPMux(ASYSCTL_CMPHPMUX_SELECT_2,1U);
	// Select the value for CMPLPM[object Object]SEL.
	ASysCtl_selectCMPLPMux(ASYSCTL_CMPLPMUX_SELECT_2,0U);
	// Select the value for CMPHPM[object Object]SEL.
	ASysCtl_selectCMPHPMux(ASYSCTL_CMPHPMUX_SELECT_7,3U);
	// Select the value for CMPLPM[object Object]SEL.
	ASysCtl_selectCMPLPMux(ASYSCTL_CMPLPMUX_SELECT_7,0U);

	//PCMC initialization
	// Sets the configuration for the high comparator.
	CMPSS_configHighComparator(PCMC_BASE,(CMPSS_INSRC_DAC));
	// Sets the configuration for the high comparator.
	CMPSS_configLowComparator(PCMC_BASE,(CMPSS_INSRC_DAC));
	// Sets the configuration for the internal comparator DACs.
	CMPSS_configDAC(PCMC_BASE,(CMPSS_DACVAL_SYSCLK | CMPSS_DACREF_VDDA | CMPSS_DACSRC_RAMP));
	// Sets the value of the internal DAC of the high comparator.
	CMPSS_setDACValueHigh(PCMC_BASE,0U);
	// Sets the value of the internal DAC of the low comparator.
	CMPSS_setDACValueLow(PCMC_BASE,0U);
	//  Configures the digital filter of the high comparator.
	CMPSS_configFilterHigh(PCMC_BASE, 5U, 10U, 6U);
	// Configures the digital filter of the low comparator.
	CMPSS_configFilterLow(PCMC_BASE, 0U, 1U, 1U);
	// Initializes the digital filter of the high comparator.
	CMPSS_initFilterHigh(PCMC_BASE);
	// Sets the output signal configuration for the high comparator.
	CMPSS_configOutputsHigh(PCMC_BASE,(CMPSS_TRIPOUT_FILTER | CMPSS_TRIP_FILTER));
	// Sets the output signal configuration for the low comparator.
	CMPSS_configOutputsLow(PCMC_BASE,(CMPSS_TRIPOUT_ASYNC_COMP | CMPSS_TRIP_ASYNC_COMP));
	// Sets the comparator hysteresis settings.
	CMPSS_setHysteresis(PCMC_BASE,0U);
	// Configures the comparator subsystem's ramp generator.
	CMPSS_configRamp(PCMC_BASE,32768U,0U,0U,1U,true);
	// Enables reset of HIGH comparator digital filter output latch on PWMSYNC
	CMPSS_enableLatchResetOnPWMSYNCHigh(PCMC_BASE);
	// Disables reset of LOW comparator digital filter output latch on PWMSYNC
	CMPSS_disableLatchResetOnPWMSYNCLow(PCMC_BASE);
	// Sets the ePWM module blanking signal that holds trip in reset.
	CMPSS_configBlanking(PCMC_BASE,1U);
	// Enables an ePWM blanking signal to hold trip in reset.
	CMPSS_enableBlanking(PCMC_BASE);
	// Configures whether or not the digital filter latches are reset by PWMSYNC
	CMPSS_configLatchOnPWMSYNC(PCMC_BASE,true,false);
	// Enables the CMPSS module.
	CMPSS_enableModule(PCMC_BASE);
	//OVP_SENSE initialization
	// Sets the configuration for the high comparator.
	CMPSS_configHighComparator(OVP_SENSE_BASE,(CMPSS_INSRC_DAC));
	// Sets the configuration for the high comparator.
	CMPSS_configLowComparator(OVP_SENSE_BASE,(CMPSS_INSRC_DAC));
	// Sets the configuration for the internal comparator DACs.
	CMPSS_configDAC(OVP_SENSE_BASE,(CMPSS_DACVAL_SYSCLK | CMPSS_DACREF_VDDA | CMPSS_DACSRC_SHDW));
	// Sets the value of the internal DAC of the high comparator.
	CMPSS_setDACValueHigh(OVP_SENSE_BASE,0U);
	// Sets the value of the internal DAC of the low comparator.
	CMPSS_setDACValueLow(OVP_SENSE_BASE,0U);
	//  Configures the digital filter of the high comparator.
	CMPSS_configFilterHigh(OVP_SENSE_BASE, 0U, 1U, 1U);
	// Configures the digital filter of the low comparator.
	CMPSS_configFilterLow(OVP_SENSE_BASE, 0U, 1U, 1U);
	// Sets the output signal configuration for the high comparator.
	CMPSS_configOutputsHigh(OVP_SENSE_BASE,(CMPSS_TRIPOUT_ASYNC_COMP | CMPSS_TRIP_ASYNC_COMP));
	// Sets the output signal configuration for the low comparator.
	CMPSS_configOutputsLow(OVP_SENSE_BASE,(CMPSS_TRIPOUT_ASYNC_COMP | CMPSS_TRIP_ASYNC_COMP));
	// Sets the comparator hysteresis settings.
	CMPSS_setHysteresis(OVP_SENSE_BASE,0U);
	// Configures the comparator subsystem's ramp generator.
	CMPSS_configRamp(OVP_SENSE_BASE,0U,0U,0U,1U,true);
	// Disables reset of HIGH comparator digital filter output latch on PWMSYNC
	CMPSS_disableLatchResetOnPWMSYNCHigh(OVP_SENSE_BASE);
	// Disables reset of LOW comparator digital filter output latch on PWMSYNC
	CMPSS_disableLatchResetOnPWMSYNCLow(OVP_SENSE_BASE);
	// Sets the ePWM module blanking signal that holds trip in reset.
	CMPSS_configBlanking(OVP_SENSE_BASE,1U);
	// Disables an ePWM blanking signal from holding trip in reset.
	CMPSS_disableBlanking(OVP_SENSE_BASE);
	// Configures whether or not the digital filter latches are reset by PWMSYNC
	CMPSS_configLatchOnPWMSYNC(OVP_SENSE_BASE,false,false);
	// Disables the CMPSS module.
	CMPSS_disableModule(OVP_SENSE_BASE);

	//OCP_SENSE initialization
	// Sets the configuration for the high comparator.
	CMPSS_configHighComparator(OCP_SENSE_BASE,(CMPSS_INSRC_DAC));
	// Sets the configuration for the high comparator.
	CMPSS_configLowComparator(OCP_SENSE_BASE,(CMPSS_INSRC_DAC));
	// Sets the configuration for the internal comparator DACs.
	CMPSS_configDAC(OCP_SENSE_BASE,(CMPSS_DACVAL_SYSCLK | CMPSS_DACREF_VDDA | CMPSS_DACSRC_SHDW));
	// Sets the value of the internal DAC of the high comparator.
	CMPSS_setDACValueHigh(OCP_SENSE_BASE,0U);
	// Sets the value of the internal DAC of the low comparator.
	CMPSS_setDACValueLow(OCP_SENSE_BASE,0U);
	//  Configures the digital filter of the high comparator.
	CMPSS_configFilterHigh(OCP_SENSE_BASE, 0U, 1U, 1U);
	// Configures the digital filter of the low comparator.
	CMPSS_configFilterLow(OCP_SENSE_BASE, 0U, 1U, 1U);
	// Sets the output signal configuration for the high comparator.
	CMPSS_configOutputsHigh(OCP_SENSE_BASE,(CMPSS_TRIPOUT_ASYNC_COMP | CMPSS_TRIP_ASYNC_COMP));
	// Sets the output signal configuration for the low comparator.
	CMPSS_configOutputsLow(OCP_SENSE_BASE,(CMPSS_TRIPOUT_ASYNC_COMP | CMPSS_TRIP_ASYNC_COMP));
	// Sets the comparator hysteresis settings.
	CMPSS_setHysteresis(OCP_SENSE_BASE,0U);
	// Configures the comparator subsystem's ramp generator.
	CMPSS_configRamp(OCP_SENSE_BASE,0U,0U,0U,1U,true);
	// Disables reset of HIGH comparator digital filter output latch on PWMSYNC
	CMPSS_disableLatchResetOnPWMSYNCHigh(OCP_SENSE_BASE);
	// Disables reset of LOW comparator digital filter output latch on PWMSYNC
	CMPSS_disableLatchResetOnPWMSYNCLow(OCP_SENSE_BASE);
	// Sets the ePWM module blanking signal that holds trip in reset.
	CMPSS_configBlanking(OCP_SENSE_BASE,1U);
	// Disables an ePWM blanking signal from holding trip in reset.
	CMPSS_disableBlanking(OCP_SENSE_BASE);
	// Configures whether or not the digital filter latches are reset by PWMSYNC
	CMPSS_configLatchOnPWMSYNC(OCP_SENSE_BASE,false,false);
	// Disables the CMPSS module.
	CMPSS_disableModule(OCP_SENSE_BASE);

	// Delay for CMPSS DAC to power up.
	DEVICE_DELAY_US(500);
	// Causes a software reset of the high comparator digital filter output latch.
	CMPSS_clearFilterLatchHigh(PCMC_BASE);
}
void CPUTIMER_init(){
	//SWTIRMER initialization 
	CPUTimer_setEmulationMode(SWTIRMER_BASE, CPUTIMER_EMULATIONMODE_RUNFREE);
	CPUTimer_selectClockSource(SWTIRMER_BASE, CPUTIMER_CLOCK_SOURCE_SYS, CPUTIMER_CLOCK_PRESCALER_1);
	CPUTimer_setPreScaler(SWTIRMER_BASE, 1U);
	CPUTimer_setPeriod(SWTIRMER_BASE, 4294967295U);
	CPUTimer_disableInterrupt(SWTIRMER_BASE);
	CPUTimer_stopTimer(SWTIRMER_BASE);

	CPUTimer_reloadTimerCounter(SWTIRMER_BASE);
	CPUTimer_startTimer(SWTIRMER_BASE);
}
void DAC_init(){
	// DEBUG_DAC initialization
	// Set DAC reference voltage.
	DAC_setReferenceVoltage(DEBUG_DAC_BASE, DAC_REF_ADC_VREFHI);
	// Set DAC gain mode.
	DAC_setGainMode(DEBUG_DAC_BASE, DAC_GAIN_TWO);
	// Set DAC load mode.
	DAC_setLoadMode(DEBUG_DAC_BASE, DAC_LOAD_SYSCLK);
	// Enable the DAC output
	DAC_enableOutput(DEBUG_DAC_BASE);
	// Set the DAC shadow output
	DAC_setShadowValue(DEBUG_DAC_BASE, 1024U);

	// IL_COMMAND initialization
	// Set DAC reference voltage.
	DAC_setReferenceVoltage(IL_COMMAND_BASE, DAC_REF_ADC_VREFHI);
	// Set DAC gain mode.
	DAC_setGainMode(IL_COMMAND_BASE, DAC_GAIN_TWO);
	// Set DAC load mode.
	DAC_setLoadMode(IL_COMMAND_BASE, DAC_LOAD_SYSCLK);
	// Enable the DAC output
	DAC_enableOutput(IL_COMMAND_BASE);
	// Set the DAC shadow output
	DAC_setShadowValue(IL_COMMAND_BASE, 0U);

	// Delay for buffered DAC to power up.
	DEVICE_DELAY_US(5000);

}

void EPWM_init(){
	//PWM_PEAK_CURR initialization
	//PWM_FAN initialization
	//PWM_VIN_COMMAND initialization
	//PWM_BLEEDER initialization
}
void EPWMXBAR_init(){
	//PCMC_EPWMXBAR0 initialization
		
	XBAR_setEPWMMuxConfig(XBAR_TRIP4, XBAR_EPWM_MUX00_CMPSS1_CTRIPH);
	XBAR_enableEPWMMux(XBAR_TRIP4, XBAR_MUX00);

}
void GPIO_init(){
		
	//FAULT_LED initialization
	GPIO_setDirectionMode(FAULT_LED, GPIO_DIR_MODE_OUT);
	GPIO_setPadConfig(FAULT_LED, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(FAULT_LED, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(FAULT_LED, GPIO_QUAL_SYNC);
		
	//CV_LED initialization
	GPIO_setDirectionMode(CV_LED, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(CV_LED, GPIO_PIN_TYPE_PULLUP);
	GPIO_setMasterCore(CV_LED, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(CV_LED, GPIO_QUAL_SYNC);
		
	//CC_LED initialization
	GPIO_setDirectionMode(CC_LED, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(CC_LED, GPIO_PIN_TYPE_PULLUP);
	GPIO_setMasterCore(CC_LED, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(CC_LED, GPIO_QUAL_SYNC);
		
	//AC_SENSE1 initialization
	GPIO_setDirectionMode(AC_SENSE1, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(AC_SENSE1, GPIO_PIN_TYPE_PULLUP);
	GPIO_setMasterCore(AC_SENSE1, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(AC_SENSE1, GPIO_QUAL_SYNC);
		
	//AC_SENSE2 initialization
	GPIO_setDirectionMode(AC_SENSE2, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(AC_SENSE2, GPIO_PIN_TYPE_PULLUP);
	GPIO_setMasterCore(AC_SENSE2, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(AC_SENSE2, GPIO_QUAL_SYNC);
		
	//AC_SENSE3 initialization
	GPIO_setDirectionMode(AC_SENSE3, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(AC_SENSE3, GPIO_PIN_TYPE_PULLUP);
	GPIO_setMasterCore(AC_SENSE3, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(AC_SENSE3, GPIO_QUAL_SYNC);
		
	//PS initialization
	GPIO_setDirectionMode(PS, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(PS, GPIO_PIN_TYPE_PULLUP);
	GPIO_setMasterCore(PS, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(PS, GPIO_QUAL_SYNC);
		
	//FAN_SENSE initialization
	GPIO_setDirectionMode(FAN_SENSE, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(FAN_SENSE, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(FAN_SENSE, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(FAN_SENSE, GPIO_QUAL_SYNC);
		
	//SPIB_CS_ICMD initialization
	GPIO_setDirectionMode(SPIB_CS_ICMD, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(SPIB_CS_ICMD, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(SPIB_CS_ICMD, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(SPIB_CS_ICMD, GPIO_QUAL_SYNC);
		
	//DEBUG_IO3 initialization
	GPIO_setDirectionMode(DEBUG_IO3, GPIO_DIR_MODE_OUT);
	GPIO_setPadConfig(DEBUG_IO3, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(DEBUG_IO3, GPIO_CORE_CPU1_CLA1);
	GPIO_setQualificationMode(DEBUG_IO3, GPIO_QUAL_SYNC);
		
	//NB0_DIO1 initialization
	GPIO_setDirectionMode(NB0_DIO1, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(NB0_DIO1, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(NB0_DIO1, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(NB0_DIO1, GPIO_QUAL_SYNC);
		
	//NB1_DIO2 initialization
	GPIO_setDirectionMode(NB1_DIO2, GPIO_DIR_MODE_OUT);
	GPIO_setPadConfig(NB1_DIO2, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(NB1_DIO2, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(NB1_DIO2, GPIO_QUAL_SYNC);
}
void I2C_init(){
	//I2CA_MASTER initialization
	
	I2C_disableModule(I2CA_MASTER_BASE);
	I2C_initMaster(I2CA_MASTER_BASE, DEVICE_SYSCLK_FREQ, 400000, I2C_DUTYCYCLE_33);
	I2C_setConfig(I2CA_MASTER_BASE, I2C_MASTER_SEND_MODE);
	I2C_setSlaveAddress(I2CA_MASTER_BASE, 80);
	I2C_disableLoopback(I2CA_MASTER_BASE);
	I2C_setBitCount(I2CA_MASTER_BASE, I2C_BITCOUNT_8);
	I2C_setDataCount(I2CA_MASTER_BASE, 1);
	I2C_setAddressMode(I2CA_MASTER_BASE, I2C_ADDR_MODE_7BITS);
	I2C_enableFIFO(I2CA_MASTER_BASE);
	I2C_setEmulationMode(I2CA_MASTER_BASE, I2C_EMULATION_STOP_SCL_LOW);
	I2C_enableModule(I2CA_MASTER_BASE);

}
void INPUTXBAR_init(){
	
	//EPWM1SYNCI initialization
	XBAR_setInputPin(XBAR_INPUT5, 34);
}
void INTERRUPT_init(){
	
	// Interrupt Setings for INT_ADCA_BASE_1
	Interrupt_register(INT_ADCA_BASE_1, &INT_ADCA_BASE_1_ISR);
	Interrupt_enable(INT_ADCA_BASE_1);
}

void OUTPUTXBAR_init(){
	
	//PCMC_OUTPUTXBAR0 initialization
	XBAR_setOutputLatchMode(XBAR_OUTPUT1, false);
	XBAR_invertOutputSignal(XBAR_OUTPUT1, false);
		
	//Mux configuration
	XBAR_setOutputMuxConfig(XBAR_OUTPUT1, XBAR_OUT_MUX00_CMPSS1_CTRIPOUTH);
	XBAR_enableOutputMux(XBAR_OUTPUT1, XBAR_MUX00);
}
void SCI_init(){
	
	//DEBUG_SCI initialization
	SCI_clearInterruptStatus(DEBUG_SCI_BASE, SCI_INT_RXFF | SCI_INT_TXFF | SCI_INT_FE | SCI_INT_OE | SCI_INT_PE | SCI_INT_RXERR | SCI_INT_RXRDY_BRKDT | SCI_INT_TXRDY);
	SCI_clearOverflowStatus(DEBUG_SCI_BASE);

	SCI_resetTxFIFO(DEBUG_SCI_BASE);
	SCI_resetRxFIFO(DEBUG_SCI_BASE);
	SCI_resetChannels(DEBUG_SCI_BASE);

	SCI_setConfig(DEBUG_SCI_BASE, DEVICE_LSPCLK_FREQ, DEBUG_SCI_BAUDRATE, (SCI_CONFIG_WLEN_8|SCI_CONFIG_STOP_ONE|SCI_CONFIG_PAR_EVEN));
	SCI_disableLoopback(DEBUG_SCI_BASE);
	SCI_performSoftwareReset(DEBUG_SCI_BASE);
	SCI_enableFIFO(DEBUG_SCI_BASE);
	SCI_enableModule(DEBUG_SCI_BASE);
}
void SPI_init()
{
	
	//SPIA_SLAVE initialization
	SPI_disableModule(SPIA_SLAVE_BASE);
	SPI_setConfig(SPIA_SLAVE_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
				  SPI_MODE_SLAVE, 1250000, 	16);
	SPI_enableFIFO(SPIA_SLAVE_BASE);
	SPI_disableLoopback(SPIA_SLAVE_BASE);
	SPI_setEmulationMode(SPIA_SLAVE_BASE, SPI_EMULATION_STOP_MIDWAY);
	SPI_enableModule(SPIA_SLAVE_BASE);
	
	//SPIB_MASTER initialization
	SPI_disableModule(SPIB_MASTER_BASE);
	SPI_setConfig(SPIB_MASTER_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
				  SPI_MODE_MASTER, 1250000, 	16);
	SPI_enableFIFO(SPIB_MASTER_BASE);
	SPI_disableLoopback(SPIB_MASTER_BASE);
	SPI_setEmulationMode(SPIB_MASTER_BASE, SPI_EMULATION_STOP_MIDWAY);
	SPI_enableModule(SPIB_MASTER_BASE);
}
void SYNC_init(){
	SysCtl_setSyncOutputConfig(SYSCTL_SYNC_OUT_SRC_EPWM1SYNCOUT);
	// For EPWM1, the sync input is: SYSCTL_SYNC_IN_SRC_EXTSYNCIN1
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_EPWM4, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_EPWM7, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_ECAP1, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_ECAP4, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_ECAP6, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	// SOCA
	SysCtl_enableExtADCSOCSource(0);
	// SOCB
	SysCtl_enableExtADCSOCSource(0);
}
