/*
 * HwConfig.h
 *
 *  Created on: 2022�~4��20��
 *      Author: cody_chen
 */

#ifndef HWCONFIG_H_
#define HWCONFIG_H_

#include "common.h"


#define PWM_ADC_KHZ                      25UL     // (KHz)
#define CNT_PWM_ADC                     (uint16_t)((uint32_t)DEVICE_SYSCLK_FREQ/1000/PWM_ADC_KHZ-1)
#define CNT_PWM_ADC_DUTY                (uint16_t)((uint32_t)DEVICE_SYSCLK_FREQ/1000/2/PWM_ADC_KHZ-1)

#define LLCPWM_KHZ                       200UL    // (KHz)
#define CNT_LLCPWM                      (uint16_t)((uint32_t)DEVICE_SYSCLK_FREQ/1000/LLCPWM_KHZ-1)
#define CNT_LLCPWM_DUTY                 (uint16_t)((uint32_t)DEVICE_SYSCLK_FREQ/1000/2/LLCPWM_KHZ-1)
#define CNT_LLCPWM_SHIFT180             (uint16_t)((uint32_t)DEVICE_SYSCLK_FREQ/1000/2/LLCPWM_KHZ)

#define T_PWM_DEADBAND_NSEC              100UL    // (nsec)
#define CNT_PWM_DEADBAND                (uint16_t)(DEVICE_SYSCLK_FREQ/1000*T_PWM_DEADBAND_NSEC/1000000)

#define PEAK_CURR_PWM_KHZ                100UL    // (KHz)
#define CNT_PEAK_CURR_PWM               (uint16_t)((uint32_t)DEVICE_SYSCLK_FREQ/1000/PEAK_CURR_PWM_KHZ-1)
#define DUTY_PEAK_CURR                   0.8f
#define CNT_PEAK_CURR_PWM_DUTY          (uint16_t)((uint32_t)DEVICE_SYSCLK_FREQ/1000*DUTY_PEAK_CURR/PEAK_CURR_PWM_KHZ-1)

#define T_PEAK_CURR_PWM_DEADBAND_NSEC    100UL    // (nsec)
#define CNT_PEAK_CURR_PWM_DEADBAND      (uint16_t)(DEVICE_SYSCLK_FREQ/1000*T_PEAK_CURR_PWM_DEADBAND_NSEC/1000000)



//
// @ ADC_RESULT_Xy(X, y)
// X:= ADCA/B/C, y:= SOC0-15
#define ADC_RESULT_Xy(X, y) (((float)HWREGH(ADC ## X ##RESULT_BASE + y))*0.00024414f)

#define A10_IO_FB        ADC_RESULT_Xy(A, 0)       // ADCA Input 10 (A10)
#define A4_VO_FB         ADC_RESULT_Xy(A, 1)       // ADCA Input 4 (A4)
#define A2_IL_FB         ADC_RESULT_Xy(A, 2)       // ADCA Input 2 (A2)
#define A3_IL_FB         ADC_RESULT_Xy(A, 3)       // ADCA Input 3 (A3)
#define A5_OVP_SENSE     ADC_RESULT_Xy(A, 4)       // ADCA Input 5 (A5)

#define B8_VO_FB         ADC_RESULT_Xy(B, 0)       // ADCB Input 8 (B8)
#define B1_IO_FB         ADC_RESULT_Xy(B, 1)       // ADCB Input 1 (B1)
#define B2_VKA           ADC_RESULT_Xy(B, 2)       // ADCB Input 2 (B2)
#define B4_IO_FRONT_FB   ADC_RESULT_Xy(B, 3)       // ADCB Input 4 (B4)
#define B0_OCP_SENSE     ADC_RESULT_Xy(B, 4)       // ADCB Input 0 (B0)

#define C1_VIN_FB        ADC_RESULT_Xy(C, 0)       // ADCC Input 1 (C1)
#define C5_VIN_FB        ADC_RESULT_Xy(C, 1)       // ADCC Input 5 (C5)
#define C8_IO_FRONT_FB   ADC_RESULT_Xy(C, 2)       // ADCC Input 8 (C8)
#define C6_VKA           ADC_RESULT_Xy(C, 3)       // ADCC Input 6 (C6)
#define C10_IL_FB        ADC_RESULT_Xy(C, 4)       // ADCC Input 10 (C10)


#endif /* HWCONFIG_H_ */
