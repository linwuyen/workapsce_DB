/*
 * common.h
 *
 *  Created on: 2022�~3��9��
 *      Author: cody_chen
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "cmath.h"
#include "board.h"

#define SW_TIMER        50000000

#define T_500US         (SW_TIMER/10000)
#define T_1MS           (SW_TIMER/1000)
#define T_2D5MS         (SW_TIMER/400)
#define T_5MS           (SW_TIMER/200)
#define T_10MS          (SW_TIMER/100)
#define T_20MS          (SW_TIMER/50)
#define T_25MS          (SW_TIMER/40)
#define T_50MS          (SW_TIMER/20)
#define T_100MS         (SW_TIMER/10)
#define T_200MS         (SW_TIMER/5)
#define T_500MS         (SW_TIMER/2)
#define T_1S            (SW_TIMER/1)

#define ENABLE_HRPWM        1
#define ENABLE_CLA_PFM      1

#define RED_LED_OFF      //GPIO_writePin(RED_LED, 1);
#define RED_LED_ON       //GPIO_writePin(RED_LED, 0);


#define DEBUG_IO_HI      //GPIO_writePin(DEBUG_IO, 1);//*(uint32_t *)(GPIODATA_BASE+GPIO_O_GPBSET) = (0x00000001<<(DEBUG_IO-32));
#define DEBUG_IO_LO      //GPIO_writePin(DEBUG_IO, 0);//*(uint32_t *)(GPIODATA_BASE+GPIO_O_GPBCLEAR) = (0x00000001<<(DEBUG_IO-32));
#define DEBUG_IO_TOGGLE  //*(uint32_t *)(GPIODATA_BASE+GPIO_O_GPBTOGGLE) = (0x00000001<<(DEBUG_IO-32));




#include "drivetype.h"

typedef struct {
    uint16_t fgDrv;
    uint16_t fgFault;

    void *pCLA;

    float32_t sfTs;
    float32_t sfDuty;

    ST_ILOOP sIloop;
    ST_VLOOP sVloop;

    ST_RAMPUPDN  sTestRef;

    float32_t f32TestRef;
    float32_t f32TestFbk;
}ST_DRV;

typedef ST_DRV* HAL_DRV;

extern volatile ST_DRV sDrv;


#include "linkPeripheral.h"
#include "PowerSequence.h"


#include "cla_task.h"

#endif /* COMMON_H_ */
