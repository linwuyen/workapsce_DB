/*
 * cla_pwm.h
 *
 *  Created on: 2022�~3��31��
 *      Author: cody_chen
 */

#ifndef CLA_PWM_H_
#define CLA_PWM_H_

#include "cmath.h"


typedef struct {
    uint32_t  u32PwmBase;
    float32_t f32Duty;
    uint16_t u16Period;
    uint16_t u16Duty;
    uint16_t u16Trigger;
} ST_PWMREG;

typedef ST_PWMREG * HAL_PWMREG;

static inline void setPWM(HAL_PWMREG v)
{

    if(0 == v->u32PwmBase) return;

    v->u16Duty = (uint16_t)(v->f32Duty * v->u16Period);
    v->u16Trigger = (v->u16Duty>>1);
    //
    // Set Compare values
    EPWM_setCounterCompareValue(v->u32PwmBase, EPWM_COUNTER_COMPARE_A, v->u16Duty);

    EPWM_setCounterCompareValue(v->u32PwmBase, EPWM_COUNTER_COMPARE_C, v->u16Trigger);
}


#endif /* CLA_PWM_H_ */
