/*
 * initPWM.c
 *
 *  Created on: 2022�~3��17��
 *      Author: cody_chen
 */

#include "initPWM.h"
#include "HwConfig.h"


void setActiveLowEPWMxDeadBand(uint32_t base, uint16_t red, uint16_t fed)
{
    //
    // Use EPWMA as the input for both RED and FED
    //
    EPWM_setRisingEdgeDeadBandDelayInput(base, EPWM_DB_INPUT_EPWMA);
    EPWM_setFallingEdgeDeadBandDelayInput(base, EPWM_DB_INPUT_EPWMA);

    //
    // Set the RED and FED values
    //
    EPWM_setFallingEdgeDelayCount(base, fed);
    EPWM_setRisingEdgeDelayCount(base, red);

    //
    // INVERT the delayed outputs (AL)
    //
    EPWM_setDeadBandDelayPolarity(base, EPWM_DB_RED, EPWM_DB_POLARITY_ACTIVE_HIGH);
    EPWM_setDeadBandDelayPolarity(base, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);

    //
    // Use the delayed signals instead of the original signals
    //
    EPWM_setDeadBandDelayMode(base, EPWM_DB_RED, true);
    EPWM_setDeadBandDelayMode(base, EPWM_DB_FED, true);

    //
    // DO NOT Switch Output A with Output B
    //
    EPWM_setDeadBandOutputSwapMode(base, EPWM_DB_OUTPUT_A, false);
    EPWM_setDeadBandOutputSwapMode(base, EPWM_DB_OUTPUT_B, false);

}

void initPeakCurrEPWM1AB(uint32_t base)
{
    //
    // Disable the ePWM time base clock before configuring the module
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    //
    // Set the local ePWM module clock divider to /1
    EPWM_setClockPrescaler(base,
                           EPWM_CLOCK_DIVIDER_1,
                           EPWM_HSCLOCK_DIVIDER_1);

    //
    // Freeze the counter
    EPWM_setTimeBaseCounterMode(base, EPWM_COUNTER_MODE_STOP_FREEZE);

    //
    // Initializing dummy values for ePWM counter and period
    EPWM_setTimeBaseCounter(base, 0);
    EPWM_setTimeBasePeriod(base,  CNT_PEAK_CURR_PWM);

    //
    // Set Compare values
    EPWM_setCounterCompareValue(base, EPWM_COUNTER_COMPARE_A, CNT_PEAK_CURR_PWM_DUTY);

    EPWM_setCounterCompareValue(base, EPWM_COUNTER_COMPARE_C, (CNT_PEAK_CURR_PWM_DUTY>>1));

    //
    // Set actions
    EPWM_setActionQualifierAction(base,
                                  EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_LOW,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);

    EPWM_setActionQualifierAction(base,
                                  EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_HIGH,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    //
    // Put the time base counter into up-count mode
    EPWM_setTimeBaseCounterMode(base, EPWM_COUNTER_MODE_UP);


    //
    // Configure the deadband of pwm of peak-current-mode.
    setActiveLowEPWMxDeadBand(base, CNT_PEAK_CURR_PWM_DEADBAND, CNT_PEAK_CURR_PWM_DEADBAND);

    //
    // Disable SOCA
    //
    EPWM_disableADCTrigger(base, EPWM_SOC_A);

    //
    // Configure the SOC to occur on the first up-count event
    EPWM_setADCTriggerSource(base, EPWM_SOC_A, EPWM_SOC_TBCTR_U_CMPC);
    EPWM_setADCTriggerEventPrescale(base, EPWM_SOC_A, 1);

    // ========================================================================
    // @ Digital Compactor Configuration

    //  Set TRIPIN4 as the DCAH of Digital Compare trip input.
    EPWM_selectDigitalCompareTripInput(base,
                                       EPWM_DC_TRIP_TRIPIN4,
                                       EPWM_DC_TYPE_DCAH);

    //
    // DCAH -> High, EPWM_TZ_DC_OUTPUT_A2 := DCAEVT2
    EPWM_setTripZoneDigitalCompareEventCondition(base,
                                                 EPWM_TZ_DC_OUTPUT_A2,
                                                 EPWM_TZ_EVENT_DCXH_HIGH);

    //
    // Set the event trigger source for digital compare from
    //      Signal source is unfiltered (DCAEVT1/2)  EPWM_DC_EVENT_SOURCE_ORIG_SIGNAL = 0,
    // >    Signal source is filtered (DCEVTFILT)    EPWM_DC_EVENT_SOURCE_FILT_SIGNAL = 1filter as DCAEVT2
    EPWM_setDigitalCompareEventSource(base,
                                      EPWM_DC_MODULE_A,
                                      EPWM_DC_EVENT_2,
                                      EPWM_DC_EVENT_SOURCE_FILT_SIGNAL);

    //
    // Set DCAEVT2  is not synced with TBCLK.
    EPWM_setDigitalCompareEventSyncMode(base,
                                        EPWM_DC_MODULE_A,
                                        EPWM_DC_EVENT_2,
                                        EPWM_DC_EVENT_INPUT_NOT_SYNCED);

    // Select DCAEVT2 cycle by cycle trip
    EPWM_enableTripZoneSignals(base, EPWM_TZ_SIGNAL_DCAEVT2);

    // ========================================================================
    // @ Event Filtering Configuration (inside digital compare)
    // The event filter needs to be configured here because the above setting selects EPWM_DC_EVENT_SOURCE_FILT_SIGNAL.

    // Enable DC filter blanking window
    EPWM_enableDigitalCompareBlankingWindow(base);

    //
    // Set the signal source that will be filtered.
    EPWM_setDigitalCompareFilterInput(base,
                                      EPWM_DC_WINDOW_SOURCE_DCAEVT2);

    //
    // Set the Digital Compare filter blanking pulse.
    EPWM_setDigitalCompareBlankingEvent(base,
                                        EPWM_DC_WINDOW_START_TBCTR_ZERO_PERIOD);

    //
    // Set the blanking window offset in TBCLK counts
    EPWM_setDigitalCompareWindowOffset(base, CNT_PEAK_CURR_PWM - 5);

    //
    // Set the blanking window length in TBCLK counts
    EPWM_setDigitalCompareWindowLength(base, 10);

    // ========================================================================
    // @ Trip-zone event actions
    // What do we want the CBC events to do?
    // TZCTL Register (Offset = 84h)
    // Trip Zone Control Register
    EPWM_setTripZoneAction(base,
                           EPWM_TZ_ACTION_EVENT_DCAEVT2,
                           EPWM_TZ_ACTION_LOW);

    // TZCTL2 Register (Offset = 85h)
    // Additional Trip Zone Control Register
    EPWM_setTripZoneAdvAction(base,
                              EPWM_TZ_ADV_ACTION_EVENT_TZA_U,
                              EPWM_TZ_ADV_ACTION_LOW);

    //
    // Set the Trip Zone CBC pulse clear event.
    EPWM_selectCycleByCycleTripZoneClearEvent(base,
                                              EPWM_TZ_CBC_PULSE_CLR_CNTR_ZERO_PERIOD);

    //
    // Clear any spurious trip
    EPWM_clearTripZoneFlag(base, (EPWM_TZ_INTERRUPT_OST | EPWM_TZ_INTERRUPT_DCAEVT2 | EPWM_TZ_SIGNAL_DCBEVT1));

    // ========================================================================
    // Start ePWM1, enabling SOCA and putting the counter in up-count mode
    //
    EPWM_enableADCTrigger(base, EPWM_SOC_A);
    EPWM_setTimeBaseCounterMode(base, EPWM_COUNTER_MODE_UP);

    //
    // Disable the ePWM time base clock before configuring the module
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    FG_SETCLA(_CLA_INIT_PWMADC);


}

#ifdef _FLASH
#pragma SET_CODE_SECTION(".TI.ramfunc")
#endif //_FLASH


void initPWM(void)
{
    //
    // Configure PEAK_CURR_PWM_BASE for Peak Current Mode
    initPeakCurrEPWM1AB(PWM_PEAK_CURR_BASE);

}

#ifdef _FLASH
#pragma SET_CODE_SECTION()
#endif //_FLASH

