/*
 * isr.c
 *
 *  Created on: 2022�~3��15��
 *      Author: cody_chen
 */

#include"common.h"

float32_t f32Period = 0.0f; //-1.0 ~ 1.0

#ifdef _FLASH
#pragma SET_CODE_SECTION(".TI.ramfunc")
#endif //_FLASH

__interrupt void INT_ADCA_BASE_1_ISR(void)
{
    static HAL_DRV s = (HAL_DRV)&sDrv;
    DEBUG_IO_HI;

    s->sVloop.sPI.f32Err = s->f32TestRef - sCLA.sVout.f32Out;
    mPiLoop_C28(&s->sVloop.sPI);

    s->sIloop.sPI.f32Err = s->sVloop.sPI.f32Out - sCLA.sIout.f32Out;
    mPiLoop_C28(&s->sIloop.sPI);




    //
    // Clear the interrupt flag
    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);

    // Acknowledge the interrupt
    Interrupt_clearACKGroup(INT_ADCA_BASE_1_INTERRUPT_ACK_GROUP);

    DEBUG_IO_LO;
}

#ifdef _FLASH
#pragma SET_CODE_SECTION()
#endif //_FLASH

