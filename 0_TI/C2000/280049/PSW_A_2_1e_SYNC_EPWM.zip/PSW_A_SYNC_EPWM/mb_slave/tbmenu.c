/*
 * tbmenu.c
 *
 *  Created on: 2022/5/9
 */
#include "ModbusSlave.h"
#include "mbcmd.h"


ST_CMD g0[_end_of_0_id] = {
    { _muSYStemSTATus,                 T_U16,        0,          1            	},// #0
    { _muCONtrolREGister,              T_U16,        1,          1            	},// #1
    { _muHARdwareFAULtSTATus,          T_U16,        2,          1            	},// #2
    { _muSOFtwareFAULtSTATus,          T_U16,        3,          1            	},// #3
};


ST_CMD g1000[_end_of_1000_id] = {
    { _muVOUT,                         T_F32,        4,          2            	},// #1000
    { _muIOUT,                         T_F32,        6,          2            	},// #1002
    { _muVIN,                          T_F32,        8,          2            	},// #1004
    { _muIL,                           T_F32,        10,         2            	},// #1006
};


ST_CMD g2000[_end_of_2000_id] = {
    { _muPASsword,                     T_U16,        12,         1            	},// #2000
    { _muACTion,                       T_U16,        13,         1            	},// #2001
    { _muFS,                           T_F32,        14,         2            	},// #2002
    { _muDT,                           T_F32,        16,         2            	},// #2004
    { _muVRAMp,                        T_U16,        18,         1            	},// #2006
    { _muSS,                           T_U16,        19,         1            	},// #2007
    { _muBM,                           T_U16,        20,         1            	},// #2008
    { _muSR,                           T_U16,        21,         1            	},// #2009
};


ST_CMD g3000[_end_of_3000_id] = {
    { _muVKP,                          T_F32,        22,         2            	},// #3000
    { _muVKI,                          T_F32,        24,         2            	},// #3002
    { _muIDKP,                         T_F32,        26,         2            	},// #3004
    { _muIDKI,                         T_F32,        28,         2            	},// #3006
};


ST_CMD g9000[_end_of_9000_id] = {
    { _muSOFtwareVERsion,              T_STR,        30,         8            	},// #9000
    { _muHARdwareVERsion,              T_STR,        38,         8            	},// #9008
    { _muPCBVERsion,                   T_STR,        46,         8            	},// #9016
    { _muSERialNUMber,                 T_STR,        54,         8            	},// #9024
};


ST_GROUP gpMbus[] = {
    {g0,           4},
    {g1000,        8},
    {g2000,        10},
    {g3000,        8},
    {g9000,        32},
    {0, 0}
};


REG_MBUSDATA regMbusData;

