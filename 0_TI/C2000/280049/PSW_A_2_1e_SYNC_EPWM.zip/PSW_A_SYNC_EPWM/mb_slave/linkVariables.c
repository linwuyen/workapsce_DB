/*
 * linkVariables.c
 *
 *  Created on: 2022/5/9
 */
#include "ModbusCommon.h"
#include "ModbusSlave.h"


void updateModbusParameter(SCI_MODBUS *p) { 

	if( MBUS_03H_Read_Holding_Registers  == p->state) {
	    switch(p->info.group) {
	    default:
	        break;
	    }

	}
	else if( MBUS_06H_Write_Single_Register  == p->state) {
	    switch(p->pfn[p->info.group].src->id) {
	    default:
	        break;
	    }

	}
	else if( MBUS_10H_Write_Multiple_Register  == p->state) {
	    switch(p->info.group) {
	    default:
	        break;
	    }

	}
	else {

	}

}
