/*
 * mbcmd.h
 *
 *  Created on: 2022/5/9
*/

#ifndef MBCMD_H_
#define MBCMD_H_



typedef enum {
	_g0_MODE = 0,
	_g1000_MODE,
	_g2000_MODE,
	_g3000_MODE,
	_g9000_MODE,
    _END_OF_MODE
} ID_MODE;


enum {
	_muSYStemSTATus = 0,                     // #0  T_U16                 
	_muCONtrolREGister = 1,                  // #1  T_U16                 
	_muHARdwareFAULtSTATus = 2,              // #2  T_U16                 
	_muSOFtwareFAULtSTATus = 3,              // #3  T_U16                 
    _end_of_0_id = 4
};

enum {
	_muVOUT = 1000,                          // #1000  T_F32              Output Voltage
	_muIOUT = 1002,                          // #1002  T_F32              Output Current
	_muVIN = 1004,                           // #1004  T_F32              Input Voltage
	_muIL = 1006,                            // #1006  T_F32              Inductor Current
    _end_of_1000_id = 4
};

enum {
	_muPASsword = 2000,                      // #2000  T_U16              Switch Frequency
	_muACTion = 2001,                        // #2001  T_U16              Voltage Ramp
	_muFS = 2002,                            // #2002  T_F32              Dead Time
	_muDT = 2004,                            // #2004  T_F32              Soft-Start
	_muVRAMp = 2006,                         // #2006  T_U16              Burst Mode
	_muSS = 2007,                            // #2007  T_U16              Sync Rectifier
	_muBM = 2008,                            // #2008  T_U16              
	_muSR = 2009,                            // #2009  T_U16              
    _end_of_2000_id = 8
};

enum {
	_muVKP = 3000,                           // #3000  T_F32              
	_muVKI = 3002,                           // #3002  T_F32              
	_muIDKP = 3004,                          // #3004  T_F32              
	_muIDKI = 3006,                          // #3006  T_F32              
    _end_of_3000_id = 4
};

enum {
	_muSOFtwareVERsion = 9000,               // #9000  T_STR              
	_muHARdwareVERsion = 9008,               // #9008  T_STR              
	_muPCBVERsion = 9016,                    // #9016  T_STR              
	_muSERialNUMber = 9024,                  // #9024  T_STR              
    _end_of_9000_id = 4
};

typedef union { 
    uint16_t u16MbusData[62];
    struct { 
        uint16_t u16SYStemSTATus;                 
        uint16_t u16CONtrolREGister;              
        uint16_t u16HARdwareFAULtSTATus;          
        uint16_t u16SOFtwareFAULtSTATus;          
        float32_t f32VOUT;                         
        float32_t f32IOUT;                         
        float32_t f32VIN;                          
        float32_t f32IL;                           
        uint16_t u16PASsword;                     
        uint16_t u16ACTion;                       
        float32_t f32FS;                           
        float32_t f32DT;                           
        uint16_t u16VRAMp;                        
        uint16_t u16SS;                           
        uint16_t u16BM;                           
        uint16_t u16SR;                           
        float32_t f32VKP;                          
        float32_t f32VKI;                          
        float32_t f32IDKP;                         
        float32_t f32IDKI;                         
        uint16_t u16SOFtwareVERsion[8];           
        uint16_t u16HARdwareVERsion[8];           
        uint16_t u16PCBVERsion[8];                
        uint16_t u16SERialNUMber[8];              
    }; 
} REG_MBUSDATA;
extern REG_MBUSDATA regMbusData;





#endif /* MBCMD_H_ */

