/*
 * drivetype.h
 *
 *  Created on: 2022�~3��15��
 *      Author: cody_chen
 */

#ifndef DRIVETYPE_H_
#define DRIVETYPE_H_


typedef struct {
    ST_PI sPI;
    float32_t  f32Cmd;
} ST_ILOOP;


typedef struct {
    ST_PI sPI;
    float32_t f32Cmd;
} ST_VLOOP;


#endif /* DRIVETYPE_H_ */
