I've shorted A0 (DAC0) and A2 (ADCA2/CMPSS1P). Adjust DAC0 to trigger CMPSS. \
![Connection Block](https://github.com/yanbai7/TI_C2000/blob/main/F28377D_PTP176_CMPSS/screenshot/ADC%20and%20CMPSS%20Block%20Diagram.jpg)
![Hardware Connection](https://github.com/yanbai7/TI_C2000/blob/main/F28377D_PTP176_CMPSS/screenshot/Connect%20Method.jpg)

I'm using GPIO2 to check if CMPSS is active or not. \
![Debug Block](https://github.com/yanbai7/TI_C2000/blob/main/F28377D_PTP176_CMPSS/screenshot/Use%20GPIO2%20to%20detect%20CMPSS%20Action.jpg)

Xbar Reference \
![Xbar Block](https://github.com/yanbai7/TI_C2000/blob/main/F28377D_PTP176_CMPSS/screenshot/XBAR.jpg)

