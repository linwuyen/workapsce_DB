
//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"


// Main
//
void main(void)
{

    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // PinMux and Peripheral Initialization
    //
    Board_init();


    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    //
    // Loop Forever
    //
    for(;;)
    {
        // Turn on LED
        //
        GPIO_writePin(myBoardLED0_GPIO, 0);

        // Turn off LED
        //
        GPIO_writePin(myBoardLED0_GPIO, 1);
    }
}

// eCAP CLK

uint32_t prevTimestamp = 0;
uint32_t timestamp = 0;
uint32_t frequency;
uint32_t ecapClockFreq = 100000000;
uint32_t timeDifference;

__interrupt void INT_myECAP0_ISR(void){

    timestamp = ECAP_getEventTimeStamp(myECAP0_BASE, ECAP_EVENT_1);

    // �p��ɶ����j
    if (prevTimestamp != 0) {
        timeDifference = timestamp - prevTimestamp ;

        if (timestamp < prevTimestamp) {
            timeDifference = (0xFFFFFFFFUL - prevTimestamp) + timestamp +1;
        } else {
            timeDifference = timestamp - prevTimestamp +1 ;
        }

    // �p���W�v
       frequency = ecapClockFreq / timeDifference;
    }


    prevTimestamp = timestamp;

   // �M�����_�X��
   ECAP_clearInterrupt(myECAP0_BASE, ECAP_ISR_SOURCE_CAPTURE_EVENT_1);

   ECAP_reArm(myECAP0_BASE);
   ECAP_clearGlobalInterrupt(myECAP0_BASE);
   Interrupt_clearACKGroup(INT_myECAP0_INTERRUPT_ACK_GROUP);
}
//
// End of File
//

