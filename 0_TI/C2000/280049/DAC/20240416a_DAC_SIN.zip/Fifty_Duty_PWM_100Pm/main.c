// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"
#include "common.h"
#include "PWM_Control.h"
#include <math.h>

#define  ADC_BUF_LEN 10
uint16_t AdcBuf[ADC_BUF_LEN];

const char chararray[] = "hello world";

#define PI 3.14159265359
#define SAMPLES 24
#define amplitude 4095
uint16_t sine_wave[SAMPLES];

void SIN_cal(void)
{
//    int i;
//PWM interrout
    //    for (i = 0; i < SAMPLES; i++)
//    {
    sine_wave[i] = (uint16_t)(amplitude * (sin(2 * PI * i / SAMPLES) + 1.0) / 2.0);
//    }
}
void  Sin_wave (void)
{
    int i;
    for (i = 0; i < SAMPLES; i++)
    {
        DAC_setShadowValue(myDAC0_BASE, sine_wave[i]);
    }
}

void task2D5msec(void * s)
{
    //GPIO_togglePin(myGPIO04);

}

void task500usec(void * s)
{

}

typedef struct _ST_TIMETASK{
    void (*fn) (void * s);
    uint32_t cnt;
    uint32_t max;
} ST_TIMETASK;

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = {
        {task500usec,         0,   T_500US},
        {task2D5msec,         0,   T_2D5MS},
        {0, 0, 0}
};
bool_t scanTimeTask(ST_TIMETASK *t, void *s)
{
    static uint32_t delta_t;
    static uint32_t u32Cnt = 0;

    u32Cnt = SW_TIMER - (uint32_t)CPUTimer_getTimerCount(SWTIRMER_BASE);

    if(t->cnt > u32Cnt) {
        delta_t = u32Cnt + SW_TIMER - t->cnt;
    }
    else {
        delta_t = u32Cnt - t->cnt;
    }
    if(delta_t >= t->max) {
        t->fn(s);
        t->cnt = u32Cnt;
        return true;
    }
    else {
        return false;
    }
}


__interrupt void INT_myADC0_1_ISR(void)
{
    static uint16_t *AdcBufPtr = AdcBuf;
    *AdcBufPtr++ = ADC_readResult(myADC0_RESULT_BASE, myADC0_SOC0);

    if (AdcBufPtr < &AdcBuf[ADC_BUF_LEN])
    {
        *AdcBufPtr++ = ADC_readResult(myADC0_RESULT_BASE, myADC0_SOC0);
    }
    else
    {
        AdcBufPtr = AdcBuf;
    }

    Interrupt_clearACKGroup(INT_myADC0_1_INTERRUPT_ACK_GROUP);
    ADC_clearInterruptStatus(myADC0_BASE, ADC_INT_NUMBER1);
}

void triangle_wave (void)
{
    int i;
    for(i = 0; i <= 4095; i+=20){
        DAC_setShadowValue(myDAC0_BASE, i);
    }

    for(i = 4095; i >= 0; i-=20){
        DAC_setShadowValue(myDAC0_BASE, i);
    }
}


//
// Main
//
void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();
    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();
    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();
    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();
    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    init_PWM();
    SIN_cal();
    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();


    SCI_writeCharArray(DEBUG_SCI_BASE,(const uint16_t *)chararray ,sizeof(chararray));
    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;


    while(1)
    {
       scanTimeTask(&time_task[id_ttask++], (void *)0);
       if(0 == time_task[id_ttask].fn) id_ttask = 0;

        Sin_wave();
    }
}
//
// End of File
//
