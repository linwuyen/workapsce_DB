/*
 * PWM_Control.h
 *
 *  Created on: Apr 16, 2024
 *      Author: roger_lin
 */

#ifndef PWM_CONTROL_H_
#define PWM_CONTROL_H_



extern void init_PWM(void);

#endif /* PWM_CONTROL_H_ */
