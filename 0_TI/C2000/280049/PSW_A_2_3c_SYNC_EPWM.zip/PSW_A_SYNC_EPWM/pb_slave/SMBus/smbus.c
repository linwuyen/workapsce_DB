/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   smbus_56F8xxx.c
*
* @brief  SMBus Platform specific source code
*
* @version 1.0.4.0
* 
* @date Jun-19-2012
* 
******************************************************************************/
#include "smbus_cfg.h"
#include "smbus_types.h"

/*****************************************************************************
* Local prototypes
******************************************************************************/
void SMBus_Isr(void);
void SMBus_SlaveProcessIIC(SMBUS_BASE_ADDRESS iicBaseAddress);
void SMBus_MasterProcessIIC(SMBUS_BASE_ADDRESS iicBaseAddress);

void SMBus_Isr(void)
{
//Handle IIC/SMBus Slave interrupt
#if (SMBCFG_INTERRUPT_DRIVEN && ((SMBCFG_SLAVE_BASE_IIC) != 0))
	SMBus_SlaveProcessIIC((SMBUS_BASE_ADDRESS)SMBCFG_SLAVE_BASE_IIC);
#endif
}
