/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   smbus_56F8xxx.h
*
* @brief  SMBus platform specificheader file
*
* @version 1.0.3.0
* 
* @date Apr-27-2012
* 
*******************************************************************************/

//#include "smbus_slave.h"

#ifndef __SMBUS_56F8XXX_H
#define __SMBUS_56F8XXX_H


#define SMBUS_INLINE inline

/****************************************************************************************
* General peripheral space access macros
*****************************************************************************************/

#define SMBUS_SETBIT(base, offset, bit)     (*(volatile SMBUS_FLAGS16*)(((SMBUS_BASE_ADDRESS)(base))+(offset)) |= bit)
#define SMBUS_CLRBIT(base, offset, bit)     (*(volatile SMBUS_FLAGS16*)(((SMBUS_BASE_ADDRESS)(base))+(offset)) &= (SMBUS_FLAGS16)~((SMBUS_FLAGS16)(bit)))
#define SMBUS_TSTBIT(base, offset, bit)     (*(volatile SMBUS_FLAGS16*)(((SMBUS_BASE_ADDRESS)(base))+(offset)) & (bit))
#define SMBUS_SETREG(base, offset, value)   (*(volatile SMBUS_FLAGS16*)(((SMBUS_BASE_ADDRESS)(base))+(offset)) = value)
#define SMBUS_GETREG(base, offset)          (*(volatile SMBUS_FLAGS16*)(((SMBUS_BASE_ADDRESS)(base))+(offset)))
#define SMBUS_SETREG32(base, offset, value) (*(volatile SMBUS_FLAGS16*)(((SMBUS_BASE_ADDRESS)(base))+(offset)) = value)
#define SMBUS_GETREG32(base, offset)        (*(volatile SMBUS_FLAGS16*)(((SMBUS_BASE_ADDRESS)(base))+(offset)))


/****************************************************************************************
* IIC module constants
*****************************************************************************************/

/* IIC module registers */
#define SMBUS_IIC_CR1_OFFSET    0x9U      //24.6.2.10 I2CMDR Register (Offset = 9h) [reset = 0h]
#define SMBUS_IIC_SR_OFFSET     0x2U      //24.6.2.3  I2CSTR Register (Offset = 2h) [reset = 410h]
#define SMBUS_IIC_TDATA_OFFSET  0x8U      //24.6.2.9  I2CDXR Register (Offset = 8h) [reset = 0h]
#define SMBUS_IIC_RDATA_OFFSET  0x6U      //24.6.2.7  I2CDRR Register (Offset = 6h) [reset = 0h]

#define SMBUS_IIC_FFTX_OFFSET   0x20U     //24.6.2.14 I2CFFTX Register (Offset = 20h) [reset = 0h]
#define SMBUS_IIC_FFRX_OFFSET   0x21U     //24.6.2.15 I2CFFRX Register (Offset = 21h) [reset = 0h]

#define SMBUS_IIC_TXFFST        (0x001FU<<8)  //Contains the status of the transmit FIFO
#define SMBUS_IIC_RXFFST        (0x001FU<<8)  //Contains the status of the receive FIFO

/* IIC Control Register bits */
#define SMBUS_IIC_CR1_MST       (0x0001U<<10) //I2CMDR.bit10  (MST)     //Master Mode Select
#define SMBUS_IIC_CR1_TX        (0x0001U<<9)  //I2CMDR.bit9   (TRX)     //Transmit Mode Select
#define SMBUS_IIC_CR1_TXAK      (0x0001U<<15) //I2CMDR.bit15  (NACKMOD) //Transmit Acknowledge Enable
#define SMBUS_IIC_CR1_IRS       (0x0001U<<5)  //I2CMDR.bit5   (IRS)     //I2C module reset bit.


/* IIC Status Register bits */
#define SMBUS_IIC_SR_IAAS       (0x0001U<<9)  //I2CSTR.bit9  (AAS)     //Addressed As A Slave
#define SMBUS_IIC_SR_BUSY       (0x0001U<<12) //I2CSTR.bit12 (BB)      //Bus Busy
#define SMBUS_IIC_SR_ARBL       (0x0001U<<0)  //I2CSTR.bit0  (ARBL)    //Arbitration Lost
#define SMBUS_IIC_SR_SRW        (0x0001U<<14) //I2CSTR.bit14 (SDIR)    //Slave Read/Write
#define SMBUS_IIC_SR_RXAK       (0x0001U<<3)  //I2CSTR.bit3  (RRDY)    //Receive Acknowledge

#define SMBUS_IIC_SR_NACK       (0x0001U<<1)  //I2CSTR.bit1  (NACK)    //No-acknowledgment interrupt flag bit.
#define SMBUS_IIC_SR_ARDY       (0x0001U<<2)  //I2CSTR.bit2  (ARDY)    //Register-access-ready interrupt flag bit
#define SMBUS_IIC_SR_RRDY       (0x0001U<<3)  //I2CSTR.bit3  (RRDY)    //Receive-data-ready interrupt flag bit.
#define SMBUS_IIC_SR_XRDY       (0x0001U<<4)  //I2CSTR.bit4  (XRDY)    //Transmit-data-ready interrupt flag bit.
#define SMBUS_IIC_SR_SCD        (0x0001U<<5)  //I2CSTR.bit5  (SCD)     //Stop condition detected bit.

#define SMBUS_IIC_SR_IICIF      (SMBUS_IIC_SR_IAAS \
                                |SMBUS_IIC_SR_ARBL \
                                |SMBUS_IIC_SR_NACK \
                                |SMBUS_IIC_SR_ARDY \
                                |SMBUS_IIC_SR_RRDY \
                                |SMBUS_IIC_SR_XRDY \
                                )


#define SMBUS_IIC_FIFO_SIZE     15

/*******************************************************************************************
* IIC access macros
*****************************************************************************************/

/* configure to TX/RX */
#define SMBUS_IIC_SET_TX(iic_base) SMBUS_SETBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_TX)
#define SMBUS_IIC_SET_RX(iic_base) SMBUS_CLRBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_TX)

/* configure to ACK/NACK */
#define SMBUS_IIC_SET_TXNACK(iic_base) SMBUS_SETBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_TXAK)
#define SMBUS_IIC_SET_TXACK(iic_base) SMBUS_CLRBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_TXAK)


#define SMBUS_IIC_RESET(iic_base) SMBUS_CLRBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_IRS)
#define SMBUS_IIC_ENABLE(iic_base) SMBUS_SETBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_IRS)

/* Tranmsit byte */
#define SMBUS_IIC_PUTBYTE(iic_base, b) SMBUS_SETREG(iic_base, SMBUS_IIC_TDATA_OFFSET, b)

/* Get received byte */
#define SMBUS_IIC_GETBYTE(iic_base) SMBUS_GETREG(iic_base, SMBUS_IIC_RDATA_OFFSET)

/* read status register */
#define SMBUS_IIC_GETSR(iic_base)   SMBUS_GETREG(iic_base, SMBUS_IIC_SR_OFFSET)

/* Clear IIC Isr flag */
#define SMBUS_IIC_CLEAR_ISR(iic_base)   SMBUS_SETREG(iic_base, SMBUS_IIC_SR_OFFSET, SMBUS_IIC_SR_IICIF)

/* Clear Stop Condition flag */
#define SMBUS_IIC_CLEAR_SCD(iic_base)   SMBUS_SETREG(iic_base, SMBUS_IIC_SR_OFFSET, SMBUS_IIC_SR_SCD)

/* test Master option */
#define SMBUS_IIC_TEST_MASTER(iic_base)   SMBUS_TSTBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_MST)

/* Set as Master */
#define SMBUS_IIC_SET_MASTER(iic_base)   SMBUS_SETBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_MST)

/* Set as Slave */
#define SMBUS_IIC_SET_SLAVE(iic_base)   SMBUS_CLRBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_MST)

/* test Tx option  */
#define SMBUS_IIC_TEST_TX(iic_base)   SMBUS_TSTBIT(iic_base, SMBUS_IIC_CR1_OFFSET, SMBUS_IIC_CR1_TX)

/* test BUSY flag  */
#define SMBUS_IIC_TEST_BUSY(iic_base)   SMBUS_TSTBIT(iic_base, SMBUS_IIC_SR_OFFSET, SMBUS_IIC_SR_BUSY)

/* get the amount of receiving data  */
#define SMBUS_IIC_RX_DATA_CNTS(iic_base)   SMBUS_TSTBIT(iic_base, SMBUS_IIC_FFRX_OFFSET, SMBUS_IIC_RXFFST)

/* get the amount of transmiting data  */
#define SMBUS_IIC_TX_DATA_CNTS(iic_base)   (SMBUS_TSTBIT(iic_base, SMBUS_IIC_FFTX_OFFSET, SMBUS_IIC_TXFFST)>>8)



#endif /* __SMBUS_56F8XXX_H */
