/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   pmbus_cmd.h
*
* @brief  PMBus command definition header file
*
* @version 1.0.11.0
* 
* @date Jun-19-2012
* 
*******************************************************************************/

#ifndef __PMBUS_CMD_H
#define __PMBUS_CMD_H

/*****************************************************************************
* Database of PMBus commands, defines PMBus command codes and type of command.
*
*//*! @addtogroup pmbus_command_list
* @brief List of all PMBus commands supported by the stack
* @{*/

// Define PAGE Command macros 
#define PAGE                                    PAGE                            ///< Identifier of PAGE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_PAGE                           0x00
#define PMB_FLAGS_PAGE                          (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define OPERATION Command macros 
#define OPERATION                               OPERATION                       ///< Identifier of OPERATION command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_OPERATION                      0x01
#define PMB_FLAGS_OPERATION                     (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define ON_OFF_CONFIG Command macros 
#define ON_OFF_CONFIG                           ON_OFF_CONFIG                   ///< Identifier of ON_OFF_CONFIG command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_ON_OFF_CONFIG                  0x02
#define PMB_FLAGS_ON_OFF_CONFIG                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define CLEAR_FAULTS Command macros 
#define CLEAR_FAULTS                            CLEAR_FAULTS                    ///< Identifier of CLEAR_FAULTS command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_CLEAR_FAULTS                   0x03
#define PMB_FLAGS_CLEAR_FAULTS                  (PMB_CMD_FLAGS_WRITE_BYTE)
// Define PHASE Command macros 
#define PHASE                                   PHASE                           ///< Identifier of PHASE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_PHASE                          0x04
#define PMB_FLAGS_PHASE                         (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define PAGE_PLUS_WRITE Command macros 
#define PAGE_PLUS_WRITE                         PAGE_PLUS_WRITE                 ///< Identifier of PAGE_PLUS_WRITE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_PAGE_PLUS_WRITE                0x05
#define PMB_FLAGS_PAGE_PLUS_WRITE               (PMB_CMD_FLAGS_WRITE_BLOCK)
// Define PAGE_PLUS_READ Command macros 
#define PAGE_PLUS_READ                          PAGE_PLUS_READ                  ///< Identifier of PAGE_PLUS_READ command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_PAGE_PLUS_READ                 0x06
#define PMB_FLAGS_PAGE_PLUS_READ                (PMB_CMD_FLAGS_READ_PROCCALL)
// Define WRITE_PROTECT Command macros 
#define WRITE_PROTECT                           WRITE_PROTECT                   ///< Identifier of WRITE_PROTECT command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_WRITE_PROTECT                  0x10
#define PMB_FLAGS_WRITE_PROTECT                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STORE_DEFAULT_ALL Command macros 
#define STORE_DEFAULT_ALL                       STORE_DEFAULT_ALL               ///< Identifier of STORE_DEFAULT_ALL command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STORE_DEFAULT_ALL              0x11
#define PMB_FLAGS_STORE_DEFAULT_ALL             (PMB_CMD_FLAGS_WRITE_BYTE)
// Define RESTORE_DEFAULT_ALL Command macros 
#define RESTORE_DEFAULT_ALL                     RESTORE_DEFAULT_ALL             ///< Identifier of RESTORE_DEFAULT_ALL command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_RESTORE_DEFAULT_ALL            0x12
#define PMB_FLAGS_RESTORE_DEFAULT_ALL           (PMB_CMD_FLAGS_WRITE_BYTE)
// Define STORE_DEFAULT_CODE Command macros 
#define STORE_DEFAULT_CODE                      STORE_DEFAULT_CODE              ///< Identifier of STORE_DEFAULT_CODE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STORE_DEFAULT_CODE             0x13
#define PMB_FLAGS_STORE_DEFAULT_CODE            (PMB_CMD_FLAGS_WRITE_BYTE_WORD)
// Define RESTORE_DEFAULT_CODE Command macros 
#define RESTORE_DEFAULT_CODE                    RESTORE_DEFAULT_CODE            ///< Identifier of RESTORE_DEFAULT_CODE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_RESTORE_DEFAULT_CODE           0x14
#define PMB_FLAGS_RESTORE_DEFAULT_CODE          (PMB_CMD_FLAGS_WRITE_BYTE_WORD)
// Define STORE_USER_ALL Command macros 
#define STORE_USER_ALL                          STORE_USER_ALL                  ///< Identifier of STORE_USER_ALL command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STORE_USER_ALL                 0x15
#define PMB_FLAGS_STORE_USER_ALL                (PMB_CMD_FLAGS_WRITE_BYTE)
// Define RESTORE_USER_ALL Command macros 
#define RESTORE_USER_ALL                        RESTORE_USER_ALL                ///< Identifier of RESTORE_USER_ALL command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_RESTORE_USER_ALL               0x16
#define PMB_FLAGS_RESTORE_USER_ALL              (PMB_CMD_FLAGS_WRITE_BYTE)
// Define STORE_USER_CODE Command macros 
#define STORE_USER_CODE                         STORE_USER_CODE                 ///< Identifier of STORE_USER_CODE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STORE_USER_CODE                0x17
#define PMB_FLAGS_STORE_USER_CODE               (PMB_CMD_FLAGS_WRITE_BYTE_WORD)
// Define RESTORE_USER_CODE Command macros 
#define RESTORE_USER_CODE                       RESTORE_USER_CODE               ///< Identifier of RESTORE_USER_CODE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_RESTORE_USER_CODE              0x18
#define PMB_FLAGS_RESTORE_USER_CODE             (PMB_CMD_FLAGS_WRITE_BYTE_WORD)
// Define CAPABILITY Command macros 
#define CAPABILITY                              CAPABILITY                      ///< Identifier of CAPABILITY command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_CAPABILITY                     0x19
#define PMB_FLAGS_CAPABILITY                    (PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define QUERY Command macros 
#define QUERY                                   QUERY                           ///< Identifier of QUERY command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_QUERY                          0x1A
#define PMB_FLAGS_QUERY                         (PMB_CMD_FLAGS_READ_PROCCALL)
// Define SMBALERT_MASK Command macros 
#define SMBALERT_MASK                           SMBALERT_MASK                   ///< Identifier of SMBALERT_MASK command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_SMBALERT_MASK                  0x1B
#define PMB_FLAGS_SMBALERT_MASK                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_PROCCALL|PMB_CMD_FLAGS_WORD_SIZE)
// Define VOUT_MODE Command macros 
#define VOUT_MODE                               VOUT_MODE                       ///< Identifier of VOUT_MODE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_MODE                      0x20
#define PMB_FLAGS_VOUT_MODE                     (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define VOUT_COMMAND Command macros 
#define VOUT_COMMAND                            VOUT_COMMAND                    ///< Identifier of VOUT_COMMAND command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_COMMAND                   0x21
#define PMB_FLAGS_VOUT_COMMAND                  (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_TRIM Command macros 
#define VOUT_TRIM                               VOUT_TRIM                       ///< Identifier of VOUT_TRIM command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_TRIM                      0x22
#define PMB_FLAGS_VOUT_TRIM                     (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_CAL_OFFSET Command macros 
#define VOUT_CAL_OFFSET                         VOUT_CAL_OFFSET                 ///< Identifier of VOUT_CAL_OFFSET command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_CAL_OFFSET                0x23
#define PMB_FLAGS_VOUT_CAL_OFFSET               (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_MAX Command macros 
#define VOUT_MAX                                VOUT_MAX                        ///< Identifier of VOUT_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_MAX                       0x24
#define PMB_FLAGS_VOUT_MAX                      (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_MARGIN_HIGH Command macros 
#define VOUT_MARGIN_HIGH                        VOUT_MARGIN_HIGH                ///< Identifier of VOUT_MARGIN_HIGH command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_MARGIN_HIGH               0x25
#define PMB_FLAGS_VOUT_MARGIN_HIGH              (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_MARGIN_LOW Command macros 
#define VOUT_MARGIN_LOW                         VOUT_MARGIN_LOW                 ///< Identifier of VOUT_MARGIN_LOW command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_MARGIN_LOW                0x26
#define PMB_FLAGS_VOUT_MARGIN_LOW               (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_TRANSITION_RATE Command macros 
#define VOUT_TRANSITION_RATE                    VOUT_TRANSITION_RATE            ///< Identifier of VOUT_TRANSITION_RATE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_TRANSITION_RATE           0x27
#define PMB_FLAGS_VOUT_TRANSITION_RATE          (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VOUT_DROOP Command macros 
#define VOUT_DROOP                              VOUT_DROOP                      ///< Identifier of VOUT_DROOP command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_DROOP                     0x28
#define PMB_FLAGS_VOUT_DROOP                    (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VOUT_SCALE_LOOP Command macros 
#define VOUT_SCALE_LOOP                         VOUT_SCALE_LOOP                 ///< Identifier of VOUT_SCALE_LOOP command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_SCALE_LOOP                0x29
#define PMB_FLAGS_VOUT_SCALE_LOOP               (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VOUT_SCALE_MONITOR Command macros 
#define VOUT_SCALE_MONITOR                      VOUT_SCALE_MONITOR              ///< Identifier of VOUT_SCALE_MONITOR command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_SCALE_MONITOR             0x2A
#define PMB_FLAGS_VOUT_SCALE_MONITOR            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define COEFFICIENTS Command macros 
#define COEFFICIENTS                            COEFFICIENTS                    ///< Identifier of COEFFICIENTS command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_COEFFICIENTS                   0x30
#define PMB_FLAGS_COEFFICIENTS                  (PMB_CMD_FLAGS_READ_PROCCALL)
// Define POUT_MAX Command macros 
#define POUT_MAX                                POUT_MAX                        ///< Identifier of POUT_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_POUT_MAX                       0x31
#define PMB_FLAGS_POUT_MAX                      (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MAX_DUTY Command macros 
#define MAX_DUTY                                MAX_DUTY                        ///< Identifier of MAX_DUTY command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MAX_DUTY                       0x32
#define PMB_FLAGS_MAX_DUTY                      (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define FREQUENCY_SWITCH Command macros 
#define FREQUENCY_SWITCH                        FREQUENCY_SWITCH                ///< Identifier of FREQUENCY_SWITCH command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_FREQUENCY_SWITCH               0x33
#define PMB_FLAGS_FREQUENCY_SWITCH              (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VIN_ON Command macros 
#define VIN_ON                                  VIN_ON                          ///< Identifier of VIN_ON command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_ON                         0x35
#define PMB_FLAGS_VIN_ON                        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VIN_OFF Command macros 
#define VIN_OFF                                 VIN_OFF                         ///< Identifier of VIN_OFF command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_OFF                        0x36
#define PMB_FLAGS_VIN_OFF                       (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define INTERLEAVE Command macros 
#define INTERLEAVE                              INTERLEAVE                      ///< Identifier of INTERLEAVE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_INTERLEAVE                     0x37
#define PMB_FLAGS_INTERLEAVE                    (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define IOUT_CAL_GAIN Command macros 
#define IOUT_CAL_GAIN                           IOUT_CAL_GAIN                   ///< Identifier of IOUT_CAL_GAIN command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_CAL_GAIN                  0x38
#define PMB_FLAGS_IOUT_CAL_GAIN                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define IOUT_CAL_OFFSET Command macros 
#define IOUT_CAL_OFFSET                         IOUT_CAL_OFFSET                 ///< Identifier of IOUT_CAL_OFFSET command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_CAL_OFFSET                0x39
#define PMB_FLAGS_IOUT_CAL_OFFSET               (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define FAN_CONFIG_1_2 Command macros 
#define FAN_CONFIG_1_2                          FAN_CONFIG_1_2                  ///< Identifier of FAN_CONFIG_1_2 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_FAN_CONFIG_1_2                 0x3A
#define PMB_FLAGS_FAN_CONFIG_1_2                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define FAN_COMMAND_1 Command macros 
#define FAN_COMMAND_1                           FAN_COMMAND_1                   ///< Identifier of FAN_COMMAND_1 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_FAN_COMMAND_1                  0x3B
#define PMB_FLAGS_FAN_COMMAND_1                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define FAN_COMMAND_2 Command macros 
#define FAN_COMMAND_2                           FAN_COMMAND_2                   ///< Identifier of FAN_COMMAND_2 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_FAN_COMMAND_2                  0x3C
#define PMB_FLAGS_FAN_COMMAND_2                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define FAN_CONFIG_3_4 Command macros 
#define FAN_CONFIG_3_4                          FAN_CONFIG_3_4                  ///< Identifier of FAN_CONFIG_3_4 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_FAN_CONFIG_3_4                 0x3D
#define PMB_FLAGS_FAN_CONFIG_3_4                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define FAN_COMMAND_3 Command macros 
#define FAN_COMMAND_3                           FAN_COMMAND_3                   ///< Identifier of FAN_COMMAND_3 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_FAN_COMMAND_3                  0x3E
#define PMB_FLAGS_FAN_COMMAND_3                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define FAN_COMMAND_4 Command macros 
#define FAN_COMMAND_4                           FAN_COMMAND_4                   ///< Identifier of FAN_COMMAND_4 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_FAN_COMMAND_4                  0x3F
#define PMB_FLAGS_FAN_COMMAND_4                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VOUT_OV_FAULT_LIMIT Command macros 
#define VOUT_OV_FAULT_LIMIT                     VOUT_OV_FAULT_LIMIT             ///< Identifier of VOUT_OV_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_OV_FAULT_LIMIT            0x40
#define PMB_FLAGS_VOUT_OV_FAULT_LIMIT           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_OV_FAULT_RESPONSE Command macros 
#define VOUT_OV_FAULT_RESPONSE                  VOUT_OV_FAULT_RESPONSE          ///< Identifier of VOUT_OV_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_OV_FAULT_RESPONSE         0x41
#define PMB_FLAGS_VOUT_OV_FAULT_RESPONSE        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define VOUT_OV_WARN_LIMIT Command macros 
#define VOUT_OV_WARN_LIMIT                      VOUT_OV_WARN_LIMIT              ///< Identifier of VOUT_OV_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_OV_WARN_LIMIT             0x42
#define PMB_FLAGS_VOUT_OV_WARN_LIMIT            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_UV_WARN_LIMIT Command macros 
#define VOUT_UV_WARN_LIMIT                      VOUT_UV_WARN_LIMIT              ///< Identifier of VOUT_UV_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_UV_WARN_LIMIT             0x43
#define PMB_FLAGS_VOUT_UV_WARN_LIMIT            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_UV_FAULT_LIMIT Command macros 
#define VOUT_UV_FAULT_LIMIT                     VOUT_UV_FAULT_LIMIT             ///< Identifier of VOUT_UV_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_UV_FAULT_LIMIT            0x44
#define PMB_FLAGS_VOUT_UV_FAULT_LIMIT           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define VOUT_UV_FAULT_RESPONSE Command macros 
#define VOUT_UV_FAULT_RESPONSE                  VOUT_UV_FAULT_RESPONSE          ///< Identifier of VOUT_UV_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VOUT_UV_FAULT_RESPONSE         0x45
#define PMB_FLAGS_VOUT_UV_FAULT_RESPONSE        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define IOUT_OC_FAULT_LIMIT Command macros 
#define IOUT_OC_FAULT_LIMIT                     IOUT_OC_FAULT_LIMIT             ///< Identifier of IOUT_OC_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_OC_FAULT_LIMIT            0x46
#define PMB_FLAGS_IOUT_OC_FAULT_LIMIT           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define IOUT_OC_FAULT_RESPONSE Command macros 
#define IOUT_OC_FAULT_RESPONSE                  IOUT_OC_FAULT_RESPONSE          ///< Identifier of IOUT_OC_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_OC_FAULT_RESPONSE         0x47
#define PMB_FLAGS_IOUT_OC_FAULT_RESPONSE        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define IOUT_OC_LV_FAULT_LIMIT Command macros 
#define IOUT_OC_LV_FAULT_LIMIT                  IOUT_OC_LV_FAULT_LIMIT          ///< Identifier of IOUT_OC_LV_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_OC_LV_FAULT_LIMIT         0x48
#define PMB_FLAGS_IOUT_OC_LV_FAULT_LIMIT        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define IOUT_OC_LV_FAULT_RESPONSE Command macros 
#define IOUT_OC_LV_FAULT_RESPONSE               IOUT_OC_LV_FAULT_RESPONSE       ///< Identifier of IOUT_OC_LV_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_OC_LV_FAULT_RESPONSE      0x49
#define PMB_FLAGS_IOUT_OC_LV_FAULT_RESPONSE     (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define IOUT_OC_WARN_LIMIT Command macros 
#define IOUT_OC_WARN_LIMIT                      IOUT_OC_WARN_LIMIT              ///< Identifier of IOUT_OC_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_OC_WARN_LIMIT             0x4A
#define PMB_FLAGS_IOUT_OC_WARN_LIMIT            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define IOUT_UC_FAULT_LIMIT Command macros 
#define IOUT_UC_FAULT_LIMIT                     IOUT_UC_FAULT_LIMIT             ///< Identifier of IOUT_UC_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_UC_FAULT_LIMIT            0x4B
#define PMB_FLAGS_IOUT_UC_FAULT_LIMIT           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define IOUT_UC_FAULT_RESPONSE Command macros 
#define IOUT_UC_FAULT_RESPONSE                  IOUT_UC_FAULT_RESPONSE          ///< Identifier of IOUT_UC_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IOUT_UC_FAULT_RESPONSE         0x4C
#define PMB_FLAGS_IOUT_UC_FAULT_RESPONSE        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define OT_FAULT_LIMIT Command macros 
#define OT_FAULT_LIMIT                          OT_FAULT_LIMIT                  ///< Identifier of OT_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_OT_FAULT_LIMIT                 0x4F
#define PMB_FLAGS_OT_FAULT_LIMIT                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define OT_FAULT_RESPONSE Command macros 
#define OT_FAULT_RESPONSE                       OT_FAULT_RESPONSE               ///< Identifier of OT_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_OT_FAULT_RESPONSE              0x50
#define PMB_FLAGS_OT_FAULT_RESPONSE             (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define OT_WARN_LIMIT Command macros 
#define OT_WARN_LIMIT                           OT_WARN_LIMIT                   ///< Identifier of OT_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_OT_WARN_LIMIT                  0x51
#define PMB_FLAGS_OT_WARN_LIMIT                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define UT_WARN_LIMIT Command macros 
#define UT_WARN_LIMIT                           UT_WARN_LIMIT                   ///< Identifier of UT_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_UT_WARN_LIMIT                  0x52
#define PMB_FLAGS_UT_WARN_LIMIT                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define UT_FAULT_LIMIT Command macros 
#define UT_FAULT_LIMIT                          UT_FAULT_LIMIT                  ///< Identifier of UT_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_UT_FAULT_LIMIT                 0x53
#define PMB_FLAGS_UT_FAULT_LIMIT                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define UT_FAULT_RESPONSE Command macros 
#define UT_FAULT_RESPONSE                       UT_FAULT_RESPONSE               ///< Identifier of UT_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_UT_FAULT_RESPONSE              0x54
#define PMB_FLAGS_UT_FAULT_RESPONSE             (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define VIN_OV_FAULT_LIMIT Command macros 
#define VIN_OV_FAULT_LIMIT                      VIN_OV_FAULT_LIMIT              ///< Identifier of VIN_OV_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_OV_FAULT_LIMIT             0x55
#define PMB_FLAGS_VIN_OV_FAULT_LIMIT            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VIN_OV_FAULT_RESPONSE Command macros 
#define VIN_OV_FAULT_RESPONSE                   VIN_OV_FAULT_RESPONSE           ///< Identifier of VIN_OV_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_OV_FAULT_RESPONSE          0x56
#define PMB_FLAGS_VIN_OV_FAULT_RESPONSE         (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define VIN_OV_WARN_LIMIT Command macros 
#define VIN_OV_WARN_LIMIT                       VIN_OV_WARN_LIMIT               ///< Identifier of VIN_OV_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_OV_WARN_LIMIT              0x57
#define PMB_FLAGS_VIN_OV_WARN_LIMIT             (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VIN_UV_WARN_LIMIT Command macros 
#define VIN_UV_WARN_LIMIT                       VIN_UV_WARN_LIMIT               ///< Identifier of VIN_UV_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_UV_WARN_LIMIT              0x58
#define PMB_FLAGS_VIN_UV_WARN_LIMIT             (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VIN_UV_FAULT_LIMIT Command macros 
#define VIN_UV_FAULT_LIMIT                      VIN_UV_FAULT_LIMIT              ///< Identifier of VIN_UV_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_UV_FAULT_LIMIT             0x59
#define PMB_FLAGS_VIN_UV_FAULT_LIMIT            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define VIN_UV_FAULT_RESPONSE Command macros 
#define VIN_UV_FAULT_RESPONSE                   VIN_UV_FAULT_RESPONSE           ///< Identifier of VIN_UV_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_VIN_UV_FAULT_RESPONSE          0x5A
#define PMB_FLAGS_VIN_UV_FAULT_RESPONSE         (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define IIN_OC_FAULT_LIMIT Command macros 
#define IIN_OC_FAULT_LIMIT                      IIN_OC_FAULT_LIMIT              ///< Identifier of IIN_OC_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IIN_OC_FAULT_LIMIT             0x5B
#define PMB_FLAGS_IIN_OC_FAULT_LIMIT            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define IIN_OC_FAULT_RESPONSE Command macros 
#define IIN_OC_FAULT_RESPONSE                   IIN_OC_FAULT_RESPONSE           ///< Identifier of IIN_OC_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IIN_OC_FAULT_RESPONSE          0x5C
#define PMB_FLAGS_IIN_OC_FAULT_RESPONSE         (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define IIN_OC_WARN_LIMIT Command macros 
#define IIN_OC_WARN_LIMIT                       IIN_OC_WARN_LIMIT               ///< Identifier of IIN_OC_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_IIN_OC_WARN_LIMIT              0x5D
#define PMB_FLAGS_IIN_OC_WARN_LIMIT             (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define POWER_GOOD_ON Command macros 
#define POWER_GOOD_ON                           POWER_GOOD_ON                   ///< Identifier of POWER_GOOD_ON command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_POWER_GOOD_ON                  0x5E
#define PMB_FLAGS_POWER_GOOD_ON                 (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define POWER_GOOD_OFF Command macros 
#define POWER_GOOD_OFF                          POWER_GOOD_OFF                  ///< Identifier of POWER_GOOD_OFF command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_POWER_GOOD_OFF                 0x5F
#define PMB_FLAGS_POWER_GOOD_OFF                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define TON_DELAY Command macros 
#define TON_DELAY                               TON_DELAY                       ///< Identifier of TON_DELAY command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_TON_DELAY                      0x60
#define PMB_FLAGS_TON_DELAY                     (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define TON_RISE Command macros 
#define TON_RISE                                TON_RISE                        ///< Identifier of TON_RISE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_TON_RISE                       0x61
#define PMB_FLAGS_TON_RISE                      (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define TON_MAX_FAULT_LIMIT Command macros 
#define TON_MAX_FAULT_LIMIT                     TON_MAX_FAULT_LIMIT             ///< Identifier of TON_MAX_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_TON_MAX_FAULT_LIMIT            0x62
#define PMB_FLAGS_TON_MAX_FAULT_LIMIT           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define TON_MAX_FAULT_RESPONSE Command macros 
#define TON_MAX_FAULT_RESPONSE                  TON_MAX_FAULT_RESPONSE          ///< Identifier of TON_MAX_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_TON_MAX_FAULT_RESPONSE         0x63
#define PMB_FLAGS_TON_MAX_FAULT_RESPONSE        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define TOFF_DELAY Command macros 
#define TOFF_DELAY                              TOFF_DELAY                      ///< Identifier of TOFF_DELAY command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_TOFF_DELAY                     0x64
#define PMB_FLAGS_TOFF_DELAY                    (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define TOFF_FALL Command macros 
#define TOFF_FALL                               TOFF_FALL                       ///< Identifier of TOFF_FALL command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_TOFF_FALL                      0x65
#define PMB_FLAGS_TOFF_FALL                     (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define TOFF_MAX_WARN_LIMIT Command macros 
#define TOFF_MAX_WARN_LIMIT                     TOFF_MAX_WARN_LIMIT             ///< Identifier of TOFF_MAX_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_TOFF_MAX_WARN_LIMIT            0x66
#define PMB_FLAGS_TOFF_MAX_WARN_LIMIT           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define POUT_OP_FAULT_LIMIT Command macros 
#define POUT_OP_FAULT_LIMIT                     POUT_OP_FAULT_LIMIT             ///< Identifier of POUT_OP_FAULT_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_POUT_OP_FAULT_LIMIT            0x68
#define PMB_FLAGS_POUT_OP_FAULT_LIMIT           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define POUT_OP_FAULT_RESPONSE Command macros 
#define POUT_OP_FAULT_RESPONSE                  POUT_OP_FAULT_RESPONSE          ///< Identifier of POUT_OP_FAULT_RESPONSE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_POUT_OP_FAULT_RESPONSE         0x69
#define PMB_FLAGS_POUT_OP_FAULT_RESPONSE        (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define POUT_OP_WARN_LIMIT Command macros 
#define POUT_OP_WARN_LIMIT                      POUT_OP_WARN_LIMIT              ///< Identifier of POUT_OP_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_POUT_OP_WARN_LIMIT             0x6A
#define PMB_FLAGS_POUT_OP_WARN_LIMIT            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define PIN_OP_WARN_LIMIT Command macros 
#define PIN_OP_WARN_LIMIT                       PIN_OP_WARN_LIMIT               ///< Identifier of PIN_OP_WARN_LIMIT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_PIN_OP_WARN_LIMIT              0x6B
#define PMB_FLAGS_PIN_OP_WARN_LIMIT             (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define STATUS_BYTE Command macros 
#define STATUS_BYTE                             STATUS_BYTE                     ///< Identifier of STATUS_BYTE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_BYTE                    0x78
#define PMB_FLAGS_STATUS_BYTE                   (PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_WORD Command macros 
#define STATUS_WORD                             STATUS_WORD                     ///< Identifier of STATUS_WORD command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_WORD                    0x79
#define PMB_FLAGS_STATUS_WORD                   (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define STATUS_VOUT Command macros 
#define STATUS_VOUT                             STATUS_VOUT                     ///< Identifier of STATUS_VOUT command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_VOUT                    0x7A
#define PMB_FLAGS_STATUS_VOUT                   (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_IOUT Command macros 
#define STATUS_IOUT                             STATUS_IOUT                     ///< Identifier of STATUS_IOUT command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_IOUT                    0x7B
#define PMB_FLAGS_STATUS_IOUT                   (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_INPUT Command macros 
#define STATUS_INPUT                            STATUS_INPUT                    ///< Identifier of STATUS_INPUT command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_INPUT                   0x7C
#define PMB_FLAGS_STATUS_INPUT                  (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_TEMPERATURE Command macros 
#define STATUS_TEMPERATURE                      STATUS_TEMPERATURE              ///< Identifier of STATUS_TEMPERATURE command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_TEMPERATURE             0x7D
#define PMB_FLAGS_STATUS_TEMPERATURE            (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_CML Command macros 
#define STATUS_CML                              STATUS_CML                      ///< Identifier of STATUS_CML command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_CML                     0x7E
#define PMB_FLAGS_STATUS_CML                    (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_OTHER Command macros 
#define STATUS_OTHER                            STATUS_OTHER                    ///< Identifier of STATUS_OTHER command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_OTHER                   0x7F
#define PMB_FLAGS_STATUS_OTHER                  (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_MFR_SPECIFIC Command macros 
#define STATUS_MFR_SPECIFIC                     STATUS_MFR_SPECIFIC             ///< Identifier of STATUS_MFR_SPECIFIC command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_MFR_SPECIFIC            0x80
#define PMB_FLAGS_STATUS_MFR_SPECIFIC           (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_FANS_1_2 Command macros 
#define STATUS_FANS_1_2                         STATUS_FANS_1_2                 ///< Identifier of STATUS_FANS_1_2 command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_FANS_1_2                0x81
#define PMB_FLAGS_STATUS_FANS_1_2               (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define STATUS_FANS_3_4 Command macros 
#define STATUS_FANS_3_4                         STATUS_FANS_3_4                 ///< Identifier of STATUS_FANS_3_4 command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_STATUS_FANS_3_4                0x82
#define PMB_FLAGS_STATUS_FANS_3_4               (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define READ_EIN Command macros 
#define READ_EIN                                READ_EIN                        ///< Identifier of READ_EIN command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_READ_EIN                       0x86
#define PMB_FLAGS_READ_EIN                      (PMB_CMD_FLAGS_READ_BLOCK)
// Define READ_EOUT Command macros 
#define READ_EOUT                               READ_EOUT                       ///< Identifier of READ_EOUT command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_READ_EOUT                      0x87
#define PMB_FLAGS_READ_EOUT                     (PMB_CMD_FLAGS_READ_BLOCK)
// Define READ_VIN Command macros 
#define READ_VIN                                READ_VIN                        ///< Identifier of READ_VIN command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_VIN                       0x88
#define PMB_FLAGS_READ_VIN                      (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_IIN Command macros 
#define READ_IIN                                READ_IIN                        ///< Identifier of READ_IIN command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_IIN                       0x89
#define PMB_FLAGS_READ_IIN                      (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_VCAP Command macros 
#define READ_VCAP                               READ_VCAP                       ///< Identifier of READ_VCAP command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_VCAP                      0x8A
#define PMB_FLAGS_READ_VCAP                     (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_VOUT Command macros 
#define READ_VOUT                               READ_VOUT                       ///< Identifier of READ_VOUT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_VOUT                      0x8B
#define PMB_FLAGS_READ_VOUT                     (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE)
// Define READ_IOUT Command macros 
#define READ_IOUT                               READ_IOUT                       ///< Identifier of READ_IOUT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_IOUT                      0x8C
#define PMB_FLAGS_READ_IOUT                     (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_TEMPERATURE_1 Command macros 
#define READ_TEMPERATURE_1                      READ_TEMPERATURE_1              ///< Identifier of READ_TEMPERATURE_1 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_TEMPERATURE_1             0x8D
#define PMB_FLAGS_READ_TEMPERATURE_1            (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_TEMPERATURE_2 Command macros 
#define READ_TEMPERATURE_2                      READ_TEMPERATURE_2              ///< Identifier of READ_TEMPERATURE_2 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_TEMPERATURE_2             0x8E
#define PMB_FLAGS_READ_TEMPERATURE_2            (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_TEMPERATURE_3 Command macros 
#define READ_TEMPERATURE_3                      READ_TEMPERATURE_3              ///< Identifier of READ_TEMPERATURE_3 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_TEMPERATURE_3             0x8F
#define PMB_FLAGS_READ_TEMPERATURE_3            (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_FAN_SPEED_1 Command macros 
#define READ_FAN_SPEED_1                        READ_FAN_SPEED_1                ///< Identifier of READ_FAN_SPEED_1 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_FAN_SPEED_1               0x90
#define PMB_FLAGS_READ_FAN_SPEED_1              (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_FAN_SPEED_2 Command macros 
#define READ_FAN_SPEED_2                        READ_FAN_SPEED_2                ///< Identifier of READ_FAN_SPEED_2 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_FAN_SPEED_2               0x91
#define PMB_FLAGS_READ_FAN_SPEED_2              (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_FAN_SPEED_3 Command macros 
#define READ_FAN_SPEED_3                        READ_FAN_SPEED_3                ///< Identifier of READ_FAN_SPEED_3 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_FAN_SPEED_3               0x92
#define PMB_FLAGS_READ_FAN_SPEED_3              (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_FAN_SPEED_4 Command macros 
#define READ_FAN_SPEED_4                        READ_FAN_SPEED_4                ///< Identifier of READ_FAN_SPEED_4 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_FAN_SPEED_4               0x93
#define PMB_FLAGS_READ_FAN_SPEED_4              (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_DUTY_CYCLE Command macros 
#define READ_DUTY_CYCLE                         READ_DUTY_CYCLE                 ///< Identifier of READ_DUTY_CYCLE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_DUTY_CYCLE                0x94
#define PMB_FLAGS_READ_DUTY_CYCLE               (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_FREQUENCY Command macros 
#define READ_FREQUENCY                          READ_FREQUENCY                  ///< Identifier of READ_FREQUENCY command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_FREQUENCY                 0x95
#define PMB_FLAGS_READ_FREQUENCY                (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_POUT Command macros 
#define READ_POUT                               READ_POUT                       ///< Identifier of READ_POUT command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_POUT                      0x96
#define PMB_FLAGS_READ_POUT                     (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define READ_PIN Command macros 
#define READ_PIN                                READ_PIN                        ///< Identifier of READ_PIN command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_READ_PIN                       0x97
#define PMB_FLAGS_READ_PIN                      (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define PMBUS_REVISION Command macros 
#define PMBUS_REVISION                          PMBUS_REVISION                  ///< Identifier of PMBUS_REVISION command. Use with ::PMBUS_CMD_INTERNAL() or with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_PMBUS_REVISION                 0x98
#define PMB_FLAGS_PMBUS_REVISION                (PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define MFR_ID Command macros 
#define MFR_ID                                  MFR_ID                          ///< Identifier of MFR_ID command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_ID                         0x99
#define PMB_FLAGS_MFR_ID                        (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_MODEL Command macros 
#define MFR_MODEL                               MFR_MODEL                       ///< Identifier of MFR_MODEL command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_MODEL                      0x9A
#define PMB_FLAGS_MFR_MODEL                     (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_REVISION Command macros 
#define MFR_REVISION                            MFR_REVISION                    ///< Identifier of MFR_REVISION command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_REVISION                   0x9B
#define PMB_FLAGS_MFR_REVISION                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_LOCATION Command macros 
#define MFR_LOCATION                            MFR_LOCATION                    ///< Identifier of MFR_LOCATION command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_LOCATION                   0x9C
#define PMB_FLAGS_MFR_LOCATION                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_DATE Command macros 
#define MFR_DATE                                MFR_DATE                        ///< Identifier of MFR_DATE command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_DATE                       0x9D
#define PMB_FLAGS_MFR_DATE                      (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_SERIAL Command macros 
#define MFR_SERIAL                              MFR_SERIAL                      ///< Identifier of MFR_SERIAL command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_SERIAL                     0x9E
#define PMB_FLAGS_MFR_SERIAL                    (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define APP_PROFILE_SUPPORT Command macros 
#define APP_PROFILE_SUPPORT                     APP_PROFILE_SUPPORT             ///< Identifier of APP_PROFILE_SUPPORT command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_APP_PROFILE_SUPPORT            0x9F
#define PMB_FLAGS_APP_PROFILE_SUPPORT           (PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_VIN_MIN Command macros 
#define MFR_VIN_MIN                             MFR_VIN_MIN                     ///< Identifier of MFR_VIN_MIN command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_VIN_MIN                    0xA0
#define PMB_FLAGS_MFR_VIN_MIN                   (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_VIN_MAX Command macros 
#define MFR_VIN_MAX                             MFR_VIN_MAX                     ///< Identifier of MFR_VIN_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_VIN_MAX                    0xA1
#define PMB_FLAGS_MFR_VIN_MAX                   (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_IIN_MAX Command macros 
#define MFR_IIN_MAX                             MFR_IIN_MAX                     ///< Identifier of MFR_IIN_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_IIN_MAX                    0xA2
#define PMB_FLAGS_MFR_IIN_MAX                   (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_PIN_MAX Command macros 
#define MFR_PIN_MAX                             MFR_PIN_MAX                     ///< Identifier of MFR_PIN_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_PIN_MAX                    0xA3
#define PMB_FLAGS_MFR_PIN_MAX                   (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_VOUT_MIN Command macros 
#define MFR_VOUT_MIN                            MFR_VOUT_MIN                    ///< Identifier of MFR_VOUT_MIN command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_VOUT_MIN                   0xA4
#define PMB_FLAGS_MFR_VOUT_MIN                  (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_VOUT_MAX Command macros 
#define MFR_VOUT_MAX                            MFR_VOUT_MAX                    ///< Identifier of MFR_VOUT_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_VOUT_MAX                   0xA5
#define PMB_FLAGS_MFR_VOUT_MAX                  (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_IOUT_MAX Command macros 
#define MFR_IOUT_MAX                            MFR_IOUT_MAX                    ///< Identifier of MFR_IOUT_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_IOUT_MAX                   0xA6
#define PMB_FLAGS_MFR_IOUT_MAX                  (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_POUT_MAX Command macros 
#define MFR_POUT_MAX                            MFR_POUT_MAX                    ///< Identifier of MFR_POUT_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_POUT_MAX                   0xA7
#define PMB_FLAGS_MFR_POUT_MAX                  (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_TAMBIENT_MAX Command macros 
#define MFR_TAMBIENT_MAX                        MFR_TAMBIENT_MAX                ///< Identifier of MFR_TAMBIENT_MAX command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_TAMBIENT_MAX               0xA8
#define PMB_FLAGS_MFR_TAMBIENT_MAX              (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_TAMBIENT_MIN Command macros 
#define MFR_TAMBIENT_MIN                        MFR_TAMBIENT_MIN                ///< Identifier of MFR_TAMBIENT_MIN command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_TAMBIENT_MIN               0xA9
#define PMB_FLAGS_MFR_TAMBIENT_MIN              (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_EFFICIENCY_LL Command macros 
#define MFR_EFFICIENCY_LL                       MFR_EFFICIENCY_LL               ///< Identifier of MFR_EFFICIENCY_LL command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_EFFICIENCY_LL              0xAA
#define PMB_FLAGS_MFR_EFFICIENCY_LL             (PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_EFFICIENCY_HL Command macros 
#define MFR_EFFICIENCY_HL                       MFR_EFFICIENCY_HL               ///< Identifier of MFR_EFFICIENCY_HL command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_MFR_EFFICIENCY_HL              0xAB
#define PMB_FLAGS_MFR_EFFICIENCY_HL             (PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_PIN_ACCURACY Command macros 
#define MFR_PIN_ACCURACY                        MFR_PIN_ACCURACY                ///< Identifier of MFR_PIN_ACCURACY command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_PIN_ACCURACY               0xAC
#define PMB_FLAGS_MFR_PIN_ACCURACY              (PMB_CMD_FLAGS_READ_BYTE_WORD)
// Define IC_DEVICE_ID Command macros 
#define IC_DEVICE_ID                            IC_DEVICE_ID                    ///< Identifier of IC_DEVICE_ID command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_IC_DEVICE_ID                   0xAD
#define PMB_FLAGS_IC_DEVICE_ID                  (PMB_CMD_FLAGS_READ_BLOCK)
// Define IC_DEVICE_REV Command macros 
#define IC_DEVICE_REV                           IC_DEVICE_REV                   ///< Identifier of IC_DEVICE_REV command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_IC_DEVICE_REV                  0xAE
#define PMB_FLAGS_IC_DEVICE_REV                 (PMB_CMD_FLAGS_READ_BLOCK)
// // Define USER_DATA_00 Command macros 
// #define USER_DATA_00                            USER_DATA_00                    ///< Identifier of USER_DATA_00 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
// #define PMB_CODE_USER_DATA_00                   0xB0
// #define PMB_FLAGS_USER_DATA_00                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// // Define USER_DATA_01 Command macros 
// #define USER_DATA_01                            USER_DATA_01                    ///< Identifier of USER_DATA_01 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
// #define PMB_CODE_USER_DATA_01                   0xB1
// #define PMB_FLAGS_USER_DATA_01                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// // Define USER_DATA_02 Command macros 
// #define USER_DATA_02                            USER_DATA_02                    ///< Identifier of USER_DATA_02 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
// #define PMB_CODE_USER_DATA_02                   0xB2
// #define PMB_FLAGS_USER_DATA_02                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// // Define USER_DATA_03 Command macros 
// #define USER_DATA_03                            USER_DATA_03                    ///< Identifier of USER_DATA_03 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
// #define PMB_CODE_USER_DATA_03                   0xB3
// #define PMB_FLAGS_USER_DATA_03                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_04 Command macros 
#define USER_DATA_04                            USER_DATA_04                    ///< Identifier of USER_DATA_04 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_04                   0xB4
#define PMB_FLAGS_USER_DATA_04                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_05 Command macros 
#define USER_DATA_05                            USER_DATA_05                    ///< Identifier of USER_DATA_05 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_05                   0xB5
#define PMB_FLAGS_USER_DATA_05                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_06 Command macros 
#define USER_DATA_06                            USER_DATA_06                    ///< Identifier of USER_DATA_06 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_06                   0xB6
#define PMB_FLAGS_USER_DATA_06                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_07 Command macros 
#define USER_DATA_07                            USER_DATA_07                    ///< Identifier of USER_DATA_07 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_07                   0xB7
#define PMB_FLAGS_USER_DATA_07                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_08 Command macros 
#define USER_DATA_08                            USER_DATA_08                    ///< Identifier of USER_DATA_08 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_08                   0xB8
#define PMB_FLAGS_USER_DATA_08                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_09 Command macros 
#define USER_DATA_09                            USER_DATA_09                    ///< Identifier of USER_DATA_09 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_09                   0xB9
#define PMB_FLAGS_USER_DATA_09                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_10 Command macros 
#define USER_DATA_10                            USER_DATA_10                    ///< Identifier of USER_DATA_10 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_10                   0xBA
#define PMB_FLAGS_USER_DATA_10                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_11 Command macros 
#define USER_DATA_11                            USER_DATA_11                    ///< Identifier of USER_DATA_11 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_11                   0xBB
#define PMB_FLAGS_USER_DATA_11                  (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD) //(PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_12 Command macros 
#define USER_DATA_12                            USER_DATA_12                    ///< Identifier of USER_DATA_12 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_12                   0xBC
#define PMB_FLAGS_USER_DATA_12                  (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD) //(PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_13 Command macros 
#define USER_DATA_13                            USER_DATA_13                    ///< Identifier of USER_DATA_13 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_13                   0xBD
#define PMB_FLAGS_USER_DATA_13                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_14 Command macros 
#define USER_DATA_14                            USER_DATA_14                    ///< Identifier of USER_DATA_14 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_14                   0xBE
#define PMB_FLAGS_USER_DATA_14                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define USER_DATA_15 Command macros 
#define USER_DATA_15                            USER_DATA_15                    ///< Identifier of USER_DATA_15 command. Use with ::PMBUS_CMD_DATA_BLOCK() macro. @hideinitializer
#define PMB_CODE_USER_DATA_15                   0xBF
#define PMB_FLAGS_USER_DATA_15                  (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)
// Define MFR_MAX_TEMP_1 Command macros 
#define MFR_MAX_TEMP_1                          MFR_MAX_TEMP_1                  ///< Identifier of MFR_MAX_TEMP_1 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_MAX_TEMP_1                 0xC0
#define PMB_FLAGS_MFR_MAX_TEMP_1                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_MAX_TEMP_2 Command macros 
#define MFR_MAX_TEMP_2                          MFR_MAX_TEMP_2                  ///< Identifier of MFR_MAX_TEMP_2 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_MAX_TEMP_2                 0xC1
#define PMB_FLAGS_MFR_MAX_TEMP_2                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)
// Define MFR_MAX_TEMP_3 Command macros 
#define MFR_MAX_TEMP_3                          MFR_MAX_TEMP_3                  ///< Identifier of MFR_MAX_TEMP_3 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_MFR_MAX_TEMP_3                 0xC2
#define PMB_FLAGS_MFR_MAX_TEMP_3                (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)

#define CAL_MODE                                CAL_MODE                        ///< Identifier of CAL_MODE command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_CAL_MODE                       0xCC
#define PMB_FLAGS_CAL_MODE                      (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)

#define CAL_LIFE                                CAL_LIFE                        ///< Identifier of MFR_MAX_TEMP_3 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_CAL_LIFE                       0xCD
#define PMB_FLAGS_CAL_LIFE                      (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)

#define CAL_DATA_1                              CAL_DATA_1                      ///< Identifier of MFR_MAX_TEMP_3 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_CAL_DATA_1                     0xCE
#define PMB_FLAGS_CAL_DATA_1                    (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)

#define CAL_DATA_2                              CAL_DATA_2                      ///< Identifier of MFR_MAX_TEMP_3 command. Use with ::PMBUS_CMD_SIMPLE() macro. @hideinitializer
#define PMB_CODE_CAL_DATA_2                     0xCF
#define PMB_FLAGS_CAL_DATA_2                    (PMB_CMD_FLAGS_WRITE_BLOCK|PMB_CMD_FLAGS_READ_BLOCK)

// Define MFR_SPECIFIC_00 Command macros 
#define MFR_SPECIFIC_00                         MFR_SPECIFIC_00                 ///< Identifier of MFR_SPECIFIC_00 command. Make sure the  @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_00" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_00                0xD0
#ifndef PMB_FLAGS_MFR_SPECIFIC_00
#define PMB_FLAGS_MFR_SPECIFIC_00               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_00 macro in pmbus_cfg.h file)
#endif

#define MFR_FW_ID                               MFR_FW_ID
#define PMB_CODE_MFR_FW_ID                      0xD1
#define PMB_FLAGS_MFR_FW_ID                    (PMB_CMD_FLAGS_READ_BLOCK)

#define MFR_FW_REVISION                         MFR_FW_REVISION
#define PMB_CODE_MFR_FW_REVISION                0xD2
#define PMB_FLAGS_MFR_FW_REVISION              (PMB_CMD_FLAGS_READ_BLOCK)

// Define MFR_SPECIFIC_03 Command macros 
#define MFR_SPECIFIC_03                         MFR_SPECIFIC_03                 ///< Identifier of MFR_SPECIFIC_03 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_03" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_03                0xD3
#ifndef PMB_FLAGS_MFR_SPECIFIC_03
#define PMB_FLAGS_MFR_SPECIFIC_03               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_03 macro in pmbus_cfg.h file)
#endif

#define MFR_FW_DATE                             MFR_FW_DATE
#define PMB_CODE_MFR_FW_DATE                    0xD4
#define PMB_FLAGS_MFR_FW_DATE                  (PMB_CMD_FLAGS_READ_BLOCK)

#define CONTROL_FAN_DUTY                        CONTROL_FAN_DUTY
#define PMB_CODE_CONTROL_FAN_DUTY               0xD5
#define PMB_FLAGS_CONTROL_FAN_DUTY             (PMB_CMD_FLAGS_READ_BYTE_WORD)

// Define MFR_SPECIFIC_06 Command macros 
#define MFR_SPECIFIC_06                         MFR_SPECIFIC_06                 ///< Identifier of MFR_SPECIFIC_06 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_06" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_06                0xD6
#ifndef PMB_FLAGS_MFR_SPECIFIC_06
#define PMB_FLAGS_MFR_SPECIFIC_06               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_06 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_07 Command macros 
#define MFR_SPECIFIC_07                         MFR_SPECIFIC_07                 ///< Identifier of MFR_SPECIFIC_07 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_07" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_07                0xD7
#ifndef PMB_FLAGS_MFR_SPECIFIC_07
#define PMB_FLAGS_MFR_SPECIFIC_07               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_07 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_08 Command macros 
#define MFR_SPECIFIC_08                         MFR_SPECIFIC_08                 ///< Identifier of MFR_SPECIFIC_08 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_08" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_08                0xD8
#ifndef PMB_FLAGS_MFR_SPECIFIC_08
#define PMB_FLAGS_MFR_SPECIFIC_08               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_08 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_09 Command macros 
#define MFR_SPECIFIC_09                         MFR_SPECIFIC_09                 ///< Identifier of MFR_SPECIFIC_09 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_09" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_09                0xD9
#ifndef PMB_FLAGS_MFR_SPECIFIC_09
#define PMB_FLAGS_MFR_SPECIFIC_09               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_09 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_10 Command macros 
#define MFR_SPECIFIC_10                         MFR_SPECIFIC_10                 ///< Identifier of MFR_SPECIFIC_10 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_10" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_10                0xDA
#ifndef PMB_FLAGS_MFR_SPECIFIC_10
#define PMB_FLAGS_MFR_SPECIFIC_10               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_10 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_11 Command macros 
#define MFR_SPECIFIC_11                         MFR_SPECIFIC_11                 ///< Identifier of MFR_SPECIFIC_11 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_11" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_11                0xDB
#ifndef PMB_FLAGS_MFR_SPECIFIC_11
#define PMB_FLAGS_MFR_SPECIFIC_11               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_11 macro in pmbus_cfg.h file)
#endif

#define BLACK_BOX_DATA                          BLACK_BOX_DATA
#define PMB_CODE_BLACK_BOX_DATA                 0xDC
#define PMB_FLAGS_BLACK_BOX_DATA               (PMB_CMD_FLAGS_READ_BLOCK)

#define BLACK_BOX_REAL_TIME                     BLACK_BOX_REAL_TIME
#define PMB_CODE_BLACK_BOX_REAL_TIME            0xDD
#define PMB_FLAGS_BLACK_BOX_REAL_TIME          (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)

// Define MFR_SPECIFIC_14 Command macros 
#define MFR_SPECIFIC_14                         MFR_SPECIFIC_14                 ///< Identifier of MFR_SPECIFIC_14 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_14" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_14                0xDE
#ifndef PMB_FLAGS_MFR_SPECIFIC_14
#define PMB_FLAGS_MFR_SPECIFIC_14               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_14 macro in pmbus_cfg.h file)
#endif

#define BLACK_BOX_CONFIG                        BLACK_BOX_CONFIG
#define PMB_CODE_BLACK_BOX_CONFIG               0xDF
#define PMB_FLAGS_BLACK_BOX_CONFIG             (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)

#define BLACK_BOX_CLEAR                         BLACK_BOX_CLEAR
#define PMB_CODE_BLACK_BOX_CLEAR                0xE0
#define PMB_FLAGS_BLACK_BOX_CLEAR              (PMB_CMD_FLAGS_WRITE_BYTE_WORD|PMB_CMD_FLAGS_READ_BYTE_WORD)

// Define MFR_SPECIFIC_17 Command macros 
#define MFR_SPECIFIC_17                         MFR_SPECIFIC_17                 ///< Identifier of MFR_SPECIFIC_17 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_17" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_17                0xE1
#ifndef PMB_FLAGS_MFR_SPECIFIC_17
#define PMB_FLAGS_MFR_SPECIFIC_17               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_17 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_18 Command macros 
#define MFR_SPECIFIC_18                         MFR_SPECIFIC_18                 ///< Identifier of MFR_SPECIFIC_18 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_18" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_18                0xE2
#ifndef PMB_FLAGS_MFR_SPECIFIC_18
#define PMB_FLAGS_MFR_SPECIFIC_18               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_18 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_19 Command macros 
#define MFR_SPECIFIC_19                         MFR_SPECIFIC_19                 ///< Identifier of MFR_SPECIFIC_19 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_19" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_19                0xE3
#ifndef PMB_FLAGS_MFR_SPECIFIC_19
#define PMB_FLAGS_MFR_SPECIFIC_19               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_19 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_20 Command macros 
#define MFR_SPECIFIC_20                         MFR_SPECIFIC_20                 ///< Identifier of MFR_SPECIFIC_20 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_20" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_20                0xE4
#ifndef PMB_FLAGS_MFR_SPECIFIC_20
#define PMB_FLAGS_MFR_SPECIFIC_20               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_20 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_21 Command macros 
#define MFR_SPECIFIC_21                         MFR_SPECIFIC_21                 ///< Identifier of MFR_SPECIFIC_21 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_21" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_21                0xE5
#ifndef PMB_FLAGS_MFR_SPECIFIC_21
#define PMB_FLAGS_MFR_SPECIFIC_21               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_21 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_22 Command macros 
#define MFR_SPECIFIC_22                         MFR_SPECIFIC_22                 ///< Identifier of MFR_SPECIFIC_22 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_22" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_22                0xE6
#ifndef PMB_FLAGS_MFR_SPECIFIC_22
#define PMB_FLAGS_MFR_SPECIFIC_22               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_22 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_23 Command macros 
#define MFR_SPECIFIC_23                         MFR_SPECIFIC_23                 ///< Identifier of MFR_SPECIFIC_23 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_23" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_23                0xE7
#ifndef PMB_FLAGS_MFR_SPECIFIC_23
#define PMB_FLAGS_MFR_SPECIFIC_23               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_23 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_24 Command macros 
#define MFR_SPECIFIC_24                         MFR_SPECIFIC_24                 ///< Identifier of MFR_SPECIFIC_24 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_24" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_24                0xE8
#ifndef PMB_FLAGS_MFR_SPECIFIC_24
#define PMB_FLAGS_MFR_SPECIFIC_24               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_24 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_25 Command macros 
#define MFR_SPECIFIC_25                         MFR_SPECIFIC_25                 ///< Identifier of MFR_SPECIFIC_25 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_25" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_25                0xE9
#ifndef PMB_FLAGS_MFR_SPECIFIC_25
#define PMB_FLAGS_MFR_SPECIFIC_25               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_25 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_26 Command macros 
#define MFR_SPECIFIC_26                         MFR_SPECIFIC_26                 ///< Identifier of MFR_SPECIFIC_26 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_26" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_26                0xEA
#ifndef PMB_FLAGS_MFR_SPECIFIC_26
#define PMB_FLAGS_MFR_SPECIFIC_26               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_26 macro in pmbus_cfg.h file)
#endif
 // Define MFR_SPECIFIC_27 Command macros 
 #define MFR_SPECIFIC_27                         MFR_SPECIFIC_27                 ///< Identifier of MFR_SPECIFIC_27 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_27" command flags are defined in pmbus_cfg.h file. @hideinitializer
 #define PMB_CODE_MFR_SPECIFIC_27                0xEB
 #ifndef PMB_FLAGS_MFR_SPECIFIC_27
 #define PMB_FLAGS_MFR_SPECIFIC_27               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_27 macro in pmbus_cfg.h file)
 #endif
// Define MFR_SPECIFIC_28 Command macros 
#define MFR_SPECIFIC_28                         MFR_SPECIFIC_28                 ///< Identifier of MFR_SPECIFIC_28 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_28" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_28                0xEC
#ifndef PMB_FLAGS_MFR_SPECIFIC_28
#define PMB_FLAGS_MFR_SPECIFIC_28               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_28 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_29 Command macros 
#define MFR_SPECIFIC_29                         MFR_SPECIFIC_29                 ///< Identifier of MFR_SPECIFIC_29 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_29" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_29                0xED
#ifndef PMB_FLAGS_MFR_SPECIFIC_29
#define PMB_FLAGS_MFR_SPECIFIC_29               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_29 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_30 Command macros 
#define MFR_SPECIFIC_30                         MFR_SPECIFIC_30                 ///< Identifier of MFR_SPECIFIC_30 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_30" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_30                0xEE
#ifndef PMB_FLAGS_MFR_SPECIFIC_30
#define PMB_FLAGS_MFR_SPECIFIC_30               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_30 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_31 Command macros 
#define MFR_SPECIFIC_31                         MFR_SPECIFIC_31                 ///< Identifier of MFR_SPECIFIC_31 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_31" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_31                0xEF
#ifndef PMB_FLAGS_MFR_SPECIFIC_31
#define PMB_FLAGS_MFR_SPECIFIC_31               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_31 macro in pmbus_cfg.h file)
#endif

#define BOOTLOADER_KEY                          BOOTLOADER_KEY
#define PMB_CODE_BOOTLOADER_KEY                 0xF0
#define PMB_FLAGS_BOOTLOADER_KEY               (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WRITE_BYTE_WORD)

#define BOOTLOADER_STATUS                       BOOTLOADER_STATUS
#define PMB_CODE_BOOTLOADER_STATUS              0xF1
#define PMB_FLAGS_BOOTLOADER_STATUS            (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WRITE_BYTE_WORD)

#define BOOTLOADER_DATE_WRITE                   BOOTLOADER_DATE_WRITE
#define PMB_CODE_BOOTLOADER_DATE_WRITE          0xF2
#define PMB_FLAGS_BOOTLOADER_DATE_WRITE        (PMB_CMD_FLAGS_READ_BLOCK|PMB_CMD_FLAGS_WRITE_BLOCK)

#define BOOTLOADER_PRODUCT_KEY                  BOOTLOADER_PRODUCT_KEY 
#define PMB_CODE_BOOTLOADER_PRODUCT_KEY         0xF3
#define PMB_FLAGS_BOOTLOADER_PRODUCT_KEY       (PMB_CMD_FLAGS_READ_BYTE_WORD|PMB_CMD_FLAGS_WORD_SIZE)

#define ADC_DATA                                ADC_DATA  
#define PMB_CODE_ADC_DATA                       0xF4
#define PMB_FLAGS_ADC_DATA                     (PMB_CMD_FLAGS_READ_BLOCK)

// Define MFR_SPECIFIC_37 Command macros 
#define MFR_SPECIFIC_37                         MFR_SPECIFIC_37                 ///< Identifier of MFR_SPECIFIC_37 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_37" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_37                0xF5
#ifndef PMB_FLAGS_MFR_SPECIFIC_37
#define PMB_FLAGS_MFR_SPECIFIC_37               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_37 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_38 Command macros 
#define MFR_SPECIFIC_38                         MFR_SPECIFIC_38                 ///< Identifier of MFR_SPECIFIC_38 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_38" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_38                0xF6
#ifndef PMB_FLAGS_MFR_SPECIFIC_38
#define PMB_FLAGS_MFR_SPECIFIC_38               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_38 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_39 Command macros 
#define MFR_SPECIFIC_39                         MFR_SPECIFIC_39                 ///< Identifier of MFR_SPECIFIC_39 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_39" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_39                0xF7
#ifndef PMB_FLAGS_MFR_SPECIFIC_39
#define PMB_FLAGS_MFR_SPECIFIC_39               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_39 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_40 Command macros 
#define MFR_SPECIFIC_40                         MFR_SPECIFIC_40                 ///< Identifier of MFR_SPECIFIC_40 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_40" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_40                0xF8
#ifndef PMB_FLAGS_MFR_SPECIFIC_40
#define PMB_FLAGS_MFR_SPECIFIC_40               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_40 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_41 Command macros 
#define MFR_SPECIFIC_41                         MFR_SPECIFIC_41                 ///< Identifier of MFR_SPECIFIC_41 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_41" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_41                0xF9
#ifndef PMB_FLAGS_MFR_SPECIFIC_41
#define PMB_FLAGS_MFR_SPECIFIC_41               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_41 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_42 Command macros 
#define MFR_SPECIFIC_42                         MFR_SPECIFIC_42                 ///< Identifier of MFR_SPECIFIC_42 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_42" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_42                0xFA
#ifndef PMB_FLAGS_MFR_SPECIFIC_42
#define PMB_FLAGS_MFR_SPECIFIC_42               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_42 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_43 Command macros 
#define MFR_SPECIFIC_43                         MFR_SPECIFIC_43                 ///< Identifier of MFR_SPECIFIC_43 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_43" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_43                0xFB
#ifndef PMB_FLAGS_MFR_SPECIFIC_43
#define PMB_FLAGS_MFR_SPECIFIC_43               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_43 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_44 Command macros 
#define MFR_SPECIFIC_44                         MFR_SPECIFIC_44                 ///< Identifier of MFR_SPECIFIC_44 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_44" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_44                0xFC
#ifndef PMB_FLAGS_MFR_SPECIFIC_44
#define PMB_FLAGS_MFR_SPECIFIC_44               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_44 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_45 Command macros 
#define MFR_SPECIFIC_45                         MFR_SPECIFIC_45                 ///< Identifier of MFR_SPECIFIC_45 command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_xx "PMBCFG_CMD_FLAGS_MFR_SPECIFIC_45" command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_45                0xFD
#ifndef PMB_FLAGS_MFR_SPECIFIC_45
#define PMB_FLAGS_MFR_SPECIFIC_45               (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_45 macro in pmbus_cfg.h file)
#endif
// Define MFR_SPECIFIC_COMMAND_EXT Command macros 
#define MFR_SPECIFIC_COMMAND_EXT                MFR_SPECIFIC_COMMAND_EXT        ///< Identifier of MFR_SPECIFIC_COMMAND_EXT command. Make sure the @ref PMBCFG_CMD_FLAGS_MFR_SPECIFIC_COMMAND_EXT command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_MFR_SPECIFIC_COMMAND_EXT       0xFE
#define PMB_FLAGS_MFR_SPECIFIC_COMMAND_EXT      (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_MFR_SPECIFIC_COMMAND_EXT macro in pmbus_cfg.h file)
// Define PMBUS_COMMAND_EXT Command macros 
#define PMBUS_COMMAND_EXT                       PMBUS_COMMAND_EXT               ///< Identifier of PMBUS_COMMAND_EXT command. Please make sure the @ref PMBCFG_CMD_FLAGS_PMBUS_COMMAND_EXT command flags are defined in pmbus_cfg.h file. @hideinitializer
#define PMB_CODE_PMBUS_COMMAND_EXT              0xFF
#ifndef PMB_FLAGS_PMBUS_COMMAND_EXT
#define PMB_FLAGS_PMBUS_COMMAND_EXT             (Command flags are not defined, please define flags in PMBCFG_CMD_FLAGS_PMBUS_COMMAND_EXT macro in pmbus_cfg.h file)
#endif

/*! @} End of pmbus_command_list */

#endif /* __PMBUS_CMD_H */
