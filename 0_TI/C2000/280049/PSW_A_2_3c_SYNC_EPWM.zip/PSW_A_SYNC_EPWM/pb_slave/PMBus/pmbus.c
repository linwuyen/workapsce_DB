/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   pmbus.c
*
* @brief  PMBus source codes of internal and API functions
*
* @version 1.0.18.0
* 
* @date Jun-22-2012
* 
*******************************************************************************
*//*! 
* @defgroup internal_functions Internal Functions
* @brief Functions used internally by the PMBus stack.
* @details These functions are not supported to be called from an application. 
* It may be honor helpful to see how functions are implemented.
*
*******************************************************************************
*//*! 
*	@defgroup internal_commands Internal Command Handlers
*	@ingroup internal_functions
*
*******************************************************************************
*//*! 
*	@defgroup aditional_function Support Functions
*	@ingroup internal_functions
*/

#include "pmbus.h"

//include communication interface
#if PMBCFG_USE_SMBUS_DRIVER
#include "smbus_slave.h"
#endif

PMB_STRUCT pmb_struct;

#if PMBCFG_USE_CAPABILITY
const PMBUS_PAGE_MEMBER pmb_const_capability_code = ((PMBCFG_CAPABILITY_PEC_SUPPORTED ? PMB_CAPABILITY_PEC_USE : 0) | (PMBCFG_CAPABILITY_MAX_SPEED ? PMB_CAPABILITY_MAX_SPEED_400 : PMB_CAPABILITY_MAX_SPEED_100) | (PMBCFG_CAPABILITY_SMBUSALERT_SUPPORTED ? PMB_CAPABILITY_SMBALERT_USE : 0));
#endif
#if PMBCFG_CONST_VOUT_MODE
const PMBUS_PAGE_MEMBER pmb_const_vout_mode = PMBCFG_VOUT_MODE_DEF_VAL;
#endif
#if PMBCFG_USE_PMBUS_REVISION
const PMBUS_PAGE_MEMBER pmb_const_pmbus_revision = PMB_REVISION_INIT;
#endif

// defines table of DIRECT coefficients groups
#define PMB_COEF_GRP_VALID
#define PMB_COEF_GRP_INIT(grp) PMBCFG_COEF_GRP_##grp##_CONST_M, PMBCFG_COEF_GRP_##grp##_CONST_B, PMBCFG_COEF_GRP_##grp##_CONST_R

const PMBUS_COEF_GRP_ENTRY pmb_coef_grp_table[]=
{
#if (!(defined(PMBCFG_COEF_GRP_0_CONST_M) && defined(PMBCFG_COEF_GRP_0_CONST_M)&&defined(PMBCFG_COEF_GRP_0_CONST_R)))
  0,0,0
#else
#if defined(PMBCFG_COEF_GRP_0_CONST_M) && defined(PMBCFG_COEF_GRP_0_CONST_B) && defined(PMBCFG_COEF_GRP_0_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(0),
#else
  #undef PMB_COEF_GRP_VALID
#endif

#if defined(PMBCFG_COEF_GRP_1_CONST_M) && defined(PMBCFG_COEF_GRP_1_CONST_B) && defined(PMBCFG_COEF_GRP_1_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(1),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_1_CONST_M) && defined(PMBCFG_COEF_GRP_1_CONST_B) && defined(PMBCFG_COEF_GRP_1_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_2_CONST_M) && defined(PMBCFG_COEF_GRP_2_CONST_B) && defined(PMBCFG_COEF_GRP_2_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(2),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_2_CONST_M) && defined(PMBCFG_COEF_GRP_2_CONST_B) && defined(PMBCFG_COEF_GRP_2_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_3_CONST_M) && defined(PMBCFG_COEF_GRP_3_CONST_B) && defined(PMBCFG_COEF_GRP_3_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(3),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_3_CONST_M) && defined(PMBCFG_COEF_GRP_3_CONST_B) && defined(PMBCFG_COEF_GRP_3_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_4_CONST_M) && defined(PMBCFG_COEF_GRP_4_CONST_B) && defined(PMBCFG_COEF_GRP_4_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(4),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_4_CONST_M) && defined(PMBCFG_COEF_GRP_4_CONST_B) && defined(PMBCFG_COEF_GRP_4_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_5_CONST_M) && defined(PMBCFG_COEF_GRP_5_CONST_B) && defined(PMBCFG_COEF_GRP_5_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(5),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_5_CONST_M) && defined(PMBCFG_COEF_GRP_5_CONST_B) && defined(PMBCFG_COEF_GRP_5_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_6_CONST_M) && defined(PMBCFG_COEF_GRP_6_CONST_B) && defined(PMBCFG_COEF_GRP_6_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(6),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_6_CONST_M) && defined(PMBCFG_COEF_GRP_6_CONST_B) && defined(PMBCFG_COEF_GRP_6_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_7_CONST_M) && defined(PMBCFG_COEF_GRP_7_CONST_B) && defined(PMBCFG_COEF_GRP_7_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(7),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_7_CONST_M) && defined(PMBCFG_COEF_GRP_7_CONST_B) && defined(PMBCFG_COEF_GRP_7_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_8_CONST_M) && defined(PMBCFG_COEF_GRP_8_CONST_B) && defined(PMBCFG_COEF_GRP_8_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(8),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_8_CONST_M) && defined(PMBCFG_COEF_GRP_8_CONST_B) && defined(PMBCFG_COEF_GRP_8_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_9_CONST_M) && defined(PMBCFG_COEF_GRP_9_CONST_B) && defined(PMBCFG_COEF_GRP_9_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(9),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_9_CONST_M) && defined(PMBCFG_COEF_GRP_9_CONST_B) && defined(PMBCFG_COEF_GRP_9_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_10_CONST_M) && defined(PMBCFG_COEF_GRP_10_CONST_B) && defined(PMBCFG_COEF_GRP_10_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(10),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_10_CONST_M) && defined(PMBCFG_COEF_GRP_10_CONST_B) && defined(PMBCFG_COEF_GRP_10_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_11_CONST_M) && defined(PMBCFG_COEF_GRP_11_CONST_B) && defined(PMBCFG_COEF_GRP_11_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(11),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_11_CONST_M) && defined(PMBCFG_COEF_GRP_11_CONST_B) && defined(PMBCFG_COEF_GRP_11_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_12_CONST_M) && defined(PMBCFG_COEF_GRP_12_CONST_B) && defined(PMBCFG_COEF_GRP_12_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(12),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_12_CONST_M) && defined(PMBCFG_COEF_GRP_12_CONST_B) && defined(PMBCFG_COEF_GRP_12_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_13_CONST_M) && defined(PMBCFG_COEF_GRP_13_CONST_B) && defined(PMBCFG_COEF_GRP_13_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(13),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_13_CONST_M) && defined(PMBCFG_COEF_GRP_13_CONST_B) && defined(PMBCFG_COEF_GRP_13_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_14_CONST_M) && defined(PMBCFG_COEF_GRP_14_CONST_B) && defined(PMBCFG_COEF_GRP_14_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(14),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_14_CONST_M) && defined(PMBCFG_COEF_GRP_14_CONST_B) && defined(PMBCFG_COEF_GRP_14_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_15_CONST_M) && defined(PMBCFG_COEF_GRP_15_CONST_B) && defined(PMBCFG_COEF_GRP_15_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(15),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_15_CONST_M) && defined(PMBCFG_COEF_GRP_15_CONST_B) && defined(PMBCFG_COEF_GRP_15_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_16_CONST_M) && defined(PMBCFG_COEF_GRP_16_CONST_B) && defined(PMBCFG_COEF_GRP_16_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(16),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_16_CONST_M) && defined(PMBCFG_COEF_GRP_16_CONST_B) && defined(PMBCFG_COEF_GRP_16_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_17_CONST_M) && defined(PMBCFG_COEF_GRP_17_CONST_B) && defined(PMBCFG_COEF_GRP_17_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(17),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_17_CONST_M) && defined(PMBCFG_COEF_GRP_17_CONST_B) && defined(PMBCFG_COEF_GRP_17_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_18_CONST_M) && defined(PMBCFG_COEF_GRP_18_CONST_B) && defined(PMBCFG_COEF_GRP_18_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(18),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_18_CONST_M) && defined(PMBCFG_COEF_GRP_18_CONST_B) && defined(PMBCFG_COEF_GRP_18_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_19_CONST_M) && defined(PMBCFG_COEF_GRP_19_CONST_B) && defined(PMBCFG_COEF_GRP_19_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(19),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_19_CONST_M) && defined(PMBCFG_COEF_GRP_19_CONST_B) && defined(PMBCFG_COEF_GRP_19_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_20_CONST_M) && defined(PMBCFG_COEF_GRP_20_CONST_B) && defined(PMBCFG_COEF_GRP_20_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(20),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_20_CONST_M) && defined(PMBCFG_COEF_GRP_20_CONST_B) && defined(PMBCFG_COEF_GRP_20_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_21_CONST_M) && defined(PMBCFG_COEF_GRP_21_CONST_B) && defined(PMBCFG_COEF_GRP_21_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(21),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_21_CONST_M) && defined(PMBCFG_COEF_GRP_21_CONST_B) && defined(PMBCFG_COEF_GRP_21_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_22_CONST_M) && defined(PMBCFG_COEF_GRP_22_CONST_B) && defined(PMBCFG_COEF_GRP_22_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(22),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_22_CONST_M) && defined(PMBCFG_COEF_GRP_22_CONST_B) && defined(PMBCFG_COEF_GRP_22_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_23_CONST_M) && defined(PMBCFG_COEF_GRP_23_CONST_B) && defined(PMBCFG_COEF_GRP_23_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(23),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_23_CONST_M) && defined(PMBCFG_COEF_GRP_23_CONST_B) && defined(PMBCFG_COEF_GRP_23_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_24_CONST_M) && defined(PMBCFG_COEF_GRP_24_CONST_B) && defined(PMBCFG_COEF_GRP_24_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(24),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_24_CONST_M) && defined(PMBCFG_COEF_GRP_24_CONST_B) && defined(PMBCFG_COEF_GRP_24_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_25_CONST_M) && defined(PMBCFG_COEF_GRP_25_CONST_B) && defined(PMBCFG_COEF_GRP_25_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(25),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_25_CONST_M) && defined(PMBCFG_COEF_GRP_25_CONST_B) && defined(PMBCFG_COEF_GRP_25_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_26_CONST_M) && defined(PMBCFG_COEF_GRP_26_CONST_B) && defined(PMBCFG_COEF_GRP_26_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(26),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_26_CONST_M) && defined(PMBCFG_COEF_GRP_26_CONST_B) && defined(PMBCFG_COEF_GRP_26_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_27_CONST_M) && defined(PMBCFG_COEF_GRP_27_CONST_B) && defined(PMBCFG_COEF_GRP_27_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(27),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_27_CONST_M) && defined(PMBCFG_COEF_GRP_27_CONST_B) && defined(PMBCFG_COEF_GRP_27_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_28_CONST_M) && defined(PMBCFG_COEF_GRP_28_CONST_B) && defined(PMBCFG_COEF_GRP_28_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(28),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_28_CONST_M) && defined(PMBCFG_COEF_GRP_28_CONST_B) && defined(PMBCFG_COEF_GRP_28_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_29_CONST_M) && defined(PMBCFG_COEF_GRP_29_CONST_B) && defined(PMBCFG_COEF_GRP_29_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(29),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_29_CONST_M) && defined(PMBCFG_COEF_GRP_29_CONST_B) && defined(PMBCFG_COEF_GRP_29_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_30_CONST_M) && defined(PMBCFG_COEF_GRP_30_CONST_B) && defined(PMBCFG_COEF_GRP_30_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(30),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_30_CONST_M) && defined(PMBCFG_COEF_GRP_30_CONST_B) && defined(PMBCFG_COEF_GRP_30_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif

#if defined(PMBCFG_COEF_GRP_31_CONST_M) && defined(PMBCFG_COEF_GRP_31_CONST_B) && defined(PMBCFG_COEF_GRP_31_CONST_R) && defined(PMB_COEF_GRP_VALID)
  PMB_COEF_GRP_INIT(31),
#else
  #undef PMB_COEF_GRP_VALID
  #if defined(PMBCFG_COEF_GRP_31_CONST_M) && defined(PMBCFG_COEF_GRP_31_CONST_B) && defined(PMBCFG_COEF_GRP_31_CONST_R)
    #warning not all coeffficients groups are initialized, please check, if is not missing any coef group initialization
  #endif
#endif
#endif /* (!(defined(PMBCFG_COEF_GRP_0_CONST_M) && defined(PMBCFG_COEF_GRP_0_CONST_M)&&defined(PMBCFG_COEF_GRP_0_CONST_R))) */
};


//@weakgroup 


/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Check of command format.
* @details          This function is checks data format of command. Function compare format defined by command with format defined by user in command table.
*
* @param[in]        pPageCmd            Pointer to command Entry
*
* @return           ::PMBUS_BOOL
*                     - ::PMBUS_TRUE    Format is correct,
*                     - ::PMBUS_FALSE   Format is incorrect,
* @internal
* @version          07-May-2012
******************************************************************************/
#if PMBCFG_USE_FORMATS
PMBUS_INLINE PMBUS_BOOL PMB_CheckFormat(PMB_CMD_ENTRY* pPageCmd)
{
	PMBUS_SIZE formatSize = 2;
	PMBUS_FLAGS16 flags = (PMBUS_FLAGS16)((pPageCmd->cmd_data)>>PMB_CMD_FLAGS_SHIFT);
	PMBUS_FLAGS8 format_flags = (PMBUS_FLAGS8)(((pPageCmd->cmd_data)>>PMB_CFG_FORMAT_SHIFT));

	//when flags are not defined, return ok
	if (format_flags == 0)
		return PMBUS_TRUE;


	if(flags&PMB_CMD_FLAGS_VOUT_MODE)
	{
		//false when format flags are not LINEAR_DATA, VID_MODE or DIRECT_MODE
		if(format_flags&(~(PMB_CFG_FORMAT_LINEAR_DATA|PMB_CFG_FORMAT_VID_MODE|PMB_CFG_FORMAT_DIRECT_MODE)))
			return PMBUS_FALSE;
	}
	else
	{
		//false when more than one format defined
		PMBUS_FLAGS8 formatRaw = 0;
		PMBUS_FLAGS8 formatmask = 0x01;
		while(formatmask&0xff)
		{
			formatRaw |= formatmask&format_flags;
			//when is set more then one flag, return false
			if (formatRaw>formatmask)
				return PMBUS_FALSE;
			formatmask = formatmask<<1;
		}
	}

	// check data block type
//	if(((flags&PMB_CMD_FLAGS_WRITE_BITS) == PMB_CMD_FLAGS_WRITE_BLOCK) ||\
//	   ((flags&PMB_CMD_FLAGS_READ_BITS) == PMB_CMD_FLAGS_READ_BLOCK) ||\
//	   ((flags&PMB_CMD_FLAGS_READ_BITS) == PMB_CMD_FLAGS_READ_PROCCALL))
	if( (flags&PMB_CMD_FLAGS_WRITE_BYTE) ||\
		(flags&PMB_CMD_FLAGS_READ_PROCCALL) )
	{
		if(format_flags&PMB_CFG_FORMAT_DATA_BLOCK)
			return PMBUS_TRUE;
		else
			return PMBUS_FALSE;
	}
	// check BYTE_WORD type
	else if(((flags&PMB_CMD_FLAGS_WRITE_BITS) == PMB_CMD_FLAGS_WRITE_BYTE_WORD) || \
			((flags&PMB_CMD_FLAGS_READ_BITS) == PMB_CMD_FLAGS_READ_BYTE_WORD))
	{
		if(format_flags&PMB_CFG_FORMAT_8BIT_UNSIGNED)
		{
			formatSize =  1;
		}
		else if(format_flags&PMB_CFG_FORMAT_DATA_BLOCK)
		{
			formatSize =  0;
		}

		if(flags&PMB_CMD_FLAGS_WORD_SIZE)
			formatSize -= 2;
		else
			formatSize -= 1;
		
		// when not zero, the size of data type is different than expected
		if(formatSize)
		{
			return PMBUS_FALSE;
		}
	}
	return PMBUS_TRUE;
}
#endif


PMBUS_ERROR_CODE PMBus_Init(void)
{
#if PMBCFG_USE_CMD_CHECK_ON_INIT
	PMBUS_INDEX pageIndex;
	// check CMD table. If formats defined by user are not correct according the command flags, function reports error
	for(pageIndex = 0; pageIndex<50 ;pageIndex++)
	{
		PMB_PAGE_STRUCT* pPageStruct;
		PMB_CMD_ENTRY* pPageCmd;
		pPageCmd = (PMB_CMD_ENTRY*)PMBus_GetPageTable(pageIndex, &pPageStruct);
		if (pPageCmd)
		{
			PMBUS_INDEX index;
			for (index = 0; index<250 ;index++ )
			{
				//if address is 0, end of table was reached
				if(pPageCmd->addr == NULL)
					break;
#if PMBCFG_USE_FORMATS
				if(!PMB_CheckFormat(pPageCmd))
					return (PMBUS_ERROR_CODE)(index|PMBUS_ERROR_CMD_INVALID_FORMAT);
#endif
				//check procCall type of command, supports only callback
				if((((pPageCmd->cmd_data>>PMB_CMD_FLAGS_SHIFT)&PMB_CMD_FLAGS_READ_BITS) == PMBUS_CMD_FLAGS_READ_PROCCALL) && (!((pPageCmd->cmd_data>>PMB_CMD_FLAGS_SHIFT)&PMB_CMD_FLAGS_CALLBACK)))
					return (PMBUS_ERROR_CODE)(index|PMBUS_ERROR_CMD_INVALID_FORMAT);
				
				pPageCmd++;
			}
		}
		//if pPageCmd is NULL, end of table of pages was reached
		else
			break;
	}
#endif /* (PMBCFG_USE_FORMATS)*/
	return PMBUS_OK;
}

#if PMBCFG_USE_WRITE_PROTECT
/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Function to checks if command is protected
* @details          This function is used by PMB_Process to check, if actual command has protection to write
* @param[in]        pCmdContext         Context of command
* 
* @return           ::PMBUS_BOOL
*                     - ::PMBUS_TRUE    Protected,
*                     - ::PMBUS_FALSE   Not protected
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_INLINE PMBUS_BOOL PMB_IsWriteProtected(PMB_PACKET_CONTEXT* pCmdContext)
{
	PMBUS_CMD_CODE cmdCode = PMBus_GetCmdCode((PMBUS_CONTEXT)pCmdContext);
	PMBUS_FLAGS8 protect = pmb_struct.writeProtect;
	if(protect)
	{
		// the command "Write protect" has no protection
		if(cmdCode == PMB_CODE_WRITE_PROTECT)
			return PMBUS_FALSE;
		// if disable all, rest of commands are protected.
		if(protect&PMB_FLAGS_WRITE_PROTECT_DISABLEALL)
			return PMBUS_TRUE;
		//  check protection of Operation and Page commands
		if(cmdCode <= PMB_CODE_OPERATION)
			return PMBUS_FALSE;
		// rest of commands are protected
		if(protect&PMB_FLAGS_WRITE_PROTECT_EN_OPERATION)
			return PMBUS_TRUE;
		// check protection of On_Off_Config and Vout_Command commands
		if((cmdCode == PMB_CODE_ON_OFF_CONFIG)||(cmdCode == PMB_CODE_VOUT_COMMAND))
			return PMBUS_FALSE;
		else
			//rest of commands are protected
			return PMBUS_TRUE;
	}
	else
		return PMBUS_FALSE;
}
/*! @} End of aditional_function */
#endif

#if PMBCFG_USE_FORMATS
/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Returns size of packet according the format in the Command Table.
* @details          This function reads formats from the Command Table, decode size from command format and returns size of packet.
* @param[in]        pCmdTable           Pointer to Command in the Command Table
* @return           ::PMBUS_SIZE        Size of packet (0,1,2 or size of data block)
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_INLINE PMBUS_SIZE PMB_GetSizeFromFormat(PMB_CMD_ENTRY* pCmdTable)
{
	PMBUS_FLAGS8 format_flags = PMBus_GetCmdFormatFlags(pCmdTable);

	//decode size
	if(format_flags == 0)
		return 0;
	if(format_flags&PMB_CFG_FORMAT_8BIT_UNSIGNED)
		return 1;
	else if(format_flags&PMB_CFG_FORMAT_DATA_BLOCK)
		return (PMBUS_SIZE)((pCmdTable->cmd_data)>>PMB_CFG_BLOCK_SIZE_SHIFT);
	else
		return 2;
}
/*! @} End of aditional_function */
#endif

/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            This function performs PMBus commands.
* @details          This function is used by the communication interface to search command in table of commands and performs  PMBus command. 
*                   This function is used to pass down received data to registered variable/callback to the received command when write is required.
*                   This function also builds response to the communication interface when is packet requested for read.
* @param[in,out]    pCmdContext         Internal PMBus context of commands to be decoded
* @param[in,out]    pLength             Size of received packet/size of packet to be send
* @param[in,out]    pBuffer             Contains received packet/packet to  be send
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                              Command was performed successfully
*                     - ::PMBUS_ERROR_CMD_PROTECTED             Command is protected to write
*                     - ::PMBUS_ERROR_CMD_INVALID_SIZE          Command has invalid size of received packet
*                     - ::PMBUS_ERROR_CMD_INVALID_RESP_SIZE     Response size is higher than size of buffer
*                     - ::PMBUS_ERROR_CMD_CALLBACK_ADDRESS      Illegal address of callback
*                     - ::PMBUS_ERROR_CMD_READ_NOT_SUPPORTED    Command does not supports read
*                     - ::PMBUS_ERROR_CMD_NOT_FOUND             Command was not found in the 
*                         @ref pmbus_define_table "Command Table".
*                     - all codes of ::PMBus_CallBack()
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_Process(PMB_PACKET_DATA* pCmdData, PMB_PACKET_CONTEXT* pCmdContext)
{
	// is command ready to initialize? (When decode flag is set and decoded flag is cleared)
	if((pCmdContext->packetFlags&(PMB_COMMAND_DECODED | PMB_COMMAND_DECODE)) == PMB_COMMAND_DECODE) //when decode flag is set to 1 and decoded flag is cleared
	{
		// finds the table of commands (page)
		pCmdContext->pPageCmd = (PMB_CMD_ENTRY*)PMBus_GetPageTable(pCmdContext->pageIndex, &pCmdContext->pPageStruct);
		// is the table of command available?
		if(pCmdContext->pPageCmd)
		{
			// find details of command in table of commands (in page)
			pCmdContext->pPageCmd = PMB_FindCmdPtr(pCmdData->cmdCode, pCmdContext->pPageCmd);
			// is the command available?
			if(pCmdContext->pPageCmd)
				pCmdContext->packetFlags |= PMB_COMMAND_DECODED;
		}
	}
	// check if command was initialized and needs to be processed
	if(((~pCmdContext->packetFlags)&(PMB_COMMAND_DECODED | PMB_PERFORM_COMMAND)) == 0) //if one of tested flags is cleared, command cannot be performed
	{
		PMBUS_SIZE expectedSize = 0;
		// get flags, Low byte contains command flags, high byte contains command configuration flags
		PMBUS_FLAGS16 flags = (PMBUS_FLAGS16)((pCmdContext->pPageCmd->cmd_data)>>PMB_CMD_FLAGS_SHIFT);
		PMBUS_BOOL isWrite = PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext);
		PMBUS_SIZE realSize = pCmdData->packetLength;
		PMBUS_SIZE packetSize = (PMBUS_SIZE) (*(pCmdData->pBuffer) + (PMBUS_SIZE)1);

		PMBUS_FLAGS8 cmdFlags;
		// initialize flags of command
		if(isWrite)
		{
			cmdFlags = (PMBUS_FLAGS8)((flags&PMB_CMD_FLAGS_WRITE_BITS)>>2);			
			// check Write protection if enabled
			if(PMB_IsWriteProtected(pCmdContext)&&(PMBCFG_USE_WRITE_PROTECT))
			{
				// report error that write is protected, used PMBus_ version of function to send SMBus Alert
				(void)PMB_SetErrorState(PMBUS_STATUS_INVALID_COMMAND | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
				return PMBUS_ERROR_CMD_PROTECTED;
			}
		}
		else
		{
			cmdFlags = (PMBUS_FLAGS8)((flags&PMB_CMD_FLAGS_READ_BITS));
		}


#if PMBCFG_USE_FORMATS
		// get size from formats
		expectedSize = PMB_GetSizeFromFormat(pCmdContext->pPageCmd);

		// this condition is valid for write block too
		if(isWrite)
		{
			// isWrite passed, test if Write Block is received
			if((cmdFlags == PMB_CMD_FLAGS_READ_BLOCK))
			{
				if(expectedSize == 0)
				{
					// packet length is not defined in format, use length from packet
					expectedSize = packetSize;
				}

				// sets Error when size is incorrect(expectedSize != pCmdData->packetLength)
				if(realSize != expectedSize)
				{
					// received packet does not have all bytes.
					(void)PMB_SetErrorState(PMBUS_STATUS_INVALID_DATA | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
					return PMBUS_ERROR_CMD_INVALID_SIZE;
				}
			}
		}
#endif /* PMBCFG_USE_FORMATS  */
		// when size was initialized, update the size to data structure of packet
		if(expectedSize)
		{
			pCmdData->packetLength = expectedSize;
		}

		// is callback or direct access to variable?
		if (flags&PMB_CMD_FLAGS_CALLBACK)
		{
			// check address of callback function
			if(pCmdContext->pPageCmd->addr)
			{
				PMBUS_ERROR_CODE status;
				status = (*((PMB_FNC_PTR)pCmdContext->pPageCmd->addr))(pCmdContext, pCmdData->pBuffer, &(pCmdData->packetLength));
				if(status)
				{
					// sets Error that call-back cannot accept the command
					PMB_SetErrorState(PMBUS_STATUS_INVALID_DATA | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
					return status;
				}
				
#if PMBCFG_USE_INTERNAL_CHECKS
				// check response size of read command
				if(!isWrite)
				{
					if(pCmdData->packetLength>PMB_COM_BUFFER_SIZE)
					{
						// error, response is too long, buffer is overwritten
						PMB_SetErrorState(PMBUS_STATUS_INVALID_DATA | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
						return PMBUS_ERROR_CMD_INVALID_RESP_SIZE;
					}
				}
#endif
			}
#if PMBCFG_USE_INTERNAL_CHECKS
			else
			{
				// call-back address is not initialized
				PMB_SetErrorState(PMBUS_STATUS_INVALID_COMMAND | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
				return PMBUS_ERROR_CMD_CALLBACK_ADDRESS;
			}
#endif
		}
		else
		{
			// sets Error when length of packet is not initialized or proc-call read is received
			//if((cmdFlags == PMB_CMD_FLAGS_READ_PROCCALL)||(pCmdData->packetLength == 0))
			if(pCmdData->packetLength == 0)
			{
				PMB_SetErrorState(PMBUS_STATUS_INVALID_DATA | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
				return PMBUS_ERROR_CMD_READ_NOT_SUPPORTED;
			}
			else
			{
				PMBUS_BUFFER* pSource;
				PMBUS_BUFFER* pDest;
				PMBUS_SIZE index = 0;

#if (PMBCFG_USE_INTERNAL_CHECKS)
				// sets Error when address of variable is not initialized
				if(pCmdContext->pPageCmd->addr == NULL)
				{
					PMB_SetErrorState(PMBUS_STATUS_INVALID_COMMAND | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
					return PMBUS_ERROR_CMD_CALLBACK_ADDRESS;
				}
#endif
				// initialize pointers to copy variable
				if(isWrite)
				{
					pSource = pCmdData->pBuffer;
					pDest = (PMBUS_BUFFER*) pCmdContext->pPageCmd->addr;
					if(((cmdFlags) == PMB_CMD_FLAGS_READ_BLOCK))
					{
						// point to second byte of received data
						pSource++;
						// data length of write block packet is one byte shorter							
						index = 1;
					}
				}
				else
				{
					pSource = (PMBUS_BUFFER*) pCmdContext->pPageCmd->addr;
					pDest = pCmdData->pBuffer;
					if(((cmdFlags) == PMB_CMD_FLAGS_READ_BLOCK))
					{
						// first byte of packet is size
						*(pDest++) = (PMBUS_BUFFER)(pCmdData->packetLength - (PMBUS_BUFFER)1);
						// data length of read block packet is one byte shorter							
						index = 1;
					}
				}
				
				// copy packet to/from memory
				for(; index<pCmdData->packetLength; index++ )
				{
					*(pDest++) = *(pSource++);
				}
			}
		}
	}
	
	// Succeeded when the DECODED flag is set
	if(pCmdContext->packetFlags&PMB_COMMAND_DECODED)
		return PMBUS_OK;
	
	PMB_SetErrorState(PMBUS_STATUS_INVALID_COMMAND | PMB_SET_SMBUSALERT_BIT, pCmdContext->pPageStruct);
	return PMBUS_ERROR_CMD_NOT_FOUND;
}
/*! @} End of aditional_function */

/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Finds command in the Command Table
* @details          This function scans the Command Table and returns pointer to command in table, where are details about the command
* @param[in]        cmdCode             Command code (0-255)
* @param[in]        pTableIndex         Pointer to begin of command table
* @return           ::PMB_CMD_ENTRY     Pointer to scanned command, 
*                                       NULL, if command was not found
* @internal
* @version          07-May-2012
******************************************************************************/
static PMB_CMD_ENTRY* PMB_FindCmdPtr(PMBUS_CMD_CODE cmdCode, PMB_CMD_ENTRY* pCmdEntry)
{
	PMBUS_INDEX index = 0;
	// scan all items in table (page)
	for (index = 0; index<250 ;index++ )
	{
		// when address is NULL, end of table was reached
		if(pCmdEntry->addr == NULL)
			return NULL;
		
		// check command code
		if((pCmdEntry->cmd_data&PMB_CMD_CODE_MASK) == cmdCode)
		{
			return pCmdEntry;
			
		}
		pCmdEntry++;
	}
	return NULL;	
}
/*! @} End of aditional_function */

PMBUS_ERROR_CODE PMBus_SetErrorState(PMBUS_INDEX pageIndex, PMBUS_STATUS_BIT_ID statBitCode)
{
	PMB_PAGE_STRUCT* pPageStruct;
	// is required page presented?
	if(PMBus_GetPageTable(pageIndex, &pPageStruct))
	{
		return PMB_SetErrorState(statBitCode, pPageStruct);
	}
	
	return PMBUS_ERROR_PAGE_NOT_FOUND;
}

PMBUS_ERROR_CODE PMBus_ResetErrorState(PMBUS_INDEX pageIndex, PMBUS_STATUS_BIT_ID statBitCode)
{
	PMB_PAGE_STRUCT* pPageStruct;
	// is required page presented?
	if(PMBus_GetPageTable(pageIndex, &pPageStruct))
	{
		return PMB_ResetErrorState(statBitCode, pPageStruct);
	}

	return PMBUS_ERROR_PAGE_NOT_FOUND;
}
/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Builds the PMBus Alert message
* @details          This function builds the PMBus Alert message and send to the SMBus layer
* @param[in]        pPageStruct         Address of structure, where are stored variables of page
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                      Command was performed successfully
*                     - all Errors of ::PMB_Alert() function
* @internal
* @version          07-May-2012
******************************************************************************/
#if PMBCFG_USE_SMBALERT_RESPONSE
PMBUS_INLINE PMBUS_ERROR_CODE PMB_Alert(PMB_PAGE_STRUCT* pPageStruct)
{
	// build SMBus Alert response
	PMBUS_FLAGS16 response = (PMBUS_FLAGS16)(pPageStruct->status_byte | (pPageStruct->status_wordh<<8));
#if PMBCFG_USE_SMBUS_DRIVER
	// Call the SMBus Alert
	return (PMBUS_ERROR_CODE)SMBus_Alert((SMBUS_FLAGS16)response);
#else
  return PMBUS_OK;
#endif
}
#endif
/*! @} End of aditional_function */

/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Sets error of the PMBus stack
* @details          This function sets error flag in the PMBus status register defined by the parameter
* @param[in]        statBitCode         Code of flag in status register to be set. Use one of @ref pmbus_status_bit_ids "PMBUS_STATUS_XXX" constants.
* @param[in]        pPageStruct         Address of structure, where are stored variables of page
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                              Flag was set successfully and no alert required
*                     - ::PMBUS_ERROR_CMD_INVALID_PARAM         Invalid parameter
*                     - ::PMBUS_ALERT_RESPONSE_ENABLED          Alert response is enabled
*                     - all Errors of ::PMB_Alert() function
* @internal
* @version          07-May-2012
******************************************************************************/
static PMBUS_ERROR_CODE PMB_SetErrorState(PMBUS_PAGE_MEMBER_INDEX statBitCode, PMB_PAGE_STRUCT* pPageStruct)
{
	PMBUS_PAGE_MEMBER_INDEX statRegIndex = (PMBUS_PAGE_MEMBER_INDEX)((statBitCode>>8)&PMB_PAGE_VAR_INDEX_STATUS_MASK);
	PMBUS_PAGE_MEMBER bitMask = (PMBUS_PAGE_MEMBER)(statBitCode&0xff);
	PMBUS_PAGE_MEMBER* pVarStat = (((PMBUS_PAGE_MEMBER*)(pPageStruct))+statRegIndex);
	
#if PMBCFG_USE_INTERNAL_CHECKS
	// is parameter in range of structure of internal variables
	if(statRegIndex>(sizeof(PMB_PAGE_STRUCT)/sizeof(PMBUS_PAGE_MEMBER)))
		return PMBUS_ERROR_CMD_INVALID_PARAM;
#endif

	// store mask(error flags) to register
	*pVarStat |= bitMask;
#if (PMBCFG_USE_SMBALERT_MASK) && (PMBCFG_USE_SMBALERT_RESPONSE)
	// !!SMBus Alert Mask is next byte after status register !!
	// call the SMBus Alert event if bit is zero
	if(((*(pVarStat+1))&bitMask) == 0)
	{
		if(statBitCode&PMBUS_CALL_SMBUSALERT)
			return (PMBUS_ERROR_CODE)(PMB_Alert(pPageStruct) | PMBUS_ALERT_RESPONSE_ENABLED);
		//Alert response is enabled from Host site but Alert message is not enabled
		return PMBUS_ALERT_RESPONSE_ENABLED;
	}
#endif

	return PMBUS_OK;
}

static PMBUS_ERROR_CODE PMB_ResetErrorState(PMBUS_PAGE_MEMBER_INDEX statBitCode, PMB_PAGE_STRUCT* pPageStruct)
{
	PMBUS_PAGE_MEMBER_INDEX statRegIndex = (PMBUS_PAGE_MEMBER_INDEX)((statBitCode>>8)&PMB_PAGE_VAR_INDEX_STATUS_MASK);
	PMBUS_PAGE_MEMBER bitMask = (PMBUS_PAGE_MEMBER)(statBitCode&0xff);
	PMBUS_PAGE_MEMBER* pVarStat = (((PMBUS_PAGE_MEMBER*)(pPageStruct))+statRegIndex);

#if PMBCFG_USE_INTERNAL_CHECKS
	// is parameter in range of structure of internal variables
	if(statRegIndex>(sizeof(PMB_PAGE_STRUCT)/sizeof(PMBUS_PAGE_MEMBER)))
		return PMBUS_ERROR_CMD_INVALID_PARAM;
#endif

	// store mask(error flags) to register
	*pVarStat &= ~bitMask;
#if (PMBCFG_USE_SMBALERT_MASK) && (PMBCFG_USE_SMBALERT_RESPONSE)
	// !!SMBus Alert Mask is next byte after status register !!
	// call the SMBus Alert event if bit is zero
	if(((*(pVarStat+1))&bitMask) == 1)
	{
		if(statBitCode&PMBUS_CALL_SMBUSALERT)
			return (PMBUS_ERROR_CODE)(PMB_Alert(pPageStruct) & ~PMBUS_ALERT_RESPONSE_ENABLED);
		//Alert response is enabled from Host site but Alert message is not enabled
		return PMBUS_ALERT_RESPONSE_ENABLED;
	}
#endif

	return PMBUS_OK;
}
/*! @} End of aditional_function */


PMBUS_PAGE_MEMBER PMBus_GetFaultResponseType(PMBUS_INDEX pageIndex, PMBUS_FAULT_ID faultId)
{
#if PMBCFG_USE_INTERNAL_CHECKS
	//  is parameter in range of structure of internal variables
	if(faultId<=(sizeof(PMB_PAGE_STRUCT)/sizeof(PMBUS_PAGE_MEMBER)))
#endif
	{
		PMB_PAGE_STRUCT* pPageStruct;
		// is required page initialized?
		if(PMBus_GetPageTable(pageIndex, &pPageStruct))
		{
			PMBUS_PAGE_MEMBER* pVarRes;
			// calculate pointer to desired member in structure
			pVarRes = ((PMBUS_PAGE_MEMBER*)(pPageStruct))+faultId;
			return *(pVarRes);
		}
	}
	// member was not found, return zero
	return 0;
}

// Table which assigns code of command to index of internal variable in page
const PMB_MEMBER_CONVERSION_STRUCT pmb_IntVar_table[]=
{
#if PMBCFG_USE_STATUS_BYTE
	{ PMB_CODE_STATUS_BYTE, PMB_PAGE_VAR_INDEX_STATUS_BYTE},
#else
	{ PMB_CODE_STATUS_BYTE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_WORD
	{ PMB_CODE_STATUS_WORD, PMB_PAGE_VAR_INDEX_STATUS_WORD},
#else
	{ PMB_CODE_STATUS_WORD, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_VOUT
	{ PMB_CODE_STATUS_VOUT, PMB_PAGE_VAR_INDEX_STATUS_VOUT},
#else
	{ PMB_CODE_STATUS_VOUT, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_IOUT
	{ PMB_CODE_STATUS_IOUT, PMB_PAGE_VAR_INDEX_STATUS_IOUT},
#else
	{ PMB_CODE_STATUS_IOUT, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_INPUT
	{ PMB_CODE_STATUS_INPUT, PMB_PAGE_VAR_INDEX_STATUS_INPUT},
#else
	{ PMB_CODE_STATUS_INPUT, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_TEMPERATURE
	{ PMB_CODE_STATUS_TEMPERATURE, PMB_PAGE_VAR_INDEX_STATUS_TEMPERATURE},
#else
	{ PMB_CODE_STATUS_TEMPERATURE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_CML
	{ PMB_CODE_STATUS_CML, PMB_PAGE_VAR_INDEX_STATUS_CML},
#else
	{ PMB_CODE_STATUS_CML, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_OTHER
	{ PMB_CODE_STATUS_OTHER, PMB_PAGE_VAR_INDEX_STATUS_OTHER},
#else
	{ PMB_CODE_STATUS_OTHER, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_MFR_SPECIFIC
	{ PMB_CODE_STATUS_MFR_SPECIFIC, PMB_PAGE_VAR_INDEX_STATUS_MFR_SPECIFIC},
#else
	{ PMB_CODE_STATUS_MFR_SPECIFIC, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_FANS_1_2
	{ PMB_CODE_STATUS_FANS_1_2, PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2},
#else
	{ PMB_CODE_STATUS_FANS_1_2, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_STATUS_FANS_3_4
	{ PMB_CODE_STATUS_FANS_3_4, PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4},
#else
	{ PMB_CODE_STATUS_FANS_3_4, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif

#if (PMBCFG_USE_VOUT_MODE) && ((PMBCFG_CONST_VOUT_MODE)==0)
	{ PMB_CODE_VOUT_MODE, PMB_PAGE_VAR_INDEX_VOUT_MODE},
#else
	{ PMB_CODE_VOUT_MODE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_VOUT_OV_FAULT_RESPONSE
	{ PMB_CODE_VOUT_OV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_VOUT_OV_FAULT_RESPONSE},
#else
	{ PMB_CODE_VOUT_OV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_VOUT_UV_FAULT_RESPONSE
	{ PMB_CODE_VOUT_UV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_VOUT_UV_FAULT_RESPONSE},
#else
	{ PMB_CODE_VOUT_UV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_IOUT_OC_FAULT_RESPONSE
	{ PMB_CODE_IOUT_OC_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_IOUT_OC_FAULT_RESPONSE},
#else
	{ PMB_CODE_IOUT_OC_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_IOUT_OC_LV_FAULT_RESPONSE
	{ PMB_CODE_IOUT_OC_LV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_IOUT_OC_LV_FAULT_RESPONSE},
#else
	{ PMB_CODE_IOUT_OC_LV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_IOUT_UC_FAULT_RESPONSE
	{ PMB_CODE_IOUT_UC_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_IOUT_UC_FAULT_RESPONSE},
#else
	{ PMB_CODE_IOUT_UC_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_OT_FAULT_RESPONSE
	{ PMB_CODE_OT_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_OT_FAULT_RESPONSE},
#else
	{ PMB_CODE_OT_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_UT_FAULT_RESPONSE
	{ PMB_CODE_UT_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UT_FAULT_RESPONSE},
#else
	{ PMB_CODE_UT_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_VIN_OV_FAULT_RESPONSE
	{ PMB_CODE_VIN_OV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_VIN_OV_FAULT_RESPONSE},
#else
	{ PMB_CODE_VIN_OV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_VIN_UV_FAULT_RESPONSE
	{ PMB_CODE_VIN_UV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_VIN_UV_FAULT_RESPONSE},
#else
	{ PMB_CODE_VIN_UV_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_IIN_OC_FAULT_RESPONSE
	{ PMB_CODE_IIN_OC_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_IIN_OC_FAULT_RESPONSE},
#else
	{ PMB_CODE_IIN_OC_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_TON_MAX_FAULT_RESPONSE
	{ PMB_CODE_TON_MAX_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_TON_MAX_FAULT_RESPONSE},
#else
	{ PMB_CODE_TON_MAX_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif
#if PMBCFG_USE_POUT_OP_FAULT_RESPONSE
	{ PMB_CODE_POUT_OP_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_POUT_OP_FAULT_RESPONSE},
#else
	{ PMB_CODE_POUT_OP_FAULT_RESPONSE, PMB_PAGE_VAR_INDEX_UNINITIALIZED},
#endif

};

PMBUS_ERROR_CODE PMBus_GetIntVarByIndex(PMBUS_CONTEXT pCmdContext, PMBUS_PAGE_MEMBER_INDEX memIndex, PMBUS_PAGE_MEMBER** ppVar)
{
	PMB_MEMBER_CONVERSION_STRUCT* pIntVarTable = (PMB_MEMBER_CONVERSION_STRUCT*)&pmb_IntVar_table[memIndex];
	PMBUS_PAGE_MEMBER_INDEX memberOffset = pIntVarTable->member_index;
	*ppVar = NULL;
	
#if PMBCFG_USE_INTERNAL_CHECKS
	//  is parameter in range of structure of internal variables
	if(memIndex>=PMBUS_INTERNAL_TABLE_SIZE)
		return PMBUS_ERROR_CMD_INVALID_PARAM;
	//  is command enabled
	if(memberOffset ==  PMB_PAGE_VAR_INDEX_UNINITIALIZED)
		return PMBUS_OK;                //not enabled, but end of table was not reached
#endif

	*ppVar = (PMBUS_PAGE_MEMBER*)(((PMB_PACKET_CONTEXT*) (PMBUS_CONTEXT) (pCmdContext))->pPageStruct)+memberOffset;
		
	// Begin of table are status registers. Modify address to point to the Smbus Alert Mask register.
	// Rest of registers have correct address.
	if(memIndex<PMBUS_INDEX_VOUT_MODE)
	{
	    // Offset points to status register, move to next member to point to Status Alert Mask
#if PMBCFG_USE_SMBALERT_MASK
		(*ppVar)++;
#else
		// SMBus Alert Mask is not supported
		*ppVar = NULL;
		if (PMBCFG_USE_INTERNAL_CHECKS)
			return PMBUS_ERROR_CMD_INVALID_PARAM;
#endif
	}
	
	return PMBUS_OK;
}

/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Returns index of command
* @details          This function scan pmb_IntVar_table table and returns index of command register placed in internal page structure
* @param[in]        cmdCode     Code of command
* @return           PMBUS_PAGE_MEMBER_INDEX:
*                      - member of command in structure of page. 
*                      - 0xffff Command was not found
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_INLINE PMBUS_PAGE_MEMBER_INDEX PMB_GetCmdIndexFromTable(PMBUS_CMD_CODE cmdCode)
{
	PMBUS_INDEX tableIndex;
	// find table index of command code
	for(tableIndex = 0; tableIndex<PMBUS_INTERNAL_TABLE_SIZE;tableIndex++)
	{
		if(pmb_IntVar_table[tableIndex].cmd_Code == cmdCode)
			return tableIndex;
	}
	return PMB_PAGE_VAR_INDEX_UNINITIALIZED;
}
/*! @} End of aditional_function */


PMBUS_ERROR_CODE PMBus_GetIntVar(PMBUS_CONTEXT pCmdContext, PMBUS_CMD_CODE cmdCode, PMBUS_PAGE_MEMBER** ppVar)
{
	// find index of command
	PMBUS_PAGE_MEMBER_INDEX memIndex = PMB_GetCmdIndexFromTable(cmdCode);
	*ppVar = NULL;
	// check if command was found
	if (memIndex == PMB_PAGE_VAR_INDEX_UNINITIALIZED)
		return PMBUS_ERROR_CMD_NOT_FOUND;

	return PMBus_GetIntVarByIndex(pCmdContext, memIndex, ppVar);
}

PMBUS_ERROR_CODE PMBus_GetPageIntVarByIndex(PMBUS_INDEX pageIndex, PMBUS_PAGE_MEMBER_INDEX memIndex, PMBUS_PAGE_MEMBER** ppVar)
{
	PMB_PACKET_CONTEXT cmdContext;
	*ppVar = NULL;
	// find page & internal registers
	if (PMBus_GetPageTable(pageIndex, &cmdContext.pPageStruct))
		return PMBus_GetIntVarByIndex((PMBUS_CONTEXT)&cmdContext, memIndex, ppVar);
	else
		return PMBUS_ERROR_PAGE_NOT_FOUND;
}

#if PMBCFG_USE_QUERY

/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Get Data Format used by Query
* @details          This function is used by the Query call-back to transform type of format from Command Table to Query response
* @param[in]        pCmdContext         Context of command
* 
* @return           ::PMBUS_FLAGS8      Code of format which is used by Query function
*                       - ::PMB_CODE_FORMAT_LINEAR_DATA
*                       - ::PMB_CODE_FORMAT_16BIT_SIGNED
*                       - ::PMB_CODE_FORMAT_DIRECT_MODE
*                       - ::PMB_CODE_FORMAT_8BIT_UNSIGNED
*                       - ::PMB_CODE_FORMAT_VID_MODE
*                       - ::PMB_CODE_FORMAT_MANUF_SPEC
*                       - ::PMB_CODE_FORMAT_DATA_BLOCK
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_INLINE PMBUS_FLAGS8 PMB_GetQueryDataFormat(PMB_PACKET_CONTEXT* pCmdContext)
{
	// get flags, Low byte contains command flags, high byte contains command configuration flags
	PMBUS_FLAGS16 flags = (PMBUS_FLAGS16)((pCmdContext->pPageCmd->cmd_data)>>PMB_CMD_FLAGS_SHIFT); 
	
	// access to command configuration flag requires move mask to high byte
	// is 8bit unsigned char?
	if(flags&(PMB_CFG_FORMAT_8BIT_UNSIGNED<<8))
		return PMB_CODE_FORMAT_8BIT_UNSIGNED <<PMB_CODE_FORMAT_SHIFT;
		
	// is linear data format supported
	if(flags&(PMB_CFG_FORMAT_LINEAR_DATA<<8))
	{
		// is command controlled by Vout Mode?
		if(flags&PMB_CMD_FLAGS_VOUT_MODE)
		{
			if((~flags)&((PMB_CFG_FORMAT_DIRECT_MODE|PMB_CFG_FORMAT_VID_MODE)<<8))
			{
				// no other mode supported, only linear data is supported
				return PMB_CODE_FORMAT_LINEAR_DATA<<PMB_CODE_FORMAT_SHIFT;
			}
			else
			{
				// return linear data when is selected in VOUT_MODE
#if PMBCFG_CONST_VOUT_MODE
				if((pmb_const_vout_mode&PMB_VOUT_MODE_CFG_MASK) == PMB_VOUT_MODE_CFG_LINEAR_DATA)
					return PMB_CODE_FORMAT_LINEAR_DATA<<PMB_CODE_FORMAT_SHIFT;
#else
				if((pCmdContext->pPageStruct->vout_mode&PMB_VOUT_MODE_CFG_MASK) == PMB_VOUT_MODE_CFG_LINEAR_DATA)
					return PMB_CODE_FORMAT_LINEAR_DATA<<PMB_CODE_FORMAT_SHIFT;
#endif
			}
		}
		else
		{ 
			return PMB_CODE_FORMAT_LINEAR_DATA<<PMB_CODE_FORMAT_SHIFT;
		}
	}
		
	// is direct mode supported?
	if(flags&(PMB_CFG_FORMAT_DIRECT_MODE<<8))
	{
		// is command directed by Vout Mode?
		if(flags&PMB_CMD_FLAGS_VOUT_MODE)
		{
			if(flags&(PMB_CFG_FORMAT_VID_MODE<<8))
			{
				// return direct mode when is selected in VOUT_MODE
#if PMBCFG_CONST_VOUT_MODE
				if((pmb_const_vout_mode&PMB_VOUT_MODE_CFG_MASK) == PMB_VOUT_MODE_CFG_DIRECT_MODE)
					return PMB_CODE_FORMAT_DIRECT_MODE<<PMB_CODE_FORMAT_SHIFT;
#else
				if((pCmdContext->pPageStruct->vout_mode&PMB_VOUT_MODE_CFG_MASK) == PMB_VOUT_MODE_CFG_DIRECT_MODE)
					return PMB_CODE_FORMAT_DIRECT_MODE<<PMB_CODE_FORMAT_SHIFT;
#endif
			}
			else
			{
				// no other mode supported, only direct mode is supported
				return PMB_CODE_FORMAT_DIRECT_MODE<<PMB_CODE_FORMAT_SHIFT;
			}
		}
		else 
		{
			return PMB_CODE_FORMAT_DIRECT_MODE<<PMB_CODE_FORMAT_SHIFT;
		}

	}
	// if VID is supported, return VID format (if command is controlled by Vout Mode and linear_data/direct_mode are not supported, no option to set another format)
	if(flags&(PMB_CFG_FORMAT_VID_MODE<<8))
		return PMB_CODE_FORMAT_VID_MODE<<PMB_CODE_FORMAT_SHIFT;
	if(flags&(PMB_CFG_FORMAT_MANUF_SPEC<<8))
		return PMB_CODE_FORMAT_MANUF_SPEC<<PMB_CODE_FORMAT_SHIFT;
	if(flags&(PMB_CFG_FORMAT_16BIT_SIGNED<<8))
		return PMB_CODE_FORMAT_16BIT_SIGNED<<PMB_CODE_FORMAT_SHIFT;
	// last option is only data block (when PMB_CFG_FORMAT_DATA_BLOCK is used or no format defined)
	else
		return PMB_CODE_FORMAT_DATA_BLOCK<<PMB_CODE_FORMAT_SHIFT;
}
/*! @} End of aditional_function */

/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Query command
* @details          This function implements call-back for Query command. 
*                   - received packet: { size=1. Command_Code }
*                   - response packet: { size=1, Query_response }
*
* @param[in]        pCmdContext Context of command
* @param[in,out]    pBuffer             Includes received packet, build response here.
* @param[in,out]    pSize               Size of received packet, size of response
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                              Command was performed successfully
*                     - ::PMBUS_ERROR_CMD_INVALID_SIZE          Invalid size of command
*                     - ::PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED   Write is not supported
*                     - all Errors of ::PMB_Process()
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackQuery(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	PMB_PACKET_CONTEXT subCmdContext;	
	PMB_PACKET_DATA cmdData;
	PMBUS_ERROR_CODE status;
	PMBUS_BUFFER response = 0;
	
#if PMBCFG_USE_INTERNAL_CALLBACK_CHECKS
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
		return PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED;
	if(pBuffer[0] != 1)
		return PMBUS_ERROR_CMD_INVALID_SIZE; //buffer contains invalid size of this command
#endif
	//Get command details(use PMB_Process to get command pointer in page)
	PMB_InitCmdContext(&subCmdContext, PMB_GetCurrentPage(pCmdContext), PMB_COMMAND_DECODE);
	cmdData.cmdCode = pBuffer[1];
	status = PMB_Process(&cmdData,&subCmdContext);

	if(status == PMBUS_OK)
	{
		PMBUS_FLAGS16 cmdFlags = (PMBUS_FLAGS16)(subCmdContext.pPageCmd->cmd_data>>PMB_CMD_FLAGS_SHIFT);
		// builds response
		// command is enabled
		response |= 0x80;
		// is command supported for write?
		if(cmdFlags&PMB_CMD_FLAGS_WRITE_BITS)
			response |= 0x40;
		// is command supported for read?
		if(cmdFlags&PMB_CMD_FLAGS_READ_BITS)
			response |= 0x20;
		//get the format
		response |= PMB_GetQueryDataFormat(&subCmdContext);
	}
	else
		return status; //command was not found

	// copy response to buffer
	*pSize = 2;
	pBuffer[0] = 1;
	pBuffer[1] = response;
	return PMBUS_OK;
}
/*! @} End of internal_commands */
#endif

#if PMBCFG_USE_STATUS_BYTE
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Status Byte command
* @details          This function implements call-back for the Status Byte command. 
*                   - received packet: { Status_Byte }
*                   - response packet: { Status_Byte }
*
* @param[in]        pCmdContext                 Context of command
* @param[in,out]    pBuffer                     Includes received packet, build response here.
* @param[in,out]    pSize                       Size of received packet, size of response
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK              Command was performed successfully
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackGetStatByte(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
	{
		// Clear flags
		PMBUS_PAGE_MEMBER maskToClean = (PMBUS_PAGE_MEMBER)(pBuffer[0]&PMB_STATUS_BYTE_MASK);
		maskToClean &= pCmdContext->pPageStruct->status_byte;
		pCmdContext->pPageStruct->status_byte ^= maskToClean;
	}
	else
	{
		// Get status Byte Flags
		pBuffer[0] = (PMBUS_BUFFER)PMB_GetStatByte(pCmdContext);
		*pSize = 1;
	}
	
	return PMBUS_OK;
}
/*! @} End of internal_commands */
#endif

#define ENABLE_STATUS_BYTE_MASK(reg, x, mask) \
  	if(pCmdContext->pPageStruct->reg&(x)) \
		status_byte |= mask; \
	if(pCmdContext->pPageStruct->reg&(0xFF & (~x))) \
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK; \
 

#if (PMBCFG_USE_STATUS_BYTE) || (PMBCFG_USE_STATUS_WORD)
/*****************************************************************************/
/*! @addtogroup aditional_function
* @{*/
/*****************************************************************************
*//*!
* @brief            Function to get status byte
* @details          This function is used by the Status Byte or by the Status Word call-back to build status byte from other status registers/ from status byte flags
* @param[in]        pCmdContext         Context of command
* 
* @return           ::PMBUS_PAGE_MEMBER Value of status byte
* @internal
* @version          07-May-2012
******************************************************************************/
static PMBUS_PAGE_MEMBER PMB_GetStatByte(PMB_PACKET_CONTEXT* pCmdContext)
{
	// initialize status byte, keep bits which are stored in status byte
	PMBUS_PAGE_MEMBER status_byte = (PMBUS_PAGE_MEMBER)(pCmdContext->pPageStruct->status_byte&PMB_STATUS_BYTE_MASK);
	
	// rest of bits are initialized by actual value of status registers
#if PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&(PMB_ST_WORD_UNKNOWN_MASK))
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif

#if PMBCFG_USE_STATUS_VOUT
	ENABLE_STATUS_BYTE_MASK(status_vout, STATUS_VOUT_ENABLE_MASK, PMB_ST_BYTE_VOUT_OV_FAULT_MASK);
#elif PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&(PMB_ST_WORD_VOUT_FAULT_REG_MASK))
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif
	// callback function to get state of power supply
#if PMBCFG_USE_CALLBACK_IS_POWER_SUPPLY_ON
	if(PMBus_IsPowerSupplyOn(PMB_GetCurrentPage(pCmdContext)))
		status_byte |= PMB_ST_BYTE_OFF_MASK;
#endif	

#if PMBCFG_USE_STATUS_IOUT
	ENABLE_STATUS_BYTE_MASK(status_iout, STATUS_IOUT_ENABLE_MASK, PMB_ST_BYTE_IOUT_OC_FAULT_MASK);
#elif PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&PMB_ST_WORD_IOUT_FAULT_REG_MASK)
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif

#if PMBCFG_USE_STATUS_INPUT
	ENABLE_STATUS_BYTE_MASK(status_input, STATUS_INPUT_ENABLE_MASK, PMB_ST_BYTE_VIN_UV_FAULT_MASK);
#elif PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&PMB_ST_WORD_INPUT_REG_MASK)
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif

#if PMBCFG_USE_STATUS_TEMPERATURE
	ENABLE_STATUS_BYTE_MASK(status_temperature, STATUS_TEMPERATURE_ENABLE_MASK, PMB_ST_BYTE_TEMPERATURE_REG_MASK);
#endif

#if PMBCFG_USE_STATUS_CML
	ENABLE_STATUS_BYTE_MASK(status_cml, STATUS_CML_ENABLE_MASK, PMB_ST_BYTE_CML_REG_MASK);
#endif

#if PMBCFG_USE_STATUS_OTHER
	ENABLE_STATUS_BYTE_MASK(status_other, STATUS_OTHER_ENABLE_MASK, PMB_ST_BYTE_NONE_OF_ABOVE_MASK);
#elif PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&PMB_ST_WORD_OTHER_REG_MASK)
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif

#if PMBCFG_USE_STATUS_MFR_SPECIFIC
	ENABLE_STATUS_BYTE_MASK(status_mfr_specific, STATUS_MFR_SPECIFIC_ENABLE_MASK, PMB_ST_BYTE_NONE_OF_ABOVE_MASK);
#elif PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&PMB_ST_WORD_MFR_SPEC_REG_MASK)
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif

#if PMBCFG_USE_STATUS_FANS_1_2
	ENABLE_STATUS_BYTE_MASK(status_fans_1_2, STATUS_FAN_1_2_ENABLE_MASK, PMB_ST_BYTE_NONE_OF_ABOVE_MASK);
#elif PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&PMB_ST_WORD_FANS_REG_MASK)
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif


#if PMBCFG_USE_STATUS_FANS_3_4
	ENABLE_STATUS_BYTE_MASK(status_fans_3_4, STATUS_FAN_3_4_ENABLE_MASK, PMB_ST_BYTE_NONE_OF_ABOVE_MASK);
#elif PMBCFG_USE_STATUS_WORD
	if(pCmdContext->pPageStruct->status_wordh&PMB_ST_WORD_FANS_REG_MASK)
		status_byte |= PMB_ST_BYTE_NONE_OF_ABOVE_MASK;
#endif

	return status_byte;	
}
/*! @} End of aditional_function */
#endif /* (PMBCFG_USE_STATUS_BYTE) || (PMBCFG_USE_STATUS_WORD) */

#if PMBCFG_USE_STATUS_WORD
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Status Word command
* @details          This function implements call-back for Status Byte command. 
*                   - received packet: { Status_Word_Low, Status_Word_High }
*                   - response packet: { Status_Word_Low, Status_Word_High }
*
* @param[in]        pCmdContext         Context of command
* @param[in,out]    pBuffer             Includes received packet, build response here.
* @param[in,out]    pSize               Size of received packet, size of response
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK      Command was performed successfully
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackGetStatWord(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
	{
		// Clear flags by writing 1 to cleared bits
		PMBUS_PAGE_MEMBER maskToClean = (PMBUS_PAGE_MEMBER)(pBuffer[0]&PMB_STATUS_BYTE_MASK);
		maskToClean &= pCmdContext->pPageStruct->status_byte;
		pCmdContext->pPageStruct->status_byte ^= maskToClean;

		maskToClean = (PMBUS_PAGE_MEMBER)(pBuffer[1]&PMB_STATUS_WORDH_MASK);
		maskToClean &= pCmdContext->pPageStruct->status_wordh;
		pCmdContext->pPageStruct->status_wordh ^= maskToClean;
	}
	else
	{
		// Get value of high byte of Status Word register, mask all valid bits (which are not defined by other Status register)
		PMBUS_PAGE_MEMBER highStatByte = (PMBUS_PAGE_MEMBER)(pCmdContext->pPageStruct->status_wordh&PMB_STATUS_WORDH_MASK);
		// Get status Byte Flags
		pBuffer[0] = (PMBUS_BUFFER)PMB_GetStatByte(pCmdContext);
		
		// Build response of high status byte from Status registers
#if PMBCFG_USE_STATUS_VOUT
		if(pCmdContext->pPageStruct->status_vout)
			highStatByte |= PMB_ST_WORD_VOUT_FAULT_REG_MASK;
#else
		// set Vout flag, if Vout OV flag was set in byte (current value is in buffer)
		if(pBuffer[0]&PMB_ST_BYTE_VOUT_OV_FAULT_MASK)
			highStatByte |= PMB_ST_WORD_VOUT_FAULT_REG_MASK;
#endif		
#if PMBCFG_USE_STATUS_IOUT
		if(pCmdContext->pPageStruct->status_iout)
			highStatByte |= PMB_ST_WORD_IOUT_FAULT_REG_MASK;
#else
		// set Iout flag, if Iout OC flag was set in byte (current value is in buffer)
		if(pBuffer[0]&PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
			highStatByte |= PMB_ST_WORD_IOUT_FAULT_REG_MASK;
#endif
#if PMBCFG_USE_STATUS_INPUT
		if(pCmdContext->pPageStruct->status_input)
			highStatByte |= PMB_ST_WORD_INPUT_REG_MASK;
#else
		// set Iout flag, if Iout OC flag was set in byte (current value is in buffer)
		if(pBuffer[0]&PMB_ST_BYTE_VIN_UV_FAULT_MASK)
			highStatByte |= PMB_ST_WORD_INPUT_REG_MASK;
#endif
#if PMBCFG_USE_STATUS_MFR_SPECIFIC
		if(pCmdContext->pPageStruct->status_mfr_specific)
			highStatByte |= PMB_ST_WORD_MFR_SPEC_REG_MASK;
#endif
		// callback function to get PowerGood status
#if PMBCFG_USE_CALLBACK_IS_POWER_GOOD
		if(PMBus_IsPowerGood(PMB_GetCurrentPage(pCmdContext)))
			highStatByte |= PMB_ST_WORD_POWER_GOOD_MASK;
#endif
#if PMBCFG_USE_STATUS_FANS_1_2
		if(pCmdContext->pPageStruct->status_fans_1_2)
			highStatByte |= PMB_ST_WORD_FANS_REG_MASK;
#endif
#if PMBCFG_USE_STATUS_FANS_3_4
		if(pCmdContext->pPageStruct->status_fans_3_4)
			highStatByte |= PMB_ST_WORD_FANS_REG_MASK;
#endif
#if PMBCFG_USE_STATUS_OTHER
		if(pCmdContext->pPageStruct->status_other)
			highStatByte |= PMB_ST_WORD_OTHER_REG_MASK;
#endif
		pBuffer[1] = (PMBUS_BUFFER)highStatByte;
		*pSize = 2;
	}
	return PMBUS_OK;
}
/*! @} End of internal_commands */
#endif

#if PMBCFG_USE_COEFFICIENTS
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Coefficients command
* @details          This function implements call-back for Coefficients command. 
*                   - received packet: { Size, Command_Code, ReadWrite }
*                   - response packet: { Size, m_low_byte, m_High_byte, b_low_byte, b_High_byte, R_byte }
*
* @param[in]        pCmdContext         Context of command
* @param[in,out]    pBuffer             Includes received packet, build response here.
* @param[in,out]    pSize               Size of received packet, size of response
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                              Command was performed successfully
*                     - ::PMBUS_ERROR_CMD_NOT_FOUND             Command was not found in the 
*                         @ref pmbus_define_table "Command Table".
*                     - ::PMBUS_ERROR_CMD_INVALID_SIZE          Invalid size of received command
*                     - ::PMBUS_ERROR_CMD_READ_NOT_SUPPORTED    Read is not supported
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackGetCoefficients(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	PMB_CMD_ENTRY* pPageCmd;
#if PMBCFG_USE_INTERNAL_CALLBACK_CHECKS
	if(pBuffer[0] != 2)
		return PMBUS_ERROR_CMD_INVALID_SIZE; //buffer contains invalid size of this command		
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
		return PMBUS_ERROR_CMD_READ_NOT_SUPPORTED;
#endif
	// Get Command Table
	pPageCmd = (PMB_CMD_ENTRY*)PMBus_GetPageTable(PMB_GetCurrentPage(pCmdContext), NULL);
	if(pPageCmd)
	{
		// Get pointer of command
		pPageCmd = PMB_FindCmdPtr((PMBUS_CMD_CODE)pBuffer[1], pPageCmd);
	}

	if(pPageCmd)
	{
		PMBUS_COEF16 tempCoef;
		// Get coefficients
		PMBUS_INDEX coefGrpIndex = PMBus_GetCoefGrpIndex(pPageCmd);
		PMBUS_COEF_GRP_ENTRY* pCoefGrp = PMBus_GetCoefficients(coefGrpIndex);
		
		if(((pPageCmd->cmd_data>>PMB_CFG_FORMAT_SHIFT)&PMB_CFG_FORMAT_DIRECT_MODE) == 0)
			return PMBUS_ERROR_CMD_INVALID_FORMAT;
		
		// build response
		*pSize = 6;
		pBuffer[0] = 5;
		tempCoef = pCoefGrp->mCoef;
		pBuffer[1] = (PMBUS_BUFFER)tempCoef;		//place low byte of m coef
		pBuffer[2] = (PMBUS_BUFFER)(tempCoef>>8);	//place high byte of m coef
		tempCoef = pCoefGrp->bCoef;
		pBuffer[3] = (PMBUS_BUFFER)tempCoef;		//place low byte of b coef
		pBuffer[4] = (PMBUS_BUFFER)(tempCoef>>8);	//place high byte of b coef
		pBuffer[5] = pCoefGrp->rCoef;
		return PMBUS_OK;
	}
	return PMBUS_ERROR_CMD_NOT_FOUND; //command was not found			
}
/*! @} End of internal_commands */
#endif


#if PMBCFG_USE_PAGE_PLUS_WRITE
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Page Plus Write command
* @details          This function implements call-back for Page Plus Write command. 
*                   - received packet: { Size, Page_Number, Command_Code, Data_Packet }
*                     - Data_Packet Byte_Word: { Data_Low,Data_High }
*                     - Data_Packet Data_Block: { data0,data1, data2 .... }
*
* @param[in]        pCmdContext         Context of command
* @param[in,out]    pBuffer             Includes received packet.
* @param[in,out]    pSize               Size of received packet.
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_ERROR_CMD_INVALID_SIZE  Invalid size of received command
*                     - all Errors of ::PMB_Process()
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackPagePlusWrite(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	PMB_PACKET_CONTEXT subCmdContext;
	PMB_PACKET_DATA cmdData;
	PMBUS_ERROR_CODE status = 0;
	
	cmdData.packetLength = (PMBUS_SIZE)((pBuffer[0])-2);

	if((pBuffer[0])>(*pSize))
		return PMBUS_ERROR_CMD_INVALID_SIZE;

	// create own packet context
	PMB_InitCmdContext(&subCmdContext, pBuffer[1], PMB_COMMAND_DECODE | PMB_CALLBACK_TYPE_WRITE);
	cmdData.cmdCode = pBuffer[2];
	// Decode command to get type of command
	status = PMB_Process(&cmdData, &subCmdContext);
	//  Is command presented in table?
	if(!status)
	{
		//  Command is presented in table, next step is to perform command
		PMB_SetCmdContextFlag(&subCmdContext, PMB_PERFORM_COMMAND);
		// initialize temporary pointer to buffer
		cmdData.pBuffer = &pBuffer[3];
		// When is data block detected, buffer must be modified to create block of data
		if((((subCmdContext.pPageCmd->cmd_data)>>PMB_CMD_FLAGS_SHIFT)&PMB_CMD_FLAGS_WRITE_BITS) == PMB_CMD_FLAGS_WRITE_BLOCK)
		{
			// Convert data Block { data0,data1, data2, .... } to { size, data0,data1, data2 .... }
			// store size of data to pBuffer+2, this address is begin of data for command
			*(--cmdData.pBuffer) = (PMBUS_BUFFER)cmdData.packetLength;
			// size of data was increased
			cmdData.packetLength++;
		}
		// Perform command
		status = PMB_Process(&cmdData, &subCmdContext);
	}
	return status;
}
/*! @} End of internal_commands */
#endif

#if PMBCFG_USE_PAGE_PLUS_READ
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Page Plus Read command
* @details          This function implements call-back for Page Plus Read command. 
*                   - received packet: { size, Page_Number, Command_Code, Data_Packet }
*                     - Data_Packet Data_Block: { data0,data1, data2 .... }
*                   - response packet: { size, Packet_to_Send }
*                     - Packet_to_Send Byte_Word: { size, Data_Low,Data_High }
*                     - Packet_to_Send Data_Block: { size, data0,data1, data2 .... }
*                     - Packet_to_Send ProcCallRead: { size, data0,data1, data2 .... }
*
* @param[in]        pCmdContext         Context of command
* @param[in,out]    pBuffer             Includes received packet.
* @param[in,out]    pSize               Size of received packet.
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_ERROR_CMD_INVALID_SIZE  Invalid size of received command
*                     - all Errors of ::PMB_Process()
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackPagePlusRead(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	PMB_PACKET_CONTEXT subCmdContext;
	PMB_PACKET_DATA cmdData;
	PMBUS_ERROR_CODE status;
	PMBUS_FLAGS8 readFlags;
	
#if PMBCFG_USE_INTERNAL_CALLBACK_CHECKS
	if((pBuffer[0])>(*pSize))
		return PMBUS_ERROR_CMD_INVALID_SIZE;
#endif
	// create own packet context
	PMB_InitCmdContext(&subCmdContext, pBuffer[1], PMB_COMMAND_DECODE | PMB_CALLBACK_TYPE_READ);
	cmdData.cmdCode = pBuffer[2];
	// Decode command to get type of command
	status =  PMB_Process(&cmdData, &subCmdContext);
	//  Is command presented in table?
	if(!status)
	{
		//  Command is presented in table, next step is to perform command
		PMB_SetCmdContextFlag(&subCmdContext, PMB_PERFORM_COMMAND | PMB_CALLBACK_TYPE_READ);
		// initialize temporary pointer to buffer
		cmdData.pBuffer = pBuffer;
		cmdData.packetLength = 0;
		// get read flags
		readFlags = (PMBUS_FLAGS8)(((subCmdContext.pPageCmd->cmd_data)>>PMB_CMD_FLAGS_SHIFT)&PMB_CMD_FLAGS_READ_BITS);
		if(readFlags == PMB_CMD_FLAGS_READ_BYTE_WORD)
		{
			// Store response into second byte of buffer
			// { size, Data_Low,Data_High }
			cmdData.pBuffer++;
		}
		else if(readFlags == PMB_CMD_FLAGS_READ_PROCCALL)
		{
			// remove offset in received packet
			PMBUS_BUFFER* pDestBuff = &pBuffer[1];
			PMBUS_BUFFER* pSrcBuff = &pBuffer[3];
			PMBUS_SIZE i;
			// update size of packet
			pBuffer[0] -= 2;
			// converts { size, Page_Number, Command_Code, data0,data1, data2 .... } to { size, data0,data1, data2 .... }
			for (i=0;i<=pBuffer[0];i++)
			{
				*(pDestBuff++)=*(pSrcBuff++);
			}
			// update size of data
			cmdData.packetLength = (PMBUS_SIZE)(*pSize - 2);
		}
		
		// Performs command
		status = PMB_Process(&cmdData, &subCmdContext);
		*pSize = cmdData.packetLength;
		if(readFlags == PMB_CMD_FLAGS_READ_BYTE_WORD)
		{
			// converts response from { Data_Low,Data_High } to { size, Data_Low,Data_High }
			pBuffer[0] = (PMBUS_BUFFER)cmdData.packetLength;
			*pSize += 1;
		}
	}
	return status;
}
/*! @} End of internal_commands */
#endif

#if PMBCFG_USE_PAGE
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Page command
* @details          This function implements call-back for Page command. 
*                   - received packet: { Page_Number }
*                   - response packet: { Page_Number }
*
* @param[in]        pCmdContext                         Context of command
* @param[in,out]    pBuffer                             Includes received packet.
* @param[in,out]    pSize                               Size of received packet.
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                      Command was performed successfully
*                     - ::PMBUS_ERROR_PAGE_NOT_FOUND    Invalid page
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackPage(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
	{
#if PMBCFG_USE_INTERNAL_CALLBACK_CHECKS
		// find page, if table is initialized, store parameter
		if(PMBus_GetPageTable((PMBUS_INDEX)pBuffer[0], &pCmdContext->pPageStruct))
		{
			pmb_struct.page = (PMBUS_INDEX)pBuffer[0];
		}
		else
		{
			return PMBUS_ERROR_PAGE_NOT_FOUND;
		}
#else
		// write parameter directly
		pmb_struct.page = pBuffer[0];

#endif
	}
	else
	{
		pBuffer[0] = (PMBUS_BUFFER)pmb_struct.page;
		*pSize = 1;
	}
	return PMBUS_OK;
}
/*! @} End of internal_commands */
#endif

#if PMBCFG_USE_SMBALERT_MASK
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the SmbusAler_Mask command
* @details          This function implements call-back for SmbusAler_Mask command. 
*                   - received packet for  Write: { Status_Reg, Mask_Byte }
*                   - received packet for Read: { Size=1, Status_Reg }
*                   - response packet for Read: { Size=1, Mask_Byte }
*                   
* @param[in]        pCmdContext         Context of command
* @param[in,out]    pBuffer             Includes received packet.
* @param[in,out]    pSize               Size of received packet.
*
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                      Command was performed successfully
*                     - ::PMBUS_ERROR_CMD_INVALID_PARAM Invalid Status register
* @note             This command expects that all status command codes are 0x78-0x82
*
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackSmbusalertMask(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	PMBUS_CMD_CODE cmdMaskIndex;
	PMBUS_PAGE_MEMBER* pSMBusAlertMask;
	PMBUS_PAGE_MEMBER_INDEX memberOffset;

	// get Code of command
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
		cmdMaskIndex = (PMBUS_CMD_CODE)pBuffer[0];
	else
		cmdMaskIndex = (PMBUS_CMD_CODE)pBuffer[1];

	// transform Code of command to index
	cmdMaskIndex -= PMB_CODE_STATUS_BYTE;
	
	// check if parameter points to Status command
	if(cmdMaskIndex>PMBUS_INDEX_STATUS_FANS_3_4_ALERT_MASK)
		return PMBUS_ERROR_CMD_INVALID_PARAM;
	
	// get member offset
	memberOffset = pmb_IntVar_table[cmdMaskIndex].member_index;
	// check if member is initialized
	if(memberOffset == PMB_PAGE_VAR_INDEX_UNINITIALIZED)
		return PMBUS_ERROR_CMD_INVALID_PARAM;
	
	// get pointer to data, point to next internal register which is Status xx Alert Mask
	pSMBusAlertMask = ((PMBUS_PAGE_MEMBER*)pCmdContext->pPageStruct) + memberOffset + sizeof(PMBUS_PAGE_MEMBER);

	// write to register or read from register
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
	{
		*pSMBusAlertMask = (PMBUS_PAGE_MEMBER) pBuffer[1];
	}
	else
	{
		pBuffer[0] = 1;
		pBuffer[1] = (PMBUS_BUFFER)*pSMBusAlertMask;
		*pSize = 2;
	}
	return PMBUS_OK;
}
/*! @} End of internal_commands */
#endif

#if PMBCFG_USE_CLEAR_FAULTS
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Clear_Faults command
* @details          This function implements call-back for Clear_Faults command. 
* @param[in]        pCmdContext         Context of command
* @param[in,out]    pBuffer             Includes received packet.
* @param[in,out]    pSize               Size of received packet.
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                      Command was performed successfully
*                     - ::PMBUS_ERROR_CMD_EXECUTION     Read is not supported
* @internal
* @version          07-May-2012
******************************************************************************/
PMBUS_ERROR_CODE PMB_CallBackClearFaults(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
#if PMBCFG_USE_INTERNAL_CALLBACK_CHECKS
	if(PMBus_IsRead((PMBUS_CONTEXT)pCmdContext))
		return PMBUS_ERROR_CMD_READ_NOT_SUPPORTED;
#endif
	// clear all status registers
#if PMBCFG_USE_STATUS_BYTE
	pCmdContext->pPageStruct->status_byte = 0;
#endif
#if PMBCFG_USE_STATUS_WORD
	pCmdContext->pPageStruct->status_wordh = 0;
#endif
#if PMBCFG_USE_STATUS_VOUT
	pCmdContext->pPageStruct->status_vout = 0;
#endif
#if PMBCFG_USE_STATUS_IOUT
	pCmdContext->pPageStruct->status_iout = 0;
#endif
#if PMBCFG_USE_STATUS_INPUT
	pCmdContext->pPageStruct->status_input = 0;
#endif
#if PMBCFG_USE_STATUS_TEMPERATURE
	pCmdContext->pPageStruct->status_temperature = 0;
#endif
#if PMBCFG_USE_STATUS_CML
	pCmdContext->pPageStruct->status_cml = 0;
#endif
#if PMBCFG_USE_STATUS_OTHER
	pCmdContext->pPageStruct->status_other = 0;
#endif
#if PMBCFG_USE_STATUS_MFR_SPECIFIC
	pCmdContext->pPageStruct->status_mfr_specific = 0;
#endif
#if PMBCFG_USE_STATUS_FANS_1_2
	pCmdContext->pPageStruct->status_fans_1_2 = 0;
#endif
#if PMBCFG_USE_STATUS_FANS_3_4
	pCmdContext->pPageStruct->status_fans_3_4 = 0;
#endif

	return PMBUS_OK;
}
/*! @} End of internal_commands */
#endif

#if ((PMBCFG_USE_STATUS_VOUT) || (PMBCFG_USE_STATUS_IOUT) || (PMBCFG_USE_STATUS_INPUT) || (PMBCFG_USE_STATUS_TEMPERATURE) || (PMBCFG_USE_STATUS_CML) || (PMBCFG_USE_STATUS_OTHER) || (PMBCFG_USE_STATUS_MFR_SPECIFIC) || (PMBCFG_USE_STATUS_FANS_1_2) || (PMBCFG_USE_STATUS_FANS_3_4))
/*****************************************************************************/
/*! @addtogroup internal_commands
* @{*/
/*****************************************************************************
*//*!
* @brief            Implementation of the Status Registers commands
* @details          This function implements call-back for all Status Register command. 
*                   - received packet for Write: { Status_Byte }
*                   - received packet for Read: { Status_Byte }
*                   
* @param[in]        pCmdContext         Context of command
* @param[in,out]    pBuffer             Includes received packet.
* @param[in,out]    pSize               Size of received packet.
* 
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                      Command was performed successfully
*                     - ::PMBUS_ERROR_CMD_INVALID_PARAM Invalid Status register
*
* @note              This command expects that all status command codes are 0x78-0x82
* @internal
* @version          07-May-2012
******************************************************************************/
//PMBUS_ERROR_CODE PMB_CallBackStatusRegs(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
//{
//	PMBUS_CMD_CODE cmdStatIndex;
//	PMBUS_PAGE_MEMBER* pStatReg;
//	PMBUS_PAGE_MEMBER_INDEX memberOffset;
//
//	// get code of command
//	cmdStatIndex = (PMBUS_CMD_CODE)(pCmdContext->pPageCmd->cmd_data&PMB_CMD_CODE_MASK);
//
//	// transform Code of command to index
//	cmdStatIndex -= PMB_CODE_STATUS_BYTE + PMBUS_INDEX_STATUS_VOUT_ALERT_MASK;
//
//#if PMBCFG_USE_INTERNAL_CALLBACK_CHECKS
//	//check if index points to status registers
//	if(cmdStatIndex>(PMBUS_INDEX_STATUS_FANS_3_4_ALERT_MASK-2))
//		return PMBUS_ERROR_CMD_INVALID_PARAM;
//#endif
//
//	// index was calculated without byte and word register, needs to update the index to include these registers
//	cmdStatIndex +=2;
//
//	memberOffset = pmb_IntVar_table[cmdStatIndex].member_index;
//	// is command enabled?
//	if(memberOffset == 0xffff)
//		return PMBUS_ERROR_CMD_INVALID_PARAM;
//	pStatReg = ((PMBUS_PAGE_MEMBER*)pCmdContext->pPageStruct) + memberOffset;
//
//	// Clear flags or return value of register
//	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
//		*pStatReg &= (PMBUS_PAGE_MEMBER) ~(pBuffer[0]);
//	else
//		pBuffer[0] = (PMBUS_BUFFER)*pStatReg;
//
//	return PMBUS_OK;
//}


/*! @} End of internal_commands */
#endif

