/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   pmbus_private.h
*
* @brief  PMBus internal header file
*
* @version 1.0.15.0
* 
* @date Jun-22-2012
* 
*******************************************************************************/
#ifndef __PMBUS_PRIVATE_H
#define __PMBUS_PRIVATE_H

#include <stddef.h>
#include "pmbus_types.h"
#include "pmbus_cmd.h"


typedef struct _PMB_CMD_ENTRY
{
 	PMBUS_CMD_ENTRY_TYPE cmd_data;
	void* addr;
} PMB_CMD_ENTRY;

typedef struct
{
 	PMBUS_CMD_CODE cmd_Code;
	PMBUS_PAGE_MEMBER_INDEX member_index;
} PMB_MEMBER_CONVERSION_STRUCT;

typedef struct
{
    PMBUS_INDEX page;
    PMBUS_FLAGS8 writeProtect;
} PMB_STRUCT;

typedef struct
{
    PMBUS_PAGE_MEMBER page_flags; //todo remove this member
#if PMBCFG_USE_VOUT_MODE
#if !PMBCFG_CONST_VOUT_MODE
    PMBUS_PAGE_MEMBER vout_mode;
#endif
#endif

// Status flags
//note:PMB_SetErrorState function requires to organize Alert status variable after status variable
#if (PMBCFG_USE_STATUS_BYTE) || (PMBCFG_USE_STATUS_WORD)
	PMBUS_PAGE_MEMBER status_byte;
#if PMBCFG_USE_SMBALERT_MASK
	PMBUS_PAGE_MEMBER status_byte_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_WORD
	PMBUS_PAGE_MEMBER status_wordh;
#if PMBCFG_USE_SMBALERT_MASK
	PMBUS_PAGE_MEMBER status_wordh_alert;
#endif
#endif

#if PMBCFG_USE_STATUS_VOUT
    PMBUS_PAGE_MEMBER status_vout;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_vout_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_IOUT
    PMBUS_PAGE_MEMBER status_iout;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_iout_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_INPUT
    PMBUS_PAGE_MEMBER status_input;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_input_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_TEMPERATURE
    PMBUS_PAGE_MEMBER status_temperature;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_temperature_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_CML
    PMBUS_PAGE_MEMBER status_cml;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_cml_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_OTHER
    PMBUS_PAGE_MEMBER status_other;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_other_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_MFR_SPECIFIC
    PMBUS_PAGE_MEMBER status_mfr_specific;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_mfr_specific_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_FANS_1_2
    PMBUS_PAGE_MEMBER status_fans_1_2;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_fans_1_2_alert;
#endif
#endif
#if PMBCFG_USE_STATUS_FANS_3_4
    PMBUS_PAGE_MEMBER status_fans_3_4;
#if PMBCFG_USE_SMBALERT_MASK
    PMBUS_PAGE_MEMBER status_fans_3_4_alert;
#endif
#endif
    //fault response 
#if PMBCFG_USE_VOUT_OV_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER vout_ov_fault_response;
#endif
#if PMBCFG_USE_VOUT_UV_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER vout_uv_fault_response;
#endif
#if PMBCFG_USE_IOUT_OC_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER iout_oc_fault_response;
#endif
#if PMBCFG_USE_IOUT_OC_LV_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER iout_oc_lv_fault_response;
#endif
#if PMBCFG_USE_IOUT_UC_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER iout_uc_fault_response;
#endif
#if PMBCFG_USE_OT_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER ot_fault_response;
#endif
#if PMBCFG_USE_UT_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER ut_fault_response;
#endif
#if PMBCFG_USE_VIN_OV_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER vin_ov_fault_response;
#endif
#if PMBCFG_USE_VIN_UV_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER vin_uv_fault_response;
#endif
#if PMBCFG_USE_IIN_OC_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER iin_oc_fault_response;
#endif
#if PMBCFG_USE_TON_MAX_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER ton_max_fault_response;
#endif
#if PMBCFG_USE_POUT_OP_FAULT_RESPONSE
    PMBUS_PAGE_MEMBER pout_op_fault_response;
#endif
}PMB_PAGE_STRUCT;

typedef struct _PMB_PACKET_CONTEXT
{
 	PMB_PAGE_STRUCT* pPageStruct;
	PMB_CMD_ENTRY* pPageCmd;
	PMBUS_CMD_CODE cmdCode;
	PMBUS_INDEX pageIndex;
	PMBUS_FLAGS8 packetFlags;
} PMB_PACKET_CONTEXT;

typedef struct
{
 	PMBUS_BUFFER* pBuffer;
	PMBUS_SIZE packetLength;
#if PMBUS_DYNAMIC_BUFFER_SIZE
	PMBUS_SIZE bufferSize;
#endif
	PMBUS_CMD_CODE cmdCode;
} PMB_PACKET_DATA;

//Define size of Communication buffer
#define PMB_COM_BUFFER_SIZE             PMBCFG_BUFFER_SIZE

//define constants
#define PMB_REVISION_INIT                       0x22    //PartI and PartII are PMBus v1.2 compliant

#define PMB_FLAGS_WRITE_PROTECT_MASK            0xe0
#define PMB_FLAGS_WRITE_PROTECT_DISABLEALL      0x80
#define PMB_FLAGS_WRITE_PROTECT_EN_OPERATION    0x40
#define PMB_FLAGS_WRITE_PROTECT_EN_VOUT_CMD     0x20


typedef PMBUS_ERROR_CODE (*PMB_FNC_PTR)(PMB_PACKET_CONTEXT *, PMBUS_BUFFER*, PMBUS_SIZE*);
extern const PMBUS_BUFFER pmb_const_capability_code;
extern const PMBUS_BUFFER pmb_const_vout_mode;
extern const PMBUS_PAGE_MEMBER pmb_const_pmbus_revision;
extern PMB_STRUCT pmb_struct;

#define PMB_CMD_DATA_CAST(x)            ((PMBUS_CMD_ENTRY_TYPE)(x))

//Capability command masks
#define PMB_CAPABILITY_PEC_MASK         0x80
#define PMB_CAPABILITY_PEC_USE          PMB_CAPABILITY_PEC_MASK
#define PMB_CAPABILITY_MAX_SPEED_MASK   0x60
#define PMB_CAPABILITY_MAX_SPEED_100    0x00
#define PMB_CAPABILITY_MAX_SPEED_400    0x20
#define PMB_CAPABILITY_SMBALERT_MASK    0x10
#define PMB_CAPABILITY_SMBALERT_USE     PMB_CAPABILITY_SMBALERT_MASK

//Format codes for query function which returns PMBus format codes
#define PMB_CODE_FORMAT_MASK            (0x07)
#define PMB_CODE_FORMAT_SHIFT           (0x02)
#define PMB_CODE_FORMAT_LINEAR_DATA     (0x00)
#define PMB_CODE_FORMAT_16BIT_SIGNED    (0x01)
#define PMB_CODE_FORMAT_DIRECT_MODE     (0x03)
#define PMB_CODE_FORMAT_8BIT_UNSIGNED   (0x04)
#define PMB_CODE_FORMAT_VID_MODE        (0x05)
#define PMB_CODE_FORMAT_MANUF_SPEC      (0x06)
#define PMB_CODE_FORMAT_DATA_BLOCK      (0x07)



#define PMB_VOUT_MODE_CFG_MASK          (0xE0)
#define PMB_VOUT_MODE_CFG_LINEAR_DATA   (0x00)
#define PMB_VOUT_MODE_CFG_VID           (0x20)
#define PMB_VOUT_MODE_CFG_DIRECT_MODE   (0x40)
#define PMB_VOUT_MODE_EXP_MASK          (0x1F)

//Command code macros
#define PMB_CMD_CODE_SHIFT              (0)
#define PMB_CMD_CODE_MASK               (0xff<<PMB_CMD_CODE_SHIFT)

//Flags definition
#define PMB_CMD_FLAGS_SHIFT             (8)
#define PMB_CMD_FLAGS_MASK              (0xff<<PMB_CMD_FLAGS_SHIFT)
#define PMB_CMD_FLAGS_WRITE_BITS        (0x0C)  // This must be equal to (SMBUS_PACKET_TYPE_WRITE_MASK)
#define PMB_CMD_FLAGS_WRITE_NA          (0x00)  // This must be equal to (SMBUS_PACKET_TYPE_WRITE_NA)
#define PMB_CMD_FLAGS_WRITE_BYTE_WORD   (0x08)  // This must be equal to (SMBUS_PACKET_TYPE_WRITE_BYTE_WORD)
#define PMB_CMD_FLAGS_WRITE_BLOCK       (0x0C)  // This must be equal to (SMBUS_PACKET_TYPE_WRITE_BLOCK)
#define PMB_CMD_FLAGS_WRITE_BYTE        (0x04)  // This must be equal to (SMBUS_PACKET_TYPE_WRITE_SEND_BYTE)

#define PMB_CMD_FLAGS_READ_BITS         (0x03)  // This must be equal to (SMBUS_PACKET_TYPE_READ_MASK)
#define PMB_CMD_FLAGS_READ_NA           (0x00)  // This must be equal to (SMBUS_PACKET_TYPE_READ_NA)
#define PMB_CMD_FLAGS_READ_BYTE_WORD    (0x02)  // This must be equal to (SMBUS_PACKET_TYPE_READ_BYTE_WORD)
#define PMB_CMD_FLAGS_READ_BLOCK        (0x03)  // This must be equal to (SMBUS_PACKET_TYPE_READ_BLOCK)
#define PMB_CMD_FLAGS_READ_PROCCALL     (0x01)  // This must be equal to (SMBUS_PACKET_TYPE_READ_REC_BYTE) //Received Byte type is transformed as ProcCall Read

#define PMB_CMD_FLAGS_WORD_SIZE         (0x10)  // This must be equal to (SMBUS_PACKET_SIZE_MASK)
#define PMB_CMD_FLAGS_CALLBACK          (0x20)
#define PMB_CMD_FLAGS_VOUT_MODE         (0x40)

//Configuration flags definition
#define PMB_CFG_FORMAT_SHIFT            (16)
#define PMB_CFG_FORMAT_MASK             (0xffUL<<PMB_CFG_FORMAT_SHIFT)
#define PMB_CFG_FORMAT_LINEAR_DATA      (0x40)
#define PMB_CFG_FORMAT_VID_MODE         (0x20)
#define PMB_CFG_FORMAT_DIRECT_MODE      (0x10)
#define PMB_CFG_FORMAT_MANUF_SPEC       (0x08)
#define PMB_CFG_FORMAT_16BIT_SIGNED     (0x04)
#define PMB_CFG_FORMAT_8BIT_UNSIGNED    (0x02)
#define PMB_CFG_FORMAT_DATA_BLOCK       (0x01)
//#define PMB_CFG_FORMAT_BYTE_WORD_BITS   (PMB_CFG_FORMAT_LINEAR_DATA|PMB_CFG_FORMAT_DIRECT_MODE|PMB_CFG_FORMAT_VID_MODE|PMB_CFG_FORMAT_MANUF_SPEC|PMB_CFG_FORMAT_16BIT_SIGNED|PMB_CFG_FORMAT_8BIT_UNSIGNED)
//#define PMB_CFG_FORMAT_LIN_DIR_VID_BITS (PMB_CFG_FORMAT_LINEAR_DATA|PMB_CFG_FORMAT_DIRECT_MODE|PMB_CFG_FORMAT_VID_MODE)

//Direct Mode group macros
#define PMB_CFG_DIR_GRP_SHIFT           (24)
#define PMB_CFG_DIR_GRP_MASK            (0x1fUL<<PMB_CFG_DIR_GRP_SHIFT)


//Block size macros
#define PMB_CFG_BLOCK_SIZE_SHIFT        (24)
#define PMB_CFG_BLOCK_SIZE_MASK         (0xffUL<<PMB_CFG_BLOCK_SIZE_SHIFT)

//Prototype of function which returns pointer to page commands/internal registers,
const PMB_CMD_ENTRY* PMBus_GetPageTable(PMBUS_INDEX nTableIndex, PMB_PAGE_STRUCT** ppPageStruct);

//Defines prototype of function which contains all PMBus commands on one page
#define PMB_PAGE_FUNC(id)               PMBus_GetPageTable_##id
#define PMB_PAGE_FUNC_PROTO(id)  const   PMB_CMD_ENTRY* PMB_PAGE_FUNC(id) (PMB_PAGE_STRUCT** ppPageStruct)

//macros which builds correct names of configuration macros
#define PMB_CMD_TABLE(id)               PMB_CmdTable_##id
#define PMB_CMD_CODE_ENTRY(cmd)         PMB_CODE_##cmd
#define PMB_CMD_FLAGS_ENTRY(cmd)        PMB_FLAGS_##cmd

#if PMBCFG_USE_FORMATS
#define PMB_CMD_ENTRY_ITEM(code, flags, access, format, size, type, addr) \
 { (PMB_CMD_DATA_CAST( (((code)<<PMB_CMD_CODE_SHIFT)&PMB_CMD_CODE_MASK) | \
                       ((((flags)&((access)|PMB_CMD_FLAGS_CALLBACK|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE))<<PMB_CMD_FLAGS_SHIFT)&PMB_CMD_FLAGS_MASK) | \
                       (((type)&PMB_CMD_FLAGS_CALLBACK)<<PMB_CMD_FLAGS_SHIFT) | \
                       (PMB_CMD_DATA_CAST((format)<<PMB_CFG_FORMAT_SHIFT)&(PMB_CFG_FORMAT_MASK|PMB_CFG_DIR_GRP_MASK)) | \
                       (((PMB_CMD_DATA_CAST(size))<<PMB_CFG_BLOCK_SIZE_SHIFT)&PMB_CFG_BLOCK_SIZE_MASK) \
                     ) \
   ), \
   (addr)\
 },
#else
#define PMB_CMD_ENTRY_ITEM(code, flags, access, format, size, type, addr) \
 { (PMB_CMD_DATA_CAST( (((code)<<PMB_CMD_CODE_SHIFT)&PMB_CMD_CODE_MASK) | \
                       ((((flags)&((access)|PMB_CMD_FLAGS_CALLBACK|PMB_CMD_FLAGS_WORD_SIZE|PMB_CMD_FLAGS_VOUT_MODE))<<PMB_CMD_FLAGS_SHIFT)&PMB_CMD_FLAGS_MASK) | \
                       (((type)&PMB_CMD_FLAGS_CALLBACK)<<PMB_CMD_FLAGS_SHIFT) \
                     ) \
   ), \
   (addr)\
 },
#endif


// define indexes of the PAGE variable table
#define PMB_PAGE_VAR_INDEX_UNINITIALIZED                0xffffU
#define PMB_GetpPageIntVar(pCmdTable, varIndex)         ((PMBUS_PAGE_MEMBER*)(((pCmdTable)->pInt_page_var)+varIndex))
#define PMB_GET_PAGE_MEMBER_INDEX(name)                 (PMBUS_PAGE_MEMBER_INDEX) offsetof(PMB_PAGE_STRUCT, name)  //((PMBUS_PAGE_MEMBER_INDEX) (PMBUS_PAGE_MEMBER*) (&(((PMB_PAGE_STRUCT*)(0))->name))) //
#define PMB_PAGE_VAR_INT_FLAGS                          PMB_PAGE_MEMBER_INDEX(page_int_flags,0)

#if (PMBCFG_USE_VOUT_MODE) && ((PMBCFG_CONST_VOUT_MODE) == 0)
#define PMB_PAGE_VAR_INDEX_VOUT_MODE                    PMB_GET_PAGE_MEMBER_INDEX(vout_mode)
#endif

#if PMBCFG_USE_VOUT_OV_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_VOUT_OV_FAULT_RESPONSE       PMB_GET_PAGE_MEMBER_INDEX(vout_ov_fault_response)
#endif

#if PMBCFG_USE_VOUT_UV_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_VOUT_UV_FAULT_RESPONSE       PMB_GET_PAGE_MEMBER_INDEX(vout_uv_fault_response)
#endif

#if PMBCFG_USE_IOUT_OC_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_IOUT_OC_FAULT_RESPONSE       PMB_GET_PAGE_MEMBER_INDEX(iout_oc_fault_response)
#endif

#if PMBCFG_USE_IOUT_OC_LV_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_IOUT_OC_LV_FAULT_RESPONSE    PMB_GET_PAGE_MEMBER_INDEX(iout_oc_lv_fault_response)
#endif

#if PMBCFG_USE_IOUT_UC_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_IOUT_UC_FAULT_RESPONSE       PMB_GET_PAGE_MEMBER_INDEX(iout_uc_fault_response)
#endif

#if PMBCFG_USE_OT_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_OT_FAULT_RESPONSE            PMB_GET_PAGE_MEMBER_INDEX(ot_fault_response)
#endif

#if PMBCFG_USE_UT_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_UT_FAULT_RESPONSE            PMB_GET_PAGE_MEMBER_INDEX(ut_fault_response)
#endif

#if PMBCFG_USE_VIN_OV_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_VIN_OV_FAULT_RESPONSE        PMB_GET_PAGE_MEMBER_INDEX(vin_ov_fault_response)
#endif

#if PMBCFG_USE_VIN_UV_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_VIN_UV_FAULT_RESPONSE        PMB_GET_PAGE_MEMBER_INDEX(vin_uv_fault_response)
#endif


#if PMBCFG_USE_IIN_OC_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_IIN_OC_FAULT_RESPONSE        PMB_GET_PAGE_MEMBER_INDEX(iin_oc_fault_response)
#endif

#if PMBCFG_USE_TON_MAX_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_TON_MAX_FAULT_RESPONSE       PMB_GET_PAGE_MEMBER_INDEX(ton_max_fault_response)
#endif

#if PMBCFG_USE_POUT_OP_FAULT_RESPONSE
#define PMB_PAGE_VAR_INDEX_POUT_OP_FAULT_RESPONSE       PMB_GET_PAGE_MEMBER_INDEX(pout_op_fault_response)
#endif

//Flag to perform PMBus Alert on set the error
#define PMB_PAGE_VAR_STATUS_SMBUSALERT_BIT_MASK 0x0080U
#define PMB_PAGE_VAR_INDEX_STATUS_MASK          0x007fU

// status pare registers
// when is SMBALERT_MASK command enabled, every status call includes status register value and also SMBALERT_MASK register
#if (PMBCFG_USE_STATUS_BYTE) || (PMBCFG_USE_STATUS_WORD)
  #define PMB_PAGE_VAR_INDEX_STATUS_BYTE                PMB_GET_PAGE_MEMBER_INDEX(status_byte)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_BYTE_MASK         PMB_GET_PAGE_MEMBER_INDEX(status_byte_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_WORD
  #define PMB_PAGE_VAR_INDEX_STATUS_WORD                PMB_GET_PAGE_MEMBER_INDEX(status_wordh)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_WORD_MASK         PMB_GET_PAGE_MEMBER_INDEX(status_wordh_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_VOUT
  #define PMB_PAGE_VAR_INDEX_STATUS_VOUT                PMB_GET_PAGE_MEMBER_INDEX(status_vout)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_VOUT_MASK         PMB_GET_PAGE_MEMBER_INDEX(status_vout_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_IOUT
  #define PMB_PAGE_VAR_INDEX_STATUS_IOUT                PMB_GET_PAGE_MEMBER_INDEX(status_iout)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_IOUT_MASK         PMB_GET_PAGE_MEMBER_INDEX(status_iout_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_INPUT
  #define PMB_PAGE_VAR_INDEX_STATUS_INPUT               PMB_GET_PAGE_MEMBER_INDEX(status_input)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_INPUT_MASK        PMB_GET_PAGE_MEMBER_INDEX(status_input_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_TEMPERATURE
  #define PMB_PAGE_VAR_INDEX_STATUS_TEMPERATURE         PMB_GET_PAGE_MEMBER_INDEX(status_temperature)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_TEMPERATURE_MASK  PMB_GET_PAGE_MEMBER_INDEX(status_temperature_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_CML
  #define PMB_PAGE_VAR_INDEX_STATUS_CML                 PMB_GET_PAGE_MEMBER_INDEX(status_cml)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_CML_MASK          PMB_GET_PAGE_MEMBER_INDEX(status_cml_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_OTHER
  #define PMB_PAGE_VAR_INDEX_STATUS_OTHER               PMB_GET_PAGE_MEMBER_INDEX(status_other)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_OTHER_MASK        PMB_GET_PAGE_MEMBER_INDEX(status_other_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_MFR_SPECIFIC
  #define PMB_PAGE_VAR_INDEX_STATUS_MFR_SPECIFIC        PMB_GET_PAGE_MEMBER_INDEX(status_mfr_specific)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_MFR_SPECIFIC_MASK PMB_GET_PAGE_MEMBER_INDEX(status_mfr_specific_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_FANS_1_2
  #define PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2            PMB_GET_PAGE_MEMBER_INDEX(status_fans_1_2)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2_MASK     PMB_GET_PAGE_MEMBER_INDEX(status_fans_1_2_alert)
  #endif
#endif

#if PMBCFG_USE_STATUS_FANS_3_4
  #define PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4            PMB_GET_PAGE_MEMBER_INDEX(status_fans_3_4)
  #if PMBCFG_USE_SMBALERT_MASK
    #define PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4_MASK     PMB_GET_PAGE_MEMBER_INDEX(status_fans_3_4_alert)
  #endif
#endif


//bits placed in page_int_flags
/*#define PMB_STAT_FLAG_PMB_BUSY_MASK     0x1
#define PMB_STAT_FLAG_UNKNOWN_MASK      0x2
#define PMB_STAT_FLAG_POWER_GOOD_MASK   0x4
#define PMB_STAT_FLAG_POWER_ON_MASK     0x8*/
#define PMB_SET_SMBUSALERT_BIT (PMBCFG_SEND_SMBUSALERT_ON_CMD_ERROR? PMBUS_CALL_SMBUSALERT:0)



//Status Byte
#define PMB_ST_BYTE_BUSY_MASK             0x80
#define PMB_ST_BYTE_OFF_MASK              0x40
#define PMB_ST_BYTE_VOUT_OV_FAULT_MASK    0x20
#define PMB_ST_BYTE_IOUT_OC_FAULT_MASK    0x10
#define PMB_ST_BYTE_VIN_UV_FAULT_MASK     0x08
#define PMB_ST_BYTE_TEMPERATURE_REG_MASK  0x04
#define PMB_ST_BYTE_CML_REG_MASK          0x02
#define PMB_ST_BYTE_NONE_OF_ABOVE_MASK    0x01

#define PMB_STATUS_BYTE_MASK   ( PMB_ST_BYTE_OFF_MASK \
		                       | PMB_ST_BYTE_VOUT_OV_FAULT_MASK \
                               | PMB_ST_BYTE_IOUT_OC_FAULT_MASK \
                               | PMB_ST_BYTE_VIN_UV_FAULT_MASK \
                               | PMB_ST_BYTE_TEMPERATURE_REG_MASK \
                               )

//79h STATUS_WORD
#define PMB_ST_WORD_VOUT_FAULT_REG_MASK   0x80
#define PMB_ST_WORD_IOUT_FAULT_REG_MASK   0x40
#define PMB_ST_WORD_INPUT_REG_MASK        0x20
#define PMB_ST_WORD_MFR_SPEC_REG_MASK     0x10
#define PMB_ST_WORD_POWER_GOOD_MASK       0x08
#define PMB_ST_WORD_FANS_REG_MASK         0x04
#define PMB_ST_WORD_OTHER_REG_MASK        0x02
#define PMB_ST_WORD_UNKNOWN_MASK          0x01

#define PMB_STATUS_WORDH_MASK   ( PMB_ST_WORD_VOUT_FAULT_REG_MASK \
                                | PMB_ST_WORD_IOUT_FAULT_REG_MASK \
                                | PMB_ST_WORD_POWER_GOOD_MASK \
                                | PMB_ST_WORD_FANS_REG_MASK \
                                )

//7Ah STATUS_VOUT register flags
#define PMB_VOUT_OV_FAULT_MASK            0x80
#define PMB_VOUT_OV_WARNING_MASK          0x40 
#define PMB_VOUT_UV_WARNING_MASK          0x20
#define PMB_VOUT_UV_FAULT_MASK            0x10
#define PMB_STATUS_VOUT_BIT3              0x08
#define PMB_STATUS_VOUT_BIT2              0x04    
#define PMB_STATUS_VOUT_BIT1              0x02    
#define PMB_STATUS_VOUT_BIT0              0x01
#define STATUS_VOUT_ENABLE_MASK          (PMB_VOUT_OV_FAULT_MASK|PMB_VOUT_OV_WARNING_MASK|PMB_VOUT_UV_WARNING_MASK|PMB_VOUT_UV_FAULT_MASK)

//7Bh STATUS_IOUT register flags
#define PMB_IOUT_OC_FAULT_MASK            0x80 
#define PMB_STATUS_IOUT_BIT6              0x40 
#define PMB_IOUT_OC_WARNING_MASK          0x20
#define PMB_STATUS_IOUT_BIT4              0x10
#define PMB_STATUS_IOUT_BIT3              0x08
#define PMB_STATUS_IOUT_BIT2              0x04
#define PMB_POUT_OP_FAULT_MASK            0x02 
#define PMB_POUT_OP_WARNING_MASK          0x01  
#define STATUS_IOUT_ENABLE_MASK          (PMB_IOUT_OC_FAULT_MASK|PMB_IOUT_OC_WARNING_MASK|PMB_POUT_OP_FAULT_MASK|PMB_POUT_OP_WARNING_MASK)

//7Ch STATUS_INPUT register flags
#define PMB_VIN_OV_FAULT_MASK             0x80 
#define PMB_VIN_OV_WARNING_MASK           0x40
#define PMB_VIN_UV_WARNING_MASK           0x20
#define PMB_VIN_UV_FAULT_MASK             0x10
#define PMB_VIN_LOW_UNIT_OFF_MASK         0x08
#define PMB_IIN_OC_FAULT_MASK             0x04
#define PMB_IIN_OC_WARNING_MASK           0x02
#define PMB_PIN_OP_WARNING_MASK           0x01
#define STATUS_INPUT_ENABLE_MASK         (PMB_VIN_UV_WARNING_MASK|PMB_VIN_UV_FAULT_MASK)

//Status Temperature register flags
#define PMB_OT_FAULT_MASK                 0x80
#define PMB_OT_WARNING_MASK               0x40
#define PMB_UT_WARNING_MASK               0x20
#define PMB_UT_FAULT_MASK                 0x10
#define PMB_STATUS_TEMPERATURE_BIT3       0x08
#define PMB_STATUS_TEMPERATURE_BIT2       0x04
#define PMB_STATUS_TEMPERATURE_BIT1       0x02
#define PMB_STATUS_TEMPERATURE_BIT0       0x01
#define STATUS_TEMPERATURE_ENABLE_MASK   (PMB_OT_FAULT_MASK|PMB_OT_WARNING_MASK)

//Status Communication/logic/memory register flags
#define PMB_INVALID_COMMAND_MASK          0x80    //Set the CML bit in the STATUS_BYTE register
#define PMB_INVALID_DATA_MASK             0x40    //Set the CML bit in the STATUS_BYTE register
#define PMB_INVALID_PEC_MASK              0x20    //Set the CML bit in the STATUS_BYTE register
#define PMB_INVALID_MEM_CRC_MASK          0x10
#define PMB_PROCESSOR_FAULT_MASK          0x08
#define PMB_COM_ERROR_MASK                0x02
#define PMB_MEMORY_FAULT_MASK             0x01
#define STATUS_CML_ENABLE_MASK           (0x00)

//Status STATUS_MFR_SPECIFIC
#define PMB_PSU_LINE_STATUS_CHANGE_MASK   0x04
#define PMB_MFR_SPEC_RESERVED1_MASK       0x02
#define PMB_MFR_SPEC_RESERVED0_MASK       0x01
#define STATUS_MFR_SPECIFIC_ENABLE_MASK  (0x00)

//Status Other register flags
#define PMB_HOT_SPARE_MASK                0x01
#define STATUS_OTHER_ENABLE_MASK         (0x00)

//Status Fan 1&2 register flags
#define PMB_FAN_1_FAULT_MASK              0x80
#define PMB_FAN_2_FAULT_MASK              0x40
#define PMB_FAN_1_WARNING_MASK            0x20
#define PMB_FAN_2_WARNING_MASK            0x10
#define PMB_FAN_1_SPEED_OVER_MASK         0x08
#define PMB_FAN_2_SPEED_OVER_MASK         0x04
#define PMB_FAN_AIR_FAULT_MASK            0x02
#define PMB_FAN_AIR_WARNING_MASK          0x01
#define STATUS_FAN_1_2_ENABLE_MASK       (PMB_FAN_2_SPEED_OVER_MASK|PMB_FAN_1_SPEED_OVER_MASK|PMB_FAN_2_WARNING_MASK|PMB_FAN_1_WARNING_MASK|PMB_FAN_2_FAULT_MASK|PMB_FAN_1_FAULT_MASK)

//Status Fan 3&4 register flags
#define PMB_FAN_3_FAULT_MASK              0x80
#define PMB_FAN_4_FAULT_MASK              0x40
#define PMB_FAN_3_WARNING_MASK            0x20
#define PMB_FAN_4_WARNING_MASK            0x10
#define PMB_FAN_3_SPEED_OVER_MASK         0x08
#define PMB_FAN_4_SPEED_OVER_MASK         0x04
#define STATUS_FAN_3_4_ENABLE_MASK       (0x00)

//Implementation of internal commands
#if PMBCFG_USE_PAGE
    #define PMB_IMPL_PAGE_PMBUS_WRITE()                         PMBUS_CMD_SIMPLE(PAGE, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackPage, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_PAGE_PMBUS_READ()                          PMBUS_CMD_SIMPLE(PAGE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmb_struct.page), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_PAGE_PMBUS_RW()                            PMBUS_CMD_SIMPLE(PAGE, PMBUS_READ|PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackPage, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_PAGE_PMBUS_WRITE()
    #define PMB_IMPL_PAGE_PMBUS_READ()
    #define PMB_IMPL_PAGE_PMBUS_RW()
#endif

#if PMBCFG_USE_VOUT_MODE
    #if PMBCFG_CONST_VOUT_MODE
        #define PMB_IMPL_VOUT_MODE_PMBUS_WRITE()                (PMBUS_WRITE option is not supported, please set PMBCFG_CONST_VOUT_MODE),
        #define PMB_IMPL_VOUT_MODE_PMBUS_READ()                 PMBUS_CMD_SIMPLE(VOUT_MODE, PMBUS_READ, PMBUS_TYPE_VARIABLE, (void *)&pmb_const_vout_mode, PMBUS_FORMAT_8BIT_UNSIGNED)
        #define PMB_IMPL_VOUT_MODE_PMBUS_RW()                   (PMBUS_RW option is not supported, please set PMBCFG_CONST_VOUT_MODE),
    #else
        #define PMB_IMPL_VOUT_MODE_PMBUS_WRITE()                PMBUS_CMD_SIMPLE(VOUT_MODE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &pmbus_PageStruct.vout_mode, PMBUS_FORMAT_8BIT_UNSIGNED)
        #define PMB_IMPL_VOUT_MODE_PMBUS_READ()                 PMBUS_CMD_SIMPLE(VOUT_MODE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &pmbus_PageStruct.vout_mode, PMBUS_FORMAT_8BIT_UNSIGNED)
        #define PMB_IMPL_VOUT_MODE_PMBUS_RW()                   PMBUS_CMD_SIMPLE(VOUT_MODE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &pmbus_PageStruct.vout_mode, PMBUS_FORMAT_8BIT_UNSIGNED)
    #endif
#else
    #define PMB_IMPL_VOUT_MODE_PMBUS_WRITE()
    #define PMB_IMPL_VOUT_MODE_PMBUS_READ()
    #define PMB_IMPL_VOUT_MODE_PMBUS_RW()
#endif

#if PMBCFG_USE_CAPABILITY
    #define PMB_IMPL_CAPABILITY_PMBUS_WRITE()                   (PMBUS_WRITE option is not supported on CAPABILITY command),
    #define PMB_IMPL_CAPABILITY_PMBUS_READ()                    PMBUS_CMD_SIMPLE(CAPABILITY, PMBUS_READ, PMBUS_TYPE_VARIABLE, (void *)&pmb_const_capability_code, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_CAPABILITY_PMBUS_RW()                      (PMBUS_RW option is not supported on CAPABILITY command),
#else
    #define PMB_IMPL_CAPABILITY_PMBUS_WRITE()
    #define PMB_IMPL_CAPABILITY_PMBUS_READ()
    #define PMB_IMPL_CAPABILITY_PMBUS_RW()
#endif

#if PMBCFG_USE_QUERY
    #define PMB_IMPL_QUERY_PMBUS_WRITE()                        (PMBUS_WRITE option is not supported on QUERY command),
    #define PMB_IMPL_QUERY_PMBUS_READ()                         PMBUS_CMD_SIMPLE(QUERY, PMBUS_READ, PMBUS_TYPE_CALLBACK, PMB_CallBackQuery, PMBUS_FORMAT_DATA_BLOCK)
    #define PMB_IMPL_QUERY_PMBUS_RW()                           (PMBUS_RW option is not supported on QUERY command),
#else
    #define PMB_IMPL_QUERY_PMBUS_WRITE()
    #define PMB_IMPL_QUERY_PMBUS_READ()
    #define PMB_IMPL_QUERY_PMBUS_RW()
#endif

#if PMBCFG_USE_VOUT_OV_FAULT_RESPONSE
    #define PMB_IMPL_VOUT_OV_FAULT_RESPONSE_PMBUS_WRITE()       PMBUS_CMD_SIMPLE(VOUT_OV_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vout_ov_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VOUT_OV_FAULT_RESPONSE_PMBUS_READ()        PMBUS_CMD_SIMPLE(VOUT_OV_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vout_ov_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VOUT_OV_FAULT_RESPONSE_PMBUS_RW()          PMBUS_CMD_SIMPLE(VOUT_OV_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vout_ov_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_VOUT_OV_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_VOUT_OV_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_VOUT_OV_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_VOUT_UV_FAULT_RESPONSE
    #define PMB_IMPL_VOUT_UV_FAULT_RESPONSE_PMBUS_WRITE()       PMBUS_CMD_SIMPLE(VOUT_UV_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vout_uv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VOUT_UV_FAULT_RESPONSE_PMBUS_READ()        PMBUS_CMD_SIMPLE(VOUT_UV_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vout_uv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VOUT_UV_FAULT_RESPONSE_PMBUS_RW()          PMBUS_CMD_SIMPLE(VOUT_UV_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vout_uv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_VOUT_UV_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_VOUT_UV_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_VOUT_UV_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_IOUT_OC_FAULT_RESPONSE
    #define PMB_IMPL_IOUT_OC_FAULT_RESPONSE_PMBUS_WRITE()       PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_oc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IOUT_OC_FAULT_RESPONSE_PMBUS_READ()        PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_oc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IOUT_OC_FAULT_RESPONSE_PMBUS_RW()          PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_oc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_IOUT_OC_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_IOUT_OC_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_IOUT_OC_FAULT_RESPONSE_PMBUS_RW()
#endif


#if PMBCFG_USE_IOUT_OC_LV_FAULT_RESPONSE
    #define PMB_IMPL_IOUT_OC_LV_FAULT_RESPONSE_PMBUS_WRITE()    PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_oc_lv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IOUT_OC_LV_FAULT_RESPONSE_PMBUS_READ()     PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_oc_lv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IOUT_OC_LV_FAULT_RESPONSE_PMBUS_RW()       PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_oc_lv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_IOUT_OC_LV_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_IOUT_OC_LV_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_IOUT_OC_LV_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_IOUT_UC_FAULT_RESPONSE
    #define PMB_IMPL_IOUT_UC_FAULT_RESPONSE_PMBUS_WRITE()       PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_uc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IOUT_UC_FAULT_RESPONSE_PMBUS_READ()        PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_uc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IOUT_UC_FAULT_RESPONSE_PMBUS_RW()          PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iout_uc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_IOUT_UC_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_IOUT_UC_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_IOUT_UC_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_OT_FAULT_RESPONSE
    #define PMB_IMPL_OT_FAULT_RESPONSE_PMBUS_WRITE()            PMBUS_CMD_SIMPLE(OT_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ot_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_OT_FAULT_RESPONSE_PMBUS_READ()             PMBUS_CMD_SIMPLE(OT_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ot_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_OT_FAULT_RESPONSE_PMBUS_RW()               PMBUS_CMD_SIMPLE(OT_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ot_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_OT_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_OT_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_OT_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_UT_FAULT_RESPONSE
    #define PMB_IMPL_UT_FAULT_RESPONSE_PMBUS_WRITE()            PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ut_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_UT_FAULT_RESPONSE_PMBUS_READ()             PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ut_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_UT_FAULT_RESPONSE_PMBUS_RW()               PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ut_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_UT_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_UT_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_UT_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_VIN_OV_FAULT_RESPONSE
    #define PMB_IMPL_VIN_OV_FAULT_RESPONSE_PMBUS_WRITE()        PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vin_ov_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VIN_OV_FAULT_RESPONSE_PMBUS_READ()         PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vin_ov_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VIN_OV_FAULT_RESPONSE_PMBUS_RW()           PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vin_ov_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_VIN_OV_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_VIN_OV_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_VIN_OV_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_VIN_UV_FAULT_RESPONSE
    #define PMB_IMPL_VIN_UV_FAULT_RESPONSE_PMBUS_WRITE()        PMBUS_CMD_SIMPLE(VIN_UV_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vin_uv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VIN_UV_FAULT_RESPONSE_PMBUS_READ()         PMBUS_CMD_SIMPLE(VIN_UV_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vin_uv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_VIN_UV_FAULT_RESPONSE_PMBUS_RW()           PMBUS_CMD_SIMPLE(VIN_UV_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.vin_uv_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_VIN_UV_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_VIN_UV_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_VIN_UV_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_IIN_OC_FAULT_RESPONSE
    #define PMB_IMPL_IIN_OC_FAULT_RESPONSE_PMBUS_WRITE()        PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iin_oc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IIN_OC_FAULT_RESPONSE_PMBUS_READ()         PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iin_oc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_IIN_OC_FAULT_RESPONSE_PMBUS_RW()           PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.iin_oc_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_IIN_OC_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_IIN_OC_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_IIN_OC_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_TON_MAX_FAULT_RESPONSE
    #define PMB_IMPL_TON_MAX_FAULT_RESPONSE_PMBUS_WRITE()       PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ton_max_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_TON_MAX_FAULT_RESPONSE_PMBUS_READ()        PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ton_max_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_TON_MAX_FAULT_RESPONSE_PMBUS_RW()          PMBUS_CMD_SIMPLE(IOUT_OC_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.ton_max_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_TON_MAX_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_TON_MAX_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_TON_MAX_FAULT_RESPONSE_PMBUS_RW()
#endif

#if PMBCFG_USE_POUT_OP_FAULT_RESPONSE
    #define PMB_IMPL_POUT_OP_FAULT_RESPONSE_PMBUS_WRITE()       PMBUS_CMD_SIMPLE(POUT_OP_FAULT_RESPONSE, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.pout_op_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_POUT_OP_FAULT_RESPONSE_PMBUS_READ()        PMBUS_CMD_SIMPLE(POUT_OP_FAULT_RESPONSE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.pout_op_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_POUT_OP_FAULT_RESPONSE_PMBUS_RW()          PMBUS_CMD_SIMPLE(POUT_OP_FAULT_RESPONSE, PMBUS_RW, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.pout_op_fault_response), PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_POUT_OP_FAULT_RESPONSE_PMBUS_WRITE()
    #define PMB_IMPL_POUT_OP_FAULT_RESPONSE_PMBUS_READ()
    #define PMB_IMPL_POUT_OP_FAULT_RESPONSE_PMBUS_RW()
#endif


#if PMBCFG_USE_STATUS_BYTE
    #define PMB_IMPL_STATUS_BYTE_PMBUS_WRITE()                  PMBUS_CMD_SIMPLE(STATUS_BYTE, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackGetStatByte, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_BYTE_PMBUS_READ()                   PMBUS_CMD_SIMPLE(STATUS_BYTE, PMBUS_READ, PMBUS_TYPE_CALLBACK, PMB_CallBackGetStatByte, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_BYTE_PMBUS_RW()                     PMBUS_CMD_SIMPLE(STATUS_BYTE, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackGetStatByte, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_BYTE_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_BYTE_PMBUS_READ()
    #define PMB_IMPL_STATUS_BYTE_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_WORD
    #define PMB_IMPL_STATUS_WORD_PMBUS_WRITE()                  PMBUS_CMD_SIMPLE(STATUS_WORD, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackGetStatWord, PMBUS_FORMAT_16BIT_SIGNED)
    #define PMB_IMPL_STATUS_WORD_PMBUS_READ()                   PMBUS_CMD_SIMPLE(STATUS_WORD, PMBUS_READ, PMBUS_TYPE_CALLBACK, PMB_CallBackGetStatWord, PMBUS_FORMAT_16BIT_SIGNED)
    #define PMB_IMPL_STATUS_WORD_PMBUS_RW()                     PMBUS_CMD_SIMPLE(STATUS_WORD, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackGetStatWord, PMBUS_FORMAT_16BIT_SIGNED)
#else
    #define PMB_IMPL_STATUS_WORD_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_WORD_PMBUS_READ()
    #define PMB_IMPL_STATUS_WORD_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_VOUT
    #define PMB_IMPL_STATUS_VOUT_PMBUS_WRITE()                  PMBUS_CMD_SIMPLE(STATUS_VOUT, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_VOUT_PMBUS_READ()                   PMBUS_CMD_SIMPLE(STATUS_VOUT, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_vout), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_VOUT_PMBUS_RW()                     PMBUS_CMD_SIMPLE(STATUS_VOUT, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_VOUT_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_VOUT_PMBUS_READ()
    #define PMB_IMPL_STATUS_VOUT_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_IOUT
    #define PMB_IMPL_STATUS_IOUT_PMBUS_WRITE()                  PMBUS_CMD_SIMPLE(STATUS_IOUT, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_IOUT_PMBUS_READ()                   PMBUS_CMD_SIMPLE(STATUS_IOUT, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_iout), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_IOUT_PMBUS_RW()                     PMBUS_CMD_SIMPLE(STATUS_IOUT, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_IOUT_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_IOUT_PMBUS_READ()
    #define PMB_IMPL_STATUS_IOUT_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_INPUT
    #define PMB_IMPL_STATUS_INPUT_PMBUS_WRITE()                 PMBUS_CMD_SIMPLE(STATUS_INPUT, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_INPUT_PMBUS_READ()                  PMBUS_CMD_SIMPLE(STATUS_INPUT, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_input), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_INPUT_PMBUS_RW()                    PMBUS_CMD_SIMPLE(STATUS_INPUT, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_INPUT_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_INPUT_PMBUS_READ()
    #define PMB_IMPL_STATUS_INPUT_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_TEMPERATURE
    #define PMB_IMPL_STATUS_TEMPERATURE_PMBUS_WRITE()           PMBUS_CMD_SIMPLE(STATUS_TEMPERATURE, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_TEMPERATURE_PMBUS_READ()            PMBUS_CMD_SIMPLE(STATUS_TEMPERATURE, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_temperature), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_TEMPERATURE_PMBUS_RW()              PMBUS_CMD_SIMPLE(STATUS_TEMPERATURE, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_TEMPERATURE_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_TEMPERATURE_PMBUS_READ()
    #define PMB_IMPL_STATUS_TEMPERATURE_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_CML
    #define PMB_IMPL_STATUS_CML_PMBUS_WRITE()                   PMBUS_CMD_SIMPLE(STATUS_CML, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_CML_PMBUS_READ()                    PMBUS_CMD_SIMPLE(STATUS_CML, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_cml), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_CML_PMBUS_RW()                      PMBUS_CMD_SIMPLE(STATUS_CML, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_CML_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_CML_PMBUS_READ()
    #define PMB_IMPL_STATUS_CML_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_OTHER
    #define PMB_IMPL_STATUS_OTHER_PMBUS_WRITE()                 PMBUS_CMD_SIMPLE(STATUS_OTHER, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_OTHER_PMBUS_READ()                  PMBUS_CMD_SIMPLE(STATUS_OTHER, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_other), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_OTHER_PMBUS_RW()                    PMBUS_CMD_SIMPLE(STATUS_OTHER, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_OTHER_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_OTHER_PMBUS_READ()
    #define PMB_IMPL_STATUS_OTHER_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_MFR_SPECIFIC
    #define PMB_IMPL_STATUS_MFR_SPECIFIC_PMBUS_WRITE()          PMBUS_CMD_SIMPLE(STATUS_MFR_SPECIFIC, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_MFR_SPECIFIC_PMBUS_READ()           PMBUS_CMD_SIMPLE(STATUS_MFR_SPECIFIC, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_mfr_specific), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_MFR_SPECIFIC_PMBUS_RW()             PMBUS_CMD_SIMPLE(STATUS_MFR_SPECIFIC, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_MFR_SPECIFIC_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_MFR_SPECIFIC_PMBUS_READ()
    #define PMB_IMPL_STATUS_MFR_SPECIFIC_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_FANS_1_2
    #define PMB_IMPL_STATUS_FANS_1_2_PMBUS_WRITE()              PMBUS_CMD_SIMPLE(STATUS_FANS_1_2, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_FANS_1_2_PMBUS_READ()               PMBUS_CMD_SIMPLE(STATUS_FANS_1_2, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_fans_1_2), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_FANS_1_2_PMBUS_RW()                 PMBUS_CMD_SIMPLE(STATUS_FANS_1_2, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_FANS_1_2_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_FANS_1_2_PMBUS_READ()
    #define PMB_IMPL_STATUS_FANS_1_2_PMBUS_RW()
#endif

#if PMBCFG_USE_STATUS_FANS_3_4
    #define PMB_IMPL_STATUS_FANS_3_4_PMBUS_WRITE()              PMBUS_CMD_SIMPLE(STATUS_FANS_3_4, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_FANS_3_4_PMBUS_READ()               PMBUS_CMD_SIMPLE(STATUS_FANS_3_4, PMBUS_READ, PMBUS_TYPE_VARIABLE, &(pmbus_PageStruct.status_fans_3_4), PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_STATUS_FANS_3_4_PMBUS_RW()                 PMBUS_CMD_SIMPLE(STATUS_FANS_3_4, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackStatusRegs, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_STATUS_FANS_3_4_PMBUS_WRITE()
    #define PMB_IMPL_STATUS_FANS_3_4_PMBUS_READ()
    #define PMB_IMPL_STATUS_FANS_3_4_PMBUS_RW()
#endif


#if PMBCFG_USE_COEFFICIENTS
    #define PMB_IMPL_COEFFICIENTS_PMBUS_WRITE()                 (PMBUS_WRITE option is not supported on COEFFICIENTS command),
    #define PMB_IMPL_COEFFICIENTS_PMBUS_READ()                  PMBUS_CMD_DATA_BLOCK(COEFFICIENTS, PMBUS_READ, PMBUS_TYPE_CALLBACK, PMB_CallBackGetCoefficients, 0, 2) //lenght of received packet
    #define PMB_IMPL_COEFFICIENTS_PMBUS_RW()                    (PMBUS_RW option is not supported on COEFFICIENTS command),
#else
    #define PMB_IMPL_COEFFICIENTS_PMBUS_WRITE()
    #define PMB_IMPL_COEFFICIENTS_PMBUS_READ()
    #define PMB_IMPL_COEFFICIENTS_PMBUS_RW()
#endif

#if PMBCFG_USE_PAGE_PLUS_WRITE
    #define PMB_IMPL_PAGE_PLUS_WRITE_PMBUS_WRITE()              PMBUS_CMD_DATA_BLOCK(PAGE_PLUS_WRITE, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackPagePlusWrite, 0, 0)
    #define PMB_IMPL_PAGE_PLUS_WRITE_PMBUS_READ()               (PMBUS_READ option is not supported on PAGE_PLUS_WRITE command),
    #define PMB_IMPL_PAGE_PLUS_WRITE_PMBUS_RW()                 (PMBUS_RW option is not supported on PAGE_PLUS_WRITE command),
#else
    #define PMB_IMPL_PAGE_PLUS_WRITE_PMBUS_WRITE()
    #define PMB_IMPL_PAGE_PLUS_WRITE_PMBUS_READ()
    #define PMB_IMPL_PAGE_PLUS_WRITE_PMBUS_RW()
#endif

#if PMBCFG_USE_PAGE_PLUS_READ
    #define PMB_IMPL_PAGE_PLUS_READ_PMBUS_WRITE()               (PMBUS_WRITE option is not supported on PAGE_PLUS_READ command),
    #define PMB_IMPL_PAGE_PLUS_READ_PMBUS_READ()                PMBUS_CMD_DATA_BLOCK(PAGE_PLUS_READ, PMBUS_READ, PMBUS_TYPE_CALLBACK, PMB_CallBackPagePlusRead, 0, 2)
    #define PMB_IMPL_PAGE_PLUS_READ_PMBUS_RW()                  (PMBUS_RW option is not supported on PAGE_PLUS_READ command),
#else
    #define PMB_IMPL_PAGE_PLUS_READ_PMBUS_WRITE()
    #define PMB_IMPL_PAGE_PLUS_READ_PMBUS_READ()
    #define PMB_IMPL_PAGE_PLUS_READ_PMBUS_RW()
#endif

#if PMBCFG_USE_SMBALERT_MASK
    #define PMB_IMPL_SMBALERT_MASK_PMBUS_WRITE()                PMBUS_CMD_DATA_BLOCK(SMBALERT_MASK, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackSmbusalertMask, PMBUS_FORMAT_DATA_BLOCK, 1)
    #define PMB_IMPL_SMBALERT_MASK_PMBUS_READ()                 PMBUS_CMD_DATA_BLOCK(SMBALERT_MASK, PMBUS_READ, PMBUS_TYPE_CALLBACK, PMB_CallBackSmbusalertMask, PMBUS_FORMAT_DATA_BLOCK, 1)
    #define PMB_IMPL_SMBALERT_MASK_PMBUS_RW()                   PMBUS_CMD_DATA_BLOCK(SMBALERT_MASK, PMBUS_RW, PMBUS_TYPE_CALLBACK, PMB_CallBackSmbusalertMask, PMBUS_FORMAT_DATA_BLOCK, 1)
#else
    #define PMB_IMPL_SMBALERT_MASK_PMBUS_WRITE()
    #define PMB_IMPL_SMBALERT_MASK_PMBUS_READ()
    #define PMB_IMPL_SMBALERT_MASK_PMBUS_RW()
#endif

#if PMBCFG_USE_CLEAR_FAULTS
    #define PMB_IMPL_CLEAR_FAULTS_PMBUS_WRITE()                 PMBUS_CMD_DATA_BLOCK(CLEAR_FAULTS, PMBUS_WRITE, PMBUS_TYPE_CALLBACK, PMB_CallBackClearFaults, 0, 0)
    #define PMB_IMPL_CLEAR_FAULTS_PMBUS_READ()                  (PMBUS_READ option is not supported on CLEAR_FAULTS command),
    #define PMB_IMPL_CLEAR_FAULTS_PMBUS_RW()                    (PMBUS_RW option is not supported on CLEAR_FAULTS command),
#else
    #define PMB_IMPL_CLEAR_FAULTS_PMBUS_WRITE()
    #define PMB_IMPL_CLEAR_FAULTS_PMBUS_READ()
    #define PMB_IMPL_CLEAR_FAULTS_PMBUS_RW()
#endif

#if PMBCFG_USE_WRITE_PROTECT
    #define PMB_IMPL_WRITE_PROTECT_PMBUS_WRITE()                PMBUS_CMD_SIMPLE(WRITE_PROTECT, PMBUS_WRITE, PMBUS_TYPE_VARIABLE, &pmb_struct.writeProtect, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_WRITE_PROTECT_PMBUS_READ()                 PMBUS_CMD_SIMPLE(WRITE_PROTECT, PMBUS_READ, PMBUS_TYPE_VARIABLE, &pmb_struct.writeProtect, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_WRITE_PROTECT_PMBUS_RW()                   PMBUS_CMD_SIMPLE(WRITE_PROTECT, PMBUS_RW, PMBUS_TYPE_VARIABLE, &pmb_struct.writeProtect, PMBUS_FORMAT_8BIT_UNSIGNED)
#else
    #define PMB_IMPL_WRITE_PROTECT_PMBUS_WRITE()
    #define PMB_IMPL_WRITE_PROTECT_PMBUS_READ()
    #define PMB_IMPL_WRITE_PROTECT_PMBUS_RW()
#endif

#if PMBCFG_USE_PMBUS_REVISION
    #define PMB_IMPL_PMBUS_REVISION_PMBUS_WRITE()              (PMBUS_WRITE option is not supported on PAGE_PLUS_READ command),
    #define PMB_IMPL_PMBUS_REVISION_PMBUS_READ()               PMBUS_CMD_SIMPLE(PMBUS_REVISION, PMBUS_READ, PMBUS_TYPE_VARIABLE, (void *)&pmb_const_pmbus_revision, PMBUS_FORMAT_8BIT_UNSIGNED)
    #define PMB_IMPL_PMBUS_REVISION_PMBUS_RW()                 (PMBUS_RW option is not supported on PAGE_PLUS_WRITE command),
#else
    #define PMB_IMPL_PMBUS_REVISION_PMBUS_WRITE()
    #define PMB_IMPL_PMBUS_REVISION_PMBUS_READ()
    #define PMB_IMPL_PMBUS_REVISION_PMBUS_RW()
#endif


//internal flags
#define PMB_CALLBACK_TYPE_MASK          0x1
#define PMB_CALLBACK_TYPE_WRITE         PMB_CALLBACK_TYPE_MASK
#define PMB_CALLBACK_TYPE_READ          0x0
#define PMB_PERFORM_COMMAND             0x80
#define PMB_COMMAND_DECODED             0x40
#define PMB_COMMAND_DECODE              0x20
#define PMB_DECODE_AND_PERFORM (PMB_PERFORM_COMMAND | PMB_COMMAND_DECODED)

//Macros to access to internal flags
#define PMB_InitCmdContext(pCmdContext, pageIndexInit, flagsInit) do{ (pCmdContext)->pageIndex = (pageIndexInit);(pCmdContext)->packetFlags = (flagsInit);(pCmdContext)->pPageCmd = NULL;}while(0)
#define PMB_SetCmdContextFlag(pCmdContext, flagsSet) (pCmdContext)->packetFlags |= (flagsSet)
#define PMB_TestCmdContextFlag(pCmdContext, flagsSet) (pCmdContext)->packetFlags & (flagsSet)
#define PMB_ClearCmdContextFlag(pCmdContext, flagsSet) (pCmdContext)->packetFlags &= ~(flagsSet)

//check of configuration
#if (PMBCFG_USE_QUERY) && (PMBCFG_USE_FORMATS == 0)
#error "QUERY command requires Formats of commands. Please set PMBCFG_USE_FORMATS macro to 1"
#endif

#if (PMBCFG_USE_COEFFICIENTS) && (PMBCFG_USE_FORMATS == 0)
#error "COEFFICIENTS command requires Formats of commands. Please set PMBCFG_USE_FORMATS macro to 1"
#endif

#if (PMBCFG_USE_SMBALERT_RESPONSE) && ((PMBCFG_USE_STATUS_WORD) == 0)
#error "SMBus Alert cannot be build, please set PMBCFG_USE_STATUS_WORD macro to 1"
#endif

//Prototypes of internal functions
PMBUS_ERROR_CODE PMB_Process(PMB_PACKET_DATA* pCmdData, PMB_PACKET_CONTEXT* pCmdContext);
static PMB_CMD_ENTRY* PMB_FindCmdPtr(PMBUS_CMD_CODE cmdCode, PMB_CMD_ENTRY* ppTableIndex);
static PMBUS_PAGE_MEMBER PMB_GetStatByte(PMB_PACKET_CONTEXT* pCmdTable);
static PMBUS_ERROR_CODE PMB_SetErrorState(PMBUS_PAGE_MEMBER_INDEX statBitCode, PMB_PAGE_STRUCT* pCmdContext);
static PMBUS_ERROR_CODE PMB_ResetErrorState(PMBUS_PAGE_MEMBER_INDEX statBitCode, PMB_PAGE_STRUCT* pPageStruct);
PMBUS_ERROR_CODE PMB_CallBackQuery(PMB_PACKET_CONTEXT* pCmdTable, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackGetStatByte(PMB_PACKET_CONTEXT* pCmdTable, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackGetCoefficients(PMB_PACKET_CONTEXT* pCmdTable, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackGetStatWord(PMB_PACKET_CONTEXT* pCmdTable, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackPagePlusWrite(PMB_PACKET_CONTEXT* pCmdTable, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackPagePlusRead(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackPage(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackSmbusalertMask(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackClearFaults(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);
PMBUS_ERROR_CODE PMB_CallBackStatusRegs(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);

#define PMB_GetCurrentPage(pCmdContext) ((pCmdContext)->pageIndex)

#endif /* __PMBUS_PRIVATE_H */

// Risks:
// - when user set 0 address of var/funct to table, algorithm end searching command
// - when coefficients have different numbers for read and for write
// - protect register (pmb_struct.writeProtect) is defined by PMBUS_FLAGS8 type
