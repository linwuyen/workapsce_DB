/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   pmbus.h
*
* @brief  PMBus Public API header file
*
* @version 1.0.17.0
* 
* @date Jun-19-2012
* 
*******************************************************************************/

#ifndef __PMBUS_H
#define __PMBUS_H

#include "pmbus_cfg.h"
#include "pmbus_private.h"

/**************************************************************************/ /*!
 * @brief Structure containing m, b and R coefficients for DIRECT Data Format
 *
 * This structure is used by some of the @ref pmbus_format "Data Format Functions"
 *****************************************************************************/
typedef struct
{
 	PMBUS_COEF16        mCoef;  ///< m coefficient of Direct Data Format.
 	PMBUS_COEF16        bCoef;  ///< b coefficient of Direct Data Format.
 	PMBUS_COEF8         rCoef;  ///< R coefficient of Direct Data Format.
} PMBUS_COEF_GRP_ENTRY;


/**************************************************************************/ /*!
 * @brief Structure contains all PMBus internal registers
 *
 *****************************************************************************/
typedef struct
{
    PMBUS_PAGE_MEMBER status_byte_alert;         ///<  status_byte_alert member.
    PMBUS_PAGE_MEMBER status_wordh_alert;        ///<  status_wordh_alert member.
    PMBUS_PAGE_MEMBER status_vout_alert;         ///<  status_vout_alert member.
    PMBUS_PAGE_MEMBER status_iout_alert;         ///<  status_iout_alert member.
    PMBUS_PAGE_MEMBER status_input_alert;        ///<  status_input_alert member.
    PMBUS_PAGE_MEMBER status_temperature_alert;  ///<  status_temperature_alert member.
    PMBUS_PAGE_MEMBER status_cml_alert;          ///<  status_cml_alert member.
    PMBUS_PAGE_MEMBER status_other_alert;        ///<  status_other_alert member.
    PMBUS_PAGE_MEMBER status_mfr_specific_alert; ///<  status_mfr_specific_alert member.
    PMBUS_PAGE_MEMBER status_fans_1_2_alert;     ///<  status_fans_1_2_alert member.
    PMBUS_PAGE_MEMBER status_fans_3_4_alert;     ///<  status_fans_3_4_alert member.
    PMBUS_PAGE_MEMBER vout_mode;                 ///<  vout_mode member.
    PMBUS_PAGE_MEMBER vout_ov_fault_response;    ///<  vout_ov_fault_response member.
    PMBUS_PAGE_MEMBER vout_uv_fault_response;    ///<  vout_uv_fault_response member.
    PMBUS_PAGE_MEMBER iout_oc_fault_response;    ///<  iout_oc_fault_response member.
    PMBUS_PAGE_MEMBER iout_oc_lv_fault_response; ///<  iout_oc_lv_fault_response member.
    PMBUS_PAGE_MEMBER iout_uc_fault_response;    ///<  iout_uc_fault_response member.
    PMBUS_PAGE_MEMBER ot_fault_response;         ///<  ot_fault_response member.
    PMBUS_PAGE_MEMBER ut_fault_response;         ///<  ut_fault_response member.
    PMBUS_PAGE_MEMBER vin_ov_fault_response;     ///<  vin_ov_fault_response member.
    PMBUS_PAGE_MEMBER vin_uv_fault_response;     ///<  vin_uv_fault_response member.
    PMBUS_PAGE_MEMBER iin_oc_fault_response;     ///<  iin_oc_fault_response member.
    PMBUS_PAGE_MEMBER ton_max_fault_response;    ///<  ton_max_fault_response member.
    PMBUS_PAGE_MEMBER pout_op_fault_response;    ///<  pout_op_fault_response member.
} PMBUS_INTERNAL_REGISTERS;

/*****************************************************************************
* PMBus indexes of internal registers used by PMBus_GetPageIntVarByIndex() and PMBus_GetIntVarByIndex() functions
*
*//*! @addtogroup pmbus_internal_var_indexes
* @{
*******************************************************************************/
#define PMBUS_INTERNAL_TABLE_SIZE                   sizeof(PMBUS_INTERNAL_REGISTERS)         ///< This macro represents count of internal page registers which could be stored or restored in user application.
#define PMBUS_INDEX_STATUS_BYTE_ALERT_MASK          0U          ///< Index of the Status Byte Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_WORD_ALERT_MASK          1U          ///< Index of the Status Word Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_VOUT_ALERT_MASK          2U          ///< Index of the Status VOut Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_IOUT_ALERT_MASK          3U          ///< Index of the Status IOut Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_INPUT_ALERT_MASK         4U          ///< Index of the Status Input Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_TEMPERATURE_ALERT_MASK   5U          ///< Index of the Status Temperature Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_CML_ALERT_MASK           6U          ///< Index of the Status Cml Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_OTHER_ALERT_MASK         7U          ///< Index of the Status Other Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_MFR_SPECIFIC_ALERT_MASK  8U          ///< Index of the Status Mfr Spec. Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_FANS_1_2_ALERT_MASK      9U          ///< Index of the Status Fans 1,2 Alert Mask internal page register.
#define PMBUS_INDEX_STATUS_FANS_3_4_ALERT_MASK      10U         ///< Index of the Status Fans 3.4 Alert Mask internal page register.
#define PMBUS_INDEX_VOUT_MODE                       11U         ///< Index of the VOut Mode internal page register.
#define PMBUS_INDEX_VOUT_OV_FAULT_RESPONSE          12U         ///< Index of the VOut OV Fault Response internal page register.
#define PMBUS_INDEX_VOUT_UV_FAULT_RESPONSE          13U         ///< Index of the VOut UV Fault Response internal page register.
#define PMBUS_INDEX_IOUT_OC_FAULT_RESPONSE          14U         ///< Index of the IOut OC Fault Response internal page register.
#define PMBUS_INDEX_IOUT_OC_LV_FAULT_RESPONSE       15U         ///< Index of the IOut OC LV Fault Response internal page register.
#define PMBUS_INDEX_IOUT_UC_FAULT_RESPONSE          16U         ///< Index of the IOut UC Fault Response internal page register.
#define PMBUS_INDEX_OT_FAULT_RESPONSE               17U         ///< Index of the OT Fault Response internal page register.
#define PMBUS_INDEX_UT_FAULT_RESPONSE               18U         ///< Index of the UT Fault Response internal page register.
#define PMBUS_INDEX_VIN_OV_FAULT_RESPONSE           19U         ///< Index of the VIn OV Fault Response internal page register.
#define PMBUS_INDEX_VIN_UV_FAULT_RESPONSE           20U         ///< Index of the VIn UV Fault Response internal page register.
#define PMBUS_INDEX_IIN_OC_FAULT_RESPONSE           21U         ///< Index of the IIn OC Fault Response internal page register.
#define PMBUS_INDEX_TON_MAX_FAULT_RESPONSE          22U         ///< Index of the TOn MAX Fault Response internal page register.
#define PMBUS_INDEX_POUT_OP_FAULT_RESPONSE          23U         ///< Index of the POut OP Fault Response internal page register.
/*! @} End of pmbus_status_bit_ids */

/*****************************************************************************
* Boolean values used by the stack
*
*//*! @addtogroup pmbus_bool
* @{
******************************************************************************/
#define PMBUS_FALSE     0       ///< boolean value FALSE (0).
#define PMBUS_TRUE      1       ///< boolean value TRUE (1).
/*! @} End of pmbus_bool */

/*****************************************************************************
* Error codes used by the stack
*
*//*! @addtogroup pmbus_error
* @{
******************************************************************************/
#define PMBUS_OK                                 0      ///< Success
#define PMBUS_ERROR_ALERT_NOT_SEND               2      ///< PMBus Alert message was not send
#define PMBUS_ERROR_PAGE_NOT_FOUND               3      ///< Required Page was not found
#define PMBUS_ERROR_CMD_NOT_FOUND                4      ///< Command was not found in Command Table
#define PMBUS_ERROR_CMD_INVALID_PARAM            5      ///< Invalid command parameter
#define PMBUS_ERROR_CMD_PROTECTED                6      ///< Command is write-protected
#define PMBUS_ERROR_CMD_INVALID_SIZE             7      ///< Invalid size of received packet
#define PMBUS_ERROR_CMD_INVALID_RESP_SIZE        8      ///< Invalid size of response packet
#define PMBUS_ERROR_CMD_EXECUTION                9      ///< Error during command execution
#define PMBUS_ERROR_CMD_CALLBACK_ADDRESS        10      ///< Call-back address was not initialized
#define PMBUS_ERROR_CMD_READ_NOT_SUPPORTED      11      ///< Read is not supported
#define PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED     12      ///< Write is not supported
#define PMBUS_ERROR_CMD_INVALID_FORMAT          128     ///< Command format is invalid
#define PMBUS_ALERT_RESPONSE_ENABLED            128     ///< Alert response is enabled
/*! @} End of pmbus_error */


/*****************************************************************************
* PMBus Fault Response registers used as parameter of PMBus_GetFaultResponseType() function
*
*//*! @addtogroup pmbus_fault_response_ids
* @{
******************************************************************************/
#if PMBCFG_USE_STATUS_VOUT
  #define PMBUS_FAULT_ID_VOUT_OV        PMB_PAGE_VAR_INDEX_VOUT_OV_FAULT_RESPONSE     ///< Get Fault Response for Over Voltage fault flag in Status VOut register
  #define PMBUS_FAULT_ID_VOUT_UV        PMB_PAGE_VAR_INDEX_VOUT_UV_FAULT_RESPONSE     ///< Get Fault Response for Under Voltage fault flag in Status VOut register
  #define PMBUS_FAULT_ID_TON_MAX        PMB_PAGE_VAR_INDEX_TON_MAX_FAULT_RESPONSE     ///< Get Fault Response for TOn Max fault flag in Status VOut register
#endif
#if PMBCFG_USE_STATUS_IOUT
  #define PMBUS_FAULT_ID_IOUT_OC        PMB_PAGE_VAR_INDEX_IOUT_OC_FAULT_RESPONSE     ///< Get Fault Response for Over Current fault flag in Status IOut register
  #define PMBUS_FAULT_ID_IOUT_OC_LV     PMB_PAGE_VAR_INDEX_IOUT_OC_LV_FAULT_RESPONSE  ///< Get Fault Response for Over Current and Low Voltage fault flags in Status IOut register
  #define PMBUS_FAULT_ID_IOUT_UC        PMB_PAGE_VAR_INDEX_IOUT_UC_FAULT_RESPONSE     ///< Get Fault Response for Under Current fault flag in Status IOut register
  #define PMBUS_FAULT_ID_POUT_OP        PMB_PAGE_VAR_INDEX_POUT_OP_FAULT_RESPONSE     ///< Get Fault Response for Over Power fault flag in Status IOut register
#endif
#if PMBCFG_USE_STATUS_INPUT
  #define PMBUS_FAULT_ID_VIN_OV         PMB_PAGE_VAR_INDEX_VIN_OV_FAULT_RESPONSE      ///< Get Fault Response for Over Voltage fault flag in Status Input register
  #define PMBUS_FAULT_ID_VIN_UV         PMB_PAGE_VAR_INDEX_VIN_UV_FAULT_RESPONSE      ///< Get Fault Response for Under Voltage fault flag in Status Input register
  #define PMBUS_FAULT_ID_IIN_OC         PMB_PAGE_VAR_INDEX_IIN_OC_FAULT_RESPONSE      ///< Get Fault Response for Over Current fault flag in Status Input register
#endif
#if PMBCFG_USE_STATUS_TEMPERATURE
  #define PMBUS_FAULT_ID_OT             PMB_PAGE_VAR_INDEX_OT_FAULT_RESPONSE          ///< Get Fault Response for Over Temperature fault flag in Status Temperature register
  #define PMBUS_FAULT_ID_UT             PMB_PAGE_VAR_INDEX_UT_FAULT_RESPONSE          ///< Get Fault Response for Under Temperature fault flag in Status Temperature register
#endif
/*! @} End of pmbus_fault_response_ids */

/*****************************************************************************
* PMBus Status bits used as parameter of the PMB_SetErrorState() function
*
*//*! @addtogroup pmbus_status_bit_ids
* @{
*******************************************************************************/

//This macro is used only with PMBUS_STATUS_xxx, the SmbusAler bit, must be moved to upper byte
#define PMBUS_CALL_SMBUSALERT           (PMB_PAGE_VAR_STATUS_SMBUSALERT_BIT_MASK<<8)                                    ///< This bit can be combined with status value to instruct the PMBus_SetErrorState() function to send SMBus alert, if is enabled by Status Mask registers

//Status Byte
#if PMBCFG_USE_STATUS_BYTE
  #define PMBUS_STATUS_BYTE_BUSY             (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_BUSY_MASK)               ///< Sets the Busy flag in the Status Byte register.
  #define PMBUS_STATUS_BYTE_OFF              (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_OFF_MASK)                ///< Sets the Off flag in the Status Byte register.
  #define PMBUS_STATUS_BYTE_VOUT_OV_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_VOUT_OV_FAULT_MASK)      ///< Sets the Vout_OV flag in the Status Byte register.
  #define PMBUS_STATUS_BYTE_IOUT_OC_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)      ///< Sets the Iout_OC flag in the Status Byte register.
  #define PMBUS_STATUS_BYTE_VIN_UV_FAULT     (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_VIN_UV_FAULT_MASK)       ///< Sets the VIN_UV flag in the Status Byte register.
  #define PMBUS_STATUS_BYTE_TEMPERATURE_REG  (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_TEMPERATURE_REG_MASK)    ///< Sets the Temperature flag in the Status Byte register.
  #define PMBUS_STATUS_BYTE_CML_REG          (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_CML_REG_MASK)            ///< Sets the CML flag in the Status Byte register.

#else
  #define PMBUS_STATUS_BYTE_BUSY          0U
#endif

//Status Word
#if PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_WORD_UNKNOWN       (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_UNKNOWN_MASK)            ///< Sets the Unknown flag in the Status Word register.
#else
  #define PMBUS_STATUS_WORD_UNKNOWN       0U
#endif

//Status VOut Flags
#if PMBCFG_USE_STATUS_VOUT
  #define PMBUS_STATUS_VOUT_OV_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_VOUT_OV_FAULT_MASK)                ///< Sets the VOut the Over Voltage fault flag in the Status VOut register.
  #define PMBUS_STATUS_VOUT_OV_WARNING  (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_VOUT_OV_WARNING_MASK)              ///< Sets the VOut the Over Voltage warning flag in the Status VOut register.
  #define PMBUS_STATUS_VOUT_UV_WARNING  (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_VOUT_UV_WARNING_MASK)              ///< Sets the VOut the Under Voltage warning flag in the Status VOut register.
  #define PMBUS_STATUS_VOUT_UV_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_VOUT_UV_FAULT_MASK)                ///< Sets the VOut the Under Voltage fault flag in the Status VOut register.
  #define PMBUS_STATUS_VOUT_MAX_WARNING (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_VOUT_MAX_WARNING_MASK)             ///< Sets the VOut the Max Warning flag in the Status VOut register.
  #define PMBUS_STATUS_TON_MAX_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_TON_MAX_FAULT_MASK)                ///< Sets the VOut the TON Max fault flag in the Status VOut register.
  #define PMBUS_STATUS_TOFF_MAX_WARNING (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_TOFF_MAX_WARNING_MASK)             ///< Sets the VOut the TOFF Max Warning flag in the Status VOut register.
  #define PMBUS_STATUS_VOUT_TRACK_ERROR (((PMB_PAGE_VAR_INDEX_STATUS_VOUT)<<8) | PMB_VOUT_TRACK_ERROR_MASK)             ///< Sets the VOut the Tracking Error flag in the Status VOut register.
#elif PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_WORD_VOUT        (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_VOUT_FAULT_REG_MASK)
  #define PMBUS_STATUS_VOUT_OV_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_VOUT_OV_FAULT_MASK)
  #define PMBUS_STATUS_VOUT_OV_WARNING  PMBUS_STATUS_WORD_VOUT
  #define PMBUS_STATUS_VOUT_UV_WARNING  PMBUS_STATUS_WORD_VOUT
  #define PMBUS_STATUS_VOUT_UV_FAULT    PMBUS_STATUS_WORD_VOUT
  #define PMBUS_STATUS_VOUT_MAX_WARNING PMBUS_STATUS_WORD_VOUT
  #define PMBUS_STATUS_TON_MAX_FAULT    PMBUS_STATUS_WORD_VOUT
  #define PMBUS_STATUS_TOFF_MAX_WARNING PMBUS_STATUS_WORD_VOUT
  #define PMBUS_STATUS_VOUT_TRACK_ERROR PMBUS_STATUS_WORD_VOUT
#elif PMBCFG_USE_STATUS_BYTE
  #define PMBUS_STATUS_VOUT_OV_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_VOUT_OV_FAULT_MASK)
  #define PMBUS_STATUS_VOUT_OV_WARNING  0U
  #define PMBUS_STATUS_VOUT_UV_WARNING  0U
  #define PMBUS_STATUS_VOUT_UV_FAULT    0U
  #define PMBUS_STATUS_VOUT_MAX_WARNING 0U
  #define PMBUS_STATUS_TON_MAX_FAULT    0U
  #define PMBUS_STATUS_TOFF_MAX_WARNING 0U
  #define PMBUS_STATUS_VOUT_TRACK_ERROR 0U
#else
  #define PMBUS_STATUS_VOUT_OV_FAULT    0U
  #define PMBUS_STATUS_VOUT_OV_WARNING  0U
  #define PMBUS_STATUS_VOUT_UV_WARNING  0U
  #define PMBUS_STATUS_VOUT_UV_FAULT    0U
  #define PMBUS_STATUS_VOUT_MAX_WARNING 0U
  #define PMBUS_STATUS_TON_MAX_FAULT    0U
  #define PMBUS_STATUS_TOFF_MAX_WARNING 0U
  #define PMBUS_STATUS_VOUT_TRACK_ERROR 0U

#endif

//Status IOut Flags
#if PMBCFG_USE_STATUS_IOUT
  #define PMBUS_STATUS_IOUT_OC_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_IOUT_OC_FAULT_MASK)                ///< Sets the the IOut Over Current fault flag in the Status IOut register.
  #define PMBUS_STATUS_IOUT_OC_LV_FAULT (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_IOUT_OC_LV_FAULT_MASK)             ///< Sets the the IOut Over Current and Low Voltage fault flag in the Status IOut register.
  #define PMBUS_STATUS_IOUT_OC_WARNING  (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_IOUT_OC_WARNING_MASK)              ///< Sets the the IOut Over Current warning flag in the Status IOut register.
  #define PMBUS_STATUS_IOUT_UC_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_IOUT_UC_FAULT_MASK)                ///< Sets the the Under Current fault flag in the Status IOut register.
  #define PMBUS_STATUS_IOUT_SHARE_FAULT (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_IOUT_SHARE_FAULT_MASK)             ///< Sets the the Current Share fault flag in the Status IOut register.
  #define PMBUS_STATUS_POWER_LIMIT_MODE (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_POWER_LIMIT_MODE_MASK)             ///< Sets the the Power Limit Mode flag in the Status IOut register.
  #define PMBUS_STATUS_POUT_OP_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_POUT_OP_FAULT_MASK)                ///< Sets the the Pout Over Power fault flag in the Status IOut register.
  #define PMBUS_STATUS_POUT_OP_WARNING  (((PMB_PAGE_VAR_INDEX_STATUS_IOUT)<<8) | PMB_POUT_OP_WARNING_MASK)              ///< Sets the the Pout Over Power warning flag in the Status IOut register.
#elif PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_WORD_IOUTPOUT    (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_IOUT_FAULT_REG_MASK)
  #define PMBUS_STATUS_IOUT_OC_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
  #define PMBUS_STATUS_IOUT_OC_LV_FAULT (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
  #define PMBUS_STATUS_IOUT_OC_WARNING  PMBUS_STATUS_WORD_IOUTPOUT
  #define PMBUS_STATUS_IOUT_UC_FAULT    PMBUS_STATUS_WORD_IOUTPOUT
  #define PMBUS_STATUS_IOUT_SHARE_FAULT PMBUS_STATUS_WORD_IOUTPOUT
  #define PMBUS_STATUS_POWER_LIMIT_MODE PMBUS_STATUS_WORD_IOUTPOUT
  #define PMBUS_STATUS_POUT_OP_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
  #define PMBUS_STATUS_POUT_OP_WARNING  (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
#elif PMBCFG_USE_STATUS_BYTE
  #define PMBUS_STATUS_IOUT_OC_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
  #define PMBUS_STATUS_IOUT_OC_LV_FAULT (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
  #define PMBUS_STATUS_IOUT_OC_WARNING  0U
  #define PMBUS_STATUS_IOUT_UC_FAULT    0U
  #define PMBUS_STATUS_IOUT_SHARE_FAULT 0U
  #define PMBUS_STATUS_POWER_LIMIT_MODE 0U
  #define PMBUS_STATUS_POUT_OP_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
  #define PMBUS_STATUS_POUT_OP_WARNING  (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_IOUT_OC_FAULT_MASK)
#else
  #define PMBUS_STATUS_IOUT_OC_FAULT    0U
  #define PMBUS_STATUS_IOUT_OC_LV_FAULT 0U
  #define PMBUS_STATUS_IOUT_OC_WARNING  0U
  #define PMBUS_STATUS_IOUT_UC_FAULT    0U
  #define PMBUS_STATUS_IOUT_SHARE_FAULT 0U
  #define PMBUS_STATUS_POWER_LIMIT_MODE 0U
  #define PMBUS_STATUS_POUT_OP_FAULT    0U
  #define PMBUS_STATUS_POUT_OP_WARNING  0U
#endif

//Status Input Flags
#if PMBCFG_USE_STATUS_INPUT
  #define PMBUS_STATUS_VIN_OV_FAULT     (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_VIN_OV_FAULT_MASK)                ///< Sets the the Vin Over Voltage fault flag in the Status Input register.
  #define PMBUS_STATUS_VIN_OV_WARNING   (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_VIN_OV_WARNING_MASK)              ///< Sets the the Vin Over Voltage warning flag in the Status Input register.
  #define PMBUS_STATUS_VIN_UV_WARNING   (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_VIN_UV_WARNING_MASK)              ///< Sets the the Vin Under Voltage warning flag in the Status Input register.
  #define PMBUS_STATUS_VIN_UV_FAULT     (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_VIN_UV_FAULT_MASK)                ///< Sets the the Vin Under Voltage fault flag in the Status Input register.
  #define PMBUS_STATUS_VIN_LOW_UNIT_OFF (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_VIN_LOW_UNIT_OFF_MASK)            ///< Sets the the Unit Off flag in the Status Input register.
  #define PMBUS_STATUS_IIN_OC_FAULT     (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_IIN_OC_FAULT_MASK)                ///< Sets the the Iin Over Current fault flag in the Status Input register.
  #define PMBUS_STATUS_IIN_OC_WARNING   (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_IIN_OC_WARNING_MASK)              ///< Sets the the Iin Over Current warning flag in the Status Input register.
  #define PMBUS_STATUS_PIN_OP_WARNING   (((PMB_PAGE_VAR_INDEX_STATUS_INPUT)<<8) | PMB_PIN_OP_WARNING_MASK)              ///< Sets the the Pin Over Power warning flag in the Status Input register.
#elif PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_WORD_INPUT       (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_INPUT_REG_MASK)
  #define PMBUS_STATUS_VIN_OV_FAULT     PMBUS_STATUS_WORD_INPUT
  #define PMBUS_STATUS_VIN_OV_WARNING   PMBUS_STATUS_WORD_INPUT
  #define PMBUS_STATUS_VIN_UV_WARNING   PMBUS_STATUS_WORD_INPUT
  #define PMBUS_STATUS_VIN_UV_FAULT     (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_VIN_UV_FAULT_MASK)
  #define PMBUS_STATUS_VIN_LOW_UNIT_OFF PMBUS_STATUS_WORD_INPUT
  #define PMBUS_STATUS_IIN_OC_FAULT     PMBUS_STATUS_WORD_INPUT
  #define PMBUS_STATUS_IIN_OC_WARNING   PMBUS_STATUS_WORD_INPUT
  #define PMBUS_STATUS_PIN_OP_WARNING   PMBUS_STATUS_WORD_INPUT
#elif PMBCFG_USE_STATUS_BYTE
  #define PMBUS_STATUS_VIN_OV_FAULT     0U
  #define PMBUS_STATUS_VIN_OV_WARNING   0U
  #define PMBUS_STATUS_VIN_UV_WARNING   0U
  #define PMBUS_STATUS_VIN_UV_FAULT     (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_VIN_UV_FAULT_MASK)
  #define PMBUS_STATUS_VIN_LOW_UNIT_OFF 0U
  #define PMBUS_STATUS_IIN_OC_FAULT     0U
  #define PMBUS_STATUS_IIN_OC_WARNING   0U
  #define PMBUS_STATUS_PIN_OP_WARNING   0U
#else
  #define PMBUS_STATUS_VIN_OV_FAULT     0U
  #define PMBUS_STATUS_VIN_OV_WARNING   0U
  #define PMBUS_STATUS_VIN_UV_WARNING   0U
  #define PMBUS_STATUS_VIN_UV_FAULT     0U
  #define PMBUS_STATUS_VIN_LOW_UNIT_OFF 0U
  #define PMBUS_STATUS_IIN_OC_FAULT     0U
  #define PMBUS_STATUS_IIN_OC_WARNING   0U
  #define PMBUS_STATUS_PIN_OP_WARNING   0U
#endif


//Status MFR specific
#if PMBCFG_USE_STATUS_MFR_SPECIFIC
  #define PMBUS_STATUS_MFR_PSU_LINE_STATUS_CHANGE  (((PMB_PAGE_VAR_INDEX_STATUS_MFR_SPECIFIC)<<8) | PMB_PSU_LINE_STATUS_CHANGE_MASK)    
  #define PMBUS_STATUS_MFR_SPEC_RESERVED1          (((PMB_PAGE_VAR_INDEX_STATUS_MFR_SPECIFIC)<<8) | PMB_MFR_SPEC_RESERVED1_MASK)        
  #define PMBUS_STATUS_MFR_SPEC_RESERVED0          (((PMB_PAGE_VAR_INDEX_STATUS_MFR_SPECIFIC)<<8) | PMB_MFR_SPEC_RESERVED0_MASK) 
#elif PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_MFR_SPEC(flags)  (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_MFR_SPEC_REG_MASK)
#else
  #define PMBUS_STATUS_MFR_SPEC(flags)  0U
#endif

//Status Fan 1&2 Flags
#if PMBCFG_USE_STATUS_FANS_1_2
  #define PMBUS_STATUS_FAN_1_FAULT      (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_1_FAULT_MASK)              ///< Sets the the Fan 1 fault flag in the Status Fans 1&2 register.
  #define PMBUS_STATUS_FAN_2_FAULT      (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_2_FAULT_MASK)              ///< Sets the the Fan 2 fault flag in the Status Fans 1&2 register.
  #define PMBUS_STATUS_FAN_1_WARNING    (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_1_WARNING_MASK)            ///< Sets the the Fan 1 warning flag in the Status Fans 1&2 register.
  #define PMBUS_STATUS_FAN_2_WARNING    (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_2_WARNING_MASK)            ///< Sets the the Fan 2 warning flag in the Status Fans 1&2 register.
  #define PMBUS_STATUS_FAN_1_SPEED_OVER (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_1_SPEED_OVER_MASK)         ///< Sets the the Speed Overridden flag for Fan 1 in the Status Fans 1&2 register.
  #define PMBUS_STATUS_FAN_2_SPEED_OVER (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_2_SPEED_OVER_MASK)         ///< Sets the the Speed Overridden flag for Fan 2 in the Status Fans 1&2 register.
  #define PMBUS_STATUS_FAN_AIR_FAULT    (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_AIR_FAULT_MASK)            ///< Sets the the Airflow fault flag in the Status Fans 1&2 register.
  #define PMBUS_STATUS_FAN_AIR_WARNING  (((PMB_PAGE_VAR_INDEX_STATUS_FANS_1_2)<<8) | PMB_FAN_AIR_WARNING_MASK)          ///< Sets the the Airflow warning flag in the Status Fans 1&2 register.
#elif PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_WORD_FANS12      (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_FANS_REG_MASK)
  #define PMBUS_STATUS_FAN_1_FAULT      PMBUS_STATUS_WORD_FANS12
  #define PMBUS_STATUS_FAN_2_FAULT      PMBUS_STATUS_WORD_FANS12
  #define PMBUS_STATUS_FAN_1_WARNING    PMBUS_STATUS_WORD_FANS12
  #define PMBUS_STATUS_FAN_2_WARNING    PMBUS_STATUS_WORD_FANS12
  #define PMBUS_STATUS_FAN_1_SPEED_OVER PMBUS_STATUS_WORD_FANS12
  #define PMBUS_STATUS_FAN_2_SPEED_OVER PMBUS_STATUS_WORD_FANS12
  #define PMBUS_STATUS_FAN_AIR_FAULT    PMBUS_STATUS_WORD_FANS12
  #define PMBUS_STATUS_FAN_AIR_WARNING  PMBUS_STATUS_WORD_FANS12
#else
  #define PMBUS_STATUS_FAN_1_FAULT      0U
  #define PMBUS_STATUS_FAN_2_FAULT      0U
  #define PMBUS_STATUS_FAN_1_WARNING    0U
  #define PMBUS_STATUS_FAN_2_WARNING    0U
  #define PMBUS_STATUS_FAN_1_SPEED_OVER 0U
  #define PMBUS_STATUS_FAN_2_SPEED_OVER 0U
  #define PMBUS_STATUS_FAN_AIR_FAULT    0U
  #define PMBUS_STATUS_FAN_AIR_WARNING  0U
#endif
//Status Fan 3&4 Flags
#if PMBCFG_USE_STATUS_FANS_3_4
  #define PMBUS_STATUS_FAN_3_FAULT      (((PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4)<<8) | PMB_FAN_3_FAULT_MASK)              ///< Sets the the Fan 3 fault flag in the Status Fans 3&4 register.
  #define PMBUS_STATUS_FAN_4_FAULT      (((PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4)<<8) | PMB_FAN_4_FAULT_MASK)              ///< Sets the the Fan 4 fault flag in the Status Fans 3&4 register.
  #define PMBUS_STATUS_FAN_3_WARNING    (((PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4)<<8) | PMB_FAN_3_WARNING_MASK)            ///< Sets the the Fan 3 warning flag in the Status Fans 3&4 register.
  #define PMBUS_STATUS_FAN_4_WARNING    (((PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4)<<8) | PMB_FAN_4_WARNING_MASK)            ///< Sets the the Fan 4 warning flag in the Status Fans 3&4 register.
  #define PMBUS_STATUS_FAN_3_SPEED_OVER (((PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4)<<8) | PMB_FAN_3_SPEED_OVER_MASK)         ///< Sets the the Speed Overridden flag for Fan 3 in the Status Fans 3&4 register.
  #define PMBUS_STATUS_FAN_4_SPEED_OVER (((PMB_PAGE_VAR_INDEX_STATUS_FANS_3_4)<<8) | PMB_FAN_4_SPEED_OVER_MASK)         ///< Sets the the Speed Overridden flag for Fan 4 in the Status Fans 3&4 register.
#elif PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_WORD_FANS34      (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_FANS_REG_MASK)
  #define PMBUS_STATUS_FAN_3_FAULT      PMBUS_STATUS_WORD_FANS34
  #define PMBUS_STATUS_FAN_4_FAULT      PMBUS_STATUS_WORD_FANS34
  #define PMBUS_STATUS_FAN_3_WARNING    PMBUS_STATUS_WORD_FANS34
  #define PMBUS_STATUS_FAN_4_WARNING    PMBUS_STATUS_WORD_FANS34
  #define PMBUS_STATUS_FAN_3_SPEED_OVER PMBUS_STATUS_WORD_FANS34
  #define PMBUS_STATUS_FAN_4_SPEED_OVER PMBUS_STATUS_WORD_FANS34
#else
  #define PMBUS_STATUS_FAN_3_FAULT      0U
  #define PMBUS_STATUS_FAN_4_FAULT      0U
  #define PMBUS_STATUS_FAN_3_WARNING    0U
  #define PMBUS_STATUS_FAN_4_WARNING    0U
  #define PMBUS_STATUS_FAN_3_SPEED_OVER 0U
  #define PMBUS_STATUS_FAN_4_SPEED_OVER 0U
#endif

//Status Other Flags
#if PMBCFG_USE_STATUS_OTHER
  #define PMBUS_STATUS_HOT_SPARE_FAULT   (((PMB_PAGE_VAR_INDEX_STATUS_OTHER)<<8) | PMB_HOT_SPARE_MASK)                ///< Sets the the Output OR-ing Device flag in the Status Other register.
#elif PMBCFG_USE_STATUS_WORD
  #define PMBUS_STATUS_WORD_OTHER       (((PMB_PAGE_VAR_INDEX_STATUS_WORD)<<8) | PMB_ST_WORD_OTHER_REG_MASK)
  #define PMBUS_STATUS_HOT_SPARE_FAULT  PMBUS_STATUS_WORD_OTHER
#else
  #define PMBUS_STATUS_HOT_SPARE_FAULT 0U
#endif

//Status Temperature Flags
#if PMBCFG_USE_STATUS_TEMPERATURE
  #define PMBUS_STATUS_OT_FAULT         (((PMB_PAGE_VAR_INDEX_STATUS_TEMPERATURE)<<8) | PMB_OT_FAULT_MASK)              ///< Sets the the Over Temperature fault flag in the Status Temperature register.
  #define PMBUS_STATUS_OT_WARNING       (((PMB_PAGE_VAR_INDEX_STATUS_TEMPERATURE)<<8) | PMB_OT_WARNING_MASK)            ///< Sets the the Over Temperature warning flag in the Status Temperature register.
  #define PMBUS_STATUS_UT_WARNING       (((PMB_PAGE_VAR_INDEX_STATUS_TEMPERATURE)<<8) | PMB_UT_WARNING_MASK)            ///< Sets the the Under Temperature warning flag in the Status Temperature register.
  #define PMBUS_STATUS_UT_FAULT         (((PMB_PAGE_VAR_INDEX_STATUS_TEMPERATURE)<<8) | PMB_UT_FAULT_MASK)              ///< Sets the the Under Temperature fault flag in the Status Temperature register.
#elif (PMBCFG_USE_STATUS_BYTE)||(PMBCFG_USE_STATUS_WORD)
  #define PMBUS_STATUS_BYTE_TEMPERATURE (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_TEMPERATURE_REG_MASK)
  #define PMBUS_STATUS_OT_FAULT         PMBUS_STATUS_BYTE_TEMPERATURE
  #define PMBUS_STATUS_OT_WARNING       PMBUS_STATUS_BYTE_TEMPERATURE
  #define PMBUS_STATUS_UT_WARNING       PMBUS_STATUS_BYTE_TEMPERATURE
  #define PMBUS_STATUS_UT_FAULT         PMBUS_STATUS_BYTE_TEMPERATURE
#else
  #define PMBUS_STATUS_OT_FAULT         0U
  #define PMBUS_STATUS_OT_WARNING       0U
  #define PMBUS_STATUS_UT_WARNING       0U
  #define PMBUS_STATUS_UT_FAULT         0U
#endif

// Status Communication/logic/memory Flags
#if PMBCFG_USE_STATUS_CML
  #define PMBUS_STATUS_INVALID_COMMAND  (((PMB_PAGE_VAR_INDEX_STATUS_CML)<<8) | PMB_INVALID_COMMAND_MASK)               ///< Sets the the Invalid/Unsupported Command Received flag in the Status CML register.
  #define PMBUS_STATUS_INVALID_DATA     (((PMB_PAGE_VAR_INDEX_STATUS_CML)<<8) | PMB_INVALID_DATA_MASK)                  ///< Sets the the Invalid/Unsupported Data Received flag in the Status CML register.
  #define PMBUS_STATUS_INVALID_PEC      (((PMB_PAGE_VAR_INDEX_STATUS_CML)<<8) | PMB_INVALID_PEC_MASK)                   ///< Sets the the Packet Error Check (PEC) flag in the Status CML register.
  #define PMBUS_STATUS_INVALID_MEM_CRC  (((PMB_PAGE_VAR_INDEX_STATUS_CML)<<8) | PMB_INVALID_MEM_CRC_MASK)               ///< Sets the the Memory Fault Detected flag in the Status CML register.
  #define PMBUS_STATUS_PROCESSOR_FAULT  (((PMB_PAGE_VAR_INDEX_STATUS_CML)<<8) | PMB_PROCESSOR_FAULT_MASK)               ///< Sets the the Processor Fault Detected flag in the Status CML register.
  #define PMBUS_STATUS_COM_ERROR        (((PMB_PAGE_VAR_INDEX_STATUS_CML)<<8) | PMB_COM_ERROR_MASK)                     ///< Sets the the Communication fault flag in the Status CML register.
  #define PMBUS_STATUS_MEMORY_FAULT     (((PMB_PAGE_VAR_INDEX_STATUS_CML)<<8) | PMB_MEMORY_FAULT_MASK)                  ///< Sets the the Other Memory or Logic fault flag in the Status CML register.
#elif (PMBCFG_USE_STATUS_BYTE)||(PMBCFG_USE_STATUS_WORD)
  #define PMBUS_STATUS_BYTE_CML         (((PMB_PAGE_VAR_INDEX_STATUS_BYTE)<<8) | PMB_ST_BYTE_CML_REG_MASK)
  #define PMBUS_STATUS_INVALID_COMMAND  PMBUS_STATUS_BYTE_CML
  #define PMBUS_STATUS_INVALID_DATA     PMBUS_STATUS_BYTE_CML
  #define PMBUS_STATUS_INVALID_PEC      PMBUS_STATUS_BYTE_CML
  #define PMBUS_STATUS_INVALID_MEM_CRC  PMBUS_STATUS_BYTE_CML
  #define PMBUS_STATUS_PROCESSOR_FAULT  PMBUS_STATUS_BYTE_CML
  #define PMBUS_STATUS_COM_ERROR        PMBUS_STATUS_BYTE_CML
  #define PMBUS_STATUS_MEMORY_FAULT     PMBUS_STATUS_BYTE_CML
#else
  #define PMBUS_STATUS_INVALID_COMMAND  0U
  #define PMBUS_STATUS_INVALID_DATA     0U
  #define PMBUS_STATUS_INVALID_PEC      0U
  #define PMBUS_STATUS_INVALID_MEM_CRC  0U
  #define PMBUS_STATUS_PROCESSOR_FAULT  0U
  #define PMBUS_STATUS_COM_ERROR        0U
  #define PMBUS_STATUS_MEMORY_FAULT     0U
#endif
/*! @} End of pmbus_status_bit_ids */

/*****************************************************************************
*//*! @addtogroup pmbus_command_entry
* @brief Macros used to build the PMBus command tables (=pages)
* @{*/

/*****************************************************************************
*//*!
* @brief    Begins of the PMBus page table
* @details  This macro is used to begin the PMBus table which represents one PMBus page.
******************************************************************************/
#define PMBUS_PAGE_BEGIN(id) \
    PMB_PAGE_FUNC_PROTO(id); \
    PMB_PAGE_FUNC_PROTO(id) { \
        static PMB_PAGE_STRUCT pmbus_PageStruct; \
        static const PMB_CMD_ENTRY pmbus_PageTable[] = { 

/*****************************************************************************
*//*!
* @brief    Defines a simple command in a page table
* @details  This macro is used to put a command descriptor into a PMBus table. 
*           A simple descriptor is used for commands which control one- or 
*           two-byte variables.
* @param    cmdId       Identifier of the PMBus command. See @ref pmbus_command_list.
* @param    readWrite   Selecting read, write or read-write access to the command. 
*                       One of constants described @ref pmbus_read_write "here".
* @param    typeVarFunc Command binding type selection (callback function or 
*                       variable mapping). One of @ref pmbus_command_exec_type 
*                       "PMBUS_TYPE_xxx" constants.
* @param    pAddr       Pointer to the callback function or mapped variable.
* @param    formats     Defines data formats supported by the command. Combination of 
*                       @ref pmbus_variable_format "PMBUS_FORMAT_xxx" constants.
*                       Set 0 to disable check of format.
******************************************************************************/
#define PMBUS_CMD_SIMPLE(cmdId, readWrite, typeVarFunc, pAddr, formats) \
 PMB_CMD_ENTRY_ITEM(PMB_CMD_CODE_ENTRY(cmdId), \
 					PMB_CMD_FLAGS_ENTRY(cmdId), \
 					readWrite, \
 					PMB_CMD_DATA_CAST(formats), \
 					0, \
 					typeVarFunc, \
 					pAddr)

/*****************************************************************************
*//*!
* @brief    Defines a data block command in a page table
* @details  This macro is used to put a command descriptor into a PMBus table. 
*           A data block command descriptor is used for commands which control 
*           block of data in memory.
* @param    cmdId       Identifier of the PMBus command. See @ref pmbus_command_list.
* @param    readWrite   Selecting read, write or read-write access to the command. 
*                       One of constants described @ref pmbus_read_write "here".
* @param    typeVarFunc Command binding type selection (callback function or 
*                       variable mapping). One of @ref pmbus_command_exec_type 
*                       "PMBUS_TYPE_xxx" constants.  
* @param    pAddr       Pointer to the callback function or mapped variable.
* @param    format      Defines data formats supported by the command. Use
*                       @ref PMBUS_FORMAT_DATA_BLOCK "PMBUS_FORMAT_DATA_BLOCK" constant.
*                       Set 0 to disable check of format.
* @param    size        Size of data block. May be specified as 0 in case the 
*                       size should be dynamically handled by a command 
*                       callback function.
******************************************************************************/
#define PMBUS_CMD_DATA_BLOCK(cmdId, readWrite, typeVarFunc, pAddr, format, size) \
 PMB_CMD_ENTRY_ITEM(PMB_CMD_CODE_ENTRY(cmdId), PMB_CMD_FLAGS_ENTRY(cmdId), readWrite, PMB_CMD_DATA_CAST(PMBUS_FORMAT_DATA_BLOCK), (size) ? ((size) + 1) : 0, typeVarFunc, pAddr)

/*****************************************************************************
*//*!
* @brief     Defines an internally-handled command in a page table
* @details   This macro is used to put a command descriptor into a PMBus table. 
*            An internal command descriptor is used for commands for which an 
*            internal built-in handler should be used.
* @param    cmdId       Identifier of the PMBus command. See @ref pmbus_command_list.
* @param    readWrite   Selecting read, write or read-write access to the command. 
*                       One of constants described @ref pmbus_read_write "here".
******************************************************************************/
#define PMBUS_CMD_INTERNAL(cmdId, readWrite) PMB_IMPL_##cmdId##_##readWrite()

//last member of table has address 0x0 to determine end of table
/*****************************************************************************
*//*!
* @brief    Terminates the PMBus page table
* @details  This macro is used to mark end of the PMBus table which represents one PMBus page.
*
* @internal
* last member of table has address 0x0 to determine end of table
******************************************************************************/
#define PMBUS_PAGE_END() {0x0, NULL}}; \
    if(ppPageStruct) *ppPageStruct = &pmbus_PageStruct; \
    return (PMB_CMD_ENTRY*)&pmbus_PageTable; }
/*! @} End of pmbus_command_entry */

/*****************************************************************************
*//*
* @brief    Defines begin of list all pages
******************************************************************************/
#define PMBUS_PAGE_LIST_BEGIN() \
    const PMB_CMD_ENTRY* PMBus_GetPageTable(PMBUS_INDEX nTableIndex, PMB_PAGE_STRUCT** ppPageStruct) {

/*****************************************************************************
*//*
* @brief    Macro is used to register page to Page list
******************************************************************************/
#define PMBUS_PAGE_TABLE(id) \
    if(!nTableIndex--) { \
        PMB_PAGE_FUNC_PROTO(id); \
        return PMB_PAGE_FUNC(id)(ppPageStruct); \
    } else

/*****************************************************************************
*//*
* @brief    Defines end of list all pages
******************************************************************************/
#define PMBUS_PAGE_LIST_END() \
    { return NULL; } }

//Parameters of PMBus Table Entry 
/*****************************************************************************
* Parameter defines if command supports Write, Read or Read&Write
*
*//*! @addtogroup pmbus_read_write
* @{
******************************************************************************/
#define PMBUS_WRITE                     (PMB_CMD_FLAGS_WRITE_BITS)      ///< Enables command to write data.
#define PMBUS_READ                      (PMB_CMD_FLAGS_READ_BITS)       ///< Enables command to read data.
#define PMBUS_RW                        (PMB_CMD_FLAGS_READ_BITS|PMB_CMD_FLAGS_WRITE_BITS)      ///< Enables command to both read and write data.
/*! @} End of READWRITE */

/*****************************************************************************
* Parameter defines if command is Callback type or command is mapped directly to variable
*
*//*! @addtogroup pmbus_command_exec_type
* @{
******************************************************************************/
#define PMBUS_TYPE_CALLBACK             (PMB_CMD_FLAGS_CALLBACK)        ///< Command is assigned a callback handler.
#define PMBUS_TYPE_VARIABLE             0                               ///< Command is mapped directly to an application variable.
/*! @} End of CMDTYPE */

/*****************************************************************************
* Command Data Formats
*
*//*! @addtogroup pmbus_variable_format
* @{
******************************************************************************/
#define PMBUS_FORMAT_DATA_BLOCK         PMB_CFG_FORMAT_DATA_BLOCK       ///< Command handles block of data.
#define PMBUS_FORMAT_LINEAR_DATA        PMB_CFG_FORMAT_LINEAR_DATA      ///< Linear Data Format.
#define PMBUS_FORMAT_DIRECT_MODE(grp)   ((PMB_CFG_FORMAT_DIRECT_MODE) | ((grp&(PMB_CFG_FORMAT_MASK>>(PMB_CFG_FORMAT_SHIFT)))<<(PMB_CFG_DIR_GRP_SHIFT-PMB_CFG_FORMAT_SHIFT))) ///< Direct Mode Format with a reference to group of calculation coefficients.
#define PMBUS_FORMAT_VID_MODE           PMB_CFG_FORMAT_VID_MODE         ///< VID Mode format.
#define PMBUS_FORMAT_MANUF_SPEC         PMB_CFG_FORMAT_MANUF_SPEC       ///< Manufacturer-specific format.
#define PMBUS_FORMAT_16BIT_SIGNED       PMB_CFG_FORMAT_16BIT_SIGNED     ///< 16 bit signed number format.
#define PMBUS_FORMAT_8BIT_UNSIGNED      PMB_CFG_FORMAT_8BIT_UNSIGNED    ///< 8 bit unsigned number format.
//#define PMBUS_FORMAT_IGNORE             PMB_CFG_FORMAT_IGNORE           ///< Configure PMBus stack not to check format validity when processing a command.
/*! @} End of pmbus_variable_format */

/*****************************************************************************
* The PMBus flags to define behavior of manufacturer specific commands
*
*//*! @addtogroup pmbus_command_flags
* @{
******************************************************************************/
#define PMBUS_CMD_FLAGS_WRITE_NA        PMB_CMD_FLAGS_WRITE_NA          ///< Write command is not supported.
#define PMBUS_CMD_FLAGS_WRITE_BYTE_WORD PMB_CMD_FLAGS_WRITE_BYTE_WORD   ///< Type of Write command is Byte/Word. Use PMBUS_CMD_FLAGS_WORD_SIZE to define Word type.
#define PMBUS_CMD_FLAGS_WRITE_BLOCK     PMB_CMD_FLAGS_WRITE_BLOCK       ///< Type of Write command is Data block.
#define PMBUS_CMD_FLAGS_WRITE_BYTE      PMB_CMD_FLAGS_WRITE_BYTE        ///< Type of Write command is Send Byte.

#define PMBUS_CMD_FLAGS_READ_NA         PMB_CMD_FLAGS_READ_NA           ///< Read command is not supported.
#define PMBUS_CMD_FLAGS_READ_BYTE_WORD  PMB_CMD_FLAGS_READ_BYTE_WORD    ///< Type of Read command is Byte/Word. Use PMBUS_CMD_FLAGS_WORD_SIZE to define Word type.
#define PMBUS_CMD_FLAGS_READ_BLOCK      PMB_CMD_FLAGS_READ_BLOCK        ///< Type of Read command is Data block.
#define PMBUS_CMD_FLAGS_READ_PROCCALL   PMB_CMD_FLAGS_READ_PROCCALL     ///< Type of Read command is Write Block - Read Block Process Call.

#define PMBUS_CMD_FLAGS_WORD_SIZE       PMB_CMD_FLAGS_WORD_SIZE         ///< Defines 2 bytes size of command data of PMBUS_CMD_FLAGS_WRITE_BYTE_WORD or PMBUS_CMD_FLAGS_READ_BYTE_WORD command type.
#define PMBUS_CMD_FLAGS_VOUT_MODE       PMB_CMD_FLAGS_VOUT_MODE         ///< Defines that command uses VOut format.
/*! @} End of pmbus_command_flags */

/*****************************************************************************
* PMBus data formats of VOut Mode
*
*//*! @addtogroup pmbus_vout_mode 
* @{
******************************************************************************/
#define PMBUS_VOUT_MODE_CFG_MASK        PMB_VOUT_MODE_CFG_MASK          ///< Mask of actual VOut data format. The masked value can then be directly compared with other PMBUS_VOUT_MODE_CFG_XXX constants.
#define PMBUS_VOUT_MODE_CFG_LINEAR_DATA PMB_VOUT_MODE_CFG_LINEAR_DATA   ///< Linear data format used
#define PMBUS_VOUT_MODE_CFG_VID         PMB_VOUT_MODE_CFG_VID           ///< VID format used
#define PMBUS_VOUT_MODE_CFG_DIRECT_MODE PMB_VOUT_MODE_CFG_DIRECT_MODE   ///< Direct mode format used
#define PMBUS_VOUT_MODE_EXP_MASK        PMB_VOUT_MODE_EXP_MASK          ///< Mask of parameter in VOut mode register
/*! @} End of pmbus_vout_mode */

/*****************************************************************************
* List of bit masks to analyze Fault Response registers.
*
*//*! @addtogroup pmbus_fault_response_bits Fault Response Bits
* @{
*******************************************************************************/
#define PMBUS_FAULT_RESP_MASK          0xc0             ///< Mask of Fault Response bits
#define PMBUS_FAULT_RESP_CONTINUE      0x00             ///< The PMBus device continues operation without interruption.
#define PMBUS_FAULT_RESP_CONT_RETRY    0x40             ///< The PMBus device continues operation for the delay time. If the fault condition is still present at the end of the delay time, the unit responds.
#define PMBUS_FAULT_RESP_STOP_RETRY    0x80             ///< The device shuts down (disables the output) and responds according to the retry setting in bits ::PMBUS_FAULT_RETRY_MASK.
#define PMBUS_FAULT_RESP_STOP          0xc0             ///< The devices output is disabled while the fault is present. Operation resumes and the output is enabled when the fault condition no longer exists.
#define PMBUS_FAULT_DELAY_MASK         0x07             ///< Mask of Delay Count bits.
#define PMBUS_FAULT_DELAY(faultResp)   ((faultResp)&PMBUS_FAULT_DELAY_MASK) ///< Decode the Fault Delay value from the Fault Response value.
#define PMBUS_FAULT_RETRY_MASK         0x38             ///< Mask of Retry Setting bits
#define PMBUS_FAULT_RETRY_SHIFT        0x03             ///< The PMBus Fault Response register must be shifted by this macro to decode the Fault Retry configuration.
#define PMBUS_FAULT_RETRY(faultResp)   (((faultResp)>>PMBUS_FAULT_RETRY_SHIFT)&PMBUS_FAULT_RETRY_MASK) ///< Decode the Fault Retry value from the Fault Response value.
/*! @} End of pmbus_fault_response_bits */

/*****************************************************************************
* List of masks to analyze Fan Config command
*
*//*! @addtogroup pmbus_fan_config_bits Bits of Fan Config command
* @{
*******************************************************************************/
#define PMBUS_FAN_CONFIG_1_SETUP_MASK       0x80                            ///< Mask of bit to determine, if FAN 1 is installed. The masked value can be compared with other FAN_CONFIG_1_SETUP_XXX constants.
#define PMBUS_FAN_CONFIG_1_SETUP_ENABLE     PMBUS_FAN_CONFIG_1_SETUP_MASK   ///< A FAN is installed in position 1.
#define PMBUS_FAN_CONFIG_1_SETUP_DISABLE    0                               ///< A FAN is not installed in position 1.
#define PMBUS_FAN_CONFIG_1_SPEED_UNIT_MASK  0x40                            ///< Mask of bit to define unit of FAN 1 speed.The masked value can be compared with other FAN_CONFIG_1_SPEED_UNIT_XXX constants.
#define PMBUS_FAN_CONFIG_1_SPEED_UNIT_RPM   PMBUS_FAN_CONFIG_1_SPEED_UNIT_MASK ///< FAN 1 is commanded in RPM.
#define PMBUS_FAN_CONFIG_1_SPEED_UNIT_DUTY  0                               ///< FAN 1 is commanded in Duty Cycle.
#define PMBUS_FAN_CONFIG_1_TACHO_CONF_MASK  0x30                            ///< Mask of bit to define Tachometer Pulses Per Revolution of FAN 1.

#define PMBUS_FAN_CONFIG_2_SETUP_MASK       0x80                            ///< Mask of bit to determine, if FAN 2 is installed. The masked value can be compared with other FAN_CONFIG_2_SETUP_XXX constants.
#define PMBUS_FAN_CONFIG_2_SETUP_ENABLE     PMBUS_FAN_CONFIG_2_SETUP_MASK   ///< A FAN is installed in position 2.
#define PMBUS_FAN_CONFIG_2_SETUP_DISABLE    0                               ///< A FAN is not installed in position 2.
#define PMBUS_FAN_CONFIG_2_SPEED_UNIT_MASK  0x40                            ///< Mask of bit to define unit of FAN 2 speed.The masked value can be compared with other FAN_CONFIG_2_SPEED_UNIT_XXX constants.
#define PMBUS_FAN_CONFIG_2_SPEED_UNIT_RPM   PMBUS_FAN_CONFIG_2_SPEED_UNIT_MASK ///< FAN 2 is commanded in RPM.
#define PMBUS_FAN_CONFIG_2_SPEED_UNIT_DUTY  0                               ///< FAN 2 is commanded in Duty Cycle.
#define PMBUS_FAN_CONFIG_2_TACHO_CONF_MASK  0x30                            ///< Mask of bit to define Tachometer Pulses Per Revolution of FAN 2.

#define PMBUS_FAN_CONFIG_3_SETUP_MASK       0x80                            ///< Mask of bit to determine, if FAN 3 is installed.The masked value can be compared with other FAN_CONFIG_3_SETUP_XXX constants.
#define PMBUS_FAN_CONFIG_3_SETUP_ENABLE     PMBUS_FAN_CONFIG_3_SETUP_MASK   ///< A FAN is installed in position 3.
#define PMBUS_FAN_CONFIG_3_SETUP_DISABLE    0                               ///< A FAN is not installed in position 3.
#define PMBUS_FAN_CONFIG_3_SPEED_UNIT_MASK  0x40                            ///< Mask of bit to define unit of FAN 3 speed.The masked value can be compared with other FAN_CONFIG_3_SPEED_UNIT_XXX constants.
#define PMBUS_FAN_CONFIG_3_SPEED_UNIT_RPM   PMBUS_FAN_CONFIG_3_SPEED_UNIT_MASK ///< FAN 3 is commanded in RPM.
#define PMBUS_FAN_CONFIG_3_SPEED_UNIT_DUTY  0                               ///< FAN 3 is commanded in Duty Cycle.
#define PMBUS_FAN_CONFIG_3_TACHO_CONF_MASK  0x30                            ///< Mask of bit to define Tachometer Pulses Per Revolution of FAN 3.

#define PMBUS_FAN_CONFIG_4_SETUP_MASK       0x80                            ///< Mask of bit to determine, if FAN 4 is installed.The masked value can be compared with other FAN_CONFIG_4_SETUP_XXX constants.
#define PMBUS_FAN_CONFIG_4_SETUP_ENABLE     PMBUS_FAN_CONFIG_4_SETUP_MASK   ///< A FAN is installed in position 4.
#define PMBUS_FAN_CONFIG_4_SETUP_DISABLE    0                               ///< A FAN is not installed in position 4.
#define PMBUS_FAN_CONFIG_4_SPEED_UNIT_MASK  0x40                            ///< Mask of bit to define unit of FAN 4 speed.The masked value can be compared with other FAN_CONFIG_4_SPEED_UNIT_XXX constants.
#define PMBUS_FAN_CONFIG_4_SPEED_UNIT_RPM   PMBUS_FAN_CONFIG_4_SPEED_UNIT_MASK ///< FAN 4 is commanded in RPM.
#define PMBUS_FAN_CONFIG_4_SPEED_UNIT_DUTY  0                               ///< FAN 4 is commanded in Duty Cycle.
#define PMBUS_FAN_CONFIG_4_TACHO_CONF_MASK  0x30                            ///< Mask of bit to define Tachometer Pulses Per Revolution of FAN 4.
/*! @} End of pmbus_fan_config_bits */

/*****************************************************************************
* Public Functions
*
*//*! @addtogroup pmbus_power_supply
* @{*/
/*****************************************************************************
*//*!
* @brief        Initializes the PMBus stack. Must be called before 
*               any other stack API functions
* @details      This function checks all the command tables of PMBus stack.
*
* @return       @ref pmbus_error
*                   - ::PMBUS_OK                           API call finished successfully.
*                   - ::PMBUS_ERROR_CMD_INVALID_FORMAT     API call aborted due to invalid format in command table.
* @internal
* @version      15-Jan-2012
******************************************************************************/
PMBUS_ERROR_CODE PMBus_Init(void);

/*****************************************************************************
*//*!
* @brief        Obtains Fault Response configuration.
* @details      This function reads Fault Response register defined 
*               by faultId parameter from internal page structure.
* @param[in]    pageIndex   Defines page index from which to get the 
*                           Fault Response register.
* @param[in]    faultId     Fault Response ID code, one of 
*                           @ref pmbus_fault_response_ids "PMBUS_FAULT_ID_XXX" 
*                           constants.
*
* @return       Fault Response configuration. See @ref pmbus_fault_response_bits 
*               "list of masks" to filter bits relevant for the caller.
* @internal
* @version      15-Jan-2012
******************************************************************************/
PMBUS_PAGE_MEMBER PMBus_GetFaultResponseType(PMBUS_INDEX pageIndex, PMBUS_FAULT_ID faultId);
/*****************************************************************************
*//*!
* @brief        Sets errors state in the PMBus status registers.
* @details      This function is used to report an error state 
*               in the power supply or in the communication.
* @param[in]    pageIndex   Defines page index in which the error 
*                           flag is to be set.
* @param[in]    statusBitId Status bit ID which defines status 
*                           register and flag in register, one of 
*                           @ref pmbus_status_bit_ids "PMBUS_STATUS_XXX" constants.
*
* @return       @ref pmbus_error 
*                 - ::PMBUS_OK                      Command was performed successfully.
*                 - ::PMBUS_ERROR_CMD_INVALID_PARAM Invalid parameter.
*                 - ::PMBUS_ERROR_PAGE_NOT_FOUND    Invalid page selected.
*                 - any other error code returned by the SMBus_Alert() function.
* @internal
* @version      15-Jan-2012
******************************************************************************/
PMBUS_ERROR_CODE PMBus_SetErrorState(PMBUS_INDEX pageIndex, PMBUS_STATUS_BIT_ID statBitCode);

PMBUS_ERROR_CODE PMBus_ResetErrorState(PMBUS_INDEX pageIndex, PMBUS_STATUS_BIT_ID statBitCode);
/*****************************************************************************
*//*!
* @brief        Obtains a pointer to internal PMBus register.
* @details      This function is used to get a pointer to internal PMBus 
*               register. This may be useful when storing or restoring 
*               the configuration.
* @param[in]    pageIndex   Defines page index, of the register.
* @param[in]    memIndex    ID of internal register, One of 
*                           @ref pmbus_internal_var_indexes "PMBUS_INDEX_XXX" 
*                           constants.
* @param[out]   ppVar       Returns an address of the register. 
*                           NULL if register is not enabled.
*
* @return       @ref pmbus_error 
*                 - ::PMBUS_OK                      Command was performed successfully.
*                 - ::PMBUS_ERROR_PAGE_NOT_FOUND    Required page was not found.
* @internal
* @version      15-Jan-2012
******************************************************************************/
PMBUS_ERROR_CODE PMBus_GetPageIntVarByIndex(PMBUS_INDEX pageIndex, PMBUS_PAGE_MEMBER_INDEX memIndex, PMBUS_PAGE_MEMBER** ppVar);
/*! @} End of pmbus_power_supply */


/*****************************************************************************
* PMBus functions used in PMBus callbacks
*
*//*! @addtogroup pmbus_in_callback 
* @{*/
/*****************************************************************************
*//*!
* @brief        Checking if the command is write type.
* @details      This function is used to check if received command is  configured 
*               to write. This function can be called only in the 
*               @ref PMBus_CallBack() "command callback" function.
* @param        context     The context of command provided by the 
*                           @ref PMBus_CallBack() "command callback" function.
*
* @return       @ref pmbus_bool
*                 - ::PMBUS_TRUE    Command buffer contains data to be processed.
*                 - ::PMBUS_FALSE   Command requires to buld a response in the buffer.
* @internal
* @version      15-Jan-2012
******************************************************************************/
PMBUS_INLINE PMBUS_BOOL PMBus_IsWrite(PMBUS_CONTEXT context)
{
	return ((((PMB_PACKET_CONTEXT*)(context))->packetFlags&PMB_CALLBACK_TYPE_MASK) == PMB_CALLBACK_TYPE_WRITE);
}

/*****************************************************************************
*//*!
* @brief        Checking if the command is read type.
* @details      This function is used to check if received command is configured 
*               to read. This function can be called only in the 
*               @ref PMBus_CallBack() "command callback" function.
* @param        context     The context of command provided by the 
*                           @ref PMBus_CallBack() "command callback" function.
*
* @return       @ref pmbus_bool
*                 - ::PMBUS_TRUE    Command buffer contains data to be processed.
*                 - ::PMBUS_FALSE   Command requires to buld a response in the buffer.
* @internal
* @version      15-Jan-2012
******************************************************************************/
PMBUS_INLINE PMBUS_BOOL PMBus_IsRead(PMBUS_CONTEXT context)
{
	return ((((PMB_PACKET_CONTEXT*)(context))->packetFlags&PMB_CALLBACK_TYPE_MASK) == PMB_CALLBACK_TYPE_READ);
}

/*****************************************************************************
*//*!
* @brief        Checking if the command is VOut type.
* @details      This function is used to check if received command uses 
*               the VOut Mode which defines the current data format. This function 
*               can be called only in the 
*               @ref PMBus_CallBack() "command callback" function.
* @param        context     The context of command provided by the 
*                           @ref PMBus_CallBack() "command callback" function.
*
* @return       @ref pmbus_bool
*                 - ::PMBUS_TRUE    Command uses the VOut Mode to determine data format.
*                 - ::PMBUS_FALSE   Command format is defined statically.
* @internal
* @version      30-Apr-2012
******************************************************************************/
PMBUS_INLINE PMBUS_BOOL PMBus_IsVoutType(PMBUS_CONTEXT context)
{
	return (PMBUS_CMD_CODE)(((((PMB_PACKET_CONTEXT*)(PMBUS_CONTEXT)(context))->pPageCmd->cmd_data)&(PMB_CMD_FLAGS_VOUT_MODE<<PMB_CMD_FLAGS_SHIFT)) == (PMB_CMD_FLAGS_VOUT_MODE<<PMB_CMD_FLAGS_SHIFT));
}

/*****************************************************************************
*//*!
* @brief        Gets the command code.
* @details      This function is used to get code of command to be performed. 
*               This function can be called only in the 
*               @ref PMBus_CallBack() "command callback" function.
* @param        context     The context of command provided by the 
*                           @ref PMBus_CallBack() "command callback" function.
*
* @return       ::PMBUS_CMD_CODE
*                 - Code of the PMBus command, value 0 to 255.
* @internal
* @version      30-Apr-2012
******************************************************************************/
PMBUS_INLINE PMBUS_CMD_CODE PMBus_GetCmdCode(PMBUS_CONTEXT context)
{
	return (PMBUS_CMD_CODE)(((((PMB_PACKET_CONTEXT*)(PMBUS_CONTEXT)(context))->pPageCmd->cmd_data)&PMB_CMD_CODE_MASK)>>PMB_CMD_CODE_SHIFT);
}

/*****************************************************************************
*//*!
* @brief        Gets the command format.
* @details      This function is used to get data format of the received command. 
*               This function can be called only in the command 
*               @ref PMBus_CallBack() "callback function".
* @param        context     The context of command provided by the 
*                           @ref PMBus_CallBack() "command callback" function.
*
* @return       Data format of the command. Use @ref PMBUS_FORMAT_DATA_BLOCK 
*               "PMBUS_FORMAT_XXX" constants to decode the data format.
* @internal
* @version      30-Apr-2012
******************************************************************************/
#if PMBCFG_USE_FORMATS
PMBUS_INLINE PMBUS_FLAGS8 PMBus_GetCmdFormat(PMBUS_CONTEXT context)
{
	return (PMBUS_FLAGS8)(((((PMB_PACKET_CONTEXT*)(PMBUS_CONTEXT)(context))->pPageCmd->cmd_data)&PMB_CFG_FORMAT_MASK)>>PMB_CFG_FORMAT_SHIFT);
}
#endif
/*****************************************************************************
*//*!
* @brief        Gets a pointer to internal PMBus register.
* @details      This function is used to a get a pointer to internal PMBus 
*               register to store or restore selected configuration parameter.
* @param[in]    context     The context of command provided by the 
*                           @ref PMBus_CallBack() "command callback" function.
* @param[in]    cmdCode     Command code of internal register.
* @param[out]   ppVar       Returns an address of the register. 
*                           NULL if register is not enabled.
*
* @return       @ref pmbus_error 
*                 - ::PMBUS_OK                  Command was performed successfully.
*                 - ::PMBUS_ERROR_CMD_NOT_FOUND Command was not found in the 
*                     @ref pmbus_define_table "Command Table".
* @internal
* @version      30-Apr-2012
******************************************************************************/
PMBUS_ERROR_CODE PMBus_GetIntVar(PMBUS_CONTEXT context, PMBUS_CMD_CODE cmdCode, PMBUS_PAGE_MEMBER** ppVar);

/*****************************************************************************
*//*!
* @brief        Gets a pointer to internal PMBus register.
* @details      This function is used to get a pointer to internal PMBus 
*               register to store or restore configuration parameter.
* @param[in]    context     The context of command provided by the 
*                           @ref PMBus_CallBack() "command callback" function.
* @param[in]    memIndex    Index of internal register. One of 
*                           @ref pmbus_internal_var_indexes "PMBUS_INDEX_XXX" constants.
* @param[out]   ppVar       Returns an address of the register. 
*                           NULL. if register is not enabled.
*
* @return       @ref pmbus_error 
*                 - ::PMBUS_OK                      Command was performed successfully
*                 - ::PMBUS_ERROR_CMD_INVALID_PARAM Invalid memIndex parameter
* @internal
* @version      30-Apr-2012
******************************************************************************/
PMBUS_ERROR_CODE PMBus_GetIntVarByIndex(PMBUS_CONTEXT context, PMBUS_PAGE_MEMBER_INDEX memIndex, PMBUS_PAGE_MEMBER** ppVar);
/*! @} End of pmbus_in_callback */

/*****************************************************************************
*//*! @addtogroup pmbus_callback PMBus callbacks function
* @{*/
/*****************************************************************************
*//*!
* @brief            This is a prototype of callback function to handle the PMBus commands.
* @details          The command callback function is registered by ::PMBUS_CMD_SIMPLE() 
*                   or ::PMBUS_CMD_DATA_BLOCK() macros and is called when 
*                   PMBus command handles the command for reading or writing. 
*                   The name of the function is freely determined by an application code.
*                   The PMBus stack expects that pBuffer and pSize pointers 
*                   contain valid response data when read is handled.
* @param[in]        context Internal command features
* @param[in]        pBuffer Buffer to received data or buffer to store a response
* @param[in,out]    pSize   Size of received data or size of response
*
* @return           @ref pmbus_error 
*                     - ::PMBUS_OK                              Command was performed successfully
*                     - ::PMBUS_ERROR_CMD_INVALID_SIZE          Command has invalid size of received packet
*                     - ::PMBUS_ERROR_CMD_INVALID_PARAM         Invalid parameter
*                     - ::PMBUS_ERROR_CMD_EXECUTION             Error during command execution
*                     - ::PMBUS_ERROR_CMD_READ_NOT_SUPPORTED    Command does not supports read
*                     - ::PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED   Command does not supports write 

* @internal
* @version          15-Jan-2012
******************************************************************************/
PMBUS_ERROR_CODE PMBus_CallBack(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize);

/*****************************************************************************
*//*!
* @brief            Callback function to get state of power supply
* @details          This function should return information if power supply 
*                   is turned on or off.
* @param[in]        index               Defines page index of the command table.
* @return           @ref pmbus_bool
*                     - ::PMBUS_TRUE    Application signals that power supply is on
*                     - ::PMBUS_FALSE   Application signals that power supply is off
* @internal
* @version          15-Jan-2012
******************************************************************************/
PMBUS_BOOL PMBus_IsPowerSupplyOn(PMBUS_INDEX index);

/*****************************************************************************
*//*!
* @brief            Callback function to check Power Good signal of the power supply.
* @details          This function should return value of the Power Good signal 
*                   in the power supply.
* @param[in]        index   Defines page index of the command table.
*
* @return           @ref pmbus_bool
*                     - ::PMBUS_TRUE    Application signals that the Power Good 
*                                       signal is on.
*                     - ::PMBUS_FALSE   Application signals that the Power Good 
*                                       signal is off.
* @internal
* @version          30-Apr-2012
******************************************************************************/
PMBUS_BOOL PMBus_IsPowerGood(PMBUS_INDEX index);
/*! @} End of pmbus_callback */

/*****************************************************************************/
/*! @addtogroup pmbus_format PMBus format function
* @{*/
/*****************************************************************************
*//*!
* @brief        Gets the VOut mode register.
* @details      This function returns a value of VOut mode register.
* @param[in]    context The context of command provided by the 
*               @ref PMBus_CallBack() "command callback" function.
*
* @return       Value of the VOut mode register. Use @ref pmbus_vout_mode "PMBUS_VOUT_MODE_XXX" 
*               constants to decode VOut mode register.
* @internal
* @version      30-Apr-2012
******************************************************************************/
#if PMBCFG_CONST_VOUT_MODE
#define PMBus_GetVoutMode(context) pmb_const_vout_mode
#else
#define PMBus_GetVoutMode(context) ((PMBUS_PAGE_MEMBER)(((PMB_PACKET_CONTEXT*)(context))->pPageStruct->vout_mode))
#endif
/*****************************************************************************
*//*!
* @brief        Gets the command data format.
* @details      This function returns value of the command data format.
* @param[in]    context The context of command provided by the 
*               @ref PMBus_CallBack() "command callback" function.
*
* @return       Value of the command data format. See 
*               @ref pmbus_variable_format "Format Macros" for more information 
*               on how to decode the returned value.
* @internal
* @version      30-Apr-2012
******************************************************************************/
#define PMBus_GetCmdFormatFlags(context) ((PMBUS_FLAGS8)((((context)->cmd_data)&PMB_CFG_FORMAT_MASK)>>PMB_CFG_FORMAT_SHIFT))

/*****************************************************************************
*//*!
* @brief        Gets the index of the Direct Mode coefficients 
*               of the command.
* @details      This function returns the index of the Direct Mode coefficients 
*               of the command. Use the returned value with 
*               the PMBus_GetCoefficients() function to access the coefficient values.
* @param[in]    context The context of command provided by 
*               the @ref PMBus_CallBack() "command callback" function.
*
* @return       Index of Direct Mode coefficients
* @internal
* @version      30-Apr-2012
******************************************************************************/
#define PMBus_GetCoefGrpIndex(context) ((PMBUS_INDEX)((((PMB_CMD_ENTRY*)(context))->cmd_data>>PMB_CFG_DIR_GRP_SHIFT)&(PMB_CFG_DIR_GRP_MASK>>PMB_CFG_DIR_GRP_SHIFT)))

/*****************************************************************************
*//*!
* @brief        Gets the Direct Format coefficients.
* @details      This function returns pointer to the Direct Format coefficients structure.
* @param[in]    grp_index       WIndex of coefficients group
* @return       Direct Format coefficients. See PMBUS_COEF_GRP_ENTRY structure.
* @internal
* @version      30-Apr-2012
******************************************************************************/
#define PMBus_GetCoefficients(grp_index) ((PMBUS_COEF_GRP_ENTRY*)&pmb_coef_grp_table[grp_index&(PMB_CFG_DIR_GRP_MASK>>PMB_CFG_DIR_GRP_SHIFT)])
/*! @} End of pmbus_format */

extern const PMBUS_COEF_GRP_ENTRY pmb_coef_grp_table[];

#endif /* __PMBUS_H */
