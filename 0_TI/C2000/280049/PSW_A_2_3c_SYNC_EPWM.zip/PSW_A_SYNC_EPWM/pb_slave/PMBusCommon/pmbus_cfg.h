/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   pmbus_cfg.h
*
* @brief  PMBus configuration header file
*
* @version 2.0
* 
* @date 2021/06/19
* 
*******************************************************************************/

#ifndef __PMBUS_CFG_H
#define __PMBUS_CFG_H

/******************************************************************************
* PMBus configuration
******************************************************************************/
#define PMBCFG_USE_SMBUS_DRIVER 1
#define PMBCFG_USE_FORMATS                      1
#define PMBCFG_PROCCALL_CHECK                   1
#define PMBCFG_USE_INTERNAL_CHECKS              1
#define PMBCFG_USE_INTERNAL_CALLBACK_CHECKS     1
#define PMBCFG_CONST_VOUT_MODE                  1
#define PMBCFG_VOUT_MODE_DEF_VAL                0x20
#define PMBCFG_USE_PMBUS_REVISION               1
#define PMBCFG_USE_SMBALERT_RESPONSE            1
#define PMBCFG_SEND_SMBUSALERT_ON_CMD_ERROR     1
#define PMBCFG_USE_CMD_CHECK_ON_INIT            1

#define PMBCFG_USE_CAPABILITY                   1
#define PMBCFG_CAPABILITY_PEC_SUPPORTED         1
#define PMBCFG_CAPABILITY_MAX_SPEED             0
#define PMBCFG_CAPABILITY_SMBUSALERT_SUPPORTED  0

#define PMBCFG_USE_CALLBACK_IS_POWER_SUPPLY_ON  1
#define PMBCFG_USE_CALLBACK_IS_POWER_GOOD       1
#define PMBCFG_BUFFER_SIZE                      (SMBCFG_BUFFER_SIZE)
/******************************************************************************
* Enable / Disable Internal commands
******************************************************************************/
#define PMBCFG_USE_PAGE                         1
#define PMBCFG_USE_VOUT_MODE                    0
#define PMBCFG_USE_QUERY                        1
#define PMBCFG_USE_SMBALERT_MASK                1

#define PMBCFG_USE_COEFFICIENTS                 1
#define PMBCFG_USE_PAGE_PLUS_WRITE              1
#define PMBCFG_USE_PAGE_PLUS_READ               1
#define PMBCFG_USE_WRITE_PROTECT                1
#define PMBCFG_USE_CLEAR_FAULTS                 1

/******************************************************************************
* Enable / Disable Fault Response registers and commands
******************************************************************************/
#define PMBCFG_USE_VOUT_OV_FAULT_RESPONSE       0
#define PMBCFG_USE_VOUT_UV_FAULT_RESPONSE       0
#define PMBCFG_USE_IOUT_OC_FAULT_RESPONSE       0
#define PMBCFG_USE_IOUT_OC_LV_FAULT_RESPONSE    0
#define PMBCFG_USE_IOUT_UC_FAULT_RESPONSE       0
#define PMBCFG_USE_OT_FAULT_RESPONSE            0
#define PMBCFG_USE_UT_FAULT_RESPONSE            0
#define PMBCFG_USE_VIN_OV_FAULT_RESPONSE        0
#define PMBCFG_USE_VIN_UV_FAULT_RESPONSE        0
#define PMBCFG_USE_IIN_OC_FAULT_RESPONSE        0
#define PMBCFG_USE_TON_MAX_FAULT_RESPONSE       0
#define PMBCFG_USE_POUT_OP_FAULT_RESPONSE       0

/******************************************************************************
* Enable / Disable Status registers and commands
******************************************************************************/
#define PMBCFG_USE_STATUS_BYTE                 1
#define PMBCFG_USE_STATUS_WORD                 1

#define PMBCFG_USE_STATUS_VOUT                 1
#define PMBCFG_USE_STATUS_IOUT                 1
#define PMBCFG_USE_STATUS_INPUT                1
#define PMBCFG_USE_STATUS_TEMPERATURE          1
#define PMBCFG_USE_STATUS_CML                  0
#define PMBCFG_USE_STATUS_OTHER                0
#define PMBCFG_USE_STATUS_MFR_SPECIFIC         0
#define PMBCFG_USE_STATUS_FANS_1_2             1
#define PMBCFG_USE_STATUS_FANS_3_4             0


/******************************************************************************
* Define coefficients m, b and R
******************************************************************************/
//converts 0-32768U to 0-512V
#define PMBCFG_COEF_GRP_0_CONST_M       0xFA00U
#define PMBCFG_COEF_GRP_0_CONST_B       0x0000U
#define PMBCFG_COEF_GRP_0_CONST_R       0xFDU

//converts 0-32768U to 0-512mA
#define PMBCFG_COEF_GRP_1_CONST_M       0xFA00U
#define PMBCFG_COEF_GRP_1_CONST_B       0x0000U
#define PMBCFG_COEF_GRP_1_CONST_R       0xFEU

//converts 0-65535U to 0-4096RPM
#define PMBCFG_COEF_GRP_2_CONST_M       0x3E80U
#define PMBCFG_COEF_GRP_2_CONST_B       0x0000U
#define PMBCFG_COEF_GRP_2_CONST_R       0xFDU


/******************************************************************************
* Define MFR spec. commands
******************************************************************************/
#define USE_USER_DEFINE_INTERNAL_STATUS_REGS     1

#endif /* __PMBUS_CFG_H */
