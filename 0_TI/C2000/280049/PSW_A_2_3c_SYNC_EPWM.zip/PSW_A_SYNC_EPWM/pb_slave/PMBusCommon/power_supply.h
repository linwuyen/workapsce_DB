/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   power_supply.h
*
* @brief  Example of power supply with the PMBus interface
*
* @version 1.0.2.0
* 
* @date Jun-1-2012
* 
*******************************************************************************/

#ifndef __POWER_SUPPLY_H
#define __POWER_SUPPLY_H

#include "PE_Types.h"
#include "pmbus.h"
#define PWR_STIM_OC_FAULT 0x01
#define PWR_STIM_OC_WARN  0x02


//Power Supply variables
typedef struct
{
	UWord16 ioutOcWarnLimit;
	UWord16 voutCommand;
	UWord8  fanCfg12;
	UWord16 fan1;
	UWord16 fan2;
	UWord8 black_box_data[160];
	UWord8 black_box_real_time[4];
	UWord8 black_box_config;
	UWord8 black_box_clear;
	UWord8 bootloader_key[3];
	UWord8 bootloader_status;
	UWord8 bootloader_data_write[32];
	UWord8 bootloader_product_key[16];
	UWord8 adc_data[16];
	
	LDATA read_pout;
	LDATA read_pin;
	UWord8 mfr_remote_control;	
	UWord8 mfr_BC_delay;	
	UWord16 control_fan_duty;
 } PWR_VARIABLES;
 
extern PWR_VARIABLES pwr;


// Prototypes of Power supply functions
void PWR_Init(void);
void PWR_Poll(void);

extern void CommBus_Poll(void);

#endif
