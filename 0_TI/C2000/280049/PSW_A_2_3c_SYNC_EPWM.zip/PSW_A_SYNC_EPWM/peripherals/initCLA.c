/*
 * initCLA.c
 *
 *  Created on: 2022�~3��29��
 *      Author: cody_chen
 */
#include "initCLA.h"

#include "HwConfig.h"

#pragma SET_DATA_SECTION("cla_shared")

float32_t f32V2F[17] = {
            -1.0,
            0.0, 0.06666, 0.13333, 0.19999, 0.26666, 0.33333, 0.39999, 0.46666,
            0.53333, 0.59999, 0.66666, 0.73333, 0.79999, 0.86666, 0.93333,  1.0
        };

volatile ST_CLA sCLA;
#pragma SET_DATA_SECTION()   // Reset section to default

#define DEFAULT_FIR(avg, m)      {m.f32K1 = avg, m.f32Out = 0.00000f;}

void initClaCpu(HAL_DRV s)
{
    sCLA.fgStatus = _CLA_NO_ACTION;

    DEFAULT_FIR(0.00001f, sCLA.sIL);
    DEFAULT_FIR(0.00001f, sCLA.sIout);
    DEFAULT_FIR(0.00001f, sCLA.sVout);
    DEFAULT_FIR(0.00001f, sCLA.sOcp);
    DEFAULT_FIR(0.00001f, sCLA.sOvp);
    DEFAULT_FIR(0.00001f, sCLA.sIfront);
    DEFAULT_FIR(0.00001f, sCLA.sVin);
    DEFAULT_FIR(0.00001f, sCLA.sVka);

    initLookupTable_CLA(4, f32V2F, (sizeof(f32V2F)/sizeof(float32_t)), (CLA_LUKTB *)&sCLA.sV2F);


    sCLA.sPWM.u32PwmBase = PWM_PEAK_CURR_BASE;
    sCLA.sPWM.f32Duty = DUTY_PEAK_CURR;
    sCLA.sPWM.u16Period = CNT_PEAK_CURR_PWM;
    sCLA.sPWM.f32KHz = (float32_t)PEAK_CURR_PWM_KHZ;
    sCLA.sPWM.u32SysCntKHz = (uint32_t)(DEVICE_SYSCLK_FREQ*0.001f);


    sCLA.sDACA.f32Input = 0.0f;
    sCLA.sILcmd.f32Input = 0.0f;

    //End of initClaCpu
    FG_SETCLA(_CLA_INIT_CLACPU);
}

//
// CLA Initialization
//
// Description: This function will
// - copy over code and const from flash to CLA program and data ram
//   respectively
// - Initialize the task vectors (MVECTx)
// - setup each task's trigger
// - enable each individual task
// - map program and data spaces to the CLA
// - run any one-time initialization task
// Please note that the CLA can only run code and access data that is in RAM.
// the user must assign constants (tables) to FLASH, and copy them over to
// RAM at run-time. They must be copied to a RAM that lies in the address space
// of the CLA, and prior to giving the CLA control over that space
//
void initCLA(void)
{
    //
    // Copy the program and constants from FLASH to RAM before configuring
    // the CLA
    //
#if defined(_FLASH)
    memcpy((uint32_t *)&Cla1ProgRunStart, (uint32_t *)&Cla1ProgLoadStart,
           (uint32_t)&Cla1ProgLoadSize);
    memcpy((uint32_t *)&Cla1ConstRunStart, (uint32_t *)&Cla1ConstLoadStart,
        (uint32_t)&Cla1ConstLoadSize );
#endif //defined(_FLASH)

    //
    // CLA Program will reside in RAMLS0/1/2/3 and data in RAMLS4/5/6/7
    //
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS0, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS1, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS2, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS3, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS4, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS5, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS6, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setLSRAMMasterSel(MEMCFG_SECT_LS7, MEMCFG_LSRAMMASTER_CPU_CLA1);
    MemCfg_setCLAMemType(MEMCFG_SECT_LS0, MEMCFG_CLA_MEM_PROGRAM);
    MemCfg_setCLAMemType(MEMCFG_SECT_LS1, MEMCFG_CLA_MEM_PROGRAM);
    MemCfg_setCLAMemType(MEMCFG_SECT_LS2, MEMCFG_CLA_MEM_PROGRAM);
    MemCfg_setCLAMemType(MEMCFG_SECT_LS3, MEMCFG_CLA_MEM_PROGRAM);
#if defined(_FLASH)
    //
    // In Flash config, constants are loaded in Flash and then copied to LS4/5/6/7.
    // CLA reads the constants from LS4/5/6/7.
    //
    MemCfg_setCLAMemType(MEMCFG_SECT_LS4, MEMCFG_CLA_MEM_DATA);
    MemCfg_setCLAMemType(MEMCFG_SECT_LS5, MEMCFG_CLA_MEM_DATA);
    MemCfg_setCLAMemType(MEMCFG_SECT_LS6, MEMCFG_CLA_MEM_DATA);
    MemCfg_setCLAMemType(MEMCFG_SECT_LS7, MEMCFG_CLA_MEM_DATA);

#endif //defined(_FLASH)

//
// Suppressing #770-D conversion from pointer to smaller integer
// The CLA address range is 16 bits so the addresses passed to the MVECT
// registers will be in the lower 64KW address space. Turn the warning
// back on after the MVECTs are assigned addresses
//
#pragma diag_suppress=770

    //
    // Assign the task vectors and set the triggers for task 1
    //
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_1, (uint16_t)&Cla1Task1);
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_2, (uint16_t)&Cla1Task2);
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_3, (uint16_t)&Cla1Task3);
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_4, (uint16_t)&Cla1Task4);
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_5, (uint16_t)&Cla1Task5);
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_6, (uint16_t)&Cla1Task6);
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_7, (uint16_t)&Cla1Task7);
    CLA_mapTaskVector(CLA1_BASE, CLA_MVECT_8, (uint16_t)&Cla1Task8);

    CLA_setTriggerSource(CLA_TASK_1, CLA_TRIGGER_ADCA1);

#pragma diag_warning=770

    //
    // Enable Task 1
    //
    CLA_enableTasks(CLA1_BASE, CLA_TASKFLAG_1);

}

