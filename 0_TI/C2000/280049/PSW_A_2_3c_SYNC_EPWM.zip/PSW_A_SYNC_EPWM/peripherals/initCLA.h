/*
 * initCLA.h
 *
 *  Created on: 2022�~3��29��
 *      Author: cody_chen
 */

#ifndef PERIPHERALS_INITCLA_H_
#define PERIPHERALS_INITCLA_H_

#include "common.h"

extern uint32_t Cla1ProgRunStart, Cla1ProgLoadStart, Cla1ProgLoadSize;
extern uint32_t Cla1ConstRunStart, Cla1ConstLoadStart, Cla1ConstLoadSize;


extern void initClaCpu(HAL_DRV s);
extern void initCLA(void);


#endif /* PERIPHERALS_INITCLA_H_ */
