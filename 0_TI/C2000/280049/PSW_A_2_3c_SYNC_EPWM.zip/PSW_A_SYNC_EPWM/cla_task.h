/*
 * cla_task.h
 *
 *  Created on: 2022�~3��29��
 *      Author: cody_chen
 */

#ifndef CLA_TASK_H_
#define CLA_TASK_H_

#include "cmath.h"
#include "cla_pwm.h"


#define FG_SETCLA(x)   sCLA.fgStatus |= (x);
#define FG_RSTCLA(x)   sCLA.fgStatus &= ~(x);

typedef enum {
    _CLA_INIT_LLCPFM =  (0x0001<<3),
    _CLA_INIT_PWMADC =  (0x0001<<2),
    _CLA_INIT_CLACPU =  (0x0001<<1),
    _CLA_INIT_SUCCESS = (0x0001<<0),
    _CLA_NO_ACTION = 0,
    _CLA_INIT_FAIL = -1
} FG_CLASTAT;

typedef struct {
    float32_t   f32Input;
    uint16_t    u16Output;
} ST_DAC;

typedef struct {
    FG_CLASTAT  fgStatus;
    ST_IIR     sIout;
    ST_IIR     sOcp;
    ST_IIR     sIL;
    ST_IIR     sVout;
    ST_IIR     sOvp;
    ST_IIR     sIfront;
    ST_IIR     sVka;
    ST_IIR     sVin;

    CLA_LUKTB   sV2F;
    ST_PWMREG   sPWM;

    ST_DAC      sDACA;
    ST_DAC      sILcmd;

} ST_CLA;

extern volatile ST_CLA sCLA;



//CLA C Tasks defined in Cla1Tasks_C.cla
__attribute__((interrupt))  void Cla1Task1();
__attribute__((interrupt))  void Cla1Task2();
__attribute__((interrupt))  void Cla1Task3();
__attribute__((interrupt))  void Cla1Task4();
__attribute__((interrupt))  void Cla1Task5();
__attribute__((interrupt))  void Cla1Task6();
__attribute__((interrupt))  void Cla1Task7();
__attribute__((interrupt))  void Cla1Task8();

#endif /* CLA_TASK_H_ */
