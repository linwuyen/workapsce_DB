//
// Included Files
//
#include "common.h"
#include "ModbusSlave.h"
#include "smbus_slave.h"
#include "pmbus.h"
#include "power_supply.h"


volatile ST_DRV sDrv;





void task25msec(HAL_DRV s)
{
    //RED_LED_OFF;


    //RED_LED_ON;
}

void task2D5msec(HAL_DRV s)
{
    //DEBUG_IO_TOGGEL;
    execPowerSequence(s);
}

typedef struct _ST_TIMETASK{
    void (*fn) (HAL_DRV s);
    uint32_t cnt;
    uint32_t max;
} ST_TIMETASK;

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = {
        {task2D5msec,         0,   T_2D5MS},
        {task25msec,          0,   T_25MS},
        {0, 0, 0}
};


bool_t scanTimeTask(ST_TIMETASK *t, void *s)
{
    static uint32_t delta_t;
    static uint32_t u32Cnt = 0;

    u32Cnt = SW_TIMER - (uint32_t)CPUTimer_getTimerCount(SWTIRMER_BASE);


    if(t->cnt > u32Cnt) {
        delta_t = u32Cnt + 0xFFFFFFFF - t->cnt;
    }
    else {
        delta_t = u32Cnt - t->cnt;
    }

    if(delta_t >= t->max) {
        t->fn(s);
        t->cnt = u32Cnt;
        return true;
    }
    else {
        return false;
    }
}


//define list of pages
PMBUS_PAGE_LIST_BEGIN()
    PMBUS_PAGE_TABLE(Page_0)
    PMBUS_PAGE_TABLE(Page_1)
PMBUS_PAGE_LIST_END()


void CommBus_init(void)
{
    //Initialize SMBus Slave Driver
    SMBus_SlaveInit();
    //Initialize PMBus Slave Stack
    PMBus_Init();
    //Initialize your application
    PWR_Init();
}



//
// Main
//
void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Initialize GPIO and configure the GPIO pin as a push-pull output
    //
    Board_init();

    initPower((HAL_DRV)&sDrv);
    initClaCpu((HAL_DRV)&sDrv);
    initCLA();
    initPWM();

    CommBus_init();

    //
    // Enable ADC interrupt
    //
    Interrupt_enable(INT_ADCA_BASE_1);

    //
    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    //
    EINT;
    ERTM;




    //
    // Loop Forever
    //
    while(1)
    {
        scanTimeTask(&time_task[id_ttask++], (void *)&sDrv);
        if(0 == time_task[id_ttask].fn) id_ttask = 0;

        exeModbusSlave(&mbcomm);
        updateModbusParameter(&mbcomm);

        SMBus_SlavePoll();

        sCLA.sDACA.u16Output = (CMPSS_getMaxRampValue(PCMC_BASE)>>4)&0x0FFF;

        sCLA.sILcmd.u16Output = (uint16_t) (sCLA.sILcmd.f32Input*2048.0f + 2047.0f);
        // Set the DAC shadow output
        DAC_setShadowValue(DEBUG_DAC_BASE, sCLA.sDACA.u16Output);
        // Set the DAC shadow output
        DAC_setShadowValue(IL_COMMAND_BASE, sCLA.sILcmd.u16Output);
    }
}

//
// End of File
//
