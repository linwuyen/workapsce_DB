/*
 * cmath.h
 *
 *  Created on: 2022�~3��22��
 *      Author: cody_chen
 *
 */

#ifndef CMATH_H_
#define CMATH_H_


#include <math.h>
#include <limits.h>

#include <stdint.h>
#include <stdbool.h>
#include "driverlib.h"

#ifndef bool_t
typedef bool bool_t;
#endif

static inline float32_t csatf(float32_t data, float32_t max, float32_t min)
{
    if(max < data) return max;
    if(min > data) return min;
    return data;
}

static inline float32_t csatPU(float32_t data)
{
    return csatf(data, 1.0f, -1.0f);
}

static inline float32_t csatPosPU(float32_t data)
{
    return csatf(data, 1.0f, 0.0f);
}

static inline float32_t csatNegPU(float32_t data)
{
    return csatf(data, 0.0f, -1.0f);
}


typedef enum {
    _LUKTB_INIT_SUCCESS = 1,
    _LUKTB_NO_ERROR = 0,
    _LUKTB_INITL_FAIL = -1,
} FG_LUKTB;


typedef struct {
    FG_LUKTB  fgStauts;
    float32_t  f32Points;
    float32_t f32InputPU;
    float32_t f32ValidData;
    float32_t f32Real;
    uint32_t  u32Integer;
    float32_t f32Fraction;
    float32_t f32Table[32];
    float32_t f32Out;
} CLA_LUKTB;

static inline void initLookupTable_CLA(uint16_t u16IndexBits /* (TablePoints - 1) = 2 ^ u16IndexBits */,
                                   float32_t *f32Table, uint16_t u16TableSize,
                                   CLA_LUKTB *s)
{
    int16_t i;

    if(32 < u16TableSize) {
        s->fgStauts = _LUKTB_INITL_FAIL;
        return ;
    }


    s->fgStauts = _LUKTB_NO_ERROR;
    s->f32Points = (float32_t)(0x0001<<u16IndexBits);

    for(i=0; i<u16TableSize; i++) {
        s->f32Table[i] = *f32Table++;
    }

    if(u16TableSize != (uint16_t)(s->f32Points+1.0f)) {
        s->fgStauts = _LUKTB_INITL_FAIL;
    }
    else {
        s->fgStauts = _LUKTB_INIT_SUCCESS;
    }
}


static inline void scanF32Table_CLA(CLA_LUKTB *s)
{
    if(0 > s->fgStauts) return;

    s->f32ValidData = csatPU(s->f32InputPU)*0.5f + 0.5f;
    s->f32Real = s->f32Points*s->f32ValidData;
    s->u32Integer = (uint32_t)(s->f32Real);
    s->f32Fraction = s->f32Real - s->u32Integer;

    /* Interpolate between both points. */
    s->f32Out = s->f32Table[s->u32Integer] + ((s->f32Table[s->u32Integer+1] - s->f32Table[s->u32Integer]) * s->f32Fraction);
}


/*  @ Lookup Table Example
 *
    float32_t f32V2F[9] = {
        -2.0, -1.0, -0.5, 0.2, 2.5, 9.0, 10.0, 15.0, 20.0
    };

    ST_LUKTB sV2F;

    float32_t j = 0.0f;

    int main()
    {
        initLookupTable(3, f32V2F, &sV2F);

         for(j=-1.0f; j<1.0; j+=0.01) {
             sV2F.f32InputPU = j;
             scanF32PUtoF32(&sV2F);
             printf("%f:, real = %f, out = %f\n", j, sV2F.f32Real, sV2F.f32Out);
         }

        return 0;
    }
 *
 */

typedef struct {    float32_t    f32Target;     // Input: Target input (pu)
                    float32_t    f32Step;       // Parameter: Increase/Decrease Step (pu)
                    float32_t    f32LowLimit;   // Parameter: Minimum limit (pu)
                    float32_t    f32HighLimit;  // Parameter: Maximum limit (pu)
                    float32_t    f32Out;     // Output: Target output (pu)
               } ST_RAMPCTRL;

typedef ST_RAMPCTRL * HAL_RAMPCTRL;

static inline void execRampCtrl(HAL_RAMPCTRL v)
{
    if (v->f32Target > v->f32Out)  {
        v->f32Out += v->f32Step;
        if (v->f32Target < v->f32Out)  v->f32Out = v->f32Target;
        if (v->f32Out > v->f32HighLimit) v->f32Out = v->f32HighLimit;
    }
    else if (v->f32Target < v->f32Out){
        v->f32Out -= v->f32Step;
        if (v->f32Target > v->f32Out)  v->f32Out = v->f32Target;
        if (v->f32Out < v->f32LowLimit) v->f32Out = v->f32LowLimit;
    }
}

typedef struct {     float32_t    f32Target1;     // Input: Target input (pu)
                     float32_t    f32Target2;     // Input: Target input (pu)
                     float32_t    f32Step1;
                     float32_t    f32Step2;
                     float32_t    f32Error;
                     bool_t       blCountMode;
                     float32_t    f32LowLimit;   // Parameter: Minimum limit (pu)
                     float32_t    f32HighLimit;  // Parameter: Maximum limit (pu)
                     float32_t    f32Out;     // Output: Target output (pu)
               } ST_RAMPUPDN;

typedef ST_RAMPUPDN * HAL_RAMPUPDN;

static inline void execRampUpDwon(HAL_RAMPUPDN v)
{
    if(false == v->blCountMode) {
        if (v->f32Target1 > v->f32Out)  {
            v->f32Error = v->f32Target1 - v->f32Out;
            if(v->f32Error > v->f32Step1) {
                v->f32Out += v->f32Step1;
            }
            else {
                v->f32Out = v->f32Target1;
                v->blCountMode = true;
            }

        }
        else if (v->f32Target1 < v->f32Out){
            v->f32Error = v->f32Out - v->f32Target1;
            if(v->f32Error > v->f32Step1) {
                v->f32Out -= v->f32Step1;
            }
            else {
                v->f32Out = v->f32Target1;
                v->blCountMode = true;
            }
        }
    }
    else {
        if (v->f32Target2 > v->f32Out)  {
            v->f32Error = v->f32Target2 - v->f32Out;
            if(v->f32Error > v->f32Step2) {
                v->f32Out += v->f32Step2;
            }
            else {
                v->f32Out = v->f32Target2;
                v->blCountMode = false;
            }

        }
        else if (v->f32Target2 < v->f32Out){
            v->f32Error = v->f32Out - v->f32Target2;
            if(v->f32Error > v->f32Step2) {
                v->f32Out -= v->f32Step2;
            }
            else {
                v->f32Out = v->f32Target2;
                v->blCountMode = false;
            }
        }
    }

    if (v->f32Out > v->f32HighLimit) v->f32Out = v->f32HighLimit;
    if (v->f32Out < v->f32LowLimit) v->f32Out = v->f32LowLimit;
}

typedef struct { float32_t    f32Target;     // Input: Target input (pu)
                 float32_t    f32Step;       // Parameter: Increase/Decrease Step (pu)
                 float32_t    f32LowLimit;   // Parameter: Minimum limit (pu)
                 float32_t    f32HighLimit;  // Parameter: Maximum limit (pu)
                 float32_t    f32Out;     // Output: Target output (pu)
               } ST_SAWTOOTH;

typedef ST_SAWTOOTH * HAL_SAWTOOTH;

static inline void execSawTooth(HAL_SAWTOOTH v)
{
    if (v->f32Target > v->f32Out)  {
        v->f32Out += v->f32Step;
        if (v->f32Target < v->f32Out)  v->f32Out = v->f32Target;
        if (v->f32Out > v->f32HighLimit) v->f32Out = v->f32HighLimit;
    }
    else if (v->f32Target < v->f32Out){
        v->f32Out -= v->f32Step;
        if (v->f32Target > v->f32Out)  v->f32Out = v->f32Target;
        if (v->f32Out < v->f32LowLimit) v->f32Out = v->f32LowLimit;
    }
    else {
        v->f32Out = 0.0f;
    }
}

typedef struct {
    float32_t f32Gain;
    float32_t f32Offset;
    float32_t f32Out;
} ST_CAL;

static inline void getCaliData(float32_t *f32Input, ST_CAL * v)
{
    v->f32Out = *f32Input * v->f32Gain + v->f32Offset;
}

typedef struct {
    float32_t f32Now;
    float32_t f32K1;
    float32_t f32Out;
}ST_LPF;

typedef ST_LPF * HAL_LPF;


static inline void mLPF(HAL_LPF v)  //0.217usec
{
    v->f32Out = ( v->f32K1 * v->f32Out) + ((1.0f - v->f32K1) * v->f32Now);
}

typedef struct {
    float32_t f32Now;
    float32_t f32K1;
    float32_t f32Out;
}ST_IIR;

typedef ST_IIR * HAL_IIR;


static inline void mIIR(HAL_IIR v) //0.207usec
{
    v->f32Out += (v->f32K1 * (v->f32Now - v->f32Out));
}

#ifdef _FLASH
#pragma SET_CODE_SECTION(".TI.ramfunc")
#endif //_FLASH

static inline float32_t csatf_C28(float32_t data, float32_t max, float32_t min)
{
    if(max < data) return 1.0f;
    if(min > data) return -1.0f;
    return data;
}

typedef struct {
    FG_LUKTB  fgStauts;
    float32_t *f32Table;
    float32_t  f32Points;
    float32_t f32InputPU;
    float32_t f32ValidData;
    float32_t f32Real;
    uint32_t  u32Integer;
    float32_t f32Fraction;
    float32_t *p1;
    float32_t *p2;
    float32_t f32Out;
} ST_LUKTB;

static inline void initLookupTable_C28(uint16_t u16IndexBits /* (TablePoints - 1) = 2 ^ u16IndexBits */,
                                   float32_t *f32Table, uint16_t u16TableSize,
                                   ST_LUKTB *s)
{
    s->fgStauts = _LUKTB_NO_ERROR;
    s->f32Table = f32Table;
    s->f32Points = (float32_t)(0x0001<<u16IndexBits);

    if(u16TableSize != (uint16_t)(s->f32Points+1.0f)) {
        s->fgStauts = _LUKTB_INITL_FAIL;
    }
    else {
        s->fgStauts = _LUKTB_INIT_SUCCESS;
    }
}

static inline void scanF32Table_C28(ST_LUKTB *s)
{
    if(0 > s->fgStauts) return;

    s->f32ValidData = csatPU(s->f32InputPU)*0.5f + 0.5f;
    s->f32Real = s->f32Points*s->f32ValidData;
    s->u32Integer = (uint32_t)(s->f32Real);
    s->f32Fraction = s->f32Real - s->u32Integer;

    s->p1 = &s->f32Table[s->u32Integer];
    s->p2 = s->p1 + 1;

    /* Interpolate between both points. */
    s->f32Out = *s->p1 + ((*s->p2 - *s->p1) * s->f32Fraction);
}


typedef struct {
    float32_t  f32Out;           // Output: controller output
    float32_t  f32Max;           // Parameter: Limit the controller output by Maximum
    float32_t  f32Min;           // Parameter: Limit the controller output by Minimum
    float32_t  f32Kp;            // Parameter: proportional loop gain
    float32_t  f32Ki;            // Parameter: integral gain (0.0~1.0)
    bool_t     blStopUi;         // Parameter: Used to stop the integral term.
    float32_t  f32Err;           // Data: (f32) Error between the feedback and reference
    float32_t  f32Pdata;         // Data: (f32) Save the proportional term results
    float32_t  f32Idata;         // Data: (f32) Save the integral term
    float32_t  f32Itemp;         // Data: (F32) Temporarily save the integral term i(k-1)
    float32_t  f32Sum;           // Data: Sum of proportional term and integral term
} ST_PI;


static inline void mPiLoop_C28(ST_PI *p)  //0.779usec
{

    /* integral term */
    if((p->f32Sum == p->f32Out)&&(false == p->blStopUi)) {
        p->f32Idata = p->f32Itemp + p->f32Ki * p->f32Err;
    }
    else {
        p->f32Idata = p->f32Itemp;
    }
    p->f32Itemp = p->f32Idata;


    /* proportional term */
    p->f32Pdata = csatf_C28(p->f32Kp * p->f32Err, 1.0f, -1.0f);

    /* control output */
    p->f32Sum = p->f32Pdata + p->f32Idata;
    p->f32Out = csatf_C28(p->f32Sum, p->f32Max, p->f32Min);
}

#ifdef _FLASH
#pragma SET_CODE_SECTION()
#endif //_FLASH


#endif /* CMATH_H_ */
