/*
 * cla_task.h
 *
 *  Created on: 2022�~3��29��
 *      Author: cody_chen
 */

#ifndef CLA_TASK_H_
#define CLA_TASK_H_

#include "ctypedef.h"
#include "cla_cmath.h"

enum {
    _CLA_NO_ERROR        = (0x0000),
    _CLA_IIN1_OCP        = (0x0001U<<0),
    _CLA_IIN2_OCP        = (0x0001U<<1),
    _CLA_IIN3_OCP        = (0x0001U<<2),
    _CLA_IOUT_OCP        = (0x0001U<<3),
    _CLA_OCP_MASK        = (_CLA_IIN1_OCP|_CLA_IIN2_OCP|_CLA_IIN3_OCP|_CLA_IOUT_OCP),
    _CLA_VIN1_OVP        = (0x0001U<<4),
    _CLA_VIN2_OVP        = (0x0001U<<5),
    _CLA_VIN3_OVP        = (0x0001U<<6),
    _CLA_VOUT_OVP        = (0x0001U<<7),
    _CLA_OVP_MASK        = (_CLA_VIN1_OVP|_CLA_VIN2_OVP|_CLA_VIN3_OVP|_CLA_VOUT_OVP),
    _CLA_WARNING_OVP     = (0x0001U<<8),
    _CLA_WARNING_UVP     = (0x0001U<<9),
    _CLA_WARNING_OCP     = (0x0001U<<10),
    _CLA_WARNING_OTP     = (0x0001U<<11),
    _CLA_WARNING_MASK    = (_CLA_WARNING_OVP|_CLA_WARNING_OVP|_CLA_WARNING_OCP|_CLA_WARNING_OTP),
    _CLA_ERROR_OVP       = (0x0001U<<12),
    _CLA_ERROR_UVP       = (0x0001U<<13),
    _CLA_ERROR_OCP       = (0x0001U<<14),
    _CLA_ERROR_OTP       = (0x0001U<<15),
    _CLA_ERROR_MASK      = (_CLA_ERROR_OVP|_CLA_ERROR_UVP|_CLA_ERROR_OCP|_CLA_ERROR_OTP),
    _CLA_ALL_ERROR       = (0xFFFFU)
};

enum {
    _CLA_NO_ACTION       =  (0x0000),
    _CLA_INIT_DRV_PARAM  =  (0x0001U<<0),
    _CLA_INIT_CLA_PARAM  =  (0x0001U<<1),
    _CLA_INIT_PWMADC     =  (0x0001U<<2),
    _CLA_INIT_SUCCESS    =  (_CLA_INIT_DRV_PARAM|_CLA_INIT_CLA_PARAM|_CLA_INIT_PWMADC),
    _CLA_TASK1_OK        =  (0x0001U<<4),
    _CLA_PWMADC_OK       =  (0x0001U<<5),
    _CLA_PWM_GPIO_OK     =  (0x0001U<<6),
    _CLA_SYSTEM_WARNING  =  (0x0001U<<14),
    _CLA_SYSTEM_ERROR    =  (0x0001U<<15)
};

typedef uint16_t FG_CLASTAT;
typedef uint16_t FG_CLAERROR;



typedef struct {
    float32_t  f32Adc;
    ST_LPF     sLPF;
    ST_CAL     sCali;
} ST_ADCLPF;

typedef struct {
    float32_t  f32Adc;
    ST_IIR     sIIR;
    ST_CAL     sCali;
} ST_ADCIIR;

typedef struct {
    uint16_t  u16Max;
    uint16_t  u16Cnt;
} ST_DLY;


typedef struct {

    ST_ADCLPF  sVin1;
    ST_ADCLPF  sVin2;
    ST_ADCLPF  sVin3;
    ST_ADCLPF  sIin1;
    ST_ADCLPF  sIin2;
    ST_ADCLPF  sIin3;
    ST_ADCLPF  sIout;
    ST_ADCLPF  sVout;
    ST_ADCIIR  sTempC;
    uint32_t  u32OffsetCaliCnt;

    ST_CLARKE  sClarkeV;
    ST_PARK    sParkV;
    float32_t  f32ThetaV;
    float32_t  f32PhaseSeq;
    ST_CLARKE  sClarkeI;
    ST_PARK    sParkI;
    ST_IPARK   siParkI;
    ST_iCLARKE siClarkeI;
    ST_SVPWM   sVPWMI;
    ST_DPWM1   sDPWM1;

    float32_t f32Vac1A;
    float32_t f32Vac2A;
    float32_t f32Vac3A;

    float32_t f32LoopKpI;
    float32_t f32LoopKiI;

    float32_t f32IdDecouple;
    float32_t f32IqDecouple;
    float32_t f32IdOut;
    float32_t f32IqOut;
    float32_t f32PLL1PeriodScale;
    float32_t f32OmegaL;
    float32_t f32Vdecoef;
    float32_t f32Idecoef;
    float32_t f32VbusInverse;
    float32_t f32Vdcom;
    float32_t f32Vqcom;
    float32_t f32Vdff;
    float32_t f32Vqff;


    ST_PI sLoopId;
    ST_PI sLoopIq;
    ST_PI sLoopV;

    float32_t f32Vac1;
    float32_t f32Vac2;
    float32_t f32Vac3;

    float32_t f32Vac1Scale;
    float32_t f32Vac2Scale;
    float32_t f32Vac3Scale;
    float32_t f32Vref;
    float32_t f32Vbus;
    float32_t f32InvRms;
    float32_t f32Iref1;
    float32_t f32Iref1Scale;

    float32_t f32Iref2;
    float32_t f32Iref2Scale;

    float32_t f32Iref3;
    float32_t f32Iref3Scale;

    ST_PWM  sPWM;

    FG_CLASTAT  fgStatus;
    FG_CLAERROR fgError;

    float32_t f32OcpRange;
    ST_DLY    sOcpDly;
    uint32_t    u32BurstCnt;
}  ST_CLA;

extern volatile ST_CLA sCLA;


#define FG_GETCLA(x)   FG_GET(x, sCLA.fgStatus)
#define FG_SETCLA(x)   FG_SET(x, sCLA.fgStatus)
#define FG_RSTCLA(x)   FG_RST(x, sCLA.fgStatus)

#define FG_GETERR(x)   FG_GET(x, sCLA.fgError)
#define FG_SETERR(x)   FG_SET(x, sCLA.fgError)
#define FG_RSTERR(x)   FG_RST(x, sCLA.fgError)
#define FG_ANDERR(x)   FG_AND(x, sCLA.fgError)

#define FG_GETPWM(x)   FG_GET(x, sCLA.sPWM.u16CtrlReg)
#define FG_SETPWM(x)   FG_SET(x, sCLA.sPWM.u16CtrlReg)
#define FG_RSTPWM(x)   FG_RST(x, sCLA.sPWM.u16CtrlReg)
#define FG_ANDPWM(x)   FG_AND(x, sCLA.sPWM.u16CtrlReg)


//CLA C Tasks defined in Cla1Tasks_C.cla
__attribute__((interrupt))  void Cla1Task1();
__attribute__((interrupt))  void Cla1Task2();
__attribute__((interrupt))  void Cla1Task3();
__attribute__((interrupt))  void Cla1Task4();
__attribute__((interrupt))  void Cla1Task5();
__attribute__((interrupt))  void Cla1Task6();
__attribute__((interrupt))  void Cla1Task7();
__attribute__((interrupt))  void Cla1Task8();

#endif /* CLA_TASK_H_ */
