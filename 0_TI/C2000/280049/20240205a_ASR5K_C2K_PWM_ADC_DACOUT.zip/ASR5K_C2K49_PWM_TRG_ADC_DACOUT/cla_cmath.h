/*
 * cla_cmath.h
 *
 *  Created on: 2022�~3��22��
 *      Author: cody_chen
 *
 */

#ifndef CLA_CMATH_H_
#define CLA_CMATH_H_

#include "ctypedef.h"
#include "CLAmath.h"

static inline void CLA_getAcCaliData(float32_t *f32Input, ST_CAL * v) //200nsec_now
{
    v->f32Out = (*f32Input + v->f32Offset) * v->f32Gain;
//    v->f32Real = v->f32Out * v->f32Base;
}

static inline void CLA_getAcCaliOffset(float32_t *f32Input, ST_CAL * v) //180nsec_now
{
    v->f32Offset = - *f32Input;
}


static inline void CLA_getCaliData(float32_t *f32Input, ST_CAL * v)
{
    v->f32Out = *f32Input * v->f32Gain + v->f32Offset;
//    v->f32Real = v->f32Out * v->f32Base;
}


static inline void CLA_mLPF(HAL_LPF v)  //0.217usec_previous
{
    v->f32Out = ( v->f32K1 * v->f32Out) + ((1.0f - v->f32K1) * v->f32Now);
}


static inline void CLA_mIIR(HAL_IIR v) //0.207usec_previous
{
    v->f32Out += (v->f32K1 * (v->f32Now - v->f32Out));
}

static inline float32_t CLA_csatf(float32_t data, float32_t max, float32_t min) //230nsec_now
{
    if(max < data) return max;
    if(min > data) return min;
    return data;
}

static inline void CLA_mPiLoop(volatile ST_PI *p) //710nsec_now
{
//    p->f32LimitErr = CLA_csatf(p->f32Err, 1.0f, -1.0f);

    /* integral term */
    if((p->f32Sum == p->f32Out)&&(false == p->u16StopUi)) {
        p->f32Idata = p->f32Itemp + p->f32Ki * p->f32Err;
    }
    else {
        p->f32Idata = p->f32Itemp;
    }
    p->f32Itemp = p->f32Idata;


    /* proportional term */
//    p->f32Pdata = CLA_csatf(p->f32Kp * p->f32Err, 1.0f, -1.0f);
    p->f32Pdata = p->f32Kp * p->f32Err;

    /* control output */
    p->f32Sum = p->f32Pdata + p->f32Idata;
    p->f32Out = CLA_csatf(p->f32Sum, p->f32Max, p->f32Min);
}

//static inline void CLA_mType3Loop(volatile ST_Type3 *p)
//{
////      p->f32LimitErr = CLA_csatf(p->f32Err, 1.0f, -1.0f);
//        p->f32X4 = p->f32Err +  p->f32KX3 * p->f32X3temp + p->f32KX2 * p->f32X2temp + p->f32KX1 * p->f32X1temp;
//        p->f32X3 = p->f32X4  + p->f32X3temp;
//        p->f32X2 = p->f32X3  + p->f32X2temp;
//        p->f32X1 = p->f32X2  + p->f32X1temp;
//        p->f32Out = p->f32KiX3 * p->f32X3 + p->f32KiX2 * p->f32X2 + p->f32KiX1 * p->f32X1;
//        p->f32X4temp = p->f32X4;
//        p->f32X3temp = p->f32X3;
//        p->f32X2temp = p->f32X2;
//        p->f32X1temp = p->f32X1;
//}

//static inline void CLA_DeCouple(HAL_Decouple v, HAL_PARK w, HAL_PARK x, float32_t *pf32VbusInverse, float32_t *pfId32Out, float32_t *pIqf32Out)
//{
//     v->f32Vdff = (w->f32D * v->f32Vdecoef + x->f32Q * v->f32Idecoef) * sCLA.f32VbusInverse;
//     v->f32Vqff = (w->f32Q * v->f32Vdecoef - x->f32D * v->f32Idecoef) * sCLA.f32VbusInverse;
//     v->f32Vdcom = sCLA.sLoopId.f32Out + v->f32Vdff;
//     v->f32Vqcom = sCLA.sLoopIq.f32Out + v->f32Vqff  ;
//}

static inline void CLA_CLARKE(float32_t *pf32PhaseA, float32_t *pf32PhaseB, float32_t *pf32PhaseC, HAL_CLARKE v) //390nsec_now
{
    v->f32Alpha = *pf32PhaseA;
    v->f32Beta = (*pf32PhaseB - *pf32PhaseC) * 0.57735f;
}


static inline void CLA_PARK(float32_t *pf32Alpha, float32_t *pf32Beta, float32_t *pf32Theta, HAL_PARK v) //1.43usec_now
{
#if (0 ==  UPDATE_PARK_BY_C28)
    v->f32sin = CLAsinPU(*pf32Theta);
    v->f32cos = CLAcosPU(*pf32Theta);
#endif  //UPDATE_PARK_BY_C28

    v->f32D = *pf32Alpha * v->f32cos + *pf32Beta * v->f32sin;
    v->f32Q = *pf32Beta * v->f32cos - *pf32Alpha * v->f32sin;
}

static inline void CLA_iPARK(float32_t *pf32D, float32_t *pf32Q, float32_t *pf32Theta, HAL_IPARK v) //1.49usec_now
{
#if (0 ==  UPDATE_PARK_BY_C28)
    v->f32sin = CLAsinPU(*pf32Theta);
    v->f32cos = CLAcosPU(*pf32Theta);
#endif  //UPDATE_PARK_BY_C28

/* Convert d-q current into a-b plant */
    v->f32Alpha = *pf32D *  v->f32cos - *pf32Q *  v->f32sin;
    v->f32Beta =  *pf32D *  v->f32sin + *pf32Q *  v->f32cos;
}


static inline void CLA_iCLARKE(HAL_IPARK pIpark, HAL_iCLARKE v) //330nsec_now
{
    v->f32TempSv1= pIpark->f32Alpha * 0.5f;
    v->f32TempSv2= pIpark->f32Beta * 0.86602f;

/* Inverse clarke transformation */
    v->f32Ta = pIpark->f32Alpha;
    v->f32Tb = -v->f32TempSv1 + v->f32TempSv2;
    v->f32Tc = -v->f32TempSv1 - v->f32TempSv2;
}


static inline void CLA_SVPWM(HAL_IPARK pIpark,  HAL_SVPWM v) //1.09usec_now
{

///* Inverse clarke transformation */
    v->f32Tmp1= pIpark->f32Beta;
    v->f32Tmp2= pIpark->f32Beta * 0.5f + pIpark->f32Alpha * 0.86603f;
    v->f32Tmp3= v->f32Tmp2 - v->f32Tmp1; // -v->f32Beta * 0.5f + v->f32Alpha * 0.86603f;

    v->u16VecSector=3;
    v->u16VecSector=(v->f32Tmp2> 0)?( v->u16VecSector-1):v->u16VecSector;
    v->u16VecSector=(v->f32Tmp3> 0)?( v->u16VecSector-1):v->u16VecSector;
    v->u16VecSector=(v->f32Tmp1< 0)?(7-v->u16VecSector) :v->u16VecSector;

    if(1 == v->u16VecSector || 4 == v->u16VecSector) {
        v->f32Ta= v->f32Tmp2;
        v->f32Tb= v->f32Tmp1-v->f32Tmp3;
        v->f32Tc=-v->f32Tmp2;
    }
    else if(2 == v->u16VecSector || 5 == v->u16VecSector) {
        v->f32Ta= v->f32Tmp3+v->f32Tmp2;
        v->f32Tb= v->f32Tmp1;
        v->f32Tc=-v->f32Tmp1;
    }
    else {
        v->f32Ta= v->f32Tmp3;
        v->f32Tb=-v->f32Tmp3;
        v->f32Tc=-(v->f32Tmp1+v->f32Tmp2);
    }
}

static inline void CLA_DPWM1(HAL_iCLARKE p,  HAL_DPWM1 v) //
{

        v->f32Tmp3 = p->f32Tc * 1.15470f;
        v->f32Tmp1 = p->f32Ta * 1.15470f;
        v->f32Tmp2 = p->f32Tb * 1.15470f;
        v->f32MIN = (v->f32Tmp1 > v->f32Tmp2) ? v->f32Tmp2 : v->f32Tmp1;
        v->f32MIN = (v->f32MIN > v->f32Tmp3) ? v->f32Tmp3 : v->f32MIN;
        v->f32SUMMIN = (-1.0f) - v->f32MIN;
        v->f32MAX = (v->f32Tmp1 < v->f32Tmp2) ? v->f32Tmp2 : v->f32Tmp1;
        v->f32MAX = (v->f32MAX < v->f32Tmp3) ? v->f32Tmp3 : v->f32MAX;
        v->f32SUMMAX = 1.0f - v->f32MAX;
//        v->f32ABSMAX = fabs(v->f32MAX);
//        v->f32ABSMIN = fabs(v->f32MIN);
        v->f32ABSMAX = (v->f32MAX > 0.0f) ? v->f32MAX : (0.0f- v->f32MAX);
        v->f32ABSMIN = (v->f32MIN > 0.0f) ? v->f32MIN : (0.0f- v->f32MIN);

//        v->f32COMP = (v->f32ABSMAX > v->f32ABSMIN) ? 1 : 0;
//        v->f32MUX = (v->f32COMP > 0.5) ? v->f32SUMMAX : v->f32SUMMIN;
        v->f32MUX = (v->f32ABSMAX > v->f32ABSMIN) ? v->f32SUMMAX : v->f32SUMMIN;
        v->f32Tc = v->f32Tmp3 + v->f32MUX;
        v->f32Tb = v->f32Tmp2 + v->f32MUX;
        v->f32Ta = v->f32Tmp1 + v->f32MUX;
}

#endif /* CLA_CMATH_H_ */
