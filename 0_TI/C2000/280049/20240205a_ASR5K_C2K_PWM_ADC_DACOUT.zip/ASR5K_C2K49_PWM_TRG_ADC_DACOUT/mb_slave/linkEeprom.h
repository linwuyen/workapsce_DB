/*
 *  File Name: linkEeprom.h
 *
 *  Created on: 10/6/2023
 *  Author: POWER2-54FD92
 */

typedef struct {
    uint16_t size;
    void *ptr;
} EE_REG;
typedef EE_REG * HAL_EEREG;

#define _BLK16_AA	25
uint16_t blkAA[_BLK16_AA];
const EE_REG regAA[7] = {
              {4, (void*)&sCLA.sLoopV.f32Kp},
              {4, (void*)&sCLA.sLoopV.f32Ki},
              {4, (void*)&sCLA.sLoopId.f32Kp},
              {4, (void*)&sCLA.sLoopId.f32Ki},
              {4, (void*)&sCLA.sLoopIq.f32Kp},
              {4, (void*)&sCLA.sLoopIq.f32Ki},
              {1, (void*)&blkAA[24]}};
#define _TABLE_AA	7

#define _BLK16_BB	13
uint16_t blkBB[_BLK16_BB];
const EE_REG regBB[4] = {
              {4, (void*)&},
              {4, (void*)&},
              {4, (void*)&},
              {1, (void*)&blkBB[12]}};
#define _TABLE_BB	4

