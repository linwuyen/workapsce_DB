/*
 *  File Name: tbmenu.c
 *
 *  Created on: 10/6/2023
 *  Author: POWER2-54FD92
 */

#include "ModbusSlave.h"
#include "mbcmd.h"


REG_MBUSDATA regMbusData;

int chkValidAddress(uint16_t addr) {
    switch(addr) {
	    case _muSYStemSTAtus:                                           
	    case _muCONtrolREGister:                                        
	    case _muFAUltSTAtus:                                            
	    case _muENABlePFCPWM:                                           
	    case _muVREf:                                                   
	    case _muVRMs:                                                   
	    case _muPHAseSEQuence0:                                         
	    case _muPHAseSEQuence1:                                         
	    case _muDACSELcet:                                              
	    case _muPERiod:                                                 
	    case _muADCLPFVIN10:                                            
	    case _muADCLPFVIN11:                                            
	    case _muADCLPFVIN20:                                            
	    case _muADCLPFVIN21:                                            
	    case _muADCLPFVIN30:                                            
	    case _muADCLPFVIN31:                                            
	    case _muADCLPFVPFc0:                                            
	    case _muADCLPFVPFc1:                                            
	    case _muADCLPFIIN10:                                            
	    case _muADCLPFIIN11:                                            
	    case _muADCLPFIIN20:                                            
	    case _muADCLPFIIN21:                                            
	    case _muADCLPFIIN30:                                            
	    case _muADCLPFIIN31:                                            
	    case _muBURstCOUnt0:                                            
	    case _muBURstCOUnt1:                                            
	    case _muVBUsOUT0:                                               
	    case _muVBUsOUT1:                                               
	    case _muVLOopkp0:                                               
	    case _muVLOopkp1:                                               
	    case _muVLOopki0:                                               
	    case _muVLOopki1:                                               
	    case _muVLOopOUT0:                                              
	    case _muVLOopOUT1:                                              
	    case _muIDLOopkp0:                                              
	    case _muIDLOopkp1:                                              
	    case _muIDLOopki0:                                              
	    case _muIDLOopki1:                                              
	    case _muIDLOopOUT0:                                             
	    case _muIDLOopOUT1:                                             
	    case _muIQLOopkp0:                                              
	    case _muIQLOopkp1:                                              
	    case _muIQLOopki0:                                              
	    case _muIQLOopki1:                                              
	    case _muIQLOopOUT0:                                             
	    case _muIQLOopOUT1:                                             
	    case _muC2000wareVERsion0:                                      
	    case _muC2000wareVERsion1:                                      
	    case _muSYSconfigVERsion0:                                      
	    case _muSYSconfigVERsion1:                                      
	    case _muSOFtwareversion0:                                       
	    case _muSOFtwareversion1:                                       
        return 0;
    default:
        return MB_ERROR_ILLEGALADDR;
    }
}

uint16_t getModbusData(uint16_t addr) {
    switch(addr) {
	    case _muSYStemSTAtus: return regMbusData.u16MbusData[0];                            
	    case _muCONtrolREGister: return regMbusData.u16MbusData[1];                            
	    case _muFAUltSTAtus: return regMbusData.u16MbusData[2];                            
	    case _muENABlePFCPWM: return regMbusData.u16MbusData[3];                            
	    case _muVREf: return regMbusData.u16MbusData[4];                            
	    case _muVRMs: return regMbusData.u16MbusData[5];                            
	    case _muPHAseSEQuence0: return regMbusData.u16MbusData[6];                            
	    case _muPHAseSEQuence1: return regMbusData.u16MbusData[7];                            
	    case _muDACSELcet: return regMbusData.u16MbusData[8];                            
	    case _muPERiod: return regMbusData.u16MbusData[9];                            
	    case _muADCLPFVIN10: return regMbusData.u16MbusData[10];                            
	    case _muADCLPFVIN11: return regMbusData.u16MbusData[11];                            
	    case _muADCLPFVIN20: return regMbusData.u16MbusData[12];                            
	    case _muADCLPFVIN21: return regMbusData.u16MbusData[13];                            
	    case _muADCLPFVIN30: return regMbusData.u16MbusData[14];                            
	    case _muADCLPFVIN31: return regMbusData.u16MbusData[15];                            
	    case _muADCLPFVPFc0: return regMbusData.u16MbusData[16];                            
	    case _muADCLPFVPFc1: return regMbusData.u16MbusData[17];                            
	    case _muADCLPFIIN10: return regMbusData.u16MbusData[18];                            
	    case _muADCLPFIIN11: return regMbusData.u16MbusData[19];                            
	    case _muADCLPFIIN20: return regMbusData.u16MbusData[20];                            
	    case _muADCLPFIIN21: return regMbusData.u16MbusData[21];                            
	    case _muADCLPFIIN30: return regMbusData.u16MbusData[22];                            
	    case _muADCLPFIIN31: return regMbusData.u16MbusData[23];                            
	    case _muBURstCOUnt0: return regMbusData.u16MbusData[24];                            
	    case _muBURstCOUnt1: return regMbusData.u16MbusData[25];                            
	    case _muVBUsOUT0: return regMbusData.u16MbusData[26];                            
	    case _muVBUsOUT1: return regMbusData.u16MbusData[27];                            
	    case _muVLOopkp0: return regMbusData.u16MbusData[28];                            
	    case _muVLOopkp1: return regMbusData.u16MbusData[29];                            
	    case _muVLOopki0: return regMbusData.u16MbusData[30];                            
	    case _muVLOopki1: return regMbusData.u16MbusData[31];                            
	    case _muVLOopOUT0: return regMbusData.u16MbusData[32];                            
	    case _muVLOopOUT1: return regMbusData.u16MbusData[33];                            
	    case _muIDLOopkp0: return regMbusData.u16MbusData[34];                            
	    case _muIDLOopkp1: return regMbusData.u16MbusData[35];                            
	    case _muIDLOopki0: return regMbusData.u16MbusData[36];                            
	    case _muIDLOopki1: return regMbusData.u16MbusData[37];                            
	    case _muIDLOopOUT0: return regMbusData.u16MbusData[38];                            
	    case _muIDLOopOUT1: return regMbusData.u16MbusData[39];                            
	    case _muIQLOopkp0: return regMbusData.u16MbusData[40];                            
	    case _muIQLOopkp1: return regMbusData.u16MbusData[41];                            
	    case _muIQLOopki0: return regMbusData.u16MbusData[42];                            
	    case _muIQLOopki1: return regMbusData.u16MbusData[43];                            
	    case _muIQLOopOUT0: return regMbusData.u16MbusData[44];                            
	    case _muIQLOopOUT1: return regMbusData.u16MbusData[45];                            
	    case _muC2000wareVERsion0: return regMbusData.u16MbusData[46];                            
	    case _muC2000wareVERsion1: return regMbusData.u16MbusData[47];                            
	    case _muSYSconfigVERsion0: return regMbusData.u16MbusData[48];                            
	    case _muSYSconfigVERsion1: return regMbusData.u16MbusData[49];                            
	    case _muSOFtwareversion0: return regMbusData.u16MbusData[50];                            
	    case _muSOFtwareversion1: return regMbusData.u16MbusData[51];                            
    default:
        return 0xFFFF;
    }
}

uint16_t setModbusData(uint16_t addr, uint16_t data) {
    switch(addr) {
	    case _muSYStemSTAtus: regMbusData.u16MbusData[0] = data; break;                            
	    case _muCONtrolREGister: regMbusData.u16MbusData[1] = data; break;                            
	    case _muFAUltSTAtus: regMbusData.u16MbusData[2] = data; break;                            
	    case _muENABlePFCPWM: regMbusData.u16MbusData[3] = data; break;                            
	    case _muVREf: regMbusData.u16MbusData[4] = data; break;                            
	    case _muVRMs: regMbusData.u16MbusData[5] = data; break;                            
	    case _muPHAseSEQuence0: regMbusData.u16MbusData[6] = data; break;                            
	    case _muPHAseSEQuence1: regMbusData.u16MbusData[7] = data; break;                            
	    case _muDACSELcet: regMbusData.u16MbusData[8] = data; break;                            
	    case _muPERiod: regMbusData.u16MbusData[9] = data; break;                            
	    case _muADCLPFVIN10: regMbusData.u16MbusData[10] = data; break;                            
	    case _muADCLPFVIN11: regMbusData.u16MbusData[11] = data; break;                            
	    case _muADCLPFVIN20: regMbusData.u16MbusData[12] = data; break;                            
	    case _muADCLPFVIN21: regMbusData.u16MbusData[13] = data; break;                            
	    case _muADCLPFVIN30: regMbusData.u16MbusData[14] = data; break;                            
	    case _muADCLPFVIN31: regMbusData.u16MbusData[15] = data; break;                            
	    case _muADCLPFVPFc0: regMbusData.u16MbusData[16] = data; break;                            
	    case _muADCLPFVPFc1: regMbusData.u16MbusData[17] = data; break;                            
	    case _muADCLPFIIN10: regMbusData.u16MbusData[18] = data; break;                            
	    case _muADCLPFIIN11: regMbusData.u16MbusData[19] = data; break;                            
	    case _muADCLPFIIN20: regMbusData.u16MbusData[20] = data; break;                            
	    case _muADCLPFIIN21: regMbusData.u16MbusData[21] = data; break;                            
	    case _muADCLPFIIN30: regMbusData.u16MbusData[22] = data; break;                            
	    case _muADCLPFIIN31: regMbusData.u16MbusData[23] = data; break;                            
	    case _muBURstCOUnt0: regMbusData.u16MbusData[24] = data; break;                            
	    case _muBURstCOUnt1: regMbusData.u16MbusData[25] = data; break;                            
	    case _muVBUsOUT0: regMbusData.u16MbusData[26] = data; break;                            
	    case _muVBUsOUT1: regMbusData.u16MbusData[27] = data; break;                            
	    case _muVLOopkp0: regMbusData.u16MbusData[28] = data; break;                            
	    case _muVLOopkp1: regMbusData.u16MbusData[29] = data; break;                            
	    case _muVLOopki0: regMbusData.u16MbusData[30] = data; break;                            
	    case _muVLOopki1: regMbusData.u16MbusData[31] = data; break;                            
	    case _muVLOopOUT0: regMbusData.u16MbusData[32] = data; break;                            
	    case _muVLOopOUT1: regMbusData.u16MbusData[33] = data; break;                            
	    case _muIDLOopkp0: regMbusData.u16MbusData[34] = data; break;                            
	    case _muIDLOopkp1: regMbusData.u16MbusData[35] = data; break;                            
	    case _muIDLOopki0: regMbusData.u16MbusData[36] = data; break;                            
	    case _muIDLOopki1: regMbusData.u16MbusData[37] = data; break;                            
	    case _muIDLOopOUT0: regMbusData.u16MbusData[38] = data; break;                            
	    case _muIDLOopOUT1: regMbusData.u16MbusData[39] = data; break;                            
	    case _muIQLOopkp0: regMbusData.u16MbusData[40] = data; break;                            
	    case _muIQLOopkp1: regMbusData.u16MbusData[41] = data; break;                            
	    case _muIQLOopki0: regMbusData.u16MbusData[42] = data; break;                            
	    case _muIQLOopki1: regMbusData.u16MbusData[43] = data; break;                            
	    case _muIQLOopOUT0: regMbusData.u16MbusData[44] = data; break;                            
	    case _muIQLOopOUT1: regMbusData.u16MbusData[45] = data; break;                            
	    case _muC2000wareVERsion0: regMbusData.u16MbusData[46] = data; break;                            
	    case _muC2000wareVERsion1: regMbusData.u16MbusData[47] = data; break;                            
	    case _muSYSconfigVERsion0: regMbusData.u16MbusData[48] = data; break;                            
	    case _muSYSconfigVERsion1: regMbusData.u16MbusData[49] = data; break;                            
	    case _muSOFtwareversion0: regMbusData.u16MbusData[50] = data; break;                            
	    case _muSOFtwareversion1: regMbusData.u16MbusData[51] = data; break;                            
    default:
        return 0xFFFF;
    }
    return data;
}



