/*
 *  File Name: mbcmd.h
 *
 *  Created on: 10/6/2023
 *  Author: POWER2-54FD92
 */

#ifndef MBCMD_H_
#define MBCMD_H_



typedef enum {
	_g2000_MODE = 0,
    _END_OF_MODE
} ID_MODE;


enum {
	_muSYStemSTAtus = 2000,                 // #2000  T_U16             
	_muCONtrolREGister = 2001,              // #2001  T_U16             
	_muFAUltSTAtus = 2002,                  // #2002  T_U16             
	_muENABlePFCPWM = 2003,                 // #2003  T_U16             
	_muVREf = 2004,                         // #2004  T_Q15             
	_muVRMs = 2005,                         // #2005  T_Q15             
	_muPHAseSEQuence0 = 2006,               // #2006  T_F32             
	_muPHAseSEQuence1 = 2007,               // #2007  T_F32             
	_muDACSELcet = 2008,                    // #2008  T_U16             
	_muPERiod = 2009,                       // #2009  T_U16             
	_muADCLPFVIN10 = 2010,                  // #2010  T_F32             
	_muADCLPFVIN11 = 2011,                  // #2011  T_F32             
	_muADCLPFVIN20 = 2012,                  // #2012  T_F32             
	_muADCLPFVIN21 = 2013,                  // #2013  T_F32             
	_muADCLPFVIN30 = 2014,                  // #2014  T_F32             
	_muADCLPFVIN31 = 2015,                  // #2015  T_F32             
	_muADCLPFVPFc0 = 2016,                  // #2016  T_F32             
	_muADCLPFVPFc1 = 2017,                  // #2017  T_F32             
	_muADCLPFIIN10 = 2018,                  // #2018  T_F32             
	_muADCLPFIIN11 = 2019,                  // #2019  T_F32             
	_muADCLPFIIN20 = 2020,                  // #2020  T_F32             
	_muADCLPFIIN21 = 2021,                  // #2021  T_F32             
	_muADCLPFIIN30 = 2022,                  // #2022  T_F32             
	_muADCLPFIIN31 = 2023,                  // #2023  T_F32             
	_muBURstCOUnt0 = 2024,                  // #2024  T_U32             
	_muBURstCOUnt1 = 2025,                  // #2025  T_U32             
	_muVBUsOUT0 = 2026,                     // #2026  T_F32             
	_muVBUsOUT1 = 2027,                     // #2027  T_F32             
	_muVLOopkp0 = 2028,                     // #2028  T_F32             
	_muVLOopkp1 = 2029,                     // #2029  T_F32             
	_muVLOopki0 = 2030,                     // #2030  T_F32             
	_muVLOopki1 = 2031,                     // #2031  T_F32             
	_muVLOopOUT0 = 2032,                    // #2032  T_F32             
	_muVLOopOUT1 = 2033,                    // #2033  T_F32             
	_muIDLOopkp0 = 2034,                    // #2034  T_F32             
	_muIDLOopkp1 = 2035,                    // #2035  T_F32             
	_muIDLOopki0 = 2036,                    // #2036  T_F32             
	_muIDLOopki1 = 2037,                    // #2037  T_F32             
	_muIDLOopOUT0 = 2038,                   // #2038  T_F32             
	_muIDLOopOUT1 = 2039,                   // #2039  T_F32             
	_muIQLOopkp0 = 2040,                    // #2040  T_F32             
	_muIQLOopkp1 = 2041,                    // #2041  T_F32             
	_muIQLOopki0 = 2042,                    // #2042  T_F32             
	_muIQLOopki1 = 2043,                    // #2043  T_F32             
	_muIQLOopOUT0 = 2044,                   // #2044  T_F32             
	_muIQLOopOUT1 = 2045,                   // #2045  T_F32             
	_muC2000wareVERsion0 = 2046,            // #2046  T_U32             
	_muC2000wareVERsion1 = 2047,            // #2047  T_U32             
	_muSYSconfigVERsion0 = 2048,            // #2048  T_U32             
	_muSYSconfigVERsion1 = 2049,            // #2049  T_U32             
	_muSOFtwareversion0 = 2050,             // #2050  T_U32             
	_muSOFtwareversion1 = 2051,             // #2051  T_U32             
    _end_of_2000_id = 30
};

typedef union { 
    uint16_t u16MbusData[52];
    struct { 
		uint16_t u16SYStemSTAtus;
		uint16_t u16CONtrolREGister;
		uint16_t u16FAUltSTAtus;
		uint16_t u16ENABlePFCPWM;
		int16_t s16VREf;
		int16_t s16VRMs;
		float32_t f32PHAseSEQuence;
		uint16_t u16DACSELcet;
		uint16_t u16PERiod;
		float32_t f32ADCLPFVIN1;
		float32_t f32ADCLPFVIN2;
		float32_t f32ADCLPFVIN3;
		float32_t f32ADCLPFVPFc;
		float32_t f32ADCLPFIIN1;
		float32_t f32ADCLPFIIN2;
		float32_t f32ADCLPFIIN3;
		uint32_t u32BURstCOUnt;
		float32_t f32VBUsOUT;
		float32_t f32VLOopkp;
		float32_t f32VLOopki;
		float32_t f32VLOopOUT;
		float32_t f32IDLOopkp;
		float32_t f32IDLOopki;
		float32_t f32IDLOopOUT;
		float32_t f32IQLOopkp;
		float32_t f32IQLOopki;
		float32_t f32IQLOopOUT;
		uint32_t u32C2000wareVERsion;
		uint32_t u32SYSconfigVERsion;
		uint32_t u32SOFtwareversion;
    }; 
} REG_MBUSDATA;
extern REG_MBUSDATA regMbusData;
extern int chkValidAddress(uint16_t addr);
extern uint16_t getModbusData(uint16_t addr);
extern uint16_t setModbusData(uint16_t addr, uint16_t data);




#endif /* MBCMD_H_ */

