/*
 *  File Name: linkVariables.c
 *
 *  Created on: 10/6/2023
 *  Author: POWER2-54FD92
 */

#include "ModbusCommon.h"
#include "ModbusSlave.h"


void initRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	sDrv.sVref.f32Target = 0; 
	sCLA.sLoopV.f32Kp = 0.5235; 
	sCLA.sLoopV.f32Ki = 0.0001227; 
	sCLA.sLoopId.f32Kp = 0.647; 
	sCLA.sLoopId.f32Ki = 0.00129557; 
	sCLA.sLoopIq.f32Kp = 0.647; 
	sCLA.sLoopIq.f32Ki = 0.00129557; 
	p->pReg->u32C2000wareVERsion = 403; 
	p->pReg->u32SYSconfigVERsion = 116; 
	p->pReg->u32SOFtwareversion = 10061526; 
}

void readRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	p->pReg->u16SYStemSTAtus = sCLA.fgStatus; 
	p->pReg->u16CONtrolREGister = sCLA.sPWM.u16CtrlReg; 
	p->pReg->u16FAUltSTAtus = sCLA.fgError; 
	p->pReg->u16ENABlePFCPWM = sDrv.blEnablePfcPwm; 
	p->pReg->s16VREf = MB_SFtoQ15(sDrv.sVref.f32Target); 
	p->pReg->s16VRMs = MB_SFtoQ15(sDrv.sVrms.f32Rms); 
	p->pReg->f32PHAseSEQuence = sCLA.f32PhaseSeq; 
	p->pReg->u16DACSELcet = sDrv.u16DACSelect; 
	p->pReg->u16PERiod = sDrv.sPLL1.u16PeriodOut; 
	p->pReg->f32ADCLPFVIN1 = sDrv.f32Vin1; 
	p->pReg->f32ADCLPFVIN2 = sDrv.f32Vin2; 
	p->pReg->f32ADCLPFVIN3 = sDrv.f32Vin3; 
	p->pReg->f32ADCLPFVPFc = sDrv.f32Vout; 
	p->pReg->f32ADCLPFIIN1 = sDrv.f32Iin1; 
	p->pReg->f32ADCLPFIIN2 = sDrv.f32Iin2; 
	p->pReg->f32ADCLPFIIN3 = sDrv.f32Iin3; 
	p->pReg->u32BURstCOUnt = sCLA.u32BurstCnt; 
	p->pReg->f32VBUsOUT = sDrv.sVref.f32Out; 
	p->pReg->f32VLOopkp = sCLA.sLoopV.f32Kp; 
	p->pReg->f32VLOopki = sCLA.sLoopV.f32Ki; 
	p->pReg->f32VLOopOUT = sCLA.sLoopV.f32Out; 
	p->pReg->f32IDLOopkp = sCLA.sLoopId.f32Kp; 
	p->pReg->f32IDLOopki = sCLA.sLoopId.f32Ki; 
	p->pReg->f32IDLOopOUT = sCLA.sLoopId.f32Out; 
	p->pReg->f32IQLOopkp = sCLA.sLoopIq.f32Kp; 
	p->pReg->f32IQLOopki = sCLA.sLoopIq.f32Ki; 
	p->pReg->f32IQLOopOUT = sCLA.sLoopIq.f32Out; 
}

void writeReg(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	switch(p->info.rwfrom) {
	case _muSYStemSTAtus :   sCLA.fgStatus = p->pReg->u16SYStemSTAtus; break;
	case _muCONtrolREGister :   sCLA.sPWM.u16CtrlReg = p->pReg->u16CONtrolREGister; break;
	case _muFAUltSTAtus :   sCLA.fgError = p->pReg->u16FAUltSTAtus; break;
	case _muENABlePFCPWM :   sDrv.blEnablePfcPwm = p->pReg->u16ENABlePFCPWM; break;
	case _muVREf :   sDrv.sVref.f32Target = MB_Q15toSF(p->pReg->s16VREf); break;
	case _muVRMs :   sDrv.sVrms.f32Rms = MB_Q15toSF(p->pReg->s16VRMs); break;
	case _muPHAseSEQuence0 :   sCLA.f32PhaseSeq = p->pReg->f32PHAseSEQuence; break;
	case _muDACSELcet :   sDrv.u16DACSelect = p->pReg->u16DACSELcet; break;
	case _muPERiod :   sDrv.sPLL1.u16PeriodOut = p->pReg->u16PERiod; break;
	case _muADCLPFVIN10 :   sDrv.f32Vin1 = p->pReg->f32ADCLPFVIN1; break;
	case _muADCLPFVIN20 :   sDrv.f32Vin2 = p->pReg->f32ADCLPFVIN2; break;
	case _muADCLPFVIN30 :   sDrv.f32Vin3 = p->pReg->f32ADCLPFVIN3; break;
	case _muADCLPFVPFc0 :   sDrv.f32Vout = p->pReg->f32ADCLPFVPFc; break;
	case _muADCLPFIIN10 :   sDrv.f32Iin1 = p->pReg->f32ADCLPFIIN1; break;
	case _muADCLPFIIN20 :   sDrv.f32Iin2 = p->pReg->f32ADCLPFIIN2; break;
	case _muADCLPFIIN30 :   sDrv.f32Iin3 = p->pReg->f32ADCLPFIIN3; break;
	case _muBURstCOUnt0 :   sCLA.u32BurstCnt = p->pReg->u32BURstCOUnt; break;
	case _muVBUsOUT0 :   sDrv.sVref.f32Out = p->pReg->f32VBUsOUT; break;
	case _muVLOopkp0 :   sCLA.sLoopV.f32Kp = p->pReg->f32VLOopkp; break;
	case _muVLOopki0 :   sCLA.sLoopV.f32Ki = p->pReg->f32VLOopki; break;
	case _muVLOopOUT0 :   sCLA.sLoopV.f32Out = p->pReg->f32VLOopOUT; break;
	case _muIDLOopkp0 :   sCLA.sLoopId.f32Kp = p->pReg->f32IDLOopkp; break;
	case _muIDLOopki0 :   sCLA.sLoopId.f32Ki = p->pReg->f32IDLOopki; break;
	case _muIDLOopOUT0 :   sCLA.sLoopId.f32Out = p->pReg->f32IDLOopOUT; break;
	case _muIQLOopkp0 :   sCLA.sLoopIq.f32Kp = p->pReg->f32IQLOopkp; break;
	case _muIQLOopki0 :   sCLA.sLoopIq.f32Ki = p->pReg->f32IQLOopki; break;
	case _muIQLOopOUT0 :   sCLA.sLoopIq.f32Out = p->pReg->f32IQLOopOUT; break;
	default:
	    break;
	}
}

void writeRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	sCLA.fgStatus = p->pReg->u16SYStemSTAtus; 
	sCLA.sPWM.u16CtrlReg = p->pReg->u16CONtrolREGister; 
	sCLA.fgError = p->pReg->u16FAUltSTAtus; 
	sDrv.blEnablePfcPwm = p->pReg->u16ENABlePFCPWM; 
	sDrv.sVref.f32Target = MB_Q15toSF(p->pReg->s16VREf); 
	sDrv.sVrms.f32Rms = MB_Q15toSF(p->pReg->s16VRMs); 
	sCLA.f32PhaseSeq = p->pReg->f32PHAseSEQuence; 
	sDrv.u16DACSelect = p->pReg->u16DACSELcet; 
	sDrv.sPLL1.u16PeriodOut = p->pReg->u16PERiod; 
	sDrv.f32Vin1 = p->pReg->f32ADCLPFVIN1; 
	sDrv.f32Vin2 = p->pReg->f32ADCLPFVIN2; 
	sDrv.f32Vin3 = p->pReg->f32ADCLPFVIN3; 
	sDrv.f32Vout = p->pReg->f32ADCLPFVPFc; 
	sDrv.f32Iin1 = p->pReg->f32ADCLPFIIN1; 
	sDrv.f32Iin2 = p->pReg->f32ADCLPFIIN2; 
	sDrv.f32Iin3 = p->pReg->f32ADCLPFIIN3; 
	sCLA.u32BurstCnt = p->pReg->u32BURstCOUnt; 
	sDrv.sVref.f32Out = p->pReg->f32VBUsOUT; 
	sCLA.sLoopV.f32Kp = p->pReg->f32VLOopkp; 
	sCLA.sLoopV.f32Ki = p->pReg->f32VLOopki; 
	sCLA.sLoopV.f32Out = p->pReg->f32VLOopOUT; 
	sCLA.sLoopId.f32Kp = p->pReg->f32IDLOopkp; 
	sCLA.sLoopId.f32Ki = p->pReg->f32IDLOopki; 
	sCLA.sLoopId.f32Out = p->pReg->f32IDLOopOUT; 
	sCLA.sLoopIq.f32Kp = p->pReg->f32IQLOopkp; 
	sCLA.sLoopIq.f32Ki = p->pReg->f32IQLOopki; 
	sCLA.sLoopIq.f32Out = p->pReg->f32IQLOopOUT; 
}

