/*
 * isr.c
 *
 *  Created on: 2022�~3��15��
 *      Author: cody_chen
 */

#include <math.h>
#include "common.h"
#include "cla_task.h"


#define _TEST_FORCE_OUTPUT_PWM    1

#ifdef _FLASH
#pragma SET_CODE_SECTION(".TI.ramfunc")
#endif //_FLASH


__interrupt void INT_PWM_ADCA_1_ISR (void) //7.55usec_now  // max7.15usec_1014
{
    if(FG_GETCLA(_CLA_TASK1_OK)) {
        GPIO_writePin(14, 1);


        FG_SETCLA(_CLA_PWMADC_OK);
    }

    //
    // Clear the interrupt flag
    ADC_clearInterruptStatus(PWM_ADCA_BASE, ADC_INT_NUMBER1);

    // Acknowledge the interrupt
    Interrupt_clearACKGroup(INT_PWM_ADCA_1_INTERRUPT_ACK_GROUP);


//    GPIO_writePin(33, 0);
    GPIO_writePin(14, 0);
}

#ifdef _FLASH
#pragma SET_CODE_SECTION()
#endif //_FLASH

