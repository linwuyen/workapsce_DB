/*
 * CTYPEDEF.h
 *
 *  Created on: 2022�~3��22��
 *      Author: cody_chen
 *
 */

#ifndef CTYPEDEF_H_
#define CTYPEDEF_H_

#include <stdbool.h>
#include <stdint.h>
#include "driver_inclusive_terminology_mapping.h"
#include "inc/hw_memcfg.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"

#ifndef bool_t
typedef bool bool_t;
#endif

#ifndef true
#define true  ((bool_t)1)
#endif

#ifndef false
#define false ((bool_t)0)
#endif

#define _2PI()                           6.283185f

typedef struct {
    float32_t f32Gain;
    float32_t f32Offset;
    float32_t f32Out;
    float32_t  f32Base;
    float32_t  f32Real;
}  ST_CAL;
typedef ST_CAL * HAL_CAL;

typedef struct {
    float32_t f32Now;
    float32_t f32K1;  //f32k1 = 1.0F / (1.0F + ((2PI() * fc) / sample_rate_hz));
    float32_t f32Out;
}   ST_LPF;
typedef ST_LPF * HAL_LPF;


typedef struct {
    float32_t f32Now;
    float32_t f32K1;
    float32_t f32Out;
}    ST_IIR;
typedef ST_IIR * HAL_IIR;

typedef struct {
    float32_t  f32Out;           // Output: controller output
    float32_t  f32Max;           // Parameter: Limit the controller output by Maximum
    float32_t  f32Min;           // Parameter: Limit the controller output by Minimum
    float32_t  f32Kp;            // Parameter: proportional loop gain
    float32_t  f32Ki;            // Parameter: integral gain (0.0~1.0)
    float32_t  f32Err;           // Data: (f32) Error between the feedback and reference
    float32_t  f32LimitErr;      // Data: (f32) Limit f32Err
    float32_t  f32Pdata;         // Data: (f32) Save the proportional term results
    float32_t  f32Idata;         // Data: (f32) Save the integral term
    float32_t  f32Itemp;         // Data: (F32) Temporarily save the integral term i(k-1)
    float32_t  f32Sum;           // Data: Sum of proportional term and integral term
    uint16_t   u16StopUi;        // Parameter: Used to stop the integral term.
}   ST_PI;
typedef ST_PI * HAL_PI;

typedef struct {
    float32_t f32Alpha;
    float32_t f32Beta;
} ST_CLARKE;
typedef ST_CLARKE * HAL_CLARKE;


typedef struct {
    float32_t f32sin;
    float32_t f32cos;
    float32_t f32D;
    float32_t f32Q;
} ST_PARK;
typedef ST_PARK * HAL_PARK;



typedef struct {
    float32_t f32sin;
    float32_t f32cos;
    float32_t f32D;
    float32_t f32Q;
    float32_t f32Alpha;
    float32_t f32Beta;
} ST_IPARK;
typedef ST_IPARK * HAL_IPARK;


typedef struct {
    float32_t f32TempSv1;
    float32_t f32TempSv2;

    float32_t f32Ta;
    float32_t f32Tb;
    float32_t f32Tc;
} ST_iCLARKE;
typedef ST_iCLARKE * HAL_iCLARKE;


typedef struct {
    float32_t f32Tmp1;
    float32_t f32Tmp2;
    float32_t f32Tmp3;


    float32_t f32Ta;
    float32_t f32Tb;
    float32_t f32Tc;
    uint16_t u16VecSector;
} ST_SVPWM;
typedef ST_SVPWM * HAL_SVPWM;


typedef struct {
    float32_t f32Tmp1;
    float32_t f32Tmp2;
    float32_t f32Tmp3;
    float32_t f32MIN;
    float32_t f32MAX;
    float32_t f32SUMMIN;
    float32_t f32SUMMAX;
    float32_t f32ABSMIN;
    float32_t f32ABSMAX;
    float32_t f32COMP;
    float32_t f32MUX;


    float32_t f32Ta;
    float32_t f32Tb;
    float32_t f32Tc;
} ST_DPWM1;
typedef ST_DPWM1 * HAL_DPWM1;


typedef struct {    float32_t    f32Target;     // Input: Target input (pu)
                    float32_t    f32Step;       // Parameter: Increase/Decrease Step (pu)
                    float32_t    f32LowLimit;   // Parameter: Minimum limit (pu)
                    float32_t    f32HighLimit;  // Parameter: Maximum limit (pu)
                    float32_t    f32Out;     // Output: Target output (pu)
}  ST_RAMPCTRL;
typedef ST_RAMPCTRL * HAL_RAMPCTRL;


typedef struct {     float32_t    f32Target1;     // Input: Target input (pu)
                     float32_t    f32Target2;     // Input: Target input (pu)
                     float32_t    f32Step1;
                     float32_t    f32Step2;
                     float32_t    f32Error;
                     float32_t    f32LowLimit;   // Parameter: Minimum limit (pu)
                     float32_t    f32HighLimit;  // Parameter: Maximum limit (pu)
                     float32_t    f32Out;     // Output: Target output (pu)
                     bool_t       blCountMode;
}  ST_RAMPUPDN;
typedef ST_RAMPUPDN * HAL_RAMPUPDN;

typedef struct { float32_t    f32Target;     // Input: Target input (pu)
                 float32_t    f32Step;       // Parameter: Increase/Decrease Step (pu)
                 float32_t    f32LowLimit;   // Parameter: Minimum limit (pu)
                 float32_t    f32HighLimit;  // Parameter: Maximum limit (pu)
                 float32_t    f32Out;     // Output: Target output (pu)
} ST_SAWTOOTH;
typedef ST_SAWTOOTH * HAL_SAWTOOTH;


typedef struct {
    float32_t *pf32Buf;
    float32_t f32Scale;
    float32_t f32Sum;
    float32_t f32Avg;
    float32_t f32Now;
    uint16_t  u16Index;
    uint16_t  u16MemSize;
    uint16_t  u16Cycle;
    uint16_t  u16CycleIndex;
}ST_MVFIR;
typedef ST_MVFIR * HAL_MVFIR;

typedef struct {
    float32_t f32Adc;      // Input range must be -1pu to +1pu.
    float32_t f32PureWave;
    float32_t f32AbsPureWave;
    float32_t f32avg;
    float32_t f32Offset;   // Default: 0.0f
    float32_t f32Theta;
    float32_t f32ThetaOrig;
    float32_t f32PhaseShift;
    float32_t f32ShiftOut;
    float32_t f32PeriodScale;
    bool_t    blPolar;
    bool_t    blPolarTemp;
    bool_t    blGridCycle;
    uint16_t  u16ZCD;
    uint16_t  u16Debunce;   // The sample rate of the PLL is multiplied by the filter time.
    uint16_t  u16DebunceCnt;
    uint16_t  u16PeriodOut;
    uint16_t  u16HalfPeriodOut;
    uint16_t  u16PeriodTimeout;
    uint16_t  u16PeriodCnt;
    uint16_t  u16PreviousCnt;
    uint16_t  u16PhaseCnt;
} ST_PLL;
typedef ST_PLL * HAL_PLL;

typedef struct {
       float32_t f32Theta;       // Input: Electrical angle (pu)
       float32_t f32OldTheta;    // History: Electrical angle at previous step (pu)
       float32_t f32ThetaError;
       float32_t f32TempFreq;
       float32_t f32FreqOut;     // Output: Freq in per-unit  (pu)
       float32_t f32FreqBase;    // Parameter: Base freq in hz

       float32_t f32SampleRate;  // Parameter: Sample Rate in (khz)
       float32_t K1;             // Parameter: Constant for differentiator
       float32_t K2;             // Parameter: Constant for low-pass filter (pu)
       float32_t K3;             // Parameter: Constant for low-pass filter (pu)
       float32_t f32FreqHz;      // Output : Speed in hz.
} ST_FREQ;
typedef ST_FREQ *HAL_FREQ;

typedef struct {
    float32_t f32Sum;  //+= 1.11 * abs( VAC )
    float32_t f32Rms;
    float32_t f32Now;
    float32_t f32Last;
    uint16_t  u16HalfPeriodCnt;  // must be bigger than ZERO.
    uint16_t  u16Enable;
} ST_RMS;
typedef ST_RMS * HAL_RMS;

typedef struct {
    uint32_t  u32PwmBase;
    uint16_t  u16CtrlReg;
    uint16_t  u16NA;
    float32_t f32InputRms;
    float32_t f32BrownIn;
    float32_t f32BrownOut;
    uint16_t  u16ZCD;
    uint16_t  u16DutyA;
    uint16_t  u16DutyB;
    uint16_t  u16DutyC;
} ST_PWM;


typedef ST_PWM * HAL_PWM;

enum {
    _NO_ACTION_FOR_PWM     = (0x0000U),
    _ENABLE_PWM            = (0x0001U << 0),
    _GET_BROWN_IN          = (0x0001U << 1),
    _GET_A_ZCD             = (0x0001U << 2),
    _MOVING_ON             = (0x0001U << 3),
    _GET_MOVING_READY      = (0x0001U << 4),
    _ENABLE_BURST_MODE     = (0x0001U << 5),
    _ENABLE_RELAY          = (0x0001U << 6),
    _OUTPUT_PWM_ALREADY    = (_GET_A_ZCD|_GET_BROWN_IN|_ENABLE_PWM|_GET_MOVING_READY|_ENABLE_RELAY),
    _ALL_PWM_STATUS        = (_GET_A_ZCD|_GET_BROWN_IN|_ENABLE_PWM|_MOVING_ON|_ENABLE_BURST_MODE|_GET_MOVING_READY|_ENABLE_RELAY),
    _UNDEFINE_PWM_ACTION   = (0x0001U << 15)
};

#define FG_GET(x, src)   ((src & (x)) == (x)) //((src & (x)) == (x))
#define FG_GETn(x, src)  (!FG_GET(x, src)) //!((src & (x)) == (x))
#define FG_AND(x, src)   (src & (x))
#define FG_SET(x, src)   {src |= (x);}
#define FG_RST(x, src)   {src &= ~(x);}

#define UPDATE_PARK_BY_C28          1


#endif /* CTYPEDEF_H_ */
