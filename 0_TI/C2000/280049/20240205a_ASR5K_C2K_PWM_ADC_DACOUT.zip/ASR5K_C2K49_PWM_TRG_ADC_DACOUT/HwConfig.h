/*
 * HwConfig.h
 *
 *  Created on: 2022�~4��20��
 *      Author: cody_chen
 */

#ifndef HWCONFIG_H_
#define HWCONFIG_H_

#define OSCSRC_FREQ                      10000000  //DEVICE_OSCSRC_FREQ

#define EPWMCLK_FREQ                     ((OSCSRC_FREQ * 20 * 1) / 2)

#define PFC_PWM_KHZ                      100UL    // (kHz)
#define CNT_PFC_PWM                      (uint16_t)(((uint32_t)EPWMCLK_FREQ/1000/PFC_PWM_KHZ)>>1)
#define CNT_PFC_HALF_PWM                 (CNT_PFC_PWM>>1)

#define SET_RED(base, red)               HWREGH(base + EPWM_O_DBRED) = red;
#define SET_FED(base, fed)               HWREGH(base + EPWM_O_DBFED) = fed;
#define SET_CMPA(base, cmp)              HWREGH(base + EPWM_O_CMPA + 0x1U) = cmp;

#define DISABLE_PWM(base)                SET_FED(base, CNT_PFC_PWM); \
                                         SET_RED(base, CNT_PFC_PWM); \
                                         SET_CMPA(base, CNT_PFC_PWM>>1);

#define DAC_U16(u16value, base)          DAC_setShadowValue(base, u16value);
#define DAC_UPU(f32value, base)          DAC_setShadowValue(base, (uint16_t)(4095.0f * f32value));
#define DAC_SPU(f32value, base)          DAC_setShadowValue(base, (uint16_t)(4095.0f * ((f32value*0.5f)+0.5f)));
#define DAC_ABS(f32value, base)          DAC_setShadowValue(base, (uint16_t)(4095.0f * f32value *(0.0 <= f32value? 1.0f: -1.0f)));




#endif /* HWCONFIG_H_ */
