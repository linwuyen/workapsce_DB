/*
 * common.h
 *
 *  Created on: 2022�~3��9��
 *      Author: cody_chen
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "ctypedef.h"

#include <math.h>
#include <limits.h>
#include "driverlib.h"

#include "board.h"
#include "HwConfig.h"

#define SW_TIMER        50000000

#define T_500US         (SW_TIMER/2000)
#define T_1MS           (SW_TIMER/1000)
#define T_2D5MS         (SW_TIMER/400)
#define T_5MS           (SW_TIMER/200)
#define T_10MS          (SW_TIMER/100)
#define T_20MS          (SW_TIMER/50)
#define T_25MS          (SW_TIMER/40)
#define T_50MS          (SW_TIMER/20)
#define T_100MS         (SW_TIMER/10)
#define T_200MS         (SW_TIMER/5)
#define T_500MS         (SW_TIMER/2)
#define T_1S            (SW_TIMER/1)


#define BLUE_LED_TOGGLE   GPIO_togglePin(D10_BLUE_LED);

#include "cpfc.h"
#include "cmath.h"

enum {
    _DAC_NO_ACTION = 0x0000,
    _DAC_PFC_DUTYA = (0x0001<<0),
    _DAC_PFC_DUTYB = (0x0001<<1),
    _DAC_PFC_DUTYC = (0x0001<<2),
    _DAC_VAR3 = (0x0001<<3),
    _DAC_VAR4 = (0x0001<<4),
    _DAC_VAR5 = (0x0001<<5),
    _DAC_VAR6 = (0x0001<<6),
    _DAC_VAR7 = (0x0001<<7),
    _DAC_VAR8 = (0x0001<<8),
    _DAC_VAR9 = (0x0001<<9),
    _DAC_VAR10 = (0x0001<<10),
    _DAC_VAR11 = (0x0001<<11),
    _DAC_VAR12 = (0x0001<<12),
    _DAC_VAR13 = (0x0001<<13),
    _DAC_VAR14 = (0x0001<<14),
    _DAC_VAR15 = 0x8000
};

typedef uint16_t REG_DACEV;



typedef struct {
    ST_PLL      sPLL1;
    ST_PLL      sPLL2;
    ST_PLL      sPLL3;
    ST_FREQ     sFreq;
    ST_RAMPCTRL sVref;
    ST_RAMPCTRL sVrefA;

    ST_CLARKE  sClarkeV;
    ST_PARK    sParkV;


    ST_RMS      sVrms;

    float32_t f32VbusBuf[512];
    ST_MVFIR  sVbus;

    float32_t f32MVVrmsBuf[512];
    ST_MVFIR  sMVVrms;

    uint16_t  fgDrv;
    uint16_t  fgFault;

    ST_SAWTOOTH sTheta;


    float32_t f32PfcDutyA;
    float32_t f32PfcDutyB;
    float32_t f32PfcDutyC;
    bool_t    blEnablePfcPwm;
    uint16_t  u16RelayDlyCnt;
    bool_t    blEnableAcRelay;

    uint16_t  u16ScanVin;
    float32_t f32Targetinit;
    REG_DACEV u16DACSelect;
    uint16_t u16DACselect1;
    float32_t f32Vin1;
    float32_t f32Vin2;
    float32_t f32Vin3;
    float32_t f32Vout;
    float32_t f32Iin1;
    float32_t f32Iin2;
    float32_t f32Iin3;
    float32_t f32Vinrms;
    float32_t f32Iin2Err;
    float32_t f32Iin2Target;
    float32_t f32Vin1Seq;
    float32_t f32Vin2Seq;
    float32_t f32Vin3Seq;
    uint16_t u16Iin2ErrCnt;
    uint16_t u16ACRlyDlyCnt;
    uint16_t u16TestA;
    uint16_t u16TestB;
    uint16_t u16TestC;
    uint16_t u16TestD;
    uint16_t u16TestE;
    uint16_t u16TestF;
    uint16_t u16TestG;
    uint16_t u16TestH;

}  ST_DRV;

typedef ST_DRV* HAL_DRV;

extern volatile ST_DRV sDrv;



#include "linkPeripheral.h"

#endif /* COMMON_H_ */
