/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************

//
// EPWM1 -> DRIVER_A Pinmux
//
//
// EPWM1_A - GPIO Settings
//
#define GPIO_PIN_EPWM1_A 0
#define DRIVER_A_EPWMA_GPIO 0
#define DRIVER_A_EPWMA_PIN_CONFIG GPIO_0_EPWM1_A
//
// EPWM1_B - GPIO Settings
//
#define GPIO_PIN_EPWM1_B 1
#define DRIVER_A_EPWMB_GPIO 1
#define DRIVER_A_EPWMB_PIN_CONFIG GPIO_1_EPWM1_B

//
// EPWM2 -> DRIVER_B Pinmux
//
//
// EPWM2_A - GPIO Settings
//
#define GPIO_PIN_EPWM2_A 2
#define DRIVER_B_EPWMA_GPIO 2
#define DRIVER_B_EPWMA_PIN_CONFIG GPIO_2_EPWM2_A
//
// EPWM2_B - GPIO Settings
//
#define GPIO_PIN_EPWM2_B 3
#define DRIVER_B_EPWMB_GPIO 3
#define DRIVER_B_EPWMB_PIN_CONFIG GPIO_3_EPWM2_B

//
// EPWM3 -> DRIVER_C Pinmux
//
//
// EPWM3_A - GPIO Settings
//
#define GPIO_PIN_EPWM3_A 4
#define DRIVER_C_EPWMA_GPIO 4
#define DRIVER_C_EPWMA_PIN_CONFIG GPIO_4_EPWM3_A
//
// EPWM3_B - GPIO Settings
//
#define GPIO_PIN_EPWM3_B 5
#define DRIVER_C_EPWMB_GPIO 5
#define DRIVER_C_EPWMB_PIN_CONFIG GPIO_5_EPWM3_B

//
// EPWM7 -> FAN1 Pinmux
//
//
// EPWM7_A - GPIO Settings
//
#define GPIO_PIN_EPWM7_A 12
#define FAN1_EPWMA_GPIO 12
#define FAN1_EPWMA_PIN_CONFIG GPIO_12_EPWM7_A

//
// EPWM7 -> FAN2 Pinmux
//
//
// EPWM7_B - GPIO Settings
//
#define GPIO_PIN_EPWM7_B 13
#define FAN2_EPWMB_GPIO 13
#define FAN2_EPWMB_PIN_CONFIG GPIO_13_EPWM7_B

//
// EPWM6 -> FAN3 Pinmux
//
//
// EPWM6_B - GPIO Settings
//
#define GPIO_PIN_EPWM6_B 11
#define FAN3_EPWMB_GPIO 11
#define FAN3_EPWMB_PIN_CONFIG GPIO_11_EPWM6_B
//
// GPIO14 - GPIO Settings
//
#define C28_IO_GPIO_PIN_CONFIG GPIO_14_GPIO14
//
// GPIO15 - GPIO Settings
//
#define CLA_IO_GPIO_PIN_CONFIG GPIO_15_GPIO15

//
// SCIA -> DEBUG_SCI Pinmux
//
//
// SCIA_RX - GPIO Settings
//
#define GPIO_PIN_SCIA_RX 28
#define DEBUG_SCI_SCIRX_GPIO 28
#define DEBUG_SCI_SCIRX_PIN_CONFIG GPIO_28_SCIA_RX
//
// SCIA_TX - GPIO Settings
//
#define GPIO_PIN_SCIA_TX 29
#define DEBUG_SCI_SCITX_GPIO 29
#define DEBUG_SCI_SCITX_PIN_CONFIG GPIO_29_SCIA_TX

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
#define PWM_ADCA_BASE ADCA_BASE
#define PWM_ADCA_RESULT_BASE ADCARESULT_BASE
#define PWM_ADCA_SOC0 ADC_SOC_NUMBER0
#define PWM_ADCA_FORCE_SOC0 ADC_FORCE_SOC0
#define PWM_ADCA_SAMPLE_WINDOW_SOC0 120
#define PWM_ADCA_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCA_CHANNEL_SOC0 ADC_CH_ADCIN2
#define PWM_ADCA_SOC1 ADC_SOC_NUMBER1
#define PWM_ADCA_FORCE_SOC1 ADC_FORCE_SOC1
#define PWM_ADCA_SAMPLE_WINDOW_SOC1 120
#define PWM_ADCA_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCA_CHANNEL_SOC1 ADC_CH_ADCIN8
#define PWM_ADCA_SOC2 ADC_SOC_NUMBER2
#define PWM_ADCA_FORCE_SOC2 ADC_FORCE_SOC2
#define PWM_ADCA_SAMPLE_WINDOW_SOC2 120
#define PWM_ADCA_TRIGGER_SOURCE_SOC2 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCA_CHANNEL_SOC2 ADC_CH_ADCIN9
#define PWM_ADCA_SOC3 ADC_SOC_NUMBER3
#define PWM_ADCA_FORCE_SOC3 ADC_FORCE_SOC3
#define PWM_ADCA_SAMPLE_WINDOW_SOC3 120
#define PWM_ADCA_TRIGGER_SOURCE_SOC3 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCA_CHANNEL_SOC3 ADC_CH_ADCIN6
void PWM_ADCA_init();

#define PWM_ADCB_BASE ADCB_BASE
#define PWM_ADCB_RESULT_BASE ADCBRESULT_BASE
#define PWM_ADCB_SOC0 ADC_SOC_NUMBER0
#define PWM_ADCB_FORCE_SOC0 ADC_FORCE_SOC0
#define PWM_ADCB_SAMPLE_WINDOW_SOC0 120
#define PWM_ADCB_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCB_CHANNEL_SOC0 ADC_CH_ADCIN2
#define PWM_ADCB_SOC1 ADC_SOC_NUMBER1
#define PWM_ADCB_FORCE_SOC1 ADC_FORCE_SOC1
#define PWM_ADCB_SAMPLE_WINDOW_SOC1 120
#define PWM_ADCB_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCB_CHANNEL_SOC1 ADC_CH_ADCIN4
#define PWM_ADCB_SOC2 ADC_SOC_NUMBER2
#define PWM_ADCB_FORCE_SOC2 ADC_FORCE_SOC2
#define PWM_ADCB_SAMPLE_WINDOW_SOC2 120
#define PWM_ADCB_TRIGGER_SOURCE_SOC2 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCB_CHANNEL_SOC2 ADC_CH_ADCIN1
#define PWM_ADCB_SOC3 ADC_SOC_NUMBER3
#define PWM_ADCB_FORCE_SOC3 ADC_FORCE_SOC3
#define PWM_ADCB_SAMPLE_WINDOW_SOC3 120
#define PWM_ADCB_TRIGGER_SOURCE_SOC3 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCB_CHANNEL_SOC3 ADC_CH_ADCIN8
void PWM_ADCB_init();

#define PWM_ADCC_BASE ADCC_BASE
#define PWM_ADCC_RESULT_BASE ADCCRESULT_BASE
#define PWM_ADCC_SOC0 ADC_SOC_NUMBER0
#define PWM_ADCC_FORCE_SOC0 ADC_FORCE_SOC0
#define PWM_ADCC_SAMPLE_WINDOW_SOC0 120
#define PWM_ADCC_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCC_CHANNEL_SOC0 ADC_CH_ADCIN4
#define PWM_ADCC_SOC1 ADC_SOC_NUMBER1
#define PWM_ADCC_FORCE_SOC1 ADC_FORCE_SOC1
#define PWM_ADCC_SAMPLE_WINDOW_SOC1 120
#define PWM_ADCC_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCC_CHANNEL_SOC1 ADC_CH_ADCIN1
#define PWM_ADCC_SOC2 ADC_SOC_NUMBER2
#define PWM_ADCC_FORCE_SOC2 ADC_FORCE_SOC2
#define PWM_ADCC_SAMPLE_WINDOW_SOC2 120
#define PWM_ADCC_TRIGGER_SOURCE_SOC2 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCC_CHANNEL_SOC2 ADC_CH_ADCIN10
#define PWM_ADCC_SOC3 ADC_SOC_NUMBER3
#define PWM_ADCC_FORCE_SOC3 ADC_FORCE_SOC3
#define PWM_ADCC_SAMPLE_WINDOW_SOC3 120
#define PWM_ADCC_TRIGGER_SOURCE_SOC3 ADC_TRIGGER_EPWM1_SOCA
#define PWM_ADCC_CHANNEL_SOC3 ADC_CH_ADCIN3
void PWM_ADCC_init();


//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
#define SWTIRMER_BASE CPUTIMER2_BASE
void SWTIRMER_init();

//*****************************************************************************
//
// DAC Configurations
//
//*****************************************************************************
#define DAC1_BASE DACA_BASE
void DAC1_init();
#define DAC2_BASE DACB_BASE
void DAC2_init();

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define DRIVER_A_BASE EPWM1_BASE
#define DRIVER_A_TBPRD 0
#define DRIVER_A_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define DRIVER_A_TBPHS 0
#define DRIVER_A_CMPA 0
#define DRIVER_A_CMPB 0
#define DRIVER_A_CMPC 0
#define DRIVER_A_CMPD 0
#define DRIVER_A_DBRED 0
#define DRIVER_A_DBFED 0
#define DRIVER_A_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define DRIVER_A_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define DRIVER_A_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define DRIVER_B_BASE EPWM2_BASE
#define DRIVER_B_TBPRD 0
#define DRIVER_B_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define DRIVER_B_TBPHS 0
#define DRIVER_B_CMPA 0
#define DRIVER_B_CMPB 0
#define DRIVER_B_CMPC 0
#define DRIVER_B_CMPD 0
#define DRIVER_B_DBRED 0
#define DRIVER_B_DBFED 0
#define DRIVER_B_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define DRIVER_B_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define DRIVER_B_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define DRIVER_C_BASE EPWM3_BASE
#define DRIVER_C_TBPRD 0
#define DRIVER_C_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define DRIVER_C_TBPHS 0
#define DRIVER_C_CMPA 0
#define DRIVER_C_CMPB 0
#define DRIVER_C_CMPC 0
#define DRIVER_C_CMPD 0
#define DRIVER_C_DBRED 0
#define DRIVER_C_DBFED 0
#define DRIVER_C_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define DRIVER_C_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define DRIVER_C_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define FAN1_BASE EPWM7_BASE
#define FAN1_TBPRD 0
#define FAN1_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define FAN1_TBPHS 0
#define FAN1_CMPA 0
#define FAN1_CMPB 0
#define FAN1_CMPC 0
#define FAN1_CMPD 0
#define FAN1_DBRED 0
#define FAN1_DBFED 0
#define FAN1_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FAN1_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FAN1_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define FAN2_BASE EPWM7_BASE
#define FAN2_TBPRD 0
#define FAN2_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define FAN2_TBPHS 0
#define FAN2_CMPA 0
#define FAN2_CMPB 0
#define FAN2_CMPC 0
#define FAN2_CMPD 0
#define FAN2_DBRED 0
#define FAN2_DBFED 0
#define FAN2_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FAN2_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FAN2_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define FAN3_BASE EPWM6_BASE
#define FAN3_TBPRD 0
#define FAN3_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define FAN3_TBPHS 0
#define FAN3_CMPA 0
#define FAN3_CMPB 0
#define FAN3_CMPC 0
#define FAN3_CMPD 0
#define FAN3_DBRED 0
#define FAN3_DBFED 0
#define FAN3_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FAN3_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FAN3_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define C28_IO 14
void C28_IO_init();
#define CLA_IO 15
void CLA_IO_init();

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************

// Interrupt Settings for INT_PWM_ADCA_1
#define INT_PWM_ADCA_1 INT_ADCA1
#define INT_PWM_ADCA_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_PWM_ADCA_1_ISR(void);

//*****************************************************************************
//
// SCI Configurations
//
//*****************************************************************************
#define DEBUG_SCI_BASE SCIA_BASE
#define DEBUG_SCI_BAUDRATE 115200
#define DEBUG_SCI_CONFIG_WLEN SCI_CONFIG_WLEN_8
#define DEBUG_SCI_CONFIG_STOP SCI_CONFIG_STOP_ONE
#define DEBUG_SCI_CONFIG_PAR SCI_CONFIG_PAR_EVEN
void DEBUG_SCI_init();

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ADC_init();
void	ASYSCTL_init();
void	CPUTIMER_init();
void	DAC_init();
void	EPWM_init();
void	GPIO_init();
void	INTERRUPT_init();
void	SCI_init();
void	SYNC_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
