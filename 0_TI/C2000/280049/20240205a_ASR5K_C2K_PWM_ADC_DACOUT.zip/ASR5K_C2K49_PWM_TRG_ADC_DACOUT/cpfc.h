/*
 * c_pfc.h
 *
 *  Created on: 2022�~4��18��
 *      Author: cody_chen
 *
 */

#ifndef CPFC_H_
#define CPFC_H_

#include "ctypedef.h"

static inline void execPLL(HAL_PLL v) //2.265usec_now
{
    //
    // Adjust f32avg to get the offset from the adc of AC Input.
    // f32Offset must be between -0.5 and 0.5.
    v->f32PureWave = (v->f32Adc - v->f32Offset);
    v->f32Offset += (v->f32avg * v->f32PureWave);

    v->f32AbsPureWave = (0.0f > v->f32PureWave? -v->f32PureWave: v->f32PureWave);

    v->u16ZCD = 0;
    v->blPolar = (v->f32Offset < v->f32Adc);
    if(v->blPolarTemp != v->blPolar) {
        v->u16DebunceCnt = 0;
        v->blPolarTemp = v->blPolar;
    }
    else if(v->u16PeriodTimeout > v->u16PeriodCnt) {
        v->u16PeriodCnt++;
        if(v->u16PhaseCnt < v->u16PeriodOut) v->u16PhaseCnt++;
        else                                 v->u16PhaseCnt=0;

        if(0 == v->u16PhaseCnt) v->u16ZCD = 1;
        if(v->u16HalfPeriodOut == v->u16PhaseCnt) v->u16ZCD = 2;

        if(v->u16DebunceCnt < v->u16Debunce) v->u16DebunceCnt++;
        else {
            if(true == v->blPolarTemp) {
                if((false == v->blGridCycle)&&(v->u16Debunce<v->u16PeriodCnt)) {
                    v->u16PeriodOut = v->u16PeriodCnt;
                    v->u16HalfPeriodOut = v->u16PeriodOut>>1;
                    v->f32PeriodScale = 1.0f/(float32_t)v->u16PeriodOut;
                    v->u16PeriodCnt = 0;
                    v->u16PhaseCnt = v->u16Debunce;
                }
            }
            v->blGridCycle = v->blPolarTemp;
        }
    }
    else {
        v->u16PeriodCnt = 0;
        v->u16PhaseCnt = v->u16Debunce;
        v->u16PeriodOut = v->u16HalfPeriodOut = 0;
        v->f32PeriodScale = 0.0f;
        v->f32Offset = 0.0f;
    }

    if(0<v->u16PeriodOut) {
        v->f32ShiftOut = (float32_t)v->u16PhaseCnt*v->f32PeriodScale + v->f32PhaseShift;
    }
    else {
        v->f32ShiftOut = 0.0f;
    }

    if(0.5f < v->f32ShiftOut) v->f32ShiftOut -= 1.0f;
    if(-0.5f > v->f32ShiftOut) v->f32ShiftOut += 1.0f;

    v->f32Theta = v->f32ShiftOut;
//    v->f32ThetaOrig = (float32_t)v->u16PhaseCnt*v->f32PeriodScale;
}

static inline void getPureWave(HAL_PLL v)
{
    //
    // Adjust f32avg to get the offset from the adc of AC Input.
    // f32Offset must be between -0.5 and 0.5.
    v->f32PureWave = (v->f32Adc - v->f32Offset);
    v->f32Offset += (v->f32avg * v->f32PureWave);
}


static inline void measFrequency(HAL_FREQ v) //360nsec_previous
{
    v->f32ThetaError = v->f32Theta - v->f32OldTheta;

    /* roll in the error */
    if (v->f32ThetaError >= 0.5f)  v->f32ThetaError -= 1.0f;
    else if (v->f32ThetaError <= -0.5f) v->f32ThetaError += 1.0f;

    /* Differentiators*/
    v->f32TempFreq = v->K1 * v->f32ThetaError;
    /* Low-pass filter*/
    v->f32TempFreq = v->K2 * v->f32FreqOut + v->K3 * v->f32TempFreq;

    if(1.0f < v->f32TempFreq) v->f32TempFreq = 1.0f;
    if(-1.0f > v->f32TempFreq) v->f32TempFreq = -1.0f;

    v->f32FreqOut = v->f32TempFreq;
    /* Update the electrical angle */
    v->f32OldTheta = v->f32Theta;
    v->f32FreqHz = v->f32FreqBase * v->f32FreqOut;
}

static inline void measRMS(HAL_RMS v) //330nsec & 770nsec_now
{
    if((v->u16Enable)&&(0<v->u16HalfPeriodCnt)) {
        v->f32Now = v->f32Sum / (float32_t) v->u16HalfPeriodCnt;
        v->f32Rms = (v->f32Now + v->f32Last) * 0.5f;
        v->f32Last = v->f32Now;
        v->f32Sum = 0.0f;
    }
    else if (0 == v->u16HalfPeriodCnt) {
        v->f32Last = v->f32Sum = v->f32Rms = 0.0f;
    }
    else {
        // Do Nothing
    }
}


#endif /* CPFC_H_ */
