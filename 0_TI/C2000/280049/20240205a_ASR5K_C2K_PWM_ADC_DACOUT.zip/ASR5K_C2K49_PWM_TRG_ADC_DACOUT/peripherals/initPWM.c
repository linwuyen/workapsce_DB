/*
 * initPWM.c
 *
 *  Created on: 2022�~3��17��
 *      Author: cody_chen
 */

#include "initPWM.h"
#include "HwConfig.h"


void initDeadbandAction(uint32_t base)
{
    //
    // Use EPWMA as the input for both RED and FED
    //
    EPWM_setRisingEdgeDeadBandDelayInput(base, EPWM_DB_INPUT_EPWMA);
    EPWM_setFallingEdgeDeadBandDelayInput(base, EPWM_DB_INPUT_EPWMA);


    //
    // INVERT the delayed outputs (AL)
    //
    EPWM_setDeadBandDelayPolarity(base, EPWM_DB_RED, EPWM_DB_POLARITY_ACTIVE_HIGH);
    EPWM_setDeadBandDelayPolarity(base, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);

    //
    // Use the delayed signals instead of the original signals
    //
    EPWM_setDeadBandDelayMode(base, EPWM_DB_RED, true);
    EPWM_setDeadBandDelayMode(base, EPWM_DB_FED, true);

    //
    // DO NOT Switch Output A with Output B
    //
    EPWM_setDeadBandOutputSwapMode(base, EPWM_DB_OUTPUT_A, false);
    EPWM_setDeadBandOutputSwapMode(base, EPWM_DB_OUTPUT_B, false);

}

void initCompPWMAB(uint32_t base)
{
    //
    // Disable the ePWM time base clock before configuring the module
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    //
    // Set the local ePWM module clock divider to /1
    EPWM_setClockPrescaler(base,
                           EPWM_CLOCK_DIVIDER_1,
                           EPWM_HSCLOCK_DIVIDER_1);

    //
    // Freeze the counter
    EPWM_setTimeBaseCounterMode(base, EPWM_COUNTER_MODE_STOP_FREEZE);

    //
    // Initializing dummy values for ePWM counter and period
    EPWM_setTimeBaseCounter(base, 0);
    EPWM_setTimeBasePeriod(base,  CNT_PFC_PWM);

    //
    // Set actions
    EPWM_setActionQualifierAction(base,
                                  EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_HIGH,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);

    EPWM_setActionQualifierAction(base,
                                  EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_LOW,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);

    EPWM_setActionQualifierAction(base,
                                  EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_HIGH,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);


    //
    // Configure the deadband of pwm of peak-current-mode.
    initDeadbandAction(base);

    DISABLE_PWM(base);

    EPWM_setTimeBaseCounterMode(base, EPWM_COUNTER_MODE_UP_DOWN);

}


void enableAdcTriggerbyPWM(uint32_t base)
{
    //
    // Disable SOCA
    //
    EPWM_disableADCTrigger(base, EPWM_SOC_A);

    //
    // Configure the SOC to occur on the first up-count event
    EPWM_setADCTriggerSource(base, EPWM_SOC_A, EPWM_SOC_TBCTR_ZERO);
    EPWM_setADCTriggerEventPrescale(base, EPWM_SOC_A, 1);

    //
    // Start ePWM1, enabling SOCA and putting the counter in up-count mode
    //
    EPWM_enableADCTrigger(base, EPWM_SOC_A);

}

void initPWM(void)
{
    // Recover EPWM function from PWM to GPIO
    FG_RSTCLA(_CLA_PWM_GPIO_OK);
    GPIO_setPinConfig(GPIO_0_GPIO0);
    GPIO_setPinConfig(GPIO_1_GPIO1);
    GPIO_setPinConfig(GPIO_2_GPIO2);
    GPIO_setPinConfig(GPIO_3_GPIO3);
    GPIO_setPinConfig(GPIO_4_GPIO4);
    GPIO_setPinConfig(GPIO_5_GPIO5);

    //
    // Configure MAIN_PWM_BASE for Peak Current Mode
    initCompPWMAB(DRIVER_A_BASE);
    initCompPWMAB(DRIVER_B_BASE);
    initCompPWMAB(DRIVER_C_BASE);

    enableAdcTriggerbyPWM(DRIVER_A_BASE);

    //
    // Enable the ePWM time base clock before configuring the module
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);


    FG_SETCLA(_CLA_INIT_PWMADC);
}

