/*
 * common.h
 *
 *  Created on: Mar 1, 2024
 *      Author: User
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "timetask.h"



#endif /* COMMON_H_ */
