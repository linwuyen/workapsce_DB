/*
 * PowerSequence.h
 *
 *  Created on: 2022�~3��24��
 *      Author: cody_chen
 */

#ifndef POWERSEQUENCE_H_
#define POWERSEQUENCE_H_

#include "common.h"

extern void initPower(HAL_DRV s);

extern void execPowerSequence(HAL_DRV s);

#endif /* POWERSEQUENCE_H_ */
