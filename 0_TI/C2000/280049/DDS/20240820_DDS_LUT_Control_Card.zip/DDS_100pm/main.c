//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"

#include "timetask.h"
#include <math.h>


#define MAX_ACC_VALUE     0xFFFFFFFF
#define SINE_TABLE_SIZE   256

typedef union {
    uint32_t u32Data;
    struct {
        uint32_t u32Decimal:24;
        uint32_t u32Index:8;
    };
}ST_ACC;

typedef struct{
    uint32_t sine_table[SINE_TABLE_SIZE];
    ST_ACC sACC;
    uint32_t u32Step;
    uint32_t u32system_clock;
    uint32_t u32Output_Frequency;
}ST_DDS;

ST_DDS DDS = {
     .u32system_clock = 100000,
     .u32Output_Frequency = 1000,
};




//LUT
void Generate_sin_table() {
    for (int i = 0; i < SINE_TABLE_SIZE; i++) {
        DDS.sine_table[i] = (uint32_t)(4095.0f * (sinf(2.0f * M_PI * i / SINE_TABLE_SIZE) * 0.5f + 0.5f));
    }
}

//Calculator Step
uint16_t Calculator_step(void){

   //DEC2HEX(INT(65535*u32Output_Frequency /(u32SYSTEM_CLOCK*1000000)))
    DDS.u32Step = MAX_ACC_VALUE / DDS.u32system_clock  * DDS.u32Output_Frequency;

    return DDS.u32Step;
}


//DDS
void Generate_DDS_signal(void) {


    //ADD u16phase_accumulator
    DDS.sACC.u32Data += DDS.u32Step;

    DAC_setShadowValue(myDAC0_BASE, DDS.sine_table[DDS.sACC.u32Index]);
}

// Main
//
void main(void)
{

    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    Generate_sin_table();



    //
    // Loop Forever
    //
    for(;;)
    {
        Calculator_step();
    }
}

__interrupt void INT_myCPUTIMER0_ISR(void)
{
      Generate_DDS_signal();
      GPIO_togglePin(myBoardLED0_GPIO);
    //
    // Acknowledge this interrupt to receive more interrupts from group 1
    //
    Interrupt_clearACKGroup(INT_myCPUTIMER0_INTERRUPT_ACK_GROUP);
}

//
// End of File
//

