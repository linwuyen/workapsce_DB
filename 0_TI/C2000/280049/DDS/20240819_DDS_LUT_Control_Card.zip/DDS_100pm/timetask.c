/*
 * timetask.c
 *
 *  Created on: May 17, 2024
 *      Author: User
 */

//#include "Global_VariableDefs.h"
//#include "spi_c28_cla_common.h"
//#include "spi_dacadc.h"

#include "timetask.h"


void task1msec(void * s)
{
    GPIO_togglePin(myBoardLED0_GPIO);
}


void task10msec(void * s)
{


}


void asapTask(void * s)
{

}

ST_TIMETASK time_task[] = {
        {task1msec,           0,   T_1MS},
        {task10msec,          0,   T_10MS},
        {asapTask,            0,   0},
        END_OF_TASK
};

void pollTimeTask(void)
{
    scanTimeTask(time_task, (void *)0);
}
