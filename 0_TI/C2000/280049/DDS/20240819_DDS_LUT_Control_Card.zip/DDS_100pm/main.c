//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"

#include "timetask.h"
#include <math.h>

uint32_t SYSTEM_CLOCK = 100000000;
uint16_t PHASE_ACC_BITS =16;
uint16_t MAX_ACC_VALUE =4095;

uint16_t output_frequency = 1000;

uint16_t u16DACValue;
float fdds_value ;
uint16_t Increase_Step = 3;
uint16_t phase_accumulator = 0 ;
float output_value;

//#pragma DATA_SECTION(sine_table, "FlashDataSection")
/// LUT
#define SINE_TABLE_SIZE 256
float sine_table[SINE_TABLE_SIZE];

void generate_sine_table() {
    for (int i = 0; i < SINE_TABLE_SIZE; i++) {
        sine_table[i] = sinf(2.0 * M_PI * i / SINE_TABLE_SIZE);
    }
}


//DDS
void DDS_generate_signal() {
//    65535*Output_Frequency/(System_Clock*1000000)
   // phase_increment = (uint16_t) ((output_frequency *  (uint32_t)MAX_ACC_VALUE) / SYSTEM_CLOCK);
//    phase_increment =3;

    //ADD
    phase_accumulator += Increase_Step;


    uint32_t sine_index = (phase_accumulator >> (PHASE_ACC_BITS - 8)) & 0xFF;


    output_value = sine_table[sine_index];


//    u16dds_value = (uint16_t)((output_value + 1.0) * 2047.5);
    fdds_value = ((output_value + 1.0) * 2047.5);


    DAC_setShadowValue(myDAC0_BASE, fdds_value);
}
// Main
//
void main(void)
{

    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    generate_sine_table();
    //
    // Loop Forever
    //
    for(;;)
    {

      pollTimeTask();
//
      DDS_generate_signal();


    }
}

//
// End of File
//

