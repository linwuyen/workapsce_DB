/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   pmbus_types.h
*
* @brief  PMBus DSC56F8xxx platform specific types
*
* @version 1.0.14.0
* 
* @date Jun-19-2012
* 
*******************************************************************************/

#ifndef __PMBUS_TYPES_H
#define __PMBUS_TYPES_H

#define PMBUS_INLINE inline

/*****************************************************************************
* List of the PMbus data types
*
*//*! @addtogroup pmbus_data_types PMBus Data Types
* @{
 ******************************************************************************/
#if PMBCFG_USE_FORMATS
typedef unsigned long   PMBUS_CMD_ENTRY_TYPE;   ///< PMBus type to store command configuration. Minimal size is 32 bits when formats and size of data block is used; 16 bits when basic configuration is used. @ingroup pmbus_data_types
#else
typedef unsigned short   PMBUS_CMD_ENTRY_TYPE;  ///< PMBus type to store command configuration. Minimal size is 32 bits when formats and size of data block is used; 16 bits when basic configuration is used. @ingroup pmbus_data_types
#endif
typedef unsigned short  PMBUS_FLAGS8;           ///< PMBus type of 8bit flag value. Minimal size is 8 bits. @ingroup pmbus_data_types
typedef unsigned short  PMBUS_FLAGS16;          ///< PMBus type of 16bit flag value. Minimal size is 16 bits. @ingroup pmbus_data_types
typedef unsigned short  PMBUS_PAGE_MEMBER_INDEX; ///< PMBus type of index of internal data members in page. Minimal size is 16 bits. @ingroup pmbus_data_types 
typedef unsigned char   PMBUS_PAGE_MEMBER;      ///< PMBus type of internal data members in page. Minimal size is 8 bits. @ingroup pmbus_data_types

typedef unsigned char   PMBUS_INDEX;            ///< PMBus index type. Minimal size is 8 bits. Stores page index and index of direct format coefficients. @ingroup pmbus_data_types
typedef unsigned char   PMBUS_SIZE;             ///< PMBus size type. Minimal size is 8 bits. Stores size of received packets. @ingroup pmbus_data_types
typedef unsigned char   PMBUS_BUFFER;           ///< PMBus buffer type. Typically must be exactly 8 bits. Used to define communication buffer element. @ingroup pmbus_data_types

typedef unsigned char   PMBUS_ERROR_CODE;       ///< PMBus type of Error code. Minimal size is 8 bits. @ingroup pmbus_data_types
typedef unsigned char   PMBUS_CMD_CODE;         ///< PMBus type of Command code. Minimal size is 8 bits. @ingroup pmbus_data_types
typedef unsigned char   PMBUS_BOOL;             ///< PMBus Boolean type. Minimal size is 8 bit. @ingroup pmbus_data_types
typedef unsigned short* PMBUS_CONTEXT;          ///< PMBus command context pointer type. @ingroup pmbus_data_types
typedef unsigned char   PMBUS_COEF8;            ///< PMBus coefficient 8bit type. Used to define the "R" coefficient. @ingroup pmbus_data_types
typedef unsigned short  PMBUS_COEF16;           ///< PMBus coefficient 16bit type. Used to define the "m" and the "b" coefficients. @ingroup pmbus_data_types

typedef PMBUS_PAGE_MEMBER_INDEX PMBUS_FAULT_ID; ///< PMBus type of Fault Response identifier.
typedef PMBUS_PAGE_MEMBER_INDEX PMBUS_STATUS_BIT_ID; ///< PMBus type of identifier of named bits in status registers
/*! @} End of pmbus_data_types */

#endif /* __PMBUS_TYPES_H */
