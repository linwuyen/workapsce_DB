/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   pmbus_smbus.c
*
* @brief  PMBus source codes of implementation the SMBus events
*
* @version 1.0.1.0
* 
* @date Jun-19-2012
* 
*******************************************************************************/

#include "smbus_slave.h"
#include "pmbus.h"

static PMB_PACKET_CONTEXT pmb_cmdContext;

// SMBus events
SMBUS_CMD_FLAGS SMBus_OnDecodePacketType(SMBUS_CMD_CODE cmd)
{
	PMB_PACKET_DATA cmdData;
	cmdData.cmdCode = cmd;

	// Init PMBus flags
	PMB_InitCmdContext(&pmb_cmdContext, pmb_struct.page, PMB_COMMAND_DECODE);
	// decode command
	if(!PMB_Process(&cmdData, &pmb_cmdContext))
	{
		PMBUS_FLAGS8 pmbCmdFlags = (PMBUS_FLAGS8)((pmb_cmdContext.pPageCmd->cmd_data)>>PMB_CMD_FLAGS_SHIFT);
		SMBUS_CMD_FLAGS smbCmdFlags; 
		// Transform PMBus flags to SMBus flags,
		smbCmdFlags = (SMBUS_CMD_FLAGS)(pmbCmdFlags&(SMBUS_PACKET_TYPE_READ_MASK|SMBUS_PACKET_TYPE_WRITE_MASK|SMBUS_PACKET_SIZE_MASK));

		if ((pmbCmdFlags&PMB_CMD_FLAGS_READ_BITS) == PMB_CMD_FLAGS_READ_PROCCALL)
		{
			smbCmdFlags &= ~SMBUS_PACKET_TYPE_READ_MASK; // Proc Call is stored in read bit field, needs to be changed to Block Read
			smbCmdFlags |= SMBUS_PACKET_PROC_CALL | SMBUS_PACKET_TYPE_READ_BLOCK;
		}
		return smbCmdFlags;
	}
	return 0;
}


SMBUS_ERROR_CODE SMBus_OnRead(SMBUS_PACKET* pDataStr)
{
	SMBUS_ERROR_CODE status;
	PMB_PACKET_DATA cmdData;
#if PMBCFG_USE_INTERNAL_CHECKS
	if(!pDataStr)
		return SMBUS_ERROR_CMD;
#endif
	cmdData = *(PMB_PACKET_DATA*) pDataStr;

	if(PMB_TestCmdContextFlag (&pmb_cmdContext, PMB_COMMAND_DECODE))
		PMB_SetCmdContextFlag(&pmb_cmdContext, PMB_PERFORM_COMMAND | PMB_CALLBACK_TYPE_READ);
	else
		PMB_InitCmdContext(&pmb_cmdContext, pmb_struct.page, PMB_COMMAND_DECODE | PMB_PERFORM_COMMAND | PMB_CALLBACK_TYPE_READ);
	
	status = (SMBUS_ERROR_CODE)PMB_Process(&cmdData, &pmb_cmdContext);
	PMB_ClearCmdContextFlag(&pmb_cmdContext, PMB_COMMAND_DECODE);
	pDataStr->packetLength = cmdData.packetLength;
	return status;
}

SMBUS_ERROR_CODE SMBus_OnWrite(SMBUS_PACKET* pDataStr)
{
	SMBUS_ERROR_CODE status;
#if PMBCFG_USE_INTERNAL_CHECKS
	if(!pDataStr)
		return SMBUS_ERROR_CMD;
#endif
	if(PMB_TestCmdContextFlag (&pmb_cmdContext, PMB_COMMAND_DECODE))
		PMB_SetCmdContextFlag(&pmb_cmdContext, PMB_PERFORM_COMMAND | PMB_CALLBACK_TYPE_WRITE);
	else
		PMB_InitCmdContext(&pmb_cmdContext, pmb_struct.page, PMB_COMMAND_DECODE | PMB_PERFORM_COMMAND | PMB_CALLBACK_TYPE_WRITE);
	
	status = (SMBUS_ERROR_CODE)PMB_Process((PMB_PACKET_DATA*)pDataStr, &pmb_cmdContext);
	PMB_ClearCmdContextFlag(&pmb_cmdContext, PMB_COMMAND_DECODE);
	return status;
}

void SMBus_OnError(SMBUS_ERROR_CODE errorCode)
{
	PMBUS_PAGE_MEMBER_INDEX statusBit;
	
	// Decode Error code and select PMBus error code
	if(errorCode&SMBUS_ERROR_CMD_NOT_SUP)
		statusBit = PMBUS_STATUS_INVALID_COMMAND;
	else if(errorCode&SMBUS_ERROR_DATA)
		statusBit = PMBUS_STATUS_INVALID_DATA;
	else if(errorCode&SMBUS_ERROR_PEC)
		statusBit = PMBUS_STATUS_INVALID_PEC;
	else
		statusBit = PMBUS_STATUS_COM_ERROR;
	
	// set error to current page
	(void)PMBus_SetErrorState(pmb_struct.page, statusBit);
}
