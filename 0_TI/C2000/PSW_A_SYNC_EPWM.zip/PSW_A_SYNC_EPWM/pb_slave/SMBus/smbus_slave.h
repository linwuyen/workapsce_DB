/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   smbus_slave.h
*
* @brief  SMBus header file
*
* @version 1.0.7.0
* 
* @date Jun-19-2012
* 
*******************************************************************************/

#ifndef __SMBUS_SLAVE_H
#define __SMBUS_SLAVE_H

#include "smbus_cfg.h"
#include "smbus_types.h"
#include "smbus_common.h"

/*****************************************************************************
* Check of configuration
******************************************************************************/
#if ((SMBCFG_SLAVE_BASE_IIC) == 0)
#error "The IIC base address is not defined, please define base address of the IIC module in smbus_cfg.h file"
#endif

/*****************************************************************************
* Internal Error codes of the SMBus Slave driver
******************************************************************************/
#define SMBUS_ERROR_IIC_ARBITRATION_LOST                1U
#define SMBUS_ERROR_RECEIVED_INVALID_PEC                2U
#define SMBUS_ERROR_CMD_NOT_SUPPORTED                   3U
#define SMBUS_ERROR_PROCCALL_NOT_SUPPORTED              4U
#define SMBUS_ERROR_PROCCALL_NOT_SUPPORTS_ZERO_PACKET   5U
#define SMBUS_ERROR_INVALID_RESPONSE_SIZE               6U
#define SMBUS_ERROR_TRANSMITED_TOO_MANY_BYTES           7U
#define SMBUS_ERROR_TRANSMITED_NOT_ENOUGH_BYTES         8U
#define SMBUS_ERROR_RECEIVED_MORE_BYTES                 9U
#define SMBUS_ERROR_RECEIVED_NOT_ENOUGH_BYTES           10U
#define SMBUS_ERROR_ALERT_FAILED                        11U


#define SMBUS_ERROR_VALID_DATA_BUT_NOT_SUPPORTED        0x90U
#define SMBUS_ERROR_READ_FORMAT_NOT_SUPPORTED           0x91U
#define SMBUS_ERROR_WRITE_FORMAT_NOT_SUPPORTED          0x92U

#define SMBUS_CALLBACK_STATUS_FLAG                      0x80U

/*****************************************************************************
* macros to build address byte
******************************************************************************/
#define SMBUS_WRITE              0
#define SMBUS_READ               1
#define SMBUS_SLAVE_ADDR_W      ((SMBCFG_SLAVE_ADDR << 1) | SMBUS_WRITE)
#define SMBUS_SLAVE_ADDR_R      ((SMBCFG_SLAVE_ADDR << 1) | SMBUS_READ)

/*****************************************************************************
* List of SMBus Slave error codes
*
*//*! @addtogroup smbus_errors_slave
* @{
*******************************************************************************/
#define SMBUS_OK                0x00            ///< Success
#define SMBUS_CMD_INIT          0x01
#define SMBUS_CMD_INITIALIZED   0x02
#define SMBUS_WRITE_PACKET      0x04
#define SMBUS_CMD_IDLE          0x08

#define SMBUS_ERROR_CMD         0x10            ///< Command Error recognized
#define SMBUS_ERROR_DATA        0x20            ///< Data Error recognized
#define SMBUS_ERROR_PEC         0x40            ///< PEC Error recognized
#define SMBUS_ERROR_CMD_NOT_SUP 0x80            ///< Command is not supported

#define SMBUS_PEC_SENT          0x100
/*! @} End of smbus_slave_errors */

/**************************************************************************/ /*!
 * @brief Data structure of SMBus packets
 *
 * This structure contains data of received SMBus packet.
 *****************************************************************************/
typedef struct
{
 	SMBUS_BUFFER* pBuffer;      ///< Pointer to packet data buffer
	SMBUS_SIZE packetLength;    ///< Length of received packet
	SMBUS_CMD_CODE cmdCode;     ///< Code of received command
} SMBUS_PACKET;

/*****************************************************************************/
/*! @addtogroup smbus_slave_api 
* @{*/

/*****************************************************************************
*//*!
* @brief            Initialization function of the SMBus Slave driver
* @details          This function initializes internal variables of the SMBus driver.
*
* @internal
* @version          29-May-2012
******************************************************************************/
void SMBus_SlaveInit(void);
/*****************************************************************************
*//*!
* @brief            Poll function of the SMBus driver
* @details          This function handles the SMBus communication and triggers 
*                   execution of command handlers (e.g. PMBus handlers). This function must 
*                   be called periodically from the main application loop or task.
* @internal
* @version          29-May-2012
******************************************************************************/
void SMBus_SlavePoll(void);

/*****************************************************************************
*//*!
* @brief            Callback to decode type of a packet
* @details          This function is called by the SMBus communication handler 
*                   when the first byte of a packet is received. This function 
*                   should decode the command code and provide information about 
*                   @ref smbus_packet_type_flags "data format and type" of the command.
*                   This function must be implemented in your application (e.g. PMBus stack).
* @param[in]        cmdCode           Code of command to be decoded by the application layer.
* @return           Command flags for the received command. See list of all @ref smbus_packet_type_flags "flags".
* @internal
* @version          29-May-2012
******************************************************************************/
SMBUS_CMD_FLAGS SMBus_OnDecodePacketType(SMBUS_CMD_CODE cmdCode);


/*****************************************************************************
*//*!
* @brief            Callback to perform the Read command
* @details          This function is called whenever the SMBus driver requires 
*                   data to be sent. This function has to prepare the response 
*                   in the SMBus buffer accessible in pDataStr->pBuffer and 
*                   should set the size of the response in pDataStr->packetLength.
*                   This function must be implemented in your application (e.g. PMBus stack).
* @param[in,out]    pDataStr                Pointer to data structure describing 
*                                           the SMBus packet.
* @return           @ref SMBUS_ERROR_CODE "SMBUS_ERROR_CODE"
*                       - SMBUS_OK          Call finished successfully.
*                       - SMBUS_ERROR_CMD   Call aborted due to command error.
*                       - user defined error.
* @internal
* @version          29-May-2012
******************************************************************************/
SMBUS_ERROR_CODE SMBus_OnRead(SMBUS_PACKET* pDataStr);

/*****************************************************************************
*//*!
* @brief            Callback to perform the Write command
* @details          This function is called by the SMBus driver whenever the 
*                   Write packet is received. The received packet is available 
*                   in the SMBus buffer in pDataStr->pBuffer and 
*                   its size is in pDataStr->packetLength.
*                   This function must be implemented in your application (e.g. PMBus stack).
* @param[in,out]    pDataStr                Pointer to data structure describing the SMBus packet.
* @return           @ref SMBUS_ERROR_CODE "SMBUS_ERROR_CODE"
*                       - SMBUS_OK          Call finished successfully.
*                       - SMBUS_ERROR_CMD   Call aborted due to command error.
*                       - SMBUS_ERROR_DATA  Call aborted due to data error.
*                       - user defined error
* @internal
* @version          29-May-2012
******************************************************************************/
SMBUS_ERROR_CODE SMBus_OnWrite(SMBUS_PACKET* pDataStr);

/*****************************************************************************
*//*!
* @brief            Callback to handle error condition
* @details          This function is called by the SMBus driver when the SMBus
*                   interface detects any communication, data or checksum error. 
*                   This function must be implemented in your application (e.g. PMBus stack).
* @param[in]        errorCode               Type of Error code. See list of 
*                                           all @ref smbus_errors_slave "Slave Error Codes".
*
* @internal
* @version          29-May-2012
******************************************************************************/
void SMBus_OnError(SMBUS_ERROR_CODE errorCode);

/*****************************************************************************
*//*!
* @brief            Function to build and send the SMBus Alert message to master.
* @details          This function is used by the application layer to send 
*                   the SMBus Alert packet to the master device.
* @param[in]        response                The SMBus alert response data which will be sent to the master device.
* @return           @ref SMBUS_ERROR_CODE "SMBUS_ERROR_CODE"
*                       - SMBUS_OK          Call finished successfully.
*                       - SMBUS_ERROR_CMD   Call aborted due to command error.
* @internal
* @version          15-Jan-2012
******************************************************************************/
SMBUS_ERROR_CODE SMBus_Alert(SMBUS_FLAGS16 response);

/*****************************************************************************
*//*!
* @brief            The IIC interrupt vector handler routine.
* @details          This function should be registered as the ISR function for 
*                   the IIC vector in case the Interrupt operation mode 
*                   is enabled.
*
* @internal
* @version          29-May-2012
******************************************************************************/
void SMBus_Isr(void);

/*****************************************************************************
*//*!
* @brief            Internal IIC process function to be called in a customized ISRs.
* @details          This function is typically called by the IIC interrupt 
*                   routine or in the Poll function. This function handles 
*                   the IIC module, processes all received bytes and sends 
*                   pending bytes. Call this function in your custom IIC ISR.
*
* @param[in]        iicBaseAddress          Base address of the IIC module
*
* @internal
* @version          29-May-2012
******************************************************************************/
void SMBus_SlaveProcessIIC(SMBUS_BASE_ADDRESS iicBaseAddress);

/*! @} End of smbus_slave_api */

#endif /* __SMBUS_SLAVE_H */

