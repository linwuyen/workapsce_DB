/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   smbus_types.h
*
* @brief  SMBus DSC56F8xxx platform specific types
*
* @version 1.0.4.0
* 
* @date Jun-1-2012
* 
*******************************************************************************/

#ifndef __SMBUS_TYPES_H
#define __SMBUS_TYPES_H

#include <pb_slave/SMBus/smbus.h>

/*****************************************************************************/
/*! @addtogroup smbus_data_types SMBus Data Types
* @{
 ******************************************************************************/
typedef unsigned short* SMBUS_BASE_ADDRESS;
typedef unsigned short  SMBUS_FLAGS8;           ///< SMBus type of 8bit flag value. Minimal size is 8 bits. @ingroup smbus_data_types
typedef unsigned short  SMBUS_FLAGS16;          ///< SMBus type of 16bit flag value. Minimal size is 16 bits. @ingroup smbus_data_types
typedef unsigned char   SMBUS_SIZE;             ///< SMBus size type. Minimal size is 8 bits. Stores size of received packets. @ingroup smbus_data_types
typedef unsigned short  SMBUS_SIZE16;           ///< SMBus size type. Minimal size is 16 bits. Stores size of received packets. @ingroup smbus_data_types
typedef unsigned char   SMBUS_BUFFER;           ///< SMBus buffer type. Typically must be exactly 8 bits. Used to define communication buffer element. @ingroup smbus_data_types
typedef unsigned char   SMBUS_ERROR_CODE;       ///< SMBus type of Error codes. Minimal size is 8 bits. @ingroup smbus_data_types
typedef unsigned short  SMBUS_CMD_FLAGS;        ///< SMBus type of Command flags. Minimal size is 8 bits. @ingroup smbus_data_types
typedef unsigned char   SMBUS_CMD_CODE;         ///< SMBus type of Command code. Minimal size is 8 bits. @ingroup smbus_data_types
typedef unsigned char   SMBUS_BOOL;             ///< SMBus Boolean type. Minimal size is 8 bit. @ingroup smbus_data_types

/*! @} End of smbus_data_types */

#endif /* __SMBUS_TYPES_H */
