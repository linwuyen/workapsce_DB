/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   smbus_slave.c
*
* @brief  SMBus source code
*
* @version 1.0.9.0
* 
* @date Jun-19-2012
* 
******************************************************************************/

#include "smbus_slave.h"

/*****************************************************************************
* Global variables
******************************************************************************/
SMBUS_SIZE smbus_packetSize;

SMBUS_FLAGS16 smbus_flags = 0;
SMBUS_BUFFER smbus_buffer[SMBCFG_BUFFER_SIZE];
SMBUS_PACKET smbus_data;



SMBUS_FLAGS8 smbus_packetType;
SMBUS_BUFFER receivedData;



SMBUS_BUFFER smbus_timeout = SMBCFG_SLAVE_TIMEOUT;
SMBUS_BUFFER smbus_pec;

#if SMBCFG_DEBUG
SMBUS_ERROR_CODE smbus_errorCode = 0;
SMBUS_ERROR_CODE smbus_lastErrorCode = 0;
#endif

#define SMBUS_RESET_TIMEOUT()  smbus_timeout = SMBCFG_SLAVE_TIMEOUT;
/*****************************************************************************
* prototypes of local functions
******************************************************************************/
static SMBUS_ERROR_CODE SMBus_IIC_OnSlaveReadByte(SMBUS_BUFFER* pDataToSend);
static void SMBus_PEC(SMBUS_BUFFER data);


/*****************************************************************************
* PEC support
******************************************************************************/

//PEC initialization
#define SMBus_PEC_Init() smbus_pec = 0

SMBUS_INLINE SMBUS_BUFFER SMBus_GetPEC(void)
{
	return (smbus_pec&0x00FF);
}
// Table of crc values
const SMBUS_BUFFER smbus_crcTable[16] = {
  0x00, 0x07, 0x0E, 0x09, 0x1C, 0x1B, 0x12, 0x15,
  0x38, 0x3F, 0x36, 0x31, 0x24, 0x23, 0x2A, 0x2D
};

//PEC CRC function
//This function uses x^8+x^2+x^1+1 polynomial
static void SMBus_PEC(SMBUS_BUFFER data)
{
	SMBUS_BUFFER index;
	index = (SMBUS_BUFFER)(((smbus_pec>>4) & 0x0f) ^ (data>>4));
	smbus_pec = (SMBUS_BUFFER)((smbus_pec<<4) ^ smbus_crcTable[index]);

	index = (SMBUS_BUFFER)(((smbus_pec>>4) & 0x0f) ^ (data&0x0f));
	smbus_pec = (SMBUS_BUFFER)((smbus_pec<<4) ^ smbus_crcTable[index]);
}


/*****************************************************************************
* SMBus Implementation
******************************************************************************/
SMBUS_INLINE void SMBus_SetErrorCode(SMBUS_ERROR_CODE errorCode, SMBUS_FLAGS16 errorFlags)
{
#if SMBCFG_DEBUG
	if((smbus_flags&SMBUS_ERROR_CMD) == 0)
		smbus_errorCode = errorCode;
#endif
	smbus_flags |= (errorFlags & (SMBUS_ERROR_CMD | SMBUS_ERROR_DATA | SMBUS_ERROR_PEC | SMBUS_ERROR_CMD_NOT_SUP));
}


//void SMBus_IIC_OnStop(void);
//void SMBus_IIC_OnStop(void)
SMBUS_INLINE void SMBus_IIC_OnStop(SMBUS_BASE_ADDRESS base)
{
	if(smbus_flags&SMBUS_CMD_INIT)
	{

		if(smbus_data.packetLength<smbus_packetSize)
		{
			//exception for send byte packet
			if((smbus_packetType&SMBUS_PACKET_TYPE_WRITE_MASK) != SMBUS_PACKET_TYPE_WRITE_SEND_BYTE)
				SMBus_SetErrorCode((SMBUS_ERROR_CODE)((smbus_flags&SMBUS_WRITE_PACKET)?SMBUS_ERROR_RECEIVED_NOT_ENOUGH_BYTES:SMBUS_ERROR_TRANSMITED_NOT_ENOUGH_BYTES), SMBUS_ERROR_CMD | SMBUS_ERROR_DATA);
	

		}

		if(smbus_flags&SMBUS_WRITE_PACKET)
		{
			if((smbus_flags&SMBUS_ERROR_CMD) == 0) //if is packet valid(set any flag), perform command
			{
				SMBUS_ERROR_CODE callbackStatus;

				//Initialization of buffer
				smbus_data.pBuffer = smbus_buffer;
				//Perform received packet
				callbackStatus = SMBus_OnWrite( &smbus_data);
				if(callbackStatus)
				{
					SMBus_SetErrorCode((SMBUS_ERROR_CODE)(callbackStatus|SMBUS_CALLBACK_STATUS_FLAG), SMBUS_ERROR_CMD | SMBUS_ERROR_DATA);
					if(callbackStatus == 4)
						smbus_flags |= SMBUS_ERROR_CMD_NOT_SUP;
				}
			}
		}

		if(smbus_flags&SMBUS_ERROR_CMD)
		{
//	        SMBUS_IIC_RESET(base);
			SMBus_OnError((SMBUS_ERROR_CODE)(smbus_flags&(SMBUS_ERROR_CMD|SMBUS_ERROR_PEC|SMBUS_ERROR_DATA|SMBUS_ERROR_CMD_NOT_SUP)));
//			SMBUS_IIC_ENABLE(base);
		}
#if SMBCFG_DEBUG
		smbus_lastErrorCode = smbus_errorCode;
#endif

		//clear all packet flags, get ready for next packet
		smbus_flags = SMBUS_CMD_IDLE;
	}
}

SMBUS_INLINE void SMBus_IIC_OnArbitrationLost(void)
{
	SMBus_SetErrorCode(SMBUS_ERROR_IIC_ARBITRATION_LOST, SMBUS_ERROR_CMD);
}


SMBUS_INLINE void SMBus_IIC_OnSlaveWriteData(SMBUS_BUFFER recByte)
{
    if(smbus_packetSize == 0)   //when size is zero, second byte was received - Only write Block does not have packet size initialized
    {
        if((smbus_packetType&SMBUS_PACKET_TYPE_WRITE_MASK) == SMBUS_PACKET_TYPE_WRITE_BYTE_WORD) {
            smbus_packetSize = (SMBUS_SIZE) ((smbus_packetType&SMBUS_PACKET_SIZE_MASK) ? 2:1);
        }
        else if(((smbus_packetType&SMBUS_PACKET_TYPE_WRITE_MASK) == SMBUS_PACKET_TYPE_WRITE_BLOCK)
           || (((smbus_packetType&SMBUS_PACKET_TYPE_READ_MASK) == SMBUS_PACKET_TYPE_READ_BLOCK)&&(smbus_packetType&SMBUS_PACKET_PROC_CALL_MASK))) {
            //CMD supports Write block or ProcCall write Block-Read block, current byte is size
            smbus_packetSize = (SMBUS_SIZE) (recByte+1);
        }
        else
        {
            //if smbus_packetSize is not initialized, "send byte" packet is received or packet does not support write
            //if packet does not support write, set error
            if(!(smbus_packetType&SMBUS_PACKET_TYPE_WRITE_MASK))
                SMBus_SetErrorCode(SMBUS_ERROR_CMD_NOT_SUPPORTED, SMBUS_ERROR_CMD | SMBUS_ERROR_CMD_NOT_SUP);
        }
    }
    if(smbus_data.packetLength<smbus_packetSize)
    {
        smbus_buffer[smbus_data.packetLength++] = recByte;
        SMBus_PEC(recByte);
    }
    //todo( optional), add to this condition also check that is (smbus_packetType&SMBUS_PACKET_TYPE_WRITE_MASK), because any READ could not receive more bytes
    // but the PEC will be wrong with high possibility
    else
    {
        if((smbus_flags&SMBUS_PEC_SENT) == 0)
        {
            smbus_flags |= SMBUS_PEC_SENT;
            if(recByte  != SMBus_GetPEC())
            {
                SMBus_SetErrorCode(SMBUS_ERROR_RECEIVED_INVALID_PEC, SMBUS_ERROR_PEC | SMBUS_ERROR_CMD);
            }
            else {
                SMBUS_ERROR_CODE callbackStatus;

                //Initialization of buffer
                smbus_data.pBuffer = smbus_buffer;
                //Perform received packet
                callbackStatus = SMBus_OnWrite( &smbus_data);
                if(callbackStatus)
                {
                    SMBus_SetErrorCode((SMBUS_ERROR_CODE)(callbackStatus|SMBUS_CALLBACK_STATUS_FLAG), SMBUS_ERROR_CMD | SMBUS_ERROR_DATA);
                    if(callbackStatus == 4)
                        smbus_flags |= SMBUS_ERROR_CMD_NOT_SUP;
                }
                else {
                    //clear all packet flags, get ready for next packet
                    smbus_flags = SMBUS_CMD_IDLE;
                }

            }
        }
        else
        {
            SMBus_SetErrorCode(SMBUS_ERROR_RECEIVED_MORE_BYTES, SMBUS_ERROR_CMD | SMBUS_ERROR_DATA);
        }
    }
}



SMBUS_INLINE void SMBus_IIC_OnSlaveReadInit(SMBUS_BUFFER SlaveAddress)
{
	SMBUS_ERROR_CODE callbackStatus = 0;
	smbus_data.pBuffer = smbus_buffer;

	//Get data to reply
	if((smbus_flags&SMBUS_ERROR_CMD) == 0)
	{
		callbackStatus = SMBus_OnRead(&smbus_data);
	}

    if((smbus_packetType&SMBUS_PACKET_TYPE_READ_MASK) == SMBUS_PACKET_TYPE_READ_BYTE_WORD) {
        smbus_data.packetLength = (SMBUS_SIZE) ((smbus_packetType&SMBUS_PACKET_SIZE_MASK) ? 2:1);
    }
    else if((smbus_packetType&SMBUS_PACKET_TYPE_READ_MASK) == SMBUS_PACKET_TYPE_READ_BLOCK) {
        smbus_data.packetLength = smbus_data.pBuffer[0] + 1;
    }
    else if((smbus_packetType&SMBUS_PACKET_PROC_CALL_MASK) == SMBUS_PACKET_PROC_CALL) {
        smbus_data.packetLength = smbus_data.pBuffer[0] + 1;
    }
    else {
        SMBus_SetErrorCode((SMBUS_ERROR_CODE)SMBUS_ERROR_READ_FORMAT_NOT_SUPPORTED, SMBUS_ERROR_CMD | SMBUS_ERROR_DATA);
    }

    //update packet size
    smbus_packetSize = smbus_data.packetLength;
    smbus_data.packetLength = 0;


	SMBus_PEC(SlaveAddress);
	if(callbackStatus)
	{
		//error of callback, send EOF byte
		smbus_packetSize = 0;
		SMBus_SetErrorCode((SMBUS_ERROR_CODE)(callbackStatus|SMBUS_CALLBACK_STATUS_FLAG), SMBUS_ERROR_CMD | SMBUS_ERROR_DATA);
		if(callbackStatus == 4)
			smbus_flags |= SMBUS_ERROR_CMD_NOT_SUP;
	}
}

SMBUS_INLINE void SMBus_IIC_OnSlaveWriteInit(SMBUS_BUFFER SlaveAddress)
{
	SMBus_SetErrorCode(SMBUS_OK, 0);
	//initialize state machine to receive packet,
	smbus_flags = SMBUS_CMD_INIT; //and also clears IDLE flag
	smbus_packetSize = smbus_data.packetLength = 0;
	SMBus_PEC_Init();
	SMBus_PEC(SlaveAddress);
}



SMBUS_ERROR_CODE SMBus_IIC_OnSlaveReadByte(SMBUS_BUFFER* pDataToSend)
{
	if(smbus_packetSize > smbus_data.packetLength)
	{
		SMBus_PEC(smbus_buffer[smbus_data.packetLength]);
		*pDataToSend = smbus_buffer[smbus_data.packetLength++];
	}
	else
	{
		//send PEC as last byte of packet, send it only once
		if((smbus_flags&SMBUS_PEC_SENT) == 0)
		{
			*pDataToSend = SMBus_GetPEC();
			smbus_flags |= SMBUS_PEC_SENT;
		}
		else
		{
			SMBus_SetErrorCode(SMBUS_ERROR_TRANSMITED_TOO_MANY_BYTES, SMBUS_ERROR_CMD | SMBUS_ERROR_DATA);
		}
	}
	return (SMBUS_ERROR_CODE) (smbus_flags&SMBUS_ERROR_CMD);
}

SMBUS_ERROR_CODE SMBus_Alert(SMBUS_FLAGS16 response)
{
	//todo: initialize Master communication, send Alert
	return SMBUS_ERROR_ALERT_FAILED;
}

SMBUS_ERROR_CODE SMBus_ParsingPackage(SMBUS_BUFFER recByte)
{
    smbus_flags = SMBUS_CMD_INIT;
    //Get packet type
    smbus_packetType = SMBus_OnDecodePacketType((SMBUS_CMD_CODE)recByte);
    //this condition immediately reports that command is not supported
    if(smbus_packetType == 0)
    {
        SMBus_SetErrorCode(SMBUS_ERROR_CMD_NOT_SUPPORTED, SMBUS_ERROR_CMD | SMBUS_ERROR_CMD_NOT_SUP);
    }


    SMBus_PEC(recByte);
    smbus_data.cmdCode = (SMBUS_CMD_CODE)recByte;

    return (SMBUS_ERROR_CODE) (smbus_flags&SMBUS_ERROR_CMD);
}


void SMBus_SlaveProcessIIC(SMBUS_BASE_ADDRESS base)
{
    register SMBUS_FLAGS16 iicsr;

    //read Status Register
    iicsr = SMBUS_IIC_GETSR(base);

    if(iicsr & SMBUS_IIC_SR_ARBL) SMBus_IIC_OnArbitrationLost();

    if((iicsr & SMBUS_IIC_SR_BUSY)||(smbus_flags&SMBUS_ERROR_CMD)||SMBUS_IIC_TX_DATA_CNTS(base)||SMBUS_IIC_RX_DATA_CNTS(base)) {
        if(0 < smbus_timeout) {
            smbus_timeout--;
            if(0 == smbus_timeout) {
                SMBUS_IIC_RESET(base);
                SMBus_IIC_OnStop(base);
                SMBUS_IIC_ENABLE(base);
            }
        }
    }

    if(iicsr & SMBUS_IIC_SR_IICIF) {

        if (smbus_flags & SMBUS_WRITE_PACKET) {
            if (iicsr & SMBUS_IIC_SR_SRW) {
                SMBus_IIC_OnSlaveReadInit(SMBUS_SLAVE_ADDR_R);
                smbus_flags &= ~SMBUS_WRITE_PACKET;
                smbus_flags |= SMBUS_CMD_INITIALIZED;
            }
            else {
                if(SMBUS_IIC_RX_DATA_CNTS(base)) {
                    SMBUS_RESET_TIMEOUT();
                    receivedData = (SMBUS_BUFFER)(SMBUS_IIC_GETBYTE(base));
                    SMBus_IIC_OnSlaveWriteData(receivedData);
                }
                __asm("  NOP");
            }
//            SMBUS_RESET_TIMEOUT();

        }
        else if (smbus_flags & SMBUS_CMD_INITIALIZED) {
            if(SMBUS_IIC_FIFO_SIZE > SMBUS_IIC_TX_DATA_CNTS(base)) {
                SMBUS_RESET_TIMEOUT();
                SMBUS_BUFFER sendByte = 0;
                //get byte to send,
                if(SMBus_IIC_OnSlaveReadByte(&sendByte)) {
                    if(SMBUS_IIC_RX_DATA_CNTS(base)) {
                        // if Error detected, send EOF
                        SMBUS_IIC_PUTBYTE(base, SMBCFG_EOF);
                    }
                    else {
                        SMBus_IIC_OnStop(base);
                    }
                }
                else {
                    SMBUS_IIC_PUTBYTE(base, sendByte);
                }
            }
        }
        else if (smbus_flags & SMBUS_CMD_INIT) {

            if(SMBUS_IIC_RX_DATA_CNTS(base)) {
                SMBUS_RESET_TIMEOUT();
                receivedData = (SMBUS_BUFFER)(SMBUS_IIC_GETBYTE(base));
                if(SMBus_ParsingPackage(receivedData)) {
                    //process received byte when Error detected, Set NACK on next received byte
                    SMBUS_IIC_SET_TXNACK(base);
                }
                else {
                    smbus_flags |= SMBUS_WRITE_PACKET;
                }
            }
        }
        else if (iicsr & SMBUS_IIC_SR_IAAS) { //Is address received?
            SMBUS_RESET_TIMEOUT();
            //Slave is addressed as Write
            //init SMBus packet
            SMBus_IIC_OnSlaveWriteInit(SMBUS_SLAVE_ADDR_W);
            //Configure IIC module to receive byte
            SMBUS_IIC_SET_TXACK(base);

        }
        else {

        }

        //Clear interrupt flag
        SMBUS_IIC_CLEAR_ISR(base);
    }
}

void SMBus_SlaveInit(void)
{
	smbus_flags = 0;
#if SMBCFG_DEBUG
	smbus_errorCode = 0;
	smbus_lastErrorCode = 0;
#endif
}

void SMBus_SlavePoll(void)
{
#if SMBCFG_POLL_DRIVEN
	SMBus_SlaveProcessIIC((SMBUS_BASE_ADDRESS)SMBCFG_SLAVE_BASE_IIC);
#endif
}
