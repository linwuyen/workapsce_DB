/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   smbus_common.h
*
* @brief  SMBus header file
*
* @version 1.0.2.0
* 
* @date Jun-1-2012
* 
*******************************************************************************/

#ifndef __SMBUS_COMMON_H
#define __SMBUS_COMMON_H

#include "smbus_types.h"

/*****************************************************************************
* SMBus macros to define type of packet
*
*//*! @addtogroup smbus_packet_type_flags
* @{
*******************************************************************************/
#define SMBUS_PACKET_TYPE_READ_MASK             0x03                            ///< Mask of bits to determine Read type of SMBus packet
#define SMBUS_PACKET_TYPE_READ_NA               0x00                            ///< Type of read packet is not supported
#define SMBUS_PACKET_TYPE_READ_REC_BYTE         0x01                            ///< Type of read packet is Receive Byte packet
#define SMBUS_PACKET_TYPE_READ_BYTE_WORD        0x02                            ///< Type of read packet is Byte/Word packet
#define SMBUS_PACKET_TYPE_READ_BLOCK            0x03                            ///< Type of read packet is data block packet

#define SMBUS_PACKET_TYPE_WRITE_MASK            0x0C                            ///< Mask of bits to determine Write type of SMBus packet
#define SMBUS_PACKET_TYPE_WRITE_NA              0x00                            ///< Type of write packet is not supported
#define SMBUS_PACKET_TYPE_WRITE_SEND_BYTE       0x04                            ///< Type of write packet is Send Byte packet
#define SMBUS_PACKET_TYPE_WRITE_BYTE_WORD       0x08                            ///< Type of write packet is Byte/Word packet
#define SMBUS_PACKET_TYPE_WRITE_BLOCK           0x0C                            ///< Type of write packet is data block packet

#define SMBUS_PACKET_SIZE_MASK                  0x10
#define SMBUS_PACKET_SIZE_WORD                  SMBUS_PACKET_SIZE_MASK          ///< Defines Word size of Byte/Word packet type
#define SMBUS_PACKET_SIZE_BYTE                  0x00                            ///< Defines Byte size of Byte/Word packet type

#define SMBUS_PACKET_PROC_CALL_MASK             0x20
#define SMBUS_PACKET_PROC_CALL                  SMBUS_PACKET_PROC_CALL_MASK     ///< Defines Write-Read process call of type packet
/*! @} End of smbus_packet_type_flags */

/*****************************************************************************
* SMBus macros to define type of packet
*
*//*! @addtogroup smbus_packet_type_flags
* @{
*******************************************************************************/
#define SMBUS_WRITE                     0
#define SMBUS_READ                      1
#define SMBUS_SLAVE_ADDR_W             ((SMBCFG_SLAVE_ADDR << 1) | SMBUS_WRITE) ///
#define SMBUS_SLAVE_ADDR_R             ((SMBCFG_SLAVE_ADDR << 1) | SMBUS_READ)



//check of configuration
#if ((SMBCFG_POLL_DRIVEN) && (SMBCFG_INTERRUPT_DRIVEN)) || \
    !((SMBCFG_POLL_DRIVEN) || (SMBCFG_INTERRUPT_DRIVEN))
    /* mismatch in interrupt modes, only one can be selected */
    #error "You have to enable exctly one of SMBCFG_POLL_DRIVEN or SMBCFG_INTERRUPT_DRIVEN"
#endif

#endif /* __SMBUS_COMMON_H */
