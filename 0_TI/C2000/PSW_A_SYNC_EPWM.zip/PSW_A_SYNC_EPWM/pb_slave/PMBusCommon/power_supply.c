/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   power_supply.c
*
* @brief  Example of power supply with the PMBus interface
*
* @version 1.0.7.0
* 
* @date Jun-19-2012
* 
*******************************************************************************/

#include "PE_Types.h"
#include <string.h>

#include "power_supply.h"


const UWord8 pmb_mfr_id[] = "MfrId123456";

const UWord8 pmb_mfr_model[] = "MfrModel12345678";

const UWord8 mfr_fw_id[] = "SEJSR201DMP3Q600A01";

const UWord8 mfr_fw_revision[] = "A01";

const UWord8 mfr_fw_date[] = "2022021601";

PWR_VARIABLES pwr;


// initialization of the PMBus internal registers
const PMBUS_INTERNAL_REGISTERS initInternalRegs = 
{
	0x02,       //status_byte_alert
	0x00,       //status_wordh_alert
	0x80,       //status_vout_alert
	0x00,       //status_iout_alert
	0x00,       //status_input_alert
	0x00,       //status_temperature_alert
	0x00,       //status_cml_alert
	0x00,       //status_other_alert
	0x00,       //status_mfr_specific_alert
	0x00,       //status_fans_1_2_alert
	0x00,       //status_fans_3_4_alert
	0x1d,       //vout_mode
	0x02,       //vout_ov_fault_response
	0x20,       //vout_uv_fault_response
	0x08,       //iout_oc_fault_response
	0x00,       //iout_oc_lv_fault_response
	0x00,       //iout_uc_fault_response
	0x00,       //ot_fault_response
	0x00,       //ut_fault_response
	0x00,       //vin_ov_fault_response
	0x00,       //vin_uv_fault_response
	0x00,       //iin_oc_fault_response
	0x00,       //ton_max_fault_response
	0x00        //pout_op_fault_response
};


PMBUS_ERROR_CODE Pmbus_ReadVout(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
    static float f32TempVout = 6.123f;

	if(PMBus_IsRead(context))
	{
	    // Example: Convert 12.999 to Linear11
	    // You would get the result: exponent= -6, mantissa = 831
	    //
        uint16_t u16LinearData;
        uint16_t u16Exponent;
        uint16_t u16Mantissa;
		// exponent = -6
	    // mantissa = input value / (2^exponent) = 12.999 / (2^-6) = 831

        u16Exponent = (uint16_t)(-6<<11);
        u16Mantissa = (uint16_t)(f32TempVout * 64.0f);

        u16LinearData = u16Exponent | u16Mantissa;

        pBuffer[0] = (UWord8)(u16LinearData&0x00FF);
        pBuffer[1] = (UWord8)((u16LinearData>>8)&0x00FF);
		return PMBUS_OK;
	}
	else
	{
		return PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED;
	}	
}

PMBUS_ERROR_CODE Pmbus_ReadIout(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
    static float f32TempIout = 70.75;
	if(PMBus_IsRead(context))
	{
        // Example: Convert Iout,scale 167.047 to Linear11
        // You would get the result: exponent= -2
        //
        uint16_t u16LinearData;
        uint16_t u16Exponent;
        uint16_t u16Mantissa;
        // exponent = -2
        // mantissa = input value / (2^exponent) = 70.75 / (2^-2) = 283

        u16Exponent = (uint16_t)(-2<<11);
        u16Mantissa = (uint16_t)(f32TempIout * 4.0f);

        u16LinearData = u16Exponent | u16Mantissa;

        pBuffer[0] = (UWord8)(u16LinearData&0x00FF);
        pBuffer[1] = (UWord8)((u16LinearData>>8)&0x00FF);

		return PMBUS_OK;
	}
	else
	{
		return PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED;
	}	
}

PMBUS_ERROR_CODE Pmbus_Read_T_SEC_C(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	if(PMBus_IsRead(context))
	{
		// exponetn = -1
//		UWord16 u16Temp = (-1<<11)+((sMLLC.sT_SEC.s16TempC<<1)&0x07FF);
//		pBuffer[0] = (UWord8)u16Temp;
//		pBuffer[1] = (UWord8)(u16Temp>>8);
		return PMBUS_OK;
	}
	else
	{
		return PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED;
	}	
}

PMBUS_ERROR_CODE Pmbus_Read_IN_NTC_C(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	if(PMBus_IsRead(context))
	{
		// exponetn = -1
//		UWord16 u16Temp = (-1<<11)+((sMLLC.sIN_NTC.s16TempC<<1)&0x07FF);
//		pBuffer[0] = (UWord8)u16Temp;
//		pBuffer[1] = (UWord8)(u16Temp>>8);
		return PMBUS_OK;
	}
	else
	{
		return PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED;
	}	
}

PMBUS_ERROR_CODE Pmbus_Read_SB_NTC_C(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	if(PMBus_IsRead(context))
	{
		// exponetn = -1
//		UWord16 u16Temp = (-1<<11)+((sMLLC.sSB_NTC.s16TempC<<1)&0x07FF);
//		pBuffer[0] = (UWord8)u16Temp;
//		pBuffer[1] = (UWord8)(u16Temp>>8);
		return PMBUS_OK;
	}
	else
	{
		return PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED;
	}	
}

PMBUS_ERROR_CODE Pmbus_Read_FAN_RPM(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
	if(PMBus_IsRead(context))
	{
//		acc32_t a32Rpm;
//		frac16_t f16FanPU;
//		UWord16 u16Temp;
//
//		f16FanPU = sMLLC.sFan.sVFilter.f16out;
//		// exponetn = +5
//		// RPM = 30/sMLLC.sFan.sVFilter.f16out
//		// Limit the range of RPM by 0.001pu ~ 1.000pu
//		// This range is equal to 30000rpm  ~ 30rpm
//		if(FRAC16(0.001) < f16FanPU) {
//			a32Rpm = MLIB_Div_A32as(ACC32(30.0), f16FanPU);
//		}
//		else {
//			a32Rpm = ACC32(0.0);
//		}
//
//		u16Temp = (5<<11)+(((a32Rpm>>5)>>15)&0x07FF);
//		pBuffer[0] = (UWord8)u16Temp;
//		pBuffer[1] = (UWord8)(u16Temp>>8);
		return PMBUS_OK;
	}
	else
	{
		return PMBUS_ERROR_CMD_WRITE_NOT_SUPPORTED;
	}	
}

extern const PMB_MEMBER_CONVERSION_STRUCT pmb_IntVar_table[];

void setStatusBitId(PMBUS_BOOL data, PMBUS_STATUS_BIT_ID ev)
{
	if(data) {
		PMBus_SetErrorState(0, ev);
		PMBus_SetErrorState(1, ev);
	}
	else {
		PMBus_ResetErrorState(0, ev);
		PMBus_ResetErrorState(1, ev);
	}
}

PMBUS_ERROR_CODE PMB_CallBackStatusRegs(PMB_PACKET_CONTEXT* pCmdContext, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
{
    static PMBUS_BOOL tstVoutStat;

	PMBUS_CMD_CODE cmdStatIndex;
	PMBUS_PAGE_MEMBER* pStatReg;
	PMBUS_CMD_CODE memberCode;
	PMBUS_PAGE_MEMBER_INDEX memberOffset;
//	PMBUS_UNUSED(pSize);
	
	// get code of command
	cmdStatIndex = (PMBUS_CMD_CODE)(pCmdContext->pPageCmd->cmd_data&PMB_CMD_CODE_MASK);

	// transform Code of command to index
	cmdStatIndex -= PMB_CODE_STATUS_BYTE + PMBUS_INDEX_STATUS_VOUT_ALERT_MASK;
	
#if PMBCFG_USE_INTERNAL_CALLBACK_CHECKS
	//check if index points to status registers
	if(cmdStatIndex>(PMBUS_INDEX_STATUS_FANS_3_4_ALERT_MASK-2))
		return PMBUS_ERROR_CMD_INVALID_PARAM;
#endif

	// index was calculated without byte and word register, needs to update the index to include these registers
	cmdStatIndex +=2;

	memberOffset = pmb_IntVar_table[cmdStatIndex].member_index;
	// is command enabled?
	if(memberOffset == 0xffff)
		return PMBUS_ERROR_CMD_INVALID_PARAM;
	
	// get the address of internal register.
	pStatReg = ((PMBUS_PAGE_MEMBER*)pCmdContext->pPageStruct) + memberOffset;
	
	memberCode = pmb_IntVar_table[cmdStatIndex].cmd_Code;
	
	// update STATUS_VOUT
	if(PMB_CODE_STATUS_VOUT == memberCode) {
	    setStatusBitId(tstVoutStat, (PMBUS_STATUS_VOUT_OV_FAULT|PMBUS_STATUS_VOUT_OV_WARNING|PMBUS_CALL_SMBUSALERT));
//		setStatusBitId(_FG_VOUT_OV, (PMBUS_STATUS_VOUT_OV_FAULT|PMBUS_STATUS_VOUT_OV_WARNING|PMBUS_CALL_SMBUSALERT));
	}
	// update STATUS_IOUT
	else if(PMB_CODE_STATUS_IOUT == memberCode) {
//		setStatusBitId(_FG_IOUT_FAST_OC, (PMBUS_STATUS_IOUT_OC_FAULT|PMBUS_STATUS_IOUT_OC_WARNING|PMBUS_CALL_SMBUSALERT));
	}
	// update PMB_CODE_STATUS_TEMPERATURE
	else if(PMB_CODE_STATUS_TEMPERATURE == memberCode) {
//		setStatusBitId(_FG_TEMP_OT, (PMBUS_STATUS_OT_FAULT|PMBUS_STATUS_OT_WARNING|PMBUS_CALL_SMBUSALERT));
	}
	// update PMB_CODE_STATUS_FANS_1_2
	else if(PMB_CODE_STATUS_FANS_1_2 == memberCode) {
//		setStatusBitId(_FG_FAN1_FAIL, (PMBUS_STATUS_FAN_1_FAULT|PMBUS_STATUS_FAN_1_WARNING|PMBUS_CALL_SMBUSALERT));
	}
	else {
		return PMBUS_ERROR_CMD_INVALID_PARAM;
	}
	
	// Clear flags or return value of register
	if(PMBus_IsWrite((PMBUS_CONTEXT)pCmdContext))
		*pStatReg &= (PMBUS_PAGE_MEMBER) ~(pBuffer[0]);
	else
		pBuffer[0] = (PMBUS_BUFFER)*pStatReg;
	
	return PMBUS_OK;
}

#define TP_VAR  PMBUS_TYPE_VARIABLE
#define TP_FUNC  PMBUS_TYPE_CALLBACK

#define FMT_BK   PMBUS_FORMAT_DATA_BLOCK
#define FMT_U8   PMBUS_FORMAT_8BIT_UNSIGNED
#define FMT_S16  PMB_CFG_FORMAT_16BIT_SIGNED
#define FMT_LD   PMBUS_FORMAT_LINEAR_DATA

#define PMBUS_CMD_00_0F() \
		PMBUS_CMD_INTERNAL    (PAGE,                    PMBUS_RW) \
		PMBUS_CMD_INTERNAL    (CLEAR_FAULTS,            PMBUS_WRITE) \
		PMBUS_CMD_INTERNAL    (PAGE_PLUS_WRITE,         PMBUS_WRITE) \
		PMBUS_CMD_INTERNAL    (PAGE_PLUS_READ,          PMBUS_READ)

#define PMBUS_CMD_10_1F() \
		PMBUS_CMD_INTERNAL    (CAPABILITY,              PMBUS_READ) \
		PMBUS_CMD_INTERNAL    (QUERY,                   PMBUS_READ) 


#define PMBUS_CMD_20_2F() \


#define PMBUS_CMD_30_3F() \
		PMBUS_CMD_SIMPLE      (FAN_CONFIG_1_2,          PMBUS_READ,    TP_VAR, &pwr.fanCfg12,          	 FMT_U8) \
		PMBUS_CMD_SIMPLE      (FAN_COMMAND_1,           PMBUS_RW,      TP_VAR, &pwr.fan1,              	 PMBUS_FORMAT_DIRECT_MODE(2))

#define PMBUS_CMD_40_4F() \
		PMBUS_CMD_SIMPLE      (IOUT_OC_WARN_LIMIT,      PMBUS_READ,    TP_VAR, &pwr.ioutOcWarnLimit,     PMBUS_FORMAT_DIRECT_MODE(1))


#define PMBUS_CMD_50_5F() \
		

#define PMBUS_CMD_60_6F() \
		

#define PMBUS_CMD_70_7F() \
		PMBUS_CMD_INTERNAL    (STATUS_WORD,          PMBUS_RW) \
		PMBUS_CMD_INTERNAL    (STATUS_VOUT,          PMBUS_RW) \
		PMBUS_CMD_INTERNAL    (STATUS_IOUT,          PMBUS_RW) \
		PMBUS_CMD_INTERNAL    (STATUS_INPUT,         PMBUS_RW) \
		PMBUS_CMD_INTERNAL    (STATUS_TEMPERATURE,   PMBUS_RW) 


#define PMBUS_CMD_80_8F() \
		PMBUS_CMD_INTERNAL    (STATUS_FANS_1_2,      PMBUS_RW) \
		PMBUS_CMD_SIMPLE      (READ_VOUT,            PMBUS_READ,     TP_FUNC, Pmbus_ReadVout,                     FMT_LD) \
		PMBUS_CMD_SIMPLE      (READ_IOUT,            PMBUS_READ,     TP_FUNC, Pmbus_ReadIout,                     FMT_LD) \
		PMBUS_CMD_SIMPLE      (READ_TEMPERATURE_1,   PMBUS_READ,     TP_FUNC, Pmbus_Read_T_SEC_C,                 FMT_LD) \
		PMBUS_CMD_SIMPLE      (READ_TEMPERATURE_2,   PMBUS_READ,     TP_FUNC, Pmbus_Read_IN_NTC_C,                FMT_LD) \
		PMBUS_CMD_SIMPLE      (READ_TEMPERATURE_3,   PMBUS_READ,     TP_FUNC, Pmbus_Read_SB_NTC_C,                FMT_LD)


#define PMBUS_CMD_90_9F() \
		PMBUS_CMD_SIMPLE      (READ_FAN_SPEED_1,     PMBUS_READ,     TP_FUNC, Pmbus_Read_FAN_RPM,                 FMT_LD) \
		PMBUS_CMD_SIMPLE      (READ_PIN ,            PMBUS_RW,       TP_VAR, &pwr.read_pin.raw,                   FMT_LD) \
		PMBUS_CMD_INTERNAL    (PMBUS_REVISION,       PMBUS_READ) \
		PMBUS_CMD_DATA_BLOCK  (MFR_ID,               PMBUS_READ,     TP_VAR, (void *)&pmb_mfr_id[0],              FMT_BK,      sizeof(pmb_mfr_id)) \
		PMBUS_CMD_DATA_BLOCK  (MFR_MODEL,            PMBUS_READ,     TP_VAR, (void *)&pmb_mfr_model[0],           FMT_BK,      sizeof(pmb_mfr_model)) \
			

#define PMBUS_CMD_A0_AF() \


#define PMBUS_CMD_B0_BF() \
		PMBUS_CMD_SIMPLE      (USER_DATA_11,         PMBUS_RW,     TP_VAR, &pwr.mfr_remote_control,               FMT_U8) \
		PMBUS_CMD_SIMPLE      (USER_DATA_12,         PMBUS_RW,     TP_VAR, &pwr.mfr_BC_delay,     	              FMT_U8)

#define PMBUS_CMD_C0_CF() \


#define PMBUS_CMD_D0_DF() \
		PMBUS_CMD_DATA_BLOCK  (MFR_FW_ID,            PMBUS_READ,   TP_VAR, (void *)&mfr_fw_id[0],                  FMT_BK,      sizeof(mfr_fw_id)) \
		PMBUS_CMD_DATA_BLOCK  (MFR_FW_REVISION,      PMBUS_READ,   TP_VAR, (void *)&mfr_fw_revision[0],            FMT_BK,      sizeof(mfr_fw_revision)) \
		PMBUS_CMD_DATA_BLOCK  (MFR_FW_DATE,          PMBUS_READ,   TP_VAR, (void *)&mfr_fw_date[0],                FMT_BK,      sizeof(mfr_fw_date)) \
		PMBUS_CMD_SIMPLE      (CONTROL_FAN_DUTY,     PMBUS_READ,   TP_VAR, (void *)&pwr.control_fan_duty,          FMT_S16) \
		PMBUS_CMD_DATA_BLOCK  (BLACK_BOX_DATA,       PMBUS_READ,   TP_VAR, (void *)&pwr.black_box_data[0],         FMT_BK,      sizeof(pwr.black_box_data)) \
		PMBUS_CMD_DATA_BLOCK  (BLACK_BOX_REAL_TIME,  PMBUS_RW,     TP_VAR, (void *)&pwr.black_box_real_time[0],    FMT_U8,      sizeof(pwr.black_box_real_time)) \
        PMBUS_CMD_SIMPLE      (BLACK_BOX_CONFIG,     PMBUS_RW,     TP_VAR, (void *)&pwr.black_box_config,          FMT_U8)
        
#define PMBUS_CMD_E0_EF() \
		PMBUS_CMD_SIMPLE      (BLACK_BOX_CLEAR ,     PMBUS_RW,     TP_VAR, (void *)&pwr.black_box_clear,           FMT_U8) 

#define PMBUS_CMD_F0_FF() \
		PMBUS_CMD_DATA_BLOCK  (BOOTLOADER_KEY,       PMBUS_RW,     TP_VAR, &pwr.bootloader_key[0],                 FMT_BK,      sizeof(pwr.bootloader_key)) \
		PMBUS_CMD_SIMPLE      (BOOTLOADER_STATUS,    PMBUS_RW,     TP_VAR, &pwr.bootloader_status,                 FMT_U8) \
		PMBUS_CMD_DATA_BLOCK  (BOOTLOADER_DATE_WRITE,PMBUS_WRITE,  TP_VAR, &pwr.bootloader_data_write[0],          FMT_BK,      sizeof(pwr.bootloader_data_write)) \
		PMBUS_CMD_DATA_BLOCK  (BOOTLOADER_PRODUCT_KEY, PMBUS_RW,   TP_VAR, &pwr.bootloader_product_key[0],         FMT_BK,      sizeof(pwr.bootloader_product_key)) \
		PMBUS_CMD_DATA_BLOCK  (ADC_DATA,             PMBUS_READ,   TP_VAR, &pwr.adc_data[0],                       FMT_BK,      sizeof(pwr.adc_data))

//table of commands in page0
PMBUS_PAGE_BEGIN(Page_0)
	PMBUS_CMD_00_0F()
	PMBUS_CMD_10_1F()
	PMBUS_CMD_20_2F()	
	PMBUS_CMD_30_3F()
	PMBUS_CMD_40_4F()
	PMBUS_CMD_50_5F()
	PMBUS_CMD_70_7F()
	PMBUS_CMD_80_8F()
	PMBUS_CMD_90_9F()
	PMBUS_CMD_A0_AF()
	PMBUS_CMD_B0_BF()
	PMBUS_CMD_C0_CF()
	PMBUS_CMD_D0_DF()
	PMBUS_CMD_E0_EF()
	PMBUS_CMD_F0_FF()
PMBUS_PAGE_END()

//table of commands in page1
PMBUS_PAGE_BEGIN(Page_1)
	PMBUS_CMD_00_0F()
	PMBUS_CMD_10_1F()
	PMBUS_CMD_20_2F()	
	PMBUS_CMD_30_3F()
	PMBUS_CMD_40_4F()
	PMBUS_CMD_50_5F()
	PMBUS_CMD_70_7F()
	PMBUS_CMD_80_8F()
	PMBUS_CMD_90_9F()
	PMBUS_CMD_A0_AF()
	PMBUS_CMD_B0_BF()
	PMBUS_CMD_C0_CF()
	PMBUS_CMD_D0_DF()
	PMBUS_CMD_E0_EF()
	PMBUS_CMD_F0_FF()
PMBUS_PAGE_END()



//callback to get value of POWER_GOOD bit in Status Word register

PMBUS_BOOL PMBus_IsPowerSupplyOn(PMBUS_INDEX index)
{
	if (index == 0)
		return 1;
	else
		return 0;
}


// callback to get value of POWER_GOOD bit in Status Word register

PMBUS_BOOL PMBus_IsPowerGood(PMBUS_INDEX index)
{
	if (index == 0)
		return 1;
	else
		return 0;
}

////example of STORE_DEFAULT_ALL or RESTORE_DEFAULT_ALL command
//
//PMBUS_ERROR_CODE Pmbus_StoreRestDefAll(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
//{
//	PMBUS_CMD_CODE cmdCode = PMBus_GetCmdCode(context);
//	PMBUS_PAGE_MEMBER* pIntVar = NULL;
//	PMBUS_PAGE_MEMBER_INDEX index;
//
//	PMBUS_UNUSED(pBuffer);
//	PMBUS_UNUSED(pSize);
//		
//	for (index = 0;index<PMBUS_INTERNAL_TABLE_SIZE;index++)
//	{
//		if(PMBus_GetIntVarByIndex(context, index, &pIntVar) == PMBUS_OK)
//		{
//			if(pIntVar)
//			{
//				if(cmdCode == PMB_CODE_RESTORE_DEFAULT_ALL)
//				{
//					//put your restore code here for PMBus internal variables
//					PMBUS_PAGE_MEMBER* pInitStr = (PMBUS_PAGE_MEMBER*)&initInternalRegs;
//					*pIntVar = pInitStr[index];
//				}
//				else if (cmdCode == PMB_CODE_STORE_DEFAULT_ALL)
//				{
//					//put your store code here for PMBus internal variables
//				}
//				else
//				{
//					return PMBUS_ERROR_CMD_NOT_FOUND;
//				}
//			}
//		}
//		else
//		{
//			break;
//		}		
//	}
//
//	if(cmdCode == PMB_CODE_RESTORE_DEFAULT_ALL)
//	{
//		//put your restore code here for Power Supply variables
//	}
//	else
//	{
//		//put your store code here for Power supply variables
//	}
//	return PMBUS_OK;
//}


//example of handling linear format (see also fan1 command for example of direct format)
//PMBUS_ERROR_CODE Pmbus_FanCommand2(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
//{
//	PMBUS_UNUSED(pSize);
//
//	//user can set Fan from 0RPM to 4095RPM
//	//internal register has valid range from 0 to 65472
//	if(PMBus_IsRead(context))
//	{
//		//converts 2^16 to 2^10 because 2^10 is max val of mantissa
//		UWord16 mantissa = pwr.fan2>>6; 
//		// add exponent = 2, because 2^10 represents value 4096RPM
//		mantissa |= 2<<11; 
//		pBuffer[0] = (UWord8)mantissa;
//		pBuffer[1] = (UWord8)(mantissa>>8);		
//	}
//	else
//	{
//		//mantissa includes number from 0 to 1023
//		UWord16 mantissa = (UWord16)((pBuffer[0] | (pBuffer[1]<<8))&0x3ff);
//		UWord8 exponent = (UWord8)(pBuffer[1] >> 3);
//
//		//if exponent is negative, fix the negative number
//		if(exponent&0x10)
//			exponent |= 0xf0;
//
//		//65536/4096 = 16 -> add 4 to exponent
//		exponent += 4;
//		
//		//todo check if value of mantissa<<exponent is not bigger than 2^16
//		//converts 0-1023 to 0-65472
//		pwr.fan2 = mantissa<<exponent;
//	}
//	return PMBUS_OK;
//}
//PMBUS_CMD_SIMPLE      (FAN_COMMAND_2,  PMBUS_RW,   PMBUS_TYPE_CALLBACK, Pmbus_FanCommand2, PMBUS_FORMAT_LINEAR_DATA)


//PMBUS_ERROR_CODE Pmbus_VoutCommand(PMBUS_CONTEXT context, PMBUS_BUFFER* pBuffer, PMBUS_SIZE* pSize)
//{
//	PMBUS_BUFFER voutMode = (PMBUS_BUFFER)(PMBus_GetVoutMode(context)&PMBUS_VOUT_MODE_CFG_MASK);
//	PMBUS_UNUSED(pSize);
//
//	switch (voutMode)
//	{
//		case PMBUS_VOUT_MODE_CFG_DIRECT_MODE:
//		{
//			if(PMBus_IsWrite (context))
//			{
//				pwr.voutCommand = (UWord16)(pBuffer[0] | (pBuffer[1]<<8));
//			}
//			else
//			{
//				pBuffer[0] = (PMBUS_BUFFER)pwr.voutCommand;
//				pBuffer[1] = (PMBUS_BUFFER)(pwr.voutCommand>>8);
//			}
//			break;
//		}
//		case PMBUS_VOUT_MODE_CFG_LINEAR_DATA:
//		{
//			PMBUS_BUFFER voutExponent = (PMBUS_BUFFER)(PMBus_GetVoutMode(context)&PMBUS_VOUT_MODE_EXP_MASK);
//			//if exponent is negative, fix the negative number
//			if(voutExponent&0x10)
//				voutExponent |= 0xf0;
//			
//			//for example power supply can set output voltage from 0V to 512V
//			//internal register has valid range from 0 to 32768
//
//			//32768/512 = 64-> add 6 to exponent to convert Real World number to Power Supply register
//			voutExponent += 6;
//			
//			if(PMBus_IsWrite (context))
//			{
//				UWord16 voutMantissa = (UWord16)(pBuffer[0] | (pBuffer[1]<<8));
//				pwr.voutCommand = voutMantissa<<voutExponent;
//			}
//			else
//			{
//				UWord16 voutMantissa = pwr.voutCommand>>voutExponent;
//				pBuffer[0] = (PMBUS_BUFFER)(voutMantissa&0xff);
//				pBuffer[1] = (PMBUS_BUFFER)(voutMantissa>>8);
//			}
//			
//			//todo calculate right value
//			break;
//		}
//		case PMBUS_VOUT_MODE_CFG_VID:
//		{
//			if((PMBus_GetVoutMode(context)&PMBUS_VOUT_MODE_EXP_MASK) == 0x1E)
//			{
//				//for example VID uses simple conversion
//				if(PMBus_IsWrite (context))
//				{
//					pwr.voutCommand = (UWord16)((pBuffer[0] | (pBuffer[1]<<8))<1);
//				}
//				else
//				{
//					pBuffer[0] = (UWord8)(pwr.voutCommand>1);
//					pBuffer[1] = (UWord8)(pwr.voutCommand>>9);
//				}
//			}
//			else
//			{
//				return PMBUS_ERROR_CMD_INVALID_PARAM;
//			}
//			break;
//		}
//	}
//
//	return PMBUS_OK;
//}
//PMBUS_CMD_SIMPLE      (VOUT_COMMAND,   PMBUS_RW,   PMBUS_TYPE_CALLBACK, Pmbus_VoutCommand, PMBUS_FORMAT_LINEAR_DATA|PMBUS_FORMAT_DIRECT_MODE(0)|PMBUS_FORMAT_VID_MODE)

void initPWR_VARIABLES(PWR_VARIABLES * p)
{
	p->mfr_remote_control = 0;
	p->mfr_BC_delay = 10;
}

void initInternalRegisters(PMBUS_INDEX pageIndex)
{
	PMBUS_PAGE_MEMBER_INDEX index;
	PMBUS_PAGE_MEMBER* pIntVar = NULL;
	PMBUS_PAGE_MEMBER* pInitStr = (PMBUS_PAGE_MEMBER*)&initInternalRegs;

		//Initialize internal PMBus registers
	for (index = 0;index<PMBUS_INTERNAL_TABLE_SIZE;index++)
	{
		if(PMBus_GetPageIntVarByIndex(pageIndex, index, &pIntVar) == PMBUS_OK)
		{
			if(pIntVar)
			{
				*pIntVar = pInitStr[index];
			}
		}
		else
		{
			break;
		}
	}
}

void PWR_Init(void)
{	
	//put your power supply initialization code here
	initPWR_VARIABLES(&pwr);
	
	initInternalRegisters(0);
	initInternalRegisters(1);

}


void PWR_Poll(void)
{
	
}
