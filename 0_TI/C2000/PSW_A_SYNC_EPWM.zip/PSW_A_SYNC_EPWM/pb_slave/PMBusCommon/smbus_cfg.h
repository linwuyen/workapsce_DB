/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2012 Freescale Semiconductor
* ALL RIGHTS RESERVED.
*
****************************************************************************//*!
*
* @file   smbus_cfg.h
*
* @brief  SMBus configuration header file
*
* @version 2.0
* 
* @date 2021/06/19
* 
*******************************************************************************/

#ifndef __SMBUS_CFG_H
#define __SMBUS_CFG_H

/******************************************************************************
* Select interrupt or poll-driven serial communication
******************************************************************************/
#define SMBCFG_POLL_DRIVEN      1                /* select poll mode */
#define SMBCFG_INTERRUPT_DRIVEN 0                /* select interrupt mode */

/*****************************************************************************
* Select and configure communication interface
******************************************************************************/
#define SMBCFG_SLAVE_BASE_IIC   0x7300      /* base address of IIC module  &I2C1 */
#define SMBCFG_SLAVE_ADDR       0x58            /* address of IIC Slave */
#define SMBCFG_EOF              0xff            /* defines EOF byte */

/*****************************************************************************
* Configure SMBUs stack
******************************************************************************/
#define SMBCFG_BUFFER_SIZE      64              /* define size of buffer */
#define SMBCFG_DEBUG            1               /* enable/disable debug mode */

#define SMBCFG_SLAVE_TIMEOUT    3000

#endif /* __SMBUS_CFG_H */
