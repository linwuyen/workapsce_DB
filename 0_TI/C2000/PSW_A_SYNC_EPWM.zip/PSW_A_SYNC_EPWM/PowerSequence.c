/*
 * PowerSequence.c
 *
 *  Created on: 2022�~3��24��
 *      Author: cody_chen
 */


#include "PowerSequence.h"
#include "initPWM.h"


void initPower(HAL_DRV s) {

    s->sTestRef.blCountMode = false;
    s->sTestRef.f32Out = -1.0f;
    s->sTestRef.f32Target1 = 1.0f;
    s->sTestRef.f32Target2 = -1.0f;
    s->sTestRef.f32Step1 = 0.001f;
    s->sTestRef.f32Step2 = 0.001f;
    s->sTestRef.f32HighLimit = 1.0f;
    s->sTestRef.f32LowLimit = -1.0f;




    s->sVloop.sPI.f32Ki = 0.00001f;
    s->sVloop.sPI.f32Kp = 0.01;
    s->sVloop.sPI.f32Min = -1.0f;
    s->sVloop.sPI.f32Max = 1.0f;
    s->sVloop.sPI.f32Itemp = -1.0;
    s->sVloop.sPI.blStopUi = false;

    s->sIloop.sPI.f32Ki = 0.00001f;
    s->sIloop.sPI.f32Kp = 0.01;
    s->sIloop.sPI.f32Min = -1.0f;
    s->sIloop.sPI.f32Max = 1.0f;
    s->sIloop.sPI.f32Itemp = -1.0;
    s->sIloop.sPI.blStopUi = false;

    FG_SETCLA(_CLA_INIT_SUCCESS);


}



#ifdef _FLASH
#pragma CODE_SECTION(execPowerSequence, ".TI.ramfunc");
#endif //_FLASH
void execPowerSequence(HAL_DRV s) {
//    DEBUG_IO_HI;
    execRampUpDwon(&s->sTestRef);



//    DEBUG_IO_LO;

}
