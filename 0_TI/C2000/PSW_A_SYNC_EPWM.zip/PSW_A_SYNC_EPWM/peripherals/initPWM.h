/*
 * initPWM.h
 *
 *  Created on: 2022�~3��17��
 *      Author: cody_chen
 */

#ifndef PERIPHERALS_INITPWM_H_
#define PERIPHERALS_INITPWM_H_

#include "common.h"
#include "SFO_V8.h"

extern void initPWM(void);


#endif /* PERIPHERALS_INITPWM_H_ */
