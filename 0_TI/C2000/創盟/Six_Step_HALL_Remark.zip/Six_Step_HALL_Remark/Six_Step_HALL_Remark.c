    // Included Files
#include "f28x_project.h"

    // Defines
#define EPWM_TIMER_TBPRD 2000
#define EPWM1_MIN_CMPA 1000

    // Globals
//uint16_t adcAResults[RESULTS_BUFFER_SIZE];   // Buffer for results
//uint16_t index;                              // Index into result buffer
//volatile uint16_t bufferFull;                // Flag to indicate buffer is full

    // Function Prototypes
void InitEPWM1(void);
void InitEPWM2(void);
void InitEPWM3(void);
void EPWM1_ISR_remark(void);
void EPWM2_ISR_remark(void);
void EPWM3_ISR_remark(void);

    // Main
void main(void)
{
    // Initialize device clock and peripherals
    InitSysCtrl();

    // Initialize GPIO
    InitGpio();

    // Disable CPU interrupts
    DINT;

    // Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    InitPieCtrl();

    // Disable CPU interrupts and clear all CPU interrupt flags:
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    InitPieVectTable();
    EALLOW;
    PieVectTable.EPWM1_INT = &EPWM1_ISR_remark;
    PieVectTable.EPWM2_INT = &EPWM2_ISR_remark;
    PieVectTable.EPWM3_INT = &EPWM3_ISR_remark;
    EDIS;

    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    EDIS;

    InitEPWM1();

    // Sync ePWM
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;

    // Enable global Interrupts and higher priority real-time debug events:
    IER |= M_INT3;  // Enable group 3 interrupts

    EINT;           // Enable Global interrupt INTM
    ERTM;           // Enable Global realtime interrupt DBGM


    // Enable PIE interrupt
    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;

    // Take conversions indefinitely in loop
    while(1)
    {

    }
}

void InitEPWM1(void){
    EALLOW;
    GpioCtrlRegs.GPAPUD.bit.GPIO0=1;    // Disable pull-up on GPIO0 EPWM1A
    GpioCtrlRegs.GPAPUD.bit.GPIO1=1;    // Disable pull-up on GPIO1 EPWM1B

    GpioCtrlRegs.GPAGMUX1.bit.GPIO0=1;  // GPIO0 = EPWM1A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO1=1;  // GPIO1 = EPWM1B
    EDIS;

    // Setup TBCLK
    EPwm1Regs.TBPRD = EPWM_TIMER_TBPRD; // Set timer period
    EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;  // Count Up
    EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE; // Disable phase loading
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV2;    // Clock ratio to SYSCLKOUT
    EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV2;   // TBCLK = SYSCLKOUT(2*2)
    EPwm1Regs.TBPHS.all = 0x0000;    // Phase is 0
    EPwm1Regs.TBCTR = 0x0000;

    // Setup Shadow Register load on ZERO
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW; // Start Shadow CMP
    EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO; // CTR = Zero

    // Set Compare Values
    EPwm1Regs.CMPA.bit.CMPA = EPWM1_MIN_CMPA;    // Set Compare A Value
//        .CMPB.bit.CMPB

    // Set Actions
    EPwm1Regs.AQCTLA.bit.ZRO = AQ_SET;  // Set PWM1A On Zero
    EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;    // Clear PWM1A On Event A ,Up
 //        .AQCTLB.bit.ZRO=AQ_SET;
 //        .AQCTLB.bit.CAU=AQ_CLEAR;

//    //Set Dead Band
//    EPwm1Regs.DBCTL.bit.IN_MODE=2; // EPWMA = UP EPWMB =DOWN
//    EPwm1Regs.DBCTL.bit.POLSEL=2;   //EPWMB Reverse
//    EPwm1Regs.DBCTL.bit.OUT_MODE=3; //UP DOWN DALEY
//    EPwm1Regs.DBRED=75; //DB Time 1us
//    EPwm1Regs.DBFED=75;

    // Interrupt where we will change the Compare Values
    EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;   // Select INT on Zero event
    EPwm1Regs.ETSEL.bit.INTEN = 1;  // Enable INT
    EPwm1Regs.ETPS.bit.INTPRD = ET_3RD; //Generate INT on 3rd event

    //Duty cycle 1000/2000*100% =50%
}
void InitEPWM2(void){
    EALLOW;
    GpioCtrlRegs.GPAPUD.bit.GPIO2=1;    // Disable pull-up on GPIO2 EPWM2A
    GpioCtrlRegs.GPAPUD.bit.GPIO3=1;    // Disable pull-up on GPIO3 EPWM2B

    GpioCtrlRegs.GPAGMUX1.bit.GPIO2=1;  // GPIO2 = EPWM2A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO3=1;  // GPIO3 = EPWM2B
    EDIS;

    // Setup TBCLK
    EPwm2Regs.TBPRD = EPWM_TIMER_TBPRD; // Set timer period
    EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;  // Count Up
    EPwm2Regs.TBCTL.bit.PHSEN = TB_DISABLE; // Disable phase loading
    EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV2;    // Clock ratio to SYSCLKOUT
    EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV2;   // TBCLK = SYSCLKOUT(2*2)
    EPwm2Regs.TBPHS.all = 0x0000;    // Phase is 0
    EPwm2Regs.TBCTR = 0x0000;

    // Setup Shadow Register load on ZERO
    EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW; // Start Shadow CMP
    EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO; // CTR = Zero

    // Set Compare Values
    EPwm2Regs.CMPA.bit.CMPA = EPWM1_MIN_CMPA;    // Set Compare A Value
    //        .CMPB.bit.CMPB

    // Set Actions
    EPwm2Regs.AQCTLA.bit.ZRO = AQ_SET;  // Set PWM1A On Zero
    EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;    // Clear PWM1A On Event A ,Up
 //        .AQCTLB.bit.ZRO=AQ_SET;
 //        .AQCTLB.bit.CAU=AQ_CLEAR;

//    //Set Dead Band
//    EPwm1Regs.DBCTL.bit.IN_MODE=2; // EPWMA = UP EPWMB =DOWN
//    EPwm1Regs.DBCTL.bit.POLSEL=2;   //EPWMB Reverse
//    EPwm1Regs.DBCTL.bit.OUT_MODE=3; //UP DOWN DALEY
//    EPwm1Regs.DBRED=75; //DB Time 1us
//    EPwm1Regs.DBFED=75;

    // Interrupt where we will change the Compare Values
    EPwm2Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;   // Select INT on Zero event
    EPwm2Regs.ETSEL.bit.INTEN = 1;  // Enable INT
    EPwm2Regs.ETPS.bit.INTPRD = ET_3RD; //Generate INT on 3rd event

    //Duty cycle 1000/2000*100% =50%
}
void InitEPWM3(void){
    EALLOW;
    GpioCtrlRegs.GPAPUD.bit.GPIO4=1;    // Disable pull-up on GPIO4 EPWM3A
    GpioCtrlRegs.GPAPUD.bit.GPIO5=1;    // Disable pull-up on GPIO5 EPWM3B

    GpioCtrlRegs.GPAGMUX1.bit.GPIO4=1;  // GPIO4 = EPWM3A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO5=1;  // GPIO5 = EPWM3B
    EDIS;

    // Setup TBCLK
    EPwm3Regs.TBPRD = EPWM_TIMER_TBPRD; // Set timer period
    EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;  // Count Up
    EPwm3Regs.TBCTL.bit.PHSEN = TB_DISABLE; // Disable phase loading
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV2;    // Clock ratio to SYSCLKOUT
    EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV2;   // TBCLK = SYSCLKOUT(2*2)
    EPwm3Regs.TBPHS.all = 0x0000;    // Phase is 0
    EPwm3Regs.TBCTR = 0x0000;

    // Setup Shadow Register load on ZERO
    EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW; // Start Shadow CMP
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO; // CTR = Zero

    // Set Compare Values
    EPwm3Regs.CMPA.bit.CMPA = EPWM1_MIN_CMPA;    // Set Compare A Value

    // Set Actions
    EPwm3Regs.AQCTLA.bit.ZRO = AQ_SET;  // Set PWM1A On Zero
    EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;    // Clear PWM1A On Event A ,Up

//    //Set Dead Band
//    EPwm1Regs.DBCTL.bit.IN_MODE=2; // EPWMA = UP EPWMB =DOWN
//    EPwm1Regs.DBCTL.bit.POLSEL=2;   //EPWMB Reverse
//    EPwm1Regs.DBCTL.bit.OUT_MODE=3; //UP DOWN DALEY
//    EPwm1Regs.DBRED=75; //DB Time 1us
//    EPwm1Regs.DBFED=75;

    // Interrupt where we will change the Compare Values
    EPwm3Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;   // Select INT on Zero event
    EPwm3Regs.ETSEL.bit.INTEN = 1;  // Enable INT
    EPwm3Regs.ETPS.bit.INTPRD = ET_3RD; //Generate INT on 3rd event

    //Duty cycle 1000/2000*100% =50%
}
void EPWM1_ISR_remark(void){

// Clear INT flag for this timer
    EPwm1Regs.ETCLR.bit.INT=1;
// Acknowledge this interrupt to receive more interrupts from group3
    PieCtrlRegs.PIEACK.all=PIEACK_GROUP3;
}
void EPWM2_ISR_remark(void){

// Clear INT flag for this timer
    EPwm1Regs.ETCLR.bit.INT=1;
// Acknowledge this interrupt to receive more interrupts from group3
    PieCtrlRegs.PIEACK.all=PIEACK_GROUP3;
}
void EPWM3_ISR_remark(void){

// Clear INT flag for this timer
    EPwm1Regs.ETCLR.bit.INT=1;
// Acknowledge this interrupt to receive more interrupts from group3
    PieCtrlRegs.PIEACK.all=PIEACK_GROUP3;
}
// End of File
//
