/*
 * SPI_Master.h
 *
 *  Created on: Apr 30, 2024
 *      Author: roger_lin
 */

#ifndef SPI_MASTER_H_
#define SPI_MASTER_H_

#define SIZE_OF_SPIFIFO      64
#define SPI_TIMEOUT          T_50US

typedef enum
{
    _SEND_SPI_PACK = (0x00000001 << 0),
    _RECEIVE_SPI_PACK = (0x00000001 << 1),
    _CLEAR_SPI_PACK = (0x00000001 << 4),
    _MARK_ERROR_SPI_PACK = (0x80000000)
} FSM_SPI_MASTER;

typedef enum
{
    _NO_SPI_COMMMAND = 0,
    _CMD_RESERVED0 = (0x01 << 0),
    _CMD_RESERVED1 = (0x01 << 1),
    _CMD_RESERVED2 = (0x01 << 2),
    _CMD_RESERVED3 = (0x01 << 3),
    _CMD_ACCESS_32BITS = (0x01 << 4),
    _CMD_WRITE_32BITS = _CMD_ACCESS_32BITS + 1,
    _CMD_SEND_READ_HEADER = _CMD_ACCESS_32BITS + 2,
    _CMD_GET_READ_32BITS = _CMD_ACCESS_32BITS + 3,
    _CMD_RESERVED5 = (0x01 << 5),
    _CMD_RESERVED6 = (0x01 << 6)
} REG_SPICMD;

typedef union
{
    uint32_t u32All[2];
    uint16_t Dword[4];

    struct
    {
        uint32_t u32Data :32;
        uint32_t u32Addr :8;
        uint32_t u32Remote :1;  //0: Write, 1:Read
        uint32_t u32Id :7;
        uint32_t u32Chksum :16;
    } bits;

    struct
    {
        uint32_t W0 :16;
        uint32_t W1 :16;
        uint32_t W2 :16;
        uint32_t W3 :16;
    } words;

    struct
    {
        uint32_t u32Data :32;
        uint32_t u32Addr :8;
        uint32_t u32Cmd :8;
        uint32_t u32Chksum :16;
    };
} REG_SPIPACK;
typedef REG_SPIPACK *HAL_SPIPACK;

typedef struct
{
    FSM_SPI_MASTER u32Fsm;
    REG_SPIPACK regFiFo[SIZE_OF_SPIFIFO];
    uint16_t u16Push;
    uint16_t u16Pop;
    uint32_t u32Timeout;
    uint32_t u32TimeStamp;
    uint32_t u32TimeMark;

    uint32_t u32IDAddr;

    REG_SPIPACK rxTemp;
    uint32_t u32ErrCnts;
    uint32_t u32OkCnts;
    int16_t s16Wsize;
    int16_t s16Rsize;

} ST_SPI_MASTER;
typedef ST_SPI_MASTER *HAL_SPI_MASTER;

static inline void wrSpiData(uint16_t u16Data)
{
    SPI_writeDataBlockingFIFO(SPIA_MASTER_BASE, u16Data);
}

static inline uint16_t rdSpiData(void)
{
    return SPI_readDataNonBlocking(SPIA_MASTER_BASE);
}

static inline uint16_t isRxEmpty(void)
{
    return (SPI_FIFO_RXEMPTY != SPI_getRxFIFOStatus(SPIA_MASTER_BASE));
}

static inline void pushSpiWpack(uint32_t addr, uint32_t *pdata, HAL_SPI_MASTER v)
{
    HAL_SPIPACK p = &v->regFiFo[v->u16Push];
    p->bits.u32Id = _CMD_WRITE_32BITS;
    p->bits.u32Remote = 0;
    p->bits.u32Addr = addr;
    p->bits.u32Data = pdata[addr];
    p->bits.u32Chksum = p->words.W0 + p->words.W1 + p->words.W2;
    v->u16Push++;
    if (SIZE_OF_SPIFIFO == v->u16Push)
        v->u16Push = 0;
}

static inline void pushSpiRheader(uint32_t addr, uint32_t *pdata,
                                  HAL_SPI_MASTER v)
{
    HAL_SPIPACK p = &v->regFiFo[v->u16Push];
    p->bits.u32Id = _CMD_SEND_READ_HEADER;
    p->bits.u32Remote = 1;
    p->bits.u32Addr = addr;
    p->bits.u32Data = (uint32_t) & pdata[addr];
    p->bits.u32Chksum = p->words.W2;
    v->u16Push++;
    if (SIZE_OF_SPIFIFO == v->u16Push)
        v->u16Push = 0;
}

static inline void pushSpiRdata(uint32_t addr, uint32_t *pdata,
                                HAL_SPI_MASTER v)
{
    HAL_SPIPACK p = &v->regFiFo[v->u16Push];
    p->bits.u32Id = _CMD_GET_READ_32BITS;
    p->bits.u32Remote = 1;
    p->bits.u32Addr = addr;
    p->bits.u32Data = (uint32_t) & pdata[addr];
    p->bits.u32Chksum = p->words.W0 + p->words.W1 + p->words.W2;
    v->u16Push++;
    if (SIZE_OF_SPIFIFO == v->u16Push)
        v->u16Push = 0;
}

static inline void pushSpiRpack(uint32_t addr, uint32_t *pdata,
                                HAL_SPI_MASTER v)
{
    pushSpiRheader(addr, pdata, v);
    pushSpiRdata(addr, pdata, v);
}

static inline int16_t wrSpiPack(HAL_SPIPACK p)
{
    switch (p->bits.u32Id)
    {
    case _CMD_WRITE_32BITS:
    case _CMD_GET_READ_32BITS:
        wrSpiData(p->words.W3);
        wrSpiData(p->words.W2);
        wrSpiData(p->words.W1);
        wrSpiData(p->words.W0);
        return 4;
    case _CMD_SEND_READ_HEADER:
        wrSpiData(p->words.W3);
        wrSpiData(p->words.W2);
        return 2;

    default:
        return 0;
    }
}

static inline void popSpiWdata(HAL_SPI_MASTER v)
{
    if (v->u16Pop != v->u16Push)
    {
        switch (v->u32Fsm)
        {
        case _SEND_SPI_PACK:
            if (0 == v->u32TimeMark)
            {
                v->s16Wsize = wrSpiPack((HAL_SPIPACK) &v->regFiFo[v->u16Pop]);
                if (0 < v->s16Wsize)
                {
                    v->u32TimeMark = v->u32TimeStamp = U32_UPCNTS;
                    v->s16Rsize = 0;
                    switch (v->regFiFo[v->u16Pop].bits.u32Id)
                    {
                    case _CMD_WRITE_32BITS:
                    case _CMD_SEND_READ_HEADER:
                        v->u32Fsm = _CLEAR_SPI_PACK;
                        break;
                    case _CMD_GET_READ_32BITS:
                        v->u32Fsm = _RECEIVE_SPI_PACK;
                        break;

                    default:
                        break;
                    }
                }
                else
                {
                    v->u16Pop++;
                    v->u32ErrCnts++;
                    v->u32Fsm |= _MARK_ERROR_SPI_PACK;
                }
            }
            break;

        case _CLEAR_SPI_PACK:
            if (0 < v->s16Wsize)
            {
                while (isRxEmpty())
                {
                    rdSpiData();
                    v->u32TimeMark = v->u32TimeStamp = U32_UPCNTS;
                    v->s16Wsize--;
                    if (0 == v->s16Wsize)
                        break;
                }
            }
            else
            {
                v->rxTemp = v->regFiFo[v->u16Pop]; //Make a copy
                v->u32OkCnts++; //Count the number of success
                v->u16Pop++;
                if (SIZE_OF_SPIFIFO == v->u16Pop)
                    v->u16Pop = 0;
                //v->u32TimeMark = 0;
                v->u32Fsm = _SEND_SPI_PACK;
            }
            break;

        case _RECEIVE_SPI_PACK:
            if (v->s16Rsize < v->s16Wsize)
            {
                while (isRxEmpty())
                {
                    v->rxTemp.Dword[v->s16Rsize++] = rdSpiData();
                    v->u32TimeMark = v->u32TimeStamp = U32_UPCNTS;
                    if (v->s16Rsize == v->s16Wsize)
                        break;
                }
            }
            else
            {
                v->rxTemp.words.W3 -= (v->rxTemp.words.W2 + v->rxTemp.words.W1+ v->rxTemp.words.W0);

                if (0 == v->rxTemp.bits.u32Chksum)
                {
                    *((uint32_t*) v->regFiFo[v->u16Pop].bits.u32Data) =v->rxTemp.bits.u32Data;
                    v->u32OkCnts++;
                }
                else
                {
                    v->u32ErrCnts++;
                }

                v->u16Pop++;
                if (SIZE_OF_SPIFIFO == v->u16Pop)
                    v->u16Pop = 0;
                //v->u32TimeMark = 0;
                v->u32Fsm = _SEND_SPI_PACK;
            }
            break;

        default:
            break;
        }

        if (0 != v->u32TimeMark)
        {
            v->u32TimeStamp = U32_UPCNTS;

            if (v->u32TimeMark > v->u32TimeStamp)
            {
                v->u32Timeout = v->u32TimeStamp + SW_TIMER - v->u32TimeMark;
            }
            else
            {
                v->u32Timeout = v->u32TimeStamp - v->u32TimeMark;
            }

            if (v->u32Timeout >= SPI_TIMEOUT)
            {
                v->u32TimeMark = 0;
                v->s16Rsize = v->s16Wsize = 0;

            }
        }
    }
}

#endif /* SPI_MASTER_H_ */
