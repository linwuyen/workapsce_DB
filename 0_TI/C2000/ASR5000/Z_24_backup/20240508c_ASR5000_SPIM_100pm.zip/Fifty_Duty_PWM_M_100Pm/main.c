// Included Files
//## PWM SETTING MOVE common.h

#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"
#include "common.h"
#include "SPI_Master.h"
#include <math.h>

uint16_t u16AdcBuf;
const char chararray[] = "Hello world";

uint32_t u32Test[5] = { 0x00000000, 0x11223344, 0x55667788, 0x12345678,
                        0x98765432 };

uint16_t u16Action = 0;
uint16_t u16Command = 1;

ST_SPI_MASTER sSpiM = { .u32Fsm = _SEND_SPI_PACK, .u16Pop = 0, .u16Push = 0,
                        .u32Timeout = 0, .u32TimeStamp = 0, .u32TimeMark = 0,
                        .u32ErrCnts = 0, .u32OkCnts = 0, };

void task25msec(void *s)
{
//Transmit data
//   SPI_writeDataNonBlocking(SPIA_MASTER_BASE, u16AdcBuf);
//   u16c_rData = SPI_readDataNonBlocking(SPIA_MASTER_BASE);
    GPIO_togglePin(myGPIO31);
}

void task1msec(void *s)
{
    if (0 == u16Action)
    {
        u16Action = u16Command;
        u16Command++;
        u32Test[0] = u32Test[1];
        u32Test[1] = u32Test[2];
        u32Test[2] = u32Test[3];
        u32Test[3] = u32Test[4];
        u32Test[4] = u32Test[0];
        if (4 == u16Command)
            u16Command = 1;
    }
}

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = { { task1msec, 0, T_1MS }, { task25msec, 0, T_25MS },
                            { 0, 0, 0 } };

void scanSpiAction(void)
{
    switch (u16Action)
    {
    case 1:
        pushSpiWpack(0x1, u32Test, &sSpiM);
        u16Action = 0;
        break;
    case 2:
        pushSpiWpack(0x2, u32Test, &sSpiM);
        u16Action = 0;
        break;

    case 3:
        pushSpiRpack(0x3, u32Test, &sSpiM);
        u16Action = 0;
        break;

    case 4:
        pushSpiRpack(0x4, u32Test, &sSpiM);
        u16Action = 0;
        break;

    default:
        popSpiWdata(&sSpiM);
        break;

    }
}

__interrupt void INT_myADC0_1_ISR(void)
{
    u16AdcBuf = ADC_readResult(myADC0_RESULT_BASE, myADC0_SOC0);

    DAC_setShadowValue(myDAC0_BASE, u16AdcBuf);

    Interrupt_clearACKGroup(INT_myADC0_1_INTERRUPT_ACK_GROUP);
    ADC_clearInterruptStatus(myADC0_BASE, ADC_INT_NUMBER1);
}

//
// Main
//
void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();
    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();
    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();
    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();
    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
    init_PWM_0();
    init_PWM_180();
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    SCI_writeCharArray(DEBUG_SCI_BASE, (const uint16_t*) chararray,
                       sizeof(chararray));
    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    while (1)
    {
        scanTimeTask(&time_task[id_ttask++], (void*) 0);
        if (0 == time_task[id_ttask].fn)
            id_ttask = 0;

        scanSpiAction();
    }
}

//
// End of File
//
