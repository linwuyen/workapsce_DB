/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************
//
// AIO227 - GPIO Settings
//
#define GPIO_PIN_AIO227 227
#define FANFAIL1_AIO_PIN_CONFIG GPIO_227_GPIO227
//
// AIO237 - GPIO Settings
//
#define GPIO_PIN_AIO237 237
#define DCOVP_AIO_PIN_CONFIG GPIO_237_GPIO237
//
// AIO239 - GPIO Settings
//
#define GPIO_PIN_AIO239 239
#define PFC_UVP_AIO_PIN_CONFIG GPIO_239_GPIO239

//
// EPWM2 -> CLK180_5 Pinmux
//
//
// EPWM2_A - GPIO Settings
//
#define GPIO_PIN_EPWM2_A 2
#define CLK180_5_EPWMA_GPIO 2
#define CLK180_5_EPWMA_PIN_CONFIG GPIO_2_EPWM2_A

//
// EPWM1 -> CLK0_5 Pinmux
//
//
// EPWM1_A - GPIO Settings
//
#define GPIO_PIN_EPWM1_A 0
#define CLK0_5_EPWMA_GPIO 0
#define CLK0_5_EPWMA_PIN_CONFIG GPIO_0_EPWM1_A
//
// GPIO31 - GPIO Settings
//
#define toggleLED_GPIO_PIN_CONFIG GPIO_31_GPIO31
//
// GPIO1 - GPIO Settings
//
#define PFCOTP_GPIO_PIN_CONFIG GPIO_1_GPIO1
//
// GPIO7 - GPIO Settings
//
#define ACFAIL5_GPIO_PIN_CONFIG GPIO_7_GPIO7
//
// GPIO10 - GPIO Settings
//
#define PFC_OVP_GPIO_PIN_CONFIG GPIO_10_GPIO10
//
// GPIO12 - GPIO Settings
//
#define FANFAIL3_GPIO_PIN_CONFIG GPIO_12_GPIO12
//
// GPIO13 - GPIO Settings
//
#define FANFAIL2_GPIO_PIN_CONFIG GPIO_13_GPIO13
//
// GPIO33 - GPIO Settings
//
#define FANFAIL4_GPIO_PIN_CONFIG GPIO_33_GPIO33

//
// OUTPUTXBAR3 -> myOUTPUTXBAR0 Pinmux
//
//
// OUTPUTXBAR3 - GPIO Settings
//
#define GPIO_PIN_OUTPUTXBAR3 14
#define myOUTPUTXBAR0_OUTPUTXBAR_GPIO 14
#define myOUTPUTXBAR0_OUTPUTXBAR_PIN_CONFIG GPIO_14_OUTPUTXBAR3

//
// SCIA -> DEBUG_SCI Pinmux
//
//
// SCIA_RX - GPIO Settings
//
#define GPIO_PIN_SCIA_RX 28
#define DEBUG_SCI_SCIRX_GPIO 28
#define DEBUG_SCI_SCIRX_PIN_CONFIG GPIO_28_SCIA_RX
//
// SCIA_TX - GPIO Settings
//
#define GPIO_PIN_SCIA_TX 29
#define DEBUG_SCI_SCITX_GPIO 29
#define DEBUG_SCI_SCITX_PIN_CONFIG GPIO_29_SCIA_TX

//
// SPIA -> SPIA_SLAVE Pinmux
//
//
// SPIA_PICO - GPIO Settings
//
#define GPIO_PIN_SPIA_PICO 16
#define SPIA_SLAVE_SPIPICO_GPIO 16
#define SPIA_SLAVE_SPIPICO_PIN_CONFIG GPIO_16_SPIA_SIMO
//
// SPIA_POCI - GPIO Settings
//
#define GPIO_PIN_SPIA_POCI 17
#define SPIA_SLAVE_SPIPOCI_GPIO 17
#define SPIA_SLAVE_SPIPOCI_PIN_CONFIG GPIO_17_SPIA_SOMI
//
// SPIA_CLK - GPIO Settings
//
#define GPIO_PIN_SPIA_CLK 9
#define SPIA_SLAVE_SPICLK_GPIO 9
#define SPIA_SLAVE_SPICLK_PIN_CONFIG GPIO_9_SPIA_CLK
//
// SPIA_PTE - GPIO Settings
//
#define GPIO_PIN_SPIA_PTE 11
#define SPIA_SLAVE_SPIPTE_GPIO 11
#define SPIA_SLAVE_SPIPTE_PIN_CONFIG GPIO_11_SPIA_STE

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
#define CV_AD_BASE ADCA_BASE
#define CV_AD_RESULT_BASE ADCARESULT_BASE
#define CV_AD_SOC0 ADC_SOC_NUMBER0
#define CV_AD_FORCE_SOC0 ADC_FORCE_SOC0
#define CV_AD_SAMPLE_WINDOW_SOC0 80
#define CV_AD_TRIGGER_SOURCE_SOC0 ADC_TRIGGER_EPWM2_SOCA
#define CV_AD_CHANNEL_SOC0 ADC_CH_ADCIN10
void CV_AD_init();

#define MCP3301_BASE ADCC_BASE
#define MCP3301_RESULT_BASE ADCCRESULT_BASE
#define MCP3301_SOC1 ADC_SOC_NUMBER1
#define MCP3301_FORCE_SOC1 ADC_FORCE_SOC1
#define MCP3301_SAMPLE_WINDOW_SOC1 80
#define MCP3301_TRIGGER_SOURCE_SOC1 ADC_TRIGGER_SW_ONLY
#define MCP3301_CHANNEL_SOC1 ADC_CH_ADCIN2
void MCP3301_init();


//*****************************************************************************
//
// AIO Configurations
//
//*****************************************************************************
#define FANFAIL1 227
void FANFAIL1_init();
#define DCOVP 237
void DCOVP_init();
#define PFC_UVP 239
void PFC_UVP_init();

//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// CMPSS Configurations
//
//*****************************************************************************
#define DAC7612_BASE CMPSS1_BASE
#define DAC7612_HIGH_COMP_BASE CMPSS1_BASE    
#define DAC7612_LOW_COMP_BASE CMPSS1_BASE    
void DAC7612_init();

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
#define SWTIRMER_BASE CPUTIMER0_BASE
void SWTIRMER_init();

//*****************************************************************************
//
// DAC Configurations
//
//*****************************************************************************
#define CC_DA_BASE DACA_BASE
void CC_DA_init();

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define CLK180_5_BASE EPWM2_BASE
#define CLK180_5_TBPRD 0
#define CLK180_5_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define CLK180_5_TBPHS 0
#define CLK180_5_CMPA 0
#define CLK180_5_CMPB 0
#define CLK180_5_CMPC 0
#define CLK180_5_CMPD 0
#define CLK180_5_DBRED 0
#define CLK180_5_DBFED 0
#define CLK180_5_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK180_5_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK180_5_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define CLK0_5_BASE EPWM1_BASE
#define CLK0_5_TBPRD 0
#define CLK0_5_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define CLK0_5_TBPHS 0
#define CLK0_5_CMPA 0
#define CLK0_5_CMPB 0
#define CLK0_5_CMPC 0
#define CLK0_5_CMPD 0
#define CLK0_5_DBRED 0
#define CLK0_5_DBFED 0
#define CLK0_5_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK0_5_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK0_5_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define toggleLED 31
void toggleLED_init();
#define PFCOTP 1
void PFCOTP_init();
#define ACFAIL5 7
void ACFAIL5_init();
#define PFC_OVP 10
void PFC_OVP_init();
#define FANFAIL3 12
void FANFAIL3_init();
#define FANFAIL2 13
void FANFAIL2_init();
#define FANFAIL4 33
void FANFAIL4_init();

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************

// Interrupt Settings for INT_CV_AD_1
#define INT_CV_AD_1 INT_ADCA1
#define INT_CV_AD_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_CV_AD_1_ISR(void);

//*****************************************************************************
//
// OUTPUTXBAR Configurations
//
//*****************************************************************************
void myOUTPUTXBAR0_init();
#define myOUTPUTXBAR0 XBAR_OUTPUT3
#define myOUTPUTXBAR0_ENABLED_MUXES (XBAR_MUX00)

//*****************************************************************************
//
// SCI Configurations
//
//*****************************************************************************
#define DEBUG_SCI_BASE SCIA_BASE
#define DEBUG_SCI_BAUDRATE 115200
#define DEBUG_SCI_CONFIG_WLEN SCI_CONFIG_WLEN_8
#define DEBUG_SCI_CONFIG_STOP SCI_CONFIG_STOP_ONE
#define DEBUG_SCI_CONFIG_PAR SCI_CONFIG_PAR_NONE
void DEBUG_SCI_init();

//*****************************************************************************
//
// SPI Configurations
//
//*****************************************************************************
#define SPIA_SLAVE_BASE SPIA_BASE
#define SPIA_SLAVE_BITRATE 1000000
void SPIA_SLAVE_init();

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ADC_init();
void	AIO_init();
void	ASYSCTL_init();
void	CMPSS_init();
void	CPUTIMER_init();
void	DAC_init();
void	EPWM_init();
void	GPIO_init();
void	INTERRUPT_init();
void	OUTPUTXBAR_init();
void	SCI_init();
void	SPI_init();
void	SYNC_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
