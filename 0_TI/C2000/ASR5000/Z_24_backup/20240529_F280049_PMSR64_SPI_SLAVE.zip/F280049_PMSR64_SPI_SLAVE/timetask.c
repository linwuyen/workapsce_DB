/*
 * timetask.c
 *
 *  Created on: May 17, 2024
 *      Author: User
 */

#include "common.h"
#include "spi_slave.h"

uint32_t u32Test[5] = {0x00000000,0x11112222,0x33334444,0x56565656,0x77888877};
ST_DRV sDrv = {
                .f32A = 0.0f,
                .f32B = 0.33456456f,
                .f32C = 0.6546545f,
                .f32D = 0.123874358f,
                .f32E = 0.0f,
                .u32MCP3301Buff = 0,
                .u32IO_STATUS = 0
};


ST_SPI_SLAVE sSpiS = {
                       .u32Fsm = _IS_THRER_A_SPI_PACK,
                       .u32Timeout = 0,
                       .u32TimeStamp = 0,
                       .u32TimeMark = 0,
                       .u32ErrCnts = 0,
                       //.p32Data = u32Test,
                       .p32Data = (uint32_t *)&sDrv,
                       .s16Rsize = 4,
                       .WriteFlag = 0
};

uint32_t first_time;
uint32_t second_time;
uint32_t delta_time;


void SPI_PARSE_Detect(void)
{
    if(sSpiS.WriteFlag == 1)
    {
        first_time = U32_UPCNTS;
        delta_time = first_time - second_time;

        if(delta_time >= T_1S)
        {
          FSM_WRITE_BBOX();

           sSpiS.WriteFlag = 0;
        }
        else
       {
            second_time = first_time;
       }

    }
}


void task1sec(void * s)
{

}

void task10msec(void * s)
{
    Update_IO();
}

void task1msec(void * s)
{
    u32Test[3] = u32Test[1];
    u32Test[4] = u32Test[2];
}

extern void scanSpiAction(void);

void asapTask(void * s)
{
    excSpiSlave(&sSpiS);

}

ST_TIMETASK time_task[] = {
        {task1sec,            0,     T_1S},
        {task1msec,           0,    T_1MS},
        {task10msec,          0,   T_10MS},
        {asapTask,            0,        0},
        END_OF_TASK
};

void pollTimeTask(void)
{
    scanTimeTask(time_task, (void *)0);
}
