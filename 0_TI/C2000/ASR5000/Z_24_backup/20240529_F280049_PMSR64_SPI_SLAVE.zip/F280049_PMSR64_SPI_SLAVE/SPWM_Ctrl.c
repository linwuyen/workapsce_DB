/*
 * SPWM_Ctrl.c
 *
 *  Created on: May 27, 2024
 *      Author: roger_lin
 */
#include "common.h"
#include "SPWM_Ctrl.h"


////====================IO=======================

typedef enum
{
    IO_ILDE     = (0x0000),
    PFC_STATUS  = (0x0001 << 0),
    DC_OVP      = (0x0001 << 1),
    FANFAIL     = (0x0001 << 2),
} IO_FSM;

typedef union
{
    IO_FSM fsm;
    uint32_t all;
    struct
    {
        uint32_t b0_DC_OVP    :1; //74HCT165 AIO
        uint32_t b1_FANFAIL_1 :1; // AIO
        uint32_t b2_FANFAIL_2 :1; // IO *
        uint32_t b3_FANFAIL_3 :1; // IO *
        uint32_t b4_FANFAIL_4 :1; // IO *
        uint32_t b5_ACFAIL_5  :1; // ACFAIL_1 ACFAIL5 IO *
        uint32_t b6_PFC_UVP   :1; // AIO
        uint32_t b7_PFC_OVP   :1; // IO *
        uint32_t b8_PFC_OTP   :1; // IO

    };
} REG_IOSTAT;
REG_IOSTAT IO_st;
typedef REG_IOSTAT *HAL_IOstatus;

void Update_IO(void)
{


    switch (IO_st.fsm)
    {
    case IO_ILDE:
        IO_st.fsm = PFC_STATUS;
        break;

    case PFC_STATUS:
        IO_st.b8_PFC_OTP = GPIO_readPin(PFC_OTP);
        IO_st.b7_PFC_OVP = GPIO_readPin(PFC_OVP);
        IO_st.b6_PFC_UVP = GPIO_readPin(PFC_UVP);

        sDrv.u32IO_STATUS = IO_st.all;
        IO_st.fsm = DC_OVP;
        break;

    case DC_OVP:
        IO_st.b0_DC_OVP = GPIO_readPin(DCOVP);
        IO_st.b5_ACFAIL_5= GPIO_readPin(ACFAIL5);
        sDrv.u32IO_STATUS = IO_st.all;
        IO_st.fsm = FANFAIL;
        break;

    case FANFAIL:
        IO_st.b1_FANFAIL_1 = GPIO_readPin(FANFAIL1);
        IO_st.b2_FANFAIL_2 = GPIO_readPin(FANFAIL2);
        IO_st.b3_FANFAIL_3 = GPIO_readPin(FANFAIL3);
        IO_st.b4_FANFAIL_4 = GPIO_readPin(FANFAIL4);
        sDrv.u32IO_STATUS = IO_st.all;
        IO_st.fsm = IO_ILDE;
        break;

    default:
        break;
    }
}

////=================================ADC======================================

uint16_t u16CV_ADBuf;
uint16_t u16MCP3301Buff;

__interrupt void INT_CV_AD_1_ISR(void)
{
//CV_AD
    ADC_forceSOC(CV_AD_BASE, ADC_SOC_NUMBER0);
    u16CV_ADBuf = ADC_readResult(CV_AD_RESULT_BASE, CV_AD_SOC0);
//CC_DA
    DAC_setShadowValue(CC_DA_BASE, u16CV_ADBuf);
//MCP3301
    u16MCP3301Buff = ADC_readResult(MCP3301_TEMP_RESULT_BASE, ADC_SOC_NUMBER1);
    sDrv.u32MCP3301Buff = u16MCP3301Buff;

    Interrupt_clearACKGroup(INT_CV_AD_1_INTERRUPT_ACK_GROUP);
    ADC_clearInterruptStatus(CV_AD_BASE, ADC_INT_NUMBER1);
}

////===============================PWM=============================
typedef struct
{
    uint32_t u32BASE;
    uint16_t u16TBperiodCount;
    uint16_t u16count;
    uint16_t u16phaseCount;
    uint16_t u16CompCount;
} PWM_Config_st;
typedef PWM_Config_st *HAL_PWM_Config;



PWM_Config_st CLK0 = { .u32BASE = EPWM1_BASE,
                       .u16TBperiodCount = 500,
                       .u16CompCount = 250,

};

PWM_Config_st CLK180 = { .u32BASE = EPWM2_BASE,
                         .u16TBperiodCount = 500,
                         .u16CompCount = 250,
                         .u16phaseCount = 500

};

void Setup_EPWM(HAL_PWM_Config p)
{
//TB
    EPWM_setClockPrescaler(p->u32BASE, EPWM_CLOCK_DIVIDER_1,
                           EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(p->u32BASE, p->u16TBperiodCount);
    EPWM_setTimeBaseCounter(p->u32BASE, p->u16count);
    EPWM_setTimeBaseCounterMode(p->u32BASE, EPWM_COUNTER_MODE_UP_DOWN);

//phase
    EPWM_forceSyncPulse(CLK0_5_BASE);
    EPWM_enablePhaseShiftLoad(CLK180_5_BASE);
    EPWM_setPhaseShift(p->u32BASE, p->u16phaseCount);

//CC
    EPWM_setCounterCompareValue(p->u32BASE, EPWM_COUNTER_COMPARE_A,
                                p->u16CompCount);
    EPWM_setCounterCompareShadowLoadMode(p->u32BASE, EPWM_COUNTER_COMPARE_A,
                                         EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_setCounterCompareValue(p->u32BASE, EPWM_COUNTER_COMPARE_B,
                                p->u16CompCount);
    EPWM_setCounterCompareShadowLoadMode(p->u32BASE, EPWM_COUNTER_COMPARE_B,
                                         EPWM_COMP_LOAD_ON_CNTR_ZERO);

//AQ-A
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_HIGH,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_LOW,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
//AQ-B
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_HIGH,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_LOW,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
//DB

    EPWM_setRisingEdgeDelayCountShadowLoadMode(p->u32BASE,
                                               EPWM_RED_LOAD_ON_CNTR_ZERO);
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(p->u32BASE);
    EPWM_setFallingEdgeDelayCountShadowLoadMode(p->u32BASE,
                                                EPWM_FED_LOAD_ON_CNTR_ZERO);
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(p->u32BASE);
}

void init_EPWM(void)
{
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    Setup_EPWM(&CLK0);
    Setup_EPWM(&CLK180);

    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
}
