#ifndef HWCONFIG_H_
#define HWCONFIG_H_


#define OSCSRC_FREQ                      10000000   //DEVICE_OSCSRC_FREQ

#define CPUCLK_FREQUENCY                 100       /* 200 MHz System frequency */


#endif /* HWCONFIG_H_ */
