/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"

//*****************************************************************************
//
// Board Configurations
// Initializes the rest of the modules. 
// Call this function in your application if you wish to do all module 
// initialization.
// If you wish to not use some of the initializations, instead of the 
// Board_init use the individual Module_inits
//
//*****************************************************************************
void Board_init()
{
	EALLOW;

	PinMux_init();
	CPUTIMER_init();
	// FLASH Initialization:
	// The "FLASH_init()" should be called after or during initialization functions like 
	// Device_init() or Device_enableAllPeripherals().
	GPIO_init();
	SPI_init();

	EDIS;
}

//*****************************************************************************
//
// PINMUX Configurations
//
//*****************************************************************************
void PinMux_init()
{
	//
	// PinMux for modules assigned to CPU1
	//
	
	// GPIO32 -> OFF_PWMn Pinmux
	GPIO_setPinConfig(GPIO_32_GPIO32);
	// GPIO17 -> EN_MASTER Pinmux
	GPIO_setPinConfig(GPIO_17_GPIO17);
	//
	// SPIB -> SPI_SLAVE Pinmux
	//
	GPIO_setPinConfig(SPI_SLAVE_SPIPICO_PIN_CONFIG);
	GPIO_setPadConfig(SPI_SLAVE_SPIPICO_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPI_SLAVE_SPIPICO_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPI_SLAVE_SPIPOCI_PIN_CONFIG);
	GPIO_setPadConfig(SPI_SLAVE_SPIPOCI_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPI_SLAVE_SPIPOCI_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPI_SLAVE_SPICLK_PIN_CONFIG);
	GPIO_setPadConfig(SPI_SLAVE_SPICLK_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPI_SLAVE_SPICLK_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPI_SLAVE_SPIPTE_PIN_CONFIG);
	GPIO_setPadConfig(SPI_SLAVE_SPIPTE_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPI_SLAVE_SPIPTE_GPIO, GPIO_QUAL_ASYNC);


}

//*****************************************************************************
//
// CPUTIMER Configurations
//
//*****************************************************************************
void CPUTIMER_init(){
	SWTIRMER_init();
}

void SWTIRMER_init(){
	CPUTimer_setEmulationMode(SWTIRMER_BASE, CPUTIMER_EMULATIONMODE_RUNFREE);
	CPUTimer_setPreScaler(SWTIRMER_BASE, 2U);
	CPUTimer_setPeriod(SWTIRMER_BASE, 50000000U);
	CPUTimer_disableInterrupt(SWTIRMER_BASE);
	CPUTimer_stopTimer(SWTIRMER_BASE);

	CPUTimer_reloadTimerCounter(SWTIRMER_BASE);
	CPUTimer_startTimer(SWTIRMER_BASE);
}

//*****************************************************************************
//
// FLASH Configurations
//
//*****************************************************************************
void FLASH_init(){
    //
    // FMC_CPU1 Initialization
    // 
    //
    // This function sets the fallback power mode of the flash bank specified by
    // the bank parameter. The power mode is specified by the powerMode
    // parameter
    //
    
    //
    // Set available banks to active power mode
    // 
    Flash_setBankPowerMode(FMC_CPU1_BASE, FLASH_BANK0, FLASH_BANK_PWR_ACTIVE);
    Flash_setBankPowerMode(FMC_CPU1_BASE, FLASH_BANK1, FLASH_BANK_PWR_ACTIVE);
    //
    // Sets the fallback power mode of the charge pump.
    //
    // Set pump power mode to active
    //
    Flash_setPumpPowerMode(FMC_CPU1_BASE, FLASH_PUMP_PWR_ACTIVE);
    //
    // Disable cache and prefetch mechanism before changing wait states
    //
    Flash_disableCache(FMC_CPU1_BASE);
    Flash_disablePrefetch(FMC_CPU1_BASE);
    //
    // This function sets the number of wait states for a flash read access. The
    // waitstates parameter is a number between 0 and 15. It is important
    // to look at your device's datasheet for information about what the required
    // minimum flash wait-state is for your selected SYSCLK frequency.
    //
    // By default the wait state amount is configured to the maximum 15. 
    //
    // Set flash wait states
    //
    Flash_setWaitstates(FMC_CPU1_BASE, FMC_CPU1_WAITSTATES); 
    //
    // Enable prefetch
    //
    Flash_enablePrefetch(FMC_CPU1_BASE);
    //
    // Enable cache
    //
    Flash_enableCache(FMC_CPU1_BASE);
    //
    // Enables flash error correction code (ECC) protection.
    //
    Flash_enableECC(FMC_CPU1_ECCBASE);
    //
    // Sets the single bit error threshold. Valid ranges are from 0-65535.
    //
    Flash_setErrorThreshold(FMC_CPU1_ECCBASE, FMC_CPU1_ERRORTHRESHOLD);
    //
    // Force a pipeline flush to ensure that the write to the last register
    // configured occurs before returning.
    //
    FLASH_DELAY_CONFIG;
}
//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
void GPIO_init(){
	OFF_PWMn_init();
	EN_MASTER_init();
}

void OFF_PWMn_init(){
	GPIO_writePin(OFF_PWMn, 1);
	GPIO_setPadConfig(OFF_PWMn, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(OFF_PWMn, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(OFF_PWMn, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(OFF_PWMn, GPIO_CORE_CPU1);
}
void EN_MASTER_init(){
	GPIO_setPadConfig(EN_MASTER, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(EN_MASTER, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(EN_MASTER, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(EN_MASTER, GPIO_CORE_CPU1);
}

//*****************************************************************************
//
// SPI Configurations
//
//*****************************************************************************
void SPI_init(){
	SPI_SLAVE_init();
}

void SPI_SLAVE_init(){
	SPI_disableModule(SPI_SLAVE_BASE);
	SPI_setConfig(SPI_SLAVE_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
				  SPI_MODE_PERIPHERAL, 1000000, 16);
	SPI_setPTESignalPolarity(SPI_SLAVE_BASE, SPI_PTE_ACTIVE_LOW);
	SPI_enableFIFO(SPI_SLAVE_BASE);
	SPI_disableLoopback(SPI_SLAVE_BASE);
	SPI_setEmulationMode(SPI_SLAVE_BASE, SPI_EMULATION_FREE_RUN);
	SPI_enableModule(SPI_SLAVE_BASE);
}

