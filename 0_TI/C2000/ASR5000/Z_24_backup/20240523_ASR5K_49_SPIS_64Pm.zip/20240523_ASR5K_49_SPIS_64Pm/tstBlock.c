/*
 * tstBlock.c
 *
 *  Created on: 2023¦~5¤ë24¤é
 *      Author: cody_chen
 */

#include <stdint.h>
#include "emu_eeprom.h"
#include "tst.h"


typedef enum
{
    _INIT_TEST_BLOCK_RAM  = 0,
    _RESET_BLOCK_RAM,
    _PROGRAM_BLOCK_TO_FLASH,
    _VARIFY_BLOCK_DATA,
    _CALLBACK_From_Flash,
    _KEEP_WRITE_EmuEepromBLOCK,
    _WRITE_EmuEepromBLOCK,
    _READ_EmuEepromBLOCK,
    _FREE_TEST_EEPROM
} TEST_EVENT;

typedef enum
{
    _EV_GET_ADDRESS = 0,
    _EV_UPLOAD_DATA,
    _EV_END_OF_UPLOAD,
    _EV_PROGRAM_DATA,
    _EV_END_OF_INIT_TESTBLOCK
} REG_INIT_TSTBLOCK;

typedef REG_INIT_TSTBLOCK REG_RST_TSTBLOCK;

REG_RST_TSTBLOCK regRESTstBlock = _EV_GET_ADDRESS;
REG_RST_TSTBLOCK regRECOstBlock = _EV_GET_ADDRESS;

typedef struct
{
    REG_INIT_TSTBLOCK regInitTstBlock;
    TEST_EVENT tstfsm;

    uint16_t beginAddress;
    uint16_t ptrAddress;
    uint16_t endAddress;
    uint16_t procBytes;
    uint16_t testBytes;

    uint16_t UserData[EMU_KBYTES];
    uint16_t UserDatalength;
    uint16_t StartAddress;
    uint16_t* puserData;

} ST_testblock;
ST_testblock Test_ST =
{
     .regInitTstBlock = _EV_GET_ADDRESS,
     .tstfsm = _FREE_TEST_EEPROM,
     .testBytes = EMU_KBYTES,


     .UserData={0x124,0x156,0x568,0x745}
};
ST_testblock * p = &Test_ST;

#pragma SET_CODE_SECTION(".TI.ramfunc")


void initBlockRam(void)
{
    switch (p->regInitTstBlock)
    {
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;
        p->regInitTstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, p->ptrAddress % 0xFFFFFFFF);
            p->ptrAddress++;
            p->procBytes++;
            p->ptrAddress &= 0xFFFF;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            p->regInitTstBlock = _EV_END_OF_UPLOAD;
        }
        break;

    case _EV_END_OF_UPLOAD:
        p->tstfsm = _FREE_TEST_EEPROM;
        p->regInitTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}

void resetBlockRam(void)
{
    switch (regRESTstBlock)
    {
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;
        regRESTstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            writeEmuEeprom(p->ptrAddress, 0xFFFF);
            p->ptrAddress++;
            p->procBytes++;
            if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
                p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            regRESTstBlock = _EV_END_OF_UPLOAD;
        }
        break;

    case _EV_END_OF_UPLOAD:
        p->tstfsm = _FREE_TEST_EEPROM;
        regRESTstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;
    }
}

void CUSTOM_BLOCK_FLASH(void)
{
    switch (regRECOstBlock)
    {
    // Calculator Address
    case _EV_GET_ADDRESS:
        p->endAddress = p->beginAddress + p->testBytes;
        p->ptrAddress = p->beginAddress;
        p->procBytes = 0;

        regRECOstBlock = _EV_UPLOAD_DATA;
        break;

    case _EV_UPLOAD_DATA:
        if (p->procBytes < p->testBytes)
        {
            UserDataRandom();
            p->ptrAddress++;
            p->procBytes++;

        if (EMU_SIZE_OF_SECTOR <= p->ptrAddress)
            p->ptrAddress -= EMU_SIZE_OF_SECTOR;
        }
        else
        {
            p->ptrAddress = p->beginAddress;
            regRECOstBlock = _EV_PROGRAM_DATA;
        }
        break;

    case _EV_PROGRAM_DATA:
        if(p->tstfsm == _FREE_TEST_EEPROM)
//        {
            setProgramEmuEeprom();
            regRECOstBlock = _EV_END_OF_UPLOAD;
//        }

        break;


    case _EV_END_OF_UPLOAD:
        regRECOstBlock = _EV_GET_ADDRESS;
        break;

    default:
        break;

    }
}


uint16_t someBuffer[EMU_KBYTES];

void tstEmuEeprom(void)
{
    //   loopWriteBlock();
    switch (p->tstfsm)
{
    case _INIT_TEST_BLOCK_RAM:
        initBlockRam();
        break;

    case _RESET_BLOCK_RAM:
        resetBlockRam();
        break;

    case _PROGRAM_BLOCK_TO_FLASH:
        setProgramEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _VARIFY_BLOCK_DATA:
        setVerifyEmuEeprom();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _CALLBACK_From_Flash:
        callbackRAMFromFlash();
        p->tstfsm = _FREE_TEST_EEPROM;
        break;

    case _KEEP_WRITE_EmuEepromBLOCK:
        CUSTOM_BLOCK_FLASH();
        break;

    case _WRITE_EmuEepromBLOCK:
    //    writeEmuEepromBlock(Test_ST.StartAddress,Test_ST.UserData,Test_ST.UserDatalength);
        p->tstfsm = _FREE_TEST_EEPROM;
    break;


    case _READ_EmuEepromBLOCK:
     //   p->puserData = readEmuEepromBlock(Test_ST.StartAddress,someBuffer,Test_ST.UserDatalength);
         p->tstfsm = _FREE_TEST_EEPROM;
    break;


    case _FREE_TEST_EEPROM:

    default:
        break;
    }
}

#pragma SET_CODE_SECTION()

//==============================================================
