
#ifndef COMMON_H_
#define COMMON_H_

#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"

//#include "F021_F28004x_C28x.h"

#ifndef bool_t
typedef bool bool_t;
#endif

#define SW_TIMER       50000000
#define U32_COUNTER     (uint32_t)CPUTimer_getTimerCount(SWTIRMER_BASE)

#define U32_UPCNTS      (SW_TIMER - U32_COUNTER)

#define T_10US          (SW_TIMER/100000)
#define T_50US          (SW_TIMER/20000)
#define T_125US         (SW_TIMER/8000)
#define T_250US         (SW_TIMER/4000)

#define T_500US         (SW_TIMER/2000)
#define T_1MS           (SW_TIMER/1000)
#define T_2D5MS         (SW_TIMER/400)
#define T_5MS           (SW_TIMER/200)
#define T_10MS          (SW_TIMER/100)
#define T_20MS          (SW_TIMER/50)
#define T_25MS          (SW_TIMER/40)
#define T_50MS          (SW_TIMER/20)
#define T_100MS         (SW_TIMER/10)
#define T_200MS         (SW_TIMER/5)
#define T_500MS         (SW_TIMER/2)
#define T_1S            (SW_TIMER/1)

#define FG_GET(x, src)   ((src & (x)) == (x)) //((src & (x)) == (x))
#define FG_GETn(x, src)  (!FG_GET(x, src)) //!((src & (x)) == (x))
#define FG_AND(x, src)   (src & (x))
#define FG_SET(x, src)   {src |= (x);}
#define FG_RST(x, src)   {src &= ~(x);}
#define FG_SWTO(x, src)  {src = (x);}




#endif /* COMMON_H_ */
