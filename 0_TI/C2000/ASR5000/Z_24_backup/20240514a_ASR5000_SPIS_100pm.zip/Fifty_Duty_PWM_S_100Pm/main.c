// Included Files
//## PWM SETTING MOVE common.h

#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"
#include "common.h"
#include "spi_slave.h"

uint16_t u16AdcBuf;
const char chararray[] = "Hello world";

uint32_t u32Test[5] = { 0x00000000, 0x11112222, 0x33334444, 0x56565656,0x77888877 };
ST_SPI_SLAVE sSpiS = { .u32Fsm = _IS_THRER_A_SPI_PACK,
                       .u32Timeout = 0,
                       .u32TimeStamp = 0,
                       .u32TimeMark = 0,
                       .u32ErrCnts = 0,
                       .p32Data = u32Test,
                       .s16Rsize = 4
};

#define index 3
uint16_t i;
uint16_t CMPSS_Value = 0;

void task25msec(void *s)
{
    GPIO_togglePin(myGPIO31);
}

void tas2D5msec(void *s)
{
//    u32Test[3] = u32Test[1];
//    u32Test[4] = u32Test[2];
}

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = { { task25msec, 0, T_25MS },
                            { tas2D5msec, 0, T_2D5MS },
                            { 0, 0, 0 } };


__interrupt void INT_myADC0_1_ISR(void)
{
    u16AdcBuf = ADC_readResult(myADC0_RESULT_BASE, myADC0_SOC0);

    DAC_setShadowValue(myDAC0_BASE, u16AdcBuf);

    Interrupt_clearACKGroup(INT_myADC0_1_INTERRUPT_ACK_GROUP);
    ADC_clearInterruptStatus(myADC0_BASE, ADC_INT_NUMBER1);
}

//
// Main
//
void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();
    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();
    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();
    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();
    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
    init_PWM_0();
    init_PWM_180();
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    SCI_writeCharArray(DEBUG_SCI_BASE, (const uint16_t*) chararray,
                       sizeof(chararray));
    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    while (1)
    {
        scanTimeTask(&time_task[id_ttask++], (void*) 0);
        if (0 == time_task[id_ttask].fn)
            id_ttask = 0;

        excSpiSlave(&sSpiS);


            CMPSS_setDACValueHigh(myCMPSS0_BASE,CMPSS_Value);



    }
}

//
// End of File
//
