/*
 * timetask.c
 *
 *  Created on: May 17, 2024
 *      Author: User
 */

#include "common.h"
#include "spi_slave.h"

float32_t f32Test[5] = {0.0, 0.0, 0.0, 0.0, 0.0};

ST_SPI_SLAVE sSpiS = {
                       .u32Fsm = _IS_THRER_A_SPI_PACK,
                       .u32Timeout = 0,
                       .u32TimeStamp = 0,
                       .u32TimeMark = 0,
                       .u32ErrCnts = 0,
                       .p32Data = (uint32_t *)f32Test,
                       .s16Rsize = 4

};


ST_DRV sDrv = { .fgStatus = _CSTAT_INIT_DRV_PARAM,
                .f32A = 1.21254f,
                .f32B = 2.33456456f,
                .f32C = 3.6546545f,
                .f32D = 5.123874358f

};

ST_SPI_SLAVE sSpiS_sDrv = {
                       .u32Fsm = _IS_THRER_A_SPI_PACK,
                       .u32Timeout = 0,
                       .u32TimeStamp = 0,
                       .u32TimeMark = 0,
                       .u32ErrCnts = 0,
                       .p32Data = (uint32_t *)f32Test,
                       .s16Rsize = 4

};

void task10msec(void * s)
{
    Update_IO();
}

void task1msec(void * s)
{

//    f32Test[3] = f32Test[1];
//    f32Test[4] = f32Test[2];
}

extern void scanSpiAction(void);

void asapTask(void * s)
{
    excSpiSlave(&sSpiS);

    excSpiSlave(&sSpiS_sDrv);
}

ST_TIMETASK time_task[] = {
        {task1msec,           0,   T_1MS},
        {task10msec,          0,   T_10MS},
        {asapTask,            0,   0},
        END_OF_TASK
};

void pollTimeTask(void)
{
    scanTimeTask(time_task, (void *)0);
}
