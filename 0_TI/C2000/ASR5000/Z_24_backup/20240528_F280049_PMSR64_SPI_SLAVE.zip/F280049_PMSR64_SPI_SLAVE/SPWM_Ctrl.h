/*
 * initCLK.h
 *
 *  Created on: May 27, 2024
 *      Author: roger_lin
 */

#ifndef SPWM_CTRL_H_
#define SPWM_CTRL_H_



//task10msec
extern void Update_IO(void);




extern void init_EPWM(void);


#endif /* SPWM_CTRL_H_ */
