// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"
#include "common.h"
#include <math.h>


void init_PWM_0(void)
{
    EPWM_setClockPrescaler(CLK0_5_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(CLK0_5_BASE, 500);
    EPWM_setTimeBaseCounter(CLK0_5_BASE, 0);
    EPWM_setTimeBaseCounterMode(CLK0_5_BASE, EPWM_COUNTER_MODE_UP_DOWN);
    EPWM_disablePhaseShiftLoad(CLK0_5_BASE);
    EPWM_setPhaseShift(CLK0_5_BASE, 0);
    EPWM_setCounterCompareValue(CLK0_5_BASE, EPWM_COUNTER_COMPARE_A, 250);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_CMPA_CMPAHR);
    EPWM_setCounterCompareShadowLoadMode(CLK0_5_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_setCounterCompareValue(CLK0_5_BASE, EPWM_COUNTER_COMPARE_B, 250);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_CMPB_CMPBHR);
    EPWM_setCounterCompareShadowLoadMode(CLK0_5_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_AQCTLA_AQCTLA2);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_AQCTLB_AQCTLB2);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
    EPWM_setDeadBandDelayPolarity(CLK0_5_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
    EPWM_setDeadBandDelayMode(CLK0_5_BASE, EPWM_DB_RED, true);
    EPWM_setRisingEdgeDelayCountShadowLoadMode(CLK0_5_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(CLK0_5_BASE);
    EPWM_setDeadBandDelayMode(CLK0_5_BASE, EPWM_DB_FED, true);
    EPWM_setFallingEdgeDelayCountShadowLoadMode(CLK0_5_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(CLK0_5_BASE);
}
void init_PWM_180(void)
{
    //trigger ADC ISR
    EPWM_forceSyncPulse(CLK0_5_BASE);
    EPWM_setClockPrescaler(CLK180_5_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(CLK180_5_BASE, 500);
    EPWM_setTimeBaseCounter(CLK180_5_BASE, 0);
    EPWM_setTimeBaseCounterMode(CLK180_5_BASE, EPWM_COUNTER_MODE_UP_DOWN);

    EPWM_enablePhaseShiftLoad(CLK180_5_BASE);
    EPWM_setPhaseShift(CLK180_5_BASE, 250);
    EPWM_setSyncOutPulseMode(CLK180_5_BASE, EPWM_SYNC_OUT_PULSE_ON_COUNTER_ZERO);
    EPWM_setCounterCompareValue(CLK180_5_BASE, EPWM_COUNTER_COMPARE_A, 250);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_CMPA_CMPAHR);
    EPWM_setCounterCompareShadowLoadMode(CLK180_5_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_setCounterCompareValue(CLK180_5_BASE, EPWM_COUNTER_COMPARE_B, 250);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_CMPB_CMPBHR);
    EPWM_setCounterCompareShadowLoadMode(CLK180_5_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_AQCTLA_AQCTLA2);

    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_AQCTLB_AQCTLB2);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);

    EPWM_setDeadBandDelayPolarity(CLK180_5_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
    EPWM_setDeadBandDelayMode(CLK180_5_BASE, EPWM_DB_RED, true);

    EPWM_setRisingEdgeDelayCountShadowLoadMode(CLK180_5_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(CLK180_5_BASE);
    EPWM_setDeadBandDelayMode(CLK180_5_BASE, EPWM_DB_FED, true);
    EPWM_setFallingEdgeDelayCountShadowLoadMode(CLK180_5_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(CLK180_5_BASE);
}


void task2D5msec(void * s)
{
}

void task500usec(void * s)
{
   // GPIO_togglePin(myGPIO04);
}
typedef struct _ST_TIMETASK{
    void (*fn) (void * s);
    uint32_t cnt;
    uint32_t max;
} ST_TIMETASK;

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = {
        {task500usec,         0,   T_500US},
        {task2D5msec,         0,   T_2D5MS},
        {0, 0, 0}
};
bool_t scanTimeTask(ST_TIMETASK *t, void *s)
{
    static uint32_t delta_t;
    static uint32_t u32Cnt = 0;

    u32Cnt = SW_TIMER - (uint32_t)CPUTimer_getTimerCount(SWTIRMER_BASE);

    if(t->cnt > u32Cnt) {
        delta_t = u32Cnt + SW_TIMER - t->cnt;
    }
    else {
        delta_t = u32Cnt - t->cnt;
    }
    if(delta_t >= t->max) {
        t->fn(s);
        t->cnt = u32Cnt;
        return true;
    }
    else {
        return false;
    }
}


#define PI 3.14159265359f
#define amplitude 4095
#define SAMPLES 100

uint16_t index = 0;
uint16_t AdcBuf;

uint16_t DACValue;
float sampleRate = 100000.0f;
float frequency = 1000.0f;
float radianIncrement;
float radian = 0.0f;

const char chararray[] = "Hello world";
#pragma CODE_SECTION(INT_myADC0_1_ISR, ".TI.ramfunc");
__interrupt void INT_myADC0_1_ISR(void)
{


    AdcBuf = ADC_readResult(myADC0_RESULT_BASE, myADC0_SOC0);


    radianIncrement  = 2 * PI * frequency / sampleRate;

    radian += radianIncrement;

    DACValue =(uint16_t)(amplitude * (sinf(radian) + 1.0f) / 2.0f);


    DAC_setShadowValue(myDAC0_BASE, AdcBuf);

    if (radian >= 2* PI) {
        radian -= 2* PI;
    }

    Interrupt_clearACKGroup(INT_myADC0_1_INTERRUPT_ACK_GROUP);
    ADC_clearInterruptStatus(myADC0_BASE, ADC_INT_NUMBER1);
}

//__interrupt void INT_myADC0_1_ISR(void)
//{
//         static uint16_t *AdcBufPtr = AdcBuf;
//
//        *AdcBufPtr++ = ADC_readResult(myADC0_RESULT_BASE, myADC0_SOC0);
//
//        if (AdcBufPtr < &AdcBuf[SAMPLES])
//        {
//            *AdcBufPtr++ = ADC_readResult(myADC0_RESULT_BASE, myADC0_SOC0);
//        }
//        else
//        {
//            AdcBufPtr = AdcBuf;
//        }
//
//    radianIncrement  = 2 * PI * frequency / sampleRate;
//
//    radian += radianIncrement;
//
//    DACValue =(uint16_t)(amplitude * (sinf(radian) + 1.0f) / 2.0f);
//
//
//    DAC_setShadowValue(myDAC0_BASE, DACValue);
//
//    if (radian >= 2* PI) {
//        radian -= 2* PI;
//    }
//
//    Interrupt_clearACKGroup(INT_myADC0_1_INTERRUPT_ACK_GROUP);
//    ADC_clearInterruptStatus(myADC0_BASE, ADC_INT_NUMBER1);
//}
//
// Main
//
void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();
    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();
    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();
    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();
    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
    init_PWM_0();
    init_PWM_180();
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();


    SCI_writeCharArray(DEBUG_SCI_BASE,(const uint16_t *)chararray ,sizeof(chararray));
    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    while(1)
    {
        scanTimeTask(&time_task[id_ttask++], (void *)0);
        if(0 == time_task[id_ttask].fn) id_ttask = 0;
    }
}

//
// End of File
//
