/*
 * f021Bbox.h
 *
 *  Created on: Apr 16, 2024
 *      Author: User
 */

#ifndef F021BBOX_H_
#define F021BBOX_H_


#include "common.h"

#define RAM_OF_SIZE  20
extern uint32_t u32Emu_RAM_FLASH[RAM_OF_SIZE];
extern void FSM_WRITE_BBOX(void);




extern void runFlashStorage(void);
extern uint16_t isBboxFree(void);
extern uint16_t isCallbackReady(void);

#endif /* F021BBOX_H_ */
