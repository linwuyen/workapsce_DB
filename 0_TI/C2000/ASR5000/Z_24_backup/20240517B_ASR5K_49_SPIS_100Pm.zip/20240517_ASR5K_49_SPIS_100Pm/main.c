// Included Files
//## PWM SETTING MOVE common.h


#include "common.h"
#include "spi_slave.h"
#include "PWM.h"
#include "emu_eeprom.h"


const char chararray[] = "Hello world";

uint32_t u32Test[5] = { 0x00000000, 0x11112222, 0x33334444, 0x56565656,0x77888877 };
ST_SPI_SLAVE sSpiS = { .u32Fsm = _IS_THRER_A_SPI_PACK,
                       .u32Timeout = 0,
                       .u32TimeStamp = 0,
                       .u32TimeMark = 0,
                       .u32ErrCnts = 0,
                       .p32Data = u32Test,
                       .s16Rsize = 4
};

uint16_t u16AdcBuf; //CV_AD
uint16_t u16TEMP; //MCP3301
uint16_t u16CMPSS_DAC; //DAC7612

typedef union {
    uint32_t all;
    struct {
        uint32_t b0_DC_OVP:1; //74HCT165 AIO
        uint32_t bFANFAIL_1:1; // AIO
        uint32_t bFANFAIL_2:1; // IO *
        uint32_t bFANFAIL_3:1;// IO *
        uint32_t bFANFAIL_4:1; // IO *
        uint32_t bACFAIL_5:1; // ACFAIL_1 ACFAIL5 IO *
        uint32_t bPFC_UVP:1; // AIO
        uint32_t bPFC_OVP:1; // IO *
        uint32_t bPFC_OTP:1; // IO *
    };
}REG_IOSTAT;
REG_IOSTAT IO_st;
typedef REG_IOSTAT *HAL_IOstatus;


void task25msec(void *s)
{
    GPIO_togglePin(toggleLED);
}

void tas2D5msec(void *s)
{
//    u32Test[3] = u32Test[1];
//    u32Test[4] = u32Test[2];
}

uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = { { task25msec, 0, T_25MS },
                            { tas2D5msec, 0, T_2D5MS },
                            { 0, 0, 0 } };


__interrupt void INT_CV_AD_1_ISR(void)
{
    u16AdcBuf = ADC_readResult(CV_AD_RESULT_BASE, CV_AD_SOC0);

    DAC_setShadowValue(CC_DA_BASE, u16AdcBuf); //CC_DA

    Interrupt_clearACKGroup(INT_CV_AD_1_INTERRUPT_ACK_GROUP);
    ADC_clearInterruptStatus(CV_AD_BASE, ADC_INT_NUMBER1);
}



void UpdateIOStatus(HAL_IOstatus p)
{
    ADC_forceSOC(MCP3301_BASE, ADC_SOC_NUMBER1);
    u16TEMP = ADC_readResult(MCP3301_RESULT_BASE, ADC_SOC_NUMBER1);


    p->b0_DC_OVP =  GPIO_readPin(DCOVP);
    p->bACFAIL_5  = GPIO_readPin(ACFAIL5);
    p->bFANFAIL_1 = GPIO_readPin(FANFAIL1);
    p->bFANFAIL_2 = GPIO_readPin(FANFAIL2);
    p->bFANFAIL_3 = GPIO_readPin(FANFAIL3);
    p->bFANFAIL_4 = GPIO_readPin(FANFAIL4);
    p->bPFC_OTP = GPIO_readPin(PFCOTP);
    p->bPFC_OVP = GPIO_readPin(PFC_OVP);
    p->bPFC_UVP = GPIO_readPin(PFC_UVP);

    switch(sSpiS.rxTemp.bits.u32Addr)
    {

    case 1:
        u16CMPSS_DAC = sSpiS.rxTemp.bits.u32Data;
        CMPSS_setDACValueHigh(DAC7612_BASE,u16CMPSS_DAC);
        break;

    case 2:
        u32Test[2] = u16AdcBuf;
        break;

    case 3:
        break;
    }
}


//
// Main
//
void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();
    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();
    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();
    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();
    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
    init_PWM_0();
    init_PWM_180();
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);


    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    SCI_writeCharArray(DEBUG_SCI_BASE, (const uint16_t*) chararray, sizeof(chararray));
    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //

    Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 100);
    Fapi_setActiveFlashBank(Fapi_FlashBank0);
    Fapi_setActiveFlashBank(Fapi_FlashBank1);

    Flash_disableECC(FLASH0ECC_BASE);

    EINT;
    ERTM;

    while (1)
    {
        scanTimeTask(&time_task[id_ttask++], (void*) 0);
        if (0 == time_task[id_ttask].fn)id_ttask = 0;

        excSpiSlave(&sSpiS);

        UpdateIOStatus(&IO_st);

        execEmuEeprom();

    }
}

//
// End of File
//
