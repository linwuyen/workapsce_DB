/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************
//
// AIO227 - GPIO Settings
//
#define GPIO_PIN_AIO227 227
#define FANFAIL1_AIO_PIN_CONFIG GPIO_227_GPIO227
//
// AIO239 - GPIO Settings
//
#define GPIO_PIN_AIO239 239
#define PFC_UVPn_AIO_PIN_CONFIG GPIO_239_GPIO239
//
// AIO237 - GPIO Settings
//
#define GPIO_PIN_AIO237 237
#define DCOVPn_AIO_PIN_CONFIG GPIO_237_GPIO237
//
// AIO245 - GPIO Settings
//
#define GPIO_PIN_AIO245 245
#define PFC_UV2n_AIO_PIN_CONFIG GPIO_245_GPIO245

//
// EPWM6 -> CLK0_5 Pinmux
//
//
// EPWM6_A - GPIO Settings
//
#define GPIO_PIN_EPWM6_A 18
#define CLK0_5_EPWMA_GPIO 18
#define CLK0_5_EPWMA_PIN_CONFIG GPIO_18_EPWM6_A

//
// EPWM2 -> CLK180_5 Pinmux
//
//
// EPWM2_A - GPIO Settings
//
#define GPIO_PIN_EPWM2_A 2
#define CLK180_5_EPWMA_GPIO 2
#define CLK180_5_EPWMA_PIN_CONFIG GPIO_2_EPWM2_A

//
// EPWM3 -> FANCTRL5 Pinmux
//
//
// EPWM3_A - GPIO Settings
//
#define GPIO_PIN_EPWM3_A 4
#define FANCTRL5_EPWMA_GPIO 4
#define FANCTRL5_EPWMA_PIN_CONFIG GPIO_4_EPWM3_A
//
// GPIO5 - GPIO Settings
//
#define SPIA_CS_GPIO_PIN_CONFIG GPIO_5_GPIO5
//
// GPIO16 - GPIO Settings
//
#define SPIA_MOSI_GPIO_PIN_CONFIG GPIO_16_GPIO16
//
// GPIO9 - GPIO Settings
//
#define SPIA_CLK_GPIO_PIN_CONFIG GPIO_9_GPIO9
//
// GPIO32 - GPIO Settings
//
#define OFF_PWMn_GPIO_PIN_CONFIG GPIO_32_GPIO32
//
// GPIO17 - GPIO Settings
//
#define MASTER_GPIO_PIN_CONFIG GPIO_17_GPIO17
//
// GPIO10 - GPIO Settings
//
#define PFC_OVPn_GPIO_PIN_CONFIG GPIO_10_GPIO10
//
// GPIO7 - GPIO Settings
//
#define ACFAIL5_GPIO_PIN_CONFIG GPIO_7_GPIO7
//
// GPIO22 - GPIO Settings
//
#define PFC_OVP2n_GPIO_PIN_CONFIG GPIO_22_GPIO22
//
// GPIO1 - GPIO Settings
//
#define PFC_OTPn_GPIO_PIN_CONFIG GPIO_1_GPIO1
//
// GPIO12 - GPIO Settings
//
#define FANFAIL3_GPIO_PIN_CONFIG GPIO_12_GPIO12
//
// GPIO13 - GPIO Settings
//
#define FANFAIL2_GPIO_PIN_CONFIG GPIO_13_GPIO13
//
// GPIO33 - GPIO Settings
//
#define FANFAIL4_GPIO_PIN_CONFIG GPIO_33_GPIO33

//
// SPIA -> SPIA_ISHARE Pinmux
//
//
// SPIA_PICO - GPIO Settings
//
#define GPIO_PIN_SPIA_PICO 8
#define SPIA_ISHARE_SPIPICO_GPIO 8
#define SPIA_ISHARE_SPIPICO_PIN_CONFIG GPIO_8_SPIA_SIMO
//
// SPIA_CLK - GPIO Settings
//
#define GPIO_PIN_SPIA_CLK 3
#define SPIA_ISHARE_SPICLK_GPIO 3
#define SPIA_ISHARE_SPICLK_PIN_CONFIG GPIO_3_SPIA_CLK
//
// SPIA_PTE - GPIO Settings
//
#define GPIO_PIN_SPIA_PTE 11
#define SPIA_ISHARE_SPIPTE_GPIO 11
#define SPIA_ISHARE_SPIPTE_PIN_CONFIG GPIO_11_SPIA_STE

//
// SPIB -> SPIB_SLAVE Pinmux
//
//
// SPIB_PICO - GPIO Settings
//
#define GPIO_PIN_SPIB_PICO 24
#define SPIB_SLAVE_SPIPICO_GPIO 24
#define SPIB_SLAVE_SPIPICO_PIN_CONFIG GPIO_24_SPIB_SIMO
//
// SPIB_POCI - GPIO Settings
//
#define GPIO_PIN_SPIB_POCI 6
#define SPIB_SLAVE_SPIPOCI_GPIO 6
#define SPIB_SLAVE_SPIPOCI_PIN_CONFIG GPIO_6_SPIB_SOMI
//
// SPIB_CLK - GPIO Settings
//
#define GPIO_PIN_SPIB_CLK 28
#define SPIB_SLAVE_SPICLK_GPIO 28
#define SPIB_SLAVE_SPICLK_PIN_CONFIG GPIO_28_SPIB_CLK
//
// SPIB_PTE - GPIO Settings
//
#define GPIO_PIN_SPIB_PTE 29
#define SPIB_SLAVE_SPIPTE_GPIO 29
#define SPIB_SLAVE_SPIPTE_PIN_CONFIG GPIO_29_SPIB_STE

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
#define BASE_ADCC_BASE ADCC_BASE
#define BASE_ADCC_RESULT_BASE ADCCRESULT_BASE
#define TEMP ADC_SOC_NUMBER0
#define TEMP_FORCE ADC_FORCE_SOC0
#define TEMP_ADC_BASE ADCC_BASE
#define TEMP_RESULT_BASE ADCCRESULT_BASE
#define TEMP_SAMPLE_WINDOW 100
#define TEMP_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define TEMP_CHANNEL ADC_CH_ADCIN2
#define RESV_C_SOC1 ADC_SOC_NUMBER1
#define RESV_C_SOC1_FORCE ADC_FORCE_SOC1
#define RESV_C_SOC1_ADC_BASE ADCC_BASE
#define RESV_C_SOC1_RESULT_BASE ADCCRESULT_BASE
#define RESV_C_SOC1_SAMPLE_WINDOW 100
#define RESV_C_SOC1_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define RESV_C_SOC1_CHANNEL ADC_CH_ADCIN2
#define C_REF_1V5 ADC_SOC_NUMBER2
#define C_REF_1V5_FORCE ADC_FORCE_SOC2
#define C_REF_1V5_ADC_BASE ADCC_BASE
#define C_REF_1V5_RESULT_BASE ADCCRESULT_BASE
#define C_REF_1V5_SAMPLE_WINDOW 100
#define C_REF_1V5_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define C_REF_1V5_CHANNEL ADC_CH_ADCIN1
void BASE_ADCC_init();

#define BASE_ADCA_BASE ADCA_BASE
#define BASE_ADCA_RESULT_BASE ADCARESULT_BASE
#define ILA_AD ADC_SOC_NUMBER0
#define ILA_AD_FORCE ADC_FORCE_SOC0
#define ILA_AD_ADC_BASE ADCA_BASE
#define ILA_AD_RESULT_BASE ADCARESULT_BASE
#define ILA_AD_SAMPLE_WINDOW 100
#define ILA_AD_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define ILA_AD_CHANNEL ADC_CH_ADCIN2
#define ILB_AD ADC_SOC_NUMBER1
#define ILB_AD_FORCE ADC_FORCE_SOC1
#define ILB_AD_ADC_BASE ADCA_BASE
#define ILB_AD_RESULT_BASE ADCARESULT_BASE
#define ILB_AD_SAMPLE_WINDOW 100
#define ILB_AD_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define ILB_AD_CHANNEL ADC_CH_ADCIN4
#define A_REF_1V5 ADC_SOC_NUMBER2
#define A_REF_1V5_FORCE ADC_FORCE_SOC2
#define A_REF_1V5_ADC_BASE ADCA_BASE
#define A_REF_1V5_RESULT_BASE ADCARESULT_BASE
#define A_REF_1V5_SAMPLE_WINDOW 100
#define A_REF_1V5_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define A_REF_1V5_CHANNEL ADC_CH_ADCIN6
void BASE_ADCA_init();

#define BASE_ADCB_BASE ADCB_BASE
#define BASE_ADCB_RESULT_BASE ADCBRESULT_BASE
#define CV_AD ADC_SOC_NUMBER0
#define CV_AD_FORCE ADC_FORCE_SOC0
#define CV_AD_ADC_BASE ADCB_BASE
#define CV_AD_RESULT_BASE ADCBRESULT_BASE
#define CV_AD_SAMPLE_WINDOW 100
#define CV_AD_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define CV_AD_CHANNEL ADC_CH_ADCIN1
#define RESV_B_SOC1 ADC_SOC_NUMBER1
#define RESV_B_SOC1_FORCE ADC_FORCE_SOC1
#define RESV_B_SOC1_ADC_BASE ADCB_BASE
#define RESV_B_SOC1_RESULT_BASE ADCBRESULT_BASE
#define RESV_B_SOC1_SAMPLE_WINDOW 100
#define RESV_B_SOC1_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define RESV_B_SOC1_CHANNEL ADC_CH_ADCIN1
#define B_REF_1V5 ADC_SOC_NUMBER2
#define B_REF_1V5_FORCE ADC_FORCE_SOC2
#define B_REF_1V5_ADC_BASE ADCB_BASE
#define B_REF_1V5_RESULT_BASE ADCBRESULT_BASE
#define B_REF_1V5_SAMPLE_WINDOW 100
#define B_REF_1V5_TRIGGER_SOURCE ADC_TRIGGER_SW_ONLY
#define B_REF_1V5_CHANNEL ADC_CH_ADCIN2
void BASE_ADCB_init();


//*****************************************************************************
//
// AIO Configurations
//
//*****************************************************************************
#define FANFAIL1 227
void FANFAIL1_init();
#define PFC_UVPn 239
void PFC_UVPn_init();
#define DCOVPn 237
void DCOVPn_init();
#define PFC_UV2n 245
void PFC_UV2n_init();

//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// DAC Configurations
//
//*****************************************************************************
#define CC_DA_BASE DACA_BASE
void CC_DA_init();
#define DEBUG_DACB_BASE DACB_BASE
void DEBUG_DACB_init();

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define CLK0_5_BASE EPWM6_BASE
#define CLK0_5_TBPRD 0
#define CLK0_5_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define CLK0_5_TBPHS 0
#define CLK0_5_CMPA 0
#define CLK0_5_CMPB 0
#define CLK0_5_CMPC 0
#define CLK0_5_CMPD 0
#define CLK0_5_DBRED 0
#define CLK0_5_DBFED 0
#define CLK0_5_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK0_5_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK0_5_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define CLK180_5_BASE EPWM2_BASE
#define CLK180_5_TBPRD 0
#define CLK180_5_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define CLK180_5_TBPHS 0
#define CLK180_5_CMPA 0
#define CLK180_5_CMPB 0
#define CLK180_5_CMPC 0
#define CLK180_5_CMPD 0
#define CLK180_5_DBRED 0
#define CLK180_5_DBFED 0
#define CLK180_5_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK180_5_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define CLK180_5_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define FANCTRL5_BASE EPWM3_BASE
#define FANCTRL5_TBPRD 0
#define FANCTRL5_COUNTER_MODE EPWM_COUNTER_MODE_STOP_FREEZE
#define FANCTRL5_TBPHS 0
#define FANCTRL5_CMPA 0
#define FANCTRL5_CMPB 0
#define FANCTRL5_CMPC 0
#define FANCTRL5_CMPD 0
#define FANCTRL5_DBRED 0
#define FANCTRL5_DBFED 0
#define FANCTRL5_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FANCTRL5_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define FANCTRL5_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define SPIA_CS 5
void SPIA_CS_init();
#define SPIA_MOSI 16
void SPIA_MOSI_init();
#define SPIA_CLK 9
void SPIA_CLK_init();
#define OFF_PWMn 32
void OFF_PWMn_init();
#define MASTER 17
void MASTER_init();
#define PFC_OVPn 10
void PFC_OVPn_init();
#define ACFAIL5 7
void ACFAIL5_init();
#define PFC_OVP2n 22
void PFC_OVP2n_init();
#define PFC_OTPn 1
void PFC_OTPn_init();
#define FANFAIL3 12
void FANFAIL3_init();
#define FANFAIL2 13
void FANFAIL2_init();
#define FANFAIL4 33
void FANFAIL4_init();

//*****************************************************************************
//
// SPI Configurations
//
//*****************************************************************************
#define SPIA_ISHARE_BASE SPIA_BASE
#define SPIA_ISHARE_BITRATE 5000000
void SPIA_ISHARE_init();
#define SPIB_SLAVE_BASE SPIB_BASE
#define SPIB_SLAVE_BITRATE 20000000
void SPIB_SLAVE_init();

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ADC_init();
void	AIO_init();
void	ASYSCTL_init();
void	DAC_init();
void	EPWM_init();
void	GPIO_init();
void	SPI_init();
void	SYNC_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
