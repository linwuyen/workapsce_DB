/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"

//*****************************************************************************
//
// Board Configurations
// Initializes the rest of the modules. 
// Call this function in your application if you wish to do all module 
// initialization.
// If you wish to not use some of the initializations, instead of the 
// Board_init use the individual Module_inits
//
//*****************************************************************************
void Board_init()
{
	EALLOW;

	PinMux_init();
	SYNC_init();
	ASYSCTL_init();
	ADC_init();
	AIO_init();
	DAC_init();
	EPWM_init();
	GPIO_init();
	SPI_init();

	EDIS;
}

//*****************************************************************************
//
// PINMUX Configurations
//
//*****************************************************************************
void PinMux_init()
{
	//
	// PinMux for modules assigned to CPU1
	//
	
	// AIO227 -> FANFAIL1 Pinmux
	GPIO_setPinConfig(GPIO_227_GPIO227);
	GPIO_setAnalogMode(227, GPIO_ANALOG_DISABLED);
	// AIO239 -> PFC_UVPn Pinmux
	GPIO_setPinConfig(GPIO_239_GPIO239);
	GPIO_setAnalogMode(239, GPIO_ANALOG_DISABLED);
	// AIO237 -> DCOVPn Pinmux
	GPIO_setPinConfig(GPIO_237_GPIO237);
	GPIO_setAnalogMode(237, GPIO_ANALOG_DISABLED);
	// AIO245 -> PFC_UV2n Pinmux
	GPIO_setPinConfig(GPIO_245_GPIO245);
	GPIO_setAnalogMode(245, GPIO_ANALOG_DISABLED);
	//
	// EPWM6 -> CLK0_5 Pinmux
	//
	GPIO_setPinConfig(CLK0_5_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(CLK0_5_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(CLK0_5_EPWMA_GPIO, GPIO_QUAL_SYNC);

	//
	// EPWM2 -> CLK180_5 Pinmux
	//
	GPIO_setPinConfig(CLK180_5_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(CLK180_5_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(CLK180_5_EPWMA_GPIO, GPIO_QUAL_SYNC);

	//
	// EPWM3 -> FANCTRL5 Pinmux
	//
	GPIO_setPinConfig(FANCTRL5_EPWMA_PIN_CONFIG);
	GPIO_setPadConfig(FANCTRL5_EPWMA_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(FANCTRL5_EPWMA_GPIO, GPIO_QUAL_SYNC);

	// GPIO5 -> SPIA_CS Pinmux
	GPIO_setPinConfig(GPIO_5_GPIO5);
	// GPIO16 -> SPIA_MOSI Pinmux
	GPIO_setPinConfig(GPIO_16_GPIO16);
	// GPIO9 -> SPIA_CLK Pinmux
	GPIO_setPinConfig(GPIO_9_GPIO9);
	// GPIO32 -> OFF_PWMn Pinmux
	GPIO_setPinConfig(GPIO_32_GPIO32);
	// GPIO17 -> MASTER Pinmux
	GPIO_setPinConfig(GPIO_17_GPIO17);
	// GPIO10 -> PFC_OVPn Pinmux
	GPIO_setPinConfig(GPIO_10_GPIO10);
	// GPIO7 -> ACFAIL5 Pinmux
	GPIO_setPinConfig(GPIO_7_GPIO7);
	// GPIO22_VFBSW -> PFC_OVP2n Pinmux
	GPIO_setPinConfig(GPIO_22_GPIO22);
	// GPIO1 -> PFC_OTPn Pinmux
	GPIO_setPinConfig(GPIO_1_GPIO1);
	// GPIO12 -> FANFAIL3 Pinmux
	GPIO_setPinConfig(GPIO_12_GPIO12);
	// GPIO13 -> FANFAIL2 Pinmux
	GPIO_setPinConfig(GPIO_13_GPIO13);
	// GPIO33 -> FANFAIL4 Pinmux
	GPIO_setPinConfig(GPIO_33_GPIO33);
	//
	// SPIA -> SPIA_ISHARE Pinmux
	//
	GPIO_setPinConfig(SPIA_ISHARE_SPIPICO_PIN_CONFIG);
	GPIO_setPadConfig(SPIA_ISHARE_SPIPICO_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIA_ISHARE_SPIPICO_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPIA_ISHARE_SPICLK_PIN_CONFIG);
	GPIO_setPadConfig(SPIA_ISHARE_SPICLK_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIA_ISHARE_SPICLK_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPIA_ISHARE_SPIPTE_PIN_CONFIG);
	GPIO_setPadConfig(SPIA_ISHARE_SPIPTE_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIA_ISHARE_SPIPTE_GPIO, GPIO_QUAL_ASYNC);

	//
	// SPIB -> SPIB_SLAVE Pinmux
	//
	GPIO_setPinConfig(SPIB_SLAVE_SPIPICO_PIN_CONFIG);
	GPIO_setPadConfig(SPIB_SLAVE_SPIPICO_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIB_SLAVE_SPIPICO_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPIB_SLAVE_SPIPOCI_PIN_CONFIG);
	GPIO_setPadConfig(SPIB_SLAVE_SPIPOCI_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIB_SLAVE_SPIPOCI_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPIB_SLAVE_SPICLK_PIN_CONFIG);
	GPIO_setPadConfig(SPIB_SLAVE_SPICLK_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIB_SLAVE_SPICLK_GPIO, GPIO_QUAL_ASYNC);

	GPIO_setPinConfig(SPIB_SLAVE_SPIPTE_PIN_CONFIG);
	GPIO_setPadConfig(SPIB_SLAVE_SPIPTE_GPIO, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIB_SLAVE_SPIPTE_GPIO, GPIO_QUAL_ASYNC);


}

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
void ADC_init(){
	BASE_ADCC_init();
	BASE_ADCA_init();
	BASE_ADCB_init();
}

void BASE_ADCC_init(){
	//
	// ADC Initialization: Write ADC configurations and power up the ADC
	//
	// Configures the ADC module's offset trim
	//
	ADC_setOffsetTrimAll(ADC_REFERENCE_EXTERNAL,ADC_REFERENCE_2_5V);
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(BASE_ADCC_BASE, ADC_CLK_DIV_2_0);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(BASE_ADCC_BASE, ADC_PULSE_END_OF_ACQ_WIN);
	//
	// Sets the timing of early interrupt generation.
	//
	ADC_setInterruptCycleOffset(BASE_ADCC_BASE, 0U);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(BASE_ADCC_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(BASE_ADCC_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(BASE_ADCC_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCC_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCC_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCC_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCC_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCC_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN1, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCC_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
}
void BASE_ADCA_init(){
	//
	// ADC Initialization: Write ADC configurations and power up the ADC
	//
	// Configures the ADC module's offset trim
	//
	ADC_setOffsetTrimAll(ADC_REFERENCE_EXTERNAL,ADC_REFERENCE_2_5V);
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(BASE_ADCA_BASE, ADC_CLK_DIV_2_0);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(BASE_ADCA_BASE, ADC_PULSE_END_OF_ACQ_WIN);
	//
	// Sets the timing of early interrupt generation.
	//
	ADC_setInterruptCycleOffset(BASE_ADCA_BASE, 0U);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(BASE_ADCA_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(BASE_ADCA_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(BASE_ADCA_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCA_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN4
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCA_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN4, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCA_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN6
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCA_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN6, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCA_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
}
void BASE_ADCB_init(){
	//
	// ADC Initialization: Write ADC configurations and power up the ADC
	//
	// Configures the ADC module's offset trim
	//
	ADC_setOffsetTrimAll(ADC_REFERENCE_EXTERNAL,ADC_REFERENCE_2_5V);
	//
	// Configures the analog-to-digital converter module prescaler.
	//
	ADC_setPrescaler(BASE_ADCB_BASE, ADC_CLK_DIV_2_0);
	//
	// Sets the timing of the end-of-conversion pulse
	//
	ADC_setInterruptPulseMode(BASE_ADCB_BASE, ADC_PULSE_END_OF_ACQ_WIN);
	//
	// Sets the timing of early interrupt generation.
	//
	ADC_setInterruptCycleOffset(BASE_ADCB_BASE, 0U);
	//
	// Powers up the analog-to-digital converter core.
	//
	ADC_enableConverter(BASE_ADCB_BASE);
	//
	// Delay for 1ms to allow ADC time to power up
	//
	DEVICE_DELAY_US(500);
	//
	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	//
	// Disables SOC burst mode.
	//
	ADC_disableBurstMode(BASE_ADCB_BASE);
	//
	// Sets the priority mode of the SOCs.
	//
	ADC_setSOCPriority(BASE_ADCB_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	//
	// Start of Conversion 0 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCB_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN1, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCB_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 1 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN1
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCB_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN1, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCB_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	//
	// Start of Conversion 2 Configuration
	//
	//
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 2
	//	  	Trigger			: ADC_TRIGGER_SW_ONLY
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 10 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	//
	ADC_setupSOC(BASE_ADCB_BASE, ADC_SOC_NUMBER2, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN2, 10U);
	ADC_setInterruptSOCTrigger(BASE_ADCB_BASE, ADC_SOC_NUMBER2, ADC_INT_SOC_TRIGGER_NONE);
}

//*****************************************************************************
//
// AIO Configurations
//
//*****************************************************************************
void AIO_init(){
	FANFAIL1_init();
	PFC_UVPn_init();
	DCOVPn_init();
	PFC_UV2n_init();
}

void FANFAIL1_init(){
	GPIO_setAnalogMode(FANFAIL1, GPIO_ANALOG_DISABLED);
	GPIO_setDirectionMode(FANFAIL1, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(FANFAIL1, GPIO_PIN_TYPE_STD);
	GPIO_setControllerCore(FANFAIL1, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(FANFAIL1, GPIO_QUAL_SYNC);
}
void PFC_UVPn_init(){
	GPIO_setAnalogMode(PFC_UVPn, GPIO_ANALOG_DISABLED);
	GPIO_setDirectionMode(PFC_UVPn, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(PFC_UVPn, GPIO_PIN_TYPE_STD);
	GPIO_setControllerCore(PFC_UVPn, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(PFC_UVPn, GPIO_QUAL_SYNC);
}
void DCOVPn_init(){
	GPIO_setAnalogMode(DCOVPn, GPIO_ANALOG_DISABLED);
	GPIO_setDirectionMode(DCOVPn, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(DCOVPn, GPIO_PIN_TYPE_STD);
	GPIO_setControllerCore(DCOVPn, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(DCOVPn, GPIO_QUAL_SYNC);
}
void PFC_UV2n_init(){
	GPIO_setAnalogMode(PFC_UV2n, GPIO_ANALOG_DISABLED);
	GPIO_setDirectionMode(PFC_UV2n, GPIO_DIR_MODE_IN);
	GPIO_setPadConfig(PFC_UV2n, GPIO_PIN_TYPE_STD);
	GPIO_setControllerCore(PFC_UV2n, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(PFC_UV2n, GPIO_QUAL_SYNC);
}

//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************
void ASYSCTL_init(){
	//
	// asysctl initialization
	//
	// Disables the temperature sensor output to the ADC.
	//
	ASysCtl_disableTemperatureSensor();
	//
	// Set the analog voltage reference selection to external.
	//
	ASysCtl_setAnalogReferenceExternal( ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC );
}

//*****************************************************************************
//
// DAC Configurations
//
//*****************************************************************************
void DAC_init(){
	CC_DA_init();
	DEBUG_DACB_init();
}

void CC_DA_init(){
	//
	// Set DAC reference voltage.
	//
	DAC_setReferenceVoltage(CC_DA_BASE, DAC_REF_ADC_VREFHI);
	//
	// Set DAC gain mode.
	//
	DAC_setGainMode(CC_DA_BASE, DAC_GAIN_ONE);
	//
	// Set DAC load mode.
	//
	DAC_setLoadMode(CC_DA_BASE, DAC_LOAD_SYSCLK);
	//
	// Enable the DAC output
	//
	DAC_enableOutput(CC_DA_BASE);
	//
	// Set the DAC shadow output
	//
	DAC_setShadowValue(CC_DA_BASE, 0U);

	//
	// Delay for buffered DAC to power up.
	//
	DEVICE_DELAY_US(500);
}
void DEBUG_DACB_init(){
	//
	// Set DAC reference voltage.
	//
	DAC_setReferenceVoltage(DEBUG_DACB_BASE, DAC_REF_ADC_VREFHI);
	//
	// Set DAC gain mode.
	//
	DAC_setGainMode(DEBUG_DACB_BASE, DAC_GAIN_ONE);
	//
	// Set DAC load mode.
	//
	DAC_setLoadMode(DEBUG_DACB_BASE, DAC_LOAD_SYSCLK);
	//
	// Enable the DAC output
	//
	DAC_enableOutput(DEBUG_DACB_BASE);
	//
	// Set the DAC shadow output
	//
	DAC_setShadowValue(DEBUG_DACB_BASE, 0U);

	//
	// Delay for buffered DAC to power up.
	//
	DEVICE_DELAY_US(500);
}

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
void EPWM_init(){
    EPWM_setClockPrescaler(CLK0_5_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_2);	
    EPWM_setTimeBasePeriod(CLK0_5_BASE, 0);	
    EPWM_setTimeBaseCounter(CLK0_5_BASE, 0);	
    EPWM_setTimeBaseCounterMode(CLK0_5_BASE, EPWM_COUNTER_MODE_STOP_FREEZE);	
    EPWM_disablePhaseShiftLoad(CLK0_5_BASE);	
    EPWM_setPhaseShift(CLK0_5_BASE, 0);	
    EPWM_setCounterCompareValue(CLK0_5_BASE, EPWM_COUNTER_COMPARE_A, 0);	
    EPWM_setCounterCompareShadowLoadMode(CLK0_5_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(CLK0_5_BASE, EPWM_COUNTER_COMPARE_B, 0);	
    EPWM_setCounterCompareShadowLoadMode(CLK0_5_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(CLK0_5_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(CLK0_5_BASE);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(CLK0_5_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(CLK0_5_BASE);	
    EPWM_setClockPrescaler(CLK180_5_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_2);	
    EPWM_setTimeBasePeriod(CLK180_5_BASE, 0);	
    EPWM_setTimeBaseCounter(CLK180_5_BASE, 0);	
    EPWM_setTimeBaseCounterMode(CLK180_5_BASE, EPWM_COUNTER_MODE_STOP_FREEZE);	
    EPWM_disablePhaseShiftLoad(CLK180_5_BASE);	
    EPWM_setPhaseShift(CLK180_5_BASE, 0);	
    EPWM_setCounterCompareValue(CLK180_5_BASE, EPWM_COUNTER_COMPARE_A, 0);	
    EPWM_setCounterCompareShadowLoadMode(CLK180_5_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(CLK180_5_BASE, EPWM_COUNTER_COMPARE_B, 0);	
    EPWM_setCounterCompareShadowLoadMode(CLK180_5_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(CLK180_5_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(CLK180_5_BASE);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(CLK180_5_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(CLK180_5_BASE);	
    EPWM_setClockPrescaler(FANCTRL5_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_2);	
    EPWM_setTimeBasePeriod(FANCTRL5_BASE, 0);	
    EPWM_setTimeBaseCounter(FANCTRL5_BASE, 0);	
    EPWM_setTimeBaseCounterMode(FANCTRL5_BASE, EPWM_COUNTER_MODE_STOP_FREEZE);	
    EPWM_disablePhaseShiftLoad(FANCTRL5_BASE);	
    EPWM_setPhaseShift(FANCTRL5_BASE, 0);	
    EPWM_setCounterCompareValue(FANCTRL5_BASE, EPWM_COUNTER_COMPARE_A, 0);	
    EPWM_setCounterCompareShadowLoadMode(FANCTRL5_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setCounterCompareValue(FANCTRL5_BASE, EPWM_COUNTER_COMPARE_B, 0);	
    EPWM_setCounterCompareShadowLoadMode(FANCTRL5_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);	
    EPWM_setActionQualifierAction(FANCTRL5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);	
    EPWM_setRisingEdgeDelayCountShadowLoadMode(FANCTRL5_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(FANCTRL5_BASE);	
    EPWM_setFallingEdgeDelayCountShadowLoadMode(FANCTRL5_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);	
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(FANCTRL5_BASE);	
}

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
void GPIO_init(){
	SPIA_CS_init();
	SPIA_MOSI_init();
	SPIA_CLK_init();
	OFF_PWMn_init();
	MASTER_init();
	PFC_OVPn_init();
	ACFAIL5_init();
	PFC_OVP2n_init();
	PFC_OTPn_init();
	FANFAIL3_init();
	FANFAIL2_init();
	FANFAIL4_init();
}

void SPIA_CS_init(){
	GPIO_setPadConfig(SPIA_CS, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIA_CS, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(SPIA_CS, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(SPIA_CS, GPIO_CORE_CPU1);
}
void SPIA_MOSI_init(){
	GPIO_setPadConfig(SPIA_MOSI, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIA_MOSI, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(SPIA_MOSI, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(SPIA_MOSI, GPIO_CORE_CPU1);
}
void SPIA_CLK_init(){
	GPIO_setPadConfig(SPIA_CLK, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(SPIA_CLK, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(SPIA_CLK, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(SPIA_CLK, GPIO_CORE_CPU1);
}
void OFF_PWMn_init(){
	GPIO_writePin(OFF_PWMn, 0);
	GPIO_setPadConfig(OFF_PWMn, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(OFF_PWMn, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(OFF_PWMn, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(OFF_PWMn, GPIO_CORE_CPU1);
}
void MASTER_init(){
	GPIO_writePin(MASTER, 0);
	GPIO_setPadConfig(MASTER, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(MASTER, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(MASTER, GPIO_DIR_MODE_OUT);
	GPIO_setControllerCore(MASTER, GPIO_CORE_CPU1);
}
void PFC_OVPn_init(){
	GPIO_setPadConfig(PFC_OVPn, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PFC_OVPn, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(PFC_OVPn, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(PFC_OVPn, GPIO_CORE_CPU1);
}
void ACFAIL5_init(){
	GPIO_setPadConfig(ACFAIL5, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(ACFAIL5, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(ACFAIL5, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(ACFAIL5, GPIO_CORE_CPU1);
}
void PFC_OVP2n_init(){
	GPIO_setPadConfig(PFC_OVP2n, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PFC_OVP2n, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(PFC_OVP2n, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(PFC_OVP2n, GPIO_CORE_CPU1);
}
void PFC_OTPn_init(){
	GPIO_setPadConfig(PFC_OTPn, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(PFC_OTPn, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(PFC_OTPn, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(PFC_OTPn, GPIO_CORE_CPU1);
}
void FANFAIL3_init(){
	GPIO_setPadConfig(FANFAIL3, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(FANFAIL3, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(FANFAIL3, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(FANFAIL3, GPIO_CORE_CPU1);
}
void FANFAIL2_init(){
	GPIO_setPadConfig(FANFAIL2, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(FANFAIL2, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(FANFAIL2, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(FANFAIL2, GPIO_CORE_CPU1);
}
void FANFAIL4_init(){
	GPIO_setPadConfig(FANFAIL4, GPIO_PIN_TYPE_STD);
	GPIO_setQualificationMode(FANFAIL4, GPIO_QUAL_SYNC);
	GPIO_setDirectionMode(FANFAIL4, GPIO_DIR_MODE_IN);
	GPIO_setControllerCore(FANFAIL4, GPIO_CORE_CPU1);
}

//*****************************************************************************
//
// SPI Configurations
//
//*****************************************************************************
void SPI_init(){
	SPIA_ISHARE_init();
	SPIB_SLAVE_init();
}

void SPIA_ISHARE_init(){
	SPI_disableModule(SPIA_ISHARE_BASE);
	SPI_setConfig(SPIA_ISHARE_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
				  SPI_MODE_CONTROLLER, 5000000, 16);
	SPI_setPTESignalPolarity(SPIA_ISHARE_BASE, SPI_PTE_ACTIVE_LOW);
	SPI_enableFIFO(SPIA_ISHARE_BASE);
	SPI_setFIFOInterruptLevel(SPIA_ISHARE_BASE, SPI_FIFO_TXEMPTY, SPI_FIFO_RXEMPTY);
	SPI_disableLoopback(SPIA_ISHARE_BASE);
	SPI_setEmulationMode(SPIA_ISHARE_BASE, SPI_EMULATION_STOP_MIDWAY);
	SPI_enableModule(SPIA_ISHARE_BASE);
}
void SPIB_SLAVE_init(){
	SPI_disableModule(SPIB_SLAVE_BASE);
	SPI_setConfig(SPIB_SLAVE_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
				  SPI_MODE_PERIPHERAL, 20000000, 16);
	SPI_setPTESignalPolarity(SPIB_SLAVE_BASE, SPI_PTE_ACTIVE_LOW);
	SPI_enableFIFO(SPIB_SLAVE_BASE);
	SPI_setFIFOInterruptLevel(SPIB_SLAVE_BASE, SPI_FIFO_TXEMPTY, SPI_FIFO_RXEMPTY);
	SPI_disableLoopback(SPIB_SLAVE_BASE);
	SPI_setEmulationMode(SPIB_SLAVE_BASE, SPI_EMULATION_STOP_MIDWAY);
	SPI_enableModule(SPIB_SLAVE_BASE);
}

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************
void SYNC_init(){
	SysCtl_setSyncOutputConfig(SYSCTL_SYNC_OUT_SRC_EPWM1SYNCOUT);
	//
	// For EPWM1, the sync input is: SYSCTL_SYNC_IN_SRC_EXTSYNCIN1
	//
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_EPWM4, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_EPWM7, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_ECAP1, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_ECAP4, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_ECAP6, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
	//
	// SOCA
	//
	SysCtl_enableExtADCSOCSource(0);
	//
	// SOCB
	//
	SysCtl_enableExtADCSOCSource(0);
}
