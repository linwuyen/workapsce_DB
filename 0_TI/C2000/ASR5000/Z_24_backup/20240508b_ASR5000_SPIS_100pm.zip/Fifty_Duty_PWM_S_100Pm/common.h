
#ifndef COMMON_H_
#define COMMON_H_

#ifndef bool_t
typedef bool bool_t;
#endif

#define SW_TIMER       50000000
#define U32_COUNTER     (uint32_t)CPUTimer_getTimerCount(SWTIRMER_BASE)

#define U32_UPCNTS      (SW_TIMER - U32_COUNTER)

#define T_10US          (SW_TIMER/100000)
#define T_50US          (SW_TIMER/20000)
#define T_125US         (SW_TIMER/8000)
#define T_250US         (SW_TIMER/4000)

#define T_500US         (SW_TIMER/2000)
#define T_1MS           (SW_TIMER/1000)
#define T_2D5MS         (SW_TIMER/400)
#define T_5MS           (SW_TIMER/200)
#define T_10MS          (SW_TIMER/100)
#define T_20MS          (SW_TIMER/50)
#define T_25MS          (SW_TIMER/40)
#define T_50MS          (SW_TIMER/20)
#define T_100MS         (SW_TIMER/10)
#define T_200MS         (SW_TIMER/5)
#define T_500MS         (SW_TIMER/2)
#define T_1S            (SW_TIMER/1)


typedef struct _ST_TIMETASK{
    void (*fn) (void * s);
    uint32_t cnt;
    uint32_t max;
} ST_TIMETASK;


bool_t scanTimeTask(ST_TIMETASK *t, void *s)
{
    static uint32_t delta_t;
    static uint32_t u32Cnt = 0;

    u32Cnt = SW_TIMER - (uint32_t)CPUTimer_getTimerCount(SWTIRMER_BASE);

    if(t->cnt > u32Cnt) {
        delta_t = u32Cnt + SW_TIMER - t->cnt;
    }
    else {
        delta_t = u32Cnt - t->cnt;
    }
    if(delta_t >= t->max) {
        t->fn(s);
        t->cnt = u32Cnt;
        return true;
    }
    else {
        return false;
    }
}

void init_PWM_0(void)
{
    EPWM_setClockPrescaler(CLK0_5_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(CLK0_5_BASE, 500);
    EPWM_setTimeBaseCounter(CLK0_5_BASE, 0);
    EPWM_setTimeBaseCounterMode(CLK0_5_BASE, EPWM_COUNTER_MODE_UP_DOWN);
    EPWM_disablePhaseShiftLoad(CLK0_5_BASE);
    EPWM_setPhaseShift(CLK0_5_BASE, 0);
    EPWM_setCounterCompareValue(CLK0_5_BASE, EPWM_COUNTER_COMPARE_A, 250);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_CMPA_CMPAHR);
    EPWM_setCounterCompareShadowLoadMode(CLK0_5_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_setCounterCompareValue(CLK0_5_BASE, EPWM_COUNTER_COMPARE_B, 250);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_CMPB_CMPBHR);
    EPWM_setCounterCompareShadowLoadMode(CLK0_5_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_AQCTLA_AQCTLA2);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
    EPWM_enableGlobalLoadRegisters(CLK0_5_BASE, EPWM_GL_REGISTER_AQCTLB_AQCTLB2);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK0_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
    EPWM_setDeadBandDelayPolarity(CLK0_5_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
    EPWM_setDeadBandDelayMode(CLK0_5_BASE, EPWM_DB_RED, true);
    EPWM_setRisingEdgeDelayCountShadowLoadMode(CLK0_5_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(CLK0_5_BASE);
    EPWM_setDeadBandDelayMode(CLK0_5_BASE, EPWM_DB_FED, true);
    EPWM_setFallingEdgeDelayCountShadowLoadMode(CLK0_5_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(CLK0_5_BASE);
}
void init_PWM_180(void)
{
    //trigger ADC ISR
    EPWM_forceSyncPulse(CLK0_5_BASE);
    EPWM_setClockPrescaler(CLK180_5_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(CLK180_5_BASE, 500);
    EPWM_setTimeBaseCounter(CLK180_5_BASE, 0);
    EPWM_setTimeBaseCounterMode(CLK180_5_BASE, EPWM_COUNTER_MODE_UP_DOWN);

    EPWM_enablePhaseShiftLoad(CLK180_5_BASE);
    EPWM_setPhaseShift(CLK180_5_BASE, 250);
    EPWM_setSyncOutPulseMode(CLK180_5_BASE, EPWM_SYNC_OUT_PULSE_ON_COUNTER_ZERO);
    EPWM_setCounterCompareValue(CLK180_5_BASE, EPWM_COUNTER_COMPARE_A, 250);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_CMPA_CMPAHR);
    EPWM_setCounterCompareShadowLoadMode(CLK180_5_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_setCounterCompareValue(CLK180_5_BASE, EPWM_COUNTER_COMPARE_B, 250);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_CMPB_CMPBHR);
    EPWM_setCounterCompareShadowLoadMode(CLK180_5_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_AQCTLA_AQCTLA2);

    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
    EPWM_enableGlobalLoadRegisters(CLK180_5_BASE, EPWM_GL_REGISTER_AQCTLB_AQCTLB2);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(CLK180_5_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);

    EPWM_setDeadBandDelayPolarity(CLK180_5_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
    EPWM_setDeadBandDelayMode(CLK180_5_BASE, EPWM_DB_RED, true);

    EPWM_setRisingEdgeDelayCountShadowLoadMode(CLK180_5_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(CLK180_5_BASE);
    EPWM_setDeadBandDelayMode(CLK180_5_BASE, EPWM_DB_FED, true);
    EPWM_setFallingEdgeDelayCountShadowLoadMode(CLK180_5_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(CLK180_5_BASE);
}

#endif /* COMMON_H_ */
