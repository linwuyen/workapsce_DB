/*
 * Modbus_Ctrl.h
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#ifndef MODBUS_CTRL_H_
#define MODBUS_CTRL_H_

#include "ModbusMaster.h"
#include "ModbusSlave.h"
#include "SPWM_Ctrl.h"


#define SLAVE_REG_ADDR            1000
#define MAX_POSSIBLE_SLAVES         10

#define PAR_ENA          0
#define PAR_DIS          1

#define RE               0  //485 READ Mode
#define DE               1  //485 WIRTE Mode

typedef enum
{
    MODE_MASTER = 0,
    MODE_SLAVE,
} Modbus_Mode;

typedef enum {
    MB_STATUS_BUSY,
    MB_STATUS_SUCCESS,
    MB_STATUS_FAIL
} ModbusStatus;

typedef enum {
    ADDR_STATE_IDLE = 0,
    ADDR_STATE_START,
    ADDR_STATE_BROADCAST_WRITE,
    ADDR_STATE_WAIT_FOR_PNA,
    ADDR_STATE_SEND_VERIFY_READ,
    ADDR_STATE_WAIT_FOR_RESPONSE,
    ADDR_STATE_SUCCESS,
    ADDR_STATE_FINISH,
    TEST,
    ADDR_STATE_ERROR
} AutoAddress_State;

typedef struct
{
    Modbus_Mode               MODE;

    AutoAddress_State        STATE;

    CMDPACK                Package;
    CMDPACK               TestPack;

    uint16_t                AM3352;

    uint16_t               NEXT_ID;
    uint16_t              TOTAL_ID;
    uint16_t            Polling_ID;

    Uint16         fsm_timer_start;
    Uint16        new_id_to_assign;
    uint16_t      total_discovered;

    Uint16  temp_register_value[1];
    Uint16      response_buffer[1];

} ModbusController;

extern volatile uint16_t g_addressing_is_complete;

extern void Run_Modbus_FSM(void);

#endif /* MODBUS_CTRL_H_ */
