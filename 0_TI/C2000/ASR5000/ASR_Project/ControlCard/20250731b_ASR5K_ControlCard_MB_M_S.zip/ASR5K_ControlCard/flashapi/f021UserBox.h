/*
 * f021UserBbox.h
 *
 *  Created on: Apr 16, 2024
 *      Author: User
 */

#ifndef F021USERBOX_H_
#define F021USERBOX_H_

extern void rstWriteUserBoxTimeStamp(void);
extern void runUserBox(void);

#endif /* F021USERBOX_H_ */
