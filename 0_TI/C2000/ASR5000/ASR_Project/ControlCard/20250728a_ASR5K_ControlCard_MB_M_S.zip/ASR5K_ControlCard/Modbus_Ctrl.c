/*
 * Modbus_Ctrl.c
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#include "Modbus_Ctrl.h"

ModbusController Conn = {
    .current_mode = MODE_SLAVE,
    .current_state = S_FSM_IDLE,
    .NEXT_ID = 1,
    .TOTAL_ID = 0,
    .SEND = 0
};

void getStatus()
{
//mbus->evstep _POP_COMMAND_OUTm = exeModbusMaster IDLE
//mbus->state  MBUS_SUCCESSm TRANS_SUCCESS�C
//ModbusmStatus getStatus(SCI_MODBUSm *mbus) {
//    if (mbus->evstep == _POP_COMMAND_OUTm && mbus->pData == NULL) {
//        if (mbus->state == MBUS_SUCCESSm) { return TRANS_SUCCESS; }
//        else { return TRANS_FAILED; }
//    }
//    return TRANS_BUSY;
//}
}
//------------------------------------------------------------------

void MasterState_Idle(ModbusController *p)
{
    p->current_state = M_FSM_HW_PREPARE;
}

void MasterState_HW_PREPARE(ModbusController *p)
{
//        PAR_ENA;
    GPIO_writePin(PAR, PAR_ENA);

//     49 SPI_MODE switch M
    sSPIA.NewFSM = _Mode_Master;

//    485
    GPIO_writePin(TXC_RXC, DE);

    p->current_state = M_FSM_BroadcastPACK;
}

void MasterState_BroadcastPACK(ModbusController *p)
{

    p->WritePack.slave    = 0x00;
    p->WritePack.function = 0x06;
    p->WritePack.address  = 1000;
    p->WritePack.points    = 0x01;
    // �sID
    regMbusData.u16MbusData[6] = p->NEXT_ID;
    p->WritePack.reg = (Uint16*) &regMbusData.u16MbusData[6];

    p->current_state =  M_FSM_SendBroadcastPACK;
}

void MasterState_SendBroadcastPACK(ModbusController *p)
{
        pushCmdPack(&p->WritePack);
        p->current_state =   M_FSM_PrepareReadPackage;
}

void MasterState_PrepareReadPackage(ModbusController *p)
{

    p->ReadPack.slave = p->NEXT_ID;
    p->ReadPack.function = 0x03;
    p->ReadPack.address = 1000;
    p->ReadPack.points = 0x01;
    p->ReadPack.reg = (Uint16*)&regMbusData.u16MbusData[6];
//    p->current_state =   M_FSM_SendReadPackage;

}


void MasterState_SendReadPackage(ModbusController *p)
{
        pushCmdPack(&p->ReadPack);

        if(p->NEXT_ID == regMbusData.u16MbusData[6]){
            p->NEXT_ID++;
            p->Polling_ID = p->NEXT_ID ;
            p->current_state = M_FSM_DISCOVERY_DONE;
    }
        else{
            p->current_state = M_FSM_BroadcastPACK;
        }
}

void MasterState_DISCOVERY_DONE(ModbusController *p)
{





//    p->FSM.M = M_FSM_NORMAL_POLLING;
}

void MasterState_NORMAL_POLLING(ModbusController *p)
{

}
void MasterState_ERROR(ModbusController *p)
{

}
//-----------------------------------------

void SlaveState_Idle(ModbusController *p)
{

    GPIO_writePin(TXC_RXC, RE);
    // ��ID�s�L�F
      if( mbcomm_s.slaveid  == 0){
          p->current_state = S_FSM_ID_ASSIGNED;
        }
}

void SlaveState_ID_ASSIGNED(ModbusController *p)
{
        if(0 != regMbusData.u16MbusData[6])
        {
            mbcomm_s.slaveid = regMbusData.u16MbusData[6];
        }
        p->current_state = S_FSM_NORMAL_OPERATION;;
}

void SlaveState_NORMAL_OPERATION(ModbusController *p)
{

    if(mbcomm_s.slaveid != 0){
        GPIO_writePin(PAR, PAR_ENA);
    }
    return;
}

//----------------------------------------
void test_Idle(ModbusController *p)
{

}

void read_pack(ModbusController *p)
{
    if (p->SEND == 1)
    {
        p->ReadPack.slave =     0x03;
        p->ReadPack.function =  0x03;
        p->ReadPack.address =   1000;
        p->ReadPack.points =    0x03;
        p->ReadPack.reg = (Uint16*) &regMbusData.u16MbusData[6];
        pushCmdPack(&(p->ReadPack));
        p->SEND  = 0;
    }
}

void write_pack(ModbusController *p)
{
    if (p->SEND == 1)
    {
        p->WritePack.slave =     0x03;
        p->WritePack.function =  0x06;
        p->WritePack.address =   1000;
        p->WritePack.points =    0x01;
        p->WritePack.reg = (Uint16*) &regMbusData.u16MbusData[6];
        pushCmdPack(&(p->WritePack));
        p->SEND  = 0;
    }
}

void writeN_pack(ModbusController *p)
{
    if (p->SEND == 1)
    {
        p->TestPack.slave =     0x03;
        p->TestPack.function =  0x10;
        p->TestPack.address =   1000;
        p->TestPack.points =    0x02;
        p->TestPack.bytes = p->TestPack.points * 2 ;
        p->TestPack.reg = (Uint16*) &regMbusData.u16MbusData[6];
        pushCmdPack(&(p->TestPack));
        p->SEND  = 0;
    }
}


typedef void (*StateHandler)(ModbusController *p);

//  ���C�ӼҦ��إߪ��A��
const StateHandler Master_FSM_Table[MASTER_STATE_COUNT] = {
    [M_FSM_IDLE]                = MasterState_Idle,
    [M_FSM_HW_PREPARE]          = MasterState_HW_PREPARE,
    [M_FSM_BroadcastPACK]       = MasterState_BroadcastPACK,
    [M_FSM_SendBroadcastPACK]   = MasterState_SendBroadcastPACK,
    [M_FSM_PrepareReadPackage]  = MasterState_PrepareReadPackage,
    [M_FSM_SendReadPackage]     = MasterState_SendReadPackage,
    [M_FSM_DISCOVERY_DONE]      = MasterState_DISCOVERY_DONE,
    [M_FSM_NORMAL_POLLING]      = MasterState_NORMAL_POLLING,
    [M_FSM_ERROR]               = MasterState_ERROR,
};

const StateHandler Slave_FSM_Table[SLAVE_STATE_COUNT] = {
    [S_FSM_IDLE]                = SlaveState_Idle,
    [S_FSM_ID_ASSIGNED]         = SlaveState_ID_ASSIGNED,
    [S_FSM_NORMAL_OPERATION]    = SlaveState_NORMAL_OPERATION,
};

const StateHandler Test_FSM_Table[TEST_STATE_COUNT] = {
    [T_FSM_IDLE]                = test_Idle,
    [T_FSM_read_pack]           = read_pack,
    [T_FSM_write_pack]          = write_pack,
    [T_FSM_writeN_pack]         = writeN_pack,
};

// �إߥD�d��� (�@�ӫ��V�U�Ӫ��A�������а}�C)
const StateHandler * const Main_FSM_Table[MODE_COUNT] = {
    [MODE_MASTER]      = Master_FSM_Table,
    [MODE_SLAVE]       = Slave_FSM_Table,
    [MODE_Master_TEST] = Test_FSM_Table,
};

//
void Run_Modbus_FSM()
{
    ModbusController *p = &Conn; // �ϥΫ��Ы��V������


    if (p->AM3352 == 0) {
        p->current_mode = MODE_SLAVE;
        exeModbusSlave((SCI_MODBUSs*) &mbcomm_s);
    } else if(p->AM3352 == 1) {
        p->current_mode = MODE_MASTER;
        exeModbusMaster((SCI_MODBUSm*) &mbcomm_m);
    } else {
        p->current_mode = MODE_Master_TEST;
        exeModbusMaster((SCI_MODBUSm*) &mbcomm_m);
    }
    // ---------------------------------------------------


    if (p->current_mode >= MODE_COUNT) {
        // ���~�B�z
        return;
    }

    // �q�D�����������Ҧ������A��
    const StateHandler *state_table = Main_FSM_Table[p->current_mode];

    // �ھڼҦ��T�w���A�ƶq���W���A�i��ĤG������ˬd
    int max_states = 0;
    if (p->current_mode == MODE_MASTER) max_states = MASTER_STATE_COUNT;
    else if (p->current_mode == MODE_SLAVE) max_states = SLAVE_STATE_COUNT;
    else if (p->current_mode == MODE_Master_TEST) max_states = TEST_STATE_COUNT;

    if (p->current_state >= max_states) {
        // ���~�B�z: ���e���A��󦹼Ҧ��O�L�Ī�
        // �i�H�Ҽ{�����@�Ӧw�����w�]���A�A�Ҧp IDLE
        if (p->current_mode == MODE_MASTER) p->current_state = M_FSM_IDLE;
        else if (p->current_mode == MODE_SLAVE) p->current_state = S_FSM_IDLE;
        else p->current_state = T_FSM_IDLE;
        return;
    }

    // ���o�Ӫ��A�������B�z�禡
    StateHandler handler = state_table[p->current_state];

    // �p�G�禡���Ф��� NULL�A�N���楦
    if (handler != NULL) {
        handler(p);
    } else {
        // ���~�B�z: �����A�S���w�q�������B�z�禡
    }
}
