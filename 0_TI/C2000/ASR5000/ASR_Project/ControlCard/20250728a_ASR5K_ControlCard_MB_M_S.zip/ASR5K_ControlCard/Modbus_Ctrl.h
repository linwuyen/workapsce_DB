/*
 * Modbus_Ctrl.h
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#ifndef MODBUS_CTRL_H_
#define MODBUS_CTRL_H_

#include "ModbusMaster.h"
#include "ModbusSlave.h"
#include "SPWM_Ctrl.h"

#define ROM_BUFFER_SIZE 16
#define SLAVE_REG_ADDR 1000

#define PAR_ENA          0
#define PAR_DIS          1

#define RE               0  //485 READ Mode
#define DE               1  //485 WIRTE Mode

typedef enum
{
    MODE_MASTER = 0,
    MODE_SLAVE,
    MODE_Master_TEST,
    MODE_COUNT
} Modbus_Mode;


typedef enum
{
    M_FSM_IDLE  = 0,
    M_FSM_HW_PREPARE,
    M_FSM_BroadcastPACK,
    M_FSM_SendBroadcastPACK,
    M_FSM_PrepareReadPackage,
    M_FSM_SendReadPackage,
    M_FSM_DISCOVERY_DONE,
    M_FSM_NORMAL_POLLING,
    M_FSM_ERROR,
    MASTER_STATE_COUNT
} Master_FSM_State;


typedef enum
{
    S_FSM_IDLE  = 0,
    S_FSM_ID_ASSIGNED,
    S_FSM_NORMAL_OPERATION,
    SLAVE_STATE_COUNT,
    TEST_STATE_COUNT
} Slave_FSM_State;


typedef enum
{
    T_FSM_IDLE  = 0,
    T_FSM_read_pack,
    T_FSM_write_pack,
    T_FSM_writeN_pack,
} Test_FSM_State;

typedef struct
{
    Modbus_Mode current_mode;
    uint16_t    current_state;

    CMDPACK ReadPack;
    CMDPACK WritePack;
    CMDPACK TestPack;

    uint16_t    AM3352;
    uint16_t      SEND;

    uint16_t NEXT_ID;
    uint16_t TOTAL_ID;
    uint16_t Polling_ID;

    Uint16 LinkEEPROM[ROM_BUFFER_SIZE];

} ModbusController;


extern void Run_Modbus_FSM(void);

#endif /* MODBUS_CTRL_H_ */
