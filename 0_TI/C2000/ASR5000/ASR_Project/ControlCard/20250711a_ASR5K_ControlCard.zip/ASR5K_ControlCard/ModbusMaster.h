/*
 * ModbusMaster.h
 *
 *  Created on: Jul 10, 2025
 *      Author: roger_lin
 */

#ifndef MODBUSMASTER_H_
#define MODBUSMASTER_H_







extern int16_t exeModbusMaster (SCI_MODBUS *mbus);


#endif /* MODBUSMASTER_H_ */
