/*
 * Modbus_Ctrl.c
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#include "Modbus_Ctrl.h"

CMDPACK confirmID;
CMDPACK ReadPack;
CMDPACK WritePack;



#define BUFFER_SIZE 16
#define SLAVE_REG_ADDR 1000
#define PAR_ENA    0
#define PAR_DIS    1
#define RE     0//485 READ Mode
#define DE     1//485 WIRTE Mode


typedef enum
{
    _IDLE,
    _PREPARE_TRANSFER,
    _PREPARE_PACKAGE,
    _SEND_BROADCAST,
    _WAIT_SLAVE_CONFIG, // add�G wait slave Config timeout
    _SEND_PACKING,
    _PROCESS_READ_RESULT,
    _NORMAL_OPERATION
} Assign_FSM;

typedef enum
{
    MODE_MASTER,
    MODE_SLAVE
} Modbus_Mode;

typedef enum
{
    TRANS_SUCCESS,
    TRANS_FAILED,
    TRANS_BUSY
} Modbus_Status;

typedef struct
{
    Modbus_Mode      MODE;
    Modbus_Status MB_STATUS;
    Assign_FSM      ID_FSM;


    Uint16 LinkEEPROM[BUFFER_SIZE];

    uint16_t       ReadID;
    uint16_t    MASTER_ON;
    uint16_t       PARENA;

    uint16_t         Done;
    uint16_t       AM3352;
    uint16_t      NEXT_ID;
    uint16_t     TOTAL_ID;
    uint16_t   Polling_ID;
} stConnect;

stConnect Conn = { .MODE = MODE_SLAVE,
                   .ID_FSM = _IDLE,
                   .MB_STATUS = TRANS_BUSY,
                   .AM3352 = 0,
                   .NEXT_ID = 1,
                   .TOTAL_ID = 0,
                   .Polling_ID = 1 };

void Modbus_Switch(void)
{
    //  AM3352
    if (Conn.AM3352 == 1)
    {
        Conn.MODE = MODE_MASTER;
    }
    else
    {
        Conn.MODE = MODE_SLAVE;
    }

    if (Conn.MODE == MODE_MASTER)
    {
        exeModbusMaster((SCI_MODBUSm*) &mbcomm_m);
        Conn.ID_FSM = _PREPARE_TRANSFER;
    }
    else
    {
        exeModbusSlave((SCI_MODBUSs*) &mbcomm_s);
    }

    switch (Conn.ID_FSM)
    {

    case _IDLE:
        break;

    case _PREPARE_TRANSFER:
//        PAR_ENA;
        GPIO_writePin(PAR,PAR_ENA);
//     49 SPI_MODE to M
//     485 transfer
        GPIO_writePin(TXC_RXC,DE);
        Conn.ID_FSM = _PREPARE_PACKAGE;
        break;

    case   _PREPARE_PACKAGE:
        confirmID.slave = 0x00;
        confirmID.function= 0x06;
        confirmID.address=  1000;
        confirmID.points= 0x01;
        confirmID.reg =  (Uint16 *)&regMbusData.u16MbusData[6];
        Conn.ID_FSM = _SEND_BROADCAST;
        break;

    case _SEND_BROADCAST:

        if (Conn.Done == 1)
        {
            pushCmdPack(&confirmID);
            Conn.Done = 0;
        }

        break;

    case _WAIT_SLAVE_CONFIG:
        break;


    case _SEND_PACKING:


        break;

    case _PROCESS_READ_RESULT:

        break;

    case _NORMAL_OPERATION:
        break;


    default:
        break;
    }
}



// IO66 485

//mbus->evstep _POP_COMMAND_OUTm = exeModbusMaster IDLE
//mbus->state  MBUS_SUCCESSm TRANS_SUCCESS�C

//ModbusmStatus getStatus(SCI_MODBUSm *mbus) {
//    if (mbus->evstep == _POP_COMMAND_OUTm && mbus->pData == NULL) {
//        if (mbus->state == MBUS_SUCCESSm) { return TRANS_SUCCESS; }
//        else { return TRANS_FAILED; }
//    }
//    return TRANS_BUSY;
//}

//void Modbus_Control(void) {
//
//    if (Conn.STATE != MODE_MASTER) {
//        if (Conn.ID_FSM != _IDLE) {
//            Conn.ID_FSM = _IDLE;
//        }
//        return;
//    }
//
//    Conn.MBstatus = getStatus(&mbcomm_m);
//    if (Conn.MBstatus == TRANS_BUSY && Conn.ID_FSM != _PROCESS_READ_RESULT) {
//        return;
//    }
//
//    switch(Conn.ID_FSM) {
//
//        case _IDLE:
//            Conn.NEXT_ID = 1;
//            Conn.TOTAL_ID = 0;
//            Conn.ID_FSM = _SEND_BROADCAST;
//            break;
//
//        case _SEND_BROADCAST:
//// �g�J�ʥ]
//            Conn.Tx_buffer[0] = Conn.NEXT_ID;
//            Conn.Tx_buffer[1] = 1;
//
//            sendpack1.slave = 0;
//            sendpack1.function = 16;
//            sendpack1.address = SLAVE_ID_REG_ADDR;
//            sendpack1.points = 2;
//            sendpack1.bytes = 4;
//            sendpack1.reg = Conn.Tx_buffer;
//
//            pushCmdPack(&sendpack1);
//
//            Conn.ID_FSM = _SEND_CONFIRMATION;
////            startAppTimer(50); // �p�ɾ�
//            break;
//
////�s�����O�M�U�@�ӽT�{���O�����гy�@�Ӧܤ֤@�� main �j�骺�L�p����
////        case _WAIT_SLAVE_CONFIG:
////            //2�G���ݭp�ɾ�
//////            if (isAppTimerExpired()) {
////            Conn.stFSM = _SEND_CONFIRMATION;
//////            }
////            break;
//
//        case _SEND_CONFIRMATION:
//// load �ʥ]
//            sendpack1.slave = Conn.NEXT_ID;
//            sendpack1.function = 3;
//            sendpack1.address = SLAVE_ID_REG_ADDR;
//            sendpack1.points = 1;
//            sendpack1.bytes = 2;
//            sendpack1.reg = NULL;
//
//            pushCmdPack(&sendpack1);
//
//
//            Conn.ID_FSM = _PROCESS_READ_RESULT;
//            break;
//
//        case _PROCESS_READ_RESULT:
//            {
//                if (Conn.MBstatus == TRANS_SUCCESS) {
//
//                    Conn.TOTAL_ID++;
//                    Conn.NEXT_ID++;
//
//                    Conn.ID_FSM = _SEND_BROADCAST;
//
//                } else if (Conn.MBstatus == TRANS_FAILED) {
//
//                    if (Conn.TOTAL_ID > 0) {
//
//                        Conn.ID_FSM = _NORMAL_OPERATION;
//                        Conn.Polling_ID = 1;
//                    } else {
//
//                        Conn.ID_FSM = _IDLE;
//                    }
//                }
//            }
//            break;
//
//
//        case _NORMAL_OPERATION:
//         { //�N���S����slave
//             if (Conn.TOTAL_ID == 0) {
//                 Conn.ID_FSM = _IDLE;
//
//                 Conn.Polling_ID = 1;
//                 break;
//             }
//
//             if (Conn.MBstatus == TRANS_SUCCESS) {
//
//             } else if (Conn.MBstatus == TRANS_FAILED) {
//
//             }
//
//             sendpack1.slave = Conn.Polling_ID;
//             sendpack1.function = 3;
//             sendpack1.address = SLAVE_ID_REG_ADDR;
//             sendpack1.points = 4;
//             sendpack1.bytes = 8;
//             sendpack1.reg = NULL;
//
//             pushCmdPack(&sendpack1);
//
//             Conn.Polling_ID++;
//             if (Conn.Polling_ID > Conn.TOTAL_ID) {
//                 Conn.Polling_ID = 1;
//             }
//         }
//         break;
//     }
//}
