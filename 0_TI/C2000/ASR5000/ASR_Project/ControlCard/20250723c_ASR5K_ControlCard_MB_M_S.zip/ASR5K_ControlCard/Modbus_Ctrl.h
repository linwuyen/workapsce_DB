/*
 * Modbus_Ctrl.h
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#ifndef MODBUS_CTRL_H_
#define MODBUS_CTRL_H_

#include "ModbusMaster.h"
#include "ModbusSlave.h"
#include "SPWM_Ctrl.h"


extern void Modbus_flow (void);




#endif /* MODBUS_CTRL_H_ */
