/*
 * Modbus_Ctrl.c
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#include "Modbus_Ctrl.h"

#define ROM_BUFFER_SIZE 16
#define SLAVE_REG_ADDR 1000
#define PAR_ENA          0
#define PAR_DIS          1
#define RE               0  //485 READ Mode
#define DE               1  //485 WIRTE Mode

typedef enum
{
    _IDLE,
    _HARDWARE_PREPARE,
    _BROADCAST_PREPARE,
    _SEND_WRITE_BROADCAST,
    _PREPARE_READ_PACKAGE, // add�G wait slave Config timeout
    _SEND_READ_PACKING,
    _PROCESS_READ_RESULT,
    _NORMAL_OPERATION
} M_FSM;

typedef enum
{
    _sIDLE,
    _CHECK_ID,
    _WAIT_RECEIVE

} S_FSM;


typedef enum
{
    MODE_MASTER,
    MODE_SLAVE
} Modbus_Mode;

typedef enum
{
    TRANS_SUCCESS,
    TRANS_FAILED,
    TRANS_BUSY
} Modbus_Status;

typedef struct
{
    Modbus_Mode MODE;
    Modbus_Status MB_STATUS;
    M_FSM mID_FSM;
    S_FSM sID_FSM;

    uint16_t AM3352;
    uint16_t Done;

    uint16_t m_working;
    uint16_t s_working;

    uint16_t NEXT_ID;
    uint16_t TOTAL_ID;
    uint16_t Polling_ID;

    Uint16 LinkEEPROM[ROM_BUFFER_SIZE];
    CMDPACK confirmID;
    CMDPACK ReadPack;
    CMDPACK WritePack;
    uint16_t GBslaveid;
} stConnect;

stConnect Conn = { .MODE = MODE_SLAVE,
                   .mID_FSM = _IDLE,
                   .MB_STATUS = TRANS_BUSY,
                   .AM3352 = 0,
                   .NEXT_ID = 1,
                   .TOTAL_ID = 0,
                   .Polling_ID = 1,
                   .GBslaveid   =0
 };


void Modbus_Switch(void)
{
    //  AM3352
    if (Conn.AM3352 == 1)
    {
        Conn.MODE = MODE_MASTER;
        exeModbusMaster((SCI_MODBUSm*) &mbcomm_m);
        Conn.mID_FSM = _HARDWARE_PREPARE;
    }
    else
    {
        Conn.MODE = MODE_SLAVE;
        exeModbusSlave((SCI_MODBUSs*) &mbcomm_s);
        Conn.sID_FSM = _sIDLE;
    }
}

void Modbus_Contol(void)
{
    if (Conn.MODE == MODE_MASTER)
    {

        switch (Conn.mID_FSM)
        {

        case _IDLE:
            break;

        case _HARDWARE_PREPARE:
//        PAR_ENA;
            GPIO_writePin(PAR, PAR_ENA);
//     49 SPI_MODE to M
            sSPIA.NewFSM = _Mode_Master;
//     485 transfer
            GPIO_writePin(TXC_RXC, DE);
            Conn.m_working = 1;
            // ���դ�������^_PREPARE_WRITE_PACKAGE
            Conn.mID_FSM = _IDLE;
            break;

        case _BROADCAST_PREPARE:
            Conn.confirmID.slave = 0x00;
            Conn.confirmID.function = 0x06;
            Conn.confirmID.address = 1000;
            Conn.confirmID.points = 0x01;
            Conn.confirmID.reg = (Uint16*) &regMbusData.u16MbusData[6];
            Conn.mID_FSM = _SEND_WRITE_BROADCAST;
            break;

        case _SEND_WRITE_BROADCAST:

            if (Conn.Done == 1)
            {
                pushCmdPack(&Conn.confirmID);
                Conn.Done = 0;
            }
            break;

        case _PREPARE_READ_PACKAGE:
            Conn.confirmID.slave = 0x00;  //NEXT_ID++;
            Conn.confirmID.function = 0x03;
            Conn.confirmID.address = 1000;
            Conn.confirmID.points = 0x01;
            Conn.confirmID.reg = (Uint16*) &regMbusData.u16MbusData[6];
            Conn.mID_FSM = _PROCESS_READ_RESULT;
            break;

        case _PROCESS_READ_RESULT:

            if (Conn.Done == 1)
            {
                pushCmdPack(&Conn.confirmID);
                Conn.Done = 0;
            }
            break;

        case _NORMAL_OPERATION:
            break;

        default:
            break;
        }
    }
    else
    {

        switch (Conn.sID_FSM)
        {
        case _sIDLE:
            break;

        case _CHECK_ID:
             if(0 != regMbusData.u16MbusData[6])
             {
                 mbcomm_s.slaveid = regMbusData.u16MbusData[6];
             }
            break;

        default:
            break;
        }

    }

}
void Modbus_flow (void)
{
       Modbus_Switch();
       Modbus_Contol();
}

// IO66 485

//mbus->evstep _POP_COMMAND_OUTm = exeModbusMaster IDLE
//mbus->state  MBUS_SUCCESSm TRANS_SUCCESS�C

//ModbusmStatus getStatus(SCI_MODBUSm *mbus) {
//    if (mbus->evstep == _POP_COMMAND_OUTm && mbus->pData == NULL) {
//        if (mbus->state == MBUS_SUCCESSm) { return TRANS_SUCCESS; }
//        else { return TRANS_FAILED; }
//    }
//    return TRANS_BUSY;
//}

//void Modbus_Control(void) {
//
//    if (Conn.STATE != MODE_MASTER) {
//        if (Conn.ID_FSM != _IDLE) {
//            Conn.ID_FSM = _IDLE;
//        }
//        return;
//    }
//
//    Conn.MBstatus = getStatus(&mbcomm_m);
//    if (Conn.MBstatus == TRANS_BUSY && Conn.ID_FSM != _PROCESS_READ_RESULT) {
//        return;
//    }
//
//    switch(Conn.ID_FSM) {
//
//        case _IDLE:
//            Conn.NEXT_ID = 1;
//            Conn.TOTAL_ID = 0;
//            Conn.ID_FSM = _SEND_BROADCAST;
//            break;
//
//        case _SEND_BROADCAST:
//// �g�J�ʥ]
//            Conn.Tx_buffer[0] = Conn.NEXT_ID;
//            Conn.Tx_buffer[1] = 1;
//
//            sendpack1.slave = 0;
//            sendpack1.function = 16;
//            sendpack1.address = SLAVE_ID_REG_ADDR;
//            sendpack1.points = 2;
//            sendpack1.bytes = 4;
//            sendpack1.reg = Conn.Tx_buffer;
//
//            pushCmdPack(&sendpack1);
//
//            Conn.ID_FSM = _SEND_CONFIRMATION;
////            startAppTimer(50); // �p�ɾ�
//            break;
//
////�s�����O�M�U�@�ӽT�{���O�����гy�@�Ӧܤ֤@�� main �j�骺�L�p����
////        case _WAIT_SLAVE_CONFIG:
////            //2�G���ݭp�ɾ�
//////            if (isAppTimerExpired()) {
////            Conn.stFSM = _SEND_CONFIRMATION;
//////            }
////            break;
//
//        case _SEND_CONFIRMATION:
//// load �ʥ]
//            sendpack1.slave = Conn.NEXT_ID;
//            sendpack1.function = 3;
//            sendpack1.address = SLAVE_ID_REG_ADDR;
//            sendpack1.points = 1;
//            sendpack1.bytes = 2;
//            sendpack1.reg = NULL;
//
//            pushCmdPack(&sendpack1);
//
//
//            Conn.ID_FSM = _PROCESS_READ_RESULT;
//            break;
//
//        case _PROCESS_READ_RESULT:
//            {
//                if (Conn.MBstatus == TRANS_SUCCESS) {
//
//                    Conn.TOTAL_ID++;
//                    Conn.NEXT_ID++;
//
//                    Conn.ID_FSM = _SEND_BROADCAST;
//
//                } else if (Conn.MBstatus == TRANS_FAILED) {
//
//                    if (Conn.TOTAL_ID > 0) {
//
//                        Conn.ID_FSM = _NORMAL_OPERATION;
//                        Conn.Polling_ID = 1;
//                    } else {
//
//                        Conn.ID_FSM = _IDLE;
//                    }
//                }
//            }
//            break;
//
//
//        case _NORMAL_OPERATION:
//         { //�N���S����slave
//             if (Conn.TOTAL_ID == 0) {
//                 Conn.ID_FSM = _IDLE;
//
//                 Conn.Polling_ID = 1;
//                 break;
//             }
//
//             if (Conn.MBstatus == TRANS_SUCCESS) {
//
//             } else if (Conn.MBstatus == TRANS_FAILED) {
//
//             }
//
//             sendpack1.slave = Conn.Polling_ID;
//             sendpack1.function = 3;
//             sendpack1.address = SLAVE_ID_REG_ADDR;
//             sendpack1.points = 4;
//             sendpack1.bytes = 8;
//             sendpack1.reg = NULL;
//
//             pushCmdPack(&sendpack1);
//
//             Conn.Polling_ID++;
//             if (Conn.Polling_ID > Conn.TOTAL_ID) {
//                 Conn.Polling_ID = 1;
//             }
//         }
//         break;
//     }
//}
