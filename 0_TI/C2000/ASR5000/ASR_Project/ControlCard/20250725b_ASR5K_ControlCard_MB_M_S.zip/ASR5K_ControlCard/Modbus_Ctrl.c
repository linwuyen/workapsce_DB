/*
 * Modbus_Ctrl.c
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#include "Modbus_Ctrl.h"

ModbusController Conn = {

                  .NEXT_ID = 1,
                  .TOTAL_ID = 0,
                  .SEND = 0
};

void getStatus()
{
//mbus->evstep _POP_COMMAND_OUTm = exeModbusMaster IDLE
//mbus->state  MBUS_SUCCESSm TRANS_SUCCESS�C
//ModbusmStatus getStatus(SCI_MODBUSm *mbus) {
//    if (mbus->evstep == _POP_COMMAND_OUTm && mbus->pData == NULL) {
//        if (mbus->state == MBUS_SUCCESSm) { return TRANS_SUCCESS; }
//        else { return TRANS_FAILED; }
//    }
//    return TRANS_BUSY;
//}
}
//------------------------------------------------------------------

void MasterState_Idle(ModbusController *p)
{
    p->FSM.M = M_FSM_HW_PREPARE;
}

void MasterState_HW_PREPARE(ModbusController *p)
{
//        PAR_ENA;
    GPIO_writePin(PAR, PAR_ENA);

//     49 SPI_MODE switch M
    sSPIA.NewFSM = _Mode_Master;

//    485
    GPIO_writePin(TXC_RXC, DE);

    p->FSM.M = M_FSM_BroadcastPACK;
}

void MasterState_BroadcastPACK(ModbusController *p)
{

    p->WritePack.slave    = 0x00;
    p->WritePack.function = 0x06;
    p->WritePack.address  = 1000;
    p->WritePack.points    = 0x01;
    // �sID
    regMbusData.u16MbusData[6] = p->NEXT_ID;
    p->WritePack.reg = (Uint16*) &regMbusData.u16MbusData[6];

   p->FSM.M =  M_FSM_SendWriteBroadcast;
}

void MasterState_SendWriteBroadcast(ModbusController *p)
{
        pushCmdPack(&p->WritePack);
        p->FSM.M =   M_FSM_PrepareReadPackage;
}

void MasterState_PrepareReadPackage(ModbusController *p)
{

    p->ReadPack.slave = p->NEXT_ID;
    p->ReadPack.function = 0x03;
    p->ReadPack.address = 1000;
    p->ReadPack.points = 0x01;
    p->ReadPack.reg = (Uint16*)&regMbusData.u16MbusData[6];
    p->FSM.M =   M_FSM_PROCESS_RESPONSE;

}


void MasterState_PROCESS_RESPONSE(ModbusController *p)
{
        pushCmdPack(&p->ReadPack);

        if(p->NEXT_ID == regMbusData.u16MbusData[6]){
            p->NEXT_ID++;
            p->Polling_ID = p->NEXT_ID ;
            p->FSM.M = M_FSM_DISCOVERY_DONE;
    }
        else{
            p->FSM.M = p->FSM.M = M_FSM_BroadcastPACK;
        }
}

void MasterState_DISCOVERY_DONE(ModbusController *p)
{





//    p->FSM.M = M_FSM_NORMAL_POLLING;
}

void MasterState_NORMAL_POLLING(ModbusController *p)
{

}

//-----------------------------------------

void SlaveState_Idle(ModbusController *p)
{

    GPIO_writePin(TXC_RXC, RE);
    // ��ID�s�L�F
      if( mbcomm_s.slaveid  == 0){
          p->FSM.S = S_FSM_ID_ASSIGNED;
        }
}

void SlaveState_CheckBroadcastID(ModbusController *p)
{
        if(0 != regMbusData.u16MbusData[6])
        {
            mbcomm_s.slaveid = regMbusData.u16MbusData[6];
        }
        p->FSM.S =  p->FSM.S = S_FSM_NORMAL_OPERATION;;
}

void SlaveState_WaitReceive(ModbusController *p)
{

    if(mbcomm_s.slaveid != 0){
        GPIO_writePin(PAR, PAR_ENA);
    }
    return;
}

//----------------------------------------
void test_Idle(ModbusController *p)
{

}

void read_pack(ModbusController *p)
{
    if (p->SEND == 1)
    {
        p->ReadPack.slave =     0x03;
        p->ReadPack.function =  0x03;
        p->ReadPack.address =   1000;
        p->ReadPack.points =    0x03;
        p->ReadPack.reg = (Uint16*) &regMbusData.u16MbusData[6];
        pushCmdPack(&(p->ReadPack));
        p->SEND  = 0;
    }
}

void write_pack(ModbusController *p)
{
    if (p->SEND == 1)
    {
        p->WritePack.slave =     0x03;
        p->WritePack.function =  0x06;
        p->WritePack.address =   1000;
        p->WritePack.points =    0x01;
       p->WritePack.reg = (Uint16*) &regMbusData.u16MbusData[6];
        pushCmdPack(&(p->WritePack));
        p->SEND  = 0;
    }
}

void writeN_pack(ModbusController *p)
{
    if (p->SEND == 1)
    {
        p->TestPack.slave =     0x03;
        p->TestPack.function =  0x10;
        p->TestPack.address =   1000;
        p->TestPack.points =    0x02;
        p->TestPack.bytes = p->TestPack.points * 2 ;
        p->TestPack.reg = (Uint16*) &regMbusData.u16MbusData[6];
        pushCmdPack(&(p->TestPack));
        p->SEND  = 0;
    }
}
void (*Mb_Contol[MODE_COUNT][MAX_FSM_STATES])(ModbusController *p) =
{

    [MODE_MASTER] =
    {
        MasterState_Idle,              // 0x00
        MasterState_HW_PREPARE,
        MasterState_BroadcastPACK,
        MasterState_SendWriteBroadcast,
        MasterState_PrepareReadPackage,
        MasterState_PROCESS_RESPONSE,
        MasterState_DISCOVERY_DONE,
        MasterState_NORMAL_POLLING
    },

    [MODE_SLAVE] =
    {
        SlaveState_Idle,               // 0x00
        SlaveState_CheckBroadcastID,
        SlaveState_WaitReceive

    },

    [MODE_Master_TEST] =
    {
            test_Idle,                // 0x00
            read_pack,
            write_pack,
            writeN_pack

    }
};

void Run_MB()
{

    if (Conn.AM3352 == 0)
    {
        Conn.MB_MODE = MODE_SLAVE;
        exeModbusSlave((SCI_MODBUSs*) &mbcomm_s);
        Mb_Contol[Conn.MB_MODE][Conn.FSM.S](&Conn);
    }
    else if(Conn.AM3352 == 1)
    {
        Conn.MB_MODE = MODE_MASTER;
        exeModbusMaster((SCI_MODBUSm*) &mbcomm_m);
        Mb_Contol[Conn.MB_MODE][Conn.FSM.M](&Conn);
    }
    else
    {
        Conn.MB_MODE = MODE_Master_TEST;
        exeModbusMaster((SCI_MODBUSm*) &mbcomm_m);
        Mb_Contol[Conn.MB_MODE][Conn.FSM.T](&Conn);
    }
}

