/*
 * Modbus_Ctrl.h
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#ifndef MODBUS_CTRL_H_
#define MODBUS_CTRL_H_

#include "ModbusMaster.h"
#include "ModbusSlave.h"
#include "SPWM_Ctrl.h"

#define ROM_BUFFER_SIZE 16
#define SLAVE_REG_ADDR 1000

#define PAR_ENA          0
#define PAR_DIS          1

#define RE               0  //485 READ Mode
#define DE               1  //485 WIRTE Mode

#define M_STATE_COUNT 8
#define S_STATE_COUNT 4
#define T_STATE_COUNT 4

#if M_STATE_COUNT > S_STATE_COUNT
    #define MAX_FSM_STATES M_STATE_COUNT
#else
    #define MAX_FSM_STATES S_STATE_COUNT
#endif


typedef enum
{
    MODE_MASTER = 0,
    MODE_SLAVE,
    MODE_Master_TEST,
    MODE_COUNT
} Modbus_Mode;


typedef enum
{
    M_FSM_IDLE  = 0,
    M_FSM_HW_PREPARE,
    M_FSM_BroadcastPACK,
    M_FSM_SendWriteBroadcast,
    M_FSM_PrepareReadPackage,
    M_FSM_PROCESS_RESPONSE,
    M_FSM_DISCOVERY_DONE,
    M_FSM_NORMAL_POLLING
} Master_FSM_State;


typedef enum
{
    S_FSM_IDLE  = 0,
    S_FSM_ID_ASSIGNED,
    S_FSM_NORMAL_OPERATION
} Slave_FSM_State;


typedef enum
{
    T_FSM_IDLE  = 0,
    T_FSM_read_pack,
    T_FSM_write_pack,
    T_FSM_writeN_pack,
} Test_FSM_State;

typedef struct
{
    Modbus_Mode MB_MODE;

    union {
        Master_FSM_State M;
        Slave_FSM_State  S;
        Test_FSM_State   T;
    }FSM;

    CMDPACK ReadPack;
    CMDPACK WritePack;
    CMDPACK TestPack;

    uint16_t    AM3352;
    uint16_t      SEND;

    uint16_t NEXT_ID;
    uint16_t TOTAL_ID;
    uint16_t Polling_ID;

    Uint16 LinkEEPROM[ROM_BUFFER_SIZE];




} ModbusController;




extern void Run_MB (void);

#endif /* MODBUS_CTRL_H_ */
