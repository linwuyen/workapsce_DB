/*
 * Modbus_Ctrl.c
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#include "Modbus_Ctrl.h"
#include "timetask.h"

ModbusController Conn = {
    .MODE = MODE_SLAVE,

    .NEXT_ID = 1,
    .TOTAL_ID = 0,
    .new_id_to_assign =1
};

static void FSM_StartTimer(void)
{
    Conn.fsm_timer_start = U32_UPCNTS;
}

static uint16_t FSM_IsTimerElapsed(uint32_t delay_ticks)
{
    uint32_t elapsed_ticks = U32_UPCNTS - Conn.fsm_timer_start;

    return (elapsed_ticks >= delay_ticks);
}

ModbusStatus GetModbusMasterStatus(void) {

    if (mbcomm_m.pData != NULL) return MB_STATUS_BUSY;

    if (mbcomm_m.state == MBUS_SUCCESSm) return MB_STATUS_SUCCESS;
        return MB_STATUS_FAIL;

}

void Slave_judge(){

    if (mbcomm_s.slaveid == 0 && regMbusData.u16SLAveid != 0) //
    {

         mbcomm_s.slaveid = regMbusData.u16SLAveid; //

          GPIO_writePin(57, 1);
    }
    }


void AutoAddress_FSM(ModbusController *p)
{
    CMDPACK cmd;


    switch(p->STATE)
    {
        case ADDR_STATE_IDLE:

            // if (start_addressing_flag) {
            //     p->addr_state = ADDR_STATE_START;}
            break;

        case ADDR_STATE_START:
            p->new_id_to_assign = 1;
            p->total_discovered = 0;
            p->STATE = ADDR_STATE_BROADCAST_WRITE;
            break;


        case ADDR_STATE_BROADCAST_WRITE:
            cmd = (CMDPACK){
                .slave    = 0x00,
                .function = MB_PRESET_SINGLE_REGISTERm,
                .address  = SLAVE_REG_ADDR,
                .points   = 1,
                .reg = &p->new_id_to_assign
            };

            pushCmdPack(&cmd);
            FSM_StartTimer();
            p->STATE = ADDR_STATE_WAIT_FOR_PNA;

            break;

        case ADDR_STATE_WAIT_FOR_PNA:
//

            if(MBUS_SUCCESSm == mbcomm_m.state && _POP_COMMAND_OUTm ==mbcomm_m. evstep){
                p->STATE = ADDR_STATE_SEND_VERIFY_READ;
            }
//            if(FSM_IsTimerElapsed(T_1S)){
//                 p->STATE = ADDR_STATE_FINISH;
//             }

            break;

        case ADDR_STATE_SEND_VERIFY_READ:
//            mbcomm_m.state = MBUS_WAITm;

            cmd = (CMDPACK){
                .slave    = p->new_id_to_assign,
                .function = 0x03,
                .address  = SLAVE_REG_ADDR,
                .points   = 1,
                .reg = p->response_buffer
            };

            pushCmdPack(&cmd);
            FSM_StartTimer();
            p->STATE = ADDR_STATE_WAIT_FOR_RESPONSE;
            break;

        case ADDR_STATE_WAIT_FOR_RESPONSE:
        {
            ModbusStatus Mstatus = GetModbusMasterStatus();

               if (Mstatus == MB_STATUS_SUCCESS) {

                   p->STATE = ADDR_STATE_SUCCESS;
               }
               else if (Mstatus == MB_STATUS_BUSY) {

                   if (FSM_IsTimerElapsed(T_500MS))
                   {
                       p->STATE = ADDR_STATE_FINISH;
                   }
                   }
                   else {
                   p->STATE = ADDR_STATE_FINISH;
                   }

        }
            break;

        case ADDR_STATE_SUCCESS:
            p->total_discovered++;
            p->new_id_to_assign++;

            if (p->new_id_to_assign > MAX_POSSIBLE_SLAVES) {
//                p->STATE = ADDR_STATE_ERROR;
                p->STATE = ADDR_STATE_FINISH;
            } else {
                p->STATE = p->STATE = ADDR_STATE_BROADCAST_WRITE;
            }
            break;


        case ADDR_STATE_FINISH:


            break;


        case TEST:

            p->Package.slave =     p->TestPack.slave;
            p->Package.function =  p->TestPack.function;
            p->Package.address =   p->TestPack.address;
            p->Package.points =    p->TestPack.points ;
            p->Package.reg = (Uint16*) &regMbusData.u16MbusData[6];
            pushCmdPack(&(p->Package));
            p->STATE = ADDR_STATE_IDLE;
        break;

        case ADDR_STATE_ERROR:

            break;
    }
}


void Run_Modbus_FSM()
{
        ModbusController *p = &Conn;

        if (p->AM3352 == 0)
        {
            p->MODE = MODE_SLAVE;
            exeModbusSlave((SCI_MODBUSs*) &mbcomm_s);
            Slave_judge();
        }
        else
        {
            p->MODE = MODE_MASTER;
            exeModbusMaster((SCI_MODBUSm*) &mbcomm_m);
            AutoAddress_FSM(&Conn);
        }
}
