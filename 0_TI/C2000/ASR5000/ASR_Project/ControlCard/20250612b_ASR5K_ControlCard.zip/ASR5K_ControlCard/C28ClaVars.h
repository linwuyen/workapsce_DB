/*
 * C28ClaVars.h
 *
 *  Created on: Jun 24, 2024
 *      Author: User
 */

#ifndef C28CLAVARS_H_
#define C28CLAVARS_H_


typedef struct {
    uint32_t u32Heartbeats;
    uint16_t u16CV_AD;
    uint16_t u16TempC_AD;

}ST_GSVAR;


#endif /* C28CLAVARS_H_ */
