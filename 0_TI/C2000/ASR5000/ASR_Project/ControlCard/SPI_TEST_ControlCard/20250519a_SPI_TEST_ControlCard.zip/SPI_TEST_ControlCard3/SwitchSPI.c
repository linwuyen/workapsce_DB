/*
 * SwitchSPI.c
 *
 *  Created on: May 16, 2025
 *      Author: roger_lin
 */


#include "common.h"

uint16_t u16flag = 0;
uint16_t SPIA_state;
uint16_t SPIB_state;


SpiConfig SPI_cfg = {
                  .Master_Base = SPIA_BASE,
                  .Slave_Base  = SPIB_BASE,
                  .FSM_SPI =     _Init
};


void Switch_SPI (void){

    switch(u16flag){
        case 1:
            SPI_cfg.Master_Base = SPIA_BASE;
            SPI_cfg.Slave_Base  = SPIB_BASE;

            SPI_Master_init(&SPI_cfg);
            SPI_Slave_init(&SPI_cfg);

            SPI_GPIO_INIT();
            GPIO_togglePin(myBoardLED1_GPIO);

            u16flag = 0;
            break;
        case 2:
            SPI_cfg.Master_Base = SPIB_BASE;
            SPI_cfg.Slave_Base  = SPIA_BASE;


            SPI_Master_init(&SPI_cfg);
            SPI_Slave_init (&SPI_cfg);

            SPI_GPIO_INIT();
            GPIO_togglePin(myBoardLED0_GPIO);
            u16flag = 0;
            break;

        case 3:

            SPIA_state = SPI_isBusy(SPI_cfg.Master_Base);
            SPIB_state = SPI_isBusy(SPI_cfg.Slave_Base);

            u16flag = 0;
            break;

        case 4:
            SPI_reset(SPI_cfg.Master_Base);
            SPI_reset(SPI_cfg.Slave_Base);
            u16flag = 0;
            break;

        default:
            break;
    }
}


