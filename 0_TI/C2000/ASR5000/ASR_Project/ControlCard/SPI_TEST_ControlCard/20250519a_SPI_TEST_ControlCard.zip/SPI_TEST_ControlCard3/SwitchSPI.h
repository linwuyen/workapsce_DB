/*
 * SwitchSPI.h
 *
 *  Created on: May 15, 2025
 *      Author: roger_lin
 */

#ifndef SWITCHSPI_H_
#define SWITCHSPI_H_

#include "device.h"

typedef enum{
    _Init    = (0x00000001<<0),
}FSM_SPI_CONFIG;

typedef struct {
    uint32_t           Master_Base;
    uint32_t            Slave_Base;
    FSM_SPI_CONFIG         FSM_SPI;
//    uint32_t  BitRate;
//    uint16_t DataWidth;
//    SPI_PTEPolarity PTEPolarity;
//    SPI_TransferProtocol TransferProtocol;
//    SPI_EmulationMode EmulationMode;
} SpiConfig;

typedef SpiConfig * cfg;
extern SpiConfig SPI_cfg;

#define SPI_MASTER_BASE      SPIA_BASE
#define SPI_SLAVE_BASE       SPIB_BASE
#define SPI_BITRATE   1000000
#define SPIB_MASTER_DATAWIDTH 16

// SPIB -> SPIB_MASTER Pinmux
//
//
// SPIB_PICO - GPIO Settings
////
#define GPIO_PIN_SPIB_PICO 24
#define SPIB_MASTER_SPIPICO_GPIO 24
#define SPIB_MASTER_SPIPICO_PIN_CONFIG GPIO_24_SPIB_SIMO
//
// SPIB_POCI - GPIO Settings
//
#define GPIO_PIN_SPIB_POCI 25
#define SPIB_MASTER_SPIPOCI_GPIO 25
#define SPIB_MASTER_SPIPOCI_PIN_CONFIG GPIO_25_SPIB_SOMI
//
// SPIB_CLK - GPIO Settings
//
#define GPIO_PIN_SPIB_CLK 26
#define SPIB_MASTER_SPICLK_GPIO 26
#define SPIB_MASTER_SPICLK_PIN_CONFIG GPIO_26_SPIB_CLK
//
// SPIB_PTE - GPIO Settings
//
#define GPIO_PIN_SPIB_PTE 27
#define SPIB_MASTER_SPIPTE_GPIO 27
#define SPIB_MASTER_SPIPTE_PIN_CONFIG GPIO_27_SPIB_STE

//
// SPIA -> SPIA_SLAVE Pinmux
//
//
// SPIA_PICO - GPIO Settings
//
#define GPIO_PIN_SPIA_PICO 16
#define SPIA_SLAVE_SPIPICO_GPIO 16
#define SPIA_SLAVE_SPIPICO_PIN_CONFIG GPIO_16_SPIA_SIMO
//
// SPIA_POCI - GPIO Settings
//
#define GPIO_PIN_SPIA_POCI 17
#define SPIA_SLAVE_SPIPOCI_GPIO 17
#define SPIA_SLAVE_SPIPOCI_PIN_CONFIG GPIO_17_SPIA_SOMI
//
// SPIA_CLK - GPIO Settings
//
#define GPIO_PIN_SPIA_CLK 9
#define SPIA_SLAVE_SPICLK_GPIO 9
#define SPIA_SLAVE_SPICLK_PIN_CONFIG GPIO_9_SPIA_CLK
//
// SPIA_PTE - GPIO Settings
//
#define GPIO_PIN_SPIA_PTE 11
#define SPIA_SLAVE_SPIPTE_GPIO 11
#define SPIA_SLAVE_SPIPTE_PIN_CONFIG GPIO_11_SPIA_STE





static inline void SPI_Master_init(SpiConfig *cfg){
    SPI_disableModule(cfg->Master_Base);
    SPI_setConfig(cfg->Master_Base, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
                  SPI_MODE_CONTROLLER, SPI_BITRATE, SPIB_MASTER_DATAWIDTH);
    SPI_setPTESignalPolarity(cfg->Master_Base, SPI_PTE_ACTIVE_LOW);
    SPI_enableFIFO(cfg->Master_Base);
    SPI_disableLoopback(cfg->Master_Base);
    SPI_setEmulationMode(cfg->Master_Base, SPI_EMULATION_FREE_RUN);
    SPI_enableModule(cfg->Master_Base);
}

static inline void SPI_Slave_init(SpiConfig *cfg){
    SPI_disableModule(cfg->Slave_Base);
    SPI_setConfig(cfg->Slave_Base, DEVICE_LSPCLK_FREQ,SPI_PROT_POL0PHA0,
                  SPI_MODE_PERIPHERAL,SPI_BITRATE,SPIB_MASTER_DATAWIDTH);
    SPI_setPTESignalPolarity(cfg->Slave_Base,SPI_PTE_ACTIVE_LOW);
    SPI_enableFIFO(cfg->Slave_Base);
    SPI_disableLoopback(cfg->Slave_Base);
    SPI_setEmulationMode(cfg->Slave_Base,SPI_EMULATION_FREE_RUN);
    SPI_enableModule(cfg->Slave_Base);
}


static inline void SPI_GPIO_INIT (){

    GPIO_setPinConfig(SPIB_MASTER_SPIPICO_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPIPICO_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPIPICO_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIB_MASTER_SPIPOCI_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPIPOCI_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPIPOCI_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIB_MASTER_SPICLK_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPICLK_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPICLK_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIB_MASTER_SPIPTE_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPIPTE_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPIPTE_GPIO, GPIO_QUAL_ASYNC);

    //
    // SPIA -> SPIA_SLAVE Pinmux
    //
    GPIO_setPinConfig(SPIA_SLAVE_SPIPICO_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPIPICO_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPIPICO_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIA_SLAVE_SPIPOCI_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPIPOCI_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPIPOCI_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIA_SLAVE_SPICLK_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPICLK_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPICLK_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIA_SLAVE_SPIPTE_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPIPTE_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPIPTE_GPIO, GPIO_QUAL_ASYNC);

}

extern void Switch_SPI (void);


#endif /* SWITCHSPI_H_ */
