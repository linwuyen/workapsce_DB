
//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"

#include "common.h"

uint16_t flag;

SpiConfig SPI_cfg = {
                     .SLAVE    = SPIA_BASE,
                     .Master    = SPIB_BASE,
                     .ModeA = SPI_MODE_PERIPHERAL,
                     .ModeB = SPI_MODE_CONTROLLER,
                     .BitRate     = 1000000,
                     .DataWidth   = 16,
                     .PTEPolarity = SPI_PTE_ACTIVE_LOW,
                     .TransferProtocol =  SPI_PROT_POL0PHA0,
                     .EmulationMode = SPI_EMULATION_FREE_RUN
};

// Main
//
void main(void)
{

    //
    // Initialize device clock and peripherals
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    Interrupt_initVectorTable();

    //
    // PinMux and Peripheral Initialization
    Board_init();

    SPIB_MASTER_init(&SPI_cfg);
    SPIA_SLAVE_init(&SPI_cfg);

    SPI_GPIO_INIT();
    //
    // C2000Ware Library initialization
    C2000Ware_libraries_init();

    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    EINT;
    ERTM;

    //
    // Loop Forever
    for(;;)
    {

     pollTimeTask();

    }

}
//
// End of File
//

