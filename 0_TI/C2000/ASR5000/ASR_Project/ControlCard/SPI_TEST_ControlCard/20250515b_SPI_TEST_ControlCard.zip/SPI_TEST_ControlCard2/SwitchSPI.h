/*
 * SwitchSPI.h
 *
 *  Created on: May 15, 2025
 *      Author: roger_lin
 */

#ifndef SWITCHSPI_H_
#define SWITCHSPI_H_

#include "device.h"

typedef struct {
    uint32_t Master;
    uint32_t SLAVE;
    SPI_Mode    ModeA;
    SPI_Mode    ModeB;
    uint32_t  BitRate;
    uint16_t DataWidth;
    SPI_PTEPolarity PTEPolarity;
    SPI_TransferProtocol TransferProtocol;
    SPI_EmulationMode EmulationMode;
} SpiConfig;

typedef SpiConfig * cfg;



// SPIB -> SPIB_MASTER Pinmux
//
//
// SPIB_PICO - GPIO Settings
////
#define GPIO_PIN_SPIB_PICO 24
#define SPIB_MASTER_SPIPICO_GPIO 24
#define SPIB_MASTER_SPIPICO_PIN_CONFIG GPIO_24_SPIB_SIMO
//
// SPIB_POCI - GPIO Settings
//
#define GPIO_PIN_SPIB_POCI 25
#define SPIB_MASTER_SPIPOCI_GPIO 25
#define SPIB_MASTER_SPIPOCI_PIN_CONFIG GPIO_25_SPIB_SOMI
//
// SPIB_CLK - GPIO Settings
//
#define GPIO_PIN_SPIB_CLK 26
#define SPIB_MASTER_SPICLK_GPIO 26
#define SPIB_MASTER_SPICLK_PIN_CONFIG GPIO_26_SPIB_CLK
//
// SPIB_PTE - GPIO Settings
//
#define GPIO_PIN_SPIB_PTE 27
#define SPIB_MASTER_SPIPTE_GPIO 27
#define SPIB_MASTER_SPIPTE_PIN_CONFIG GPIO_27_SPIB_STE

//
// SPIA -> SPIA_SLAVE Pinmux
//
//
// SPIA_PICO - GPIO Settings
//
#define GPIO_PIN_SPIA_PICO 16
#define SPIA_SLAVE_SPIPICO_GPIO 16
#define SPIA_SLAVE_SPIPICO_PIN_CONFIG GPIO_16_SPIA_SIMO
//
// SPIA_POCI - GPIO Settings
//
#define GPIO_PIN_SPIA_POCI 17
#define SPIA_SLAVE_SPIPOCI_GPIO 17
#define SPIA_SLAVE_SPIPOCI_PIN_CONFIG GPIO_17_SPIA_SOMI
//
// SPIA_CLK - GPIO Settings
//
#define GPIO_PIN_SPIA_CLK 9
#define SPIA_SLAVE_SPICLK_GPIO 9
#define SPIA_SLAVE_SPICLK_PIN_CONFIG GPIO_9_SPIA_CLK
//
// SPIA_PTE - GPIO Settings
//
#define GPIO_PIN_SPIA_PTE 11
#define SPIA_SLAVE_SPIPTE_GPIO 11
#define SPIA_SLAVE_SPIPTE_PIN_CONFIG GPIO_11_SPIA_STE





static inline void SPIB_MASTER_init(SpiConfig *cfg){
    SPI_disableModule(cfg->Master);
    SPI_setConfig(cfg->Master, DEVICE_LSPCLK_FREQ, cfg->TransferProtocol,
                  cfg->ModeB, cfg->BitRate, cfg->DataWidth);
    SPI_setPTESignalPolarity(cfg->Master, cfg->PTEPolarity);
    SPI_enableFIFO(cfg->Master);
    SPI_disableLoopback(cfg->Master);
    SPI_setEmulationMode(cfg->Master,cfg->EmulationMode);
    SPI_enableModule(cfg->Master);
}

static inline void SPIA_SLAVE_init(SpiConfig *cfg){
    SPI_disableModule(cfg->SLAVE);
    SPI_setConfig(cfg->SLAVE, DEVICE_LSPCLK_FREQ,cfg->TransferProtocol,
                  cfg->ModeA,cfg->BitRate,cfg->DataWidth);
    SPI_setPTESignalPolarity(cfg->SLAVE,cfg->PTEPolarity);
    SPI_enableFIFO(cfg->SLAVE);
    SPI_disableLoopback(cfg->SLAVE);
    SPI_setEmulationMode(cfg->SLAVE,cfg->EmulationMode);
    SPI_enableModule(cfg->SLAVE);
}



static inline void SPI_GPIO_INIT (){

    GPIO_setPinConfig(SPIB_MASTER_SPIPICO_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPIPICO_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPIPICO_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIB_MASTER_SPIPOCI_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPIPOCI_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPIPOCI_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIB_MASTER_SPICLK_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPICLK_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPICLK_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIB_MASTER_SPIPTE_PIN_CONFIG);
    GPIO_setPadConfig(SPIB_MASTER_SPIPTE_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIB_MASTER_SPIPTE_GPIO, GPIO_QUAL_ASYNC);

    //
    // SPIA -> SPIA_SLAVE Pinmux
    //
    GPIO_setPinConfig(SPIA_SLAVE_SPIPICO_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPIPICO_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPIPICO_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIA_SLAVE_SPIPOCI_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPIPOCI_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPIPOCI_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIA_SLAVE_SPICLK_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPICLK_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPICLK_GPIO, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(SPIA_SLAVE_SPIPTE_PIN_CONFIG);
    GPIO_setPadConfig(SPIA_SLAVE_SPIPTE_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(SPIA_SLAVE_SPIPTE_GPIO, GPIO_QUAL_ASYNC);

}




#endif /* SWITCHSPI_H_ */
