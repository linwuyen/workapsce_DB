/*
 * Modbus_Ctrl.h
 *
 *  Created on: Jul 22, 2025
 *      Author: roger_lin
 */

#ifndef MODBUS_CTRL_H_
#define MODBUS_CTRL_H_



extern void Modbus_Switch2 (void);
extern void Modbus_Switch (void);

#endif /* MODBUS_CTRL_H_ */
