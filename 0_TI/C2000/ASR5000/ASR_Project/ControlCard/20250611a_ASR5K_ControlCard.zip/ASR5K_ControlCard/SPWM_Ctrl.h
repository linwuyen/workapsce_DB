/*
 * initCLK.h
 *
 *  Created on: May 27, 2024
 *      Author: roger_lin
 */

#ifndef SPWM_CTRL_H_
#define SPWM_CTRL_H_


//==========SPIA========================
#define mySPI0_BASE      SPIA_BASE
#define mySPI0_BITRATE   5000000

// Interrupt Settings for INT_mySPI0_RX
#define INT_mySPI0_RX INT_SPIA_RX
#define INT_mySPI0_RX_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP6
extern __interrupt void INT_mySPI0_RX_ISR(void);

//// Interrupt Settings for INT_mySPI0_TX
//#define INT_mySPI0_TX INT_SPIA_TX
//#define INT_mySPI0_TX_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP6
//extern __interrupt void INT_mySPI0_TX_ISR(void);

//=========================Common_Test  PIN================

#define Card           0
#define ASR            1
#define ControlGPIO    Card

#define Common_PICO               16
#define Common_PICO_GPIO          16
#define Common_PICO_PIN_CONFIG    GPIO_16_SPIA_SIMO
//

#define Common_POCI               17
#define Common_POCI_GPIO          17
#define Common_POCI_PIN_CONFIG    GPIO_17_SPIA_SOMI


// SPIA_CLK - GPIO Settings
//
#define Common_CLK                9
#define Common_SPICLK_GPIO        9
#define Common_SPICLK_PIN_CONFIG  GPIO_9_SPIA_CLK
//
// SPIA_PTE - GPIO Settings

#define Common_PTE                11
#define Common_SPIPTE_GPIO        11
#define Common_SPIPTE_PIN_CONFIG  GPIO_11_SPIA_STE

//=========================SPIA_MASTER PIN===============================
//
#define GPIO_PIN_SPIA_PICO             16
#define mySPI0_SPIPICO_GPIO            16
#define mySPI0_SPIPICO_PIN_CONFIG      GPIO_16_SPIA_SIMO
//
// SPIA_CLK - GPIO Settings
//
#define GPIO_PIN_SPIA_CLK              9
#define mySPI0_SPICLK_GPIO             9
#define mySPI0_SPICLK_PIN_CONFIG       GPIO_9_SPIA_CLK
//
// SPIA_PTE - GPIO Settings

#define GPIO_PIN_SPIA_PTE              5
#define mySPI0_SPIPTE_GPIO             5
#define mySPI0_SPIPTE_PIN_CONFIG       GPIO_5_SPIA_STE


//=========================SPIA_SLAVE PIN===============================

#define GPIO_PIN_SPIA_PICO_S          8
#define mySPI0_SPIPICO_GPIO_S         8
#define mySPI0_SPIPICO_PIN_CONFIG_S   GPIO_8_SPIA_SIMO
//
// SPIA_CLK - GPIO Settings
//
#define GPIO_PIN_SPIA_CLK_S           3
#define mySPI0_SPICLK_GPIO_S          3
#define mySPI0_SPICLK_PIN_CONFIG_S    GPIO_3_SPIA_CLK
//
// SPIA_PTE - GPIO Settings
//
#define GPIO_PIN_SPIA_PTE_S           11
#define mySPI0_SPIPTE_GPIO_S          11
#define mySPI0_SPIPTE_PIN_CONFIG_S    GPIO_11_SPIA_STE

#define BUFFER_SIZE 64

typedef enum{
    _Interrupt_Init        = (0x00000001<<0),
    _Mode_Master           = (0x00000001<<1),
    _Mode_Slave            = (0x00000001<<2),
    _Idle                  = (0x00000001<<3),
    _Reset_Module          = (0x00000001<<4),
    _Test_Function         = (0x00000001<<5),
    _MARK_ERROR_SPI_M_PACK = (0x80000000)
}FSM_SPIA;


typedef union{
    struct{

        uint16_t u16CV_AD:12;
        uint16_t u16check:4;
    }Package;
    uint16_t u16Data;
}SPI_PACK;

typedef struct{
    FSM_SPIA    FSM;
    uint16_t    u16isMaster;
    uint16_t    u16MasterChange;
    SPI_PACK    u16Rxpack;
    SPI_PACK    u16Txpack;
    uint16_t    u16Data_Array[BUFFER_SIZE];
    uint16_t    u16Index;
    uint16_t    u16ChkFailCnt;
    uint16_t    u16check;
}ST_SPIA;

typedef ST_SPIA * HAL_SPIA;

extern void SPIA_Switch(HAL_SPIA P);
//==============================================================

typedef union {
    float32_t f32Data;
    uint32_t u32Data;
    uint16_t u16Data[2];

    struct {
        uint32_t b0_pfc_ovp_n:1;
        uint32_t b1_pfc_uvp_n:1;
        uint32_t b2_pfc_ovp_2_n:1;
        uint32_t b3_pfc_uvp_2_n:1;
        uint32_t b4_pfc_otp_n:1;
        uint32_t b5_dc_ovp_n:1;
        uint32_t b6_ac_fail_5_n:1;
        uint32_t b7_fan_fail_1:1;
        uint32_t b8_fan_fail_2:1;
        uint32_t b9_fan_fail_3:1;
        uint32_t b10_fan_fail_4:1;
        uint32_t b11_15_reserved:5;
        uint32_t b16_off_pwm_n:1;
        uint32_t b17_master:1;
        uint32_t b18_31_reserved:14;
    } i_stat;

    struct {
        uint32_t b0_15_reserved:16;
        uint32_t b16_off_pwm_n:1;
        uint32_t b17_master:1;
        uint32_t b18_31_reserved:14;
    } o_stat;
} REG_PARAM;


// Define a struct containing three register parameters
typedef struct {
    REG_PARAM sDin;
    REG_PARAM sDout;
    REG_PARAM sFanCtrl;
    REG_PARAM sIref_P;
    REG_PARAM sIref_N;
    REG_PARAM sTemp_C;
    REG_PARAM sHeartbeats;
} ST_PARAMS;

// Macro to calculate the offset of a member in the struct
#define INIT_PARAM(name) (uintptr_t)(REG_PARAM*)(&((ST_PARAMS*)(0))->name)/sizeof(REG_PARAM)

// Define enum with calculated offsets
typedef enum {
    _ID_DIN      = INIT_PARAM(sDin),
    _ID_DOUT     = INIT_PARAM(sDout),
    _ID_FAN_CTRL = INIT_PARAM(sFanCtrl),
    _ID_IREF_P   = INIT_PARAM(sIref_P),
    _ID_IREF_N   = INIT_PARAM(sIref_N),
    _ID_TEMP_C   = INIT_PARAM(sTemp_C),
    _END_OF_IDCMD
} ID_CMD;

extern  ST_PARAMS sParams;

static inline uint16_t verifychk (uint16_t data) {
    uint16_t u16check;
    u16check =0;
    return   u16check;
}

static inline uint16_t calcsum(uint16_t data) {

    uint16_t high, low, checksum;

    high = ( data >> 8) & 0x00FF;  // �� 8 bit
    low  =  data & 0x00FF;         // �C 8 bit

    checksum = (high ^ low) & 0x000F;    // �u�O�d 4 bit

    return checksum;


//    //test
//         high = (sSPIA.u16Txpack.Package.u16CV_AD >> 8) & 0xFF;
//         low  = sSPIA.u16Txpack.Package.u16CV_AD & 0xFF;
//         sSPIA.u16Txpack.Package.u16ID = (high ^ low) & 0x0F;
}



//timetask.c- task10msec
extern void Update_IO(void);

extern void init_EPWM(void);

extern void updateFANCTRL5Duty( void);


#endif /* SPWM_CTRL_H_ */
