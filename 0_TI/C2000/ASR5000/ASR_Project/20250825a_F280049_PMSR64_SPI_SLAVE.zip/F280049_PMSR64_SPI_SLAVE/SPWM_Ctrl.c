/*
 * SPWM_Ctrl.c
 *
 *  Created on: May 27, 2024
 *      Author: roger_lin
 */
#include "common.h"


//==================================eCAP================================
// AC_FAIL GPIO 7 To INPUTXBAR1
// CAP INPUTXBAR1

uint32_t frequency;

__interrupt void INT_myECAP0_ISR(void){

static  uint32_t prevTimestamp;
static  uint32_t timestamp;
static  uint32_t timeDifference;

    timestamp = ECAP_getEventTimeStamp(myECAP0_BASE, ECAP_EVENT_1);

    // �p��ɶ����j
    if (prevTimestamp != 0) {
            timeDifference = timestamp - prevTimestamp;

        if (timestamp < prevTimestamp) {
            timeDifference = (0xFFFFFFFFUL - prevTimestamp) + timestamp + 1;
        } else {
            timeDifference = timestamp - prevTimestamp + 1 ;
        }
    // �p���W�v ecapClockFreq = 100000000
        frequency = 100000000 / timeDifference;
    }
    //���e�ɶ������U���ɶ��W
    prevTimestamp = timestamp;

//Range 65-45hz
    if (frequency > 43 && frequency < 65){
        sParams.sDin.i_stat.b6_ac_fail_5_n = GPIO_readPin(ACFAIL5);

    }else{
        sParams.sDin.i_stat.b6_ac_fail_5_n = false;
    }


   // �M�����_�X��
   ECAP_clearInterrupt(myECAP0_BASE, ECAP_ISR_SOURCE_CAPTURE_EVENT_1);
   ECAP_clearGlobalInterrupt(myECAP0_BASE);
   Interrupt_clearACKGroup(INT_myECAP0_INTERRUPT_ACK_GROUP);
}

////===============================IO=======================

typedef struct{
    uint32_t b0_pfc_ovp_n:1;
    uint32_t b1_pfc_uvp_n :1;
    uint32_t b2_pfc_ovp_2_n:1;
    uint32_t b3_pfc_uvp_2_n:1;
    uint32_t b4_pfc_otp_n:1;
    uint32_t b5_dc_ovp_n:1;
    uint32_t b6_ac_fail_5_n:1;

    uint32_t b7_fan_fail_1:1;
    uint32_t b8_fan_fail_2:1;
    uint32_t b9_fan_fail_3:1;
    uint32_t b10_fan_fail_4:1;
}st_Fake_singal;
st_Fake_singal Fake_singal;

ST_GSVAR sGbVars;


void scanFanFail(void)
{
    static uint16_t u16FanIo = 0;
    static uint16_t u16FanShadow = 0;
    static uint16_t u16Fan1Timeout = 0;
    static uint16_t u16Fan2Timeout = 0;
    static uint16_t u16Fan3Timeout = 0;
    static uint16_t u16Fan4Timeout = 0;

//    u16FanIo  = (GPIO_readPin(FANFAIL1)<<0);
//    u16FanIo |= (GPIO_readPin(FANFAIL2)<<1);
//    u16FanIo |= (GPIO_readPin(FANFAIL3)<<2);
//    u16FanIo |= (GPIO_readPin(FANFAIL4)<<3);

    u16FanIo++;
    u16FanIo &= 0x0F;

    if((u16FanShadow^u16FanIo) & (0x0001<<0)) {
        u16Fan1Timeout = 0;
        sParams.sDin.i_stat.b7_fan_fail_1 = 0;
    }
    else if(u16Fan1Timeout<1000){
        u16Fan1Timeout++;
    }
    else {
        sParams.sDin.i_stat.b7_fan_fail_1 = 1;
    }

    if((u16FanShadow^u16FanIo) & (0x0001<<1)) {
        u16Fan2Timeout = 0;
        sParams.sDin.i_stat.b8_fan_fail_2 = 0;
    }
    else if(u16Fan2Timeout<1000){
        u16Fan2Timeout++;
    }
    else {
        sParams.sDin.i_stat.b8_fan_fail_2 = 1;
    }

    if((u16FanShadow^u16FanIo) & (0x0001<<2)) {
        u16Fan3Timeout = 0;
        sParams.sDin.i_stat.b9_fan_fail_3 = 0;
    }
    else if(u16Fan3Timeout<1000){
        u16Fan3Timeout++;
    }
    else {
        sParams.sDin.i_stat.b9_fan_fail_3 = 1;
    }

    if((u16FanShadow^u16FanIo) & (0x0001<<3)) {
        u16Fan4Timeout = 0;
        sParams.sDin.i_stat.b10_fan_fail_4 = 0;
    }
    else if(u16Fan4Timeout<1000){
        u16Fan4Timeout++;
    }
    else {
        sParams.sDin.i_stat.b10_fan_fail_4 = 1;
    }

    u16FanShadow = u16FanIo;
}

void Update_IO(void)
{

#if (SCAN_ERROR_MODE == DISABLE_SCAN_ERROR)
    sParams.sDin.i_stat.b0_pfc_ovp_n   = 1;
    sParams.sDin.i_stat.b1_pfc_uvp_n   = 1;
    sParams.sDin.i_stat.b2_pfc_ovp_2_n = 0;
    sParams.sDin.i_stat.b3_pfc_uvp_2_n = 0;
    sParams.sDin.i_stat.b4_pfc_otp_n   = 1;
    sParams.sDin.i_stat.b5_dc_ovp_n    = 0;
    sParams.sDin.i_stat.b6_ac_fail_5_n = 1;
    sParams.sDin.i_stat.b7_fan_fail_1  = 0;
    sParams.sDin.i_stat.b8_fan_fail_2  = 0;
    sParams.sDin.i_stat.b9_fan_fail_3  = 0;
    sParams.sDin.i_stat.b10_fan_fail_4 = 0;
#elif (SCAN_ERROR_MODE == FEED_FACK_ERROR)
    sParams.sDin.i_stat.b0_pfc_ovp_n   = Fake_singal.b0_pfc_ovp_n;
    sParams.sDin.i_stat.b1_pfc_uvp_n   = Fake_singal.b1_pfc_uvp_n;
    sParams.sDin.i_stat.b2_pfc_ovp_2_n = Fake_singal.b2_pfc_ovp_2_n;
    sParams.sDin.i_stat.b3_pfc_uvp_2_n = Fake_singal.b3_pfc_uvp_2_n;
    sParams.sDin.i_stat.b4_pfc_otp_n   = Fake_singal.b4_pfc_otp_n;
    sParams.sDin.i_stat.b5_dc_ovp_n    = Fake_singal.b5_dc_ovp_n;
    sParams.sDin.i_stat.b6_ac_fail_5_n   = Fake_singal.b6_ac_fail_5_n;
    sParams.sDin.i_stat.b7_fan_fail_1  = Fake_singal.b7_fan_fail_1;
    sParams.sDin.i_stat.b8_fan_fail_2  = Fake_singal.b8_fan_fail_2;
    sParams.sDin.i_stat.b9_fan_fail_3  = Fake_singal.b9_fan_fail_3;
    sParams.sDin.i_stat.b10_fan_fail_4 = Fake_singal.b10_fan_fail_4;
#else
    sParams.sDin.i_stat.b0_pfc_ovp_n    = GPIO_readPin(PFC_OVP);
    sParams.sDin.i_stat.b1_pfc_uvp_n    = GPIO_readPin(PFC_UVP);
    sParams.sDin.i_stat.b2_pfc_ovp_2_n  = GPIO_readPin(PFC_OVP2);
    sParams.sDin.i_stat.b3_pfc_uvp_2_n  = GPIO_readPin(PFC_UVP2);
    sParams.sDin.i_stat.b4_pfc_otp_n    = GPIO_readPin(PFC_OTP);
    sParams.sDin.i_stat.b5_dc_ovp_n     = GPIO_readPin(DCOVP);
   sParams.sDin.i_stat.b6_ac_fail_5_n  = GPIO_readPin(ACFAIL5);


    scanFanFail();
#endif

   sParams.sDin.i_stat.b16_off_pwm_n  = sParams.sDout.o_stat.b16_off_pwm_n;
   sParams.sDin.i_stat.b17_master  = sParams.sDout.o_stat.b17_master;

   GPIO_writePin(OFF_PWMn  ,sParams.sDout.o_stat.b16_off_pwm_n);
   GPIO_writePin(EN_MASTER ,sParams.sDout.o_stat.b17_master);
}


//==============================ADC_LOOKUPTABLE===================================
#define ADC_MAX 4096
#define lookupTableSize  33
uint16 dutyCycle ;

int16_t TableAdc2DutyCnt[lookupTableSize] = {
  409, 409, 409, 409, 839, 1269, 1700, 1700,
  1700, 1700, 1700, 1700, 1700, 1700, 1700, 1700,
  1700, 1700, 1700, 1700, 1700, 1700, 1700, 1700,
  1700, 1700, 1700, 1700, 1700, 1700, 1700, 1700, 1700
};


int16_t getAdc2DutyCnt(uint16_t adcValue) {
    float scale = (float)(lookupTableSize - 1) / ADC_MAX;
    float indexFloat = adcValue * scale;
    int16_t index = (int16_t)indexFloat;
    int16_t nextIndex = (index + 1 < lookupTableSize) ? index + 1 : index;

    int16_t value1 = TableAdc2DutyCnt[index];
    int16_t value2 = TableAdc2DutyCnt[nextIndex];

    float fraction = indexFloat - index;
    int16_t DutyCnt = value1 + (int16_t)((value2 - value1) * fraction);

    return DutyCnt;
}

uint16 cnvAdc2Duty() {

 //MCP3301 TEMP
   dutyCycle = getAdc2DutyCnt(sGbVars.u16TempC_AD);

   return dutyCycle;
}


void myECAP0_init(){
    //
    // Disable ,clear all capture flags and interrupts
    //
    ECAP_disableInterrupt(myECAP0_BASE,
        (ECAP_ISR_SOURCE_CAPTURE_EVENT_1  |
        ECAP_ISR_SOURCE_CAPTURE_EVENT_2  |
        ECAP_ISR_SOURCE_CAPTURE_EVENT_3  |
        ECAP_ISR_SOURCE_CAPTURE_EVENT_4  |
        ECAP_ISR_SOURCE_COUNTER_OVERFLOW |
        ECAP_ISR_SOURCE_COUNTER_PERIOD   |
        ECAP_ISR_SOURCE_COUNTER_COMPARE));
    ECAP_clearInterrupt(myECAP0_BASE,
        (ECAP_ISR_SOURCE_CAPTURE_EVENT_1  |
        ECAP_ISR_SOURCE_CAPTURE_EVENT_2  |
        ECAP_ISR_SOURCE_CAPTURE_EVENT_3  |
        ECAP_ISR_SOURCE_CAPTURE_EVENT_4  |
        ECAP_ISR_SOURCE_COUNTER_OVERFLOW |
        ECAP_ISR_SOURCE_COUNTER_PERIOD   |
        ECAP_ISR_SOURCE_COUNTER_COMPARE));
    //
    // Disables time stamp capture.
    //
    ECAP_disableTimeStampCapture(myECAP0_BASE);
    //
    // Stops Time stamp counter.
    //
    ECAP_stopCounter(myECAP0_BASE);
    //
    // Sets eCAP in Capture mode.
    //
    ECAP_enableCaptureMode(myECAP0_BASE);
    //
    // Sets the capture mode.
    //
    ECAP_setCaptureMode(myECAP0_BASE,ECAP_CONTINUOUS_CAPTURE_MODE,ECAP_EVENT_1);
    //
    // Sets the Capture event prescaler.
    //
    ECAP_setEventPrescaler(myECAP0_BASE, 0U);
    //
    // Sets the Capture event polarity.
    //
    ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_1,ECAP_EVNT_RISING_EDGE);
    ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_2,ECAP_EVNT_FALLING_EDGE);
    ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_3,ECAP_EVNT_RISING_EDGE);
    ECAP_setEventPolarity(myECAP0_BASE,ECAP_EVENT_4,ECAP_EVNT_FALLING_EDGE);
    //
    // Configure counter reset on events
    //
    ECAP_disableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_1);
    ECAP_disableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_2);
    ECAP_disableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_3);
    ECAP_enableCounterResetOnEvent(myECAP0_BASE,ECAP_EVENT_4);
    //
    // Select eCAP input.
    //
    ECAP_selectECAPInput(myECAP0_BASE,ECAP_INPUT_INPUTXBAR1);
    //
    // Sets a phase shift value count.
    //
    ECAP_setPhaseShiftCount(myECAP0_BASE,0U);
    //
    // Disable counter loading with phase shift value.
    //
    ECAP_disableLoadCounter(myECAP0_BASE);
    //
    // Configures Sync out signal mode.
    //
    ECAP_setSyncOutMode(myECAP0_BASE,ECAP_SYNC_OUT_SYNCI);
    //
    // Configures emulation mode.
    //
    ECAP_setEmulationMode(myECAP0_BASE,ECAP_EMULATION_STOP);
    //
    // Starts Time stamp counter for myECAP0.
    //
    ECAP_startCounter(myECAP0_BASE);
    //
    // Enables time stamp capture for myECAP0.
    //
    ECAP_enableTimeStampCapture(myECAP0_BASE);
    //
    // Re-arms the eCAP module for myECAP0.
    //
    ECAP_reArm(myECAP0_BASE);
    //
    // Enables interrupt source for myECAP0.
    //
    ECAP_enableInterrupt(myECAP0_BASE,(ECAP_ISR_SOURCE_CAPTURE_EVENT_1));

    //-----------------Signal Monitoring--------------------//
}




////===============================PWM=============================

typedef struct
{
    uint32_t u32BASE;
    uint16_t u16TBperiodCount;
    uint16_t u16count;
    uint16_t u16phaseCount;
    uint16_t u16CompCount;
} sPWM;
typedef sPWM *HAL_sPWM;

//100K 50 Duty
sPWM CLK0 = { .u32BASE = EPWM1_BASE, .u16TBperiodCount = 500, .u16CompCount =
                      250, };

sPWM CLK180 = { .u32BASE = EPWM2_BASE, .u16TBperiodCount = 500, .u16CompCount =
                        250,
                .u16phaseCount = 500, };

//25k
sPWM FANCTRL5 = { .u32BASE = EPWM3_BASE, .u16TBperiodCount = 2000,
                  .u16CompCount = 0, .u16phaseCount = 0 };


void Setup_EPWM(HAL_sPWM p)
{
//TB
    EPWM_setClockPrescaler(p->u32BASE, EPWM_CLOCK_DIVIDER_1,
                           EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(p->u32BASE, p->u16TBperiodCount);
    EPWM_setTimeBaseCounter(p->u32BASE, p->u16count);
    EPWM_setTimeBaseCounterMode(p->u32BASE, EPWM_COUNTER_MODE_UP_DOWN);

//phase
    EPWM_forceSyncPulse(CLK0_5_BASE);
    EPWM_enablePhaseShiftLoad(CLK180_5_BASE);
    EPWM_setPhaseShift(p->u32BASE, p->u16phaseCount);

//CC
    EPWM_setCounterCompareValue(p->u32BASE, EPWM_COUNTER_COMPARE_A,
                                p->u16CompCount);
    EPWM_setCounterCompareShadowLoadMode(p->u32BASE, EPWM_COUNTER_COMPARE_A,
                                         EPWM_COMP_LOAD_ON_CNTR_ZERO);
    EPWM_setCounterCompareValue(p->u32BASE, EPWM_COUNTER_COMPARE_B,
                                p->u16CompCount);
    EPWM_setCounterCompareShadowLoadMode(p->u32BASE, EPWM_COUNTER_COMPARE_B,
                                         EPWM_COMP_LOAD_ON_CNTR_ZERO);

//AQ-A
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_LOW,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_HIGH,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_A,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
//AQ-B
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_LOW,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_HIGH,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
    EPWM_setActionQualifierAction(p->u32BASE, EPWM_AQ_OUTPUT_B,
                                  EPWM_AQ_OUTPUT_NO_CHANGE,
                                  EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
//DB

    EPWM_setRisingEdgeDelayCountShadowLoadMode(p->u32BASE,
                                               EPWM_RED_LOAD_ON_CNTR_ZERO);
    EPWM_disableRisingEdgeDelayCountShadowLoadMode(p->u32BASE);
    EPWM_setFallingEdgeDelayCountShadowLoadMode(p->u32BASE,
                                                EPWM_FED_LOAD_ON_CNTR_ZERO);
    EPWM_disableFallingEdgeDelayCountShadowLoadMode(p->u32BASE);
}

void init_EPWM(void)
{
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    Setup_EPWM(&CLK0);
    Setup_EPWM(&CLK180);
    Setup_EPWM(&FANCTRL5);

    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);
}


void updateFANCTRL5Duty( void)
{
    EPWM_setCounterCompareValue(EPWM3_BASE, EPWM_COUNTER_COMPARE_A, cnvAdc2Duty());

}

//========================SPIA=============================

//200k
sPWM pwm200kCfg = { .u32BASE = EPWM4_BASE, .u16TBperiodCount = 499, // 200kHz �� TBPRD
                    .u16count = 0,              // ��l�p�ƭ�
                    .u16phaseCount = 0,              // �L�ۦ찾��
                    .u16CompCount = 250 };
//Event-Trigger
void EPWM_TRIGER_ADC(HAL_sPWM p)
{

    //TB
    EPWM_setClockPrescaler(p->u32BASE, EPWM_CLOCK_DIVIDER_1,
                           EPWM_HSCLOCK_DIVIDER_1);
    EPWM_setTimeBasePeriod(p->u32BASE, p->u16TBperiodCount);
    EPWM_setTimeBaseCounter(p->u32BASE, p->u16count);
    EPWM_setTimeBaseCounterMode(p->u32BASE, EPWM_COUNTER_MODE_UP);

    EPWM_disableADCTrigger(p->u32BASE, EPWM_SOC_A);

    //����Ĳ�o
    EPWM_setADCTriggerSource(p->u32BASE, EPWM_SOC_A, EPWM_SOC_TBCTR_PERIOD);
    //every time
    EPWM_setADCTriggerEventPrescale(p->u32BASE, EPWM_SOC_A, 1);

    //OPEN SOC
    EPWM_enableADCTrigger(p->u32BASE, EPWM_SOC_A);
}

//  GPIO_togglePin(PIN74_GPIO31_GPIO);
//  GPIO_writePin(PIN74_GPIO31_GPIO,1);
//  GPIO_writePin(PIN74_GPIO31_GPIO,0);

volatile uint32_t *gpioDataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) +((31 / 32U) * GPIO_DATA_REGS_STEP);
volatile uint32_t *gpioDataReg2 = (uint32_t *)((uintptr_t)GPIODATA_BASE) +((31 / 32U) * GPIO_DATA_REGS_STEP);
ST_SPIA sSPIA = { .REGFIFO = 0,
                  .u16pop = 0,
                  .u16push = 0,
                  .CurFSM = _Idle,
                  .NewFSM = _Mode_Slave

};


 void SPIA_Switch(HAL_SPIA p){

     if(sParams.sDout.o_stat.b17_master == 0){
         p->NewFSM = _Mode_Slave;
     }else{
         p->NewFSM = _Mode_Master;
     }

     if(p->NewFSM == p->CurFSM) return;

    switch (p->NewFSM){

    case _Idle:
        break;

    case _Mode_Slave:

        SPIA_ClearInterrupt();
        SPI_disableModule(mySPI0_BASE);
        SPI_reset(mySPI0_BASE);

        Interrupt_init();
        EPWM_TRIGER_ADC(&pwm200kCfg);
        Reset_SPI_GPIO();
        #if (SetControlGPIO == Card)
            Common_GPIO();
        #else
            SLAVE_GPIO();
        #endif
        SPIA_Config_S();

        p->CurFSM = p->NewFSM;
        break;

    case _Mode_Master:

        SPIA_ClearInterrupt();
        SPI_disableModule(mySPI0_BASE);
        SPI_reset(mySPI0_BASE);

        Interrupt_init();
        EPWM_TRIGER_ADC(&pwm200kCfg);
        Reset_SPI_GPIO();
        #if (SetControlGPIO == Card)
            Common_GPIO();
        #else
            MASTER_GPIO();
        #endif
        SPIA_Config_M();

        p->CurFSM = p->NewFSM;
        break;




    default:
        break;
    }
}
 void SPIA_Control(void){
     SPIA_Switch(&sSPIA);
 }

////=================================ADC======================================


#ifdef _FLASH
#pragma SET_CODE_SECTION(".TI.ramfunc")
#endif //_FLASH


__interrupt void INT_mySPI0_RX_ISR(void){

//    gpioDataReg[GPIO_GPxSET_INDEX]   = 0x80000000U;

    sSPIA.REGFIFO[sSPIA.u16pop].u16AllData = HWREGH(mySPI0_BASE + SPI_O_RXBUF);

    uint16_t rxChk1 = sSPIA.REGFIFO[sSPIA.u16pop].Package.u16check & 0x000F;

    uint16_t rxChk2 = SPI_CalcChecksum(sSPIA.REGFIFO[sSPIA.u16pop].u16AllData);

    if (rxChk1 == rxChk2){
        DAC_setShadowValue(CC_DA_BASE, sSPIA.REGFIFO[sSPIA.u16pop].Package.u16CV_AD);

        sSPIA.u16ChkSuccess++;
    }
    else{
        sSPIA.u16ChkFail++;
    }

    SPI_clearInterruptStatus(mySPI0_BASE, SPI_INT_RXFF);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP6);

//    gpioDataReg[GPIO_GPxCLEAR_INDEX] = 0x80000000U;
}

//__interrupt void INT_mySPI0_TX_ISR(void){}


uint16_t index;
// 200k trigger
__interrupt void INT_CV_AD_2_ISR(void){

//    gpioDataReg2[GPIO_GPxSET_INDEX]   = 0x40000000U;


    //Slave ADC Interrupt exit
//    if(sSPIA.CurFSM == _Mode_Slave){
        if(sParams.sDout.o_stat.b17_master == 0){
        sSPIA.REGFIFO[sSPIA.u16push].Package.u16CV_AD = ADC_readResult(CV_AD_RESULT_BASE, ADC_SOC_NUMBER0);

        sGbVars.u16TempC_AD                           = ADC_readResult(MCP3301_TEMP_RESULT_BASE, ADC_SOC_NUMBER1);
        sParams.sTemp_C.u16Data[0] = sGbVars.u16TempC_AD;
        sParams.sTemp_C.u16Data[1] = 0;
//        ADC_clearInterruptStatus(CV_AD_BASE, ADC_INT_NUMBER1);
        Interrupt_clearACKGroup(INT_CV_AD_2_INTERRUPT_ACK_GROUP);

//        gpioDataReg2[GPIO_GPxCLEAR_INDEX] = 0x40000000U;
        return;
    }

    //Master ADC through SPI to slave
    DAC_setShadowValue(CC_DA_BASE, sSPIA.REGFIFO[sSPIA.u16push].Package.u16CV_AD );
    sSPIA.u16push ^= 1;

    sSPIA.REGFIFO[sSPIA.u16push].Package.u16CV_AD = ADC_readResult(CV_AD_RESULT_BASE, ADC_SOC_NUMBER0);
//    sSPIA.REGFIFO[sSPIA.u16push].Package.u16CV_AD = index++;
    sSPIA.REGFIFO[sSPIA.u16push].Package.u16check = SPI_CalcChecksum(sSPIA.REGFIFO[sSPIA.u16push].u16AllData);

//    if(index == 4096) index =0;

    SPI_writeDataNonBlocking(mySPI0_BASE,sSPIA.REGFIFO[sSPIA.u16push].u16AllData);


    sGbVars.u16TempC_AD                           = ADC_readResult(MCP3301_TEMP_RESULT_BASE, ADC_SOC_NUMBER1);
    sParams.sTemp_C.u16Data[0] = sGbVars.u16TempC_AD;
    sParams.sTemp_C.u16Data[1] = 0;

//    ADC_clearInterruptStatus(CV_AD_BASE, ADC_INT_NUMBER1);
    Interrupt_clearACKGroup(INT_CV_AD_2_INTERRUPT_ACK_GROUP);


//    gpioDataReg2[GPIO_GPxCLEAR_INDEX] = 0x40000000U;
}

#ifdef _FLASH
#pragma SET_CODE_SECTION()
#endif //_FLASH


__interrupt void INT_CV_AD_1_ISR(void){

//    sGbVars.u32Heartbeats++;
//    sGbVars.u32Heartbeats &= 0x7FFFFFFF;
//    sParams.sHeartbeats.u32Data = sGbVars.u32Heartbeats;
//
////CV_AD adcValue
//    sGbVars.u16CV_AD = ADC_readResult(CV_AD_RESULT_BASE, ADC_SOC_NUMBER0);
//    sGbVars.u16TempC_AD = ADC_readResult(MCP3301_TEMP_RESULT_BASE, ADC_SOC_NUMBER1);
//
//
//    DAC_setShadowValue(CC_DA_BASE, sGbVars.u16CV_AD);
//    sParams.sTemp_C.u16Data[0] = sGbVars.u16TempC_AD;
//    sParams.sTemp_C.u16Data[1] = 0;
//
//    Interrupt_clearACKGroup(INT_CV_AD_1_INTERRUPT_ACK_GROUP);
//    ADC_clearInterruptStatus(CV_AD_BASE, ADC_INT_NUMBER1);
}
