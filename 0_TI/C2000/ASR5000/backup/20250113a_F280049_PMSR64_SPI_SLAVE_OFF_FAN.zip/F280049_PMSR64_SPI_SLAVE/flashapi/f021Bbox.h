/*
 * f021Bbox.h
 *
 *  Created on: Apr 16, 2024
 *      Author: User
 */

#ifndef F021BBOX_H_
#define F021BBOX_H_


#include "common.h"

extern void runFlashStorage(void);
extern uint16_t isBboxFree(void);
extern uint16_t isCallbackReady(void);

#endif /* F021BBOX_H_ */
