//
// Included Files
//
#include "common.h"

#include "mb_slave/ModbusSlave.h"
#include "spi_master.h"

uint32_t u32Test[5] = {0x00000000,0x11223344,0x55667788,0x12345678,0x98765432};

ST_SPI_MASTER sSpiM = {
                       .u32Fsm = _SEND_SPI_PACK,
                       .u16Pop = 0,
                       .u16Push = 0,
                       .u32Timeout = 0,
                       .u32TimeStamp = 0,
                       .u32TimeMark = 0,
                       .u32ErrCnts = 0,
                       .u32OkCnts = 0

};


uint16_t u16Action = 0;

uint16_t u16Command = 1;

void task25msec(void * s)
{


    GPIO_togglePin(LED_GPIO67);
}



void task1msec(void * s)
{
    if(0 == u16Action){
        u16Action = u16Command;
        u16Command++;
        u32Test[0] = u32Test[1];
        u32Test[1] = u32Test[2];
        u32Test[2] = u32Test[3];
        u32Test[3] = u32Test[4];
        u32Test[4] = u32Test[0];
        if(5 == u16Command) u16Command = 1;
    }
}


uint16_t id_ttask = 0;
ST_TIMETASK time_task[] = {
        {task1msec,           0,   T_1MS},
        {task25msec,          0,   T_25MS},
        {0, 0, 0}
};


void scanSpiAction(void)
{
    switch(u16Action) {
    case 1:
        pushSpiWpack(0x1, u32Test, &sSpiM);
        u16Action = 0;
        break;
    case 2:
        pushSpiWpack(0x2, u32Test, &sSpiM);
        u16Action = 0;
        break;

    case 3:
        pushSpiRpack(0x3, u32Test, &sSpiM);
        u16Action = 0;
        break;

    case 4:
        pushSpiRpack(0x4, u32Test, &sSpiM);
        u16Action = 0;
        break;

    default:
        popSpiWdata(&sSpiM);
        break;

    }
}


void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Initialize GPIO and configure the GPIO pin as a push-pull output
    //
    Board_init();


    //
    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    //
    EINT;
    ERTM;

    //
    // Loop Forever
    //
    while(1)
    {
        scanTimeTask(&time_task[id_ttask++], (void *)0);
        if(0 == time_task[id_ttask].fn) id_ttask = 0;

        exeModbusSlave((SCI_MODBUS *)&mbcomm);

        scanSpiAction();
    }
}

//
// End of File
//
