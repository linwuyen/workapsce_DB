/*===========================================================================================
    Project Name    : I04_VDU1
    Built Date      : 2020-05-13
    Version         : V1.00a
    Programmer      : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Compiler        : TI V18.12.2.LTS
    MCU             : F280049
    Support Driver  : -
    Support HMI     : -
    Description     : -
	Last Update		: See "Setup firmware" below.
    =========================================================================================
    History         :
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

// Setup firmware version here !
#define CONST_FW_VERSION	"J06VDU1V202b 2022121610F1  "

#ifndef COM_CODE_VER
#define COM_CODE_VER		84	// MarkV2.5 communication
#endif
#ifndef HWEEP_CODE_VER
#define HWEEP_CODE_VER		85  // HW Info save in fweep.
#endif
#define FWEEP_CODE_VER		82	// Major 9, minor 16
#define HW_CODE_VER			83  // Project, PWR src, max I or power, other
#define FW_CODE_VER			83  // Branch number is now after date. stage should have space if only 1 char.

/************************** EXTERNAL VARIABLES ********************************/


volatile Struct_MD 									CG_MD;								// Main.c global variable data structure.




extern volatile Struct_Encoder 						CG_Encoder;

extern volatile Struct_UART  						CG_UART;
extern volatile Struct_UART485 	 					CG_UART485;
extern volatile Struct_Modbus_Slave 				CG_Modbus_Slave;
extern volatile Struct_Modbus_Slave					CG_Modbus_Slave_485;
extern volatile Struct_Parameter					CG_Parameter;
extern volatile Struct_ComProtocol_01				CG_ComProtocol_01;
extern volatile Struct_GPIO 						CG_GPIO;
//extern volatile Struct_BLDC_Drive					CG_BLDC_Drive;
//extern volatile Struct_BLDC_CTRL 					CG_BLDC_CTRL;

//extern volatile Struct_Speed 						CG_Speed;
extern volatile Struct_HallSensor                   CG_Hall_M0;
//extern volatile Struct_HallSensor                   CG_Hall_M1;

extern volatile Struct_I2C 							CG_I2C;
extern volatile Struct_HWEEP						CG_HWEEP;
extern volatile Struct_OPMode 						CG_OPMode;
extern volatile Struct_IO							CG_IO;
extern volatile Struct_IO_FUNC                      CG_IO_Func_M0;
//extern volatile Struct_IO_FUNC                      CG_IO_Func_M1;
extern volatile Struct_Pretect 						CG_Protect;
//extern volatile Struct_PhaseAdv 					CG_PhaseAdv;
extern volatile Struct_ADC 							CG_ADC;

extern volatile Struct_Move 						CG_Move;

extern volatile Struct_BLDC_Drive                   CG_BLDC_Drive_M0;
//extern volatile Struct_BLDC_Drive                   CG_BLDC_Drive_M1;
extern volatile Struct_BLDC_CTRL                    CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL                    CG_BLDC_CTRL_M1;
extern volatile Struct_Move                         CG_Move_M0;
//extern volatile Struct_Move                         CG_Move_M1;
//extern volatile Struct_IO_Expander                  CG_IO_Expander;
extern volatile Struct_SPK                          CG_SPK_M0;
//extern volatile Struct_SPK                          CG_SPK_M1;
extern volatile Struct_CAN                          CG_CAN;
extern volatile Struct_PI                           CG_PI;

extern void ( *const opMode_Handler[ OP_MODE_NUM ] ) ( uint32_t digit_num );
extern uint32_t ( *const inputXn_action[ FUNC_NUM ] ) ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );
extern void ( *const motor_State_Handler[ MOTOR_STATE_TOTALNUM ] ) ( Struct_BLDC_CTRL* bldc_ctrl );
extern void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void );
extern void ( *const modbus_slave_Handler[MB_SLV_TRANS_MODE_NUM][ MB_SLV_STATE_NUM ] )
														(	uint8_t *ReceiveFlag,	// UART receive flag.
															uint8_t *data,          // UART receive data buffer.
															uint32_t data_num,      // UART receive data number.
															uint8_t *T_data,        // UART transmit data buffer.
															uint8_t *T_data_Length, // UART transmit data length.
															uint8_t *T_send_flag,   // UART data send flag.
															uint8_t *T_data_ptr,    // UART sata send pointer.
															Struct_Modbus_Slave *str_modbus
														 );



//#pragma CODE_SECTION( cpu_timer0_isr, "ramfuncs");
#pragma CODE_SECTION( cpu_timer0_isr, ".TI.ramfunc" );

/*===========================================================================================
    Function Name    : cpu_timer0_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__interrupt void cpu_timer0_isr(void)
{
	// CpuTimer0.InterruptCount++;

	static uint32_t cnt_1s		= 1000;
	static uint32_t cnt_100ms	= 100;
	static uint32_t cnt_PFms	= 33;
	static uint32_t cnt_10ms	= 10;

	//IO_Y1_TOGGLE;
	//IO_Y2_TOGGLE;

	CG_MD.SysTickCnt++;
	CG_MD.SysTick_BITF |= TICK_1MS;					// Set 1 ms tick flag.

	checkBusyFlag_I2C();
	checkError_I2C();

	if (CG_MD.SysTickCnt == cnt_10ms) {
		CG_MD.SysTick_BITF |= TICK_10MS;			// Set 10 ms tick flag.
		cnt_10ms      = cnt_10ms + 10;
	}

	if (CG_MD.SysTickCnt == cnt_100ms) {
		CG_MD.SysTick_BITF |= TICK_100MS;			// Set 100 ms tick flag.
		cnt_100ms     = cnt_100ms + 100;
	}

	if (CG_MD.SysTickCnt == cnt_PFms) {
		CG_MD.SysTick_BITF |= TICK_PFMS;			// Set PF ms tick flag.
		cnt_PFms	  = cnt_PFms + CG_MD.PowerFreq;
	}

	if (CG_MD.SysTickCnt == cnt_1s) {
		CG_MD.SysTick_BITF |= TICK_1S;				// Set 1 s tick flag.
		cnt_1s		  = cnt_1s + 1000;
	}

	//
#if(TEST_FAKE_HALL_SENSOR)
	gpio_FakeHallSensor();
#endif
	//


   	// Acknowledge this interrupt to receive more interrupts from group 1
   	PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
}

/*===========================================================================================
    Function Name    : variableInitial_MD
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw ( Modified by Gear.Feng@trumman.com.tw )
    Description      : Variable CG_MD initial
//==========================================================================================*/
void variableInitial_MD (void)
{
    CG_MD.SysTickCnt        = 0;			// system tick counter reset.
    CG_MD.SysTick_BITF      = 0;            // system tick bit field reset.
    CG_MD.Test_cnt			= 0;
    CG_MD.Test_time 		= 0;
    CG_MD.Test_tp1			= 0;
    CG_MD.Test_tp2			= 0;
    CG_MD.PwrOn_BITF		= ( 0xFFFFUL << 16 | 0xFFFF );
    CG_MD.Start_Cnt			= 0;

#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Main_TP_New = 0;
    CG_MD.Main_TP_Old = 0;
    CG_MD.Main_Cost_Time = 0;

    CG_MD.Event1ms_TP_New = 0;
    CG_MD.Event1ms_TP_Old = 0;
    CG_MD.Event1ms_Cost_Time = 0;

    CG_MD.Event10ms_TP_New = 0;
    CG_MD.Event10ms_TP_Old = 0;
    CG_MD.Event10ms_Cost_Time = 0;

    CG_MD.Event100ms_TP_New = 0;
    CG_MD.Event100ms_TP_Old = 0;
    CG_MD.Event100ms_Cost_Time = 0;

    CG_MD.Event1000ms_TP_New = 0;
    CG_MD.Event1000ms_TP_Old = 0;
    CG_MD.Event1000ms_Cost_Time = 0;

#endif


    CG_MD.Pwr_On_Cnt        = 0;
    CG_MD.Relay_On_Cnt      = 0;
    CG_MD.PowerRelay_Flag   = NO;
	CG_MD.PowerFreq			= POWERFREQ;    // Initial value for the power frequency.

	//
	CG_MD.DI_5V_State = LOW;
	CG_MD.Vcc12V_Ctrl_State = LOW;
	CG_MD.STA_LED_State = LOW;
	CG_MD.STA_LED_State_RS485 = LOW;
	CG_MD.STA_LED_State_CAN = LOW;
	CG_MD.RS485_CAN_SEL_State = LOW;
	CG_MD.CAN_EN_State = LOW;


	//
#if(TEST_FAKE_HALL_SENSOR)
	CG_MD.FakeHall_Timer = 0;
	CG_MD.FakeHall_TimeConst = 0;
	CG_MD.FakeHall_Point = 0;
#endif
	//

}

/*===========================================================================================
    Function Name    : SysTick_Set
    Input            : NULL
    Return           : Null
    Programmer       :
    Description      :
//==========================================================================================*/
void SysTick_Set( uint32_t ticks )
{

	variableInitial_MD();

	//SET_485_MUX_STATE( STATE_READY );

	EALLOW;  // This is needed to write to EALLOW protected registers
	PieVectTable.TIMER0_INT = &cpu_timer0_isr;
	EDIS;    // This is needed to disable write to EALLOW protected registers

	InitCpuTimers();   // Initialize the Cpu Timers

	// Configure CPU-Timer 0 to interrupt every 1 milliseconds:
	// 90MHz CPU Freq, 1 millisecond Period (in uSeconds)
	ConfigCpuTimer( &CpuTimer0, CPU_FREQ_IN_M, ticks );

	CpuTimer0Regs.TCR.bit.TSS = 0; // Use write-only instruction to set TSS bit = 0

	PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

	IER |= M_INT1;


}

/*===========================================================================================
    Function Name    : management_PowerRelay
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Decide if open power relay
//==========================================================================================*/
void management_PowerRelay( void )
{
    /*
    if( CG_MD.PowerRelay_Ready2Open == YES ){
        //BUSV_RELAY_ON;
        CG_MD.PowerRelay_Flag = YES;
    }else{
        //BUSV_RELAY_OFF;
        CG_MD.PowerRelay_Flag = NO;
    }*/
}

/*===========================================================================================
    Function Name    : management_RGN_DAC
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Decide if turn on RGNEN
//==========================================================================================*/
void management_RGN_DAC( void )
{
    int32_t dac_value;
    if( ( ( CG_Protect.Motor_0.Fault_BITF >> FAULT_STATE_OT_RGN ) & 0x01 ) != 0 ||     // RGN OT or
        ( ( CG_Protect.Motor_0.Fault_BITF >> FAULT_STATE_BUSV_OVER ) & 0x01 ) != 0 ||   // Over bus V or
        CG_ADC.BusV > CG_Protect.Motor_0.over_vbus_value  ){                      // Relay is not on

        dac_value = ADC_MAX_VALUE;

        CG_IO_Func_M0.Output_State[ OUTPUT_RGN_OUT ] = 1 - CG_IO_Func_M0.ActState_of_Func[ OUTPUT_RGN_OUT ];

    }else{

        if( BUSV_PHYSIC_MAX != 0 ){
            //dac_value = ( CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OV_RECOVER ] * ADC_MAX_VALUE / BUSV_PHYSIC_MAX ) / 3;
            if( CG_ADC.BusV > CG_Protect.Motor_0.over_vbus_recover_value  ){
                dac_value = 0;
                CG_IO_Func_M0.Output_State[ OUTPUT_RGN_OUT ] = CG_IO_Func_M0.ActState_of_Func[ OUTPUT_RGN_OUT ];
            }else{
                dac_value = ADC_MAX_VALUE;
                CG_IO_Func_M0.Output_State[ OUTPUT_RGN_OUT ] = 1 - CG_IO_Func_M0.ActState_of_Func[ OUTPUT_RGN_OUT ];
            }
        }else{
            dac_value = ADC_MAX_VALUE;
            CG_IO_Func_M0.Output_State[ OUTPUT_RGN_OUT ] = 1 - CG_IO_Func_M0.ActState_of_Func[ OUTPUT_RGN_OUT ];
        }
    }

    //setup_DAC( dac_value ); // RGN DAC
    setValue_DACA( dac_value ); // RGN DAC
    OutputYn_action [ CG_IO_Func_M0.Output_State[ OUTPUT_RGN_OUT ] ]
                    [ CG_IO_Func_M0.OutputPin_of_Func[ OUTPUT_RGN_OUT ] ]();
}

/*===========================================================================================
    Function Name    : management_BR_ALL
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void management_BR_ALL( void )
{
    if( CG_ADC.BusV < CG_Protect.Motor_0.under_vbus_value ){
        CG_BLDC_CTRL_M0.IO_Func_Ptr->Output_State[ OUTPUT_BR_ALL ] = 1 - CG_BLDC_CTRL_M0.IO_Func_Ptr->ActState_of_Func[ OUTPUT_BR_ALL ];
    }else{
        CG_BLDC_CTRL_M0.IO_Func_Ptr->Output_State[ OUTPUT_BR_ALL ] = CG_BLDC_CTRL_M0.IO_Func_Ptr->ActState_of_Func[ OUTPUT_BR_ALL ];
    }

    OutputYn_action[ CG_BLDC_CTRL_M0.IO_Func_Ptr->Output_State[ OUTPUT_BR_ALL ] ]
                   [ CG_BLDC_CTRL_M0.IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_BR_ALL ] ]();

}

/*===========================================================================================
    Function Name    : call_1ms
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 1 ms time up event.
//==========================================================================================*/
static void call_1ms (void)
{
    int32_t duty;

#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event1ms_TP_Old = FREE_RUN_TIMER.TIM.all;
#endif
    //CG_MD.Test_tp1          = CURRENT_TIMER_CNT;

    modBus_TimeOut_Check( (Struct_Modbus_Slave*)&CG_Modbus_Slave, CG_Modbus_Slave.Time_Out_num );
	modBus_TimeOut_Check( (Struct_Modbus_Slave*)&CG_Modbus_Slave_485, CG_Modbus_Slave_485.Time_Out_num );

	// Fixed DynamicData update
	// M0
	CG_Parameter.dynamic_data[0] = CG_BLDC_CTRL_M0.Motor_State & 65535;
	CG_Parameter.dynamic_data[2] = CG_BLDC_CTRL_M0.Current_RPM_Abs & 65535;
	CG_Parameter.dynamic_data[3] = CG_BLDC_CTRL_M0.Protect_Ptr->first_fault_user & 65535;
    CG_Parameter.dynamic_data[4] = CG_BLDC_CTRL_M0.Current_Dir & 65535;
    CG_Parameter.dynamic_data[5] = CG_BLDC_CTRL_M0.Target_Speed_RPM_Abs & 65535;
    CG_Parameter.dynamic_data[6] = CG_BLDC_CTRL_M0.Current_Target_Speed_RPM_Abs & 65535;
    CG_Parameter.dynamic_data[7] = CG_BLDC_CTRL_M0.ADC_Ptr->Power & 65535;

    // M1
    CG_Parameter.dynamic_data[0+16] = CG_BLDC_CTRL_M0.E_Lock_Flag & 65535;//CG_BLDC_CTRL_M1.Motor_State & 65535;
    CG_Parameter.dynamic_data[2+16] = 0;//CG_BLDC_CTRL_M1.Current_RPM_Abs & 65535;
    CG_Parameter.dynamic_data[3+16] = 0;//CG_BLDC_CTRL_M1.Protect_Ptr->first_fault_user & 65535;
    CG_Parameter.dynamic_data[4+16] = 0;//CG_BLDC_CTRL_M1.Current_Dir & 65535;
    CG_Parameter.dynamic_data[5+16] = 0;//CG_BLDC_CTRL_M1.Target_Speed_RPM_Abs & 65535;
    CG_Parameter.dynamic_data[6+16] = 0;//CG_BLDC_CTRL_M1.Current_Target_Speed_RPM_Abs & 65535;
    CG_Parameter.dynamic_data[7+16] = 0;//CG_BLDC_CTRL_M1.ADC_Ptr->Power & 65535;

    // Selectable DynamicData update
    if ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] == 0 ) {
        // M0

        CG_Parameter.dynamic_data[1] = CG_BLDC_CTRL_M0.Protect_Ptr->OverLoad_flag;

        #define IO_X(index)   ( ( CG_GPIO.Xn_State_BITF >> index ) & 0x01 )
        #define IO_Y(index)   ( ( CG_GPIO.Yn_State_BITF >> index ) & 0x01 )

        CG_Parameter.dynamic_data[8] = ( IO_X(4) * 10000 + IO_X(3) * 1000 + IO_X(2) * 100 + IO_X(1) * 10 + IO_X(0) ) & 65535 ;
        CG_Parameter.dynamic_data[9] = CG_ADC.BusV & 65535;

        CG_Parameter.dynamic_data[10] = ( CG_BLDC_CTRL_M0.ADC_Ptr->Shunt_I / TORQUE_J06TOI04_GAIN ) & 65535;
        CG_Parameter.dynamic_data[11] = CG_BLDC_CTRL_M0.Current_Duty_Display & 65535;
        CG_Parameter.dynamic_data[12] = ( CG_BLDC_CTRL_M0.ADC_Ptr->Shunt_I_Avg / TORQUE_J06TOI04_GAIN ) & 65535;
        CG_Parameter.dynamic_data[13] = ( CG_BLDC_CTRL_M0.OpMode_Ptr->Torque_Limit / TORQUE_J06TOI04_GAIN ) & 65535;
        CG_Parameter.dynamic_data[14] = ( CG_BLDC_CTRL_M0.Protect_Ptr->OverLoad_flag * 1000 +
                                          CG_BLDC_CTRL_M0.Protect_Ptr->OverPower_flag * 100 +
                                          CG_BLDC_CTRL_M0.Protect_Ptr->FWCR_flag * 10 +
                                          ( 1 - CG_BLDC_CTRL_M0.Protect_Ptr->HWCR_Lock_Flag ) ) & 65535;

        CG_Parameter.dynamic_data[15] = ( *CG_BLDC_CTRL_M0.VR_Speed / THROTTLE_MULTIFY ) & 65535;

        // M1
        CG_Parameter.dynamic_data[1+16] = 0;//CG_BLDC_CTRL_M1.Protect_Ptr->OverLoad_flag;

        CG_Parameter.dynamic_data[8+16] = ( IO_X(9) * 10000 + IO_X(8) * 1000 + IO_X(7) * 100 + IO_X(6) * 10 + IO_X(5) ) & 65535 ;
        CG_Parameter.dynamic_data[9+16] = 0;

        CG_Parameter.dynamic_data[10+16] = 0;//CG_BLDC_CTRL_M1.ADC_Ptr->Shunt_I & 65535;
        CG_Parameter.dynamic_data[11+16] = 0;//CG_BLDC_CTRL_M1.Current_Duty_Display & 65535;
        CG_Parameter.dynamic_data[12+16] = 0;//CG_BLDC_CTRL_M1.ADC_Ptr->Shunt_I_Avg & 65535;
        CG_Parameter.dynamic_data[13+16] = 0;//CG_BLDC_CTRL_M1.OpMode_Ptr->Torque_Limit & 65535;
        CG_Parameter.dynamic_data[14+16] = 0;/*( CG_BLDC_CTRL_M1.Protect_Ptr->OverLoad_flag * 1000 +
                                             CG_BLDC_CTRL_M1.Protect_Ptr->OverPower_flag * 100 +
                                             CG_BLDC_CTRL_M1.Protect_Ptr->FWCR_flag * 10 +
                                             ( 1 - CG_BLDC_CTRL_M1.Protect_Ptr->HWCR_Lock_Flag ) ) & 65535;*/

        CG_Parameter.dynamic_data[15+16] = 0;//( *CG_BLDC_CTRL_M1.VR_Speed / THROTTLE_MULTIFY ) & 65535;

    } else if( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] == 1 ) {
        // M0
        CG_Parameter.dynamic_data[1] = ( CG_BLDC_CTRL_M0.Current_Dir == CG_BLDC_CTRL_M0.Target_Dir );
        CG_Parameter.dynamic_data[8] = ( IO_Y(3) * 1000 + IO_Y(2) * 100 + IO_Y(1) * 10 + IO_Y(0) ) & 65535 ;
        CG_Parameter.dynamic_data[9] = CG_BLDC_CTRL_M0.OpMode_Ptr->Acc_Time & 65535;
        CG_Parameter.dynamic_data[10] = CG_BLDC_CTRL_M0.OpMode_Ptr->Dec_Time & 65535;
        CG_Parameter.dynamic_data[11] = 0;
        CG_Parameter.dynamic_data[12] = ( CG_ADC.Value_Mapping[ ADC_Index_A0X ] / THROTTLE_MULTIFY ) & 65535;
        CG_Parameter.dynamic_data[13] = 0;
        CG_Parameter.dynamic_data[14] = 0;
        CG_Parameter.dynamic_data[15] = 0;

        // M1
        CG_Parameter.dynamic_data[1+16] = 0;//( CG_BLDC_CTRL_M1.Current_Dir == CG_BLDC_CTRL_M1.Target_Dir );
        CG_Parameter.dynamic_data[8+16] = ( IO_Y(8) * 10000 + IO_Y(7) * 1000 + IO_Y(6) * 100 + IO_Y(5) * 10 + IO_Y(4) ) & 65535 ;
        CG_Parameter.dynamic_data[9+16] = 0;//CG_BLDC_CTRL_M1.OpMode_Ptr->Acc_Time & 65535;
        CG_Parameter.dynamic_data[10+16] = 0;//CG_BLDC_CTRL_M1.OpMode_Ptr->Dec_Time & 65535;
        CG_Parameter.dynamic_data[11+16] = 0;
        CG_Parameter.dynamic_data[12+16] = ( CG_ADC.Value_Mapping[ ADC_Index_A1X ] / THROTTLE_MULTIFY ) & 65535;
        CG_Parameter.dynamic_data[13+16] = 0;
        CG_Parameter.dynamic_data[14+16] = 0;
        CG_Parameter.dynamic_data[15+16] = 0;

    }else if( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] == 2 ){

        CG_Parameter.dynamic_data[1] = 0;

        CG_Parameter.dynamic_data[8] = 0;
        CG_Parameter.dynamic_data[9] = 0;

        CG_Parameter.dynamic_data[10] = mcIndexDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[11] = mcPosDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[12] = mcIndexDisplay_CurrentTarget( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[13] = mcPosDisplay_CurrentTarget( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[14] = mcIndexDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[15] = mcPosDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;

        CG_Parameter.dynamic_data[1+16] = 0;

        CG_Parameter.dynamic_data[8+16] = 0;
        CG_Parameter.dynamic_data[9+16] = 0;

        CG_Parameter.dynamic_data[10+16] = 0;//mcIndexDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[11+16] = 0;//mcPosDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[12+16] = 0;//mcIndexDisplay_CurrentTarget( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[13+16] = 0;//mcPosDisplay_CurrentTarget( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[14+16] = 0;//mcIndexDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[15+16] = 0;//mcPosDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;

    //}else if( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] < ENG_PAGE_ADC_INDEX ){
    }else if( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] < ENG_PAGE_IBIKE_INDEX ){

        // M0
        CG_Parameter.dynamic_data[0] = CG_BLDC_CTRL_M0.Motor_State & 65535;
        CG_Parameter.dynamic_data[1] = CG_BLDC_CTRL_M0.Target_Speed_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[2] = CG_BLDC_CTRL_M0.Current_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[3] = CG_BLDC_CTRL_M0.Protect_Ptr->first_fault_user & 65535;
        CG_Parameter.dynamic_data[4] = CG_BLDC_CTRL_M0.Current_Dir & 65535;
        CG_Parameter.dynamic_data[5] = CG_BLDC_CTRL_M0.OpMode_Ptr->Digit_Num & 65535;
        CG_Parameter.dynamic_data[6] = CG_BLDC_CTRL_M0.Hall_Ptr->Position & 65535;
        CG_Parameter.dynamic_data[7] = CG_BLDC_CTRL_M0.ADC_Ptr->Power & 65535;
        CG_Parameter.dynamic_data[8] = CG_GPIO.Xn_State_BITF & 65535;

        CG_Parameter.dynamic_data[9] = CG_ADC.BusV & 65535;
        CG_Parameter.dynamic_data[10] = ( CG_BLDC_CTRL_M0.ADC_Ptr->Shunt_I_Avg / TORQUE_J06TOI04_GAIN ) & 65535;
        CG_Parameter.dynamic_data[11] = CG_BLDC_CTRL_M0.Current_Duty_Display & 65535;

        CG_Parameter.dynamic_data[12] = mcIndexDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[13] = mcPosDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[14] = mcIndexDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        CG_Parameter.dynamic_data[15] = mcPosDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;

        // M1
        CG_Parameter.dynamic_data[0+16] = 0;//CG_BLDC_CTRL_M1.Motor_State & 65535;
        CG_Parameter.dynamic_data[1+16] = 0;//CG_BLDC_CTRL_M1.Target_Speed_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[2+16] = 0;//CG_BLDC_CTRL_M1.Current_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[3+16] = 0;//CG_BLDC_CTRL_M1.Protect_Ptr->first_fault_user & 65535;
        CG_Parameter.dynamic_data[4+16] = 0;//CG_BLDC_CTRL_M1.Current_Dir & 65535;
        CG_Parameter.dynamic_data[5+16] = 0;//CG_BLDC_CTRL_M1.OpMode_Ptr->Digit_Num & 65535;
        CG_Parameter.dynamic_data[6+16] = 0;//CG_BLDC_CTRL_M1.Hall_Ptr->Position & 65535;
        CG_Parameter.dynamic_data[7+16] = 0;//CG_BLDC_CTRL_M1.ADC_Ptr->Power & 65535;
        CG_Parameter.dynamic_data[8+16] = CG_GPIO.Yn_State_BITF & 65535;

        CG_Parameter.dynamic_data[9+16] = 0;
        CG_Parameter.dynamic_data[10+16] = 0;//CG_BLDC_CTRL_M1.ADC_Ptr->Shunt_I_Avg & 65535;
        CG_Parameter.dynamic_data[11+16] = 0;//CG_BLDC_CTRL_M1.Current_Duty_Display & 65535;

        CG_Parameter.dynamic_data[12+16] = 0;//mcIndexDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[13+16] = 0;//mcPosDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[14+16] = 0;//mcIndexDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        CG_Parameter.dynamic_data[15+16] = 0;//mcPosDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;

    }else if( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] == ENG_PAGE_IBIKE_INDEX ){

        // M0
        CG_Parameter.dynamic_data[0] = CG_BLDC_CTRL_M0.Motor_State & 65535;
        CG_Parameter.dynamic_data[1] = CG_BLDC_CTRL_M0.Target_Speed_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[2] = CG_BLDC_CTRL_M0.Current_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[3] = CG_BLDC_CTRL_M0.Protect_Ptr->first_fault_user & 65535;
        CG_Parameter.dynamic_data[4] = CG_BLDC_CTRL_M0.Current_Dir & 65535;
        CG_Parameter.dynamic_data[5] = CG_BLDC_CTRL_M0.OpMode_Ptr->Digit_Num & 65535;
        //CG_Parameter.dynamic_data[6] = CG_BLDC_CTRL_M0.Hall_Ptr->Position & 65535;
        CG_Parameter.dynamic_data[6] = CG_PI.Motor_0.DirCnt & 65535;
        CG_Parameter.dynamic_data[7] = CG_BLDC_CTRL_M0.ADC_Ptr->Power & 65535;
        CG_Parameter.dynamic_data[8] = CG_GPIO.Xn_State_BITF & 65535;

        CG_Parameter.dynamic_data[9] = CG_ADC.BusV & 65535;
        CG_Parameter.dynamic_data[10] = ( CG_BLDC_CTRL_M0.ADC_Ptr->Shunt_I_Avg / TORQUE_J06TOI04_GAIN ) & 65535;
        CG_Parameter.dynamic_data[11] = CG_BLDC_CTRL_M0.Current_Duty_Display & 65535;

        CG_Parameter.dynamic_data[12] = ( CG_ADC.Value_Mapping[ ADC_Index_A0X ] / THROTTLE_MULTIFY ) & 65535;
        CG_Parameter.dynamic_data[13] = ( CG_BLDC_CTRL_M0.OpMode_Ptr->Torque_Limit / TORQUE_J06TOI04_GAIN ) & 65535;
        CG_Parameter.dynamic_data[14] = ( CG_BLDC_CTRL_M0.Torque_Limit / TORQUE_J06TOI04_GAIN ) & 65535;
        CG_Parameter.dynamic_data[15] = CG_BLDC_CTRL_M0.OpMode_Ptr->EVR_Avg & 65535;

        // M1
        CG_Parameter.dynamic_data[0+16] = 0;//CG_BLDC_CTRL_M1.Motor_State & 65535;
        CG_Parameter.dynamic_data[1+16] = 0;//CG_BLDC_CTRL_M1.Target_Speed_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[2+16] = 0;//CG_BLDC_CTRL_M1.Current_RPM_Abs & 65535;
        CG_Parameter.dynamic_data[3+16] = 0;//CG_BLDC_CTRL_M1.Protect_Ptr->first_fault_user & 65535;
        CG_Parameter.dynamic_data[4+16] = 0;//CG_BLDC_CTRL_M1.Current_Dir & 65535;
        CG_Parameter.dynamic_data[5+16] = 0;//CG_BLDC_CTRL_M1.OpMode_Ptr->Digit_Num & 65535;
        CG_Parameter.dynamic_data[6+16] = 0;//CG_BLDC_CTRL_M1.Hall_Ptr->Position & 65535;
        CG_Parameter.dynamic_data[7+16] = 0;//CG_BLDC_CTRL_M1.ADC_Ptr->Power & 65535;
        CG_Parameter.dynamic_data[8+16] = CG_GPIO.Yn_State_BITF & 65535;

        CG_Parameter.dynamic_data[9+16] = 0;//CG_ADC.BusV & 65535;
        CG_Parameter.dynamic_data[10+16] = 0;//CG_BLDC_CTRL_M1.ADC_Ptr->Shunt_I_Avg & 65535;
        CG_Parameter.dynamic_data[11+16] = 0;//CG_BLDC_CTRL_M1.Current_Duty_Display & 65535;

        CG_Parameter.dynamic_data[12+16] = 0;//( CG_ADC.Value_Mapping[ ADC_Index_A1X ] / THROTTLE_MULTIFY ) & 65535;
        CG_Parameter.dynamic_data[13+16] = 0;//CG_BLDC_CTRL_M1.OpMode_Ptr->Torque_Limit & 65535;
        CG_Parameter.dynamic_data[14+16] = 0;//CG_BLDC_CTRL_M1.Torque_Limit & 65535;
        CG_Parameter.dynamic_data[15+16] = 0;

    }else{

        CG_Parameter.dynamic_data[0] = CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U ] & 65535;
        CG_Parameter.dynamic_data[1] = CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_V ] & 65535;
        CG_Parameter.dynamic_data[2] = CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_W ] & 65535;
        CG_Parameter.dynamic_data[3] = CG_ADC.Value_Inst[ ADC_Index_MosOT_1 ] & 65535;
        CG_Parameter.dynamic_data[4] = CG_ADC.Value_Inst[ ADC_Index_MosOT_2 ] & 65535;
        CG_Parameter.dynamic_data[5] = CG_ADC.Value_Inst[ ADC_Index_MosOT_3 ] & 65535;
        CG_Parameter.dynamic_data[6] = CG_ADC.Value_Inst[ ADC_Index_BusV ] & 65535;
        CG_Parameter.dynamic_data[7] = CG_ADC.Value_Inst[ ADC_Index_A0X ] & 65535;
        CG_Parameter.dynamic_data[8] = CG_ADC.Value_Inst[ ADC_Index_A1X ] & 65535;
        CG_Parameter.dynamic_data[9] = CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U2 ] & 65535;
        CG_Parameter.dynamic_data[10] = CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_V2 ] & 65535;
        CG_Parameter.dynamic_data[11] = CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_W2 ] & 65535;
        CG_Parameter.dynamic_data[12] = CG_ADC.Value_Inst[ ADC_Index_VCC5V_SENSE ] & 65535;
        CG_Parameter.dynamic_data[13] = CG_ADC.Value_Inst[ ADC_Index_POUT1_FB ] & 65535;
        CG_Parameter.dynamic_data[14] = CG_ADC.Value_Inst[ ADC_Index_POUT2_FB ] & 65535;
        CG_Parameter.dynamic_data[15] = 0;

        CG_Parameter.dynamic_data[0+16] = 0;
        CG_Parameter.dynamic_data[1+16] = CG_ADC.Value_Inst[ ADC_Index_M0_BEMF_U ] & 65535;
        CG_Parameter.dynamic_data[2+16] = CG_ADC.Value_Inst[ ADC_Index_M0_BEMF_V ] & 65535;
        CG_Parameter.dynamic_data[3+16] = CG_ADC.Value_Inst[ ADC_Index_M0_BEMF_W ] & 65535;
        CG_Parameter.dynamic_data[4+16] = CG_Protect.Motor_0.MosNTC_1.Temperature & 65535;//CG_ADC.Value_Inst[ ADC_Index_M1_BEMF_U ] & 65535;
        CG_Parameter.dynamic_data[5+16] = CG_Protect.Motor_0.MosNTC_2.Temperature & 65535;//CG_ADC.Value_Inst[ ADC_Index_M1_BEMF_V ] & 65535;
        CG_Parameter.dynamic_data[6+16] = CG_Protect.Motor_0.MosNTC_3.Temperature & 65535;//CG_ADC.Value_Inst[ ADC_Index_M1_BEMF_W ] & 65535;
        CG_Parameter.dynamic_data[7+16] = ( CG_PI.Channel[ PI_XH0 ].Pulse_Width / CPU_FREQ_IN_M ) & 65535;
        CG_Parameter.dynamic_data[8+16] = ( CG_PI.Channel[ PI_XH1 ].Pulse_Width / CPU_FREQ_IN_M ) & 65535;

        CG_Parameter.dynamic_data[9+16] = ( CG_MD.Main_Cost_Time / 100 ) & 65535;
        CG_Parameter.dynamic_data[10+16] = ( CG_MD.Event1ms_Cost_Time / 100 ) & 65535;
        CG_Parameter.dynamic_data[11+16] = 0;
        CG_Parameter.dynamic_data[12+16] = 0;
        CG_Parameter.dynamic_data[13+16] = ( CG_MD.ADC_Cost_Time / 100 ) & 65535;
        CG_Parameter.dynamic_data[14+16] = ( CG_MD.Test_time / 100 ) & 65535;
        CG_Parameter.dynamic_data[15+16] = CG_GPIO.OtherOutput_State_BITF & 65535;
    }

    update_MonitorData();

#if(!TEST_CAN_MASTER)
    //if( CG_MD.RS485_CAN_SEL_State == LOW ){ // Low = RS485, High = CAN
        output_StaLED();
    //}
#endif

    // IO_EXP Test
    /*
    if( CG_MD.HW_Ver == HW_VER_A ){
        ioExp_SetOutput( IO_EXP_HALL_PH, CG_MD.HallPH_State_M0 );
    }else{
        ioExp_SetOutput( IO_EXP_HALL_PH_M1, CG_MD.HallPH_State_M0 );
        ioExp_SetOutput( IO_EXP_HALL_PH_M2, CG_MD.HallPH_State_M1 );
    }

    ioExp_SetOutput( IO_EXP_YH0_SEL, CG_MD.YH0_SEL_State );
    ioExp_SetOutput( IO_EXP_YH1_SEL, CG_MD.YH1_SEL_State );

    ioExp_SetOutput( IO_EXP_485_CAN_SEL,  CG_MD.RS485_CAN_SEL_State );
    ioExp_SetOutput( IO_EXP_CAN_EN,  CG_MD.CAN_EN_State );
    //

	ioExp_SetOutput( IO_EXP_M1_LED, CG_BLDC_CTRL_M0.AlarmLED_State );
	ioExp_SetOutput( IO_EXP_M2_LED, CG_BLDC_CTRL_M1.AlarmLED_State );
	*/

    switch( CG_MD.RS485_CAN_SEL_State ){
    case RS485_CAN_SEL_ALL:
    default:
        CG_MD.STA_LED_State = CG_MD.STA_LED_State_RS485 | CG_MD.STA_LED_State_CAN;
        break;
    case RS485_CAN_SEL_RS485:
        CG_MD.STA_LED_State = CG_MD.STA_LED_State_RS485;
        break;
    case RS485_CAN_SEL_CAN:
        CG_MD.STA_LED_State = CG_MD.STA_LED_State_CAN;
        break;
    }

    otherGPIO_SetOutput( OTHER_OUTPUT_HALL_PH, CG_MD.HallPH_State_M0 );

    otherGPIO_SetOutput( OTHER_OUTPUT_DI_5V, CG_MD.DI_5V_State );
    otherGPIO_SetOutput( OTHER_OUTPUT_VCC12V_CTRL, CG_MD.Vcc12V_Ctrl_State );
    otherGPIO_SetOutput( OTHER_OUTPUT_ALARM_LED, CG_BLDC_CTRL_M0.AlarmLED_State );
    otherGPIO_SetOutput( OTHER_OUTPUT_STA_LED, CG_MD.STA_LED_State );
    otherGPIO_SetOutput( OTHER_OUTPUT_CAN_EN, CG_MD.CAN_EN_State );

	//ioExp_RoutineWork();
	call_1ms_PI();
	polling_ADC_1ms();

	//
    if( CG_GPIO.Out1_IsDependsOnBusV ){

        /*
        duty = calibration( CG_ADC.BusV,
                            CG_PI.PWM_RatingVoltage, CG_PI.PWM_Duty_Pa,
                            CG_PI.PWM_MinimumVoltage, CG_PI.PWM_Period );
                            */
        if( CG_ADC.BusV > 0 ){
            duty = ( CG_PI.PWM_MinimumVoltage * CG_PI.PWM_Period ) / CG_ADC.BusV;
        }else{
            duty = CG_PI.PWM_Period;
        }

        if( duty < CG_PI.PWM_Duty_Pa ){
            duty = CG_PI.PWM_Duty_Pa;
        }else if( duty >= CG_PI.PWM_Period - 1 ){
            duty = CG_PI.PWM_Period - 1;
        }

        CG_PI.PWM_Duty = duty;

        ECap7Regs.CAP4 = CG_PI.PWM_Period - CG_PI.PWM_Duty;

    }

    //

	//if(  CG_MD.RS485_CAN_SEL_State == HIGH ){ // Low = RS485, High = CAN
	    can_Call_1ms( (Struct_CAN*)&CG_CAN );
	//}

	//calibration_ADCOffset();

	if( CG_ADC.Shunt_I_Calibration_Flag == NO ){
	    if( CG_MD.Pwr_On_Cnt >= POWER_ON_TIME / 2 ){
            calibration_ShuntIOffset( CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_U_H ] * TORQUE_J06TOI04_GAIN,
                                      CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_V_H ] * TORQUE_J06TOI04_GAIN,
                                      CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_W_H ] * TORQUE_J06TOI04_GAIN,
                                      CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_U_OFFSET ],
                                      CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_V_OFFSET ],
                                      CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_W_OFFSET ] );
	    }
	}


	CG_ComProtocol_01.COM_IO_Yn_BITF[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = output_ShowInBITF( (Struct_IO_FUNC*) CG_BLDC_CTRL_M0.IO_Func_Ptr );
	//CG_ComProtocol_01.COM_IO_Yn_BITF[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = output_ShowInBITF( (Struct_IO_FUNC*) CG_BLDC_CTRL_M1.IO_Func_Ptr );

	call_1ms_OPMode();


    call_1ms_bldc_ctrl( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 );

    call_1ms_Protect ( (Struct_Driver_Pretect*)CG_BLDC_CTRL_M0.Protect_Ptr,
	                   (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0,
	                   CG_ADC.Value_Avg[ ADC_Index_MosOT_1 ],
	                   (uint32_t*)&CG_ComProtocol_01.FlagBITF );
    /*
    if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
        call_1ms_bldc_ctrl( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 );

        call_1ms_Protect ( (Struct_Driver_Pretect*)CG_BLDC_CTRL_M1.Protect_Ptr,
                       (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1,
                       CG_ADC.Value_Avg[ ADC_Index_MosOT_M1 ],
                       (uint32_t*)&CG_ComProtocol_01.FlagBITF );
    }*/

#if(TEST_FAKE_HALL_SENSOR)
    {
        int32_t speed_rpm_abs = CG_BLDC_CTRL_M0.OpMode_Ptr->Digit_Speed[0];
        if( speed_rpm_abs == 0 ){
            CG_MD.FakeHall_TimeConst = 1;
        }else{
            CG_MD.FakeHall_TimeConst = 10000 / ( speed_rpm_abs * CG_BLDC_CTRL_M0.Hall_Ptr->Pole_Factor );
        }
    }
#endif

	CG_MD.SysTick_BITF &= ~TICK_1MS;				// Clear 1 ms tick flag.

#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event1ms_TP_New = FREE_RUN_TIMER.TIM.all;
    CG_MD.Event1ms_Cost_Time = CG_MD.Event1ms_TP_Old - CG_MD.Event1ms_TP_New;
#endif

}


/*===========================================================================================
    Function Name    : call_10ms									(Struct_PulseInput*)&CG_PulseInput[0
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 10 ms time up event.
//==========================================================================================*/
static void call_10ms (void)
{
#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event10ms_TP_Old = FREE_RUN_TIMER.TIM.all;
#endif
    if( CG_MD.Pwr_On_Cnt < POWER_ON_TIME_MAX ){
        CG_MD.Pwr_On_Cnt++;
        if( CG_MD.Pwr_On_Cnt >= POWER_ON_TIME ){
            CG_MD.PowerRelay_Flag = YES;
#if(!TEST_DEBUG_JTAG_ENABLED)
            if( ( CG_MD.PwrOn_BITF >> PWM_ON_SET_Y0_BIT ) & 0x01 ){
                GPIO_SetupPinMux( 37, GPIO_MUX_CPU1, 0 );
                //GPIO_SetupPinMux( 35, GPIO_MUX_CPU1, 0 );
                CG_MD.PwrOn_BITF &= ~( 1UL << PWM_ON_SET_Y0_BIT );
            }
#endif
        }
    }

    if( CG_MD.PowerRelay_Flag ){
        CG_BLDC_CTRL_M0.IO_Func_Ptr->Output_State[ OUTPUT_RELAY_OUT ] = CG_BLDC_CTRL_M0.IO_Func_Ptr->ActState_of_Func[ OUTPUT_RELAY_OUT ];
    }else{
        CG_BLDC_CTRL_M0.IO_Func_Ptr->Output_State[ OUTPUT_RELAY_OUT ] = 1 - CG_BLDC_CTRL_M0.IO_Func_Ptr->ActState_of_Func[ OUTPUT_RELAY_OUT ];
    }

    OutputYn_action[ CG_BLDC_CTRL_M0.IO_Func_Ptr->Output_State[ OUTPUT_RELAY_OUT ] ]
                   [ CG_BLDC_CTRL_M0.IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_RELAY_OUT ] ]();


    if( ( CG_MD.PwrOn_BITF >> PWM_ON_HALL_INT_BIT ) & 0x01 ){
        if( CG_MD.Pwr_On_Cnt >= POWER_ON_TIME / 2 ){

            if( CG_BLDC_Drive_M0.Sensor_Type == SENSOR_TYPE_HALL ){
                hall_Prepare_M0();
            }

            /*
            if( CG_BLDC_Drive_M1.Sensor_Type == SENSOR_TYPE_HALL ){
                hall_Prepare_M1();
            }*/

            CG_MD.PwrOn_BITF &= ~( 1UL << PWM_ON_HALL_INT_BIT );
        }
    }


    if( ( CG_MD.PwrOn_BITF >> PWM_ON_CHECK_HALL_BIT ) & 0x01 ){
        if( CG_MD.Pwr_On_Cnt >= POWER_ON_TIME * 3 / 4 ){
            if( CG_BLDC_Drive_M0.Sensor_Type == SENSOR_TYPE_HALL ){
                hall_Ready_M0();
            }
            /*
            if( CG_BLDC_Drive_M1.Sensor_Type == SENSOR_TYPE_HALL ){
                hall_Ready_M1();
            }*/

            CG_MD.PwrOn_BITF &= ~( 1UL << PWM_ON_CHECK_HALL_BIT );
        }
    }


    if( CG_MD.Relay_On_Cnt < RELAY_ON_MAX_TIME ){
        if( CG_MD.PowerRelay_Flag == YES ){
            CG_MD.Relay_On_Cnt ++;
        }
	}

    manageEncoderPower();

    //
    if( CG_GPIO.Out1_Type == OUT_TYPE_PWM &&
        CG_GPIO.Out1_PwmTimer_Flag ){

        if( CG_GPIO.Out1_PwmTimerMs < CG_GPIO.Out1_PwmTimeMs_Pa ){
            CG_GPIO.Out1_PwmTimerMs += 10; // 10ms each time here
        }else{
            CG_GPIO.Out1_Pwm_Flag = YES;
        }
    }

    if( CG_GPIO.Out2_Type == OUT_TYPE_PWM &&
        CG_GPIO.Out2_PwmTimer_Flag ){

        if( CG_GPIO.Out2_PwmTimerMs < CG_GPIO.Out2_PwmTimeMs_Pa ){
            CG_GPIO.Out2_PwmTimerMs += 10; // 10ms each time here
        }else{
            CG_GPIO.Out2_Pwm_Flag = YES;
        }
    }

    //

	output_EnableOUT ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 );
	//output_EnableOUT ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 );

	polling_ADC_10ms();

	ServiceDog();

	calculate_NTCTemp( (Struct_NTC_Temperature *)&CG_Protect.Motor_0.MosNTC_1, CG_ADC.Value_Avg[ ADC_Index_MosOT_1 ] );
	calculate_NTCTemp( (Struct_NTC_Temperature *)&CG_Protect.Motor_0.MosNTC_2, CG_ADC.Value_Avg[ ADC_Index_MosOT_2 ] );
	calculate_NTCTemp( (Struct_NTC_Temperature *)&CG_Protect.Motor_0.MosNTC_3, CG_ADC.Value_Avg[ ADC_Index_MosOT_3 ] );

	CG_Protect.Motor_0.Alm_tick_Time_BITF |= (1UL << ALM_TICK_10MS_BIT );
	//CG_Protect.Motor_1.Alm_tick_Time_BITF |= (1UL << ALM_TICK_10MS_BIT );

#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event10ms_TP_New = FREE_RUN_TIMER.TIM.all;
    CG_MD.Event10ms_Cost_Time = CG_MD.Event10ms_TP_Old - CG_MD.Event10ms_TP_New;
#endif

	CG_MD.SysTick_BITF &= ~TICK_10MS;				// Clear 10 ms tick flag.

}


/*===========================================================================================
    Function Name    : call_PFms
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Power frequency time up event.
//==========================================================================================*/
static void call_PFms (void)
{


	CG_MD.SysTick_BITF &= ~TICK_PFMS;				// Clear PF ms tick flag.


}


/*===========================================================================================
    Function Name    : call_100ms
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 100 ms time up event.
//==========================================================================================*/
static void call_100ms (void)
{
    static int test_timer = 0;
#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event100ms_TP_Old = FREE_RUN_TIMER.TIM.all;
#endif
	//CG_MD.Test_cnt = WdRegs.WDCNTR.all;
	//ServiceDog();

	call_100ms_Protect( (Struct_Driver_Pretect*)&CG_Protect.Motor_0 );
	//call_100ms_Protect( (Struct_Driver_Pretect*)&CG_Protect.Motor_1 );

#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event100ms_TP_New = FREE_RUN_TIMER.TIM.all;
    CG_MD.Event100ms_Cost_Time = CG_MD.Event100ms_TP_Old - CG_MD.Event100ms_TP_New;
#endif
    if( ++test_timer >= 5 ){
        call_100ms_PI();
        test_timer = 0;
    }

	CG_MD.SysTick_BITF &= ~TICK_100MS;			// Clear 100 ms tick flag.

}


/*===========================================================================================
    Function Name    : call_1s
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 1 sec time up event.
//==========================================================================================*/
static void call_1s (void)
{
#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event1000ms_TP_Old = FREE_RUN_TIMER.TIM.all;
#endif
	com_Init_waiting_Check (2);
	//CG_MD.Test_cnt++;
	CG_MD.Start_Cnt++;

	/*
	if(  CG_MD.RS485_CAN_SEL_State == HIGH ){ // Low = RS485, High = CAN
        can_Routine( (Struct_CAN*)&CG_CAN );
    }*/

#if(TEST_CALCULATE_TIME_COST)
    CG_MD.Event1000ms_TP_New = FREE_RUN_TIMER.TIM.all;
    CG_MD.Event1000ms_Cost_Time = CG_MD.Event1000ms_TP_Old - CG_MD.Event1000ms_TP_New;
#endif

	CG_MD.SysTick_BITF &= ~TICK_1S;				// Clear 1 s tick flag.

}

/*===========================================================================================
    Function Name    : code_Ver_Setup
    Input            : 1. com : Communication ver
					   2. hweep : hardware eep ver
					   3. fweep : firmware eep ver
					   4. hwver : hardware info ver
					   5. fwver : firmare version coding ver.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the coding version.
//==========================================================================================*/
void code_Ver_Setup ( uint8_t com, uint8_t hweep, uint8_t fweep, uint8_t hwver, uint8_t fwver )
{
	CG_MD.Code_Ver[ CV_COM ] = com;
	CG_MD.Code_Ver[ CV_HWE ] = hweep;
	CG_MD.Code_Ver[ CV_FWE ] = fweep;
	CG_MD.Code_Ver[ CV_HWV ] = hwver;
	CG_MD.Code_Ver[ CV_FWV ] = fwver;
}

/*===========================================================================================
    Function Name    : hw_fw_Ver_Setup
    Input            : 1. *hw_ver : hardware version
					   2. *fw_ver : firmware version
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the hardware and firmware version.
//==========================================================================================*/
void hw_fw_Ver_Setup ( uint8_t *hw_ver, uint8_t *fw_ver )
{
	int i = 0;

	/*
	for ( i=0; i< PART_NUM_CHARS; i++ ) {
		CG_MD.PN[ i ] = hw_ver[ i ];
	}*/

	for ( i=0; i< FW_VER_CHARS; i++ ) {
		CG_MD.FW_Ver[ i ] = fw_ver[ i ];
	}

}

/*===========================================================================================
    Function Name    : motor_sensor_Setup
    Input            : Null
    Return           : Null
    Programmer       :Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void motor_sensor_Setup ( void )
{
#if(1)
    CG_MD.HW_Ver = CG_HWEEP.HW_Ver[0];
    if( CG_MD.HW_Ver == 0 || CG_MD.HW_Ver == 255 ){
        CG_MD.HW_Ver = HW_VER_A;
    }

    /*
    CG_MD.Driver_Mode = DRIVER_MODE;
    if( CG_MD.Driver_Mode >= PA_DRIVER_MODE_NUM ){
        CG_MD.Driver_Mode = PA_DRIVER_MODE_2SMALL_MOTOR;
    }*/

    /*
    if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
        CG_MD.Driver_Num = 2;
    }else{
        CG_MD.Driver_Num = 1;
    }*/
    CG_MD.Driver_Num = 1;

    // Motor Type
    CG_BLDC_Drive_M0.Motor_Type = MOTOR_TYPE_MOTOR_0;
	if( CG_BLDC_Drive_M0.Motor_Type >= MOTOR_NUM ){
	    CG_BLDC_Drive_M0.Motor_Type = MOTOR_BLDC;
	}

	/*
	CG_BLDC_Drive_M1.Motor_Type = MOTOR_TYPE_MOTOR_1;
    if( CG_BLDC_Drive_M1.Motor_Type >= MOTOR_NUM ){
        CG_BLDC_Drive_M1.Motor_Type = MOTOR_BLDC;
    }*/
	//

	CG_MD.Motor_Sensor = ( ( DRIVE_METHOD >> BITF_SENSOR_0 ) & 0x0f );

	if( CG_MD.Motor_Sensor >= SENSOR_TYPE_NUM ){
		CG_MD.Motor_Sensor = SENSOR_TYPE_HALL;
	}

    CG_BLDC_Drive_M0.Sensor_Type = CG_MD.Motor_Sensor;
    //CG_BLDC_Drive_M1.Sensor_Type = CG_MD.Motor_Sensor;

    if( CG_MD.Motor_Sensor == SENSOR_TYPE_ENCODER ){

        if( ENCODER_TYPE_MOTOR_0 == PA_SENSOR_HALL ){
            CG_BLDC_Drive_M0.Sensor_Type = SENSOR_TYPE_HALL;
        }

        /*
        if( ENCODER_TYPE_MOTOR_1 == PA_SENSOR_HALL ){
            CG_BLDC_Drive_M1.Sensor_Type = SENSOR_TYPE_HALL;
        }*/
    }

    //

    if( CG_BLDC_Drive_M0.Sensor_Type == SENSOR_TYPE_HALL ){
        if( DRIVE_TYPE_MOTOR_0 == 0 ){
            CG_BLDC_Drive_M0.Mode = BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE;
        }else{
            CG_BLDC_Drive_M0.Mode = BLDCDRIVE_FOC;
        }
    }else{
        CG_BLDC_Drive_M0.Mode = BLDCDRIVE_FOC;
    }

    /*
    if( CG_BLDC_Drive_M1.Sensor_Type == SENSOR_TYPE_HALL ){
        if( DRIVE_TYPE_MOTOR_1 == 0 ){
            CG_BLDC_Drive_M1.Mode = BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE;
        }else{
            CG_BLDC_Drive_M1.Mode = BLDCDRIVE_FOC;
        }
    }else{
        CG_BLDC_Drive_M1.Mode = BLDCDRIVE_FOC;
    }*/


	//
    if( CG_BLDC_Drive_M0.Motor_Type == MOTOR_BDC ){
        CG_BLDC_Drive_M0.Sensor_Type = SENSOR_TYPE_HALL;
        CG_BLDC_Drive_M0.Mode = BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE;
    }

    /*
    if( CG_BLDC_Drive_M1.Motor_Type == MOTOR_BDC ){
        CG_BLDC_Drive_M1.Sensor_Type = SENSOR_TYPE_HALL;
        CG_BLDC_Drive_M1.Mode = BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE;
    }*/

	//
	//CG_MD.Drive_Method = BLDCDRIVE_FOC;

	CG_BLDC_CTRL_M0.Dir_Def = DIRECTION_DEFINE_MOTOR_0;
	CG_BLDC_CTRL_M0.Hall_Ptr->Dir_Def = CG_BLDC_CTRL_M0.Dir_Def;

	//CG_BLDC_CTRL_M1.Dir_Def = DIRECTION_DEFINE_MOTOR_1;
	//CG_BLDC_CTRL_M1.Hall_Ptr->Dir_Def = CG_BLDC_CTRL_M1.Dir_Def;

	//
    CG_BLDC_Drive_M0.GateDriver_Type = ( DRIVE_METHOD >> BITF_GATEDRIVER_0 ) & 0x0F;
    if( CG_BLDC_Drive_M0.GateDriver_Type >= GATEDRIVER_TYPE_NUM ){
        CG_BLDC_Drive_M0.GateDriver_Type = GATEDRIVER_TYPE_NORMAL;
    }
    //CG_BLDC_Drive_M1.GateDriver_Type = CG_BLDC_Drive_M0.GateDriver_Type;
    //

#endif

}


/************************** MAIN FUNCTIONS ************************************/
//==============================================================================
//  Main Program
//==============================================================================
void main(void)
{
	//uint8_t data[32];
	//
	// Initialize device clock and peripherals
	//
	InitSysCtrl();

	//
	// Initialize GPIO
	//
	InitGpio();

	//
	// Disable CPU interrupts
	//
	DINT;

	//
	// Initialize the PIE control registers to their default state.
	// The default state is all PIE interrupts disabled and flags
	// are cleared.
	//
	InitPieCtrl();

	//
	// Disable CPU interrupts and clear all CPU interrupt flags
	//
	IER = 0x0000;
	IFR = 0x0000;

	//
	// Initialize the PIE vector table with pointers to the shell Interrupt
	// Service Routines (ISR)
	//
	InitPieVectTable();


	SysTick_Set( 1000 );	// Set systick as 1ms.


	FREE_RUN_TIMER_START;

	//
	setupInitial_GPIO();

#if(1)

	setup_DACA( ADC_MAX_VALUE );
	setup_DACB( ADC_MIN_VALUE );
	setupInitial_WDT();
	setupInitial_I2C();



	variableInitial_BLDC( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 );
	//variableInitial_BLDC( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 );

	CG_BLDC_CTRL_M0.MultiDrive_Src = SRC_MULTI_DRIVE_M0;
	CG_BLDC_CTRL_M0.ADC_Ptr = (Struct_Motor_Analog*) &CG_ADC.Motor_0;
	CG_BLDC_CTRL_M0.Hall_Ptr = (Struct_HallSensor*) &CG_Hall_M0;
	CG_BLDC_CTRL_M0.Encoder_Ptr = (Struct_Basic_Encoder*) &CG_Encoder.Motor_0;
	CG_BLDC_CTRL_M0.Drive_Ptr = (Struct_BLDC_Drive*) &CG_BLDC_Drive_M0;
	CG_BLDC_CTRL_M0.IO_Func_Ptr = (Struct_IO_FUNC*) &CG_IO_Func_M0;
	CG_BLDC_CTRL_M0.Move_Ptr = ( Struct_Move *)& CG_Move_M0;
	CG_BLDC_CTRL_M0.Protect_Ptr = ( Struct_Driver_Pretect *)&CG_Protect.Motor_0;
	CG_BLDC_CTRL_M0.OpMode_Ptr = ( Struct_Basic_OPMode *)&CG_OPMode.Motor_0;
	CG_BLDC_CTRL_M0.SPK_Ptr = ( Struct_SPK *)&CG_SPK_M0;
	CG_BLDC_CTRL_M0.PI_Ptr = (Struct_PI_CMD*)&CG_PI.Motor_0;

	/*
	CG_BLDC_CTRL_M1.MultiDrive_Src = SRC_MULTI_DRIVE_M1;
	CG_BLDC_CTRL_M1.ADC_Ptr = (Struct_Motor_Analog*) &CG_ADC.Motor_1;
    CG_BLDC_CTRL_M1.Hall_Ptr = (Struct_HallSensor*) &CG_Hall_M1;
    CG_BLDC_CTRL_M1.Encoder_Ptr = (Struct_Basic_Encoder*) &CG_Encoder.Motor_1;
    CG_BLDC_CTRL_M1.Drive_Ptr = (Struct_BLDC_Drive*) &CG_BLDC_Drive_M1;
    CG_BLDC_CTRL_M1.IO_Func_Ptr = (Struct_IO_FUNC*) &CG_IO_Func_M1;
    CG_BLDC_CTRL_M1.Move_Ptr = ( Struct_Move *)& CG_Move_M1;
    CG_BLDC_CTRL_M1.Protect_Ptr = ( Struct_Driver_Pretect *)&CG_Protect.Motor_1;
    CG_BLDC_CTRL_M1.OpMode_Ptr = ( Struct_Basic_OPMode *)&CG_OPMode.Motor_1;
    CG_BLDC_CTRL_M1.SPK_Ptr = ( Struct_SPK *)&CG_SPK_M1;
    CG_BLDC_CTRL_M1.PI_Ptr = (Struct_PI_CMD*)&CG_PI.Motor_1;
    */

	variableInitial_IO();
	variableInitial_IO_Func( (Struct_IO_FUNC*)&CG_IO_Func_M0 );
	//variableInitial_IO_Func( (Struct_IO_FUNC*)&CG_IO_Func_M1 );

	variableInitial_OPMode();
	variableInitial_Protect();
	variableInitial_HallSensor ( (Struct_HallSensor*) &CG_Hall_M0 );
	//variableInitial_HallSensor ( (Struct_HallSensor*) &CG_Hall_M1 );

	//
	// Enable global Interrupts and higher priority real-time debug events
	//
	EINT;
	ERTM;


	variableInitial_Parameter();

	readTotalHWEEP();
	CG_I2C.is_OK_Flag &= readFWEEP();
	//setupInitial_IO_Expander();

	motor_sensor_Setup ();

	//setupYOutByVersion();

	gpioXHFilter_Setup();

	//
	/*
	if( CG_MD.HW_Ver == HW_VER_A ){
        CG_MD.Comm_ID = CG_Parameter.RAM_data[ PARAMETER_COM ][  COM_PA_485_CAN_ID ];
    }else{
        readData_IOExp( IO_EXPANDER_ADDRESS, IO_EXP_REG_INPUT_0, 2 );
        while( CG_I2C.MasterState != I2C_READY );
        CG_IO_Expander.Xn_State_BITF = ( ( CG_I2C.R_Data[1] << 8 ) | CG_I2C.R_Data[0] ) ^ CG_IO_Expander.XnNormState_BITF;

        CG_MD.Comm_ID = ( CG_IO_Expander.Xn_State_BITF >> IO_EXP_COMM_ID_SW0 ) & 0x03;
        CG_MD.Comm_ID = CG_MD.Comm_ID * 2 + 1;

        setup_DACB( 0 );
    }
    */
	CG_MD.Comm_ID = CG_Parameter.RAM_data[ PARAMETER_COM ][  COM_PA_485_CAN_ID ];
	//


	ServiceDog();

	//
	DINT;
	//

	// firmware, hardware version setup
	//hw_fw_Ver_Setup	( (uint8_t*)&CG_MD.PN, (uint8_t*)CONST_FW_VERSION );
    hw_fw_Ver_Setup	( (uint8_t*)&CG_MD.PN, CONST_FW_VERSION );
	code_Ver_Setup ( COM_CODE_VER, CG_MD.Code_Ver[ CV_HWE ], FWEEP_CODE_VER, CG_MD.Code_Ver[ CV_HWV ], FW_CODE_VER );	// Code ver setup.

	variableInitial_COM_Protocol( (int32_t*)&CG_Protect.Alarm_His_EEP, (int32_t*)&CG_Protect.Warning_His_RAM );
	setupInitial_UART( RS232_BAUDRATE );

#if(TEST_CAN_MASTER)
    CG_MD.Comm_ID = 1;

    CG_MD.RS485_CAN_SEL_State = HIGH;    // Low = RS485, High = CAN
    CG_MD.CAN_EN_State = HIGH;
    setupInitial_CAN( (Struct_CAN *)&CG_CAN, CG_MD.Comm_ID, CAN_BAUD_RATE_1M );

#else

    /*
    if( CG_Parameter.EEP_data[ PARAMETER_COM ][ COM_PA_RS485_CAN_SELECT ] != RS485_CAN_SELECT_CAN ){
	    setupInitial_UART485( RS232_BAUDRATE );	// initial
	}else{
	    CG_MD.RS485_CAN_SEL_State = HIGH;    // Low = RS485, High = CAN
	    CG_MD.CAN_EN_State = HIGH;
	    setupInitial_CAN( (Struct_CAN *)&CG_CAN, CG_MD.Comm_ID, CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_CAN_BAUDRATE ] );
	}*/

    setupInitial_UART485( RS232_BAUDRATE ); // initial
    CG_MD.CAN_EN_State = HIGH;
    setupInitial_CAN( (Struct_CAN *)&CG_CAN, CG_MD.Comm_ID, CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CAN_BAUDRATE ] );

    //setupInitial_UART485( RS232_BAUDRATE ); // initial
    //setupInitial_CAN( (Struct_CAN *)&CG_CAN, CG_MD.Comm_ID, CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_CAN_BAUDRATE ] );

#endif

	variableInitial_ModBus_Slave( (Struct_Modbus_Slave*)&CG_Modbus_Slave, 		RS232_ID, CG_UART.modbus_mode );
	variableInitial_ModBus_Slave( (Struct_Modbus_Slave*)&CG_Modbus_Slave_485, 	 CG_UART485.ID, CG_UART485.modbus_mode );

	// ==

	setupInitial_BLDCDrive( CG_MD.Drive_Method, DRIVE_FREQUENCE, DRIVE_DEAD_TIME ); // freq & dead time
	setupInitial_SPK();

	setupInitial_ADC( CG_HWEEP.HW_Info[ HWEEP_IDX_HWP ] * TORQUE_J06TOI04_GAIN,
	                  CG_HWEEP.HW_Info[ HWEEP_IDX_FWP ] * TORQUE_J06TOI04_GAIN,
	                  CG_Parameter.EEP_data[ PARAMETER_GENERAL ][ GENERAL_POWER_PERCENTAGE ],
	                  CG_HWEEP.HW_Info[ HWEEP_IDX_PGA_INDEX ],
	                  CG_HWEEP.HW_Info[ HWEEP_IDX_CTRIP_PRESCALE ] );

	//

	hweep_WatchUpdate ( CG_Parameter.EEP_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] );

	/*NoteToGear For Special Modbus FC*/
	io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_STOP_MODE_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_STOP_MODE );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_START_STOP_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_START_STOP );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_CW_CCW_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CW_CCW );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_STOP_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_STOP );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_IMR_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_IMR );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_MR_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_MR );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_MA_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_MA );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_FREE_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_FREE );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_EBRAKE_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_EBRAKE );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_KEYSWITCH_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_KEY_SWITCH );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_CMR_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CMR );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M0, SRC_MULTI_DRIVE_CMA_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CMA );

    /*
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_STOP_MODE_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_STOP_MODE );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_START_STOP_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_START_STOP );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_CW_CCW_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CW_CCW );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_STOP_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_STOP );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_IMR_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_IMR );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_MR_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_MR );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_MA_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_MA );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_FREE_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_FREE );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_EBRAKE_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_EBRAKE );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_KEYSWITCH_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_KEY_SWITCH );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_CMR_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CMR );
    io_ValSet_DIn_Func( SRC_MULTI_DRIVE_M1, SRC_MULTI_DRIVE_CMA_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CMA );
    */

    //
    io_ValSet_DIn_Func( SRC_OTHERS, SRC_OTHERS_M0_STOP_BIT, CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_STOP );
    //io_ValSet_DIn_Func( SRC_OTHERS, SRC_OTHERS_M1_STOP_BIT, CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_STOP );
    //

	protect_EEP_Error ( ( Struct_Driver_Pretect* )&CG_Protect.Motor_0, CG_I2C.is_OK_Flag );
	//protect_EEP_Error ( ( Struct_Driver_Pretect* )&CG_Protect.Motor_1, CG_I2C.is_OK_Flag );

#if(1)
	if( CG_BLDC_Drive_M0.Sensor_Type == SENSOR_TYPE_HALL ){
	    CG_MD.HallPH_State_M0 = HIGH;
	    initHallSensor_M0();
	}else{
	    CG_MD.HallPH_State_M0 = LOW;
	    setupInitial_Encoder_M0( (Struct_Basic_Encoder*) &CG_Encoder.Motor_0,
	                             ENCODER_TYPE_MOTOR_0,
	                             ENCODER_RESOLUTION_MOTOR_0,
	                             POLAR_FACTOR_MOTOR_0,
	                             DIRECTION_DEFINE_MOTOR_0,
	                             HALL_SEQUENCE_MOTOR_0 );

	}

	/*
	if( CG_BLDC_Drive_M1.Sensor_Type == SENSOR_TYPE_HALL ){
        CG_MD.HallPH_State_M1 = HIGH;
        initHallSensor_M1();
    }else{
        CG_MD.HallPH_State_M1 = LOW;
        setupInitial_Encoder_M1( (Struct_Basic_Encoder*) &CG_Encoder.Motor_1,
                                 ENCODER_TYPE_MOTOR_1,
                                 ENCODER_RESOLUTION_MOTOR_1,
                                 POLAR_FACTOR_MOTOR_1,
                                 DIRECTION_DEFINE_MOTOR_1,
                                 HALL_SEQUENCE_MOTOR_1 );

    }*/

	setupInitial_Capture( CG_BLDC_Drive_M0.Sensor_Type );

#endif

	EINT;   // Enable Global interrupt INTM
	//ERTM;   // Enable Global realtime interrupt DBGM

	updateSpeceilParameter(); // 2nd time

#endif // Test

	// ================== Main Loop ==================
   	while(1){



   		//CG_MD.Test_tp1			= FREE_RUN_TIMER.TIM.all;
#if(TEST_CALCULATE_TIME_COST)
        CG_MD.Main_TP_Old = FREE_RUN_TIMER.TIM.all;
#endif

   		if (CG_MD.SysTick_BITF & TICK_1MS) 				{call_1ms();}
		if (CG_MD.SysTick_BITF & TICK_10MS) 			{call_10ms();}
		if (CG_MD.SysTick_BITF & TICK_100MS) 			{call_100ms();}
		if (CG_MD.SysTick_BITF & TICK_PFMS) 			{call_PFms();}
		if (CG_MD.SysTick_BITF & TICK_1S) 				{call_1s();}

		polling_GPIO( (Struct_GPIO*)&CG_GPIO );

#if(1)

		io_ValSet_DI_XN( SRC_IO , CG_GPIO.Xn_State_BITF );
		call_MainLoop_PI();

		polling_ADC_MainLoop();
		management_RGN_DAC();
		//management_BR_ALL();

		checkRTUframe_232();
		checkRTUframe_485();



		modbus_slave_Handler [ CG_UART.modbus_mode ][ CG_Modbus_Slave.State ] ( (uint8_t*)&CG_UART.ReceiveFlag,
																				(uint8_t*)&CG_UART.R_data_buffer,
																				CG_UART.R_data_number,
																				(uint8_t*)&CG_UART.T_data_buffer,
																				(uint8_t*)&CG_UART.T_data_length,
																				(uint8_t*)&CG_UART.request_to_send_data_flag,
																				(uint8_t*)&CG_UART.T_data_pointer,
																				(Struct_Modbus_Slave*)&CG_Modbus_Slave
																			  );

		CG_I2C.is_OK_Flag &= com_Protocol_routine( (Struct_Modbus_Slave*)&CG_Modbus_Slave, (uint32_t*)&CG_IO.DI_XN_BITF[ SRC_UART ],
		                                           LOW, (uint8_t*)&CG_UART.R_data_buffer );
													//CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_RUN ] ][ CMD_RUN ], (uint8_t*)&CG_UART.R_data_buffer );

		/*
		if(  CG_MD.RS485_CAN_SEL_State == HIGH ){ // Low = RS485, High = CAN
            can_Routine( (Struct_CAN*)&CG_CAN );
            if( CG_CAN.CANOpen.Is_Reset_COM ){
                CG_CAN.CANOpen.Is_Reset_COM = NO;
                setupInitial_CAN( (Struct_CAN *)&CG_CAN, CG_MD.Comm_ID, CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_CAN_BAUDRATE ] );
            }
        }else{
            modbus_slave_Handler [ CG_UART485.modbus_mode ][ CG_Modbus_Slave_485.State ] ( (uint8_t*)&CG_UART485.ReceiveFlag,
																					   (uint8_t*)&CG_UART485.R_data_buffer,
																					   CG_UART485.R_data_number,
																					   (uint8_t*)&CG_UART485.T_data_buffer,
																					   (uint8_t*)&CG_UART485.T_data_length,
																					   (uint8_t*)&CG_UART485.request_to_send_data_flag,
																					   (uint8_t*)&CG_UART485.T_data_pointer,
																					   (Struct_Modbus_Slave*)&CG_Modbus_Slave_485
																					);

            CG_I2C.is_OK_Flag &= com_Protocol_routine( (Struct_Modbus_Slave*)&CG_Modbus_Slave_485, (uint32_t*)&CG_IO.DI_XN_BITF[ SRC_UART ],
		                                           LOW, (uint8_t*)&CG_UART485.R_data_buffer );
													//CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_RUN ] ][ CMD_RUN ], (uint8_t*)&CG_UART485.R_data_buffer );

        }*/

		modbus_slave_Handler [ CG_UART485.modbus_mode ][ CG_Modbus_Slave_485.State ] ( (uint8_t*)&CG_UART485.ReceiveFlag,
                                                                                   (uint8_t*)&CG_UART485.R_data_buffer,
                                                                                   CG_UART485.R_data_number,
                                                                                   (uint8_t*)&CG_UART485.T_data_buffer,
                                                                                   (uint8_t*)&CG_UART485.T_data_length,
                                                                                   (uint8_t*)&CG_UART485.request_to_send_data_flag,
                                                                                   (uint8_t*)&CG_UART485.T_data_pointer,
                                                                                   (Struct_Modbus_Slave*)&CG_Modbus_Slave_485
                                                                                );

        CG_I2C.is_OK_Flag &= com_Protocol_routine( (Struct_Modbus_Slave*)&CG_Modbus_Slave_485, (uint32_t*)&CG_IO.DI_XN_BITF[ SRC_UART ],
                                               LOW, (uint8_t*)&CG_UART485.R_data_buffer );
                                                //CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_RUN ] ][ CMD_RUN ], (uint8_t*)&CG_UART485.R_data_buffer );


		can_Routine( (Struct_CAN*)&CG_CAN );
        if( CG_CAN.CANOpen.Is_Reset_COM ){
            CG_CAN.CANOpen.Is_Reset_COM = NO;
            setupInitial_CAN( (Struct_CAN *)&CG_CAN, CG_MD.Comm_ID, CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CAN_BAUDRATE ] );
        }

		checkUARTSend();

		detect_HWOCP();

		//stop_command_determine();
		vrFunc_Advance();

		ioFunc_Polling_routine ( (Struct_IO*)&CG_IO, (Struct_IO_FUNC*)&CG_IO_Func_M0 );

		if( CG_BLDC_Drive_M0.Sensor_Type == SENSOR_TYPE_HALL ){
		    hall_Speed_Calculations( ( Struct_HallSensor* ) &CG_Hall_M0 );
		}else{
		    encoderGetGuessPos( ( struct EQEP_REGS * )&EQep1Regs, ( Struct_Basic_Encoder*) &CG_Encoder.Motor_0, ENCODER_SIGNAL_M0, MOTOR_S2S1S0_SIGNAL_M0 );
		    encoder_CalculateSpeed( ( Struct_Basic_Encoder*) &CG_Encoder.Motor_0 );
		}

		// M0
		inputXn_action[ FUNC_EBRAKE ]  											( (Struct_IO_FUNC*)&CG_IO_Func_M0, CG_BLDC_CTRL_M0.Motor_State, 0 );
		inputXn_action[ FUNC_FREE ]  											( (Struct_IO_FUNC*)&CG_IO_Func_M0, CG_BLDC_CTRL_M0.Motor_State, 0 );
		inputXn_action[ FUNC_STOP ]  											( (Struct_IO_FUNC*)&CG_IO_Func_M0, CG_BLDC_CTRL_M0.Motor_State, 0 );

		inputXn_action[ const_SC_CC_SEL[ CG_IO_Func_M0.SC_CC_Mode ][FUNC_START_STOP] ]  ( (Struct_IO_FUNC*)&CG_IO_Func_M0, CG_BLDC_CTRL_M0.Motor_State, (int32_t)(CG_BLDC_CTRL_M0.Inverse_Mode) );
		inputXn_action[ const_SC_CC_SEL[ CG_IO_Func_M0.SC_CC_Mode ][FUNC_CW_CCW] ] 	   	( (Struct_IO_FUNC*)&CG_IO_Func_M0, CG_BLDC_CTRL_M0.Motor_State, (int32_t)(CG_BLDC_CTRL_M0.Inverse_Mode) );

		protect_IO_Type_fault_handler( (Struct_Driver_Pretect*)&CG_Protect.Motor_0, CG_IO_Func_M0.IOF_STAT_BITF[ SRC_ALL ] );

		protect_EEP_Error ( ( Struct_Driver_Pretect* )&CG_Protect.Motor_0, CG_I2C.is_OK_Flag );

		motor_State_Handler[ CG_BLDC_CTRL_M0.Motor_State ]( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 );

		call_MainLoop_bldc_ctrl( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 );

		/*
		if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){

            if( CG_BLDC_Drive_M1.Sensor_Type == SENSOR_TYPE_HALL ){
                hall_Speed_Calculations( ( Struct_HallSensor* ) &CG_Hall_M1 );
            }else{
                encoderGetGuessPos( ( struct EQEP_REGS * )&EQep2Regs, ( Struct_Basic_Encoder*) &CG_Encoder.Motor_1, ENCODER_SIGNAL_M1, MOTOR_S2S1S0_SIGNAL_M1 );
                encoder_CalculateSpeed( ( Struct_Basic_Encoder*) &CG_Encoder.Motor_1 );
            }

            // M1
            inputXn_action[ FUNC_EBRAKE ]                                           ( (Struct_IO_FUNC*)&CG_IO_Func_M1, CG_BLDC_CTRL_M1.Motor_State, 0 );
            inputXn_action[ FUNC_FREE ]                                             ( (Struct_IO_FUNC*)&CG_IO_Func_M1, CG_BLDC_CTRL_M1.Motor_State, 0 );
            inputXn_action[ FUNC_STOP ]                                             ( (Struct_IO_FUNC*)&CG_IO_Func_M1, CG_BLDC_CTRL_M1.Motor_State, 0 );

            inputXn_action[ const_SC_CC_SEL[ CG_IO_Func_M1.SC_CC_Mode ][FUNC_START_STOP] ]  ( (Struct_IO_FUNC*)&CG_IO_Func_M1, CG_BLDC_CTRL_M1.Motor_State, (int32_t)(CG_BLDC_CTRL_M1.Inverse_Mode) );
            inputXn_action[ const_SC_CC_SEL[ CG_IO_Func_M1.SC_CC_Mode ][FUNC_CW_CCW] ]      ( (Struct_IO_FUNC*)&CG_IO_Func_M1, CG_BLDC_CTRL_M1.Motor_State, (int32_t)(CG_BLDC_CTRL_M1.Inverse_Mode) );

            protect_IO_Type_fault_handler( (Struct_Driver_Pretect*)&CG_Protect.Motor_1, CG_IO_Func_M1.IOF_STAT_BITF[ SRC_ALL ] );

            protect_EEP_Error ( ( Struct_Driver_Pretect* )&CG_Protect.Motor_1, CG_I2C.is_OK_Flag );

            motor_State_Handler[ CG_BLDC_CTRL_M1.Motor_State ]( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 );

		    call_MainLoop_bldc_ctrl( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 );

		}*/

		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_PA_CHANGE_REALTIME_REQ_BIT );
		//CG_ComProtocol_01.FlagBITF |= ( ( CG_BLDC_CTRL_M0.Running_Flag | CG_BLDC_CTRL_M1.Running_Flag ) << COM_PA_CHANGE_REALTIME_REQ_BIT );
		CG_ComProtocol_01.FlagBITF |= ( ( CG_BLDC_CTRL_M0.Running_Flag ) << COM_PA_CHANGE_REALTIME_REQ_BIT );

		/*
		CG_MD.test_i1 = 50LL * 10000LL * 10000LL;
		CG_MD.test_i2 = -1;
		CG_MD.Test_tp1          = CURRENT_TIMER_CNT;
		CG_MD.test_i3 = CG_MD.test_i1 / 2000;
		CG_MD.Test_tp2			= CURRENT_TIMER_CNT;
		CG_MD.Test_time 		= CG_MD.Test_tp1 - CG_MD.Test_tp2; // 12000 ~ 20000 clk ticks*/

#if(TEST_CALCULATE_TIME_COST)
        CG_MD.Main_TP_New = FREE_RUN_TIMER.TIM.all;
        CG_MD.Main_Cost_Time = CG_MD.Main_TP_Old - CG_MD.Main_TP_New;
#endif
#endif // Test

   	}

}




/************************** <END OF FILE> *****************************************/

