/*
 * C2000_BLDC_Drive.h
 *
 *  Created on: 2015/7/20
 *      Author: Chaim.Chen
 */
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef C2000_BLDC_DRIVE_H_
#define C2000_BLDC_DRIVE_H_

#include "IncludeFiles.h"
#include "FOC.h"

#define HWCR_STATE_M0          PWM_M0_U.TZFLG.bit.DCAEVT2
#define HWCR_CLEAR_M0          ( PWM_M0_U.TZCLR.bit.DCAEVT2 = 1 )

//#define HWCR_STATE_M1          PWM_M1_U.TZFLG.bit.DCAEVT2
//#define HWCR_CLEAR_M1          ( PWM_M1_U.TZCLR.bit.DCAEVT2 = 1 )

/*===========================================================================================
    Hall State to UVW output table.
//==========================================================================================*/
extern const uint8_t Const_Hall_TableA[2][8];
extern const uint8_t Const_Hall_TableB[2][8];

extern const uint8_t Const_Hall_TableA_I01B[2][8];
extern const uint8_t Const_Hall_TableB_I01B[2][8];

extern const uint8_t Const_ShuntI_Bottom[ 6 ];

#define BOOTSTRAP_CNT			4
#define SMALL_BOOTSTRAP_LOOP	1000
#define SMALL_DELAY				200

enum{
	BLDCDRIVE_6STEP_COMMUTATION_SLOW_DECAY				= 0,
	BLDCDRIVE_6STEP_COMMUTATION_FAST_DECAY				= 1,
	BLDCDRIVE_6STEP_COMMUTATION_ABS_VOLTAGE				= 2,
	BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE			= 3,
	BLDCDRIVE_FOC										= 4,
	BLDCDRIVE_6STEP_COMMUTATION_SLOW_DECAY_PWM_ON		= 5,
	BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE_PWM_ON		= 6,
	BLDCDRIVE_NUM										= 7
};

#define FULL_DUTY	1000

// Set as output
#define SET_AS_OUTPUT_M0_UT				GpioCtrlRegs.GPADIR.bit.GPIO0 = 1
#define SET_AS_OUTPUT_M0_VT				GpioCtrlRegs.GPADIR.bit.GPIO2 = 1
#define SET_AS_OUTPUT_M0_WT				GpioCtrlRegs.GPADIR.bit.GPIO4 = 1

#define SET_AS_OUTPUT_M0_UB				GpioCtrlRegs.GPADIR.bit.GPIO1 = 1
#define SET_AS_OUTPUT_M0_VB				GpioCtrlRegs.GPADIR.bit.GPIO3 = 1
#define SET_AS_OUTPUT_M0_WB				GpioCtrlRegs.GPADIR.bit.GPIO5 = 1

/*
#define SET_AS_OUTPUT_M1_UT             GpioCtrlRegs.GPADIR.bit.GPIO6 = 1
#define SET_AS_OUTPUT_M1_VT             GpioCtrlRegs.GPADIR.bit.GPIO8 = 1
#define SET_AS_OUTPUT_M1_WT             GpioCtrlRegs.GPADIR.bit.GPIO10 = 1

#define SET_AS_OUTPUT_M1_UB             GpioCtrlRegs.GPADIR.bit.GPIO7 = 1
#define SET_AS_OUTPUT_M1_VB             GpioCtrlRegs.GPADIR.bit.GPIO9 = 1
#define SET_AS_OUTPUT_M1_WB             GpioCtrlRegs.GPADIR.bit.GPIO11 = 1
*/

// Pull Low

#define PULL_LOW_M0_UT					( GpioCtrlRegs.GPAPUD.bit.GPIO0 = 1 )
#define PULL_LOW_M0_VT					( GpioCtrlRegs.GPAPUD.bit.GPIO2 = 1 )
#define PULL_LOW_M0_WT					( GpioCtrlRegs.GPAPUD.bit.GPIO4 = 1 )

#define PULL_LOW_M0_UB					( GpioCtrlRegs.GPAPUD.bit.GPIO1 = 1 )
#define PULL_LOW_M0_VB					( GpioCtrlRegs.GPAPUD.bit.GPIO3 = 1 )
#define PULL_LOW_M0_WB					( GpioCtrlRegs.GPAPUD.bit.GPIO5 = 1 )

/*
#define PULL_LOW_M1_UT                  ( GpioCtrlRegs.GPAPUD.bit.GPIO6 = 1 )
#define PULL_LOW_M1_VT                  ( GpioCtrlRegs.GPAPUD.bit.GPIO8 = 1 )
#define PULL_LOW_M1_WT                  ( GpioCtrlRegs.GPAPUD.bit.GPIO10 = 1 )

#define PULL_LOW_M1_UB                  ( GpioCtrlRegs.GPAPUD.bit.GPIO7 = 1 )
#define PULL_LOW_M1_VB                  ( GpioCtrlRegs.GPAPUD.bit.GPIO9 = 1 )
#define PULL_LOW_M1_WB                  ( GpioCtrlRegs.GPAPUD.bit.GPIO11 = 1 )
*/


// PWM
#define PWM_M0_U						EPwm1Regs
#define PWM_M0_V						EPwm2Regs
#define PWM_M0_W						EPwm3Regs

/*
#define PWM_M1_U                        EPwm4Regs
#define PWM_M1_V                        EPwm5Regs
#define PWM_M1_W                        EPwm6Regs
*/

#define PWM_M0_UT_ON					GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1
#define PWM_M0_VT_ON					GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1
#define PWM_M0_WT_ON					GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1

#define PWM_M0_UB_ON					GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1
#define PWM_M0_VB_ON					GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1
#define PWM_M0_WB_ON					GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1

#define PWM_M0_UT_OFF					GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 0
#define PWM_M0_VT_OFF					GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 0
#define PWM_M0_WT_OFF					GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 0

#define PWM_M0_UB_OFF					GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 0
#define PWM_M0_VB_OFF					GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 0
#define PWM_M0_WB_OFF					GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 0

/*
#define PWM_M1_UT_ON                    GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 1
#define PWM_M1_VT_ON                    GpioCtrlRegs.GPAMUX1.bit.GPIO8 = 1
#define PWM_M1_WT_ON                    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1

#define PWM_M1_UB_ON                    GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 1
#define PWM_M1_VB_ON                    GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 1
#define PWM_M1_WB_ON                    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1

#define PWM_M1_UT_OFF                   GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 0
#define PWM_M1_VT_OFF                   GpioCtrlRegs.GPAMUX1.bit.GPIO8 = 0
#define PWM_M1_WT_OFF                   GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 0

#define PWM_M1_UB_OFF                   GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 0
#define PWM_M1_VB_OFF                   GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 0
#define PWM_M1_WB_OFF                   GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 0
*/

// GPIO
/*
#define GPIO_M0_UT_ON					GpioDataRegs.GPASET.bit.GPIO0 = 1
#define GPIO_M0_VT_ON					GpioDataRegs.GPASET.bit.GPIO2 = 1
#define GPIO_M0_WT_ON					GpioDataRegs.GPASET.bit.GPIO4 = 1

#define GPIO_M0_UB_ON					GpioDataRegs.GPASET.bit.GPIO1 = 1
#define GPIO_M0_VB_ON					GpioDataRegs.GPASET.bit.GPIO3 = 1
#define GPIO_M0_WB_ON					GpioDataRegs.GPASET.bit.GPIO5 = 1
*/

#define GPIO_M0_UT_OFF					GpioDataRegs.GPACLEAR.bit.GPIO0 = 1
#define GPIO_M0_VT_OFF					GpioDataRegs.GPACLEAR.bit.GPIO2 = 1
#define GPIO_M0_WT_OFF					GpioDataRegs.GPACLEAR.bit.GPIO4 = 1

#define GPIO_M0_UB_HIGH                 GpioDataRegs.GPASET.bit.GPIO1 = 1
#define GPIO_M0_VB_HIGH                 GpioDataRegs.GPASET.bit.GPIO3 = 1
#define GPIO_M0_WB_HIGH                 GpioDataRegs.GPASET.bit.GPIO5 = 1

#define GPIO_M0_UB_LOW                  GpioDataRegs.GPACLEAR.bit.GPIO1 = 1
#define GPIO_M0_VB_LOW                  GpioDataRegs.GPACLEAR.bit.GPIO3 = 1
#define GPIO_M0_WB_LOW                  GpioDataRegs.GPACLEAR.bit.GPIO5 = 1

/*
#define GPIO_M0_UB_OFF					GpioDataRegs.GPACLEAR.bit.GPIO1 = 1
#define GPIO_M0_VB_OFF					GpioDataRegs.GPACLEAR.bit.GPIO3 = 1
#define GPIO_M0_WB_OFF					GpioDataRegs.GPACLEAR.bit.GPIO5 = 1
*/
#define GPIO_M0_UB_OFF                  if( CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ){ \
                                            GPIO_M0_UB_LOW; \
                                        }else{ GPIO_M0_UB_HIGH; }

#define GPIO_M0_VB_OFF                  if( CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ){ \
                                            GPIO_M0_VB_LOW; \
                                        }else{ GPIO_M0_VB_HIGH; }

#define GPIO_M0_WB_OFF                  if( CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ){ \
                                            GPIO_M0_WB_LOW; \
                                        }else{ GPIO_M0_WB_HIGH; }


/*
#define GPIO_M1_UT_ON                   GpioDataRegs.GPASET.bit.GPIO6 = 1
#define GPIO_M1_VT_ON                   GpioDataRegs.GPASET.bit.GPIO8 = 1
#define GPIO_M1_WT_ON                   GpioDataRegs.GPASET.bit.GPIO10 = 1

#define GPIO_M1_UB_ON                   GpioDataRegs.GPASET.bit.GPIO7 = 1
#define GPIO_M1_VB_ON                   GpioDataRegs.GPASET.bit.GPIO9 = 1
#define GPIO_M1_WB_ON                   GpioDataRegs.GPASET.bit.GPIO11 = 1
*/
#if(0)
#define GPIO_M1_UT_OFF                  GpioDataRegs.GPACLEAR.bit.GPIO6 = 1
#define GPIO_M1_VT_OFF                  GpioDataRegs.GPACLEAR.bit.GPIO8 = 1
#define GPIO_M1_WT_OFF                  GpioDataRegs.GPACLEAR.bit.GPIO10 = 1

#define GPIO_M1_UB_HIGH                 GpioDataRegs.GPASET.bit.GPIO7 = 1
#define GPIO_M1_VB_HIGH                 GpioDataRegs.GPASET.bit.GPIO9 = 1
#define GPIO_M1_WB_HIGH                 GpioDataRegs.GPASET.bit.GPIO11 = 1

#define GPIO_M1_UB_LOW                  GpioDataRegs.GPACLEAR.bit.GPIO7 = 1
#define GPIO_M1_VB_LOW                  GpioDataRegs.GPACLEAR.bit.GPIO9 = 1
#define GPIO_M1_WB_LOW                  GpioDataRegs.GPACLEAR.bit.GPIO11 = 1

/*
#define GPIO_M1_UB_OFF                  GpioDataRegs.GPACLEAR.bit.GPIO7 = 1
#define GPIO_M1_VB_OFF                  GpioDataRegs.GPACLEAR.bit.GPIO9 = 1
#define GPIO_M1_WB_OFF                  GpioDataRegs.GPACLEAR.bit.GPIO11 = 1
*/
#define GPIO_M1_UB_OFF                  if( CG_BLDC_Drive_M1.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ){ \
                                            GPIO_M1_UB_LOW; \
                                        }else{ GPIO_M1_UB_HIGH; }

#define GPIO_M1_VB_OFF                  if( CG_BLDC_Drive_M1.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ){ \
                                            GPIO_M1_VB_LOW; \
                                        }else{ GPIO_M1_VB_HIGH; }

#define GPIO_M1_WB_OFF                  if( CG_BLDC_Drive_M1.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ){ \
                                            GPIO_M1_WB_LOW; \
                                        }else{ GPIO_M1_WB_HIGH; }
#endif

#define	AQ_FORCE_DISABLE				0x0
#define	AQ_FORCE_LOW					0x1
#define	AQ_FORCE_HIGH					0x2


//#define OUTPUT_M0_U_DUTY( x )			{ CG_BLDC_Drive.Duty_U = x; EPwm1Regs.CMPA.bit.CMPA = CG_BLDC_Drive.Period - x; }
//#define OUTPUT_M0_V_DUTY( x )			{ CG_BLDC_Drive.Duty_V = x; EPwm2Regs.CMPA.bit.CMPA = CG_BLDC_Drive.Period - x; }
//#define OUTPUT_M0_W_DUTY( x )			{ CG_BLDC_Drive.Duty_W = x; EPwm3Regs.CMPA.bit.CMPA = CG_BLDC_Drive.Period - x; }



// Motor Type defines
enum{
    MOTOR_BLDC	                    = 0,
    MOTOR_BDC               	    = 1,
    MOTOR_NUM              		    = 2
};


enum{
	SENSOR_TYPE_HALL				= 0,
	SENSOR_TYPE_ENCODER,
	//SENSOR_TYPE_SENSORLESS,
	SENSOR_TYPE_NUM = 2
};

enum{
	DRIVE_FREQUENCE_20KHz	= 0,
	DRIVE_FREQUENCE_16KHz	= 1,
	DRIVE_FREQUENCE_12KHz	= 2,
	DRIVE_FREQUENCE_8KHz	= 3,
	DRIVE_FREQUENCE_5KHz    = 4,
	DRIVE_FREQUENCE_4KHz    = 5,
	DRIVE_FREQUENCE_NUM		= 6
};

enum{
    GATEDRIVER_TYPE_NORMAL                  = 0,
    GATEDRIVER_TYPE_LOWSIDE_REVERSE         = 1,
    GATEDRIVER_TYPE_PWM_FREE                = 2,
    GATEDRIVER_TYPE_NUM                     = 3
};

typedef struct{

	uint8_t  	Mode;
	uint16_t  	DeadTime;
	uint32_t 	Frequency;
	int32_t 	Period;
	int32_t 	Period_Limit;
	int32_t 	Period_Limit_Brake;

	int32_t		Duty_U;
	int32_t		Duty_V;
	int32_t		Duty_W;

	int32_t     Duty_Apply_Abs;

	int8_t		Motor_Type;
	int16_t		Sensor_Type;
	int32_t 	Pole_Factor;

	int32_t  	Duty_Max_Abs;
	int32_t  	Duty_Min_Abs;
	int32_t  	Duty_Resolution;

	int32_t	 	Full_Speed_Rpm_Abs;
	uint8_t  	Commutation_Enable;
	int8_t      Commutation;
	uint8_t  	(*Commutation_Table)[8];

	int8_t		FOC_Start_Flag;
	Struct_FOC	FOC;
	uint8_t     EBrake_Flag;
	uint8_t     HWOCP_Flag;

	//

	uint8_t     GateDriver_Type;

	//
	void (*StepToSineWave)( void );
	void (*SineWaveToStep)( void );
	void (*Commutation_Out)( uint8_t commutation );
	void (*Duty_Out)( int32_t duty_u, int32_t duty_v, int32_t duty_w );

}Struct_BLDC_Drive;


enum{
	BITF_DRIVE_0					= 0,
	BITF_DRIVE_1,
	BITF_DRIVE_2,
	BITF_DRIVE_3,

	BITF_SENSOR_0					= 4,
	BITF_SENSOR_1,
	BITF_SENSOR_2,
	BITF_SENSOR_3,

    BITF_GATEDRIVER_0               = 8,
    BITF_GATEDRIVER_1,
    BITF_GATEDRIVER_2,
    BITF_GATEDRIVER_3
};

/*
#define SET_DRIVE_MODE( hw_data ) 				CG_BLDC_Drive.mode = ( hw_data & 0x0f );	\
												if( CG_BLDC_Drive.mode >= BLDCDRIVE_NUM ){ CG_BLDC_Drive.mode = BLDCDRIVE_6STEP_COMMUTATION_SLOW_DECAY; }


#define SET_SENSOR_TYPE( hw_data ) 				CG_BLDC_Drive.sensor_type = ( ( hw_data >> BITF_SENSOR_0 ) & 0x0f );	\
												if( CG_BLDC_Drive.sensor_type >= SENSOR_TYPE_NUM ){ CG_BLDC_Drive.sensor_type = SENSOR_TYPE_HALL; }
*/

/*===========================================================================================
    Function Name    : variableInitial_BLDCDrive
    Input            : 1.bldc_drive
                       2.mode
                       3.freq
                       4.deadtime
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_BLDCDrive ( Struct_BLDC_Drive *bldc_drive, uint8_t mode, uint32_t freq, uint32_t deadtime );


/*===========================================================================================
    Function Name    : setupInitial_BLDCDrive
    Input            :
					   1.mode: To decide the BLDC drive mode.
							0 = 6step commutation slow decay.
							1 = 6step commutation fast decay.
							2 = 6step commutation sabs
							3 = 6step commutation sabs
							4 = Sine wave drive.
					   2.freq: PWM frequency.
					   3.deadtime: It must be set with a non-zero value in mode 2, 3 and 4.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : BLDC drive mode setup. Here EPWM was used as the main tool for the drive.
					   More info. please read user manu at EPWM setting.
//==========================================================================================*/
void setupInitial_BLDCDrive( uint8_t mode, uint32_t freq, uint32_t deadtime );


/*===========================================================================================
    Function Name    : bldcDrive_OutputDuty_M0
    Input            : 1.duty_u
                       2.duty_v
                       3.duty_w
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
//void bldcDrive_OutputDuty_MotorAll( int32_t duty_u, int32_t duty_v, int32_t duty_w );
void bldcDrive_OutputDuty_M0( int32_t duty_u, int32_t duty_v, int32_t duty_w );
//void bldcDrive_OutputDuty_M1( int32_t duty_u, int32_t duty_v, int32_t duty_w );

/*===========================================================================================
    Function Name    : changeDriveMode_6stepToSineWave_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : From 6step to Sinewave
//==========================================================================================*/
//void changeDriveMode_6stepToSineWave_MotorAll( void );
void changeDriveMode_6stepToSineWave_M0( void );
//void changeDriveMode_6stepToSineWave_M1( void );

/*===========================================================================================
    Function Name    : changeDriveMode_SineWaveTo6step_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : From 6step to Sinewave
//==========================================================================================*/
//void changeDriveMode_SineWaveTo6step_MotorAll( void );
void changeDriveMode_SineWaveTo6step_M0( void );
//void changeDriveMode_SineWaveTo6step_M1( void );

/*===========================================================================================
    Function Name    : commutation_6Step_sabs_voltage ( single abs )
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 6 step commutation function with top switch, when duty off doing motor short brake.
    				   commutation from 'B' to normal commutation, it needs a 'C' to make all PWM_X.DBCTL.bit.IN_MODE = DBA_ALL;
//==========================================================================================*/
//void commutation_6Step_sabs_voltage_MotorAll ( uint8_t commutation );
void commutation_6Step_sabs_voltage_M0 ( uint8_t commutation );
//void commutation_6Step_sabs_voltage_M1 ( uint8_t commutation );

/*===========================================================================================
    Function Name    : swOutputDuty_ByADC
    Input            : 1.bldc_drive
                       2.is_ctrl_iq
                       3.target
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Sine wave functions.
//==========================================================================================*/
void swOutputDuty_ByADC( Struct_BLDC_Drive *bldc_drive, int8_t is_ctrl_iq, int32_t target );


extern const int32_t Const_Shunt_I_Type[ BLDCDRIVE_NUM ];
//extern void ( *const commutation_output_M0[ BLDCDRIVE_NUM ] ) ( uint8_t commutation );
//extern void ( *const commutation_output_M1[ BLDCDRIVE_NUM ] ) ( uint8_t commutation );

/*
__inline void il_NoIRQ_Commutation_output_M0( mode, commutation )
{
	DINT;
	commutation_output_M0[ mode ]( commutation );
	EINT;
}

__inline void il_NoIRQ_Commutation_output_M1( mode, commutation )
{
    DINT;
    commutation_output_M1[ mode ]( commutation );
    EINT;
}
*/

#endif /* C2000_BLDC_DRIVE_H_ */

/************************** <END OF FILE> *****************************************/


