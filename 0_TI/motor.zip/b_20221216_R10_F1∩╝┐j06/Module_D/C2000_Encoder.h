/*
 * C2000_Encoder.h
 *
 *  Created on: 2015/8/17
 *      Author: chaim.chen
 */
/*  Trunmman Technology Corporation. All rights reserved. */


#ifndef C2000_ENCODER_H_
#define C2000_ENCODER_H_


static const uint8_t Const_Encoder_Hall[ 8 ] = { 0, 2, 1, 3, 4, 6, 5, 0 };

static const uint8_t Const_Encoder_Distance_Tamagawa[ 8 ] = { 0, 5, 1, 0, 3, 4, 2, 0 };     // Tamagawa Encoder
static const uint8_t Const_Encoder_Distance_Siruba[ 8 ] = { 0, 4, 0, 5, 2, 3, 1, 0 };		// GaoLin Motor

static const uint8_t Const_Encoder_Distance_HallA[ 8 ] = { 0, 4, 0, 5, 2, 3, 1, 0 };       // Encoder + Hall Sequence A
static const uint8_t Const_Encoder_Distance_HallB[ 8 ] = { 0, 1, 5, 0, 3, 2, 4, 0 };       // Encoder + Hall Sequence B


static const uint8_t Const_EncoderAB_Distance_HallA[ 8 ] = { 0, 3, 5, 4, 1, 2, 0, 0 };       // EncoderAB + Hall Sequence A
static const uint8_t Const_EncoderAB_Distance_HallB[ 8 ] = { 0, 5, 3, 4, 1, 0, 2, 0 };       // EncoderAB + Hall Sequence B


#if(TEST_ENCODER_CN_ORDER_IS_EV)
#define ENCODER_STATE_A_M0                  ( GpioDataRegs.GPBDAT.bit.GPIO56 )
#define ENCODER_STATE_B_M0                  ( GpioDataRegs.GPBDAT.bit.GPIO57 )
#define ENCODER_STATE_Z_M0                  ( GpioDataRegs.GPBDAT.bit.GPIO59 )

/*
#define ENCODER_STATE_A_M1                  ( GpioDataRegs.GPADAT.bit.GPIO14 )
#define ENCODER_STATE_B_M1                  ( GpioDataRegs.GPADAT.bit.GPIO15 )
#define ENCODER_STATE_Z_M1                  ( GpioDataRegs.GPADAT.bit.GPIO26 )
*/

#else
#define ENCODER_STATE_A_M0				    ( 1 - GpioDataRegs.GPBDAT.bit.GPIO56 )
#define ENCODER_STATE_B_M0			        ( 1 - GpioDataRegs.GPBDAT.bit.GPIO57 )
#define ENCODER_STATE_Z_M0			        ( 1 - GpioDataRegs.GPBDAT.bit.GPIO59 )

#define ENCODER_STATE_A_M1                  ( 1 - GpioDataRegs.GPADAT.bit.GPIO14 )
#define ENCODER_STATE_B_M1                  ( 1 - GpioDataRegs.GPADAT.bit.GPIO15 )
#define ENCODER_STATE_Z_M1                  ( 1 - GpioDataRegs.GPADAT.bit.GPIO26 )
#endif

#define ENCODER_SIGNAL_M0                   ( ( ENCODER_STATE_Z_M0 << 2 ) | ( ENCODER_STATE_B_M0 << 1 ) | ( ENCODER_STATE_A_M0 << 0 ) )
//#define ENCODER_SIGNAL_M1                   ( ( ENCODER_STATE_Z_M1 << 2 ) | ( ENCODER_STATE_B_M1 << 1 ) | ( ENCODER_STATE_A_M1 << 0 ) )


#define CAPTURE_MODE                     1        	// 0 = only PhA edges are counted (2X)
													// 1 = BOTH PhA and PhB edges are counted (4X)

// Make Sure : ENCODER_SMOOTH_FACTOR1 * ENCODER_SMOOTH_FACTOR2 = 1000
#define ENCODER_SMOOTH_FACTOR1			100
#define ENCODER_SMOOTH_FACTOR2			( 1000 / ENCODER_SMOOTH_FACTOR1 )

#define ENCODER_ALLEGRO_PWM_CONST       ( 50 * PI_MULTIFY )
#define ENCODER_ALLEGRO_PWM_RESOLUTION  ( 900 * PI_MULTIFY ) // Duty 5% ~ 95%, resolution = 95% - 5% = 90%

//#define ENCODER_SOLUTION			361

//#define SET_AS_OUTPUT_POWER_5V		( GpioCtrlRegs.GPADIR.bit.GPIO30 = 1 )
//#define POWER_5V_HIGH				( GpioDataRegs.GPASET.bit.GPIO30 = 1 )
//#define POWER_5V_LOW				( GpioDataRegs.GPACLEAR.bit.GPIO30 = 1 )
//#define POWER_5V_ON				POWER_5V_HIGH
//#define POWER_5V_OFF				POWER_5V_LOW


enum{
	ENCODER_STATE_NOT_READY		= 0,
	ENCODER_STATE_READY			= 1,
	ENCODER_STATE_NUM			= 2
};


enum{
    ENCODER_TYPE_DEFAULT   = 0,
    ENCODER_TYPE_TAMAGAWA,
    ENCODER_TYPE_HALL_ENCODER_STD,
    ENCODER_TYPE_ALLEGRO,
    ENCODER_TYPE_HALL_ENCODER_AB,
    ENCODER_TYPE_SIRUBA,
    ENCODER_TYPE_NUM
};

enum{
    ENCODER_UPDATE_RATE_10HZ    = 0,
    ENCODER_UPDATE_RATE_20HZ,
    ENCODER_UPDATE_RATE_50HZ,
    ENCODER_UPDATE_RATE_100HZ,
    ENCODER_UPDATE_RATE_NUM
};

static const int32_t Const_Encoder_UpdateRate_Factor[ ENCODER_UPDATE_RATE_NUM ] = { 100, 50, 20 , 10 };

typedef struct{

    uint8_t Type;
    int8_t  Dir_Def;
    uint8_t Hall_Sequence;

    uint16_t UpdateRate_Pa;
    int32_t UpdateRate_Factor_1;
    int32_t UpdateRate_Factor_2;

    // Tamagawa Encoder variables
    uint8_t State;
    uint8_t Hall_Checked;
    uint8_t Hall_Check_IsFirstTime;
    uint32_t Hall_Check_First_Time;
    uint32_t Hall_Check_Current_Time;
    uint32_t Hall_Check_Time_Pass;
    uint32_t Hall_Check_Settling_Time;
    uint32_t Hall_Check_Checking_Time;

    //
	int32_t Index;
	int32_t Pos;
	int32_t Pos_Reg;

	int32_t Guess_Pos_T0;	// Before Z pulse occurs, we don't have the absolute pos, thus needs to guess its absolute pos by hall
	int64_t Position;	// Index * MaxPos + Pos

	int32_t Rapid_RPM_Abs;
	int32_t Rapid_RPM;
	//int32_t Rapid_ERPM_Abs;
	//int32_t Rapid_ERPM;

	int32_t Smooth_RPM_Abs;
	int32_t Smooth_RPM;
	//int32_t Smooth_ERPM_Abs;
	//int32_t Smooth_ERPM;

	int8_t	Direction;

	//
	int32_t FullPos;	// delta pos over 1 Physic cycle
	int32_t	MaxPos;
	int32_t PosErrorMax_P;
	int32_t PosErrorMax_N;

	//

	// FOC Rated varibles
    int32_t MaxPos_ForFOC;
    int32_t Phase_Length;
    int32_t PosError_Const;
    int16_t Offset;

    int32_t Pos_EstByHall;
    int32_t Pos_Est_Const;

    int32_t Pos_Est_Offset;

    uint32_t InputState;
    int8_t  Hall_State;

    //
    int16_t Hall_Cnt;
    int16_t Hall_Cnt_Latch;
    uint8_t Next_State_If_CW;
    uint8_t Next_State_If_CCW;
    //

    int32_t Pos_PWM;
    int32_t Pos_PWM_T0;

	//uint8_t GotNewSpeed;

	uint8_t Z_Got_Flag;
	int32_t LastPos_B4Z;
	int32_t LastIndex_B4Z;

	int32_t Dummy_Index;
	int32_t Dummy_Pos;

	int32_t	Offset_Index;
	int32_t	Offset_Pos;

	int32_t First_Z_Event_Flag;
	int32_t Z_Processed_Flag;

	//
	int32_t PosLat_Update_Flag;
	int32_t Delta_PosLat;
	int32_t Delta_PosLat_Sum;
	int32_t Delta_PosLat_Cnt;

    int32_t Delta_PosLat_Dummy;
    uint32_t PosLat_Old;

	//

	int32_t Pos_Stamp_Old;
	int32_t Pos_Stamp_New;
	int32_t Pos_Delta;

	int32_t Inst_Speed_Old;
	int32_t Inst_Speed_New;

	int32_t Inst_Acc;
	int32_t Inst_Speed_Acc_Const;

	//
	int32_t Delta_Pos_Integration;

    uint32_t Stall_Timer;

    //
    int32_t ThresholdPos_P;    // threshold pos for index
    int32_t ThresholdPos_N;    // threshold pos for index

    int32_t Threshold_HallCnt_P;    // threshold hall cnt
    int32_t Threshold_HallCnt_N;    // threshold hall cnt

    uint8_t ThresholdPos_P_HallState;
    uint8_t ThresholdPos_N_HallState;

}Struct_Basic_Encoder;



typedef struct{

	uint8_t	Power_On_Flag;

	Struct_Basic_Encoder	Motor_0;	// Motor 0 = BLDC in I01
	//Struct_Basic_Encoder	Motor_1;	// Motor 1 = Step Motor in I01


}Struct_Encoder;


/*===========================================================================================
    Function Name    : variableInitial_BasicEncoder
    Input            : encoder
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable initial
//==========================================================================================*/
void variableInitial_BasicEncoder ( Struct_Basic_Encoder* encoder );

/*===========================================================================================
    Function Name    : variableInitial_Encoder
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Encoder initial
//==========================================================================================*/
void variableInitial_Encoder ( void );

/*===========================================================================================
    Function Name    : encoder_Reset_Stall_Timer
    Input            : encoder
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoder_Reset_Stall_Timer( Struct_Basic_Encoder* encoder );

/*===========================================================================================
    Function Name    : targetPosInit_Encoder
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Encoder.TargetPos initial
//==========================================================================================*/
void targetPosInit_Encoder ( void );

/*===========================================================================================
    Function Name    : setupInitial_Encoder_M0
    Input            : 1.encoder_type,
                       2.resolution,
                       3.pole_factor,
                       4.direction_def,
                       5.hall_sequence,
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Encoder initialzation function.
                       For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_Encoder_M0(   Struct_Basic_Encoder*encoder,
                                uint8_t encoder_type,
                                int32_t resolution,
                                int32_t pole_factor,
                                int32_t direction_def,
                                int32_t hall_sequence );

/*===========================================================================================
    Function Name    : setupInitial_Encoder_M1
    Input            : 1.encoder_type,
                       2.resolution,
                       3.pole_factor,
                       4.direction_def,
                       5.hall_sequence,
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Encoder initialzation function.
                       For more info please check for the user manual.
//==========================================================================================*/
/*
void setupInitial_Encoder_M1(   Struct_Basic_Encoder*encoder,
                                uint8_t encoder_type,
                                int32_t resolution,
                                int32_t pole_factor,
                                int32_t direction_def,
                                int32_t hall_sequence );*/

/*===========================================================================================
    Function Name    : setupInitial_Encode
    Input            : 1.encoder_type_m0,
                       2.encoder_type_m1,
                       3.resolution_m0,
                       4.resolution_m1,
                       5.pole_factor_m0,
                       6.pole_factor_m1,
                       7.direction_def_m0,
                       8.direction_def_m1
                       9.hall_sequence_m0,
                       10.hall_sequence_m1
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Encoder initialzation function.
                       For more info please check for the user manual.
//==========================================================================================*/
/*
void setupInitial_Encoder(  uint8_t encoder_type_m0,
                            uint8_t encoder_type_m1,
                            int32_t resolution_m0,
                            int32_t resolution_m1,
                            int32_t pole_factor_m0,
                            int32_t pole_factor_m1,
                            int32_t direction_def_m0,
                            int32_t direction_def_m1,
                            int32_t hall_sequence_m0,
                            int32_t hall_sequence_m1 );*/

/*===========================================================================================
    Function Name    : power5V_Switch
    Input            : State
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void power5V_Switch( int8_t state );

/*===========================================================================================
    Function Name    : manageEncoderPower
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : manage 5v power
//==========================================================================================*/
void manageEncoderPower( void );

/*===========================================================================================
    Function Name    : captureEncoderInfo
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void captureEncoderInfo( void );

/*===========================================================================================
    Function Name    : encoder_CalculateSpeed
    Input            : 1.encoder
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoder_CalculateSpeed( Struct_Basic_Encoder* encoder );

/*===========================================================================================
    Function Name    : encoderGetGuessPos
    Input            : 1.enconder_reg
                        2.encoder
                        3.io_bitf_encoder
                        4.io_bitf_hall
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoderGetGuessPos( struct EQEP_REGS *enconder_reg, Struct_Basic_Encoder* encoder, uint8_t io_bitf_encoder, uint8_t io_bitf_hall );

/*===========================================================================================
    Function Name    : encoderOffset
    Input            : encoder : basic encoder
    				   index : offset index
					   pos : offset pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoderOffset ( Struct_Basic_Encoder* encoder, int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : encoderGetPosition
    Input            : 1.encoder
                        2.pos_reg: position from encoder peripheral
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : When doing this fuction, make sure Interrupt is turned off
//==========================================================================================*/
void encoderGetPosition ( Struct_Basic_Encoder* encoder, int32_t pos_reg );

/*===========================================================================================
    Function Name    : encoderGetAngle
    Input            : 1.encoder
                        2.pos_reg: position from encoder peripheral
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t encoderGetAngle ( Struct_Basic_Encoder* encoder, int32_t pos_reg );

/*===========================================================================================
    Function Name    : motor_0_encoder_isr
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The QEI ( Encoder ) interrupt event
//==========================================================================================*/
__interrupt void motor_0_encoder_isr( void );

/*===========================================================================================
    Function Name    : motor_1_encoder_isr
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The QEI ( Encoder ) interrupt event
//==========================================================================================*/
//__interrupt void motor_1_encoder_isr( void );

/*===========================================================================================
    Function Name    : ecap5_encoder_0_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__interrupt void ecap5_encoder_0_isr(void);

/*===========================================================================================
    Function Name    : ecap6_encoder_1_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
//__interrupt void ecap6_encoder_1_isr(void);

/*===========================================================================================
    Function Name    : il_EncoderPositionProcess
    Input            :  1. encoder = basic encoder
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_EncoderPositionProcess ( Struct_Basic_Encoder *encoder )
{
	encoder->Pos_Stamp_Old = encoder->Pos_Stamp_New;
	encoder->Pos_Stamp_New = encoder->Pos;

	encoder->Inst_Speed_Old = encoder->Inst_Speed_New;

	encoder->Pos_Delta = encoder->Pos_Stamp_New - encoder->Pos_Stamp_Old;
	if( encoder->Pos_Delta > encoder->PosErrorMax_P ){
		encoder->Pos_Delta = encoder->Pos_Delta - encoder->MaxPos;
	}else if( encoder->Pos_Delta < encoder->PosErrorMax_N ){
		encoder->Pos_Delta = encoder->Pos_Delta + encoder->MaxPos;
	}

	encoder->Inst_Speed_New = encoder->Pos_Delta * encoder->Inst_Speed_Acc_Const;
	encoder->Inst_Acc = encoder->Inst_Speed_New - encoder->Inst_Speed_Old;
}


#endif /* C2000_ENCODER_H_ */
/************************** <END OF FILE> *****************************************/


