/*
 * C2000_CAN.c
 *
 *  Created on: 2020/11/19
 *      Author: chaim.chen
 */

/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"
#include "driverlib.h"
#include "device.h"
#include "CANOpen.h"

volatile Struct_CAN     CG_CAN;

//extern volatile Struct_UART485  CG_UART485;
extern volatile Struct_Parameter						CG_Parameter;
//extern volatile Struct_Modbus_Slave						CG_Modbus_Slave_485;
//extern volatile Struct_HWEEP							CG_HWEEP;
extern volatile Struct_MD                                   CG_MD;
extern volatile Struct_Pretect                          CG_Protect;

/*===========================================================================================
    Function Name    : il_SetUp_CAN_Pin
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up Pin
//==========================================================================================*/
__inline void il_SetUp_CAN_Pin( void )
{
    GPIO_SetupPinMux(6, GPIO_MUX_CPU1, 6);
    GPIO_SetupPinMux(7, GPIO_MUX_CPU1, 6);

	EALLOW;
	GpioCtrlRegs.GPAPUD.bit.GPIO7 = 0;   // Enable pullup on GPIO13
	GpioCtrlRegs.GPAQSEL1.bit.GPIO7 = 3; // Asynch input
	//GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 6;  // GPIO13 = SCIRXDB
    GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;   // Enable pullup on GPIO12
	EDIS;

}


/*===========================================================================================
    Function Name    : setupInitial_CAN
    Input            : 1.can
                       2.node_id
					   3.baudrate
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_CAN( Struct_CAN *can, uint32_t node_id, unsigned int baudrate )
{
    can->Timeout_Flag = NO;
    can->Timeout_Pa_Ms = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_CAN_TIME_OUT_TICKS ];
    can->Timeout_Cnt_Ms = 0;
    can->LED_Indicator_Cnt_Ms = 0xFFFF;

    il_SetUp_CAN_Pin();

    can->ID = node_id;
    if( can->ID == 0 ){
        can->ID = 1;
    }else if( can->ID > 127 ){
        can->ID = 127;
    }

    can->BAUD_Index = baudrate;
    if( can->BAUD_Index >= CAN_BAUD_RATE_NUM ){
        can->BAUD_Index = CAN_BAUD_RATE_1M;
    }

    can->BaudRate = Const_CAN_Baud_Rate[ can->BAUD_Index ];

    CAN_setBitRate( C2000_CAN_BASE, DEVICE_SYSCLK_FREQ, can->BaudRate, 20);

    //CAN_enableTestMode( C2000_CAN_BASE, CAN_TEST_EXL);

    EALLOW;  // This is needed to write to EALLOW protected registers
    C2000_CAN_REG.CAN_CTL.bit.ABO = 1;
    EDIS;   // This is needed to disable write to EALLOW protected registers


#if(0)
    CAN_setupMessageObject( C2000_CAN_BASE, 1, 0x1234, CAN_MSG_FRAME_STD,
                           CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, 2, 0x1234, CAN_MSG_FRAME_STD,
                           CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 8);
#endif

    coSetupInitial( &can->CANOpen, can->ID );

    CAN_startModule( C2000_CAN_BASE );


}

/*===========================================================================================
    Function Name    : can_TimeOut_Check
    Input            : can
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : This function check if timeout.
//==========================================================================================*/
void can_TimeOut_Check ( Struct_CAN *can )
{
    if( can->Timeout_Cnt_Ms < 0xFFFF ){
        can->Timeout_Cnt_Ms++;
    }
    if( can->Timeout_Pa_Ms != 0 ){
        if( can->Timeout_Cnt_Ms >= can->Timeout_Pa_Ms ){
            can->Timeout_Flag = YES;

            CG_Protect.Motor_0.ComAlarm_Req_Flag = YES;
            //CG_Protect.Motor_1.ComAlarm_Req_Flag = YES;
        }
    }else{
        can->Timeout_Flag = NO;
    }
}

/*===========================================================================================
    Function Name    : output_CANStaLED
    Input            : can
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : This function output LED flash according to the CAN state
//==========================================================================================*/
void output_CANStaLED ( Struct_CAN *can )
{

    if( can->LED_Indicator_Cnt_Ms < 0xFFFF ){
        can->LED_Indicator_Cnt_Ms++;
    }

    if( can->LED_Indicator_Cnt_Ms >= STALED_TIME_OUT_CONST ){
        //COM_LED_OFF;
        //ioExp_SetOutput( IO_EXP_STA_LED, LOW );
        //otherGPIO_SetOutput( OTHER_OUTPUT_STA_LED, LOW );
        CG_MD.STA_LED_State_CAN = LOW;
    }else{
        //COM_LED_ON;
        //ioExp_SetOutput( IO_EXP_STA_LED, HIGH );
        //otherGPIO_SetOutput( OTHER_OUTPUT_STA_LED, HIGH );
        CG_MD.STA_LED_State_CAN = HIGH;
    }

}

/*===========================================================================================
    Function Name    : an_Call_1ms
    Input            : can
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void can_Call_1ms( Struct_CAN *can )
{
    co_Call_1ms( &can->CANOpen );

    can_TimeOut_Check( can );

    output_CANStaLED( can );

}

/*===========================================================================================
    Function Name    : can_Routine
    Input            : can
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void can_Routine( Struct_CAN *can )
{
    //uint16_t t_data[8] = { 0, 1, 2, 3, 4, 5, 6, 7 };

    //CG_MD.Test_tp1            = FREE_RUN_TIMER.TIM.all;

    /*
    CAN_sendMessage(CANB_BASE, 1, 8, t_data );
    //CAN_readMessage(CANB_BASE, 2, t_data );
    if( CAN_readMessage(CANB_BASE, 2, t_data ) ){
        can->CANOpen.Test_Cnt++;
    }*/

    co_Routine( &can->CANOpen );

    if( can->CANOpen.NewFrame_Flag ){
        can->CANOpen.NewFrame_Flag = NO;

        can->Timeout_Flag = NO;
        can->Timeout_Cnt_Ms = 0;
        can->LED_Indicator_Cnt_Ms = 0;
    }

    //CG_MD.Test_tp2            = FREE_RUN_TIMER.TIM.all;
    //CG_MD.Test_time       = CG_MD.Test_tp1 - CG_MD.Test_tp2;  // 1635 clk ticks for encoder model

}



 /************************** <END OF FILE> *****************************************/



