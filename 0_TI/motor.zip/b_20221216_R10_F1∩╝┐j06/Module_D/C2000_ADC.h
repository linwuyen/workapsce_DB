/*===========================================================================================

    File Name       : C2000_ADC.h

    Version         : V1_00_00_a

    Built Date      : 2015/08/03

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : This is the head file of ADC driver
				
    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef ADC_H
#define ADC_H

#include "IncludeFiles.h"
#include "FOC.h"

// SOC
#define SAMPLE_CLOCK            9//9

#define ADC_MIN_VALUE		    0										// VR min
#define ADC_MAX_VALUE		    4095//1023								// VR max
#define ADC_LIMIT_VALUE		    4096L

//#define ADC_DEAD_BAND			200//50
#define ADC_STOP_DISTANCE		40
#define THROTTLE_100_PERCENT	1000
#define THROTTLE_50_PERCENT		500


#define THROTTLE_MULTIFY		4

#define DAC_RESOLUTION 			4096UL//64UL
#define DAC_MAX_VALUE           4095UL

#define AD_L0_V					100
#define AD_H0_V					500
#define AD_L1_V					100
#define AD_H1_V					1000

#define CONST_VREFOUT_VALUE			2//4//10//2//10
#define CONST_ADC_CALIBRATION 		100
#define CONST_ADC_OFFSET_INIT 		80
#define CONST_SHUNT_I_CALIBRATION 	100

#define BUSV_PHYSIC_MAX			CG_HWEEP.HW_Info[ HWEEP_IDX_BUSV1 ]		//CG_Parameter.EEP_data[ PARAMETER_GENERAL ][ GENERAL_BUSV_MAX ]//24000//45000		// 6600 = 66V
#define SHUNT_I_PHYSIC_MAX		CG_HWEEP.HW_Info[ HWEEP_IDX_SHUNT_I_U_H ]		// 920 = 9.20 A ; 920 should be checked
#define SHUNT_I_HWP				CG_HWEEP.HW_Info[ HWEEP_IDX_HWP ]	// HWP = Hard Ware Protect ; and 920 = 9.20 A
#define SHUNT_I_FWP				CG_ADC.Motor_0.FWOCP



enum{

	PGA_Index_X3			= 0,
	PGA_Index_X6			= 1,
	//PGA_Index_X11			= 2,
	PGA_Index_X12			= 2,
	PGA_Index_X24			= 3,
	PGA_Index_NUM			= 4
};

#define CTRIP_CLKPRESCALE_MAX	0xFF

#define VREFOUT_DAC( x )		( AnalogSubsysRegs.VREFOUTCTL.bit.DACVAL = x )
#define SETUP_CURRENT_HWP( x )	( AnalogSubsysRegs.DAC1CTL.bit.DACVAL = x )

enum{
      
    Shunt_Index_U        = 0,
    Shunt_Index_V,
    Shunt_Index_W,
    Shunt_Index_NUM

};


enum{

	ADC_Index_M0_Shunt_U		= 0,    // Sample when PWM On
	ADC_Index_M0_Shunt_V,
	ADC_Index_M0_Shunt_W,

    ADC_Index_BusV,

	ADC_Index_A0X,
	ADC_Index_A1X,

    ADC_Index_M0_Shunt_U2,              // Sample when PWM Off
    ADC_Index_M0_Shunt_V2,
    ADC_Index_M0_Shunt_W2,

    ADC_Index_MosOT_1,
    ADC_Index_MosOT_2,
    ADC_Index_MosOT_3,

    ADC_Index_M0_BEMF_U,
    ADC_Index_M0_BEMF_V,
    ADC_Index_M0_BEMF_W,

    //

    ADC_Index_VCC5V_SENSE,

    ADC_Index_POUT1_FB,
    ADC_Index_POUT2_FB,

    ADC_Index_Num
	
};



enum{
    Throttle_SINGLE_ENDED         	= 0,
    Throttle_SINGLE_ENDED_R		    = 1,
	Throttle_WIG_WAG	         	= 2,
    Throttle_WIG_WAG_R			    = 3,
	Throttle_UNIPOLAR				= 4,
	Throttle_NUM					= 5
};

enum{

	SHUNT_I_TYPE_SAMPLE_ON_SINGLE		= 0,
	SHUNT_I_TYPE_SAMPLE_OFF_MULTIPLE	= 1,
	SHUNT_I_TYPE_SAMPLE_BOTH_SINGLE		= 2,
	SHUNT_I_TYPE_SAMPLE_FOC				= 3,
	SHUNT_I_TYPE_SAMPLE_NUM				= 4
};


#define SLOW_ADC_BUFF_SIZE  		5	// 200Hz = 1000 / 5
#define ADC_UPDATE_DUTY_FREQUENCE   1000UL
//#define BUSV_BUFFER_SIZE			5	// 200Hz = 1000 / 5
#define SHUNT_BUFFER_SIZE			5	// 200Hz = 1000 / 5
#define BUSV_BUFFER_SIZE			8
#define BUSV_BUFFER_SIZE_BIT		3

#define A0A1X_BUFFER_SIZE			16
#define A0A1X_BUFFER_SIZE_BIT		4

typedef struct{

	uint32_t	Power;

	uint32_t	Power_Percentage;		// HW/FW OCP restraint for low-power motor
	int32_t		HWOCP;					// HWOCP value
	int32_t		FWOCP;					// FWOCP value
	int16_t 	PGA_Index;
	int16_t 	DAC_Value;
	int16_t 	CTRIP_PreScale;

	//

	int32_t		Shunt_I_Type;
	uint8_t  	Shunt_I_Pointer;
	int32_t 	Shunt_I;
	int32_t		Shunt_I_Sum;
	int32_t		Shunt_I_Cnt;
	int32_t 	Shunt_I_Avg;
	int32_t     Shunt_I_With_Signed;

	//

	int32_t 	Shunt_U_HWP_P;
	int32_t 	Shunt_V_HWP_P;
	int32_t 	Shunt_W_HWP_P;

	int32_t 	Shunt_U_HWP_N;
	int32_t 	Shunt_V_HWP_N;
	int32_t 	Shunt_W_HWP_N;

	int32_t 	Shunt_BRAKE_HWP;

	//
	uint16_t	Shunt_I_Offset[ Shunt_Index_NUM ];
	uint32_t    Shunt_I_Full_Scale[ Shunt_Index_NUM ];
	uint32_t	Shunt_I_Offset_Dummy[ Shunt_Index_NUM ];	// Dummy value for shunt i offset calculation

}Struct_Motor_Analog;



typedef struct{

	uint32_t 	Updated_BITF;
	uint32_t 	Update_Duty_Const;

	uint16_t    Is_ShuntV_Exist;

    uint16_t 	Value_Inst             	[ ADC_Index_Num ];
	uint32_t 	Value_Sum             	[ ADC_Index_Num ];
	uint32_t 	Value_Cnt             	[ ADC_Index_Num ];
    int32_t 	Value_Avg              	[ ADC_Index_Num ];
    int32_t 	Value_Smooth            [ ADC_Index_Num ];

	int32_t		Value_Mapping           [ ADC_Index_Num ];

	int32_t	 	BusV;
	uint16_t 	BusV_ADC             	[ BUSV_BUFFER_SIZE ];
	int32_t	 	BusV_ADC_Sum;
	uint16_t 	BusV_ADC_Pointer;

	//

	uint16_t 	A0X_ADC             	[ A0A1X_BUFFER_SIZE ];
	int32_t	 	A0X_ADC_Sum;
	uint16_t 	A1X_ADC             	[ A0A1X_BUFFER_SIZE ];
	int32_t	 	A1X_ADC_Sum;

	uint16_t 	A0A1X_ADC_Pointer;


	//
	int32_t		Calibration_Cnt;
	int32_t		Calibration_Value;

    int16_t     Shunt_I_Calibration_Flag;
    int16_t     Shunt_I_Calibration_Cnt;

	Struct_Motor_Analog	Motor_0;
	//

	// ==
	//uint32_t	test_p1;
	//uint32_t	test_p2;
	//uint32_t	test_period;
	
	
}Struct_ADC;

/*===========================================================================================
    Function Name    : il_Calculate_ShuntI_abc_WithOffset_P
    Input            :
                       1.adc_value: ADC value
                       2.offset_adc: opa reference offset
                       3.physic_max: current for delta 3.3V
    Return           : Shunt I value ( unit: 0.01 A )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate Shunt I physic value.
//==========================================================================================*/
__inline int32_t il_Calculate_ShuntI_abc_WithOffset_P( int32_t adc_value, int32_t offset_adc, int32_t physic_max )
{
    return ( physic_max * ( adc_value - offset_adc) / ADC_LIMIT_VALUE );
}

/*===========================================================================================
    Function Name    : il_Calculate_ShuntI_abc_WithOffset
    Input            :
					   1.adc_value: ADC value
					   2.offset_adc: opa reference offset
					   3.physic_max: current for delta 3.3V
    Return           : Shunt I value ( unit: 0.01 A )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate Shunt I physic value.
//==========================================================================================*/
__inline int32_t il_Calculate_ShuntI_abc_WithOffset( int32_t adc_value, int32_t offset_adc, int32_t physic_max )
{
	//return ( physic_max * ( offset_adc - adc_value ) / ADC_MAX_VALUE );
	return ( physic_max * ( offset_adc - adc_value ) / ADC_LIMIT_VALUE );
}

/*===========================================================================================
    Function Name    : variableInitial_MotorAnalog
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_MotorAnalog ( Struct_Motor_Analog* motor );

/*===========================================================================================
    Function Name    : variableInitial_ADC
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_ADC initial
//==========================================================================================*/
void variableInitial_ADC (void);


/*===========================================================================================
    Function Name    : setupInitial_ADC
    Input            : 1. hwocp
                        2. fwocp
                        3. power_percentage
                        4. pga_index
                        5. ocp_detect_prescale
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : ADC initialzation function.
                       For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_ADC( int32_t hwocp, int32_t fwocp, int32_t power_percentage, int32_t pga_index, int32_t ocp_detect_prescale );

/*===========================================================================================
    Function Name    : setup_DACA
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setup_DACA( int32_t dac );

/*===========================================================================================
    Function Name    : setValue_DACA
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setValue_DACA( int32_t dac );

/*===========================================================================================
    Function Name    : setup_DACB
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setup_DACB( int32_t dac );

/*===========================================================================================
    Function Name    : setValue_DACB
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setValue_DACB( int32_t dac );

/*===========================================================================================
    Function Name    : setup_HWPADC
    Input            : 1.motor_analog
                        2.hweep_shunt_full_scale_u
                        3.hweep_shunt_full_scale_v
                        4.hweep_shunt_full_scale_w
                        5.hweep_shunt_offset_u
                        6.hweep_shunt_offset_v
                        7.hweep_shunt_offset_w
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : HWP ADC setup
//==========================================================================================*/
void setup_HWPADC ( Struct_Motor_Analog* motor_analog,
                    int32_t hweep_shunt_full_scale_u,
                    int32_t hweep_shunt_full_scale_v,
                    int32_t hweep_shunt_full_scale_w,
                    int32_t hweep_shunt_offset_u,
                    int32_t hweep_shunt_offset_v,
                    int32_t hweep_shunt_offset_w );

/*===========================================================================================
    Function Name    : calibration_ShuntIOffset
    Input            : 1.hweep_shunt_full_scale_m0_u
                        2.hweep_shunt_full_scale_m0_v
                        3.hweep_shunt_full_scale_m0_w
                        4.hweep_shunt_offset_m0_u
                        5.hweep_shunt_offset_m0_v
                        6.hweep_shunt_offset_m0_w
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Shunt I offset adjustment
//==========================================================================================*/
void calibration_ShuntIOffset ( int32_t hweep_shunt_full_scale_m0_u,
                                int32_t hweep_shunt_full_scale_m0_v,
                                int32_t hweep_shunt_full_scale_m0_w,
                                int32_t hweep_shunt_offset_m0_u,
                                int32_t hweep_shunt_offset_m0_v,
                                int32_t hweep_shunt_offset_m0_w );

/*===========================================================================================
    Function Name    : polling_ADC_MainLoop
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @main loop
//==========================================================================================*/
void polling_ADC_MainLoop( void );

/*===========================================================================================
    Function Name    : polling_ADC_1ms
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @1ms event
//==========================================================================================*/
void polling_ADC_1ms( void );

/*===========================================================================================
    Function Name    : polling_ADC_10ms
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @10ms event
//==========================================================================================*/
void polling_ADC_10ms( void );


/*===========================================================================================
    Function Name    : calculatePhysic_BUSV
    Input            : 
					   1.adc_value: ADC value
    Return           : Bus v value ( unit: 0.01 Volt )			
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate bus v physic value.
//==========================================================================================*/
int32_t calculatePhysic_BUSV( uint32_t adc_value );


/*===========================================================================================
    Function Name    : calculatePhysic_ShuntI_WithOffset
    Input            :
					   1.adc_value: ADC value
					   2.offset_adc: opa reference offset
					   3.physic_max: current for delta 3.3V
    Return           : Shunt I value ( unit: 0.01 A )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate Shunt I physic value.
//==========================================================================================*/
int32_t calculatePhysic_ShuntI_WithOffset( uint32_t adc_value, int32_t offset_adc, int32_t physic_max );

/*===========================================================================================
    Function Name    : calculate_Throttle
    Input            : 
					   1.input_x: 	input value x
					   2.RefA_x:	Ref. A's x value
					   3.RefA_y:	Ref. A's y value
					   4.RefB_x:	Ref. B's x value
					   5.RefB_y:	Ref. B's y value
    Return           : Output y 
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
int32_t calibration( int32_t input_x, int32_t RefA_x, int32_t RefA_y, int32_t RefB_x, int32_t RefB_y );

/*===========================================================================================
    Function Name    : calibration_3Point
    Input            :
					   1.input_x: 	input value x
					   2.RefA_x:	Ref. A's x value
					   3.RefA_y:	Ref. A's y value
					   4.RefB_x:	Ref. B's x value
					   5.RefB_y:	Ref. B's y value
					   6.RefB_x:	Ref. C's x value
					   7.RefB_y:	Ref. C's y value

    Return           : Output y
    Programmer       : Andrew.an@trumman.com.tw
    Description      : According to Chaim's older calculate_Throttle function
//==========================================================================================*/
int32_t calibration_3Point( int32_t input_x, int32_t RefA_x, int32_t RefA_y, int32_t RefB_x, int32_t RefB_y, int32_t RefC_x, int32_t RefC_y );

/*===========================================================================================
    Function Name    : calculate_Throttle
    Input            :
                       1.adc_value:     ADC value
                       2.throttle_max:  Throttle max value
                       3.throttle_min:  Throttle min value ( Deadband )
                       4.output_max:    Max output duty
                       5.output_min:    Min output duty
                       6.map_factor:    Output duty corresponse to half throttle value
                       7.type:          Normal rising / falling , speciel rising / falling
                       8.deadband
    Return           : result
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate result by throttle.
//==========================================================================================*/
int32_t calculate_Throttle( uint32_t adc_value,
                            uint32_t throttle_max,
                            uint32_t throttle_min,
                            uint32_t output_max,
                            uint32_t output_min,
                            uint32_t map_factor,
                            uint8_t  type,
                            uint32_t deadband );
							
/*===========================================================================================
    Function Name    : calculate_AD_Input_to_Spd
    Input            : 
					   1.input: 		input value
					   2.offset_V:		offset voltage of zero point
					   3.offset_output:	offset output
					   4.output_max:	Output max value to limit the output
					   5.output_min:	Output min value to limit the output
					   6.gain:			gain value of the ad input. (rpm per 1V)
    Return           : Output
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Calculate output by ad input.
//==========================================================================================*/
int32_t calculate_AD_Input_to_Spd( 	uint32_t input,
									uint32_t offset_V,
									uint32_t offset_output,
									uint32_t output_max,
									uint32_t output_min,
									uint32_t gain );

/*===========================================================================================
    Function Name    : calculateAvg_ADC
    Input            : Index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate ADC avg value.
    				   @polling_ADC
//==========================================================================================*/
void calculateAvg_ADC( int8_t index );

/*===========================================================================================
    Function Name    : calculateAvg_A0A1X
    Input            : Index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate A0A1X avg value.
//==========================================================================================*/
void calculateAvg_A0A1X( void );

/*===========================================================================================
    Function Name    : calculateAvg_A1A2
    Input            : Index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate A1A2 avg value.
//==========================================================================================*/
void calculateAvg_A1A2( void );

/*===========================================================================================
    Function Name    : setADC_UpdateDutyConst
    Input            : freq : PWM freq
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate ADC avg value.
    				   @BLDC Drive setupInitial_BLDCDrive
//==========================================================================================*/
void setADC_UpdateDutyConst( int32_t freq );

/*===========================================================================================
    Function Name    : adc_isr1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : ADC IRQ event2.
//==========================================================================================*/
__interrupt void adc_isr1(void);

/*===========================================================================================
    Function Name    : adc_isr2
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : ADC IRQ event2.
//==========================================================================================*/
__interrupt void adc_isr2(void);


extern const uint16_t Const_DAC_Index[3];
extern const char Const_Shunt_I_Pointer[ 7 ];




#endif

/************************** <END OF FILE> *****************************************/
