/*
 * C2000_UART232.c
 *
 *  Created on: 2015/4/15
 *      Author: chaim.chen
 */

/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_UART  CG_UART;
//extern volatile Struct_Parameter			CG_Parameter;

//#pragma CODE_SECTION( sciaRxFifoIsr, "ramfuncs");
#pragma CODE_SECTION( sciaRxFifoIsr, ".TI.ramfunc" );

/*===========================================================================================
    Function Name    : variableInitial_UART
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_UART initial
//==========================================================================================*/
void variableInitial_UART (void)
{
    CG_UART.R_data_pointer = 0;
    CG_UART.T_data_pointer = 0;
    CG_UART.request_to_send_data_flag = 0;

    CG_UART.ReceiveFlag = UART_READY;
	CG_UART.get_data_flag = NO;

	CG_UART.modbus_mode = MB_SLV_ASCII;

}

/*===========================================================================================
    Function Name    : il_SetUp_UARTPin
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up UART Pin
//==========================================================================================*/
__inline void il_SetUp_UARTPin( void )
{

	EALLOW;

	// GPIO_SetupPinMux() - Sets the GPxMUX1/2 and GPyMUX1/2 register bits
	// GPIO_SetupPinOptions() - Sets the direction and configuration of GPIOs
	// These functions are found in the F28X7x_Gpio.c file.
	//

#if(0)
	// GPIO17 RXD
	GPIO_SetupPinMux(17, GPIO_MUX_CPU1, 6);
	GPIO_SetupPinOptions(17, GPIO_INPUT, GPIO_PUSHPULL);
	// GPIO16 TXD
	GPIO_SetupPinMux(16, GPIO_MUX_CPU1, 6);
	GPIO_SetupPinOptions(16, GPIO_OUTPUT, GPIO_ASYNC);
#else
	/*
	// GPIO28 RXD
	GPIO_SetupPinMux(28, GPIO_MUX_CPU1, 1);
	GPIO_SetupPinOptions(28, GPIO_INPUT, GPIO_PUSHPULL);
	// GPIO29 TXD
	GPIO_SetupPinMux(29, GPIO_MUX_CPU1, 1);
	GPIO_SetupPinOptions(29, GPIO_OUTPUT, GPIO_ASYNC);
	*/
	//
	// Enable SCI-A on GPIO28 - GPIO29
	//
	GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;   // Enable pullup on GPIO28
	GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 3; // Asynch input
	GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;  // GPIO28 = SCIRXDA
	GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;   // Enable pullup on GPIO29
	GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;  // GPIO29 = SCITXDA

#endif


	EDIS;

}

/*===========================================================================================
    Function Name    : il_SetUp_UARTReg
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up UART register
//==========================================================================================*/
__inline void il_SetUp_UARTReg( unsigned long baudrate )
{
	uint32_t dummy;
	// Interrupts that are used in this example are re-mapped to
	// ISR functions found within this file.
	EALLOW;  // This is needed to write to EALLOW protected registers
	PieVectTable.SCIA_RX_INT = &sciaRxFifoIsr;
	EDIS;   // This is needed to disable write to EALLOW protected registers

	SciaRegs.SCICCR.all = 0x0007;   // 1 stop bit,  No loopback
	                                  // No parity,8 char bits,
	                                  // async mode, idle-line protocol
	SciaRegs.SCICTL1.all = 0x0003;  // enable TX, RX, internal SCICLK,
								  // Disable RX ERR, SLEEP, TXWAKE
	//SciaRegs.SCICTL2.bit.TXINTENA =1;
	SciaRegs.SCICTL2.bit.RXBKINTENA =1;

	dummy = ( LSPCLK_FREQ / ( baudrate * 8 ) ) - 1;

	SciaRegs.SCIHBAUD.all = ( dummy >> 8 );
	SciaRegs.SCILBAUD.all = ( dummy & 0xFF );

	//SciaRegs.SCICCR.bit.LOOPBKENA =1; // Enable loop back
	//SciaRegs.SCIFFTX.all=0xC022;
	//SciaRegs.SCIFFRX.all=0x0022;
	//SciaRegs.SCIFFCT.all=0x00;
	CG_UART.rtu_time_frame_length = ( CPU_FREQ / baudrate ) * 35; // ( 35 = 10 bit * 3.5 char length )
	if( CG_UART.rtu_time_frame_length < MODBUS_FRAME_GAP_LIMIT ){
		CG_UART.rtu_time_frame_length = MODBUS_FRAME_GAP_LIMIT;
	}


	//SciaRegs.SCICTL1.all = 0x0033;     // Relinquish SCI from Reset
	SciaRegs.SCICTL1.all = 0x0023;     // Relinquish SCI from Reset
	//SciaRegs.SCIFFTX.bit.TXFIFOXRESET=1;
	//SciaRegs.SCIFFRX.bit.RXFIFORESET=1;

	PieCtrlRegs.PIEIER9.bit.INTx1 = 1;     	// PIE Group 9, INT1
	IER |= M_INT9;

}

/*===========================================================================================
    Function Name    : setupInitial_UART
    Input            :
					   1.baudrate : baudrate number of the UART.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : UART initialzation function.
					   For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_UART( unsigned long baudrate)
{

    variableInitial_UART();

    il_SetUp_UARTPin();

    il_SetUp_UARTReg( baudrate );

}


/*===========================================================================================
    Function Name    : sciaRxFifoIsr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__interrupt void sciaRxFifoIsr(void)
{
	if( SciaRegs.SCIRXST.bit.RXERROR == 1 ){

		SciaRegs.SCICTL1.all = 0x0000;
		//SciaRegs.SCICTL1.all = 0x0033;     // Relinquish SCI from Reset
		SciaRegs.SCICTL1.all = 0x0023;     // Relinquish SCI from Reset

	}else{

		/* Receive Data Available */

		CG_UART.R_data_buffer[ CG_UART.R_data_pointer++ ] = SciaRegs.SCIRXBUF.all;

		if( CG_UART.ReceiveFlag == UART_READY ){

            if( CG_UART.modbus_mode == MB_SLV_RTU ){
                CG_UART.get_data_flag = YES;
                CG_UART.rtu_time_point_2 = FREE_RUN_TIMER.TIM.all;

            }else{

                if( CG_UART.R_data_buffer[ CG_UART.R_data_pointer - 1 ] == START_BYTE ){
                    CG_UART.R_data_buffer[ 0 ] = START_BYTE;
                    CG_UART.R_data_pointer = 1;

                }else if( CG_UART.R_data_buffer[ CG_UART.R_data_pointer - 1 ] == END_BYTE ){
                    CG_UART.R_data_number = CG_UART.R_data_pointer;
                    CG_UART.R_data_pointer = 0;
                    CG_UART.ReceiveFlag = UART_DONE;

                }

            }

		}


		// buffer overflow reset
		if( CG_UART.R_data_pointer == UART_BUFFER_SIZE ){
			CG_UART.R_data_pointer = 0;
		}
	}


	SciaRegs.SCIFFRX.bit.RXFFOVRCLR=1;   // Clear Overflow flag
	SciaRegs.SCIFFRX.bit.RXFFINTCLR=1;   // Clear Interrupt flag
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;       // Issue PIE ack

    return;
}


/*===========================================================================================
    Function Name    : checkUARTSend
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Check if the UART data transmit commmand has been set then decide if it
					   needs to send output data.
					   For previous version please check oringial A04 or A09 MDB code.
					   *Avoid using while loop.
//==========================================================================================*/
void checkUARTSend( void )
{

    if( CG_UART.request_to_send_data_flag == 1 ){      // UART data transmit command has been set

        if( CG_UART.T_data_pointer < CG_UART.T_data_length ){   // data transmit is not finished

			// Check if Tx buffer empty.
            if( SciaRegs.SCICTL2.bit.TXEMPTY == 1 ){

            	SciaRegs.SCITXBUF.all = CG_UART.T_data_buffer[ CG_UART.T_data_pointer ];
                CG_UART.T_data_pointer++;
            }

        }else{
            CG_UART.request_to_send_data_flag = 0;
        }


    }
}


/*===========================================================================================
    Function Name    : checkUARTframe_232
    Input            : Null
    Return           : Null
    Programmer       : Eric.Tsai@trumman.com.tw
					   Modified by Chaum.Chen@trumman.com.tw
    Description      : For RTU
//==========================================================================================*/
 void checkRTUframe_232( void )
{

	uint32_t dummy_rtu_time_point_2;

	if( CG_UART.modbus_mode == MB_SLV_RTU && CG_UART.get_data_flag == YES ){

		dummy_rtu_time_point_2 = CG_UART.rtu_time_point_2;

		CG_UART.rtu_time_point_1 = FREE_RUN_TIMER.TIM.all;

		if( dummy_rtu_time_point_2 - CG_UART.rtu_time_point_1 > CG_UART.rtu_time_frame_length ){	// in C2000, timer always decelerates

			CG_UART.get_data_flag			= NO;
			CG_UART.R_data_number			= CG_UART.R_data_pointer;
			CG_UART.R_data_pointer			= 0;
			CG_UART.ReceiveFlag 			= UART_DONE;

		}

	}

}

 /************************** <END OF FILE> *****************************************/



