/*
 * F280XX_CAP.h
 *
 *  Created on: 2015/4/22
 *      Author: chaim.chen
 */

#ifndef F280XX_CAP_H_
#define F280XX_CAP_H_


#define PULSE_MULTIFY			2
#define PI_MULTIFY				4

#define PI_NO_SIGNAL_CNT		100 // 100 = 100 ms ( unit: 1ms )
#define X1_PI_NO_SIGNAL_CNT		40 	// 20 = 20 ms ( unit: 1ms )

#define PI_DUTY_MAX				( 916  * PI_MULTIFY )//( 925  * 4 )	//  925 = 92.5% duty
#define PI_DUTY_MIN	   			( 321  * PI_MULTIFY )//( 360  * 4 )	//  360 = 36.5% duty
#define PI_DUTY_RESOLUTION		( 1000 * PI_MULTIFY )	// 1000 = 100.0% duty

#define PI_XH_DUTY_MAX			( 1000 * PI_MULTIFY )	//  1000 = 100.0% duty
#define PI_XH_DUTY_MIN	   		(    0 * PI_MULTIFY ) 		//  0 = 0% duty

#define XH0_GPIO_INDEX          14
#define XH1_GPIO_INDEX          15
//#define XH2_GPIO_INDEX_VER_A    30
//#define XH3_GPIO_INDEX_VER_A    31
//#define XH2_GPIO_INDEX_VER_B    16
//#define XH3_GPIO_INDEX_VER_B    17

#define MOTOR_FEEDBACK_NORMAL_STATE         1

#define PI_CONST				100000UL

#define CONST_PI_TIMEOUT        100

// PI sequence CW: 0 -> 1 -> 3 -> 2 -> 0
static const uint8_t        Const_PI_NextState_Table_CW[ 2 ][ 4 ] = { { 1, 3, 0, 2 },
                                                                      { 2, 0, 3, 1 } };
enum{
    PI_TYPE_2_PULSE     = 0,
    PI_TYPE_DIR_PULSE,
    PI_TYPE_NUM
};


enum{
    CAP_MODE_HALL           = SENSOR_TYPE_HALL,    // Cap5 = M0C, and Cap6 = M1C, and Cap5 and Cap6 will trigger IRQ
    CAP_MODE_ENCODER        = SENSOR_TYPE_ENCODER,    // Cap5 = M0S2, and Cap6 = M1S2, their behavior is like as XH0 ~ XH3
    CAP_MODE_NUM            = 2
};

enum{
	PI_XH0		= 0,
	PI_XH1      = 1,
	//PI_XH2      = 2,
	//PI_XH3      = 3,
	//PI_M0S2     = 4,
	//PI_M1S2     = 5,
	//PI_NUM		= 6

	PI_M0S2     = 2,
	PI_NUM      = 3

};

enum{
	PI_RISE		= 0,
	PI_FALL		= 1
};

#define PI_BUFFER_SIZE	4


typedef struct{
    int32_t     Freq;             // unit : 0.1Hz
    int32_t     Duty;             // uint : 0.1 %
    int32_t     Lowside_Duty;     // uint : 0.1 %
    int8_t      Ready;

    uint32_t    Image_VR;
    uint32_t    Image_VR_Mapping;
    uint32_t    Image_VR_Buffer[ PI_BUFFER_SIZE ];
    uint32_t    Image_VR_Sum;
    uint32_t    Image_VR_Pointer;

    uint32_t    Image_VR_PFM;
    uint32_t    Pulse_Width;

    uint8_t     ZeroCnt;

    uint8_t     State;

    uint32_t    Rising_Time;
    uint32_t    Falling_Time;

    int16_t     XH_Rising_Adj;

    uint32_t    Peroid_Low;
    uint32_t    Peroid_High;

    uint32_t    Cap[4];
    uint32_t    OldCap;
    int32_t     D_12;
    int32_t     D_23;
    int32_t     D_34;

    //

    struct ECAP_REGS *ECapRegs;

}Struct_PI_Basic;


typedef struct{
    int32_t     Freq;             // unit : 0.1Hz
    int8_t      Direction;
    int8_t      Direction_Old;
    int32_t     Pos;

    int32_t     DirCnt;
    int32_t     Cnt;
    int32_t     Cnt_Latch;

    uint8_t     IOState;
    uint8_t     IOState_Old;
    uint8_t     IOState_If_CW;
    uint8_t     IOState_If_CCW;

    //
    uint16_t    Type_PA;
    uint32_t    Timeout_PA;
    uint32_t    Timeout_Cnt;

}Struct_PI_CMD;


typedef struct{

    Struct_PI_Basic Channel[ PI_NUM ];

    Struct_PI_CMD   Motor_0;
    //Struct_PI_CMD   Motor_1;
	//
	//uint32_t	test_cnt;
	//uint32_t	test_data[10];

    //

    uint32_t        PWM_Period;
    uint32_t        PWM_Duty_Pa;
    uint32_t        PWM_Duty;

    int32_t         PWM_RatingVoltage;
    int32_t         PWM_MinimumVoltage;

}Struct_PI;


/*===========================================================================================
    Function Name    : variableInitial_Capture
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Capture/CG_PI initial
//==========================================================================================*/
void variableInitial_Capture (void);

/*===========================================================================================
    Function Name    : setupInitial_Capture
    Input            : 1.mode_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : mode: 0 >> Cap5 = M0C, and Cap6 = M1C, and Cap5 and Cap6 will trigger IRQ
                       mode: 1 >> Cap5 = M0S2, and Cap6 = M1S2, their behavior is like as XH0 ~ XH3
//==========================================================================================*/
void setupInitial_Capture( int32_t mode_m0 );

/*===========================================================================================
    Function Name    : calculate_PI_Info_Simple
    Input            : 1.index: x
                       2.normal_state : normal high / low
                       3.current_state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void calculate_PI_Info_Simple ( uint8_t index, uint8_t normal_state, uint8_t current_state );

/*===========================================================================================
    Function Name    : call_MainLoop_PI
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void call_MainLoop_PI ( void );

/*===========================================================================================
    Function Name    : call_1ms_PI
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 1 ms time up event of PI.
//==========================================================================================*/
void call_1ms_PI ( void );

/*===========================================================================================
    Function Name    : call_100ms_PI
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 10 ms time up event of PI.
//==========================================================================================*/
void call_100ms_PI ( void );

/*===========================================================================================
    Function Name    : capPICMD_Init
    Input            : 1.pi_cmd
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void capPICMD_Init ( Struct_PI_CMD *pi_cmd );

/*===========================================================================================
    Function Name    : capPICMD_RoutineWork
    Input            : 1.pi_cmd
                       2.state_a
                       3.state_b
                       4.normal_state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void capPICMD_RoutineWork ( Struct_PI_CMD *pi_cmd, uint8_t state_a, uint8_t state_b, uint8_t normal_state );

/*===========================================================================================
    Function Name    : capPICMD_Latch
    Input            : 1.pi_cmd
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void capPICMD_Latch ( Struct_PI_CMD *pi_cmd );

#endif /* F280XX_CAP_H_ */



/************************** <END OF FILE> *****************************************/

