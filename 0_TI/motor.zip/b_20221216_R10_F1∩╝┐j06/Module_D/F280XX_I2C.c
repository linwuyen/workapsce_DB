/*
 * F280XX_I2C.c
 *
 *  Created on: 2015/8/10
 *      Author: chaim.chen
 */

/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"
#include "IO_Expander.h"

volatile Struct_I2C CG_I2C;

//extern volatile Struct_IO_Expander      CG_IO_Expander;

//#pragma CODE_SECTION( i2c_int1a_isr, "ramfuncs");
#pragma CODE_SECTION( i2c_int1a_isr, ".TI.ramfunc" );

/*===========================================================================================
    Function Name    : variableInitial_I2C
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_I2C initial
//==========================================================================================*/
void variableInitial_I2C( void )
{
	uint8_t i;

    CG_I2C.MasterState 				= I2C_READY;

    CG_I2C.RdIndex     				= 0;
    CG_I2C.WrIndex     				= 0;

    CG_I2C.ReadLength				= 0;
    CG_I2C.WriteLength				= 0;

    CG_I2C.Busy_flag   				= 0;
    CG_I2C.write_delay_counter 		= I2C_WRITE_DELAY_TIME;

    CG_I2C.error_counter 			= 0;
    CG_I2C.ErrorDeviceAddr 			= 0;
	CG_I2C.is_OK_Flag	 			= YES;
	CG_I2C.State_BIFT				= 0;

	for( i = 0; i < I2C_BUFSIZE; i++ ){
		CG_I2C.R_Data[i] = 0;
		CG_I2C.T_Data[i] = 0;
	}

	CG_I2C.test_reg = 0;
	CG_I2C.test_reg2 = 0;

}

/*===========================================================================================
    Function Name    : checkBusyFlag_I2C
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Busy flag will be clear after a time delay.
    				   @cpu_timer0_isr
//==========================================================================================*/
void checkBusyFlag_I2C( void )
{
    if( ++CG_I2C.write_delay_counter > I2C_WRITE_DELAY_TIME ){
        CG_I2C.write_delay_counter = I2C_WRITE_DELAY_TIME;
        CG_I2C.Busy_flag = 0;
    }
}

/*===========================================================================================
    Function Name    : checkError_I2C
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Check if I2C has no response.
    				   @cpu_timer0_isr
//==========================================================================================*/
void checkError_I2C( void )
{

    if( CG_I2C.MasterState == I2C_READ_STARTED ||
    	CG_I2C.MasterState == I2C_READ_REPEAT_STARTED  ){

        if( ++CG_I2C.error_counter > I2C_ERROR_TIME ){

			CG_I2C.ErrorDeviceAddr = I2caRegs.I2CSAR.all;
			#if(I2C_ERROR_DETCET)
				CG_I2C.is_OK_Flag	   = NO;
			#endif
            CG_I2C.error_counter = I2C_ERROR_TIME;

            I2caRegs.I2CMDR.bit.IRS = 0; // disable I2C
            CG_I2C.MasterState = I2C_READY;
            CG_I2C.State_BIFT |= ( 1UL << RDATA_TIME_OUT );
            I2caRegs.I2CMDR.bit.IRS = 1; // disable I2C
        }

    }else{

        if( --CG_I2C.error_counter < 0 ){

            CG_I2C.error_counter = 0;	// NoteToGear: was 10 in old B03 code?

        }
    }


}

/*===========================================================================================
    Function Name    : il_SetUp_I2CPin
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up I2C pins.
//==========================================================================================*/
__inline void il_SetUp_I2CPin( void )
{

	// GPIO027 I2C SCL
	GPIO_SetupPinMux(27, GPIO_MUX_CPU1, 11);

	// GPIO032 I2C SDA
	GPIO_SetupPinMux(32, GPIO_MUX_CPU1, 1);

	EALLOW;

	GpioCtrlRegs.GPAPUD.bit.GPIO27 = 0;   // Enable pullup on GPIO8
	GpioCtrlRegs.GPAQSEL2.bit.GPIO27 = 3;  // Asynch input GPIO8

	GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;   // Enable pullup on GPIO32
	GpioCtrlRegs.GPBQSEL1.bit.GPIO32 = 3;  // Asynch input GPIO32

	EDIS;

}

/*===========================================================================================
    Function Name    : il_SetUp_I2CReg
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up I2C reg.
//==========================================================================================*/
__inline void il_SetUp_I2CReg( void )
{
	EALLOW;
	// Initialize I2C
	PieVectTable.I2CA_INT = &i2c_int1a_isr;

	I2caRegs.I2CMDR.bit.IRS = 0;

	//I2caRegs.I2CSAR = 0xA2;		// Slave address - EEPROM control code

	//I2caRegs.I2CPSC.bit.IP SC = 5;		    // Prescaler - need 7-12 Mhz on module clk
	I2caRegs.I2CPSC.bit.IPSC = 9;
	I2caRegs.I2CCLKL = I2SCLL_SCLL;				// NOTE: must be non zero
	I2caRegs.I2CCLKH = I2SCLH_SCLH;				// NOTE: must be non zero
	//I2caRegs.I2CIER.all = 0x24;			// Enable SCD & ARDY interrupts
	I2caRegs.I2CIER.bit.SCD = 1;
	I2caRegs.I2CIER.bit.ARDY = 1;
	I2caRegs.I2CIER.bit.XRDY = 1;
	I2caRegs.I2CIER.bit.RRDY = 1;
	I2caRegs.I2CIER.bit.NACK = 1;
	//I2caRegs.I2CIER.bit.ARBL = 1;
	//I2caRegs.I2CIER.bit.AAS  = 1;

	I2caRegs.I2CMDR.all = 0x0020;		// Take I2C out of reset
										// Stop I2C when suspended

	I2caRegs.I2CFFTX.all = 0x6000;		// Enable FIFO mode and TXFIFO
	I2caRegs.I2CFFRX.all = 0x2040;		// Enable RXFIFO, clear RXFFINT,

	// Enable interrupts required for this example

	// Enable I2C interrupt 1 in the PIE: Group 8 interrupt 1
	PieCtrlRegs.PIEIER8.bit.INTx1 = 1;

	// Enable CPU INT8 which is connected to PIE group 8

	IER |= M_INT8;

	EDIS;

}

/*===========================================================================================
    Function Name    : il_ResetEEP
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Reset EEP
//==========================================================================================*/
__inline void il_ResetEEP( void )
{
    int32_t i = 0;

    EALLOW;

    #define SDA_HIGH                ( GpioDataRegs.GPBSET.bit.GPIO32 = 1 )
    #define SDA_LOW                 ( GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1 )

    #define SCL_HIGH                ( GpioDataRegs.GPASET.bit.GPIO27 = 1 )
    #define SCL_LOW                 ( GpioDataRegs.GPACLEAR.bit.GPIO27 = 1 )

    GpioCtrlRegs.GPBDIR.bit.GPIO32 = 1; // SDA
    GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;  // SCL

    // start
    SCL_HIGH;
    SDA_HIGH;
    il_Delay( CPU_FREQ / 10000 );
    SDA_LOW;
    il_Delay( CPU_FREQ / 10000 );

    SCL_LOW;
    il_Delay( CPU_FREQ / 40000 );
    SDA_HIGH;
    il_Delay( CPU_FREQ / 40000 );

    // 9 dummy Clks
    for( i = 0; i < 9; i++ ){
        SCL_HIGH;
        il_Delay( CPU_FREQ / 40000 );
        SCL_LOW;
        il_Delay( CPU_FREQ / 40000 );
    }

    // start

    SCL_HIGH;
    il_Delay( CPU_FREQ / 10000 );
    SDA_LOW;
    il_Delay( CPU_FREQ / 10000 );
    SCL_LOW;
    il_Delay( CPU_FREQ / 10000 );

    // stop

    SCL_HIGH;
    il_Delay( CPU_FREQ / 10000 );
    SDA_HIGH;
    il_Delay( CPU_FREQ / 10000 );

    GpioCtrlRegs.GPBDIR.bit.GPIO32 = 0; // SDA
    GpioCtrlRegs.GPADIR.bit.GPIO27 = 0;  // SCL

    SCL_LOW;
    SDA_LOW;

    EDIS;

}

/*===========================================================================================
    Function Name    : checkError_I2C
    Input            : Null
    Return           :
                       true or false, return false if the I2C
                       interrupt handler was not installed correctly
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up I2C.
//==========================================================================================*/
uint32_t setupInitial_I2C( void )
{

    il_ResetEEP();

    variableInitial_I2C();

    il_SetUp_I2CPin();

    il_SetUp_I2CReg();

    return 1 ;
}

/*===========================================================================================
    Function Name    : writeData_I2C
    Input            :
                       1.slaveID: S2S1S0
                       2.EEPType: 64K bits or 2K bits in this application
                       3.address: EEP address
                       4.data   : data needs to write
                       5.num    : data length.
    Return           : Is_Write_Success
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Write data to EEP
                       User must make a delay after data writing
                       ( roughly 10ms for delay time )
//==========================================================================================*/
Uint16 writeData_I2C( uint8_t slaveID, uint8_t EEPType, uint32_t address, uint8_t * data, uint8_t num )
{
#if(1)
	Uint16 i = 0;
	Uint16 datanum = 0;

	while( CG_I2C.Busy_flag == 1 );    // Wait for I2C to be not busy

	// Wait until the STP bit is cleared from any previous master communication.
	// Clearing of this bit by the module is delayed until after the SCD bit is
	// set. If this bit is not checked prior to initiating a new message, the
	// I2C could get confused.
	if( I2caRegs.I2CMDR.bit.STP == 1 ){
		CG_I2C.State_BIFT |= ( 1UL << STOP_MISSED );
		return 0;
	}

	// Setup slave address
	I2caRegs.I2CSAR.all = slaveID;

	// Check if bus busy
	if( I2caRegs.I2CSTR.bit.BB == 1 ){
		CG_I2C.State_BIFT |= ( 1UL << STUCK_IN_BUSY );
		return 0;
	}

   // Setup number of bytes to send
	if( EEPType == EEPTYPE_2KBIT ){
		CG_I2C.WriteLength = BASIC_WRITE_LENGTH_2KBIT  + num;	// address ( 1byte ) + num
		CG_I2C.T_Data[ datanum++ ] = address;
	}else{
		CG_I2C.WriteLength = BASIC_WRITE_LENGTH_64KBIT + num;	// address ( 2byte ) + num
		CG_I2C.T_Data[ datanum++ ] = address / 256;
		CG_I2C.T_Data[ datanum++ ] = address % 256;
	}
	I2caRegs.I2CCNT = CG_I2C.WriteLength;

	CG_I2C.WrIndex = 0;

	for( i = 0; i < num; i++ ){
		CG_I2C.T_Data[ datanum++ ] = data[ i ];
	}

	CG_I2C.write_delay_counter = I2C_WRITE_DELAY_TIME - 20;
	CG_I2C.Busy_flag = 1;
	CG_I2C.MasterState 		= I2C_WRITE_STARTED;
	// Send start as master transmitter

	I2caRegs.I2CMDR.all = 0x2E20;

	//CG_IO_Expander.Data_Flag = NO;

#endif

	return 1;
}

/*===========================================================================================
    Function Name    : readData_I2C
    Input            :
                       1.slaveID: S2S1S0
                       2.EEPType: 64K bits or 2K bits in this application
                       3.address: EEP address
                       4.data   : data needs to read
                       5.num    : data length.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Read data from EEP
//==========================================================================================*/
Uint16 readData_I2C( uint8_t slaveID, uint8_t EEPType, uint32_t address, uint8_t * data, uint8_t num )
{

	Uint16 i = 0;

	while( CG_I2C.Busy_flag == 1 );    // Wait for I2C to be not busy

	// Wait until the STP bit is cleared from any previous master communication.
	// Clearing of this bit by the module is delayed until after the SCD bit is
	// set. If this bit is not checked prior to initiating a new message, the
	// I2C could get confused.
	if( I2caRegs.I2CMDR.bit.STP == 1 ){
		CG_I2C.State_BIFT |= ( 1UL << STOP_MISSED );
		return 0;
	}

	I2caRegs.I2CSAR.all = slaveID;

	// Check if bus busy
	if( I2caRegs.I2CSTR.bit.BB == 1 ){
		CG_I2C.State_BIFT |= ( 1UL << STUCK_IN_BUSY );
		return 0;
	}

	if( EEPType == EEPTYPE_2KBIT ){
		CG_I2C.WriteLength = BASIC_WRITE_LENGTH_2KBIT;	// address ( 1byte )
		CG_I2C.T_Data[ 0 ] = address;
	}else{
		CG_I2C.WriteLength = BASIC_WRITE_LENGTH_64KBIT;	// address ( 2byte )
		CG_I2C.T_Data[ 0 ] = address / 256;
		CG_I2C.T_Data[ 1 ] = address % 256;
	}
	I2caRegs.I2CCNT = CG_I2C.WriteLength;

	CG_I2C.RdIndex = 0;
	CG_I2C.WrIndex = 0;
	CG_I2C.ReadLength = num;

	CG_I2C.MasterState 		= I2C_READ_STARTED;

	I2caRegs.I2CMDR.all 	= 0x2620;			// Send data to setup EEPROM address

	CG_I2C.error_counter = 0;

	//CG_IO_Expander.Data_Flag = NO;

	while( CG_I2C.MasterState != I2C_READY );

	for( i = 0; i < num; i++ ){
		data[ i ] = CG_I2C.R_Data[ i ];
	}

	if( CG_I2C.State_BIFT == 0 ){
		return 1;
	}else{
		return 0;
	}

}

/*===========================================================================================
    Function Name    : writeAndCheckDataEEP
    Input            :
                       1.slaveID: S2S1S0
                       2.EEPType: 64K bits or 2K bits in this application
                       3.address: EEP address
                       4.data   : data needs to write
                       5.num    : data length.
    Return           :  1 : data transmit is success.
                        0 : data transmit is failed.
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Write data to EEP and then check if data transmit is success.
    				   Max data num = 8
//==========================================================================================*/
uint8_t writeAndCheckDataEEP( uint8_t slaveID, uint8_t EEPType, uint32_t address, uint8_t * data, uint8_t num )
{

    int8_t result = 1;
    uint8_t data_read[ MAX_OP_BYTE_NUM ];
    uint8_t i;

    writeData_I2C( slaveID, EEPType, address, data, num );
    readData_I2C(  slaveID, EEPType, address, data_read, num );

    for( i = 0; i < num; i ++ ){

        if( data_read[i] != data[ i ] ){
            result = 0;
            break;
        }

    }

    return result;
}



/*===========================================================================================
    Function Name    : i2c_int1a_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : I2C IRQ
//==========================================================================================*/
__interrupt void i2c_int1a_isr(void)     // I2C-A
{
	Uint16 IntSource;
	Uint16 i;
	Uint16 R_Length;

	IntSource = I2caRegs.I2CISRC.all;

	// Interrupt source = stop condition detected
	switch( IntSource ){

	case I2C_TX_ISRC:											// To output data

		I2caRegs.I2CDXR.all = CG_I2C.T_Data[ CG_I2C.WrIndex++ ] ;
		if( CG_I2C.WrIndex >= I2C_BUFSIZE ){
			CG_I2C.WrIndex = 0;
			CG_I2C.State_BIFT |= ( 1UL << TDATA_OVERFLOAT );
		}

		break;


	case I2C_RX_ISRC:											// To recieve data

		R_Length = I2caRegs.I2CFFRX.bit.RXFFRST;

		for( i = 0; i < R_Length; i++ ){
			CG_I2C.R_Data[ CG_I2C.RdIndex++ ] = I2caRegs.I2CDRR.all;
			if( CG_I2C.RdIndex >= I2C_BUFSIZE ){
				CG_I2C.RdIndex = 0;
				CG_I2C.State_BIFT |= ( 1UL << RDATA_OVERFLOAT );
			}
		}

		break;

	case I2C_SCD_ISRC:											// Stop condition occurs

		if( CG_I2C.MasterState == I2C_READ_REPEAT_STARTED ){
			CG_I2C.MasterState = I2C_READY;

			R_Length = I2caRegs.I2CFFRX.bit.RXFFRST;

			for( i = 0; i < R_Length; i++ ){
				CG_I2C.R_Data[ CG_I2C.RdIndex++ ] = I2caRegs.I2CDRR.all;
				if( CG_I2C.RdIndex >= I2C_BUFSIZE ){
					CG_I2C.RdIndex = 0;
					CG_I2C.State_BIFT |= ( 1UL << RDATA_OVERFLOAT );
				}
			}

		}else if( CG_I2C.MasterState == I2C_WRITE_STARTED ){
			CG_I2C.MasterState = I2C_READY;
		}


		break;

	case I2C_ARDY_ISRC:

		if( CG_I2C.MasterState == I2C_READ_STARTED ){			// READ_STARTED, and needs a restart
			CG_I2C.MasterState = I2C_READ_REPEAT_STARTED;

			I2caRegs.I2CCNT = CG_I2C.ReadLength;				// Setup how many bytes to expect
			I2caRegs.I2CMDR.all = 0x2C20;						// Send restart as master receiver
		}

		break;

	case I2C_NACK_ISRC:											// NACK, No response : wrong slave ID or Line broken
	default:
		I2caRegs.I2CMDR.bit.STP = 1;
		I2caRegs.I2CSTR.all = I2C_CLR_NACK_BIT;
		CG_I2C.State_BIFT |= ( 1UL << RECIEVE_NACK );
		CG_I2C.MasterState = I2C_READY;

		break;
	//case I2C_ARB_ISRC:


		//I2caRegs.I2CMDR.bit.STB = 1;
		//I2caRegs.I2CMDR.bit.STT = 1;

		//break;
	}


	// Enable future I2C (PIE Group 8) interrupts
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
}

/************************** <END OF FILE> *****************************************/


