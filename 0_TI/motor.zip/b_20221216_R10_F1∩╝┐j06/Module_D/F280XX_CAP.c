/*
 * F280XX_CAP.c
 *
 *  Created on: 2015/4/22
 *      Author: chaim.chen
 */

#include "IncludeFiles.h"

volatile Struct_PI							CG_PI;
extern volatile Struct_GPIO 				CG_GPIO;
extern volatile Struct_BLDC_CTRL            CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL            CG_BLDC_CTRL_M1;

extern volatile Struct_BLDC_Drive           CG_BLDC_Drive_M0;
//extern volatile Struct_BLDC_Drive           CG_BLDC_Drive_M1;
extern volatile Struct_Encoder              CG_Encoder;
extern volatile Struct_MD                   CG_MD;

//#pragma CODE_SECTION( ecap1_isr, "ramfuncs");

/*===========================================================================================
    Function Name    : variableInitial_Capture
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Capture/CG_PI initial
//==========================================================================================*/
void variableInitial_Capture (void)
{
    Struct_PI_Basic *pulse;
	uint32_t	i,j;
	for( i = 0; i < PI_NUM; i++ ){
	    pulse = (Struct_PI_Basic *)&CG_PI.Channel[ i ];

	    pulse->Freq = 0;             // unit : 0.1Hz
	    pulse->Duty = 0;             // uint : 0.1 %
	    pulse->Lowside_Duty = 0;     // uint : 0.1 %

	    pulse->ZeroCnt = PI_NO_SIGNAL_CNT;
	    pulse->State = PI_RISE;

	    pulse->Image_VR_Pointer = 0;
		for( j = 0; j < PI_BUFFER_SIZE; j++ ){
		    pulse->Image_VR_Buffer[ j ] = 0;
		}
		pulse->Image_VR_Sum = 0;
		pulse->Image_VR = 0;
		pulse->Image_VR_Mapping = 0;
		pulse->Ready = NO;
		pulse->XH_Rising_Adj = 0;
		pulse->Pulse_Width = 0;
	}
	capPICMD_Init ( (Struct_PI_CMD*)&CG_PI.Motor_0 );
	//capPICMD_Init ( (Struct_PI_CMD*)&CG_PI.Motor_1 );

}

/*===========================================================================================
    Function Name    : il_SetUp_CapPin
    Input            : 1.mode_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : mode: 0 >> Cap5 = M0C, and Cap6 = M1C, and Cap5 and Cap6 will trigger IRQ
                       mode: 1 >> Cap5 = M0S2, and Cap6 = M1S2, their behavior is like as XH0 ~ XH3
//==========================================================================================*/
__inline void il_SetUp_CapPin( int32_t mode_m0 )
{
	EALLOW;
	/* Enable internal pull-up for the selected pins */
	// Pull-ups can be enabled or disabled by the user.
	// This will enable the pullups for the specified pins.
	// Comment out other unwanted lines.

	GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;		// Enable pull-up   // XH0
    GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;     // Enable pull-up   // XH1

    GpioCtrlRegs.GPBPUD.bit.GPIO39 = 0;     // Enable pull-up   // M0S2
    //GpioCtrlRegs.GPBPUD.bit.GPIO40 = 0;     // Enable pull-up   // M1S2

    // Inputs are synchronized to SYSCLKOUT by default.
    // Comment out other unwanted lines.

    GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = 0;		// 0 = Synch to SYSCLKOUT, 1 = Qualification using 3 samples, 2 = Qualification using 6 samples
    GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 0;       // 0 = Synch to SYSCLKOUT, 1 = Qualification using 3 samples, 2 = Qualification using 6 samples

    GpioCtrlRegs.GPBQSEL1.bit.GPIO39 = 0;       // 0 = Synch to SYSCLKOUT, 1 = Qualification using 3 samples, 2 = Qualification using 6 samples
    //GpioCtrlRegs.GPBQSEL1.bit.GPIO40 = 0;       // 0 = Synch to SYSCLKOUT, 1 = Qualification using 3 samples, 2 = Qualification using 6 samples

    InputXbarRegs.INPUT7SELECT = XH0_GPIO_INDEX;
    InputXbarRegs.INPUT8SELECT = XH1_GPIO_INDEX;

    // Hall mode, it connect to M0C and M1C
    if( mode_m0 == CAP_MODE_HALL ){
        InputXbarRegs.INPUT11SELECT = HALL_W_M0;
    }else{
        InputXbarRegs.INPUT11SELECT = MOTOR_S2_M0;
    }

    /*
    if( mode_m1 == CAP_MODE_HALL ){
        InputXbarRegs.INPUT12SELECT = HALL_W_M1;
    }else{
        InputXbarRegs.INPUT12SELECT = MOTOR_S2_M1;
    }
    */

    //
    ECap1Regs.ECCTL0.bit.INPUTSEL = 6;  // Cap1 pin = Xbar-Input7
    ECap2Regs.ECCTL0.bit.INPUTSEL = 7;  // Cap2 pin = Xbar-Input8
    //ECap3Regs.ECCTL0.bit.INPUTSEL = 8;  // Cap3 pin = Xbar-Input9
    //ECap4Regs.ECCTL0.bit.INPUTSEL = 9;  // Cap4 pin = Xbar-Input10

    ECap5Regs.ECCTL0.bit.INPUTSEL = 10;  // Cap5 pin = Xbar-Input11
    //ECap6Regs.ECCTL0.bit.INPUTSEL = 11;  // Cap6 pin = Xbar-Input12

	EDIS;

}

/*===========================================================================================
    Function Name    : il_SetUp_CapReg
    Input            : 1.mode_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : mode: 0 >> Cap5 = M0C, and Cap6 = M1C, and Cap5 and Cap6 will trigger IRQ
                       mode: 1 >> Cap5 = M0S2, and Cap6 = M1S2, their behavior is like as XH0 ~ XH3
//==========================================================================================*/
__inline void il_SetUp_CapReg( int32_t mode_m0 )
{
    int32_t i;
    struct ECAP_REGS *ecap;

	EALLOW;  // This is needed to write to EALLOW protected registers
	//PieVectTable.ECAP1_INT = &ecap1_isr;

	for( i = 0; i < PI_NUM; i++ ){

	    switch( i ){
	    case PI_XH0:
	        ecap = ( struct ECAP_REGS * )&ECap1Regs;
	        break;
	    case PI_XH1:
	        ecap = ( struct ECAP_REGS * )&ECap2Regs;
	        break;
	    case PI_M0S2:
	        ecap = ( struct ECAP_REGS * )&ECap5Regs;
	        break;

	    default:

	        break;
	    }

	    CG_PI.Channel[i].ECapRegs = ecap;

	    //ecap->ECEINT.all = 0x0000;             	// Disable all capture interrupts
        ecap->ECCLR.all = 0xFFFF;              	// Clear all CAP interrupt flags
        ecap->ECCTL1.bit.CAPLDEN = 0;          	// Disable CAP1-CAP4 register loads
        ecap->ECCTL2.bit.TSCTRSTOP = 0;        	// Make sure the counter is stopped

        // Configure peripheral registers
        ecap->ECCTL1.bit.CAP1POL = 0;          	// 0 = Rising edge, 1 = Falling edge
        ecap->ECCTL1.bit.CAP2POL = 1;          	// 0 = Rising edge, 1 = Falling edge
        ecap->ECCTL1.bit.CAP3POL = 0;          	// 0 = Rising edge, 1 = Falling edge
        ecap->ECCTL1.bit.CAP4POL = 1;          	// 0 = Rising edge, 1 = Falling edge
        ecap->ECCTL1.bit.CTRRST1 = 0;          	// Difference operation
        ecap->ECCTL1.bit.CTRRST2 = 0;          	// Difference operation
        ecap->ECCTL1.bit.CTRRST3 = 0;          	// Difference operation
        ecap->ECCTL1.bit.CTRRST4 = 0;          	// Difference operation

        ecap->ECCTL1.bit.CAPLDEN = 1;          	// Enable CAP1-CAP4 register loads
        ecap->ECCTL1.bit.PRESCALE = 0;			// precsale = 1
        ecap->ECCTL2.bit.CAP_APWM = 0;			// capture mode
        ecap->ECCTL2.bit.CONT_ONESHT = 0;      	// Continunous
        ecap->ECCTL2.bit.STOP_WRAP = 3;      	// 010101
        ecap->ECCTL2.bit.SYNCO_SEL = 2;        	// Disable
        ecap->ECCTL2.bit.SYNCI_EN = 0;         	// Disable sync in
        ecap->ECCTL2.bit.TSCTRSTOP = 1;        	// Start Counter
	}

	if( mode_m0 == CAP_MODE_HALL ){
	    ECap5Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
        ECap5Regs.ECEINT.all = ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );            // 4 events = interrupt
        // Enable CPU INT4 which is connected to ECAP1-4 INT:
        IER |= M_INT4;
	}

	/*
	if( mode_m1 == CAP_MODE_HALL ){
	    ECap6Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
	    ECap6Regs.ECEINT.all = ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );            // 4 events = interrupt
	    // Enable CPU INT4 which is connected to ECAP1-4 INT:
	    IER |= M_INT4;
	}*/

	EDIS;    // This is needed to disable write to EALLOW protected registers

}

/*===========================================================================================
    Function Name    : il_SetUp_CapPWM
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SetUp_CapPWM( void )
{
    //int32_t i;
    struct ECAP_REGS *ecap;

    EALLOW;  // This is needed to write to EALLOW protected registers
    //PieVectTable.ECAP1_INT = &ecap1_isr;

    ecap = ( struct ECAP_REGS * )&ECap7Regs;


    //ecap->ECEINT.all = 0x0000;                // Disable all capture interrupts
    ecap->ECCLR.all = 0xFFFF;               // Clear all CAP interrupt flags
    //ecap->ECCTL1.bit.CAPLDEN = 0;           // Disable CAP1-CAP4 register loads
    ecap->ECCTL2.bit.TSCTRSTOP = 0;         // Make sure the counter is stopped

    // Configure peripheral registers

    //ecap->ECCTL1.bit.CAPLDEN = 1;           // Enable CAP1-CAP4 register loads
    ecap->ECCTL1.bit.PRESCALE = 0;          // precsale = 1


    CG_PI.PWM_Period = SYSTEM_FREQUENCE / CAP_PWM_FREQ;
    CG_PI.PWM_Duty = CG_PI.PWM_Period / 2;

    ecap->CAP3 = CG_PI.PWM_Period;
    ecap->CAP4 = CG_PI.PWM_Period - CG_PI.PWM_Duty;

    ecap->ECCTL2.bit.CAP_APWM = 1;          // capture mode

    //ecap->ECCTL2.bit.CONT_ONESHT = 0;       // Continunous
   //ecap->ECCTL2.bit.STOP_WRAP = 3;         // 010101
    ecap->ECCTL2.bit.SYNCO_SEL = 2;         // Disable
    ecap->ECCTL2.bit.SYNCI_EN = 0;          // Disable sync in
    ecap->ECCTL2.bit.TSCTRSTOP = 1;         // Start Counter


    EDIS;    // This is needed to disable write to EALLOW protected registers

}

/*===========================================================================================
    Function Name    : setupInitial_Capture
    Input            : 1.mode_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : mode: 0 >> Cap5 = M0C, and Cap6 = M1C, and Cap5 and Cap6 will trigger IRQ
                       mode: 1 >> Cap5 = M0S2, and Cap6 = M1S2, their behavior is like as XH0 ~ XH3
//==========================================================================================*/
void setupInitial_Capture( int32_t mode_m0 )
{

	variableInitial_Capture();

	il_SetUp_CapPin( mode_m0 );

	il_SetUp_CapReg( mode_m0 );

	il_SetUp_CapPWM();

	//
    if( CG_Encoder.Motor_0.Type == ENCODER_TYPE_HALL_ENCODER_AB ){
        EALLOW;  // This is needed to write to EALLOW protected registers
        PieVectTable.ECAP5_INT = &ecap5_encoder_0_isr;
        PieCtrlRegs.PIEIER4.bit.INTx5 = 1;
        ECap5Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
        ECap5Regs.ECEINT.all = ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );            // 4 events = interrupt
        // Enable CPU INT4 which is connected to ECAP1-4 INT:
        IER |= M_INT4;
        EDIS;    // This is needed to disable write to EALLOW protected registers
    }

    /*
    if( CG_Encoder.Motor_1.Type == ENCODER_TYPE_HALL_ENCODER_AB ){
        EALLOW;  // This is needed to write to EALLOW protected registers
        PieVectTable.ECAP6_INT = &ecap6_encoder_1_isr;
        PieCtrlRegs.PIEIER4.bit.INTx6 = 1;
        ECap6Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
        ECap6Regs.ECEINT.all = ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );            // 4 events = interrupt
        // Enable CPU INT4 which is connected to ECAP1-4 INT:
        IER |= M_INT4;
        EDIS;    // This is needed to disable write to EALLOW protected registers
    }*/
    //

}


/*===========================================================================================
    Function Name    : calculate_PI_Info_Simple
    Input            : 1.index: x
					   2.normal_state : normal high / low
					   3.current_state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void calculate_PI_Info_Simple ( uint8_t index, uint8_t normal_state, uint8_t current_state )
{
    Struct_PI_Basic *pulse = (Struct_PI_Basic *)&CG_PI.Channel[ index ];
	uint32_t i;

	//
	pulse->Cap[ 3 ] = pulse->ECapRegs->CAP4;
	pulse->Cap[ 2 ] = pulse->ECapRegs->CAP3;
	pulse->Cap[ 1 ] = pulse->ECapRegs->CAP2;
	pulse->Cap[ 0 ] = pulse->ECapRegs->CAP1;
	//

	/*		-----	-----	-----	-----
	 * 		|	|	|	|	|	|	|	|
	 * ------	-----	-----	-----	-----
	 *		1	2	3	4	1	2	3	4
	 */

	pulse->D_12 = (int32_t)( pulse->Cap[ 1 ] - pulse->Cap[ 0 ] );
	pulse->D_23 = (int32_t)( pulse->Cap[ 2 ] - pulse->Cap[ 1 ] );
	pulse->D_34 = (int32_t)( pulse->Cap[ 3 ] - pulse->Cap[ 2 ] );

	if( pulse->D_12 < 0 ){	// Cap1 is the newest point
		pulse->Peroid_Low = pulse->D_23;
		pulse->Peroid_High = pulse->D_34;
	}else if( pulse->D_23 < 0 ){	// Cap2 is the newest point
		pulse->Peroid_Low = pulse->Cap[ 0 ] - pulse->Cap[ 3 ];
		pulse->Peroid_High = pulse->D_34;
	}else{	// Cap3 or Cap4 is the newest point
		pulse->Peroid_Low = pulse->D_23;
		pulse->Peroid_High = pulse->D_12;
	}

	if( pulse->OldCap != pulse->Cap[ 0 ] ){
		pulse->ZeroCnt = 0;
	}

	pulse->OldCap = pulse->Cap[ 0 ];

	if( pulse->ZeroCnt < X1_PI_NO_SIGNAL_CNT ){

		if( pulse->Peroid_Low + pulse->Peroid_High != 0 ){
			pulse->Freq =  CPU_FREQ / ( pulse->Peroid_Low + pulse->Peroid_High );

			if( pulse->XH_Rising_Adj >= 0 ){
				if( pulse->Peroid_Low >= pulse->XH_Rising_Adj ){
					pulse->Peroid_Low -= pulse->XH_Rising_Adj;
					pulse->Peroid_High += pulse->XH_Rising_Adj;
				}else{
					pulse->Peroid_High = pulse->Peroid_Low + pulse->Peroid_High;
					pulse->Peroid_Low = 0;
				}
			}else{
				if( pulse->Peroid_High >= -1 * pulse->XH_Rising_Adj ){
					pulse->Peroid_Low -= pulse->XH_Rising_Adj;
					pulse->Peroid_High += pulse->XH_Rising_Adj;
				}else{
					pulse->Peroid_High = 0;
					pulse->Peroid_Low = pulse->Peroid_Low + pulse->Peroid_High;
				}
			}

			if( pulse->Peroid_High < PI_CONST ){
				pulse->Duty = pulse->Peroid_High * PI_DUTY_RESOLUTION / ( pulse->Peroid_Low + pulse->Peroid_High );
			}else{
				pulse->Duty =  ( pulse->Peroid_High >> 4 ) * PI_DUTY_RESOLUTION / ( ( pulse->Peroid_Low + pulse->Peroid_High ) >> 4 );
			}

			pulse->Lowside_Duty = PI_DUTY_RESOLUTION - pulse->Duty;

			pulse->Image_VR_Sum = pulse->Image_VR_Sum - pulse->Image_VR_Buffer[ pulse->Image_VR_Pointer ];

			if( normal_state == HIGH ){
				pulse->Image_VR_Buffer[ pulse->Image_VR_Pointer ] = pulse->Lowside_Duty;
				pulse->Pulse_Width = pulse->Peroid_Low;
			}else{
				pulse->Image_VR_Buffer[ pulse->Image_VR_Pointer ] = pulse->Duty;
				pulse->Pulse_Width = pulse->Peroid_High;
			}

			pulse->Image_VR_Sum = pulse->Image_VR_Sum + pulse->Image_VR_Buffer[ pulse->Image_VR_Pointer ];

			if( pulse->Ready == YES ){
				pulse->Image_VR = pulse->Image_VR_Sum / PI_BUFFER_SIZE;
			}else{
				pulse->Image_VR = 0;
			}

			if( ++pulse->Image_VR_Pointer >= PI_BUFFER_SIZE ){
				pulse->Image_VR_Pointer = 0;
				pulse->Ready = YES;
			}

		}

	}else{

		pulse->Freq = 0;
		pulse->Duty = current_state * PI_DUTY_RESOLUTION;
		pulse->Lowside_Duty = PI_DUTY_RESOLUTION - pulse->Duty;

		if( normal_state == HIGH ){
			pulse->Image_VR = pulse->Lowside_Duty;
		}else{
			pulse->Image_VR = pulse->Duty;
		}

		pulse->Pulse_Width = 0;

		for( i = 0; i < PI_BUFFER_SIZE; i++ ){
			pulse->Image_VR_Buffer[ i ] = 0;
		}
		pulse->Image_VR_Sum = 0;
		pulse->Ready = NO;
	}

	pulse->Image_VR_PFM = pulse->Freq * PULSE_MULTIFY;

}

/*===========================================================================================
    Function Name    : call_MainLoop_PI
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void call_MainLoop_PI ( void )
{
    //capPICMD_RoutineWork ( (Struct_PI_CMD*)&CG_PI.Motor_0, IO_X4_STAT, IO_X5_STAT, ( CG_GPIO.XnNormState_BITF >> 5 ) & 0x01 );
    /*
    if( CG_MD.HW_Ver == HW_VER_A ){
        capPICMD_RoutineWork ( (Struct_PI_CMD*)&CG_PI.Motor_1, IO_X6_STAT_VER_A, IO_X7_STAT, ( CG_GPIO.XnNormState_BITF >> 7 ) & 0x01 );
    }*/
}

/*===========================================================================================
    Function Name    : call_1ms_PI
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 1 ms time up event of PI.
//==========================================================================================*/
void call_1ms_PI ( void )
{
    int32_t i;

    for( i = 0; i < PI_NUM; i++ ){
        if( CG_PI.Channel[i].ZeroCnt < PI_NO_SIGNAL_CNT ){
            CG_PI.Channel[i].ZeroCnt++;
        }
    }

    // XH0 ~ XH3
	calculate_PI_Info_Simple ( PI_XH0, ( CG_GPIO.XnNormState_BITF >> 8 ) & 0x01, IO_XH0_STAT );
    calculate_PI_Info_Simple ( PI_XH1, ( CG_GPIO.XnNormState_BITF >> 9 ) & 0x01, IO_XH1_STAT );

    // M0C, M1C or M0S2, M1S2
    if( CG_BLDC_Drive_M0.Sensor_Type == SENSOR_TYPE_HALL ){
        CG_PI.Channel[PI_M0S2].Freq = 0;
        CG_PI.Channel[PI_M0S2].Duty = 0;
        CG_PI.Channel[PI_M0S2].Lowside_Duty = 0;
    }else{
        calculate_PI_Info_Simple ( PI_M0S2, MOTOR_FEEDBACK_NORMAL_STATE, MOTOR_S2_STATE_M0 );
        //CG_Encoder.Motor_0.Pos_PWM = CG_PI.Channel[PI_M0S2].Duty;
        CG_Encoder.Motor_0.Pos_PWM = CG_PI.Channel[PI_M0S2].Lowside_Duty;
    }

    /*
    if( CG_BLDC_Drive_M1.Sensor_Type == SENSOR_TYPE_HALL ){
        CG_PI.Channel[PI_M1S2].Freq = 0;
        CG_PI.Channel[PI_M1S2].Duty = 0;
        CG_PI.Channel[PI_M1S2].Lowside_Duty = 0;
    }else{
        calculate_PI_Info_Simple ( PI_M1S2, MOTOR_FEEDBACK_NORMAL_STATE, MOTOR_S2_STATE_M1 );
        //CG_Encoder.Motor_1.Pos_PWM = CG_PI.Channel[PI_M1S2].Duty;
        CG_Encoder.Motor_1.Pos_PWM = CG_PI.Channel[PI_M1S2].Lowside_Duty;
    }
    */

    if( CG_PI.Motor_0.Timeout_Cnt < 65535 ){
        CG_PI.Motor_0.Timeout_Cnt++;
    }

    /*
    if( CG_PI.Motor_1.Timeout_Cnt < 65535 ){
        CG_PI.Motor_1.Timeout_Cnt++;
    }*/

}

/*===========================================================================================
    Function Name    : call_100ms_PI
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 10 ms time up event of PI.
//==========================================================================================*/
void call_100ms_PI ( void )
{
    //capPICMD_Latch ( (Struct_PI_CMD*)&CG_PI.Motor_0 );
    //capPICMD_Latch ( (Struct_PI_CMD*)&CG_PI.Motor_1 );
}

/*===========================================================================================
    Function Name    : capPICMD_Init
    Input            : 1.pi_cmd
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void capPICMD_Init ( Struct_PI_CMD *pi_cmd )
{
    pi_cmd->IOState_Old = 0xFF;
    pi_cmd->Direction = -1;
    pi_cmd->Direction_Old = pi_cmd->Direction;
    pi_cmd->Pos = 0;
    pi_cmd->Freq = 0;

    pi_cmd->DirCnt = 0;
    pi_cmd->Cnt = 0;
    pi_cmd->Cnt_Latch = 0;

    pi_cmd->Type_PA = PI_TYPE_2_PULSE;
    pi_cmd->Timeout_PA = CONST_PI_TIMEOUT;
    pi_cmd->Timeout_Cnt = 0;

    pi_cmd->IOState_If_CW = 0xFF;
    pi_cmd->IOState_If_CCW = 0xFF;
}

/*===========================================================================================
    Function Name    : capPICMD_RoutineWork
    Input            : 1.pi_cmd
                       2.state_a
                       3.state_b
                       4.normal_state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void capPICMD_RoutineWork ( Struct_PI_CMD *pi_cmd, uint8_t state_a, uint8_t state_b, uint8_t normal_state )
{
    uint8_t dir_state;
    uint8_t is_cw;
    uint8_t is_ccw;

    if( pi_cmd->Type_PA == PI_TYPE_2_PULSE ){
        pi_cmd->IOState = ( ( state_b << 1 ) | state_a ) & 0x03;
        is_cw = ( pi_cmd->IOState == pi_cmd->IOState_If_CW );
        is_ccw = ( pi_cmd->IOState == pi_cmd->IOState_If_CCW );

        pi_cmd->IOState_If_CW = Const_PI_NextState_Table_CW[ DIR_CW ][ pi_cmd->IOState ];
        pi_cmd->IOState_If_CCW = Const_PI_NextState_Table_CW[ DIR_CCW ][ pi_cmd->IOState ];
    }else{
        pi_cmd->IOState = ( state_a ) & 0x01;
        dir_state = state_b;

        is_cw = dir_state == normal_state;
        is_ccw = dir_state != normal_state;
    }

    if( pi_cmd->IOState != pi_cmd->IOState_Old ){
        pi_cmd->Timeout_Cnt = 0;

        if( is_cw ){
            pi_cmd->Direction = DIR_CW;
            pi_cmd->Cnt++;

            if( pi_cmd->Direction_Old != pi_cmd->Direction ){
                pi_cmd->DirCnt = 1;
            }else if( pi_cmd->DirCnt < 65535 ){
                pi_cmd->DirCnt++;
            }
        }else if( is_ccw ){
            pi_cmd->Direction = DIR_CCW;
            pi_cmd->Cnt--;

            if( pi_cmd->Direction_Old != pi_cmd->Direction ){
                pi_cmd->DirCnt = -1;
            }else if( pi_cmd->DirCnt > -65535 ){
                pi_cmd->DirCnt--;
            }
        }
    }else if( pi_cmd->Timeout_Cnt > pi_cmd->Timeout_PA ){
        pi_cmd->DirCnt = 0;
    }

    pi_cmd->IOState_Old = pi_cmd->IOState;
    pi_cmd->Direction_Old = pi_cmd->Direction;

}

/*===========================================================================================
    Function Name    : capPICMD_Latch
    Input            : 1.pi_cmd
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void capPICMD_Latch ( Struct_PI_CMD *pi_cmd )
{
    pi_cmd->Cnt_Latch = pi_cmd->Cnt;
    pi_cmd->Cnt = 0;

}

/************************** <END OF FILE> *****************************************/

