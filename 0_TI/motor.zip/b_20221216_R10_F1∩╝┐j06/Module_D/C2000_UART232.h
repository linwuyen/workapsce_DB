/*
 * C2000_UART232.h
 *
 *  Created on: 2015/4/15
 *      Author: chaim.chen
 */

#ifndef C2000_UART232_H_
#define C2000_UART232_H_

/*  Trunmman Technology Corporation. All rights reserved. */

//#include "IncludeFiles.h"



#define LSPCLK_FREQ CPU_FREQ/4
#define SCI_PRD     (LSPCLK_FREQ/(SCI_FREQ*8))-1


#define ModBus		1


#if ( ModBus )
#define START_BYTE 	58
#define CR_BYTE		13
#define END_BYTE	10
#endif

enum {

    UART_READY       = 0,
    UART_BUSY        = 1,
    UART_DONE        = 2,
    UART_STATE_NUM   = 3

};


#define UART_BUFFER_SIZE	200


typedef struct{

    unsigned char R_data_buffer[ UART_BUFFER_SIZE ];
    unsigned char T_data_buffer[ UART_BUFFER_SIZE ];

    unsigned char T_data_pointer;
    unsigned char R_data_pointer;

    unsigned char T_data_length;

    unsigned char request_to_send_data_flag;

    //unsigned char TxEmpty;
	unsigned char ReceiveFlag;

	unsigned char time_out_flag;
    int32_t  		time_out_cnt;
	uint32_t 		R_data_number;

	uint8_t 		modbus_mode;
	uint8_t  		get_data_flag;
	uint32_t 		rtu_time_point_1;
	uint32_t 		rtu_time_point_2;
	uint32_t 		rtu_time_frame_length;

}Struct_UART;



/*===========================================================================================
    Function Name    : variableInitial_UART
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_UART initial
//==========================================================================================*/
void varibleInitial_UART( void );

/*===========================================================================================
    Function Name    : setupInitial_UART
    Input            :
					   1.baudrate : baudrate number of the UART.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : UART initialzation function.
					   For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_UART( unsigned long baudrate);

/*===========================================================================================
    Function Name    : sciaRxFifoIsr
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : The UART( UART0 ) IRQ event
//==========================================================================================*/
__interrupt void sciaRxFifoIsr(void);

/*===========================================================================================
    Function Name    : checkUARTSend
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Check if the UART data transmit commmand has been set then decide if it
					   needs to send output data.
					   For previous version please check oringial A04 or A09 MDB code.
					   *Avoid using while loop.
//==========================================================================================*/
void checkUARTSend( void );

/*===========================================================================================
    Function Name    : checkUARTframe_232
    Input            : Null
    Return           : Null
    Programmer       : Eric.Tsai@trumman.com.tw
					   Modified by Chaum.Chen@trumman.com.tw
    Description      : For RTU
//==========================================================================================*/
 void checkRTUframe_232( void );



#endif /* F280XX_UART232_H_ */


 /************************** <END OF FILE> *****************************************/



