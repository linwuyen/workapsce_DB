/*===========================================================================================

    File Name       : I04_GPIO.h

    Version         : V1_00_00_a

    Built Date      : 2020/06/22

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : This file provides the functions for GPIO.

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */


#ifndef GPIO_H
#define GPIO_H

#include "IncludeFiles.h"

#define HALL_U_M0			56
#define HALL_V_M0			57
#define HALL_W_M0			59

/*
#define HALL_U_M1			14
#define HALL_V_M1			15
#define HALL_W_M1			26
*/

#define MOTOR_S2_M0         39
//#define MOTOR_S2_M1         40

#define HALL_U_STATE_M0     ( GpioDataRegs.GPBDAT.bit.GPIO56 )
#define HALL_V_STATE_M0     ( GpioDataRegs.GPBDAT.bit.GPIO57 )
#define HALL_W_STATE_M0     ( GpioDataRegs.GPBDAT.bit.GPIO59 )

#define MOTOR_S0_STATE_M0  ( GpioDataRegs.GPHDAT.bit.GPIO233 )
#define MOTOR_S1_STATE_M0  ( GpioDataRegs.GPHDAT.bit.GPIO234 )
#define MOTOR_S2_STATE_M0   ( GpioDataRegs.GPBDAT.bit.GPIO39 )

/*
#define HALL_U_STATE_M1     ( GpioDataRegs.GPADAT.bit.GPIO14 )
#define HALL_V_STATE_M1     ( GpioDataRegs.GPADAT.bit.GPIO15 )
#define HALL_W_STATE_M1     ( GpioDataRegs.GPADAT.bit.GPIO26 )

#define MOTOR_S0_STATE_M1  ( GpioDataRegs.GPHDAT.bit.GPIO242 )
#define MOTOR_S1_STATE_M1  ( GpioDataRegs.GPHDAT.bit.GPIO244 )
#define MOTOR_S2_STATE_M1   ( GpioDataRegs.GPBDAT.bit.GPIO40 )
*/

//#define HALL_SIGNAL 	 	( ( HALL_W_STATE << 2 ) | ( HALL_V_STATE << 1 ) | ( HALL_U_STATE << 0 ) )
//#define HALL_SIGNAL_CONST	2

#define HALL_SIGNAL_M0      ( ( HALL_W_STATE_M0 << 2 ) | ( HALL_V_STATE_M0 << 1 ) | ( HALL_U_STATE_M0 << 0 ) )
//#define HALL_SIGNAL_M1      ( ( HALL_W_STATE_M1 << 2 ) | ( HALL_V_STATE_M1 << 1 ) | ( HALL_U_STATE_M1 << 0 ) )

#define MOTOR_S2S1S0_SIGNAL_M0      ( ( MOTOR_S2_STATE_M0 << 2 ) | ( MOTOR_S1_STATE_M0 << 1 ) | ( MOTOR_S0_STATE_M0 << 0 ) )
//#define MOTOR_S2S1S0_SIGNAL_M1      ( ( MOTOR_S2_STATE_M1 << 2 ) | ( MOTOR_S1_STATE_M1 << 1 ) | ( MOTOR_S0_STATE_M1 << 0 ) )

/*===========================================================================================
    Digital Input control Macros
//==========================================================================================*/


#define IO_NUM  16

#define IO_X0_STAT	( GpioDataRegs.GPHDAT.bit.GPIO237 ) // X0
#define IO_X1_STAT	( GpioDataRegs.GPHDAT.bit.GPIO238 ) // X1
#define IO_X2_STAT  ( GpioDataRegs.GPHDAT.bit.GPIO244 ) // X2
#define IO_X3_STAT  ( GpioDataRegs.GPHDAT.bit.GPIO225 ) // X3
#define IO_X4_STAT  ( GpioDataRegs.GPADAT.bit.GPIO10 )  // X4
#define IO_X5_STAT  ( GpioDataRegs.GPHDAT.bit.GPIO246 ) // X5-KeyIn

#define IO_X6_STAT  ( CG_ADC.Value_Avg[ ADC_Index_A0X ] < ADC_LIMIT_VALUE / 8 ) // A0X
#define IO_X7_STAT  ( CG_ADC.Value_Avg[ ADC_Index_A1X ] < ADC_LIMIT_VALUE / 8 ) // A1X

#define IO_X8_STAT  ( GpioDataRegs.GPADAT.bit.GPIO14 )  // XH0
#define IO_X9_STAT  ( GpioDataRegs.GPADAT.bit.GPIO15 )  // XH1

#define IO_X10_STAT  ( GpioDataRegs.GPHDAT.bit.GPIO227 ) // STO1
#define IO_X11_STAT  ( GpioDataRegs.GPHDAT.bit.GPIO239 ) // STO2

#define IO_X12_STAT  ( 0x00 )
#define IO_X13_STAT  ( 0x00 )
#define IO_X14_STAT  ( 0x00 )
#define IO_X15_STAT  ( 0x00 )


#define IO_XH0_STAT  IO_X8_STAT
#define IO_XH1_STAT  IO_X9_STAT


//#define XH_STATE	IO_X6_STAT
//#define XH_INDEX	5

enum{
    OTHER_INPUT_S0_TEMP = 0,
    OTHER_INPUT_M_ER    = 1,
    OTHER_INPUT_NUM     = 2
};


#define IO_S0_TEMP_STAT     ( MOTOR_S0_STATE_M0 )
#define IO_M_ER_STAT        ( GpioDataRegs.GPADAT.bit.GPIO25 )

/*===========================================================================================
    Digital Output control Macros
//==========================================================================================*/
//#define OUTPUT_NUM				7
enum {
    OUTPUT_Y0           = 0,
    OUTPUT_Y1           = 1,
    OUTPUT_Y2           = 2,
    OUTPUT_Y3           = 3,
    OUTPUT_Y4           = 4, // POUT_0
    OUTPUT_Y5           = 5, // POUT_1
    OUTPUT_Y6           = 6, // POUT_PWR

    OUTPUT_NUM          = 7
};

enum {
    OUT_TYPE_GPIO       = 0,
    OUT_TYPE_PWM        = 1,
    OUT_TYPE_NUM        = 2
};

enum{

    OTHER_OUTPUT_DI_5V          = 0,
    OTHER_OUTPUT_CAN_EN         = 1,
    OTHER_OUTPUT_VCC12V_CTRL    = 2,

    OTHER_OUTPUT_HALL_PH        = 3,
    OTHER_OUTPUT_EN_5V          = 4,

    OTHER_OUTPUT_ALARM_LED      = 5,
    OTHER_OUTPUT_STA_LED        = 6,

    OTHER_OUTPUT_NUM            = 7
};

// Y0
#define SET_AS_OUTPUT_Y0		GpioCtrlRegs.GPBDIR.bit.GPIO37 = 1; GpioCtrlRegs.GPBPUD.bit.GPIO37 = 0
#define IO_Y0_ON				( GpioDataRegs.GPBSET.bit.GPIO37 = 1 )
#define IO_Y0_OFF				( GpioDataRegs.GPBCLEAR.bit.GPIO37 = 1 )
#define IO_Y0_TOGGLE			( GpioDataRegs.GPBTOGGLE.bit.GPIO37 = 1 )

// Y1
#define SET_AS_OUTPUT_Y1        GpioCtrlRegs.GPADIR.bit.GPIO17 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0
#define IO_Y1_ON                ( GpioDataRegs.GPASET.bit.GPIO17 = 1 )
#define IO_Y1_OFF               ( GpioDataRegs.GPACLEAR.bit.GPIO17 = 1 )
#define IO_Y1_TOGGLE            ( GpioDataRegs.GPATOGGLE.bit.GPIO17 = 1 )

// Y2
#define SET_AS_OUTPUT_Y2        GpioCtrlRegs.GPADIR.bit.GPIO11 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO11 = 0
#define IO_Y2_ON                ( GpioDataRegs.GPASET.bit.GPIO11 = 1 )
#define IO_Y2_OFF               ( GpioDataRegs.GPACLEAR.bit.GPIO11 = 1 )
#define IO_Y2_TOGGLE            ( GpioDataRegs.GPATOGGLE.bit.GPIO11 = 1 )

// Y3Y4
#define SET_AS_OUTPUT_Y3Y4      GpioCtrlRegs.GPADIR.bit.GPIO9 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO9 = 0; \
                                GpioCtrlRegs.GPBDIR.bit.GPIO40 = 1; GpioCtrlRegs.GPBPUD.bit.GPIO40 = 0


// Y3
//#define SET_AS_OUTPUT_Y3        GpioCtrlRegs.GPADIR.bit.GPIO9 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO9 = 0
#define IO_Y3_ON_A              ( GpioDataRegs.GPASET.bit.GPIO9 = 1 )
#define IO_Y3_OFF_A             ( GpioDataRegs.GPACLEAR.bit.GPIO9 = 1 )
#define IO_Y3_TOGGLE_A          ( GpioDataRegs.GPATOGGLE.bit.GPIO9 = 1 )

#define IO_Y3_ON_B              ( GpioDataRegs.GPBSET.bit.GPIO40 = 1 )
#define IO_Y3_OFF_B             ( GpioDataRegs.GPBCLEAR.bit.GPIO40 = 1 )
#define IO_Y3_TOGGLE_B          ( GpioDataRegs.GPBTOGGLE.bit.GPIO40 = 1 )

// POUT_0
//#define SET_AS_OUTPUT_Y4        GpioCtrlRegs.GPBDIR.bit.GPIO40 = 1; GpioCtrlRegs.GPBPUD.bit.GPIO40 = 0
#define IO_Y4_HIGH_A              ( GpioDataRegs.GPBSET.bit.GPIO40 = 1 )
#define IO_Y4_LOW_A               ( GpioDataRegs.GPBCLEAR.bit.GPIO40 = 1 )
#define IO_Y4_ON_A                IO_Y4_LOW_A
#define IO_Y4_OFF_A               IO_Y4_HIGH_A
#define IO_Y4_TOGGLE_A            ( GpioDataRegs.GPBTOGGLE.bit.GPIO40 = 1 )

#define IO_Y4_HIGH_B              ( GpioDataRegs.GPASET.bit.GPIO9 = 1 )
#define IO_Y4_LOW_B               ( GpioDataRegs.GPACLEAR.bit.GPIO9 = 1 )
#define IO_Y4_ON_B                IO_Y4_LOW_B
#define IO_Y4_OFF_B               IO_Y4_HIGH_B
#define IO_Y4_TOGGLE_B            ( GpioDataRegs.GPATOGGLE.bit.GPIO9 = 1 )

#define PWM_Y4_ON_A               //GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 1; GpioCtrlRegs.GPBGMUX2.bit.GPIO58 = 1
#define PWM_Y4_OFF_A              //GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 0; GpioCtrlRegs.GPBGMUX2.bit.GPIO58 = 0

#define PWM_Y4_ON_B               GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 3//; GpioCtrlRegs.GPAGMUX1.bit.GPIO9 = 0
#define PWM_Y4_OFF_B              GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 0//; GpioCtrlRegs.GPAGMUX1.bit.GPIO9 = 0


// POUT_1
#define SET_AS_OUTPUT_Y5        GpioCtrlRegs.GPBDIR.bit.GPIO58 = 1; GpioCtrlRegs.GPBPUD.bit.GPIO58 = 0
#define IO_Y5_HIGH              ( GpioDataRegs.GPBSET.bit.GPIO58 = 1 )
#define IO_Y5_LOW               ( GpioDataRegs.GPBCLEAR.bit.GPIO58 = 1 )
#define IO_Y5_ON                IO_Y5_LOW
#define IO_Y5_OFF               IO_Y5_HIGH
#define IO_Y5_TOGGLE            ( GpioDataRegs.GPBTOGGLE.bit.GPIO58 = 1 )

#define PWM_Y5_ON               GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 1; GpioCtrlRegs.GPBGMUX2.bit.GPIO58 = 1
#define PWM_Y5_OFF              GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 0; GpioCtrlRegs.GPBGMUX2.bit.GPIO58 = 0

// POUT_POW
#define SET_AS_OUTPUT_Y6        GpioCtrlRegs.GPADIR.bit.GPIO8 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO8 = 0
#define IO_Y6_ON                ( GpioDataRegs.GPASET.bit.GPIO8 = 1 )
#define IO_Y6_OFF               ( GpioDataRegs.GPACLEAR.bit.GPIO8 = 1 )
#define IO_Y6_TOGGLE            ( GpioDataRegs.GPATOGGLE.bit.GPIO8 = 1 )


#define OTHER_OUTPUT_ACT_BITF_INIT      0xFFFF

// EN_5V : This 5V provides power to Hall and Encoder
#define SET_AS_OUTPUT_EN_5V     GpioCtrlRegs.GPADIR.bit.GPIO30 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO30 = 0
#define IO_EN_5V_ON             ( GpioDataRegs.GPASET.bit.GPIO30 = 1 )
#define IO_EN_5V_OFF            ( GpioDataRegs.GPACLEAR.bit.GPIO30 = 1 )
//#define IO_EN_5V_TOGGLE         ( GpioDataRegs.GPATOGGLE.bit.GPIO30 = 1 )

// DI_5V : This 5V provides power to Xn ( That is : users can short Xn and 0V to make Xn = On )
#define SET_AS_OUTPUT_DI_5V     GpioCtrlRegs.GPADIR.bit.GPIO31 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO31 = 0
#define IO_DI_5V_ON             ( GpioDataRegs.GPASET.bit.GPIO31 = 1 )
#define IO_DI_5V_OFF            ( GpioDataRegs.GPACLEAR.bit.GPIO31 = 1 )
//#define IO_DI_5V_TOGGLE         ( GpioDataRegs.GPATOGGLE.bit.GPIO31 = 1 )


// VCC_12V_CTRL : J06 Power structure
// The Vcc12V is coming from 5V, we and use this pin to ctrl Vcc12V
#define SET_AS_OUTPUT_VCC_12V_CTRL  GpioCtrlRegs.GPADIR.bit.GPIO26 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0
#define IO_VCC_12V_CTRL_ON          ( GpioDataRegs.GPASET.bit.GPIO26 = 1 )
#define IO_VCC_12V_CTRL_OFF         ( GpioDataRegs.GPACLEAR.bit.GPIO26 = 1 )
//#define IO_VCC_12V_CTRL_TOGGLE      ( GpioDataRegs.GPATOGGLE.bit.GPIO26 = 1 )

// CAN_EN :
#define SET_AS_OUTPUT_CAN_EN     GpioCtrlRegs.GPADIR.bit.GPIO16 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO16 = 0
#define IO_CAN_EN_ON             ( GpioDataRegs.GPASET.bit.GPIO16 = 1 )
#define IO_CAN_EN_OFF            ( GpioDataRegs.GPACLEAR.bit.GPIO16 = 1 )
//#define IO_CAN_EN_TOGGLE         ( GpioDataRegs.GPATOGGLE.bit.GPIO16 = 1 )

/*===========================================================================================
    Other Macros
//==========================================================================================*/
#define SET_AS_OUTPUT_BUSV_RELAY	//( GpioCtrlRegs.GPADIR.bit.GPIO30 = 1 )
#define BUSV_RELAY_ON				//( GpioDataRegs.GPASET.bit.GPIO30 = 1 )
#define BUSV_RELAY_OFF				//( GpioDataRegs.GPACLEAR.bit.GPIO30 = 1 )

#define SET_AS_OUTPUT_RUN_LED       GpioCtrlRegs.GPADIR.bit.GPIO23 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO23 = 0
#define RUN_LED_HIGH                ( GpioDataRegs.GPASET.bit.GPIO23 = 1 )
#define RUN_LED_LOW                 ( GpioDataRegs.GPACLEAR.bit.GPIO23 = 1 )
#define RUN_LED_ON                  RUN_LED_HIGH
#define RUN_LED_OFF                 RUN_LED_LOW
//#define RUN_LED_TOGGLE              ( GpioDataRegs.GPATOGGLE.bit.GPIO23 = 1 )

#define SET_AS_OUTPUT_ALARM_LED     SET_AS_OUTPUT_RUN_LED//( GpioCtrlRegs.GPADIR.bit.GPIO23 = 1 )
#define ALARM_LED_ON                RUN_LED_ON//( GpioDataRegs.GPASET.bit.GPIO23 = 1 )
#define ALARM_LED_OFF               RUN_LED_OFF//( GpioDataRegs.GPACLEAR.bit.GPIO23 = 1 )
//#define ALARM_LED_TOGGLE            RUN_LED_TOGGLE//( GpioDataRegs.GPATOGGLE.bit.GPIO23 = 1 )

#define PWRLED_FLASH_PULSE_WIDTH		100

#define SET_AS_OUTPUT_COM_LED       GpioCtrlRegs.GPADIR.bit.GPIO24 = 1; GpioCtrlRegs.GPAPUD.bit.GPIO24 = 0
#define COM_LED_HIGH                ( GpioDataRegs.GPASET.bit.GPIO24 = 1 )
#define COM_LED_LOW                 ( GpioDataRegs.GPACLEAR.bit.GPIO24 = 1 )

#define COM_LED_ON                  COM_LED_HIGH
#define COM_LED_OFF                 COM_LED_LOW
//#define COM_LED_TOGGLE              ( GpioDataRegs.GPATOGGLE.bit.GPIO24 = 1 )

typedef struct{

    uint16_t Xn_State_BITF;                                  // I/O state.
    uint16_t XnNormState_BITF;                               // I/O active state.

    uint16_t Yn_State_BITF_MCU;                              // I/O state.
    uint16_t Yn_State_BITF;                                  // I/O state.
    uint16_t YnActState_BITF;                                // I/O active state.

	uint16_t PwrLED_Timer;

	//
    uint8_t  Out1_Type;
    uint8_t  Out1_IsDependsOnBusV;
    uint8_t  Out1_Pwm_Flag;
    uint8_t  Out1_PwmTimer_Flag;
    uint16_t Out1_PwmTimeMs_Pa;
    uint16_t Out1_PwmTimerMs;


    uint8_t  Out2_Type;
    uint8_t  Out2_IsDependsOnBusV;
    uint8_t  Out2_Pwm_Flag;
    uint8_t  Out2_PwmTimer_Flag;
    uint16_t Out2_PwmTimeMs_Pa;
    uint16_t Out2_PwmTimerMs;

    //
    uint16_t OtherInput_State_BITF;                                     // I/O state.


    uint16_t OtherOutput_State_BITF;                                   // I/O state.
    uint16_t OtherOutput_ActState_BITF;                                // I/O active state.

	//
	uint8_t	TestState;

}Struct_GPIO;



/*===========================================================================================
    Function Name    : variableInitial_GPIO
    Input            : gpio
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_GPIO initial
//==========================================================================================*/
void variableInitial_GPIO ( Struct_GPIO * gpio );

/*===========================================================================================
    Function Name    : otherGPIO_SetOutput
    Input            : 1.index
                       2.state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void otherGPIO_SetOutput( int32_t index, int32_t state );


/*===========================================================================================
    Function Name    : otherGPIO_ToggleOutput
    Input            : 1.index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void otherGPIO_ToggleOutput( int32_t index );

/*===========================================================================================
    Function Name    : polling_GPIO
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : GPIO polling
//==========================================================================================*/
void polling_GPIO ( Struct_GPIO * gpio );

/*===========================================================================================
    Function Name    : initIOPorts
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Initialize I/O Port.
//==========================================================================================*/
void initIOPorts (void);

/*===========================================================================================
    Function Name    : setupInitial_GPIO
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : GPIO initialization
//==========================================================================================*/
void setupInitial_GPIO ( void );

/*===========================================================================================
    Function Name    : gpioXHFilter_Setup
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void gpioXHFilter_Setup (void);

/*===========================================================================================
    Function Name    : initHallSensor_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Initialize Hall sensor interrupt settings
//==========================================================================================*/
void initHallSensor_M0 (void);

/*===========================================================================================
    Function Name    : initHallSensor_M1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Initialize Hall sensor interrupt settings
//==========================================================================================*/
//void initHallSensor_M1 (void);

/*===========================================================================================
    Function Name    : initHallSensor
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Initialize Hall sensor interrupt settings
//==========================================================================================*/
//void initHallSensor (void);

/*===========================================================================================
    Function Name    : hall_Prepare_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_Prepare_M0 (void);

/*===========================================================================================
    Function Name    : hall_Prepare_M1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
//void hall_Prepare_M1 (void);

/*===========================================================================================
    Function Name    : hall_Ready_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_Ready_M0 (void);

/*===========================================================================================
    Function Name    : hall_Ready_M1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
//void hall_Ready_M1 (void);

/*===========================================================================================
    Function Name    : xint1_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT1 IRQ event
//==========================================================================================*/
__interrupt void xint1_isr (void);

/*===========================================================================================
    Function Name    : xint2_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT1 IRQ event
//==========================================================================================*/
__interrupt void xint2_isr (void);

#if(0)
/*===========================================================================================
    Function Name    : xint3_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT1 IRQ event
//==========================================================================================*/
__interrupt void xint3_isr (void);

/*===========================================================================================
    Function Name    : xint4_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT4 IRQ event
//==========================================================================================*/
__interrupt void xint4_isr (void);
#endif

/*===========================================================================================
    Function Name    : ecap5_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__interrupt void ecap5_isr(void);

/*===========================================================================================
    Function Name    : ecap6_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
//__interrupt void ecap6_isr(void);

#if(TEST_FAKE_HALL_SENSOR)
/*===========================================================================================
    Function Name    : gpio_FakeHallSensor
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void gpio_FakeHallSensor(void);
#endif

#endif

/************************** <END OF FILE> *****************************************/
