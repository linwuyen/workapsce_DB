/*===========================================================================================

    File Name       : I04_GPIO.c

    Version         : V1_00_00_a

    Built Date      : 2020/06/22

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : This file provides the functions for GPIO.

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile 		Struct_GPIO 				CG_GPIO;

extern volatile Struct_HallSensor           CG_Hall_M0;
//extern volatile Struct_HallSensor           CG_Hall_M1;

extern volatile Struct_BLDC_CTRL 			CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL            CG_BLDC_CTRL_M1;

extern volatile Struct_MD 					CG_MD;
extern volatile Struct_HWEEP				CG_HWEEP;
extern volatile Struct_ADC                  CG_ADC;
extern volatile Struct_Parameter            CG_Parameter;
extern volatile Struct_BLDC_Drive           CG_BLDC_Drive_M0;
//extern volatile Struct_BLDC_Drive           CG_BLDC_Drive_M1;


extern void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void );

#if(0)
//#pragma CODE_SECTION( xint1_isr, "ramfuncs");
//#pragma CODE_SECTION( xint2_isr, "ramfuncs");
//#pragma CODE_SECTION( xint3_isr, "ramfuncs");
//#pragma CODE_SECTION( xint4_isr, "ramfuncs");
#pragma CODE_SECTION( xint1_isr, ".TI.ramfunc" );
#pragma CODE_SECTION( xint2_isr, ".TI.ramfunc" );
#pragma CODE_SECTION( xint3_isr, ".TI.ramfunc" );
#pragma CODE_SECTION( xint4_isr, ".TI.ramfunc" );
#endif

/*===========================================================================================
    Function Name    : variableInitial_GPIO
    Input            : gpio
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_GPIO initial
//==========================================================================================*/
void variableInitial_GPIO ( Struct_GPIO * gpio )
{
    CG_GPIO.PwrLED_Timer = 0;

    CG_GPIO.TestState = 0;

    //
    gpio->XnNormState_BITF          = 0xFFFF;
    gpio->Xn_State_BITF = 0;

    gpio->Yn_State_BITF_MCU = 0;

    gpio->OtherOutput_State_BITF = 0;


    //gpio->HallState = 0;
    //gpio->OT_State = 0;

    //gpio->TestState = 0;

    //
    gpio->Out1_Pwm_Flag = NO;
    gpio->Out2_Pwm_Flag = NO;
    gpio->Out1_PwmTimer_Flag = NO;
    gpio->Out2_PwmTimer_Flag = NO;

    gpio->Out1_PwmTimerMs = 0;
    gpio->Out2_PwmTimerMs = 0;

    gpio->Out1_IsDependsOnBusV = NO;
    gpio->Out2_IsDependsOnBusV = NO;

}

/*===========================================================================================
    Function Name    : otherGPIO_SetOutput
    Input            : 1.index
                       2.state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void otherGPIO_SetOutput( int32_t index, int32_t state )
{
    int32_t act_state = ( CG_GPIO.OtherOutput_ActState_BITF >> index ) & 0x01;
    //  state,  act state, final
    //      1,          1, >> 1
    //      1,          0, >> 0
    //      0,          1, >> 0
    //      0,          0, >> 1
    state = 1 - ( act_state ^ state );

    if( state ){
        CG_GPIO.OtherOutput_State_BITF |=  ( 1 << index );
    }else{
        CG_GPIO.OtherOutput_State_BITF &= ~( 1 << index );
    }
}

/*===========================================================================================
    Function Name    : otherGPIO_ToggleOutput
    Input            : 1.index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void otherGPIO_ToggleOutput( int32_t index )
{
    if( ( CG_GPIO.OtherOutput_State_BITF >> index ) & 0x01 ){
        CG_GPIO.OtherOutput_State_BITF &= ~( 1 << index );
    }else{
        CG_GPIO.OtherOutput_State_BITF |=  ( 1 << index );
    }
}


/*===========================================================================================
    Function Name    : polling_GPIO
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : GPIO polling
//==========================================================================================*/
void polling_GPIO ( Struct_GPIO * gpio )
{
    uint32_t other_output = CG_GPIO.OtherOutput_State_BITF;

	// Use XOR logic op. to get Xn value.
    gpio->Xn_State_BITF = ( ( IO_X0_STAT << 0 ) | ( IO_X1_STAT << 1 ) | ( IO_X2_STAT << 2 ) | ( IO_X3_STAT << 3 ) |
                            ( IO_X4_STAT << 4 ) | ( IO_X5_STAT << 5 ) | ( IO_X6_STAT << 6 ) | ( IO_X7_STAT << 7 ) |
                            ( IO_X8_STAT << 8 ) | ( IO_X9_STAT << 9 ) | ( IO_X10_STAT << 10 ) | ( IO_X11_STAT << 11 ) |
                            ( IO_X12_STAT << 12 ) | ( IO_X13_STAT << 13 ) | ( IO_X14_STAT << 14 ) | ( IO_X15_STAT << 15 ) ) ^ gpio->XnNormState_BITF;


    gpio->OtherInput_State_BITF = ( IO_S0_TEMP_STAT << OTHER_INPUT_S0_TEMP ) |
                                  ( IO_M_ER_STAT << OTHER_INPUT_M_ER );


    // OTHER_OUTPUT_HALL_PH
    if( ( other_output >> OTHER_OUTPUT_HALL_PH ) & 0x01 ){
        setValue_DACB( ADC_MAX_VALUE );
    }else{
        setValue_DACB( ADC_MIN_VALUE );
    }

    // OTHER_OUTPUT_EN_5V
    if( ( other_output >> OTHER_OUTPUT_EN_5V ) & 0x01 ){
        IO_EN_5V_ON;
    }else{
        IO_EN_5V_OFF;
    }

    // OTHER_OUTPUT_DI_5V
    if( ( other_output >> OTHER_OUTPUT_DI_5V ) & 0x01 ){
        IO_DI_5V_ON;
    }else{
        IO_DI_5V_OFF;
    }

    // OTHER_OUTPUT_VCC12V_CTRL
    if( ( other_output >> OTHER_OUTPUT_VCC12V_CTRL ) & 0x01 ){
        IO_VCC_12V_CTRL_ON;
    }else{
        IO_VCC_12V_CTRL_OFF;
    }


    // OTHER_OUTPUT_ALARM_LED
    if( ( other_output >> OTHER_OUTPUT_ALARM_LED ) & 0x01 ){
        ALARM_LED_ON;
    }else{
        ALARM_LED_OFF;
    }

    // OTHER_OUTPUT_STA_LED
    if( ( other_output >> OTHER_OUTPUT_STA_LED ) & 0x01 ){
        COM_LED_ON;
    }else{
        COM_LED_OFF;
    }

    // OTHER_OUTPUT_CAN_EN
    if( ( other_output >> OTHER_OUTPUT_CAN_EN ) & 0x01 ){
        IO_CAN_EN_ON;
    }else{
        IO_CAN_EN_OFF;
    }

}


/*===========================================================================================
    Function Name    : initIOPorts
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Initialize I/O Port.
//==========================================================================================*/
void initIOPorts (void)
{
#if(1)
    // Set Y0 = TDO, YH1 = TDI
    GPIO_SetupPinMux( 37, GPIO_MUX_CPU1, 15 );
    GPIO_SetupPinMux( 35, GPIO_MUX_CPU1, 15 );

    //GPIO_SetupPinMux(58, GPIO_MUX_CPU1, 5); // Output Xbar 4
    //GPIO_SetupPinMux(33, GPIO_MUX_CPU1, 5); // Output Xbar 1

	EALLOW;
    // The default value of FIODIR is 0, which means GPIO as input
    // Set FIODIR to 1 will make GPIO as output.
	//GpioCtrlRegs.GPAPUD.bit.GPIO12 = 0;    // Enable pull-up for GPIO12 (X1)

	SET_AS_OUTPUT_Y0;
	SET_AS_OUTPUT_Y1;
	SET_AS_OUTPUT_Y2;
	//SET_AS_OUTPUT_Y3;
	//SET_AS_OUTPUT_Y4;
	SET_AS_OUTPUT_Y3Y4;
	SET_AS_OUTPUT_Y5;
	SET_AS_OUTPUT_Y6;

	IO_Y0_OFF;
	IO_Y1_OFF;
	IO_Y2_OFF;
#if( HW_VERSION == HW_VERSION_A )
	IO_Y3_OFF_A;
	IO_Y4_OFF_A;
#else
	IO_Y3_OFF_B;
	IO_Y4_OFF_B;
#endif
	IO_Y5_OFF;
	IO_Y6_OFF;

	OutputXbarRegs.OUTPUT1MUX0TO15CFG.bit.MUX12 = 3;    // We us eCap_7 as our POUT_1
	OutputXbarRegs.OUTPUT6MUX0TO15CFG.bit.MUX12 = 3;

	OutputXbarRegs.OUTPUT1MUXENABLE.bit.MUX12 = 1;
	OutputXbarRegs.OUTPUT6MUXENABLE.bit.MUX12 = 1;

	SET_AS_OUTPUT_EN_5V;
	SET_AS_OUTPUT_DI_5V;
	SET_AS_OUTPUT_VCC_12V_CTRL;
	SET_AS_OUTPUT_CAN_EN;
	SET_AS_OUTPUT_ALARM_LED;
	SET_AS_OUTPUT_COM_LED;

	IO_EN_5V_OFF;
	IO_DI_5V_OFF;
	IO_VCC_12V_CTRL_OFF;
	IO_CAN_EN_OFF;
	ALARM_LED_OFF;
	COM_LED_OFF;


	EDIS;
#endif

}

/*===========================================================================================
    Function Name    : initHallSensor_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Initialize Hall sensor interrupt settings
//==========================================================================================*/
void initHallSensor_M0 (void)
{
#if(1)
    // Select Hall U V W as XINT src input

    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.XINT1_INT = &xint1_isr;
    PieVectTable.XINT2_INT = &xint2_isr;

    PieVectTable.ECAP5_INT = &ecap5_isr;

    InputXbarRegs.INPUT4SELECT = HALL_U_M0;         // XINT1 connected to HALL_U_M0;
    InputXbarRegs.INPUT5SELECT = HALL_V_M0;         // XINT2 connected to HALL_V_M0;

    XintRegs.XINT1CR.bit.POLARITY = 0x03;           // Interrupt generated on both a falling edge and a rising edge
    XintRegs.XINT2CR.bit.POLARITY = 0x03;           // Interrupt generated on both a falling edge and a rising edge

    XintRegs.XINT1CR.bit.ENABLE = 1;                // Enables external interrupt XINTn.
    XintRegs.XINT2CR.bit.ENABLE = 1;                // Enables external interrupt XINTn.


#if(1)
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD0 : 0 ~ 7
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD1 : 8 ~ 15
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD2 :16 ~ 23
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD3 :24 ~ 31

    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD0 :32 ~ 39
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 :40 ~ 47
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD2 :48 ~ 55
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 :56 ~ 63
    // M0
    //GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
    GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 = HALL_FILTER_CONST;

    GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO57 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO59 = ENCODER_QSEL_CONST & 0x03;

#endif

    EDIS;    // This is needed to disable write to EALLOW protected registers

    // Enable CPU INT1 which is connected to XINT1 and 2 INT:
    IER |= M_INT1;

    hall_ResetPosition( (Struct_HallSensor*) &CG_Hall_M0 );


#endif

}

/*===========================================================================================
    Function Name    : initHallSensor_M1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Initialize Hall sensor interrupt settings
//==========================================================================================*/
#if(0)
void initHallSensor_M1 (void)
{
#if(1)
    // Select Hall U V W as XINT src input

    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.XINT3_INT = &xint3_isr;
    PieVectTable.XINT4_INT = &xint4_isr;

    PieVectTable.ECAP6_INT = &ecap6_isr;

    InputXbarRegs.INPUT6SELECT = HALL_U_M1;         // XINT3 connected to HALL_U_M1;
    InputXbarRegs.INPUT13SELECT = HALL_V_M1;         // XINT4 connected to HALL_V_M1;

    XintRegs.XINT3CR.bit.POLARITY = 0x03;           // Interrupt generated on both a falling edge and a rising edge
    XintRegs.XINT4CR.bit.POLARITY = 0x03;           // Interrupt generated on both a falling edge and a rising edge

    XintRegs.XINT3CR.bit.ENABLE = 1;                // Enables external interrupt XINTn.
    XintRegs.XINT4CR.bit.ENABLE = 1;                // Enables external interrupt XINTn.

#if(1)
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD0 : 0 ~ 7
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD1 : 8 ~ 15
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD2 :16 ~ 23
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD3 :24 ~ 31

    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD0 :32 ~ 39
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 :40 ~ 47
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD2 :48 ~ 55
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 :56 ~ 63
    // M1
    //GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
    //GpioCtrlRegs.GPACTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
    GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = HALL_FILTER_CONST;
    GpioCtrlRegs.GPACTRL.bit.QUALPRD3 = HALL_FILTER_CONST;

    GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = ENCODER_QSEL_CONST & 0x03;
#endif

    EDIS;    // This is needed to disable write to EALLOW protected registers

    // Enable CPU INT12 which is connected to XINT3 INT:
    IER |= M_INT12;

    hall_ResetPosition( (Struct_HallSensor*) &CG_Hall_M1 );

#endif

}
#endif

/*===========================================================================================
    Function Name    : initHallSensor
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Initialize Hall sensor interrupt settings
//==========================================================================================*/
#if(0)
void initHallSensor (void)
{
#if(1)
	// Select Hall U V W as XINT src input

	EALLOW;  // This is needed to write to EALLOW protected registers
	PieVectTable.XINT1_INT = &xint1_isr;
	PieVectTable.XINT2_INT = &xint2_isr;
	PieVectTable.XINT3_INT = &xint3_isr;
	PieVectTable.XINT4_INT = &xint4_isr;

    PieVectTable.ECAP5_INT = &ecap5_isr;
    PieVectTable.ECAP6_INT = &ecap6_isr;

	InputXbarRegs.INPUT4SELECT = HALL_U_M0;			// XINT1 connected to HALL_U_M0;
	InputXbarRegs.INPUT5SELECT = HALL_V_M0;			// XINT2 connected to HALL_V_M0;

	InputXbarRegs.INPUT6SELECT = HALL_U_M1;			// XINT3 connected to HALL_U_M1;
	InputXbarRegs.INPUT13SELECT = HALL_V_M1;         // XINT4 connected to HALL_V_M1;

	XintRegs.XINT1CR.bit.POLARITY = 0x03;			// Interrupt generated on both a falling edge and a rising edge
	XintRegs.XINT2CR.bit.POLARITY = 0x03;			// Interrupt generated on both a falling edge and a rising edge
	XintRegs.XINT3CR.bit.POLARITY = 0x03;			// Interrupt generated on both a falling edge and a rising edge
	XintRegs.XINT4CR.bit.POLARITY = 0x03;           // Interrupt generated on both a falling edge and a rising edge

	XintRegs.XINT1CR.bit.ENABLE = 1;				// Enables external interrupt XINTn.
	XintRegs.XINT2CR.bit.ENABLE = 1;				// Enables external interrupt XINTn.
	XintRegs.XINT3CR.bit.ENABLE = 1;				// Enables external interrupt XINTn.
	XintRegs.XINT4CR.bit.ENABLE = 1;                // Enables external interrupt XINTn.

#if(1)
	// GpioCtrlRegs.GPACTRL.bit.QUALPRD0 : 0 ~ 7
	// GpioCtrlRegs.GPACTRL.bit.QUALPRD1 : 8 ~ 15
	// GpioCtrlRegs.GPACTRL.bit.QUALPRD2 :16 ~ 23
	// GpioCtrlRegs.GPACTRL.bit.QUALPRD3 :24 ~ 31

	// GpioCtrlRegs.GPBCTRL.bit.QUALPRD0 :32 ~ 39
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 :40 ~ 47
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD2 :48 ~ 55
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 :56 ~ 63
	// M0
	GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;

    GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO57 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO59 = ENCODER_QSEL_CONST & 0x03;

    // M1
	GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
	GpioCtrlRegs.GPACTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;

	GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = ENCODER_QSEL_CONST & 0x03;
	GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = ENCODER_QSEL_CONST & 0x03;
	GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = ENCODER_QSEL_CONST & 0x03;
#endif

	// Encoder with PWM in
	GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;

	// M0
	GpioCtrlRegs.GPBPUD.bit.GPIO39 = 0;   	// Enable pull up
	GpioCtrlRegs.GPBQSEL1.bit.GPIO39 = ENCODER_QSEL_CONST & 0x03;

	// M1
    GpioCtrlRegs.GPBPUD.bit.GPIO40 = 0;     // Enable pull up
    GpioCtrlRegs.GPBQSEL1.bit.GPIO40 = ENCODER_QSEL_CONST & 0x03;

	EDIS;    // This is needed to disable write to EALLOW protected registers

	// Enable CPU INT1 which is connected to XINT1 and 2 INT:
	IER |= M_INT1;
	// Enable CPU INT12 which is connected to XINT3 INT:
	IER |= M_INT12;

	hall_ResetPosition( (Struct_HallSensor*) &CG_Hall_M0 );
	hall_ResetPosition( (Struct_HallSensor*) &CG_Hall_M1 );

	//CG_Hall_M0.Current_State = HALL_SIGNAL_M0;
	//CG_Hall_M1.Current_State = HALL_SIGNAL_M1;

	/*
	// Enable XINT INTn in the PIE:
	PieCtrlRegs.PIEIER1.bit.INTx4 = 1;					// XINT1
	PieCtrlRegs.PIEIER1.bit.INTx5 = 1;					// XINT2
	PieCtrlRegs.PIEIER12.bit.INTx1 = 1;					// XINT3
	PieCtrlRegs.PIEIER12.bit.INTx2 = 1;                 // XINT4
	*/

	//PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;
	//PieCtrlRegs.PIEACK.all |= PIEACK_GROUP12;

#endif

}
#endif

/*===========================================================================================
    Function Name    : setupInitial_GPIO
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : GPIO initialization
//==========================================================================================*/
void setupInitial_GPIO (void)
{
    variableInitial_GPIO( (Struct_GPIO*)&CG_GPIO );

	initIOPorts();
	//initHallSensor();

}

/*===========================================================================================
    Function Name    : gpioXHFilter_Setup
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void gpioXHFilter_Setup (void)
{
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD0 : 0 ~ 7
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD1 : 8 ~ 15
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD2 :16 ~ 23
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD3 :24 ~ 31

    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD0 :32 ~ 39
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 :40 ~ 47
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD2 :48 ~ 55
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 :56 ~ 63

    // QSEL_CONST
    // 0: Synchronous
    // 1: 3-sample qualification
    // 2: 6-sample qualification
    // 3: Asynchronous

#define IO_QUALIFICATION    2

    uint32_t io_filter = CG_Parameter.EEP_data[ PARAMETER_GENERAL ][ GENERAL_IO_FILTER ] & 0xFF;

    if( io_filter != 0 ){

        EALLOW;  // This is needed to write to EALLOW protected registers

        GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = io_filter;

        GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = IO_QUALIFICATION;
        GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = IO_QUALIFICATION;

        EDIS;    // This is needed to disable write to EALLOW protected registers

    }

}

/*===========================================================================================
    Function Name    : hall_Prepare_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_Prepare_M0 (void)
{
    DINT;
    EALLOW;  // This is needed to write to EALLOW protected registers

    // Enable XINT INTn in the PIE:
    PieCtrlRegs.PIEIER1.bit.INTx4 = 1;                  // XINT1
    PieCtrlRegs.PIEIER1.bit.INTx5 = 1;                  // XINT2
    PieCtrlRegs.PIEIER4.bit.INTx5 = 1;

    ECap5Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );

    if( HALL_W_STATE_M0 == LOW ){
        //ECap5Regs.ECFRC.bit.CEVT1 = 1;
        ECap5Regs.ECCTL1.bit.CAP1POL = 0;           // 0 = Rising edge, 1 = Falling edge
        ECap5Regs.ECCTL1.bit.CAP2POL = 1;           // 0 = Rising edge, 1 = Falling edge
        ECap5Regs.ECCTL1.bit.CAP3POL = 0;           // 0 = Rising edge, 1 = Falling edge
        ECap5Regs.ECCTL1.bit.CAP4POL = 1;           // 0 = Rising edge, 1 = Falling edge
    }else{
        ECap5Regs.ECCTL1.bit.CAP1POL = 1;           // 0 = Rising edge, 1 = Falling edge
        ECap5Regs.ECCTL1.bit.CAP2POL = 0;           // 0 = Rising edge, 1 = Falling edge
        ECap5Regs.ECCTL1.bit.CAP3POL = 1;           // 0 = Rising edge, 1 = Falling edge
        ECap5Regs.ECCTL1.bit.CAP4POL = 0;           // 0 = Rising edge, 1 = Falling edge
    }

    EDIS;    // This is needed to disable write to EALLOW protected registers
    EINT;
}

/*===========================================================================================
    Function Name    : hall_Prepare_M1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
#if(0)
void hall_Prepare_M1 (void)
{
    DINT;
    EALLOW;  // This is needed to write to EALLOW protected registers

    // Enable XINT INTn in the PIE:
    PieCtrlRegs.PIEIER12.bit.INTx1 = 1;                 // XINT3
    PieCtrlRegs.PIEIER12.bit.INTx2 = 1;                 // XINT4
    PieCtrlRegs.PIEIER4.bit.INTx6 = 1;
    ECap6Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );

    if( HALL_W_STATE_M1 == LOW ){
        //ECap6Regs.ECFRC.bit.CEVT1 = 1;
        ECap6Regs.ECCTL1.bit.CAP1POL = 0;           // 0 = Rising edge, 1 = Falling edge
        ECap6Regs.ECCTL1.bit.CAP2POL = 1;           // 0 = Rising edge, 1 = Falling edge
        ECap6Regs.ECCTL1.bit.CAP3POL = 0;           // 0 = Rising edge, 1 = Falling edge
        ECap6Regs.ECCTL1.bit.CAP4POL = 1;           // 0 = Rising edge, 1 = Falling edge
    }else{
        ECap6Regs.ECCTL1.bit.CAP1POL = 1;           // 0 = Rising edge, 1 = Falling edge
        ECap6Regs.ECCTL1.bit.CAP2POL = 0;           // 0 = Rising edge, 1 = Falling edge
        ECap6Regs.ECCTL1.bit.CAP3POL = 1;           // 0 = Rising edge, 1 = Falling edge
        ECap6Regs.ECCTL1.bit.CAP4POL = 0;           // 0 = Rising edge, 1 = Falling edge
    }

    EDIS;    // This is needed to disable write to EALLOW protected registers
    EINT;
}
#endif

/*===========================================================================================
    Function Name    : hall_Ready_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_Ready_M0 (void)
{
    DINT;
    CG_Hall_M0.INT_Time_New = CURRENT_TIMER_CNT;
    CG_Hall_M0.Current_State = HALL_SIGNAL_M0;

    CG_Hall_M0.Next_State_If_CW = CG_Hall_M0.Next_State_Table[ DIR_CW  ][ CG_Hall_M0.Current_State ];
    CG_Hall_M0.Next_State_If_CCW = CG_Hall_M0.Next_State_Table[ DIR_CCW  ][ CG_Hall_M0.Current_State ];
    CG_Hall_M0.Current_Dir = 0;
    CG_Hall_M0.Old_Dir = CG_Hall_M0.Current_Dir;
    hall_ResetPosition( (Struct_HallSensor*) &CG_Hall_M0 );
    EINT;
}

/*===========================================================================================
    Function Name    : hall_Ready_M1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
#if(0)
void hall_Ready_M1 (void)
{
    DINT;
    CG_Hall_M1.INT_Time_New = CURRENT_TIMER_CNT;
    CG_Hall_M1.Current_State = HALL_SIGNAL_M1;

    CG_Hall_M1.Next_State_If_CW = CG_Hall_M1.Next_State_Table[ DIR_CW  ][ CG_Hall_M1.Current_State ];
    CG_Hall_M1.Next_State_If_CCW = CG_Hall_M1.Next_State_Table[ DIR_CCW  ][ CG_Hall_M1.Current_State ];
    CG_Hall_M1.Current_Dir = 0;
    CG_Hall_M1.Old_Dir = CG_Hall_M1.Current_Dir;
    hall_ResetPosition( (Struct_HallSensor*) &CG_Hall_M1 );

    EINT;

}
#endif

/*===========================================================================================
    Function Name    : il_HallSensorIRQ
    Input            : 1. bldc_ctrl
                       2. hall_state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Hall sensor interrupt handler
//==========================================================================================*/
__inline void il_HallSensorIRQ( Struct_BLDC_CTRL *bldc_ctrl, uint8_t hall_state )
{
#if(1)
    Struct_HallSensor *hall = bldc_ctrl->Hall_Ptr;
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;

    hall->INT_Time_New = CURRENT_TIMER_CNT;
    hall->Current_State = hall_state;

	if( bldc_drive->Sensor_Type == SENSOR_TYPE_HALL ){

	    /*
		if( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING || bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ){

			bldc_ctrl->Commutation = bldc_drive->Commutation_Table[ bldc_ctrl->Target_Dir ][ hall_state ];

			//il_PhaseAdv_DisableTimer();


			if( ( hall_state == hall->Next_State_If_CW  && hall->Current_Dir == DIR_CW  ) ||		// direction is right
				( hall_state == hall->Next_State_If_CCW && hall->Current_Dir == DIR_CCW )    ){

				if( CG_PhaseAdv.Enabled && CG_Speed.hall_int_times >= PA_OPEN_CNT && CG_Speed.current_dir == bldc_ctrl->Target_Dir ){
					phaseAdvance( CG_PhaseAdv.Enabled );
				}else{
					commutation_output[ bldc_drive->Mode ]( bldc_ctrl->Commutation );
					CG_PhaseAdv.phase_changed = NO;
				}

			}else{

				CG_Speed.hall_int_times = 0;

				commutation_output[ bldc_drive->Mode ]( bldc_ctrl->Commutation );

			}

		}*/

	    hall->INT_Flag = YES;

	    hall_PeriodCalculation( hall );
	    management_LockPointer( bldc_ctrl->SPK_Ptr, hall->Current_Dir );

		bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_SPD_OUT ] ^= 1;
		OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_SPD_OUT ] ][ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_SPD_OUT ] ]();

	}

	//DINT;

#endif

}


/*===========================================================================================
    Function Name    : xint1_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT1 IRQ event
//==========================================================================================*/
__interrupt void xint1_isr (void)
{
    uint8_t hall_state;

	//CG_Speed.hall_int_time_new = FREE_RUN_TIMER.TIM.all;
	//CG_Speed.hall_int_time_new += XintRegs.XINT1CTR; //  roughly 13 clk

    hall_state = HALL_SIGNAL_M0;
	il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0, hall_state );

	// Acknowledge this interrupt to receive more interrupts from group 1
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;



}

/*===========================================================================================
    Function Name    : xint2_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT1 IRQ event
//==========================================================================================*/
__interrupt void xint2_isr (void)
{

    uint8_t hall_state;

    //CG_Speed.hall_int_time_new = FREE_RUN_TIMER.TIM.all;
    //CG_Speed.hall_int_time_new += XintRegs.XINT1CTR; //  roughly 13 clk

    hall_state = HALL_SIGNAL_M0;
    il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0, hall_state );

	// Acknowledge this interrupt to receive more interrupts from group 1
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;


}

/*===========================================================================================
    Function Name    : xint3_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT1 IRQ event
//==========================================================================================*/
#if(0)
__interrupt void xint3_isr (void)
{

    uint8_t hall_state;

    //CG_Speed.hall_int_time_new = FREE_RUN_TIMER.TIM.all;
    //CG_Speed.hall_int_time_new += XintRegs.XINT1CTR; //  roughly 13 clk

    hall_state = HALL_SIGNAL_M1;
    il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1, hall_state );

	// Acknowledge this interrupt to receive more interrupts from group 12
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP12;
}

/*===========================================================================================
    Function Name    : xint4_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XINT4 IRQ event
//==========================================================================================*/
__interrupt void xint4_isr (void)
{

    uint8_t hall_state;

    //CG_Speed.hall_int_time_new = FREE_RUN_TIMER.TIM.all;
    //CG_Speed.hall_int_time_new += XintRegs.XINT1CTR; //  roughly 13 clk

    hall_state = HALL_SIGNAL_M1;
    il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1, hall_state );

    // Acknowledge this interrupt to receive more interrupts from group 12
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP12;
}
#endif

/*===========================================================================================
    Function Name    : ecap5_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__interrupt void ecap5_isr(void)
{
    uint8_t hall_state;

    hall_state = HALL_SIGNAL_M0;
    il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0, hall_state );

    ECap5Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
    // Acknowledge this interrupt to receive more interrupts from group 4
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP4;
}

/*===========================================================================================
    Function Name    : ecap6_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
#if(0)
__interrupt void ecap6_isr(void)
{
    uint8_t hall_state;

    hall_state = HALL_SIGNAL_M1;
    il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1, hall_state );

    ECap6Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
    // Acknowledge this interrupt to receive more interrupts from group 4
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP4;
}
#endif

#if(TEST_FAKE_HALL_SENSOR)
/*===========================================================================================
    Function Name    : gpio_FakeHallSensor
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void gpio_FakeHallSensor(void)
{
    /*=============     Hall CW : 1 -> 3 -> 2 -> 6-> 4 -> 5 ============*/
    uint32_t hall_table[ 6 ] = { 1, 3, 2, 6, 4, 5 };
    uint8_t hall_state;

    if( ++CG_MD.FakeHall_Timer >= CG_MD.FakeHall_TimeConst ){
        CG_MD.FakeHall_Timer = 0;

        if( ++CG_MD.FakeHall_Point >= 6 ){
            CG_MD.FakeHall_Point = 0;
        }
        hall_state = hall_table[ CG_MD.FakeHall_Point ];

        il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0, hall_state );
        il_HallSensorIRQ( (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1, hall_state );

    }
}

#endif
/************************** <END OF FILE> *****************************************/




