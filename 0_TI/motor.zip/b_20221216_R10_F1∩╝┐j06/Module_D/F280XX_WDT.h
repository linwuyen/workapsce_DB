/*
 * F280XX_WDT.h
 *
 *  Created on: 2015/4/13
 *      Author: chaim.chen
 */

/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef F280XX_WDT_H_
#define F280XX_WDT_H_


/*===========================================================================================
    Function Name    : setupInitial_WDT
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup the watchdog timer
//==========================================================================================*/
void setupInitial_WDT( void );

/*===========================================================================================
    Function Name    : WDT_IRQHandler
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Watchdog timer interrupt handler
//==========================================================================================*/
void WDT_IRQHandler(void);


#endif /* F280XX_WDT_H_ */
