/*
 * C2000_UART485.h
 *
 *  Created on: 2015/9/1
 *      Author: chaim.chen
 */

#ifndef C2000_UART485_H_
#define C2000_UART485_H_

/*  Trunmman Technology Corporation. All rights reserved. */

//#include "IncludeFiles.h"

#define SET_485_MUX_STATE( x )		( CG_UART485.Mux_Info_State = x )


#define STALED_FLASH_PULSE_WIDTH		50
#define STALED_TIME_OUT_CONST			650
#define STALED_FRAMEERROR_CONST			2000

enum {
    STATE_READY       	= 0,
	STATE_START        	= 1,
	STATE_DONE        	= 2,
    STATE_NUM   		= 3
};

enum{
    STALED_TIMEOUT				= 0,
	STALED_FINE					= 1,
	STALED_FRAME_ERROR			= 2,
	STALED_NUM					= 3
};

enum{
	COMBITF_FINE				= 0,
    COMBITF_TIMEOUT				= 1,
	COMBITF_GOT_DATA			= 2,
	COMBITF_FRAME_BAD			= 3,
	COMBITF_FRAME_GOOD			= 4,
	COMBITF_OVERFLOW			= 5,
	COMBITF_NUM					= 6

};

enum{
	BAUD_RATE_9600		= 0,
	BAUD_RATE_19200		= 1,
	BAUD_RATE_38400		= 2,
	BAUD_RATE_57600		= 3,
	BAUD_RATE_115200	= 4,
	BAUD_RATE_NUM		= 5
};

static const uint32_t Const_Baud_Rate[ BAUD_RATE_NUM ] = { 9600UL, 19200UL, 38400UL, 57600UL, 115200UL };

enum{
	RS485_PROTOCOL			= 0,
    //PHYSICAL_PARITY_S0		= 1,
	//PHYSICAL_PARITY_S1		= 2,
	//PHYSICAL_STOP_BIT		= 3,
	//PHYSICAL_DATA_BIT		= 4,
	//PHYSICAL_BIT_NUM		= 5
	PHYSICAL_BIT_NUM        = 1
};

enum{
    PARITY_NONE				= 0,
	PARITY_ODD				= 1,
	PARITY_EVEN				= 2,
	PARITY_NUM				= 3
};

enum{
    STOP_BIT_1BIT			= 0,
	STOP_BIT_2BIT			= 1,
	STOP_BIT_NUM			= 2
};

enum{
    DATA_BIT_8BIT			= 0,
	DATA_BIT_7BIT			= 1,
	DATA_BIT_NUM			= 2
};

enum{
    EXCEPTION_MODE_ORIGINAL	= 0,
	EXCEPTION_MODE_NORMAL	= 1,
	EXCEPTION_MODE_NUM		= 2
};

/*===========================================================================================
    TXD Enalbe output control Macros
//==========================================================================================*/
#define SET_AS_OUTPUT_TXEN    ( GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1 )
#define TXEN_HIGH             ( GpioDataRegs.GPBSET.bit.GPIO34 = 1 )
#define TXEN_LOW              ( GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1 )

#define TXEN_ON               TXEN_LOW
#define TXEN_OFF              TXEN_HIGH

#define TXEN_ACT_TIME			( CPU_FREQ / 10000 ) // about 0.1ms


static const uint32_t Const_TXEN_Act_Time[ BAUD_RATE_NUM ] = { TXEN_ACT_TIME * 12, TXEN_ACT_TIME * 6, TXEN_ACT_TIME * 3, TXEN_ACT_TIME * 2, TXEN_ACT_TIME };


/*===========================================================================================
    Mux control Macros
//==========================================================================================*/

//#define RS485_BAUD_RT_0			( GpioDataRegs.GPADAT.bit.GPIO9 )
//#define RS485_BAUD_RT_1			( GpioDataRegs.GPADAT.bit.GPIO8 )

//#define RS485_ID_STATE_S0		( GpioDataRegs.GPADAT.bit.GPIO7 )
//#define RS485_ID_STATE_S1		( GpioDataRegs.GPADAT.bit.GPIO6 )
//#define RS485_ID_STATE_S2		( GpioDataRegs.GPADAT.bit.GPIO11 )




enum{
    MUX_Y0        					= 0,
	MUX_ID_S0        				= 0,
    MUX_Y1							= 1,
	MUX_ID_S1        				= 1,
	MUX_Y2        					= 2,
	MUX_ID_S2        				= 2,
	MUX_Y3							= 3,
	MUX_ID_S3        				= 3,
	MUX_Y4        					= 4,

	MUX_Y5							= 5,
	MUX_BAUD_S0        				= 5,
	MUX_Y6        					= 6,
	MUX_BAUD_S1        				= 6,
	MUX_Y7							= 7,
	MUX_BAUD_S2        				= 7,
	MUX_NUM							= 8,

	MUX_PROTOCOL        			= 8

};

enum{
    TXEN_STATE_OFF        			= 0,
    TXEN_STATE_OPENING        		= 1,
    TXEN_STATE_ON        			= 2,
    TXEN_STATE_CLOSING        		= 3,
    TXEN_STATE_NUM					= 4
};

#define UART485_BUFFER_SIZE_R	360
#define UART485_BUFFER_SIZE_T	200

typedef struct{

    unsigned char R_data_buffer[ UART485_BUFFER_SIZE_R ];
    unsigned char T_data_buffer[ UART485_BUFFER_SIZE_T ];

    unsigned char T_data_pointer;
    unsigned char R_data_pointer;

    unsigned char T_data_length;

    unsigned char request_to_send_data_flag;
    uint8_t TxEn_State;

    //unsigned char TxEmpty;
	unsigned char ReceiveFlag;

	//unsigned char time_out_flag;
	int32_t time_out_cnt;
	uint8_t	Connection_State;
	uint8_t	Connection_BITF;

	int32_t  TX_EN_Time;

    //uint32_t state;
    //uint32_t pclk;

	uint32_t R_data_number;

	uint8_t  modbus_mode;
	uint8_t  get_data_flag;
	uint32_t rtu_time_point_1;
	uint32_t rtu_time_point_2;
	uint32_t rtu_frame_length_limit;
	uint32_t rtu_time_frame_length;

	uint16_t Mux_BIFT;
	uint16_t Mux_Info_State;
	uint16_t ID;
	uint16_t BAUD_Index;
	uint16_t Protocol_Index;

	uint32_t BaudRate;

}Struct_UART485;



/*===========================================================================================
    Function Name    : variableInitial_UART485
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_UART initial
//==========================================================================================*/
void varibleInitial_UART485( void );

/*===========================================================================================
    Function Name    : setupInitial_UART
    Input            :
					   1.baudrate : baudrate number of the UART.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : UART initialzation function.
					   For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_UART485( unsigned long baudrate);

/*===========================================================================================
    Function Name    : output_StaLED
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : This function output LED flash according to the 485 state
//==========================================================================================*/
void output_StaLED ( void );

/*===========================================================================================
    Function Name    : scibRxFifoIsr
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : The UART( UART0 ) IRQ event
//==========================================================================================*/
__interrupt void scibRxFifoIsr(void);

/*===========================================================================================
    Function Name    : checkUARTSend
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Check if the UART data transmit commmand has been set then decide if it
					   needs to send output data.
					   For previous version please check oringial A04 or A09 MDB code.
					   *Avoid using while loop.
//==========================================================================================*/
void checkUARTSend485( void );

/*===========================================================================================
    Function Name    : checkUARTframe_232
    Input            : Null
    Return           : Null
    Programmer       : Eric.Tsai@trumman.com.tw
					   Modified by Chaum.Chen@trumman.com.tw
    Description      : For RTU
//==========================================================================================*/
 void checkRTUframe_485( void );



#endif /* C2000_UART485_H_ */


 /************************** <END OF FILE> *****************************************/



