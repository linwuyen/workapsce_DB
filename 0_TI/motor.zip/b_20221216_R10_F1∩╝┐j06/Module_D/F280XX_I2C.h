/*
 * F280XX_I2C.h
 *
 *  Created on: 2015/8/10
 *      Author: chaim.chen
 */
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef F280XX_I2C_H_
#define F280XX_I2C_H_

/* If I2C SEEPROM is tested, make sure FAST_MODE_PLUS is 0.
For board to board test, this flag can be turned on. */

#define FW_EEP_ADDRESS 				0x52
#define HW_EEP_ADDRESS 				FW_EEP_ADDRESS//0x51

#define FW_EEP_TYPE     			EEPTYPE_64KBIT
#define HW_EEP_TYPE     			FW_EEP_TYPE//EEPTYPE_2KBIT


#define	I2C_ERROR_DETCET	1

#define I2C_BUFSIZE			        80
#define I2C_MAX_TIMEOUT				0x00FFFFFF
#define MAX_OP_BYTE_NUM     		0x20

#define I2C_RD_BIT			      	0x01

#define I2C_WRITE_DELAY_TIME       	100   		//
#define I2C_ERROR_TIME              100			// 100ms

#define I2SCLH_SCLH					0x0000014//0x0000030//0x00000E6//  /* I2C SCL Duty Cycle High Reg */
#define I2SCLL_SCLL					0x0000014//0x0000030//0x00000E6//  /* I2C SCL Duty Cycle Low Reg */


// Clear Status Flags
#define I2C_CLR_AL_BIT          0x0001
#define I2C_CLR_NACK_BIT        0x0002
#define I2C_CLR_ARDY_BIT        0x0004
#define I2C_CLR_RRDY_BIT        0x0008
#define I2C_CLR_SCD_BIT         0x0020

// Interrupt Source Messages
#define I2C_NO_ISRC             0x0000
#define I2C_ARB_ISRC            0x0001
#define I2C_NACK_ISRC           0x0002
#define I2C_ARDY_ISRC           0x0003
#define I2C_RX_ISRC             0x0004
#define I2C_TX_ISRC             0x0005
#define I2C_SCD_ISRC            0x0006
#define I2C_AAS_ISRC            0x0007


enum{
    I2CMASTER   = 0x01,
    I2CSLAVE    = 0x02
};


enum{
    I2C_READY					= 0,
    I2C_WRITE_STARTED			= 1,
    I2C_READ_STARTED			= 2,
    I2C_READ_REPEAT_STARTED		= 3,

    I2C_TIME_OUT       			= 6,

    I2C_FAULT           		= 8
};

enum{
	TDATA_OVERFLOAT		= 0,		// T data overfloat
	RDATA_OVERFLOAT		= 1,		// R data overfloat
	RDATA_TIME_OUT		= 2,		// No response when read data
	STOP_MISSED			= 3,		// Bus can not stop
	STUCK_IN_BUSY		= 4,		// Stuck in busy
	RECIEVE_NACK		= 5,	    // No Slave anwser
	EEP_BUSY            = 6

};


enum{
    EEPTYPE_2KBIT    	= 0,
    EEPTYPE_64KBIT   	= 1
};

enum{
    BASIC_WRITE_LENGTH_2KBIT    = 1,
    BASIC_WRITE_LENGTH_64KBIT   = 2
};


typedef struct {

    uint8_t 	MasterState; //
    uint32_t 	State_BIFT;
    uint8_t 	T_Data[ I2C_BUFSIZE ];
    uint8_t 	R_Data[ I2C_BUFSIZE ];
	uint8_t 	ErrorDeviceAddr;
	uint8_t 	is_OK_Flag;	// 1=Normal, 0=Error

    uint16_t 	ReadLength;
    uint16_t 	WriteLength;

    uint16_t 	RdIndex;    // = 0;
    uint16_t 	WrIndex;    // = 0;

    // When write data to EEP , it should make about a 10ms delay time
    // I2C should not be used during this period
    // Ex: write data to eep => busy_flag will be set ( clear after 10ms  )
    uint8_t  	Busy_flag;
    uint32_t 	write_delay_counter;  // a counter for calculate delay time

    int32_t 	error_counter;

    //

    int32_t 	test_reg;
    int32_t 	test_reg2;

}Struct_I2C;



/*===========================================================================================
    Function Name    : variableInitial_I2C
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_I2C initial
//==========================================================================================*/
void variableInitial_I2C( void );


/*===========================================================================================
    Function Name    : checkBusyFlag_I2C
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Busy flag will be clear after a time delay.
    				   @cpu_timer0_isr
//==========================================================================================*/
void checkBusyFlag_I2C( void );

/*===========================================================================================
    Function Name    : checkError_I2C
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Check if I2C has no response.
    				   @cpu_timer0_isr
//==========================================================================================*/
void checkError_I2C( void );

/*===========================================================================================
    Function Name    : resetEEP_HWVer_AB
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Reset EEP
//==========================================================================================*/
void resetEEP_HWVer_AB( void );

/*===========================================================================================
    Function Name    : checkError_I2C
    Input            : Null
    Return           :
                       true or false, return false if the I2C
                       interrupt handler was not installed correctly
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up I2C.
//==========================================================================================*/
uint32_t setupInitial_I2C( void );


/*===========================================================================================
    Function Name    : writeData_I2C
    Input            :
                       1.slaveID: S2S1S0
                       2.EEPType: 64K bits or 2K bits in this application
                       3.address: EEP address
                       4.data   : data needs to write
                       5.num    : data length.
    Return           : Is_Write_Success
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Write data to EEP
                       User must make a delay after data writing
                       ( roughly 10ms for delay time )
//==========================================================================================*/
Uint16 writeData_I2C( uint8_t slaveID, uint8_t EEPType, uint32_t address, uint8_t * data, uint8_t num );

/*===========================================================================================
    Function Name    : readData_I2C
    Input            :
                       1.slaveID: S2S1S0
                       2.EEPType: 64K bits or 2K bits in this application
                       3.address: EEP address
                       4.data   : data needs to read
                       5.num    : data length.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Read data from EEP
//==========================================================================================*/
Uint16 readData_I2C( uint8_t slaveID, uint8_t EEPType, uint32_t address, uint8_t * data, uint8_t num );

/*===========================================================================================
    Function Name    : writeAndCheckDataEEP
    Input            :
                       1.slaveID: S2S1S0
                       2.EEPType: 64K bits or 2K bits in this application
                       3.address: EEP address
                       4.data   : data needs to write
                       5.num    : data length.
    Return           :  1 : data transmit is success.
                        0 : data transmit is failed.
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Write data to EEP and then check if data transmit is success.
    				   Max data num = 8
//==========================================================================================*/
uint8_t writeAndCheckDataEEP( uint8_t slaveID, uint8_t EEPType, uint32_t address, uint8_t * data, uint8_t num );

/*===========================================================================================
    Function Name    : i2c_int1a_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : I2C IRQ
//==========================================================================================*/
__interrupt void i2c_int1a_isr(void);     // I2C-A



#endif /* F280XX_I2C_H_ */

/************************** <END OF FILE> *****************************************/


