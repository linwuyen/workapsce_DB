/*
 * F280XX_WDT.c
 *
 *  Created on: 2015/4/13
 *      Author: chaim.chen
 */

/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"


/*===========================================================================================
    Function Name    : setupInitial_WDT
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup the watchdog timer
//==========================================================================================*/
void setupInitial_WDT( void )
{
	// Interrupts that are used in this example are re-mapped to
	// ISR functions found within this file.
	//EALLOW;	// This is needed to write to EALLOW protected registers
	//PieVectTable.WAKEINT = &WDT_IRQHandler;
	//EDIS;   // This is needed to disable write to EALLOW protected registers

	// Connect the watchdog to the WAKEINT interrupt of the PIE
	// Write to the whole SCSR register to avoid clearing WDOVERRIDE bit
	//EALLOW;
	//SysCtrlRegs.SCSR = 1;
	//EDIS;
	// Enable WAKEINT in the PIE: Group 1 interrupt 8
	// Enable INT1 which is connected to WAKEINT:
	//PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
	//PieCtrlRegs.PIEIER1.bit.INTx8 = 1;   // Enable PIE Gropu 1 INT8

	// Reset the watchdog counter
	ServiceDog();

	// Enable the watchdog
	EALLOW;
	WdRegs.WDCR.all = ( 5 << 3 ) | ( 7 << 0 ); // 10101000
	EDIS;

}


/*===========================================================================================
    Function Name    : WDT_IRQHandler
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Watchdog timer interrupt handler
//==========================================================================================*/
void WDT_IRQHandler(void)
{
	EALLOW;
	WdRegs.WDCR.all = ( 1 << 3 ); //
	EDIS;
	// Acknowledge this interrupt to get more from group 1
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}


