/*
 * C2000_CAN.h
 *
 *  Created on: 2020/11/19
 *      Author: chaim.chen
 */

#ifndef C2000_CAN_H_
#define C2000_CAN_H_

/*  Trunmman Technology Corporation. All rights reserved. */

//#include "IncludeFiles.h"
#include "CANOpen_TypeDef.h"

#define C2000_CAN_BASE      CANB_BASE
#define C2000_CAN_REG       CanbRegs

enum{
    CAN_BAUD_RATE_100K      = 0,
	CAN_BAUD_RATE_125K  	= 1,
	CAN_BAUD_RATE_250K		= 2,
	CAN_BAUD_RATE_500K		= 3,
	CAN_BAUD_RATE_1M		= 4,
	CAN_BAUD_RATE_NUM		= 5
};

static const uint32_t Const_CAN_Baud_Rate[ CAN_BAUD_RATE_NUM ] = { 100000UL, 125000UL, 250000UL, 500000UL, 1000000UL };


/*===========================================================================================
    Mux control Macros
//==========================================================================================*/


#define CAN_BUFFER_SIZE	8


typedef struct{

    unsigned char R_data_buffer[ CAN_BUFFER_SIZE ];
    unsigned char T_data_buffer[ CAN_BUFFER_SIZE ];

    unsigned char request_to_send_data_flag;
	unsigned char ReceiveFlag;

	uint8_t  Mode;
	uint16_t ID;
	uint16_t BAUD_Index;
	uint16_t Protocol_Index;

	uint32_t BaudRate;

	uint8_t  Timeout_Flag;
	uint32_t Timeout_Pa_Ms;
    uint32_t Timeout_Cnt_Ms;
    uint32_t LED_Indicator_Cnt_Ms;

	Struct_CANOpen  CANOpen;

}Struct_CAN;


/*===========================================================================================
    Function Name    : setupInitial_CAN
    Input            : 1.can
                       2.node_id
                       3.baudrate
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_CAN( Struct_CAN *can, uint32_t node_id, unsigned int baudrate );

/*===========================================================================================
    Function Name    : an_Call_1ms
    Input            : can
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void can_Call_1ms( Struct_CAN *can );

/*===========================================================================================
    Function Name    : can_Routine
    Input            : can
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void can_Routine( Struct_CAN *can );


#endif /* C2000_CAN_H_ */


 /************************** <END OF FILE> *****************************************/



