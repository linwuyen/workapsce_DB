/*
 * C2000_UART485.c
 *
 *  Created on: 2015/9/1
 *      Author: chaim.chen
 */

/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_UART485  CG_UART485;
extern volatile Struct_Parameter						CG_Parameter;
extern volatile Struct_Modbus_Slave						CG_Modbus_Slave_485;
extern volatile Struct_HWEEP							CG_HWEEP;
extern volatile Struct_MD                               CG_MD;

//#pragma CODE_SECTION( scicRxFifoIsr, "ramfuncs");
#pragma CODE_SECTION( scibRxFifoIsr, ".TI.ramfunc" );

/*===========================================================================================
    Function Name    : variableInitial_UART485
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_UART initial
//==========================================================================================*/
void variableInitial_UART485 (void)
{
    CG_UART485.R_data_pointer = 0;
    CG_UART485.T_data_pointer = 0;
    CG_UART485.T_data_length = 0;
    CG_UART485.time_out_cnt = STALED_TIME_OUT_CONST;
    //CG_UART485.time_out_flag = 0;
    CG_UART485.Connection_State = STALED_TIMEOUT;
    CG_UART485.Connection_BITF = 0;

    CG_UART485.rtu_time_point_1 = 0;
    CG_UART485.rtu_time_point_2 = 0;

    CG_UART485.rtu_frame_length_limit = 0;

    CG_UART485.request_to_send_data_flag = 0;
    CG_UART485.TxEn_State = TXEN_STATE_OFF;

    SET_485_MUX_STATE( STATE_START );

    CG_UART485.ReceiveFlag = UART_READY;
	CG_UART485.get_data_flag = NO;
	CG_UART485.TX_EN_Time = Const_TXEN_Act_Time[ BAUD_RATE_115200 ];
	CG_UART485.modbus_mode = MB_SLV_ASCII;

}

/*===========================================================================================
    Function Name    : il_SetUp_UARTPin485
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up UART Pin
//==========================================================================================*/
__inline void il_SetUp_UARTPin485( void )
{

    GPIO_SetupPinMux(12, GPIO_MUX_CPU1, 6);
    GPIO_SetupPinMux(13, GPIO_MUX_CPU1, 6);

	EALLOW;

    SET_AS_OUTPUT_TXEN;
    TXEN_OFF;

	// GPIO_SetupPinMux() - Sets the GPxMUX1/2 and GPyMUX1/2 register bits
	// GPIO_SetupPinOptions() - Sets the direction and configuration of GPIOs
	// These functions are found in the F28X7x_Gpio.c file.
	//
	GpioCtrlRegs.GPAPUD.bit.GPIO13 = 0;   // Enable pullup on GPIO13
	GpioCtrlRegs.GPAQSEL1.bit.GPIO13 = 3; // Asynch input
	//GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 6;  // GPIO13 = SCIRXDB
    GpioCtrlRegs.GPAPUD.bit.GPIO12 = 0;   // Enable pullup on GPIO12

	EDIS;

}

/*===========================================================================================
    Function Name    : configure_UART485
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup UART config
//==========================================================================================*/
void configure_UART485( void )
{

	uint32_t dummy;
	int8_t baud_index;


	ScibRegs.SCICTL1.all = 0x0003;

	CG_UART485.Protocol_Index = ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_SETTINGS ] >> RS485_PROTOCOL ) & 0x01;

	// ==
	CG_UART485.ID = CG_MD.Comm_ID;
	if( CG_UART485.ID == 0 ){
	    CG_UART485.ID = 1;
	}else if( CG_UART485.ID > 255 ){
		CG_UART485.ID = 255;
	}

	CG_UART485.BAUD_Index = CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_BAUDRATE ];
	if( CG_UART485.BAUD_Index >= BAUD_RATE_NUM ){
		CG_UART485.BAUD_Index = 0;
	}

	CG_UART485.modbus_mode = 1 - CG_UART485.Protocol_Index;

	// Physical settings
	/*
	switch( ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_SETTINGS ] >> PHYSICAL_PARITY_S0 ) & 0x03 ){
	case PARITY_NONE:
	default:
		ScibRegs.SCICCR.bit.PARITYENA = 0;
		break;
	case PARITY_ODD:
		ScibRegs.SCICCR.bit.PARITYENA = 1;
		ScibRegs.SCICCR.bit.PARITY = 0;// Odd parity
		break;
	case PARITY_EVEN:
		ScibRegs.SCICCR.bit.PARITYENA = 1;
		ScibRegs.SCICCR.bit.PARITY = 1;// Even parity
		break;
	}*/
	ScibRegs.SCICCR.bit.PARITYENA = 0;  // PARITY_NONE

	//ScibRegs.SCICCR.bit.STOPBITS = ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_SETTINGS ] >> PHYSICAL_STOP_BIT ) & 0x01;
	ScibRegs.SCICCR.bit.STOPBITS = 0;// 0  = 1bit, 1 = 2 bits

	/*
	switch( ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_SETTINGS ] >> PHYSICAL_DATA_BIT ) & 0x01  ){
	case DATA_BIT_8BIT:
	default:
		ScibRegs.SCICCR.bit.SCICHAR = 7;
		break;
	case DATA_BIT_7BIT:
		ScibRegs.SCICCR.bit.SCICHAR = 6;
		break;
	}
	*/
	ScibRegs.SCICCR.bit.SCICHAR = 7; // 7 = 8bits

	// Baud

	baud_index = CG_UART485.BAUD_Index;
	if( baud_index > BAUD_RATE_115200 ){
		baud_index = BAUD_RATE_115200;
	}
	CG_UART485.BaudRate = Const_Baud_Rate[ baud_index ];

	ScibRegs.SCICTL2.bit.RXBKINTENA =1;

	dummy = ( LSPCLK_FREQ / ( Const_Baud_Rate[ baud_index ] * 8 ) ) - 1;

	ScibRegs.SCIHBAUD.all = ( dummy >> 8 );
	ScibRegs.SCILBAUD.all = ( dummy & 0xFF );

	CG_UART485.TX_EN_Time = Const_TXEN_Act_Time[ baud_index ];
	CG_UART485.rtu_time_frame_length = ( CPU_FREQ / Const_Baud_Rate[ baud_index ] ) * 35; // ( 35 = 10 bit * 3.5 char length )
	if( CG_UART485.rtu_time_frame_length < MODBUS_FRAME_GAP_LIMIT ){
		CG_UART485.rtu_time_frame_length = MODBUS_FRAME_GAP_LIMIT;
	}

	//

	ScibRegs.SCICTL1.all = 0x0023;     // Relinquish SCI from Reset


}

/*===========================================================================================
    Function Name    : il_SetUp_UARTReg485
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up UART register
//==========================================================================================*/
__inline void il_SetUp_UARTReg485( unsigned long baudrate )
{
	//uint32_t dummy;
	// Interrupts that are used in this example are re-mapped to
	// ISR functions found within this file.
	EALLOW;  // This is needed to write to EALLOW protected registers
	PieVectTable.SCIB_RX_INT = &scibRxFifoIsr;
	EDIS;   // This is needed to disable write to EALLOW protected registers

#if(TEST_EEP_OPEN)
	configure_UART485();
#else

	ScibRegs.SCICCR.all = 0x0007;   // 1 stop bit,  No loopback
								  // No parity,8 char bits,
								  // async mode, idle-line protocol

	ScibRegs.SCICTL1.all = 0x0003;  // enable TX, RX, internal SCICLK,
								  // Disable RX ERR, SLEEP, TXWAKE

	ScibRegs.SCICTL2.bit.RXBKINTENA =1;

	dummy = ( LSPCLK_FREQ / ( baudrate * 8 ) ) - 1;

	ScibRegs.SCIHBAUD.all = ( dummy >> 8 );
	ScibRegs.SCILBAUD.all = ( dummy & 0xFF );

	CG_UART485.rtu_time_frame_length = ( CPU_FREQ / baudrate ) * 35; // ( 35 = 10 bit * 3.5 char length )
	if( CG_UART485.rtu_time_frame_length < MODBUS_FRAME_GAP_LIMIT ){
		CG_UART485.rtu_time_frame_length = MODBUS_FRAME_GAP_LIMIT;
	}

	ScibRegs.SCICTL1.all = 0x0023;     // Relinquish SCI from Reset

#endif

	PieCtrlRegs.PIEIER9.bit.INTx3 = 1;     	// PIE Group 9, INT3
	IER |= M_INT9;

}

/*===========================================================================================
    Function Name    : setupInitial_UART485
    Input            :
					   1.baudrate : baudrate number of the UART.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : UART initialzation function.
					   For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_UART485( unsigned long baudrate)
{

    variableInitial_UART485();

    il_SetUp_UARTPin485();

    il_SetUp_UARTReg485( baudrate );


}


/*===========================================================================================
    Function Name    : output_StaLED
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : This function output LED flash according to the 485 state
//==========================================================================================*/
void output_StaLED ( void )
{
#if(1)

	static int16_t timer = 0;

	if( CG_UART485.time_out_cnt < 65536 ){
		CG_UART485.time_out_cnt++;
	}


	#define CONDITION_GOT_DATA		( ( CG_UART485.Connection_BITF & _BIT( COMBITF_GOT_DATA ) ) != 0 )
	#define CONDITION_OVERFLOW		( ( CG_UART485.Connection_BITF   & _BIT( COMBITF_OVERFLOW ) ) != 0 )
	#define CONDITION_FRAME_ERROR	( CG_Modbus_Slave_485.is_frame_ok == 0 )

	if( CG_UART485.time_out_cnt >= STALED_TIME_OUT_CONST ){

		CG_UART485.Connection_State = STALED_TIMEOUT;

		CG_UART485.Connection_BITF &= ~_BIT( COMBITF_OVERFLOW );
		CG_UART485.Connection_BITF &= ~_BIT( COMBITF_GOT_DATA );
		CG_Modbus_Slave_485.is_frame_ok = NO;
	}else if( CG_Modbus_Slave_485.is_frame_ok ){
		CG_UART485.Connection_State = STALED_FINE;
	}else if( CONDITION_GOT_DATA && ( CONDITION_OVERFLOW || ( CONDITION_FRAME_ERROR && CG_UART485.time_out_cnt >= STALED_FLASH_PULSE_WIDTH ) ) ){
		CG_UART485.Connection_State = STALED_FRAME_ERROR;
	}

	switch ( CG_UART485.Connection_State ){
	case STALED_TIMEOUT:
	default:
		//COM_LED_OFF;
	    //ioExp_SetOutput( IO_EXP_STA_LED, LOW );
		//otherGPIO_SetOutput( OTHER_OUTPUT_STA_LED, LOW );
	    CG_MD.STA_LED_State_RS485 = LOW;
		timer = 0;
		break;
	case STALED_FINE:
		//COM_LED_ON;
	    //ioExp_SetOutput( IO_EXP_STA_LED, HIGH );
	    //otherGPIO_SetOutput( OTHER_OUTPUT_STA_LED, HIGH );
	    CG_MD.STA_LED_State_RS485 = HIGH;
		timer = 0;
		break;
	case STALED_FRAME_ERROR:
		if( ++timer >= STALED_FLASH_PULSE_WIDTH ){
			//COM_LED_TOGGLE;
		    //ioExp_ToggleOutput( IO_EXP_STA_LED );
		    //otherGPIO_ToggleOutput( OTHER_OUTPUT_STA_LED );
		    CG_MD.STA_LED_State_RS485 = 1 - CG_MD.STA_LED_State_RS485;
			timer = 0;
		}
		break;

	}
#endif

}

/*===========================================================================================
    Function Name    : scibRxFifoIsr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__interrupt void scibRxFifoIsr(void)
{

	if( ScibRegs.SCIRXST.bit.RXERROR == 1 ){

		ScibRegs.SCICTL1.all = 0x0000;
		ScibRegs.SCICTL1.all = 0x0033;     // Relinquish SCI from Reset

	}else{

		 /* Receive Data Available */
		CG_UART485.Connection_BITF |= _BIT( COMBITF_GOT_DATA );
		CG_UART485.time_out_cnt = 0;

		CG_UART485.R_data_buffer[ CG_UART485.R_data_pointer++ ] = ScibRegs.SCIRXBUF.all;

		if( CG_UART485.ReceiveFlag == UART_READY ){

            if( CG_UART485.modbus_mode == MB_SLV_RTU ){
                CG_UART485.get_data_flag = YES;
                CG_UART485.rtu_time_point_2 = FREE_RUN_TIMER.TIM.all;

            }else{

                if( CG_UART485.R_data_buffer[ CG_UART485.R_data_pointer - 1 ] == START_BYTE ){
                    CG_UART485.R_data_buffer[ 0 ] = START_BYTE;
                    CG_UART485.R_data_pointer = 1;

                }else if( CG_UART485.R_data_buffer[ CG_UART485.R_data_pointer - 1 ] == END_BYTE ){
                    CG_UART485.R_data_number = CG_UART485.R_data_pointer;
                    CG_UART485.R_data_pointer = 0;
                    CG_UART485.ReceiveFlag = UART_DONE;

                }

            }

		}

		// buffer overflow reset
		if( CG_UART485.R_data_pointer == UART485_BUFFER_SIZE_R ){
			CG_UART485.R_data_pointer = 0;
			CG_UART485.Connection_BITF |= _BIT( COMBITF_OVERFLOW );
		}

	}


	ScibRegs.SCIFFRX.bit.RXFFOVRCLR=1;   // Clear Overflow flag
	ScibRegs.SCIFFRX.bit.RXFFINTCLR=1;   // Clear Interrupt flag
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;       // Issue PIE ack


    return;
}


/*===========================================================================================
    Function Name    : checkUARTSend485
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Check if the UART data transmit commmand has been set then decide if it
					   needs to send output data.
					   For previous version please check oringial A04 or A09 MDB code.
					   *Avoid using while loop.
//==========================================================================================*/
void checkUARTSend485( void )
{
	static uint32_t time_p1 = 0;
	uint32_t time_p2 = 0;

	//
#if( TEST_485_DEBUG_TOOL == 1 )
	TXEN_ON;
	CG_UART485.TxEn_State = TXEN_STATE_ON;
#endif

    if( CG_UART485.request_to_send_data_flag == 1 ){      // UART data transmit command has been set

    	switch( CG_UART485.TxEn_State ){
    	case TXEN_STATE_OFF:
    	    TXEN_ON;
    		CG_UART485.TxEn_State = TXEN_STATE_OPENING;
    		time_p1 = FREE_RUN_TIMER.TIM.all;
    		break;
    	case TXEN_STATE_OPENING:
    		time_p2 = FREE_RUN_TIMER.TIM.all;
    		if( time_p1 - time_p2 > CG_UART485.TX_EN_Time ){
    			CG_UART485.TxEn_State = TXEN_STATE_ON;
    		}
    		break;
    	case TXEN_STATE_ON:

    		if( CG_UART485.T_data_pointer < CG_UART485.T_data_length ){   // data transmit is not finished
				// Check if Tx buffer empty.
				if( ScibRegs.SCICTL2.bit.TXEMPTY == 1 ){
					ScibRegs.SCITXBUF.all = CG_UART485.T_data_buffer[ CG_UART485.T_data_pointer ];
					CG_UART485.T_data_pointer++;
				}

			}else{
				CG_UART485.TxEn_State = TXEN_STATE_CLOSING;
				time_p1 = FREE_RUN_TIMER.TIM.all;
			}
    		break;
    	case TXEN_STATE_CLOSING:
    		time_p2 = FREE_RUN_TIMER.TIM.all;
    		if( time_p1 - time_p2 > CG_UART485.TX_EN_Time ){
    			CG_UART485.TxEn_State = TXEN_STATE_OFF;
    			CG_UART485.request_to_send_data_flag = 0;
    			TXEN_OFF;

    		}
    		break;
    	default:
    		// impossiable place
    		break;

    	}

    }
}


/*===========================================================================================
    Function Name    : checkUARTframe_485
    Input            : Null
    Return           : Null
    Programmer       : Eric.Tsai@trumman.com.tw
					   Modified by Chaum.Chen@trumman.com.tw
    Description      : For RTU
//==========================================================================================*/
 void checkRTUframe_485( void )
{

	uint32_t dummy_rtu_time_point_2;

	if( CG_UART485.modbus_mode == MB_SLV_RTU && CG_UART485.get_data_flag == YES ){

		dummy_rtu_time_point_2 = CG_UART485.rtu_time_point_2;

		CG_UART485.rtu_time_point_1 = FREE_RUN_TIMER.TIM.all;

		if( dummy_rtu_time_point_2 - CG_UART485.rtu_time_point_1 > CG_UART485.rtu_time_frame_length ){	// in C2000, timer always decelerates

			CG_UART485.get_data_flag			= NO;
			CG_UART485.R_data_number			= CG_UART485.R_data_pointer;
			CG_UART485.R_data_pointer			= 0;
			CG_UART485.ReceiveFlag 				= UART_DONE;

		}

	}

}

 /************************** <END OF FILE> *****************************************/



