/*===========================================================================================

    File Name       : C2000_ADC.c

    Version         : V1_00_00_a

    Built Date      : 2015/08/03

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : This is the head file of ADC driver

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_ADC 								CG_ADC;
//extern volatile Struct_BLDC_Drive					CG_BLDC_Drive;
//extern volatile Struct_BLDC_CTRL 					CG_BLDC_CTRL;
extern volatile Struct_BLDC_CTRL                    CG_BLDC_CTRL_M0;

extern volatile Struct_HWEEP						CG_HWEEP;
extern volatile Struct_Pretect 						CG_Protect;
extern volatile Struct_MD 							CG_MD;
//extern volatile Struct_Encoder 						CG_Encoder;
//extern volatile Struct_Speed 						CG_Speed;
//extern volatile Struct_SPK 							CG_SPK;
//extern volatile Struct_Parameter					CG_Parameter;
extern volatile Struct_UART485  					CG_UART485;
//extern volatile Struct_ComProtocol_01               CG_ComProtocol_01;
extern volatile Struct_BLDC_Drive                      CG_BLDC_Drive_M0;

const uint16_t Const_DAC_Index[3] = { 682, 340, 2 };
const char Const_Shunt_I_Pointer[ 7 ] 		= { 0, Shunt_Index_V, Shunt_Index_V,
                                      		    Shunt_Index_W, Shunt_Index_W,
                                      		    Shunt_Index_U, Shunt_Index_U };

//#pragma CODE_SECTION( adc_isr1, "ramfuncs");
//#pragma CODE_SECTION( adc_isr1, ".TI.ramfunc" );


/*===========================================================================================
    Function Name    : variableInitial_MotorAnalog
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_MotorAnalog ( Struct_Motor_Analog* motor )
{
	int8_t i;

	motor->Power_Percentage = 0;		// HW/FW OCP restraint for low-power motor
	motor->HWOCP = 0;					// HWOCP value
	motor->FWOCP = 0;					// FWOCP value
	motor->PGA_Index = 0;
	motor->DAC_Value = 0;
	motor->CTRIP_PreScale = 0;

	//
	motor->Shunt_I_Type = 0;
	motor->Shunt_I_Pointer = 0;
	motor->Shunt_I = 0;
	motor->Shunt_I_Sum = 0;
	motor->Shunt_I_Cnt = 0;
	motor->Shunt_I_Avg = 0;
	motor->Shunt_I_With_Signed = 0;

	//

	motor->Shunt_U_HWP_P = 0;
	motor->Shunt_V_HWP_P = 0;
	motor->Shunt_W_HWP_P = 0;

	motor->Shunt_U_HWP_N = 0;
	motor->Shunt_V_HWP_N = 0;
	motor->Shunt_W_HWP_N = 0;

	motor->Shunt_BRAKE_HWP = 0;

	//
	for( i = 0; i < Shunt_Index_NUM; i++ ){
		motor->Shunt_I_Offset_Dummy[ i ] = 0;
		motor->Shunt_I_Offset[ i ] = 0;
	}

}


/*===========================================================================================
    Function Name    : variableInitial_ADC
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_ADC initial
//==========================================================================================*/
void variableInitial_ADC (void)
{
	int8_t i;

	CG_ADC.Updated_BITF = 0;
	CG_ADC.Update_Duty_Const = 0;

	for( i = 0; i < ADC_Index_Num; i ++ ){
		CG_ADC.Value_Inst[ i ] = 0;
		CG_ADC.Value_Sum[ i ] = 0;
		CG_ADC.Value_Cnt[ i ] = 0;
		CG_ADC.Value_Avg[ i ] = 0;
		CG_ADC.Value_Mapping[ i ] = 0;
		CG_ADC.Value_Smooth[ i ] = 0;

	}

	CG_ADC.BusV = 0;
	for( i = 0; i < BUSV_BUFFER_SIZE; i ++ ){
		CG_ADC.BusV_ADC[i] = 0;
	}
	CG_ADC.BusV_ADC_Sum = 0;
	CG_ADC.BusV_ADC_Pointer = 0;

	for( i = 0; i < A0A1X_BUFFER_SIZE; i ++ ){
		CG_ADC.A0X_ADC[i] = 0;
		CG_ADC.A1X_ADC[i] = 0;
	}

	CG_ADC.A0X_ADC_Sum = 0;
	CG_ADC.A1X_ADC_Sum = 0;
	CG_ADC.A0A1X_ADC_Pointer = 0;

	CG_ADC.Calibration_Cnt = 0;
	CG_ADC.Calibration_Value = 0;

	CG_ADC.Shunt_I_Calibration_Flag = NO;
	CG_ADC.Shunt_I_Calibration_Cnt = 0;

	variableInitial_MotorAnalog ( ( Struct_Motor_Analog* ) &CG_ADC.Motor_0 );

}

/*===========================================================================================
    Function Name    : il_SetUp_ADCPin
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup ADC pins.
//==========================================================================================*/
__inline void il_SetUp_ADCPin( void )
{
	// A I/O was set by default

}



/*===========================================================================================
    Function Name    : il_SetUp_ADC_A_Reg
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup ADC reg.
//==========================================================================================*/
__inline void il_SetUp_ADC_A_Reg( void )
{
	//int16_t i;

	//
	// Setup VREF as internal
	//
    SetVREF(ADC_ADCA, ADC_EXTERNAL, ADC_VREF3P3 );
    //SetVREF(ADC_ADCA, ADC_INTERNAL, ADC_VREF3P3 );

	EALLOW;

	AnalogSubsysRegs.ANAREFPP.all = 2;	// For the Errata needed: Analog Subsystem: Software Configuration for Shared Reference Pins

	//
	AdcaRegs.ADCCTL2.bit.PRESCALE = 6;

	//
	// Set pulse positions to late
	//
	AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;

	//
	// Power up the ADC and then delay for 1 ms
	//
	AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;


	DELAY_US(1000);


	// Priority
	// Seems no register can be set.

	AdcaRegs.ADCSOCPRICTL.bit.SOCPRIORITY = 6; // 06h SOC0-SOC5 are high priority, SOC6-SOC15 are in round robin mode.


	//
	Pga1Regs.PGACTL.bit.GAIN = CG_ADC.Motor_0.PGA_Index;
	Pga1Regs.PGACTL.bit.FILTRESSEL = 0;						// No filter resistor for output
	Pga1Regs.PGACTL.bit.PGAEN = 1;							// Enable PGA

	Pga5Regs.PGACTL.bit.GAIN = CG_ADC.Motor_0.PGA_Index;
	Pga5Regs.PGACTL.bit.FILTRESSEL = 0;						// No filter resistor for output
	Pga5Regs.PGACTL.bit.PGAEN = 1;							// Enable PGA

	Pga6Regs.PGACTL.bit.GAIN = CG_ADC.Motor_0.PGA_Index;
	Pga6Regs.PGACTL.bit.FILTRESSEL = 0;						// No filter resistor for output
	Pga6Regs.PGACTL.bit.PGAEN = 1;							// Enable PGA1

    Pga2Regs.PGACTL.bit.GAIN = CG_ADC.Motor_0.PGA_Index;
    Pga2Regs.PGACTL.bit.FILTRESSEL = 0;                     // No filter resistor for output
    Pga2Regs.PGACTL.bit.PGAEN = 1;                          // Enable PGA

    Pga3Regs.PGACTL.bit.GAIN = CG_ADC.Motor_0.PGA_Index;
    Pga3Regs.PGACTL.bit.FILTRESSEL = 0;                     // No filter resistor for output
    Pga3Regs.PGACTL.bit.PGAEN = 1;                          // Enable PGA

    Pga4Regs.PGACTL.bit.GAIN = CG_ADC.Motor_0.PGA_Index;
    Pga4Regs.PGACTL.bit.FILTRESSEL = 0;                     // No filter resistor for output
    Pga4Regs.PGACTL.bit.PGAEN = 1;                          // Enable PGA1

	// Triggered by PWM SOCA ( Cnt = Period )

	AdcaRegs.ADCSOC0CTL.bit.CHSEL = 2;     			    // A2 = Shunt U
	AdcaRegs.ADCSOC0CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = 5;   				// Trigger on ePWM1 SOCA

	AdcaRegs.ADCSOC1CTL.bit.CHSEL = 6;     			    // A6 = Shunt V
	AdcaRegs.ADCSOC1CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = 5;   				// Trigger on ePWM1 SOCA

	AdcaRegs.ADCSOC2CTL.bit.CHSEL = 8;     			    // A8 = Shunt W
	AdcaRegs.ADCSOC2CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC2CTL.bit.TRIGSEL = 5;   				// Trigger on ePWM1 SOCA


	AdcaRegs.ADCSOC6CTL.bit.CHSEL = 11;                 // A11 = BEMF U
    AdcaRegs.ADCSOC6CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcaRegs.ADCSOC6CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC7CTL.bit.CHSEL = 14;                 // A14 = BEMF V
    AdcaRegs.ADCSOC7CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcaRegs.ADCSOC7CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA

    AdcaRegs.ADCSOC8CTL.bit.CHSEL = 15;                 // A15 = BEMF W
    AdcaRegs.ADCSOC8CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcaRegs.ADCSOC8CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA


	// Triggered by PWM SOCB ( Cnt = Zero )

	AdcaRegs.ADCSOC3CTL.bit.CHSEL = 2;     			    // SOC0 will convert A2 ( Shunt U )
	AdcaRegs.ADCSOC3CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC3CTL.bit.TRIGSEL = 6;   				// Trigger on ePWM1 SOCB

	AdcaRegs.ADCSOC4CTL.bit.CHSEL = 6;     			    // SOC0 will convert A6 ( Shunt V )
	AdcaRegs.ADCSOC4CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC4CTL.bit.TRIGSEL = 6;   				// Trigger on ePWM1 SOCB

	AdcaRegs.ADCSOC5CTL.bit.CHSEL = 8;     			    // SOC0 will convert A8 ( Shunt W )
	AdcaRegs.ADCSOC5CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC5CTL.bit.TRIGSEL = 6;   				// Trigger on ePWM1 SOCB

	AdcaRegs.ADCSOC10CTL.bit.CHSEL 	= 9;				// A9 = A0X
	AdcaRegs.ADCSOC10CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC10CTL.bit.TRIGSEL = 6;   			// Trigger on ePWM1 SOCB

	/*
	AdcaRegs.ADCSOC11CTL.bit.CHSEL 	= 8;				// A8 = A1X
	AdcaRegs.ADCSOC11CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC11CTL.bit.TRIGSEL = 6;   			// Trigger on ePWM1 SOCB
    */
    AdcaRegs.ADCSOC12CTL.bit.CHSEL  = 10;               // A10 = POUT2_FB
    AdcaRegs.ADCSOC12CTL.bit.ACQPS = SAMPLE_CLOCK;      // Sample window
    AdcaRegs.ADCSOC12CTL.bit.TRIGSEL = 6;               // Trigger on ePWM1 SOCB

	AdcaRegs.ADCSOC13CTL.bit.CHSEL 	= 12;				// A12 = MosOT 1
	AdcaRegs.ADCSOC13CTL.bit.ACQPS = SAMPLE_CLOCK;     	// Sample window
	AdcaRegs.ADCSOC13CTL.bit.TRIGSEL = 6;   			// Trigger on ePWM1 SOCB
	/*
	AdcaRegs.ADCSOC14CTL.bit.CHSEL  = 5;                // A5 = MosOT 2
    AdcaRegs.ADCSOC14CTL.bit.ACQPS = SAMPLE_CLOCK;      // Sample window
    AdcaRegs.ADCSOC14CTL.bit.TRIGSEL = 6;               // Trigger on ePWM1 SOCB
    */

	EDIS;

}

/*===========================================================================================
    Function Name    : il_SetUp_ADC_B_Reg
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup ADC reg.
//==========================================================================================*/
__inline void il_SetUp_ADC_B_Reg( void )
{
    //int16_t i;

    //
    // Setup VREF as internal
    //
    SetVREF(ADC_ADCB, ADC_EXTERNAL, ADC_VREF3P3 );
    //SetVREF(ADC_ADCB, ADC_INTERNAL, ADC_VREF3P3 );

    EALLOW;

    //
    AdcbRegs.ADCCTL2.bit.PRESCALE = 6;

    //
    // Set pulse positions to late
    //
    AdcbRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    //
    // Power up the ADC and then delay for 1 ms
    //
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 1;


    DELAY_US(1000);


    // Priority
    // Seems no register can be set.

    AdcbRegs.ADCSOCPRICTL.bit.SOCPRIORITY = 6; // 06h SOC0-SOC5 are high priority, SOC6-SOC15 are in round robin mode.


    //
    /*
    Pga2Regs.PGACTL.bit.GAIN = CG_ADC.Motor_1.PGA_Index;
    Pga2Regs.PGACTL.bit.FILTRESSEL = 0;                     // No filter resistor for output
    Pga2Regs.PGACTL.bit.PGAEN = 1;                          // Enable PGA

    Pga3Regs.PGACTL.bit.GAIN = CG_ADC.Motor_1.PGA_Index;
    Pga3Regs.PGACTL.bit.FILTRESSEL = 0;                     // No filter resistor for output
    Pga3Regs.PGACTL.bit.PGAEN = 1;                          // Enable PGA

    Pga4Regs.PGACTL.bit.GAIN = CG_ADC.Motor_1.PGA_Index;
    Pga4Regs.PGACTL.bit.FILTRESSEL = 0;                       // No filter resistor for output
    Pga4Regs.PGACTL.bit.PGAEN = 1;                            // Enable PGA1
    */

    Pga7Regs.PGACTL.bit.GAIN = CG_ADC.Motor_0.PGA_Index;
    Pga7Regs.PGACTL.bit.FILTRESSEL = 0;                       // No filter resistor for output
    Pga7Regs.PGACTL.bit.PGAEN = 1;                            // Enable PGA1

    // SOC
    // Triggered by PWM SOCA ( Cnt = Period )
    /*
    AdcbRegs.ADCSOC0CTL.bit.CHSEL = 8;                  // B8 = Shunt U
    AdcbRegs.ADCSOC0CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC0CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA

    AdcbRegs.ADCSOC1CTL.bit.CHSEL = 2;                  // B2 = Shunt V
    AdcbRegs.ADCSOC1CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC1CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA

    AdcbRegs.ADCSOC2CTL.bit.CHSEL = x;                  // x = Shunt W
    AdcbRegs.ADCSOC2CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC2CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA

    AdcbRegs.ADCSOC6CTL.bit.CHSEL = 9;                  // B9 = BEMF U
    AdcbRegs.ADCSOC6CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC6CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA

    AdcbRegs.ADCSOC7CTL.bit.CHSEL = 10;                 // B10 = BEMF V
    AdcbRegs.ADCSOC7CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC7CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA

    AdcbRegs.ADCSOC8CTL.bit.CHSEL = 11;                 // B11 = BEMF W
    AdcbRegs.ADCSOC8CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC8CTL.bit.TRIGSEL = 5;                // Trigger on ePWM1 SOCA
     */


    // Triggered by PWM SOCB ( Cnt = Zero )
    /*
    AdcbRegs.ADCSOC3CTL.bit.CHSEL = 8;                  //
    AdcbRegs.ADCSOC3CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC3CTL.bit.TRIGSEL = 6;                // Trigger on ePWM1 SOCB

    AdcbRegs.ADCSOC4CTL.bit.CHSEL = 2;                  //
    AdcbRegs.ADCSOC4CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC4CTL.bit.TRIGSEL = 6;                // Trigger on ePWM1 SOCB

    AdcbRegs.ADCSOC5CTL.bit.CHSEL = x;                  //
    AdcbRegs.ADCSOC5CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC5CTL.bit.TRIGSEL = 6;                // Trigger on ePWM1 SOCB
    */

    AdcbRegs.ADCSOC9CTL.bit.CHSEL   = 12;                // B12 = Bus V
    AdcbRegs.ADCSOC9CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC9CTL.bit.TRIGSEL = 6;                // Trigger on ePWM1 SOCB

    AdcbRegs.ADCSOC10CTL.bit.CHSEL   = 3;                // B3 = Vcc_5V Sense
    AdcbRegs.ADCSOC10CTL.bit.ACQPS = SAMPLE_CLOCK;       // Sample window
    AdcbRegs.ADCSOC10CTL.bit.TRIGSEL = 6;                // Trigger on ePWM1 SOCB

    AdcbRegs.ADCSOC11CTL.bit.CHSEL  = 2;                // B2 = A1X
    AdcbRegs.ADCSOC11CTL.bit.ACQPS = SAMPLE_CLOCK;      // Sample window
    AdcbRegs.ADCSOC11CTL.bit.TRIGSEL = 6;               // Trigger on ePWM1 SOCB

    AdcbRegs.ADCSOC13CTL.bit.CHSEL  = 0;                // B0 = POUT1_FB
    AdcbRegs.ADCSOC13CTL.bit.ACQPS = SAMPLE_CLOCK;      // Sample window
    AdcbRegs.ADCSOC13CTL.bit.TRIGSEL = 6;               // Trigger on ePWM1 SOCB

    AdcbRegs.ADCSOC14CTL.bit.CHSEL  = 10;                // B10 = MosOT 2
    AdcbRegs.ADCSOC14CTL.bit.ACQPS = SAMPLE_CLOCK;      // Sample window
    AdcbRegs.ADCSOC14CTL.bit.TRIGSEL = 6;               // Trigger on ePWM1 SOCB

    AdcbRegs.ADCSOC15CTL.bit.CHSEL  = 11;                // B11 = MosOT 3
    AdcbRegs.ADCSOC15CTL.bit.ACQPS = SAMPLE_CLOCK;      // Sample window
    AdcbRegs.ADCSOC15CTL.bit.TRIGSEL = 6;               // Trigger on ePWM1 SOCB

    EDIS;

}

/*===========================================================================================
    Function Name    : il_SetUp_Compare_Trip
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SetUp_Compare_Trip( void )
{

    // Set Compare for the usage of M-Brake
    // H Compare: input (+)  |\
    //                       | ->>  Low
    //             4095 (-)  |/
    // L Compare:  4095 (+)  |\
    //                       | ->>  High
    //             input(-)  |/

    EALLOW;

#if(0)
    // DAC Out
    DacbRegs.DACCTL.bit.MODE = 0;   // 0 : Gain = 1; 1 : Gain = 2
    // Use ADC voltage reference
    //DacbRegs.DACCTL.bit.DACREFSEL = 1;
    DacbRegs.DACCTL.bit.DACREFSEL = 1;
    // Load count value for DAC on next SYSCLK
    DacbRegs.DACCTL.bit.LOADMODE = 0;
    // Enable DAC output
    DacbRegs.DACOUTEN.bit.DACOUTEN = 1;

    DacbRegs.DACVALS.all = CG_ADC.Motor_0.DAC_Value;
#endif

    // == Compare
    // Step1 : Set PGA output as Comparator's Input

    // M0
    AnalogSubsysRegs.CMPHPMXSEL.bit.CMP1HPMXSEL = 0;    // OF = Comparator High P
    AnalogSubsysRegs.CMPHPMXSEL.bit.CMP5HPMXSEL = 0;    // OF = Comparator High P
    AnalogSubsysRegs.CMPHPMXSEL.bit.CMP6HPMXSEL = 0;    // OF = Comparator High P

    AnalogSubsysRegs.CMPLPMXSEL.bit.CMP1LPMXSEL = 0;    // OF = Comparator Low P
    AnalogSubsysRegs.CMPLPMXSEL.bit.CMP5LPMXSEL = 0;    // OF = Comparator Low P
    AnalogSubsysRegs.CMPLPMXSEL.bit.CMP6LPMXSEL = 0;    // OF = Comparator Low P

    // M1
    /*
    AnalogSubsysRegs.CMPHPMXSEL.bit.CMP2HPMXSEL = 0;    // OF = Comparator High P
    AnalogSubsysRegs.CMPHPMXSEL.bit.CMP3HPMXSEL = 0;    // OF = Comparator High P
    //AnalogSubsysRegs.CMPHPMXSEL.bit.CMP4HPMXSEL = 0;    // OF = Comparator High P

    AnalogSubsysRegs.CMPLPMXSEL.bit.CMP2LPMXSEL = 0;    // OF = Comparator Low P
    AnalogSubsysRegs.CMPLPMXSEL.bit.CMP3LPMXSEL = 0;    // OF = Comparator Low P
    //AnalogSubsysRegs.CMPLPMXSEL.bit.CMP4LPMXSEL = 0;    // OF = Comparator Low P
    */

    // Set Compare for the usage of M-Brake
    AnalogSubsysRegs.CMPHPMXSEL.bit.CMP7HPMXSEL = 2;    // BusV = Comparator High P
    AnalogSubsysRegs.CMPLPMXSEL.bit.CMP7LPMXSEL = 2;    // BusV = Comparator Low P

    // Step2 : Comparator DAC Enable

    // M0
    // Select DAC source
    Cmpss1Regs.COMPDACCTL.bit.SELREF =  0;// 0 VDDA is the voltage reference for the DAC; 1 VDAC is the voltage reference for the DAC
    Cmpss5Regs.COMPDACCTL.bit.SELREF =  0;// 0 VDDA is the voltage reference for the DAC; 1 VDAC is the voltage reference for the DAC
    Cmpss6Regs.COMPDACCTL.bit.SELREF =  0;

    Cmpss1Regs.COMPCTL.bit.COMPDACE = 1;
    Cmpss5Regs.COMPCTL.bit.COMPDACE = 1;
    Cmpss6Regs.COMPCTL.bit.COMPDACE = 1;

    // M1
    // Select DAC source
    /*
    Cmpss2Regs.COMPDACCTL.bit.SELREF =  0;// 0 VDDA is the voltage reference for the DAC; 1 VDAC is the voltage reference for the DAC
    Cmpss3Regs.COMPDACCTL.bit.SELREF =  0;// 0 VDDA is the voltage reference for the DAC; 1 VDAC is the voltage reference for the DAC
    //Cmpss4Regs.COMPDACCTL.bit.SELREF =  0;
    Cmpss2Regs.COMPCTL.bit.COMPDACE = 1;
    Cmpss3Regs.COMPCTL.bit.COMPDACE = 1;
    //Cmpss4Regs.COMPCTL.bit.COMPDACE = 1;
    */

    // Set Compare for the usage of M-Brake
    Cmpss7Regs.COMPDACCTL.bit.SELREF =  0;// 0 VDDA is the voltage reference for the DAC; 1 VDAC is the voltage reference for the DAC
    Cmpss7Regs.COMPCTL.bit.COMPDACE = 1;

    // Step3 :�@: Set Comparator's N input = DAC
    // M0
    Cmpss1Regs.COMPCTL.bit.COMPHSOURCE = 0;
    Cmpss1Regs.COMPCTL.bit.COMPLSOURCE = 0;

    Cmpss5Regs.COMPCTL.bit.COMPHSOURCE = 0;
    Cmpss5Regs.COMPCTL.bit.COMPLSOURCE = 0;

    Cmpss6Regs.COMPCTL.bit.COMPHSOURCE = 0;
    Cmpss6Regs.COMPCTL.bit.COMPLSOURCE = 0;

    // M1
    /*
    Cmpss2Regs.COMPCTL.bit.COMPHSOURCE = 0;
    Cmpss2Regs.COMPCTL.bit.COMPLSOURCE = 0;

    Cmpss3Regs.COMPCTL.bit.COMPHSOURCE = 0;
    Cmpss3Regs.COMPCTL.bit.COMPLSOURCE = 0;

    //Cmpss4Regs.COMPCTL.bit.COMPHSOURCE = 0;
    //Cmpss4Regs.COMPCTL.bit.COMPLSOURCE = 0;
    */

    // Set Compare for the usage of M-Brake
    Cmpss7Regs.COMPCTL.bit.COMPHSOURCE = 0;
    Cmpss7Regs.COMPCTL.bit.COMPLSOURCE = 0;


    // Step4 : Comparator Low output should be reversed
    // M0
    Cmpss1Regs.COMPCTL.bit.COMPLINV = 1;
    Cmpss5Regs.COMPCTL.bit.COMPLINV = 1;
    Cmpss6Regs.COMPCTL.bit.COMPLINV = 1;

    // M1
    /*
    Cmpss2Regs.COMPCTL.bit.COMPLINV = 1;
    Cmpss3Regs.COMPCTL.bit.COMPLINV = 1;
    //Cmpss4Regs.COMPCTL.bit.COMPLINV = 1;
    */

    // Set Compare for the usage of M-Brake
    Cmpss7Regs.COMPCTL.bit.COMPLINV = 1;

    // Step5 : Set output with filter

    // M0
    Cmpss1Regs.COMPCTL.bit.CTRIPHSEL = 2;
    Cmpss5Regs.COMPCTL.bit.CTRIPHSEL = 2;
    Cmpss6Regs.COMPCTL.bit.CTRIPHSEL = 2;

    Cmpss1Regs.COMPCTL.bit.CTRIPLSEL = 2;
    Cmpss5Regs.COMPCTL.bit.CTRIPLSEL = 2;
    Cmpss6Regs.COMPCTL.bit.CTRIPLSEL = 2;

    // M1
    /*
    Cmpss2Regs.COMPCTL.bit.CTRIPHSEL = 2;
    Cmpss3Regs.COMPCTL.bit.CTRIPHSEL = 2;
    //Cmpss4Regs.COMPCTL.bit.CTRIPHSEL = 2;

    Cmpss2Regs.COMPCTL.bit.CTRIPLSEL = 2;
    Cmpss3Regs.COMPCTL.bit.CTRIPLSEL = 2;
    //Cmpss4Regs.COMPCTL.bit.CTRIPLSEL = 2;
    */

    // Set Compare for the usage of M-Brake
    Cmpss7Regs.COMPCTL.bit.CTRIPOUTHSEL = 2;
    Cmpss7Regs.COMPCTL.bit.CTRIPOUTLSEL = 2;

    // Step6 : Set up filter window
    #define SAMPLE_WINDOW       0x1F
    #define SAMPLE_THRESH       0x10
    #define SAMPLE_CLKPRESCALE  CG_ADC.Motor_0.CTRIP_PreScale//0x20
    // M0
    Cmpss1Regs.CTRIPHFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss5Regs.CTRIPHFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss6Regs.CTRIPHFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;

    Cmpss1Regs.CTRIPHFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss5Regs.CTRIPHFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss6Regs.CTRIPHFILCTL.bit.THRESH = SAMPLE_THRESH;

    Cmpss1Regs.CTRIPHFILCTL.bit.FILINIT = 1;
    Cmpss5Regs.CTRIPHFILCTL.bit.FILINIT = 1;
    Cmpss6Regs.CTRIPHFILCTL.bit.FILINIT = 1;

    Cmpss1Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    Cmpss5Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    Cmpss6Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;

    Cmpss1Regs.CTRIPLFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss5Regs.CTRIPLFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss6Regs.CTRIPLFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;

    Cmpss1Regs.CTRIPLFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss5Regs.CTRIPLFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss6Regs.CTRIPLFILCTL.bit.THRESH = SAMPLE_THRESH;

    Cmpss1Regs.CTRIPLFILCTL.bit.FILINIT = 1;
    Cmpss5Regs.CTRIPLFILCTL.bit.FILINIT = 1;
    Cmpss6Regs.CTRIPLFILCTL.bit.FILINIT = 1;

    Cmpss1Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    Cmpss5Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    Cmpss6Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;

    // M1
    /*
    Cmpss2Regs.CTRIPHFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss3Regs.CTRIPHFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    //Cmpss4Regs.CTRIPHFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;

    Cmpss2Regs.CTRIPHFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss3Regs.CTRIPHFILCTL.bit.THRESH = SAMPLE_THRESH;
    //Cmpss4Regs.CTRIPHFILCTL.bit.THRESH = SAMPLE_THRESH;

    Cmpss2Regs.CTRIPHFILCTL.bit.FILINIT = 1;
    Cmpss3Regs.CTRIPHFILCTL.bit.FILINIT = 1;
    //Cmpss4Regs.CTRIPHFILCTL.bit.FILINIT = 1;

    Cmpss2Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    Cmpss3Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    //Cmpss4Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;

    Cmpss2Regs.CTRIPLFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss3Regs.CTRIPLFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    //Cmpss4Regs.CTRIPLFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;

    Cmpss2Regs.CTRIPLFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss3Regs.CTRIPLFILCTL.bit.THRESH = SAMPLE_THRESH;
    //Cmpss4Regs.CTRIPLFILCTL.bit.THRESH = SAMPLE_THRESH;

    Cmpss2Regs.CTRIPLFILCTL.bit.FILINIT = 1;
    Cmpss3Regs.CTRIPLFILCTL.bit.FILINIT = 1;
    //Cmpss4Regs.CTRIPLFILCTL.bit.FILINIT = 1;

    Cmpss2Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    Cmpss3Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    //Cmpss4Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;
    */

    // Set Compare for the usage of M-Brake
    Cmpss7Regs.CTRIPHFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss7Regs.CTRIPHFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss7Regs.CTRIPHFILCTL.bit.FILINIT = 1;
    Cmpss7Regs.CTRIPHFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;

    Cmpss7Regs.CTRIPLFILCTL.bit.SAMPWIN = SAMPLE_WINDOW;
    Cmpss7Regs.CTRIPLFILCTL.bit.THRESH = SAMPLE_THRESH;
    Cmpss7Regs.CTRIPLFILCTL.bit.FILINIT = 1;
    Cmpss7Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE = SAMPLE_CLKPRESCALE;

    Cmpss7Regs.DACHVALS.bit.DACVAL = DAC_MAX_VALUE;
    Cmpss7Regs.DACLVALS.bit.DACVAL = DAC_MAX_VALUE;

    // Step7 : Set ePWM X Bar
    //if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
        // M0
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX0 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX1 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX8 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX9 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX10 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX11 = 0;

        // M1
        /*
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX2 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX3 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX4 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX5 = 0;
        //EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX6 = 0;
        //EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX7 = 0;
        */

#if( TEST_HWOCP_OPEN == 1 )

        // M0
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX0 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX1 = 1;
        if( CG_ADC.Is_ShuntV_Exist ){
            EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX8 = 1;
            EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX9 = 1;
        }
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX10 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX11 = 1;

        // M1
        /*
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX2 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX3 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX4 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX5 = 1;
        //EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX6 = 1;
        //EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX7 = 1;
        */

#endif
    //}else{
#if(0)
        // M0
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX0 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX1 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX8 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX9 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX10 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX11 = 0;

        /*
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX2 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX3 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX4 = 0;
        EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX5 = 0;
        */

        // M1
        /*
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX0 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX1 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX8 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX9 = 0;

        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX2 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX3 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX4 = 0;
        EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX5 = 0;
        */

#if( TEST_HWOCP_OPEN == 1 )

        // M0
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX0 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX1 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX8 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX9 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX10 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX11 = 1;

        /*
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX2 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX3 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX4 = 1;
        EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX5 = 1;
        // M1

        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX0 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX1 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX8 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX9 = 1;

        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX2 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX3 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX4 = 1;
        EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX5 = 1;
        */

#endif
    }
#endif

    EDIS;

}

/*===========================================================================================
    Function Name    : il_SetUp_ADC_IRQ
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SetUp_ADC_IRQ( void )
{
    EALLOW;

    // Enable ADCINT1 in PIE
    PieVectTable.ADCA1_INT = &adc_isr1;
    AdcaRegs.ADCINTSEL1N2.bit.INT1E     = 1;    // Enabled ADCINT2
    AdcaRegs.ADCINTSEL1N2.bit.INT1CONT  = 0;    // Disable ADCINT2 Continuous mode
    //AdcaRegs.ADCINTSEL1N2.bit.INT1CONT  = 1;  // For the errata needed, Use Continue-to-Interrupt Mode to prevent the ADCINTFLG from blocking additional ADC interrupts:
    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL   = 10;    // setup EOC11 to trigger ADCINT2 to fire

    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;  // Enable INT 1.1 in the PIE
    IER |= M_INT1;                      // Enable CPU Interrupt 1

    EDIS;
}

/*===========================================================================================
    Function Name    : setupInitial_ADC
    Input            : 1. hwocp
                        2. fwocp
                        3. power_percentage
                        4. pga_index
                        5. ocp_detect_prescale
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : ADC initialzation function.
					   For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_ADC( int32_t hwocp, int32_t fwocp, int32_t power_percentage, int32_t pga_index, int32_t ocp_detect_prescale )
{

    variableInitial_ADC();

    if( CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_V_H ] != 0 ){
        CG_ADC.Is_ShuntV_Exist = YES;
    }else{
        CG_ADC.Is_ShuntV_Exist = NO;
    }

    pga_index = PGA_Index_X3;

    // M0
    CG_ADC.Motor_0.Power_Percentage = power_percentage;
	if( CG_ADC.Motor_0.Power_Percentage == 0 || CG_ADC.Motor_0.Power_Percentage > PERCENTAGE_100 ){
		CG_ADC.Motor_0.Power_Percentage = PERCENTAGE_100;
	}
	CG_ADC.Motor_0.HWOCP = hwocp * CG_ADC.Motor_0.Power_Percentage / PERCENTAGE_100;										// HWOCP value
	CG_ADC.Motor_0.FWOCP = fwocp * CG_ADC.Motor_0.Power_Percentage / PERCENTAGE_100;										// FWOCP value

	/*
	if( CG_MD.Driver_Mode == PA_DRIVER_MODE_1BIG_MOTOR ){
	    CG_ADC.Motor_0.HWOCP *= 2;
	    CG_ADC.Motor_0.FWOCP *= 2;
	}*/

    CG_ADC.Motor_0.PGA_Index = ( pga_index >= PGA_Index_NUM ? PGA_Index_X3 : pga_index );
    CG_ADC.Motor_0.DAC_Value = Const_DAC_Index[ pga_index ];
    CG_ADC.Motor_0.CTRIP_PreScale = ( ocp_detect_prescale > CTRIP_CLKPRESCALE_MAX ? 0 : ocp_detect_prescale );

    // M1
    /*
    CG_ADC.Motor_1.Power_Percentage = CG_ADC.Motor_0.Power_Percentage;
    CG_ADC.Motor_1.HWOCP = CG_ADC.Motor_0.HWOCP;                                        // HWOCP value
    CG_ADC.Motor_1.FWOCP = CG_ADC.Motor_0.FWOCP;                                        // FWOCP value

    CG_ADC.Motor_1.PGA_Index = CG_ADC.Motor_0.PGA_Index;
    CG_ADC.Motor_1.DAC_Value = CG_ADC.Motor_0.DAC_Value;
    CG_ADC.Motor_1.CTRIP_PreScale = CG_ADC.Motor_0.CTRIP_PreScale;
    */

    il_SetUp_ADCPin();                  // To set pins as ADC function.

    //il_SetUp_ADC_Reg();               // To set ADC registers. Please Check the user maual.

    il_SetUp_ADC_A_Reg();               //
    il_SetUp_ADC_B_Reg();               //

    il_SetUp_Compare_Trip();

    il_SetUp_ADC_IRQ();

}


/*===========================================================================================
    Function Name    : setup_DACA
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setup_DACA( int32_t dac )
{
    EALLOW;

#if(1)
    // DAC Out
    DacaRegs.DACCTL.bit.MODE = 0;   // 0 : Gain = 1; 1 : Gain = 2
    // Use ADC voltage reference
    //DacbRegs.DACCTL.bit.DACREFSEL = 1;

    DacaRegs.DACCTL.bit.DACREFSEL = 1;  // 0 VDAC/VSSA are the reference voltages, 1 ADC VREFHI/VSSA are the reference voltages

    // Load count value for DAC on next SYSCLK
    DacaRegs.DACCTL.bit.LOADMODE = 0;
    // Enable DAC output
    DacaRegs.DACOUTEN.bit.DACOUTEN = 1;

    DacaRegs.DACVALS.all = dac;
#endif

    EDIS;

}

/*===========================================================================================
    Function Name    : setValue_DACA
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setValue_DACA( int32_t dac )
{
    EALLOW;
#if(1)
    DacaRegs.DACVALS.all = dac;
#endif
    EDIS;
}

/*===========================================================================================
    Function Name    : setup_DACB
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setup_DACB( int32_t dac )
{
    EALLOW;

#if(1)
    // DAC Out
    DacbRegs.DACCTL.bit.MODE = 0;   // 0 : Gain = 1; 1 : Gain = 2
    // Use ADC voltage reference
    //DacbRegs.DACCTL.bit.DACREFSEL = 1;

    DacbRegs.DACCTL.bit.DACREFSEL = 1;  // 0 VDAC/VSSA are the reference voltages, 1 ADC VREFHI/VSSA are the reference voltages

    // Load count value for DAC on next SYSCLK
    DacbRegs.DACCTL.bit.LOADMODE = 0;
    // Enable DAC output
    DacbRegs.DACOUTEN.bit.DACOUTEN = 1;

    DacbRegs.DACVALS.all = dac;
#endif

    EDIS;

}

/*===========================================================================================
    Function Name    : setValue_DACB
    Input            : 1.dac
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setValue_DACB( int32_t dac )
{
    EALLOW;
#if(1)
    DacbRegs.DACVALS.all = dac;
#endif
    EDIS;
}

/*===========================================================================================
    Function Name    : setup_HWPADC
    Input            : 1.motor_analog
                        2.hweep_shunt_full_scale_u
                        3.hweep_shunt_full_scale_v
                        4.hweep_shunt_full_scale_w
                        5.hweep_shunt_offset_u
                        6.hweep_shunt_offset_v
                        7.hweep_shunt_offset_w
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : HWP ADC setup
//==========================================================================================*/
void setup_HWPADC ( Struct_Motor_Analog* motor_analog,
                    int32_t hweep_shunt_full_scale_u,
                    int32_t hweep_shunt_full_scale_v,
                    int32_t hweep_shunt_full_scale_w,
                    int32_t hweep_shunt_offset_u,
                    int32_t hweep_shunt_offset_v,
                    int32_t hweep_shunt_offset_w )
{
	int32_t temp_p = 0;
	int32_t temp_n = 0;
	int32_t dummy = 0;
	int32_t dummy1;
	int32_t dummy2;
	int8_t i;
	//int32_t shunt_i_offset_sum;
	//int32_t shunt_i_hwp_sum;
	int32_t* shunt_hwp_p[ Shunt_Index_NUM ];
	int32_t* shunt_hwp_n[ Shunt_Index_NUM ];

	motor_analog->Shunt_I_Offset[ Shunt_Index_U ] = ( hweep_shunt_offset_u != 0 ? hweep_shunt_offset_u : motor_analog->Shunt_I_Offset_Dummy[ Shunt_Index_U ] );
	motor_analog->Shunt_I_Offset[ Shunt_Index_V ] = ( hweep_shunt_offset_v != 0 ? hweep_shunt_offset_v : motor_analog->Shunt_I_Offset_Dummy[ Shunt_Index_V ] );
	motor_analog->Shunt_I_Offset[ Shunt_Index_W ] = ( hweep_shunt_offset_w != 0 ? hweep_shunt_offset_w : motor_analog->Shunt_I_Offset_Dummy[ Shunt_Index_W ] );

	motor_analog->Shunt_I_Full_Scale[ Shunt_Index_U ] = hweep_shunt_full_scale_u;
	motor_analog->Shunt_I_Full_Scale[ Shunt_Index_V ] = hweep_shunt_full_scale_v;
	motor_analog->Shunt_I_Full_Scale[ Shunt_Index_W ] = hweep_shunt_full_scale_w;

	shunt_hwp_p[ Shunt_Index_U ] = (int32_t*)&motor_analog->Shunt_U_HWP_P;
	shunt_hwp_p[ Shunt_Index_V ] = (int32_t*)&motor_analog->Shunt_V_HWP_P;
	shunt_hwp_p[ Shunt_Index_W ] = (int32_t*)&motor_analog->Shunt_W_HWP_P;

	shunt_hwp_n[ Shunt_Index_U ] = (int32_t*)&motor_analog->Shunt_U_HWP_N;
	shunt_hwp_n[ Shunt_Index_V ] = (int32_t*)&motor_analog->Shunt_V_HWP_N;
	shunt_hwp_n[ Shunt_Index_W ] = (int32_t*)&motor_analog->Shunt_W_HWP_N;


	for( i = 0; i < Shunt_Index_NUM; i++ ){

		if( motor_analog->Shunt_I_Full_Scale[i] != 0 ){
			dummy = CG_ADC.Motor_0.HWOCP * ADC_MAX_VALUE / motor_analog->Shunt_I_Full_Scale[i];
			/*
			if( CG_MD.Driver_Mode == PA_DRIVER_MODE_1BIG_MOTOR ){
			    dummy /= 2;
			}*/
		}

		//temp_p = ( CG_ADC.Motor_0.Shunt_I_Offset[ i ] + dummy ) * DAC_RESOLUTION;
		//temp_n = ( CG_ADC.Motor_0.Shunt_I_Offset[ i ] - dummy ) * DAC_RESOLUTION;
		temp_p = ( ( DAC_RESOLUTION / 2 ) + dummy ) * DAC_RESOLUTION;
		temp_n = ( ( DAC_RESOLUTION / 2 ) - dummy ) * DAC_RESOLUTION;

		// P
		dummy1 = ( temp_p / ADC_MAX_VALUE ) * 2;
		dummy2 = ( temp_p * 2 ) / ADC_MAX_VALUE;
		if( dummy2 > dummy1 ){
			*shunt_hwp_p[i] = dummy1 / 2;
		}else{
			*shunt_hwp_p[i] = dummy1 / 2 - 1;
		}

		if( *shunt_hwp_p[i] > DAC_RESOLUTION - 1 ){
			*shunt_hwp_p[i] = DAC_RESOLUTION - 1;
		}else if( *shunt_hwp_p[i] < 0 ){
			*shunt_hwp_p[i] = 0;
		}

		// N
		dummy1 = ( temp_n / ADC_MAX_VALUE ) * 2;
		dummy2 = ( temp_n * 2 ) / ADC_MAX_VALUE;
		if( dummy2 > dummy1 ){
			*shunt_hwp_n[i] = dummy1 / 2;
		}else{
			*shunt_hwp_n[i] = dummy1 / 2 - 1;
		}

		if( *shunt_hwp_n[i] > DAC_RESOLUTION - 1 ){
			*shunt_hwp_n[i] = DAC_RESOLUTION - 1;
		}else if( *shunt_hwp_n[i] < 0 ){
			*shunt_hwp_n[i] = 0;
		}

	}

}


/*===========================================================================================
    Function Name    : calibration_ShuntIOffset
    Input            : 1.hweep_shunt_full_scale_m0_u
                        2.hweep_shunt_full_scale_m0_v
                        3.hweep_shunt_full_scale_m0_w
                        4.hweep_shunt_offset_m0_u
                        5.hweep_shunt_offset_m0_v
                        6.hweep_shunt_offset_m0_w
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Shunt I offset adjustment
//==========================================================================================*/
void calibration_ShuntIOffset ( int32_t hweep_shunt_full_scale_m0_u,
                                int32_t hweep_shunt_full_scale_m0_v,
                                int32_t hweep_shunt_full_scale_m0_w,
                                int32_t hweep_shunt_offset_m0_u,
                                int32_t hweep_shunt_offset_m0_v,
                                int32_t hweep_shunt_offset_m0_w )
{

	if( CG_ADC.Shunt_I_Calibration_Cnt < CONST_SHUNT_I_CALIBRATION ){

	    CG_ADC.Motor_0.Shunt_I_Offset_Dummy[ Shunt_Index_U ] += ( ( CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U ] + CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U2 ] ) / 2 );
	    CG_ADC.Motor_0.Shunt_I_Offset_Dummy[ Shunt_Index_V ] += ( ( CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_V ] + CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_V2 ] ) / 2 );
	    CG_ADC.Motor_0.Shunt_I_Offset_Dummy[ Shunt_Index_W ] += ( ( CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_W ] + CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_W2 ] ) / 2 );

	    //CG_ADC.Motor_1.Shunt_I_Offset_Dummy[ Shunt_Index_U ] += ( ( CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_U ] + CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_U2 ] ) / 2 );
        //CG_ADC.Motor_1.Shunt_I_Offset_Dummy[ Shunt_Index_V ] += ( ( CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_V ] + CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_V2 ] ) / 2 );
        //CG_ADC.Motor_1.Shunt_I_Offset_Dummy[ Shunt_Index_W ] += ( ( CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_W ] + CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_W2 ] ) / 2 );

        CG_ADC.Shunt_I_Calibration_Cnt++;
        if( CG_ADC.Shunt_I_Calibration_Cnt == CONST_SHUNT_I_CALIBRATION ){

            CG_ADC.Shunt_I_Calibration_Flag = YES;

            CG_ADC.Motor_0.Shunt_I_Offset_Dummy[ Shunt_Index_U ] /= CONST_SHUNT_I_CALIBRATION;
            CG_ADC.Motor_0.Shunt_I_Offset_Dummy[ Shunt_Index_V ] /= CONST_SHUNT_I_CALIBRATION;
            CG_ADC.Motor_0.Shunt_I_Offset_Dummy[ Shunt_Index_W ] /= CONST_SHUNT_I_CALIBRATION;

            //CG_ADC.Motor_1.Shunt_I_Offset_Dummy[ Shunt_Index_U ] /= CONST_SHUNT_I_CALIBRATION;
            //CG_ADC.Motor_1.Shunt_I_Offset_Dummy[ Shunt_Index_V ] /= CONST_SHUNT_I_CALIBRATION;
            //CG_ADC.Motor_1.Shunt_I_Offset_Dummy[ Shunt_Index_W ] /= CONST_SHUNT_I_CALIBRATION;

            setup_HWPADC( (Struct_Motor_Analog*)&CG_ADC.Motor_0,
                          hweep_shunt_full_scale_m0_u,
                          hweep_shunt_full_scale_m0_v,
                          hweep_shunt_full_scale_m0_w,
                          hweep_shunt_offset_m0_u,
                          hweep_shunt_offset_m0_v,
                          hweep_shunt_offset_m0_w );
            /*
            setup_HWPADC( (Struct_Motor_Analog*)&CG_ADC.Motor_1,
                          hweep_shunt_full_scale_m1_u,
                          hweep_shunt_full_scale_m1_v,
                          hweep_shunt_full_scale_m1_w,
                          hweep_shunt_offset_m1_u,
                          hweep_shunt_offset_m1_v,
                          hweep_shunt_offset_m1_w );
            */


            #if( TEST_HWOCP_OPEN == 1 )

            EALLOW;

            // M0
            Cmpss1Regs.DACHVALS.bit.DACVAL = CG_ADC.Motor_0.Shunt_U_HWP_P;
            Cmpss1Regs.DACLVALS.bit.DACVAL = CG_ADC.Motor_0.Shunt_U_HWP_N;

            if( CG_ADC.Is_ShuntV_Exist ){
                Cmpss5Regs.DACHVALS.bit.DACVAL = CG_ADC.Motor_0.Shunt_V_HWP_P;
                Cmpss5Regs.DACLVALS.bit.DACVAL = CG_ADC.Motor_0.Shunt_V_HWP_N;
            }

            Cmpss6Regs.DACHVALS.bit.DACVAL = CG_ADC.Motor_0.Shunt_W_HWP_P;
            Cmpss6Regs.DACLVALS.bit.DACVAL = CG_ADC.Motor_0.Shunt_W_HWP_N;

            // M1
            /*
            Cmpss2Regs.DACHVALS.bit.DACVAL = CG_ADC.Motor_1.Shunt_U_HWP_P;
            Cmpss2Regs.DACLVALS.bit.DACVAL = CG_ADC.Motor_1.Shunt_U_HWP_N;
            Cmpss3Regs.DACHVALS.bit.DACVAL = CG_ADC.Motor_1.Shunt_V_HWP_P;
            Cmpss3Regs.DACLVALS.bit.DACVAL = CG_ADC.Motor_1.Shunt_V_HWP_N;
            Cmpss4Regs.DACHVALS.bit.DACVAL = CG_ADC.Motor_1.Shunt_W_HWP_P;
            Cmpss4Regs.DACLVALS.bit.DACVAL = CG_ADC.Motor_1.Shunt_W_HWP_N;
            */

            EDIS;

            #endif


        }

	}

}

/*===========================================================================================
    Function Name    : polling_ADC_MainLoop
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @main loop
//==========================================================================================*/
void polling_ADC_MainLoop( void )
{

	if( ( ( CG_ADC.Updated_BITF >> ADC_Index_M0_Shunt_U ) & 0x01 ) ){

		CG_ADC.Updated_BITF &= ~( 1UL << ADC_Index_M0_Shunt_U );

		CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U ] = AdcaResultRegs.ADCRESULT0;
		CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_V ] = AdcaResultRegs.ADCRESULT1;
		CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_W ] = AdcaResultRegs.ADCRESULT2;

		//CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_U ] = AdcbResultRegs.ADCRESULT0;
		//CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_V ] = AdcbResultRegs.ADCRESULT1;
		//CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_W ] = AdcbResultRegs.ADCRESULT2;

		calculateAvg_ADC( ADC_Index_M0_Shunt_U );
		calculateAvg_ADC( ADC_Index_M0_Shunt_V );
		calculateAvg_ADC( ADC_Index_M0_Shunt_W );

		//calculateAvg_ADC( ADC_Index_M1_Shunt_U );
		//calculateAvg_ADC( ADC_Index_M1_Shunt_V );
		//calculateAvg_ADC( ADC_Index_M1_Shunt_W );
	}

	if( ( ( CG_ADC.Updated_BITF >> ADC_Index_M0_Shunt_U2 ) & 0x01 ) ){

		CG_ADC.Updated_BITF &= ~( 1UL << ADC_Index_M0_Shunt_U2 );

		CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U2 ] = AdcaResultRegs.ADCRESULT3;
		CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_V2 ] = AdcaResultRegs.ADCRESULT4;
		CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_W2 ] = AdcaResultRegs.ADCRESULT5;

		//CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_U2 ] = AdcbResultRegs.ADCRESULT3;
		//CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_V2 ] = AdcbResultRegs.ADCRESULT4;
		//CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_W2 ] = AdcbResultRegs.ADCRESULT5;

        calculateAvg_ADC( ADC_Index_M0_Shunt_U2 );
        calculateAvg_ADC( ADC_Index_M0_Shunt_V2 );
        calculateAvg_ADC( ADC_Index_M0_Shunt_W2 );
        //calculateAvg_ADC( ADC_Index_M1_Shunt_U2 );
        //calculateAvg_ADC( ADC_Index_M1_Shunt_V2 );
        //calculateAvg_ADC( ADC_Index_M1_Shunt_W2 );


		CG_ADC.Value_Inst[ ADC_Index_A0X ] 	= AdcaResultRegs.ADCRESULT10;
		CG_ADC.Value_Inst[ ADC_Index_A1X ] 	= AdcbResultRegs.ADCRESULT11;

		//calculateAvg_ADC( ADC_Index_A0X );
		//calculateAvg_ADC( ADC_Index_A1X );
		calculateAvg_A0A1X();


	}

}

/*===========================================================================================
    Function Name    : polling_ADC_1ms
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @1ms event
//==========================================================================================*/
void polling_ADC_1ms( void )
{
	//int32_t shunt_max = 0;
	int32_t shunt_u;
	int32_t shunt_v;
	//int32_t shunt_w;
	int32_t shunt_alpha;
	int32_t shunt_beta;
	int32_t shunt_i;
	int32_t i;
	Struct_BLDC_CTRL *bldc_ctrl;
	Struct_Motor_Analog* motor_adc;
	//uint16_t *value_inst;

	//CG_ADC.Value_Inst[ ADC_Index_BUSV ] 		= AdcResult.ADCRESULT9;
	//calculateAvg_ADC( ADC_Index_BUSV );

	CG_ADC.Value_Mapping[ ADC_Index_A0X ] = calibration_3Point( 	CG_ADC.Value_Avg[ ADC_Index_A0X ],//CG_ADC.Value_Avg[ ADC_Index_EXT_VR1 ],
																		CG_HWEEP.HW_Info[ HWEEP_IDX_AD0_L0 ], AD_L0_V * THROTTLE_MULTIFY,
																		CG_HWEEP.HW_Info[ HWEEP_IDX_AD0_H0 ], AD_H0_V * THROTTLE_MULTIFY,
																		CG_HWEEP.HW_Info[ HWEEP_IDX_AD0_H1 ], AD_H1_V * THROTTLE_MULTIFY );

	CG_ADC.Value_Mapping[ ADC_Index_A1X ] = calibration_3Point( 	CG_ADC.Value_Avg[ ADC_Index_A1X ],//CG_ADC.Value_Avg[ ADC_Index_EXT_VR2 ],
																		CG_HWEEP.HW_Info[ HWEEP_IDX_AD1_L0 ], AD_L0_V * THROTTLE_MULTIFY,
																		CG_HWEEP.HW_Info[ HWEEP_IDX_AD1_H0 ], AD_H0_V * THROTTLE_MULTIFY,
																		CG_HWEEP.HW_Info[ HWEEP_IDX_AD1_H1 ], AD_H1_V * THROTTLE_MULTIFY );
	// Bus V

	CG_ADC.BusV = calculatePhysic_BUSV( CG_ADC.Value_Avg[ ADC_Index_BusV ] );

#if(1)
	// Shunt I

	if( CG_ADC.Shunt_I_Calibration_Flag ){

	    for( i = 0; i < CG_MD.Driver_Num; i++ ){
	        /*
            if( i == 0 ){
                bldc_ctrl = (Struct_BLDC_CTRL *)&CG_BLDC_CTRL_M0;
            }else{
                bldc_ctrl = (Struct_BLDC_CTRL *)&CG_BLDC_CTRL_M1;
            }*/

	        bldc_ctrl = (Struct_BLDC_CTRL *)&CG_BLDC_CTRL_M0;

            motor_adc = bldc_ctrl->ADC_Ptr;

            if( bldc_ctrl->Drive_Ptr->HWOCP_Flag ){
                motor_adc->Shunt_I = motor_adc->HWOCP;
            }else{

                if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag ){
                    motor_adc->Shunt_I_Type = SHUNT_I_TYPE_SAMPLE_FOC;
                }else{
                    motor_adc->Shunt_I_Type = SHUNT_I_TYPE_SAMPLE_ON_SINGLE;
                }

                switch( motor_adc->Shunt_I_Type ){
                case SHUNT_I_TYPE_SAMPLE_ON_SINGLE:
                default:

                    shunt_u = bldc_ctrl->Drive_Ptr->FOC.Shunt_Ia;
#if( TEST_HW_VER_B )
                    shunt_v = bldc_ctrl->Drive_Ptr->FOC.Shunt_Ic;
#else

                    shunt_v = bldc_ctrl->Drive_Ptr->FOC.Shunt_Ic;

#endif
                    //shunt_w = 0 - shunt_u - shunt_v;

                    if( shunt_u < 0 ){
                        shunt_u *= -1;
                    }
                    if( shunt_v < 0 ){
                        shunt_v *= -1;
                    }
                    /*
                    if( shunt_w < 0 ){
                        shunt_w *= -1;
                    }*/

                    shunt_i = shunt_u;
                    if( shunt_v > shunt_i ){
                        shunt_i = shunt_v;
                    }

                    /*
                    if( shunt_w > shunt_i ){
                        shunt_i = shunt_w;
                    }*/

                    break;

                case SHUNT_I_TYPE_SAMPLE_OFF_MULTIPLE:

                    shunt_alpha = bldc_ctrl->Drive_Ptr->FOC.Shunt_Ialpha;
                    shunt_beta = bldc_ctrl->Drive_Ptr->FOC.Shunt_Ibeta;

                    shunt_i = newtonSqrt( shunt_alpha * shunt_alpha + shunt_beta * shunt_beta );

                    break;

                case SHUNT_I_TYPE_SAMPLE_FOC:

                    shunt_i = il_FOC_Get_Iq ( ( Struct_FOC* ) &bldc_ctrl->Drive_Ptr->FOC );

                    break;

                }

                if( shunt_i < 0 ){
                    shunt_i *= -1;
                }

                motor_adc->Shunt_I = shunt_i;

            }

	    }

	}else{
		CG_ADC.Motor_0.Shunt_I = 0;
		//CG_ADC.Motor_1.Shunt_I = 0;
	}

	CG_ADC.Motor_0.Shunt_I_Sum += CG_ADC.Motor_0.Shunt_I;
	CG_ADC.Motor_0.Shunt_I_Cnt ++;
	if( CG_ADC.Motor_0.Shunt_I_Cnt >= SHUNT_BUFFER_SIZE ){
		CG_ADC.Motor_0.Shunt_I_Avg = CG_ADC.Motor_0.Shunt_I_Sum / CG_ADC.Motor_0.Shunt_I_Cnt;
		CG_ADC.Motor_0.Shunt_I_Sum = 0;
		CG_ADC.Motor_0.Shunt_I_Cnt = 0;

		// Power
		CG_ADC.Motor_0.Power = ( CG_ADC.Motor_0.Shunt_I_Avg * CG_ADC.BusV / CG_BLDC_Drive_M0.Period ) * CG_BLDC_Drive_M0.Duty_Apply_Abs / 10000;
		//CG_ADC.Motor_0.Power = ( CG_ADC.Motor_0.Shunt_I_Avg * CG_ADC.BusV / CG_BLDC_Drive_M0.Period ) * CG_BLDC_Drive_M0.Duty_Apply_Abs / 1000;
	}

	/*
	CG_ADC.Motor_1.Shunt_I_Sum += CG_ADC.Motor_1.Shunt_I;
    CG_ADC.Motor_1.Shunt_I_Cnt ++;
    if( CG_ADC.Motor_1.Shunt_I_Cnt >= SHUNT_BUFFER_SIZE ){
        CG_ADC.Motor_1.Shunt_I_Avg = CG_ADC.Motor_1.Shunt_I_Sum / CG_ADC.Motor_1.Shunt_I_Cnt;
        CG_ADC.Motor_1.Shunt_I_Sum = 0;
        CG_ADC.Motor_1.Shunt_I_Cnt = 0;

        // Power
        CG_ADC.Motor_1.Power = ( CG_ADC.Motor_1.Shunt_I_Avg * CG_ADC.BusV / CG_BLDC_Drive_M1.Period ) * CG_BLDC_Drive_M1.Duty_Apply_Abs / 10000;
    }
    */

#endif

}

/*===========================================================================================
    Function Name    : polling_ADC_10ms
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @10ms event
//==========================================================================================*/
void polling_ADC_10ms( void )
{
    CG_ADC.Value_Inst[ ADC_Index_MosOT_1 ]       = AdcaResultRegs.ADCRESULT13;
    CG_ADC.Value_Inst[ ADC_Index_MosOT_2 ]       = AdcbResultRegs.ADCRESULT14;
    CG_ADC.Value_Inst[ ADC_Index_MosOT_3 ]       = AdcbResultRegs.ADCRESULT15;

    CG_ADC.Value_Inst[ ADC_Index_VCC5V_SENSE ] = AdcbResultRegs.ADCRESULT10;

    CG_ADC.Value_Inst[ ADC_Index_POUT1_FB ] = AdcbResultRegs.ADCRESULT13;
    CG_ADC.Value_Inst[ ADC_Index_POUT2_FB ] = AdcaResultRegs.ADCRESULT12;

    calculateAvg_ADC( ADC_Index_MosOT_1 );
    calculateAvg_ADC( ADC_Index_MosOT_2 );
    calculateAvg_ADC( ADC_Index_MosOT_3 );

    calculateAvg_ADC( ADC_Index_VCC5V_SENSE );
    calculateAvg_ADC( ADC_Index_POUT1_FB );
    calculateAvg_ADC( ADC_Index_POUT2_FB );

}

/*===========================================================================================
    Function Name    : calculatePhysic_BUSV
    Input            :
					   1.adc_value: ADC value
    Return           : Bus v value ( unit: 0.01 Volt )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate bus v physic value.
//==========================================================================================*/
int32_t calculatePhysic_BUSV( uint32_t adc_value )
{
	int32_t BusV_result = 0;

	BusV_result = BUSV_PHYSIC_MAX * adc_value / ADC_MAX_VALUE;

	return BusV_result;
}


/*===========================================================================================
    Function Name    : calculatePhysic_ShuntI_WithOffset
    Input            :
					   1.adc_value: ADC value
					   2.offset_adc: opa reference offset
					   3.physic_max: current for delta 3.3V
    Return           : Shunt I value ( unit: 0.01 A )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate Shunt I physic value.
//==========================================================================================*/
int32_t calculatePhysic_ShuntI_WithOffset( uint32_t adc_value, int32_t offset_adc, int32_t physic_max )
{
	int32_t ShuntI_result = 0;
	int32_t dummy_value;

#if(0)
	if( adc_value > offset_adc ){
		dummy_value = adc_value - offset_adc;
	}else{
		dummy_value = offset_adc - adc_value;
	}
#else
	dummy_value = adc_value - offset_adc;
#endif

	ShuntI_result = physic_max * dummy_value / ADC_MAX_VALUE;

	return ShuntI_result;
}

/*===========================================================================================
    Function Name    : calculate_Throttle
    Input            :
					   1.input_x: 	input value x
					   2.RefA_x:	Ref. A's x value
					   3.RefA_y:	Ref. A's y value
					   4.RefB_x:	Ref. B's x value
					   5.RefB_y:	Ref. B's y value
    Return           : Output y
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t calibration( int32_t input_x, int32_t RefA_x, int32_t RefA_y, int32_t RefB_x, int32_t RefB_y )
{
	int32_t output_y = 0;

	if( RefB_x - RefA_x != 0 ){
		output_y = RefA_y + ( input_x - RefA_x ) * ( RefB_y - RefA_y ) / ( RefB_x - RefA_x );
	}

	// Gear test
	if (output_y < 0) {
		output_y = 0;
	}

	return output_y;

}

/*===========================================================================================
    Function Name    : calibration_3Point
    Input            :
					   1.input_x: 	input value x
					   2.RefA_x:	Ref. A's x value
					   3.RefA_y:	Ref. A's y value
					   4.RefB_x:	Ref. B's x value
					   5.RefB_y:	Ref. B's y value
					   6.RefB_x:	Ref. C's x value
					   7.RefB_y:	Ref. C's y value

    Return           : Output y
    Programmer       : Andrew.an@trumman.com.tw
    Description      : According to Chaim's older calculate_Throttle function
//==========================================================================================*/
int32_t calibration_3Point( int32_t input_x, int32_t RefA_x, int32_t RefA_y, int32_t RefB_x, int32_t RefB_y, int32_t RefC_x, int32_t RefC_y )
{
	int32_t output_y = 0;

	//determine use which part to calibration
	if ( input_x < RefB_x ){
		if( RefB_x - RefA_x != 0 ){
			output_y = RefA_y + ( input_x - RefA_x ) * ( RefB_y - RefA_y ) / ( RefB_x - RefA_x );
		}
		if (output_y < 0) {
			output_y = 0;
		}
		return output_y;
	}else{
		if( RefC_x - RefB_x != 0 ){
			output_y = RefB_y + ( input_x - RefB_x ) * ( RefC_y - RefB_y ) / ( RefC_x - RefB_x );
		}
		if (output_y < 0) {
			output_y = 0;
		}
		return output_y;
	}

}

/*===========================================================================================
    Function Name    : calculate_Throttle
    Input            :
					   1.adc_value: 	ADC value
					   2.throttle_max:	Throttle max value
					   3.throttle_min:	Throttle min value ( Deadband )
					   4.output_max:	Max output duty
					   5.output_min:	Min output duty
					   6.map_factor:	Output duty corresponse to half throttle value
					   7.type:			Normal rising / falling , speciel rising / falling
					   8.deadband
    Return           : result
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate result by throttle.
//==========================================================================================*/
int32_t calculate_Throttle( uint32_t adc_value,
							uint32_t throttle_max,
							uint32_t throttle_min,
							uint32_t output_max,
							uint32_t output_min,
							uint32_t map_factor,
							uint8_t  type,
							uint32_t deadband )
{
	int32_t  result = 0;
	uint32_t output_map = ( output_max - output_min ) * map_factor / THROTTLE_100_PERCENT + output_min;
	uint32_t throttle_mid = ( throttle_max + throttle_min ) / 2;
	uint32_t throttle_length = throttle_max - throttle_min;

	int32_t processed_max;
	int32_t processed_min;
	int32_t processed_mid;
	int32_t processed_value;

	switch( type ){

		case Throttle_WIG_WAG:
		case Throttle_WIG_WAG_R:
		case Throttle_UNIPOLAR:

			processed_max = throttle_length / 2;
			processed_min = deadband;
			processed_mid = ( processed_max + processed_min ) / 2;

			if( adc_value <= throttle_mid ){
				processed_value = throttle_mid - adc_value;
			}else{
				processed_value = adc_value - throttle_mid;
			}

			break;

		case Throttle_SINGLE_ENDED_R:

			processed_max = throttle_max;
			processed_min = throttle_min;
			processed_mid = throttle_mid;

			if( adc_value > throttle_max + throttle_min ){
				processed_value = 0;
			}else{
				processed_value = throttle_max + throttle_min - adc_value;
			}

			break;

		case Throttle_SINGLE_ENDED:
		default:

			processed_max = throttle_max;
			processed_min = throttle_min;
			processed_mid = throttle_mid;
			processed_value = adc_value;

			break;
	}

	if( processed_value <= processed_mid ){

		if( processed_value <= processed_min ){
			result = output_min;
		}else{
			result = ( output_map - output_min ) * ( processed_value - processed_min ) / ( processed_mid - processed_min ) + output_min;
		}
	}else{

		if( processed_value >= processed_max ){
			result = output_max;
		}else{
			result = ( output_max - output_map ) * ( processed_value - processed_mid ) / ( processed_max - processed_mid ) + output_map;
		}

	}

	return result;
}

/*===========================================================================================
    Function Name    : calculate_AD_Input_to_Spd
    Input            :
					   1.input: 		input value
					   2.offset_V:		offset voltage of zero point
					   3.offset_output:	offset output
					   4.output_max:	Output max value to limit the output
					   5.output_min:	Output min value to limit the output
					   6.gain:			gain value of the ad input. (rpm per 1V)
    Return           : Output
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Calculate output by ad input.
//==========================================================================================*/
int32_t calculate_AD_Input_to_Spd( 	uint32_t input,
									uint32_t offset_V,
									uint32_t offset_output,
									uint32_t output_max,
									uint32_t output_min,
									uint32_t gain )
{
	int32_t Output = 0;

	if (input < offset_V) {
		input = offset_V;
	}

	Output = ( ( input - offset_V ) * gain ) / ( 100 * THROTTLE_MULTIFY ) + offset_output;

	// limit
	if ( Output > output_max ) {
		Output = output_max;
	} else if ( Output <  output_min ) {
		Output = output_min;
	}

	return Output;
}


/*===========================================================================================
    Function Name    : calculateAvg_ADC
    Input            : Index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate ADC avg value.
    				   @polling_ADC
//==========================================================================================*/
void calculateAvg_ADC( int8_t index )
{
	CG_ADC.Value_Cnt[ index ]++;
	CG_ADC.Value_Sum[ index ]+= CG_ADC.Value_Inst[ index ];

	if( CG_ADC.Value_Cnt[ index ] >= SLOW_ADC_BUFF_SIZE ){	// 200Hz,

		CG_ADC.Value_Avg[ index ] = CG_ADC.Value_Sum[ index ] / CG_ADC.Value_Cnt[ index ];

		CG_ADC.Value_Sum[ index ] = 0;
		CG_ADC.Value_Cnt[ index ] = 0;
	}
}

/*===========================================================================================
    Function Name    : calculateAvg_BusV
    Input            : Index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate BusV avg value.
    				   @ADC_IRQ
//==========================================================================================*/
void calculateAvg_BusV( void )
{
	uint16_t new_value = CG_ADC.Value_Inst[ ADC_Index_BusV ];
	uint16_t old_value = CG_ADC.BusV_ADC[ CG_ADC.BusV_ADC_Pointer ];

	CG_ADC.BusV_ADC_Sum -= old_value;
	CG_ADC.BusV_ADC[ CG_ADC.BusV_ADC_Pointer ] = new_value;
	CG_ADC.BusV_ADC_Sum += new_value;

	if( ++CG_ADC.BusV_ADC_Pointer >= BUSV_BUFFER_SIZE ){
		CG_ADC.BusV_ADC_Pointer = 0;
	}

	CG_ADC.Value_Avg[ ADC_Index_BusV ] = CG_ADC.BusV_ADC_Sum >> BUSV_BUFFER_SIZE_BIT;

}

/*===========================================================================================
    Function Name    : calculateAvg_A0A1X
    Input            : Index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate A0A1X avg value.
//==========================================================================================*/
void calculateAvg_A0A1X( void )
{
	uint16_t new_value_a1 = CG_ADC.Value_Inst[ ADC_Index_A0X ];
	uint16_t old_value_a1 = CG_ADC.A0X_ADC[ CG_ADC.A0A1X_ADC_Pointer ];
	uint16_t new_value_a2 = CG_ADC.Value_Inst[ ADC_Index_A1X ];
	uint16_t old_value_a2 = CG_ADC.A1X_ADC[ CG_ADC.A0A1X_ADC_Pointer ];

	CG_ADC.A0X_ADC_Sum -= old_value_a1;
	CG_ADC.A0X_ADC[ CG_ADC.A0A1X_ADC_Pointer ] = new_value_a1;
	CG_ADC.A0X_ADC_Sum += new_value_a1;

	CG_ADC.A1X_ADC_Sum -= old_value_a2;
	CG_ADC.A1X_ADC[ CG_ADC.A0A1X_ADC_Pointer ] = new_value_a2;
	CG_ADC.A1X_ADC_Sum += new_value_a2;

	if( ++CG_ADC.A0A1X_ADC_Pointer >= A0A1X_BUFFER_SIZE ){
		CG_ADC.A0A1X_ADC_Pointer = 0;
	}

	CG_ADC.Value_Avg[ ADC_Index_A0X ] = CG_ADC.A0X_ADC_Sum >> A0A1X_BUFFER_SIZE_BIT;
	CG_ADC.Value_Avg[ ADC_Index_A1X ] = CG_ADC.A1X_ADC_Sum >> A0A1X_BUFFER_SIZE_BIT;

}

/*===========================================================================================
    Function Name    : setADC_UpdateDutyConst
    Input            : freq : PWM freq
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate ADC avg value.
    				   @BLDC Drive setupInitial_BLDCDrive
//==========================================================================================*/
void setADC_UpdateDutyConst( int32_t freq )
{
	CG_ADC.Update_Duty_Const = freq / ADC_UPDATE_DUTY_FREQUENCE;
}

/*===========================================================================================
    Function Name    : il_calculateAngle
    Input            : 1.encoder
                        2.pos_reg: position from encoder peripheral
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_calculateAngle ( Struct_Basic_Encoder* encoder, int32_t pos_reg )
{
    int32_t angle;
    int32_t current_pos = pos_reg;

    encoder->Pos_Reg = current_pos;
    if( encoder->Z_Got_Flag ){
        if( encoder->Dir_Def == FORWARD_DIR_TOP ){
            angle = current_pos + encoder->Offset;
        }else{
            angle = encoder->MaxPos - current_pos + encoder->Offset;
        }
    }else{
        if( encoder->Dir_Def == FORWARD_DIR_TOP ){
            angle = current_pos + encoder->Guess_Pos_T0;
        }else{
            angle = encoder->MaxPos - current_pos + encoder->Guess_Pos_T0;
        }
        angle += encoder->Offset;
    }

    //angle = angle * SINE_TABLE_RESOLUTION / encoder->MaxPos_ForFOC;
    //angle = MOD( angle, SINE_TABLE_RESOLUTION );
    angle = (int32_t)( (float)( angle * SINE_TABLE_RESOLUTION ) / (float)encoder->MaxPos_ForFOC );
    angle = angle - ( ( int32_t )( (float)angle / (float)SINE_TABLE_RESOLUTION ) ) * SINE_TABLE_RESOLUTION;

    return angle;
}

/*===========================================================================================
    Function Name    : il_calculateAngle_ByHall
    Input            : 1.bldc_ctrl
                       2.offset
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_calculateAngle_ByHall ( Struct_BLDC_CTRL *bldc_ctrl, int32_t offset )
{
    int32_t angle;
    Struct_HallSensor *hall = bldc_ctrl->Hall_Ptr;
    uint32_t current_time;
    int32_t dummy;
    int32_t adjust = bldc_ctrl->Adjust_Angle;
    int8_t direction = DIR_UNKNOWN;

    hall->PA_Time_Stamp = hall->INT_Time_New;
    current_time = CURRENT_TIMER_CNT;
    hall->PA_Time_Pass = hall->PA_Time_Stamp - current_time;

    hall->PA_State = hall->Current_State;

    if( ( hall->Current_Dir == DIR_CW && hall->Dir_Def == FORWARD_DIR_TOP ) ||
        ( hall->Current_Dir == DIR_CCW && hall->Dir_Def == FORWARD_DIR_BOTTOM )  ){
        direction = DIR_CW;
    }else if( ( hall->Current_Dir == DIR_CCW && hall->Dir_Def == FORWARD_DIR_TOP ) ||
            ( hall->Current_Dir == DIR_CW && hall->Dir_Def == FORWARD_DIR_BOTTOM )){
        direction = DIR_CCW;
    }

    if( hall->PA_Time_Pass > hall->PA_Time_Threshold &&
        hall->Smooth_Flag &&
        hall->INT_Times > PA_OPEN_CNT ){

        if( hall->Current_Dir == DIR_CW ){
            hall->PA_State = hall->Next_State_If_CW;
        }else if( hall->Current_Dir == DIR_CCW ){
            hall->PA_State = hall->Next_State_If_CCW;
        }
    }

    if( hall->Sequence == HALL_SEQUENCE_A ){
        angle = 30 + Const_Encoder_Distance_HallA[ hall->PA_State ] * 60;
    }else{
        angle = Const_Encoder_Distance_HallB[ hall->PA_State ] * 60;
        angle -= 30;
        if( angle < 0 ){
            angle += 360;
        }
    }

    dummy = hall->Ecycle_ERPM_Abs * 6 + bldc_ctrl->Delta_Angle_Rest;
    bldc_ctrl->Delta_Angle = dummy / bldc_ctrl->Drive_Ptr->Frequency;
    bldc_ctrl->Delta_Angle_Rest = dummy % bldc_ctrl->Drive_Ptr->Frequency;
    if( hall->PA_State_Old != hall->PA_State ){
        //if( hall->Current_Dir == DIR_CW ){
        if( direction == DIR_CW ){
            adjust = bldc_ctrl->Delta_Angle;
        //}else if( hall->Current_Dir == DIR_CCW ){
        }else if( direction == DIR_CCW ){
            adjust = 60 - bldc_ctrl->Delta_Angle;
        }else{
            adjust = 30;
        }
    }else{
        //if( hall->Current_Dir == DIR_CW ){
        if( direction == DIR_CW ){
            adjust += bldc_ctrl->Delta_Angle;
        }else{
            adjust -= bldc_ctrl->Delta_Angle;
        }

        if( adjust > 60 ){
            adjust = 60;
        }else if( adjust < 0 ){
            adjust = 0;
        }
    }

    bldc_ctrl->Adjust_Angle = adjust;

    //if( hall->INT_Times > PA_OPEN_CNT ){
        angle += adjust;
    //}

    angle += offset;
    if( angle > 360 ){
        angle -= 360;
    }else if( angle < 0 ){
        angle += 360;
    }

    hall->PA_State_Old = hall->PA_State;

    return angle;
}


#if( TEST_485_DEBUG_TOOL )
static inline il_485_data_prepare(void)
{
    int32_t dummy;

    CG_UART485.T_data_pointer = 0;

    /*
    CG_UART485.T_data_buffer[ 0 ] = CG_BLDC_CTRL_M0.Current_Target_Speed_RPM_Abs >> 8;
    CG_UART485.T_data_buffer[ 1 ] = CG_BLDC_CTRL_M0.Current_Target_Speed_RPM_Abs & 0xFF;
    CG_UART485.T_data_buffer[ 2 ] = CG_BLDC_CTRL_M0.Accelerate >> 8;

    CG_UART485.T_data_buffer[ 3 ] = CG_BLDC_CTRL_M0.Accelerate & 0xFF;
    CG_UART485.T_data_buffer[ 4 ] = CG_BLDC_CTRL_M0.Decelerate >> 8;
    CG_UART485.T_data_buffer[ 5 ] = CG_BLDC_CTRL_M0.Decelerate & 0xFF;
    */
    dummy = CG_BLDC_CTRL_M0.Hall_Ptr->Position;
    CG_UART485.T_data_buffer[ 0 ] = dummy >> 8;
    CG_UART485.T_data_buffer[ 1 ] = dummy & 0xFF;

    dummy = CG_BLDC_CTRL_M0.PositionCtrl.Drive_Infor.SpeedERPM;
    CG_UART485.T_data_buffer[ 2 ] = dummy >> 8;
    CG_UART485.T_data_buffer[ 3 ] = dummy & 0xFF;

    dummy = CG_BLDC_CTRL_M0.Hall_Ptr->Current_State;
    CG_UART485.T_data_buffer[ 4 ] = dummy >> 8;
    CG_UART485.T_data_buffer[ 5 ] = dummy & 0xFF;

    CG_UART485.T_data_length = 6;
    CG_UART485.request_to_send_data_flag = 1;

}
#endif

/*===========================================================================================
    Function Name    : il_rtCtrl
    Input            : bldc_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_rtCtrl ( Struct_BLDC_CTRL *bldc_ctrl )
{
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;
    int32_t busv = CG_ADC.Value_Avg[ ADC_Index_BusV ];
    Struct_HallSensor *hall = bldc_ctrl->Hall_Ptr;

    if( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING  ){

        if( ++bldc_ctrl->RealTimeCtrl_Cnt >= bldc_ctrl->RealTimeCtrl_Const ){
            bldc_ctrl->RealTimeCtrl_Cnt = 0;
            CG_MD.Test_tp1            = FREE_RUN_TIMER.TIM.all;
            rtCtrl_MotorRun( bldc_ctrl );

#if( TEST_485_DEBUG_TOOL )
            if( bldc_ctrl->MultiDrive_Src == SRC_MULTI_DRIVE_M0 ){
                il_485_data_prepare();
            }
#endif

            CG_MD.Test_tp2            = FREE_RUN_TIMER.TIM.all;
            CG_MD.Test_time       = CG_MD.Test_tp1 - CG_MD.Test_tp2;  // 1635 clk ticks for encoder model
        }

        if( bldc_drive->Mode != BLDCDRIVE_FOC ){
            bldc_ctrl->Commutation = bldc_drive->Commutation_Table[ bldc_ctrl->Target_Dir ][ bldc_ctrl->Hall_Ptr->Current_State ];
            //
            il_Hall_PhaseAdvance( hall, bldc_ctrl->Commutation );
            if( hall->PA_Flag ){
                bldc_drive->Commutation_Out( hall->PA_Commutation );
            }else{
                bldc_drive->Commutation_Out( bldc_ctrl->Commutation );
            }
            //

            //bldc_drive->Commutation_Out( bldc_ctrl->Commutation );
        }

#if( TEST_CTRL_BUSV_USED )
        if( bldc_drive->Mode != BLDCDRIVE_FOC &&
            bldc_ctrl->InstStop_CMD != YES &&
            bldc_ctrl->Control_Mode != CTRL_OPENLOOP ){

            bldc_ctrl->Current_Duty = (int16_t)bldc_ctrl->PositionCtrl.SpdCtrl.Output;
            if( busv != 0 ){
                bldc_ctrl->Current_Duty = bldc_ctrl->Current_Duty * bldc_ctrl->BusVRef_ADC / busv;
            }

            if( bldc_ctrl->Current_Duty > 0 ){
                if( bldc_ctrl->Current_Duty > bldc_drive->Period_Limit ){
                    bldc_ctrl->Current_Duty = bldc_drive->Period_Limit;
                }
                bldc_ctrl->Target_Dir = DIR_CW;
                bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
            }else if( bldc_ctrl->Current_Duty < 0 ){
                if( bldc_ctrl->Current_Duty < -bldc_drive->Period_Limit ){
                    bldc_ctrl->Current_Duty = -bldc_drive->Period_Limit;
                }
                bldc_ctrl->Target_Dir = DIR_CCW;
                bldc_ctrl->Current_Duty_Abs = -bldc_ctrl->Current_Duty;
            }else{
                bldc_ctrl->Current_Duty_Abs = 0;
            }
            bldc_drive->Duty_Out( bldc_ctrl->Current_Duty_Abs,
                                  bldc_ctrl->Current_Duty_Abs,
                                  bldc_ctrl->Current_Duty_Abs );

        }
#endif

    }else if( bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ){

        if( ++bldc_ctrl->RealTimeCtrl_Cnt >= bldc_ctrl->RealTimeCtrl_Const ){
            bldc_ctrl->RealTimeCtrl_Cnt = 0;
            CG_MD.Test_tp1            = FREE_RUN_TIMER.TIM.all;
            rtCtrl_MotorMove( bldc_ctrl );

#if( TEST_485_DEBUG_TOOL )
            if( bldc_ctrl->MultiDrive_Src == SRC_MULTI_DRIVE_M0 ){
                il_485_data_prepare();
            }
#endif

            CG_MD.Test_tp2            = FREE_RUN_TIMER.TIM.all;
            CG_MD.Test_time       = CG_MD.Test_tp1 - CG_MD.Test_tp2;  // 1373 clk ticks

        }

        if( bldc_drive->Mode != BLDCDRIVE_FOC ){
            bldc_ctrl->Commutation = bldc_drive->Commutation_Table[ bldc_ctrl->Target_Dir ][ bldc_ctrl->Hall_Ptr->Current_State ];
            //
            il_Hall_PhaseAdvance( hall, bldc_ctrl->Commutation );
            if( hall->PA_Flag ){
                bldc_drive->Commutation_Out( hall->PA_Commutation );
            }else{
                bldc_drive->Commutation_Out( bldc_ctrl->Commutation );
            }
            //

            //bldc_drive->Commutation_Out( bldc_ctrl->Commutation );
        }

#if( TEST_CTRL_BUSV_USED )
        if( bldc_drive->Mode != BLDCDRIVE_FOC &&
            bldc_ctrl->InstStop_CMD != YES ){

            bldc_ctrl->Current_Duty = (int16_t)bldc_ctrl->PositionCtrl.SpdCtrl.Output;
            if( busv != 0 ){
                bldc_ctrl->Current_Duty = bldc_ctrl->Current_Duty * bldc_ctrl->BusVRef_ADC / busv;
            }

            if( bldc_ctrl->Current_Duty > 0 ){
                if( bldc_ctrl->Current_Duty > bldc_drive->Period_Limit ){
                    bldc_ctrl->Current_Duty = bldc_drive->Period_Limit;
                }
                bldc_ctrl->Target_Dir = DIR_CW;
                bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
            }else if( bldc_ctrl->Current_Duty < 0 ){
                if( bldc_ctrl->Current_Duty < -bldc_drive->Period_Limit ){
                    bldc_ctrl->Current_Duty = -bldc_drive->Period_Limit;
                }
                bldc_ctrl->Target_Dir = DIR_CCW;
                bldc_ctrl->Current_Duty_Abs = -bldc_ctrl->Current_Duty;
            }else{
                bldc_ctrl->Current_Duty_Abs = 0;
            }
            bldc_drive->Duty_Out( bldc_ctrl->Current_Duty_Abs,
                                  bldc_ctrl->Current_Duty_Abs,
                                  bldc_ctrl->Current_Duty_Abs );


        }
#endif

    }else{

        if( bldc_ctrl->Motor_State == MOTOR_STATE_EBRAKING  ){
            if( bldc_ctrl->Ctrl_Updated == NO ){
                bldc_ctrl->Ctrl_Updated  = YES;
                management_BrakePWMDuty( bldc_ctrl );
            }
        }

        bldc_ctrl->RealTimeCtrl_Cnt = 0;
    }

}

/*===========================================================================================
    Function Name    : adc_isr1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : ADC IRQ event1.
//==========================================================================================*/
__interrupt void adc_isr1(void)
{
    Struct_BLDC_CTRL *bldc_ctrl;
	Struct_ADC 	*adc;
	Struct_FOC	*foc;
	uint16_t    *adc_value;
	uint16_t     *adc_offset;
	int32_t     *physic_max;
	Struct_Basic_Encoder* encoder;
	uint32_t     encoder_pos_reg;
    int32_t is_iq_ctrl;
    int32_t target;
    int8_t i;
    uint8_t hall_state;

	//int32_t angle = 0;
	//
	//Struct_Encoder *encoder;
	//int32_t offset;
	//int32_t lock_point;


#if(TEST_CALCULATE_TIME_COST)
    CG_MD.ADC_TP_Old = FREE_RUN_TIMER.TIM.all;
#endif

#if(TEST_DUTY_UPDATE_FROM_ADC)
    PWM_M0_U.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - CG_BLDC_Drive_M0.Duty_U;
    PWM_M0_V.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - CG_BLDC_Drive_M0.Duty_V;
    PWM_M0_W.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - CG_BLDC_Drive_M0.Duty_W;

    /*
    if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
        PWM_M1_U.CMPA.bit.CMPA = CG_BLDC_Drive_M1.Period - CG_BLDC_Drive_M1.Duty_U;
        PWM_M1_V.CMPA.bit.CMPA = CG_BLDC_Drive_M1.Period - CG_BLDC_Drive_M1.Duty_V;
        PWM_M1_W.CMPA.bit.CMPA = CG_BLDC_Drive_M1.Period - CG_BLDC_Drive_M1.Duty_W;
    }else{
        PWM_M1_U.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - CG_BLDC_Drive_M0.Duty_U;
        PWM_M1_V.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - CG_BLDC_Drive_M0.Duty_V;
        PWM_M1_W.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - CG_BLDC_Drive_M0.Duty_W;
    }*/
#endif

	adc = ( Struct_ADC* )&CG_ADC;

	adc->Updated_BITF |= ( 1UL << ADC_Index_M0_Shunt_U );
	adc->Updated_BITF |= ( 1UL << ADC_Index_M0_Shunt_U2 );

	// Shunt

    adc->Value_Inst[ ADC_Index_M0_Shunt_U2 ] = AdcaResultRegs.ADCRESULT3;
    adc->Value_Inst[ ADC_Index_M0_Shunt_V2 ] = AdcaResultRegs.ADCRESULT4;
    adc->Value_Inst[ ADC_Index_M0_Shunt_W2 ] = AdcaResultRegs.ADCRESULT5;

    /*
    adc->Value_Inst[ ADC_Index_M1_Shunt_U2 ] = AdcbResultRegs.ADCRESULT3;
    adc->Value_Inst[ ADC_Index_M1_Shunt_V2 ] = AdcbResultRegs.ADCRESULT4;
    //adc->Value_Inst[ ADC_Index_M1_Shunt_W2 ] = AdcbResultRegs.ADCRESULT5;
    */


    // BEMF
    adc->Value_Inst[ ADC_Index_M0_BEMF_U ] = AdcaResultRegs.ADCRESULT6;
    adc->Value_Inst[ ADC_Index_M0_BEMF_V ] = AdcaResultRegs.ADCRESULT7;
    adc->Value_Inst[ ADC_Index_M0_BEMF_W ] = AdcaResultRegs.ADCRESULT8;

    /*
    adc->Value_Inst[ ADC_Index_M1_BEMF_U ] = AdcbResultRegs.ADCRESULT6;
    adc->Value_Inst[ ADC_Index_M1_BEMF_V ] = AdcbResultRegs.ADCRESULT7;
    adc->Value_Inst[ ADC_Index_M1_BEMF_W ] = AdcbResultRegs.ADCRESULT8;
    */

	adc->Value_Inst[ ADC_Index_BusV ] = AdcbResultRegs.ADCRESULT9;

	calculateAvg_BusV();

#if(1)
	if( adc->Value_Inst[ ADC_Index_BusV ] > CG_Protect.OverBusV_Clamping ||
		adc->Value_Inst[ ADC_Index_BusV ] < CG_Protect.UnderBusV_Clamping ){

		EALLOW;
		// M0
		PWM_M0_U.TZFRC.bit.CBC = 1;
		PWM_M0_V.TZFRC.bit.CBC = 1;
		PWM_M0_W.TZFRC.bit.CBC = 1;
		// M1
		/*
		PWM_M1_U.TZFRC.bit.CBC = 1;
        PWM_M1_V.TZFRC.bit.CBC = 1;
        PWM_M1_W.TZFRC.bit.CBC = 1;
        */
		EDIS;
	}
#endif

	// ==
	// M0

	for( i = 0; i < CG_MD.Driver_Num; i++ ){

	    /*
	    if( i == 0 ){
	        bldc_ctrl = (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0;
            adc_value = (uint16_t*)&CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U2 ];
            adc_offset = (uint16_t*)&CG_ADC.Motor_0.Shunt_I_Offset[ Shunt_Index_U ];
            physic_max = (int32_t*)&CG_ADC.Motor_0.Shunt_I_Full_Scale[ Shunt_Index_U ];
            encoder_pos_reg = EQep1Regs.QPOSCNT;
	    }else{
	        // M1
            bldc_ctrl = (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1;
            adc_value = (uint16_t*)&CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_U2 ];
            adc_offset = (uint16_t*)&CG_ADC.Motor_1.Shunt_I_Offset[ Shunt_Index_U ];
            physic_max = (int32_t*)&CG_ADC.Motor_1.Shunt_I_Full_Scale[ Shunt_Index_U ];
            encoder_pos_reg = EQep2Regs.QPOSCNT;
	    }*/
	    bldc_ctrl = (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0;
        adc_value = (uint16_t*)&CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U2 ];
        adc_offset = (uint16_t*)&CG_ADC.Motor_0.Shunt_I_Offset[ Shunt_Index_U ];
        physic_max = (int32_t*)&CG_ADC.Motor_0.Shunt_I_Full_Scale[ Shunt_Index_U ];
        encoder_pos_reg = EQep1Regs.QPOSCNT;
        //
        hall_state = MOTOR_S2S1S0_SIGNAL_M0;

	    foc = (Struct_FOC*)&bldc_ctrl->Drive_Ptr->FOC;
        encoder = bldc_ctrl->Encoder_Ptr;

        if( bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL ){
            foc->Angle = il_calculateAngle_ByHall ( bldc_ctrl, encoder->Offset );
        }else{
            foc->Angle = il_calculateAngle ( encoder, encoder_pos_reg );

            //
            if( hall_state == encoder->Next_State_If_CW ){
                encoder->Hall_Cnt++;
            }else if( hall_state == encoder->Next_State_If_CCW ){
                encoder->Hall_Cnt--;
            }
            encoder->Next_State_If_CW = bldc_ctrl->Hall_Ptr->Next_State_Table[ DIR_CW  ][ hall_state ];
            encoder->Next_State_If_CCW = bldc_ctrl->Hall_Ptr->Next_State_Table[ DIR_CCW ][ hall_state ];
            //
        }
        foc->SensorAngle = foc->Angle;
        if( bldc_ctrl->FOCTest_Flag ){
            foc->Angle = bldc_ctrl->FOCTest_Angle;
        }

        /*
        if( CG_MD.HW_Ver == HW_VER_A ){

            if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
                foc->Shunt_Ia = il_Calculate_ShuntI_abc_WithOffset_P( adc_value[ Shunt_Index_U ], adc_offset[ Shunt_Index_U ], physic_max[ Shunt_Index_U ] );
                foc->Shunt_Ib = il_Calculate_ShuntI_abc_WithOffset_P( adc_value[ Shunt_Index_V ], adc_offset[ Shunt_Index_V ], physic_max[ Shunt_Index_V ] );
                //foc->Shunt_Ic = il_Calculate_ShuntI_abc_WithOffset_P( adc_value[ Shunt_Index_W ], adc_offset[ Shunt_Index_W ], physic_max[ Shunt_Index_W ] );
            }else{
                foc->Shunt_Ia = il_Calculate_ShuntI_abc_WithOffset_P( CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_U ],
                                                                      CG_ADC.Motor_0.Shunt_I_Offset[ Shunt_Index_U ],
                                                                      CG_ADC.Motor_0.Shunt_I_Full_Scale[ Shunt_Index_U ] ) +
                                il_Calculate_ShuntI_abc_WithOffset_P( CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_U ],
                                                                      CG_ADC.Motor_1.Shunt_I_Offset[ Shunt_Index_U ],
                                                                      CG_ADC.Motor_1.Shunt_I_Full_Scale[ Shunt_Index_U ] );

                foc->Shunt_Ib = il_Calculate_ShuntI_abc_WithOffset_P( CG_ADC.Value_Inst[ ADC_Index_M0_Shunt_V ],
                                                                      CG_ADC.Motor_0.Shunt_I_Offset[ Shunt_Index_V ],
                                                                      CG_ADC.Motor_0.Shunt_I_Full_Scale[ Shunt_Index_V ] ) +
                                il_Calculate_ShuntI_abc_WithOffset_P( CG_ADC.Value_Inst[ ADC_Index_M1_Shunt_V ],
                                                                      CG_ADC.Motor_1.Shunt_I_Offset[ Shunt_Index_V ],
                                                                      CG_ADC.Motor_1.Shunt_I_Full_Scale[ Shunt_Index_V ] );


            }

            foc->Shunt_Ic = -foc->Shunt_Ia - foc->Shunt_Ib;

        }*/

        foc->Shunt_Ia = il_Calculate_ShuntI_abc_WithOffset_P( adc_value[ Shunt_Index_U ], adc_offset[ Shunt_Index_U ], physic_max[ Shunt_Index_U ] );
        //foc->Shunt_Ib = il_Calculate_ShuntI_abc_WithOffset( adc_value[ Shunt_Index_V ], adc_offset[ Shunt_Index_V ], physic_max[ Shunt_Index_V ] );
        foc->Shunt_Ic = il_Calculate_ShuntI_abc_WithOffset_P( adc_value[ Shunt_Index_W ], adc_offset[ Shunt_Index_W ], physic_max[ Shunt_Index_W ] );
        if( CG_ADC.Is_ShuntV_Exist ){
            foc->Shunt_Ib = il_Calculate_ShuntI_abc_WithOffset( adc_value[ Shunt_Index_V ], adc_offset[ Shunt_Index_V ], physic_max[ Shunt_Index_V ] );
        }else{
            foc->Shunt_Ib = -foc->Shunt_Ia - foc->Shunt_Ic;
        }


	    il_FOC_Shunt_I_Run ( foc );
        encoderGetPosition( encoder, encoder_pos_reg );

        output_Encoder_Pulse( bldc_ctrl, encoder_pos_reg );

        il_rtCtrl ( bldc_ctrl );

        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag ){

            if( bldc_ctrl->Control_Mode == CTRL_OPENLOOP ){
                if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
                    is_iq_ctrl = YES;
                    if( bldc_ctrl->Target_Dir == DIR_CW ){
                        target = -bldc_ctrl->Torque_Limit;
                    }else{
                        target = bldc_ctrl->Torque_Limit;
                    }
                }else{
                    is_iq_ctrl = NO;
                    target = -( bldc_ctrl->Current_Duty * CONST_SQRT3_OVER_3 ) / CONST_1;
                }
            }else{
                if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
                    is_iq_ctrl = YES;
                    target = -bldc_ctrl->PositionCtrl.SpdCtrl.Output;
                }else{
                    is_iq_ctrl = NO;
                    target = -( bldc_ctrl->Current_Duty * CONST_SQRT3_OVER_3 ) / CONST_1;
                    //
                    if( target > 0 ){
                        target += bldc_ctrl->Duty_Compensation;
                    }else if( target < 0 ){
                        target -= bldc_ctrl->Duty_Compensation;
                    }
                    //
                }
            }

            if( bldc_ctrl->Dir_Def == FORWARD_DIR_BOTTOM ){
                target *= -1;
            }

            swOutputDuty_ByADC( bldc_ctrl->Drive_Ptr, is_iq_ctrl, target );

        }

        if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
            spkOutputDuty_ByADC( bldc_ctrl->SPK_Ptr, bldc_ctrl );
        }

	}

    checkUARTSend485();

    //
#if(0)

	if( CG_BLDC_Drive.FOC_Start_Flag == YES ){
		swOutputDuty_ByADC();
	}else if( CG_SPK.Tq_Restraint_flag == YES ){
		spkOutputDuty_ByADC();
	}

	//DINT;
#endif

	// ==

	AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;		//Clear ADCINT1 flag reinitialize for next SOC

	//
	// Check if overflow has occurred
	//
	if(1 == AdcaRegs.ADCINTOVF.bit.ADCINT1){
		AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
		AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
	}

#if(TEST_CALCULATE_TIME_COST)
    CG_MD.ADC_TP_New = FREE_RUN_TIMER.TIM.all;
    CG_MD.ADC_Cost_Time = CG_MD.ADC_TP_Old - CG_MD.ADC_TP_New;
#endif

	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;   	// Acknowledge interrupt to PIE

}

/*===========================================================================================
    Function Name    : adc_isr2
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : ADC IRQ event2.
//==========================================================================================*/
__interrupt void adc_isr2(void)
{

}



/************************** <END OF FILE> *****************************************/


