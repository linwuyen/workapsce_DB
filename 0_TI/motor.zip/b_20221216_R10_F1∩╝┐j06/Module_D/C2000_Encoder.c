/*
 * C2000_Encoder.c
 *
 *  Created on: 2015/8/17
 *      Author: chaim.chen
 */
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_Encoder CG_Encoder;
//extern volatile Struct_BLDC_CTRL 			CG_BLDC_CTRL;
//extern volatile Struct_GPIO 				CG_GPIO;
//extern volatile Struct_Speed 				CG_Speed;
//extern volatile Struct_Parameter			CG_Parameter;
extern volatile Struct_ADC 					CG_ADC;
//extern volatile Struct_Pretect 				CG_Protect;
//extern volatile Struct_BLDC_Drive 			CG_BLDC_Drive;
extern volatile Struct_HWEEP				CG_HWEEP;
extern volatile Struct_MD 					CG_MD;

extern void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void );

//#pragma CODE_SECTION( motor_0_encoder_isr, "ramfuncs");
#pragma CODE_SECTION( motor_0_encoder_isr, ".TI.ramfunc" );
//#pragma CODE_SECTION( motor_1_encoder_isr, ".TI.ramfunc" );

/*===========================================================================================
    Function Name    : variableInitial_BasicEncoder
    Input            : encoder
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable initial
//==========================================================================================*/
void variableInitial_BasicEncoder ( Struct_Basic_Encoder* encoder )
{
    encoder->UpdateRate_Pa = ENCODER_UPDATE_RATE_10HZ;
    encoder->UpdateRate_Factor_1 = Const_Encoder_UpdateRate_Factor[ encoder->UpdateRate_Pa ];
    encoder->UpdateRate_Factor_2 = 1000 / encoder->UpdateRate_Factor_1;

    // Tamagawa Encoder variables
    encoder->State = ENCODER_STATE_NOT_READY;
    encoder->Hall_Checked = NO;
    encoder->Hall_Check_IsFirstTime = YES;
    encoder->Hall_Check_First_Time = 0;
    encoder->Hall_Check_Current_Time = 0;
    encoder->Hall_Check_Time_Pass = 0;
    encoder->Hall_Check_Settling_Time = 0;
    encoder->Hall_Check_Checking_Time = 0;

	encoder->Index = 0;
	encoder->Pos = 0;
	encoder->Pos_Reg = 0;
	encoder->Position = 0;

	encoder->Rapid_RPM_Abs = 0;
	encoder->Rapid_RPM = 0;
	//encoder->Rapid_ERPM_Abs = 0;
	//encoder->Rapid_ERPM = 0;

	encoder->Smooth_RPM_Abs = 0;
	encoder->Smooth_RPM = 0;
	//encoder->Smooth_ERPM_Abs = 0;
	//encoder->Smooth_ERPM = 0;

	encoder->Direction = 0;

	//
	encoder->FullPos = 0;
	encoder->MaxPos = 0;
	encoder->PosErrorMax_P = 0;
	encoder->PosErrorMax_N = 0;

    // The following variables are used for motor 0 BLDC

	encoder->MaxPos_ForFOC = 0;
	encoder->Phase_Length = 0;
	encoder->PosError_Const = 0;
	encoder->Pos_Est_Offset = 0;
	encoder->Offset = 0;

	encoder->Pos_EstByHall = 0;
	encoder->Pos_Est_Const = 0;

	encoder->InputState = 0;
	encoder->Hall_State = 0;

	encoder->Hall_Cnt = 0;

	encoder->Pos_PWM = 0;
	encoder->Pos_PWM_T0 = 0;

	//
	//encoder->GotNewSpeed = 0;
	encoder->Z_Got_Flag = 0;
	encoder->LastPos_B4Z = 0;
	encoder->LastIndex_B4Z = 0;

	encoder->Offset_Index = 0;
	encoder->Offset_Pos = 0;

	encoder->Dummy_Index = 0;
	encoder->Dummy_Pos = 0;

	encoder->First_Z_Event_Flag = 0;
	encoder->Z_Processed_Flag = NO;

	encoder->PosLat_Update_Flag = NO;
	encoder->Delta_PosLat = 0;
	encoder->Delta_PosLat_Sum = 0;
	encoder->Delta_PosLat_Cnt = 0;

	encoder->Delta_PosLat_Dummy = 0;
	encoder->PosLat_Old = 0;

	//

	encoder->Pos_Stamp_Old = 0;
	encoder->Pos_Stamp_New = 0;
	encoder->Pos_Delta = 0;

	encoder->Inst_Speed_Old = 0;
	encoder->Inst_Speed_New = 0;

	encoder->Inst_Acc = 0;
	encoder->Inst_Speed_Acc_Const = 1;

	//

	encoder->Delta_Pos_Integration = 0;

	//
	encoder->Stall_Timer = 0;
}


/*===========================================================================================
    Function Name    : variableInitial_Encoder
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Encoder initial
//==========================================================================================*/
void variableInitial_Encoder ( void )
{
	//int8_t i;
	CG_Encoder.Power_On_Flag = NO;

	variableInitial_BasicEncoder ( ( Struct_Basic_Encoder*) &CG_Encoder.Motor_0 );
	//variableInitial_BasicEncoder ( ( Struct_Basic_Encoder*) &CG_Encoder.Motor_1 );

}

/*===========================================================================================
    Function Name    : encoder_Reset_Stall_Timer
    Input            : encoder
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoder_Reset_Stall_Timer( Struct_Basic_Encoder* encoder )
{
    encoder->Stall_Timer = 0;
}

/*===========================================================================================
    Function Name    : targetPosInit_Encoder
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Encoder.TargetPos initial
//==========================================================================================*/
void targetPosInit_Encoder ( void )
{
	//CG_Encoder.TargetPos = EQep1Regs.QPOSCNT;
}

/*===========================================================================================
    Function Name    : il_SetUp_EncoderPin_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup Encoder pin
//==========================================================================================*/
__inline void il_SetUp_EncoderPin_M0( void )
{

    // Motor 0 Encoder, ABZ
    GPIO_SetupPinMux( 56, GPIO_MUX_CPU1, 11 );
    GPIO_SetupPinMux( 57, GPIO_MUX_CPU1, 11 );
    if( CG_Encoder.Motor_0.Type != ENCODER_TYPE_HALL_ENCODER_AB ){
        GPIO_SetupPinMux( 59, GPIO_MUX_CPU1, 11 );
    }

    EALLOW;
    // M0
    GpioCtrlRegs.GPBPUD.bit.GPIO56 = 0;     // Enable pull up
    GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = 0;   // Synch to SYSCLKOUT

    GpioCtrlRegs.GPBPUD.bit.GPIO57 = 0;     // Enable pull up
    GpioCtrlRegs.GPBQSEL2.bit.GPIO57 = 0;   // Synch to SYSCLKOUT

    GpioCtrlRegs.GPBPUD.bit.GPIO59 = 0;     // Enable pull up
    GpioCtrlRegs.GPBQSEL2.bit.GPIO59 = 0;   // Synch to SYSCLKOUT

    // Digital filter
#if(1)
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD0 : 0 ~ 7
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD1 : 8 ~ 15
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD2 :16 ~ 23
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD3 :24 ~ 31

    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD0 :32 ~ 39
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 :40 ~ 47
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD2 :48 ~ 55
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 :56 ~ 63

    // Motor 0 Encoder
    GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO57 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPBQSEL2.bit.GPIO59 = ENCODER_QSEL_CONST & 0x03;

    // Hall
    // GpioCtrlRegs.GPHCTRL.bit.QUALPRD3 :Res
    // GpioCtrlRegs.GPHCTRL.bit.QUALPRD2 :GPIO240 to GPIO247
    // GpioCtrlRegs.GPHCTRL.bit.QUALPRD1 :GPIO232 to GPIO239
    // GpioCtrlRegs.GPHCTRL.bit.QUALPRD0 :GPIO224 to GPIO231

    GpioCtrlRegs.GPHCTRL.bit.QUALPRD1 = HALL_FILTER_CONST;
    GpioCtrlRegs.GPHQSEL1.bit.GPIO233 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPHQSEL1.bit.GPIO234 = ENCODER_QSEL_CONST & 0x03;

    // Encoder with PWM in
    if( CG_Encoder.Motor_0.Type == ENCODER_TYPE_ALLEGRO ){
        GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
    }else{
        GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 = HALL_FILTER_CONST;
    }
    // M0
    GpioCtrlRegs.GPBPUD.bit.GPIO39 = 0;     // Enable pull up
    GpioCtrlRegs.GPBQSEL1.bit.GPIO39 = ENCODER_QSEL_CONST & 0x03;

#endif

    EDIS;

}

/*===========================================================================================
    Function Name    : il_SetUp_EncoderPin_M1
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup Encoder pin
//==========================================================================================*/
/*
__inline void il_SetUp_EncoderPin_M1( void )
{
    // Motor 1 Encoder, ABZ
    GPIO_SetupPinMux( 14, GPIO_MUX_CPU1, 10 );
    GPIO_SetupPinMux( 15, GPIO_MUX_CPU1, 10 );
    GPIO_SetupPinMux( 26, GPIO_MUX_CPU1, 2 );


    EALLOW;
    // M1
    GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;     // Enable pull up
    GpioCtrlRegs.GPAQSEL1.bit.GPIO14= 0;    // Synch to SYSCLKOUT

    GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;     // Enable pull up
    GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 0;   // Synch to SYSCLKOUT

    GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0;     // Enable pull up
    GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = 0;   // Synch to SYSCLKOUT

    // Digital filter
#if(1)
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD0 : 0 ~ 7
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD1 : 8 ~ 15
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD2 :16 ~ 23
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD3 :24 ~ 31

    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD0 :32 ~ 39
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 :40 ~ 47
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD2 :48 ~ 55
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 :56 ~ 63

    // Motor 1 Encoder

    GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
    GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;

    GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = ENCODER_QSEL_CONST & 0x03;
    GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = ENCODER_QSEL_CONST & 0x03;

    // Encoder with PWM in
    GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;

    // M1
    GpioCtrlRegs.GPBPUD.bit.GPIO40 = 0;     // Enable pull up
    GpioCtrlRegs.GPBQSEL1.bit.GPIO40 = ENCODER_QSEL_CONST & 0x03;

#endif

    EDIS;

}
*/

/*===========================================================================================
    Function Name    : il_SetUp_EncoderPin
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup Encoder pin
//==========================================================================================*/
#if(0)
__inline void il_SetUp_EncoderPin( void )
{

	// Motor 0 Encoder, ABZ
	GPIO_SetupPinMux( 56, GPIO_MUX_CPU1, 11 );
	GPIO_SetupPinMux( 57, GPIO_MUX_CPU1, 11 );
	GPIO_SetupPinMux( 59, GPIO_MUX_CPU1, 11 );

	// Motor 1 Encoder, ABZ
	/*
	GPIO_SetupPinMux( 14, GPIO_MUX_CPU1, 10 );
	GPIO_SetupPinMux( 15, GPIO_MUX_CPU1, 10 );
	GPIO_SetupPinMux( 26, GPIO_MUX_CPU1, 2 );
	*/

	EALLOW;
	// M0
	GpioCtrlRegs.GPBPUD.bit.GPIO56 = 0;   	// Enable pull up
	GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = 0;  	// Synch to SYSCLKOUT

	GpioCtrlRegs.GPBPUD.bit.GPIO57 = 0;   	// Enable pull up
	GpioCtrlRegs.GPBQSEL2.bit.GPIO57 = 0;  	// Synch to SYSCLKOUT

	GpioCtrlRegs.GPBPUD.bit.GPIO59 = 0;   	// Enable pull up
	GpioCtrlRegs.GPBQSEL2.bit.GPIO59 = 0;  	// Synch to SYSCLKOUT

	// M1
	/*
    GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;   	// Enable pull up
    GpioCtrlRegs.GPAQSEL1.bit.GPIO14= 0;  	// Synch to SYSCLKOUT

	GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;   	// Enable pull up
	GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 0;  	// Synch to SYSCLKOUT

	GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0;     // Enable pull up
	GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = 0;   // Synch to SYSCLKOUT
	*/

	// Digital filter
#if(1)
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD0 : 0 ~ 7
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD1 : 8 ~ 15
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD2 :16 ~ 23
    // GpioCtrlRegs.GPACTRL.bit.QUALPRD3 :24 ~ 31

    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD0 :32 ~ 39
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD1 :40 ~ 47
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD2 :48 ~ 55
    // GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 :56 ~ 63

	// Motor 0 Encoder
	GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
	GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = ENCODER_QSEL_CONST & 0x03;
	GpioCtrlRegs.GPBQSEL2.bit.GPIO57 = ENCODER_QSEL_CONST & 0x03;
	GpioCtrlRegs.GPBQSEL2.bit.GPIO59 = ENCODER_QSEL_CONST & 0x03;

	// Motor 1 Encoder
	/*
	GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;
	GpioCtrlRegs.GPBCTRL.bit.QUALPRD3 = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFF;

	GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = ENCODER_QSEL_CONST & 0x03;
	GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = ENCODER_QSEL_CONST & 0x03;
	GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = ENCODER_QSEL_CONST & 0x03;
	*/

#endif

	EDIS;

}
#endif

/*===========================================================================================
    Function Name    : il_SetUp_Motor_0_Encoder_Reg
    Input            : 1.type
					   2.resolution: Encoder pulse number per cycle
					   3.pole_factor : motor pole factor = pole number / 2
					   4.direction_def : 0 = Top view, 1 = bottom view
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up Encoder registers.
//==========================================================================================*/
__inline void il_SetUp_Motor_0_Encoder_Reg( uint8_t type, int32_t resolution, int32_t pole_factor, int32_t direction_def )
{
#if(1)
	int32_t max_pos;
	struct EQEP_REGS *enconder_reg;
	Struct_Basic_Encoder* encoder;

	enconder_reg = ( struct EQEP_REGS * )&EQep1Regs;
	encoder = ( Struct_Basic_Encoder*) &CG_Encoder.Motor_0;

	// Interrupts that are used in this example are re-mapped to
	// ISR functions found within this file.
	EALLOW;  // This is needed to write to EALLOW protected registers
	PieVectTable.EQEP1_INT = &motor_0_encoder_isr;

	if( resolution < 1 ){
		resolution = 1;
	}

	if( pole_factor < 1 ){
		pole_factor = 1;
	}

	//CG_Encoder.MaxPos = resolution * 4;


	if( type == ENCODER_TYPE_SIRUBA ){

        max_pos = resolution * 2;	//	GaoLin BLDC Motor encoder, A and B signals are standard, but Z signal is half high, and half low for one cycle.
        encoder->MaxPos = max_pos;
        encoder->FullPos = encoder->MaxPos * 2;
        encoder->PosErrorMax_P = max_pos / 2 - 1;
        encoder->PosErrorMax_N = -1 * max_pos / 2;

        encoder->Inst_Speed_Acc_Const = CTRL_FREQ_HZ * 60 * pole_factor / encoder->FullPos;

        //encoder->PosError_Const = 60 * ADC_UPDATE_DUTY_FREQUENCE;

        encoder->MaxPos_ForFOC = ( resolution * 4 / pole_factor );	// GaoLin Motor

        //encoder->Phase_Length = max_pos * 2 / ( 6 * pole_factor );
        encoder->Phase_Length = max_pos / ( 3 * pole_factor );
        encoder->Pos_Est_Const = encoder->Phase_Length;

        //encoder->recognize_const_value = CG_Encoder.swLength / 2;

        enconder_reg->QUPRD = SYSTEM_FREQUENCE / 1000;         		// Unit Timer for 1000Hz

        enconder_reg->QDECCTL.bit.QSRC = 00;      	// QEP quadrature count mode

        if( direction_def == FORWARD_DIR_TOP ){
            enconder_reg->QDECCTL.bit.SWAP = 1;			// Quadrature-clock inputs are swapped
        }else{
            enconder_reg->QDECCTL.bit.SWAP = 0;			// Quadrature-clock inputs are not swapped
        }

	}else{

	    max_pos = resolution * 4;   // Standard Encoder.
        encoder->MaxPos = max_pos;
        encoder->FullPos = encoder->MaxPos;
        encoder->PosErrorMax_P = max_pos / 2 - 1;
        encoder->PosErrorMax_N = -1 * max_pos / 2;

        encoder->Inst_Speed_Acc_Const = CTRL_FREQ_HZ * 60 * pole_factor / encoder->FullPos;

        //encoder->PosError_Const = 60 * ADC_UPDATE_DUTY_FREQUENCE;

        encoder->MaxPos_ForFOC = ( resolution * 4 / pole_factor );    // GaoLin Motor

        //encoder->Phase_Length = max_pos * 2 / ( 6 * pole_factor );
        encoder->Phase_Length = max_pos / ( 6 * pole_factor );
        encoder->Pos_Est_Const = encoder->Phase_Length / 2;

        //CG_Encoder.recognize_const_value = CG_Encoder.swLength / 2;

        enconder_reg->QUPRD = SYSTEM_FREQUENCE / 1000;              // Unit Timer for 1000Hz

        enconder_reg->QDECCTL.bit.QSRC = 00;        // QEP quadrature count mode

        if( direction_def == FORWARD_DIR_TOP ){
            enconder_reg->QDECCTL.bit.SWAP = 1;         // Quadrature-clock inputs are not swapped
        }else{
            enconder_reg->QDECCTL.bit.SWAP = 0;         // Quadrature-clock inputs are swapped
        }
	}
#if(TEST_ENCODER_CN_ORDER_IS_EV)
	enconder_reg->QDECCTL.bit.QIP = 1;			// Negates QEPI input
#else
	enconder_reg->QDECCTL.bit.QIP = 0;
	enconder_reg->QDECCTL.bit.QAP = 1;
	enconder_reg->QDECCTL.bit.QBP = 1;
#endif

	enconder_reg->QEPCTL.bit.FREE_SOFT = 2;
	enconder_reg->QEPCTL.bit.PCRM = 1;			// Position counter reset on the maximum position
	enconder_reg->QEPCTL.bit.IEL = 1;			// Latches position counter on rising edge of the index signal
	enconder_reg->QEPCTL.bit.UTE = 1;         	// Unit Timeout Enable
	enconder_reg->QEPCTL.bit.QCLM = 1;        	// Latch on unit time out

	enconder_reg->QPOSMAX = max_pos - 1;
	enconder_reg->QEPCTL.bit.QPEN = 1;        	// QEP enable

	enconder_reg->QCAPCTL.bit.UPPS = 0;       	// 1/1 for unit position
	enconder_reg->QCAPCTL.bit.CCPS = 2;       	// 1/4 for CAP clock
	enconder_reg->QCAPCTL.bit.CEN = 1;        	// QEP Capture Enable

	enconder_reg->QEINT.bit.UTO = 1;			// Unit time out interrupt enable
	if( encoder->Type != ENCODER_TYPE_HALL_ENCODER_AB ){
	    enconder_reg->QEINT.bit.IEL = 1;			// Index event latch interrupt enable
	}

	enconder_reg->QCLR.bit.UTO = 1;
	enconder_reg->QCLR.bit.IEL = 1;
	enconder_reg->QCLR.bit.INT = 1;

	encoder->Threshold_HallCnt_P = pole_factor * 6 - 3;
    encoder->Threshold_HallCnt_N = -encoder->Threshold_HallCnt_P;

    encoder->ThresholdPos_P = encoder->FullPos * encoder->Threshold_HallCnt_P / ( pole_factor * 6 );
    encoder->ThresholdPos_N = -encoder->ThresholdPos_P;

	PieCtrlRegs.PIEIER5.bit.INTx1 = 1;		// Enable INT 5.1 in the PIE
	IER |= M_INT5; 							// Enable CPU Interrupt 5

	EDIS;    // This is needed to disable write to EALLOW protected registers
#endif

}

/*===========================================================================================
    Function Name    : il_SetUp_Motor_1_Encoder_Reg
    Input            : 1.type
					   2.resolution: Encoder pulse number per cycle
					   3.pole_factor : motor pole factor = pole number / 2
					   4.direction_def : 0 = Top view, 1 = bottom view
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up Encoder registers.
//==========================================================================================*/
/*
__inline void il_SetUp_Motor_1_Encoder_Reg( uint8_t type, int32_t resolution, int32_t pole_factor, int32_t direction_def )
{

	int32_t max_pos;
	struct EQEP_REGS *enconder_reg;
	Struct_Basic_Encoder* encoder;

	enconder_reg = ( struct EQEP_REGS * )&EQep2Regs;
	encoder = ( Struct_Basic_Encoder*) &CG_Encoder.Motor_1;

	// Interrupts that are used in this example are re-mapped to
	// ISR functions found within this file.
	EALLOW;  // This is needed to write to EALLOW protected registers
	PieVectTable.EQEP2_INT = &motor_1_encoder_isr;

	if( resolution < 1 ){
        resolution = 1;
    }

    if( pole_factor < 1 ){
        pole_factor = 1;
    }

    //CG_Encoder.MaxPos = resolution * 4;

    if( type == ENCODER_TYPE_SIRUBA ){

        max_pos = resolution * 2;   //  GaoLin BLDC Motor encoder, A and B signals are standard, but Z signal is half high, and half low for one cycle.
        encoder->MaxPos = max_pos;
        encoder->FullPos = encoder->MaxPos * 2;
        encoder->PosErrorMax_P = max_pos / 2 - 1;
        encoder->PosErrorMax_N = -1 * max_pos / 2;

        encoder->Inst_Speed_Acc_Const = CTRL_FREQ_HZ * 60 * pole_factor / encoder->FullPos;

        //encoder->PosError_Const = 60 * ADC_UPDATE_DUTY_FREQUENCE;

        encoder->MaxPos_ForFOC = ( resolution * 4 / pole_factor );  // GaoLin Motor

        //encoder->Phase_Length = max_pos * 2 / ( 6 * pole_factor );
        encoder->Phase_Length = max_pos / ( 3 * pole_factor );
        encoder->Pos_Est_Const = encoder->Phase_Length;

        //encoder->recognize_const_value = CG_Encoder.swLength / 2;

        enconder_reg->QUPRD = SYSTEM_FREQUENCE / 1000;              // Unit Timer for 1000Hz

        enconder_reg->QDECCTL.bit.QSRC = 00;        // QEP quadrature count mode

        if( direction_def == FORWARD_DIR_TOP ){
            enconder_reg->QDECCTL.bit.SWAP = 1;         // Quadrature-clock inputs are swapped
        }else{
            enconder_reg->QDECCTL.bit.SWAP = 0;         // Quadrature-clock inputs are not swapped
        }

    }else{

        max_pos = resolution * 4;   // Standard Encoder.
        encoder->MaxPos = max_pos;
        encoder->FullPos = encoder->MaxPos;
        encoder->PosErrorMax_P = max_pos / 2 - 1;
        encoder->PosErrorMax_N = -1 * max_pos / 2;

        encoder->Inst_Speed_Acc_Const = CTRL_FREQ_HZ * 60 * pole_factor / encoder->FullPos;

        //encoder->PosError_Const = 60 * ADC_UPDATE_DUTY_FREQUENCE;

        encoder->MaxPos_ForFOC = ( resolution * 4 / pole_factor );    // GaoLin Motor

        //encoder->Phase_Length = max_pos * 2 / ( 6 * pole_factor );
        encoder->Phase_Length = max_pos / ( 6 * pole_factor );
        encoder->Pos_Est_Const = encoder->Phase_Length / 2;

        //CG_Encoder.recognize_const_value = CG_Encoder.swLength / 2;

        enconder_reg->QUPRD = SYSTEM_FREQUENCE / 1000;              // Unit Timer for 1000Hz

        enconder_reg->QDECCTL.bit.QSRC = 00;        // QEP quadrature count mode

        if( direction_def == FORWARD_DIR_TOP ){
            enconder_reg->QDECCTL.bit.SWAP = 1;         // Quadrature-clock inputs are not swapped
        }else{
            enconder_reg->QDECCTL.bit.SWAP = 0;         // Quadrature-clock inputs are swapped
        }
    }

#if(TEST_ENCODER_CN_ORDER_IS_EV)
    enconder_reg->QDECCTL.bit.QIP = 1;          // Negates QEPI input
#else
    enconder_reg->QDECCTL.bit.QIP = 0;
    enconder_reg->QDECCTL.bit.QAP = 1;
    enconder_reg->QDECCTL.bit.QBP = 1;
#endif

    enconder_reg->QEPCTL.bit.FREE_SOFT = 2;
    enconder_reg->QEPCTL.bit.PCRM = 1;          // Position counter reset on the maximum position
    enconder_reg->QEPCTL.bit.IEL = 1;           // Latches position counter on rising edge of the index signal
    enconder_reg->QEPCTL.bit.UTE = 1;           // Unit Timeout Enable
    enconder_reg->QEPCTL.bit.QCLM = 1;          // Latch on unit time out

    enconder_reg->QPOSMAX = max_pos - 1;
    enconder_reg->QEPCTL.bit.QPEN = 1;          // QEP enable

    enconder_reg->QCAPCTL.bit.UPPS = 0;         // 1/1 for unit position
    enconder_reg->QCAPCTL.bit.CCPS = 2;         // 1/4 for CAP clock
    enconder_reg->QCAPCTL.bit.CEN = 1;          // QEP Capture Enable

    enconder_reg->QEINT.bit.UTO = 1;            // Unit time out interrupt enable
    enconder_reg->QEINT.bit.IEL = 1;            // Index event latch interrupt enable

    enconder_reg->QCLR.bit.UTO = 1;
    enconder_reg->QCLR.bit.IEL = 1;
    enconder_reg->QCLR.bit.INT = 1;

    encoder->ThresholdPos_P = encoder->FullPos * ( pole_factor * 6 - 1 ) / ( pole_factor * 6 );
    encoder->ThresholdPos_N = -encoder->ThresholdPos_P;

	PieCtrlRegs.PIEIER5.bit.INTx2 = 1;		// Enable INT 5.1 in the PIE
	IER |= M_INT5; 							// Enable CPU Interrupt 5

	EDIS;    // This is needed to disable write to EALLOW protected registers

}
*/

/*===========================================================================================
    Function Name    : setupInitial_Encoder_M0
    Input            : 1.encoder_type,
                       2.resolution,
                       3.pole_factor,
                       4.direction_def,
                       5.hall_sequence,
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Encoder initialzation function.
                       For more info please check for the user manual.
//==========================================================================================*/
void setupInitial_Encoder_M0(   Struct_Basic_Encoder*encoder,
                                uint8_t encoder_type,
                                int32_t resolution,
                                int32_t pole_factor,
                                int32_t direction_def,
                                int32_t hall_sequence )
{

    CG_Encoder.Power_On_Flag = NO;

    variableInitial_BasicEncoder ( encoder );

    switch( encoder_type ){
    case PA_SENSOR_ENCODER_PLUS_HALL:
        encoder->Type = ENCODER_TYPE_HALL_ENCODER_STD;
        break;
    case PA_SENSOR_ENCODER_ALLEGRO:
        encoder->Type = ENCODER_TYPE_ALLEGRO;
        break;
    case PA_SENSOR_HALL_ENCODER_AB:
        encoder->Type = ENCODER_TYPE_HALL_ENCODER_AB;
        break;
    case PA_SENSOR_ENCODER_SIRUBA:
        encoder->Type = ENCODER_TYPE_SIRUBA;
        break;
    case PA_SENSOR_DEFAULT:
    case PA_SENSOR_HALL:
    case PA_SENSOR_ENCODER_TAMAGAWA:
    default:
        encoder->Type = ENCODER_TYPE_TAMAGAWA;
        break;
    }

    il_SetUp_EncoderPin_M0();

    encoder->Dir_Def = direction_def;

    encoder->Hall_Sequence = hall_sequence;

    if( encoder->Hall_Sequence == HALL_SEQUENCE_A ){ // CW: 3->2->6->4->5->1
        encoder->ThresholdPos_P_HallState = 6;
        encoder->ThresholdPos_N_HallState = 2;
    }else{
        encoder->ThresholdPos_P_HallState = 5; // CW: 1->5->4->6->2->3
        encoder->ThresholdPos_N_HallState = 1;
    }

    il_SetUp_Motor_0_Encoder_Reg( encoder->Type, resolution, pole_factor, direction_def );

}

/*===========================================================================================
    Function Name    : setupInitial_Encoder_M1
    Input            : 1.encoder_type,
                       2.resolution,
                       3.pole_factor,
                       4.direction_def,
                       5.hall_sequence,
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Encoder initialzation function.
                       For more info please check for the user manual.
//==========================================================================================*/
/*
void setupInitial_Encoder_M1(   Struct_Basic_Encoder*encoder,
                                uint8_t encoder_type,
                                int32_t resolution,
                                int32_t pole_factor,
                                int32_t direction_def,
                                int32_t hall_sequence )
{

    CG_Encoder.Power_On_Flag = NO;

    variableInitial_BasicEncoder ( encoder );

    il_SetUp_EncoderPin_M1();

    switch( encoder_type ){
    case PA_SENSOR_ENCODER_PLUS_HALL:
        encoder->Type = ENCODER_TYPE_HALL_ENCODER_STD;
        break;
    case PA_SENSOR_ENCODER_ALLEGRO:
        encoder->Type = ENCODER_TYPE_ALLEGRO;
        break;
    case PA_SENSOR_HALL_ENCODER_AB:
        encoder->Type = ENCODER_TYPE_HALL_ENCODER_AB;
        break;
    case PA_SENSOR_ENCODER_SIRUBA:
        encoder->Type = ENCODER_TYPE_SIRUBA;
        break;
    case PA_SENSOR_DEFAULT:
    case PA_SENSOR_HALL:
    case PA_SENSOR_ENCODER_TAMAGAWA:
    default:
        encoder->Type = ENCODER_TYPE_TAMAGAWA;
        break;
    }

    encoder->Dir_Def = direction_def;

    encoder->Hall_Sequence = hall_sequence;

    if( encoder->Hall_Sequence == HALL_SEQUENCE_A ){ // CW: 3->2->6->4->5->1
        encoder->ThresholdPos_P_HallState = 6;
        encoder->ThresholdPos_N_HallState = 2;
    }else{
        encoder->ThresholdPos_P_HallState = 5; // CW: 1->5->4->6->2->3
        encoder->ThresholdPos_N_HallState = 1;
    }

    il_SetUp_Motor_1_Encoder_Reg( encoder->Type, resolution, pole_factor, direction_def );

}
*/

/*===========================================================================================
    Function Name    : setupInitial_Encode
    Input            : 1.encoder_type_m0,
                       2.encoder_type_m1,
                       3.resolution_m0,
                       4.resolution_m1,
                       5.pole_factor_m0,
                       6.pole_factor_m1,
                       7.direction_def_m0,
                       8.direction_def_m1
                       9.hall_sequence_m0,
                       10.hall_sequence_m1
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Encoder initialzation function.
					   For more info please check for the user manual.
//==========================================================================================*/
/*
void setupInitial_Encoder( 	uint8_t encoder_type_m0,
                           	uint8_t encoder_type_m1,
                            int32_t resolution_m0,
							int32_t resolution_m1,
							int32_t pole_factor_m0,
							int32_t pole_factor_m1,
							int32_t direction_def_m0,
							int32_t direction_def_m1,
							int32_t hall_sequence_m0,
							int32_t hall_sequence_m1 )
{
    variableInitial_Encoder();

    il_SetUp_EncoderPin();

    switch( encoder_type_m0 ){
    case PA_SENSOR_ENCODER_PLUS_HALL:
        CG_Encoder.Motor_0.Type = ENCODER_TYPE_HALL_ENCODER_STD;
        break;
    case PA_SENSOR_ENCODER_ALLEGRO:
        CG_Encoder.Motor_0.Type = ENCODER_TYPE_ALLEGRO;
        break;
    case PA_SENSOR_HALL_ENCODER_AB:
        CG_Encoder.Motor_0.Type = ENCODER_TYPE_HALL_ENCODER_AB;
        break;
    case PA_SENSOR_ENCODER_SIRUBA:
        CG_Encoder.Motor_0.Type = ENCODER_TYPE_SIRUBA;
        break;
    case PA_SENSOR_DEFAULT:
    case PA_SENSOR_HALL:
    case PA_SENSOR_ENCODER_TAMAGAWA:
    default:
        CG_Encoder.Motor_0.Type = ENCODER_TYPE_TAMAGAWA;
        break;
    }

    switch( encoder_type_m1 ){
    case PA_SENSOR_ENCODER_PLUS_HALL:
        CG_Encoder.Motor_1.Type = ENCODER_TYPE_HALL_ENCODER_STD;
        break;
    case PA_SENSOR_ENCODER_ALLEGRO:
        CG_Encoder.Motor_1.Type = ENCODER_TYPE_ALLEGRO;
        break;
    case PA_SENSOR_HALL_ENCODER_AB:
        CG_Encoder.Motor_1.Type = ENCODER_TYPE_HALL_ENCODER_AB;
        break;
    case PA_SENSOR_ENCODER_SIRUBA:
        CG_Encoder.Motor_1.Type = ENCODER_TYPE_SIRUBA;
        break;
    case PA_SENSOR_DEFAULT:
    case PA_SENSOR_HALL:
    case PA_SENSOR_ENCODER_TAMAGAWA:
    default:
        CG_Encoder.Motor_1.Type = ENCODER_TYPE_TAMAGAWA;
        break;
    }

    CG_Encoder.Motor_0.Dir_Def = direction_def_m0;
    CG_Encoder.Motor_1.Dir_Def = direction_def_m1;

    CG_Encoder.Motor_0.Hall_Sequence = hall_sequence_m0;
    CG_Encoder.Motor_1.Hall_Sequence = hall_sequence_m1;

    if( CG_Encoder.Motor_0.Hall_Sequence == HALL_SEQUENCE_A ){ // CW: 3->2->6->4->5->1
        CG_Encoder.Motor_0.ThresholdPos_P_HallState = 6;
        CG_Encoder.Motor_0.ThresholdPos_N_HallState = 2;
    }else{
        CG_Encoder.Motor_0.ThresholdPos_P_HallState = 5; // CW: 1->5->4->6->2->3
        CG_Encoder.Motor_0.ThresholdPos_N_HallState = 1;
    }

    if( CG_Encoder.Motor_1.Hall_Sequence == HALL_SEQUENCE_A ){ // CW: 3->2->6->4->5->1
        CG_Encoder.Motor_1.ThresholdPos_P_HallState = 6;
        CG_Encoder.Motor_1.ThresholdPos_N_HallState = 2;
    }else{
        CG_Encoder.Motor_1.ThresholdPos_P_HallState = 5; // CW: 1->5->4->6->2->3
        CG_Encoder.Motor_1.ThresholdPos_N_HallState = 1;
    }

    il_SetUp_Motor_0_Encoder_Reg( CG_Encoder.Motor_0.Type, resolution_m0, pole_factor_m0, direction_def_m0 );
    il_SetUp_Motor_1_Encoder_Reg( CG_Encoder.Motor_1.Type, resolution_m1, pole_factor_m1, direction_def_m1 );


}
*/

/*===========================================================================================
    Function Name    : power5V_Switch
    Input            : State
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void power5V_Switch( int8_t state )
{
#if(0)
	EALLOW;
	if( state ){
		POWER_5V_ON;
	}else{
		POWER_5V_OFF;
	}
	EDIS;
#endif
}

/*===========================================================================================
    Function Name    : manageEncoderPower
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : manage 5v power
//==========================================================================================*/
void manageEncoderPower( void )
{
#if(1)
#define ENCODER_OFF_TIME    20  // 20 = 200ms

	if( CG_MD.Pwr_On_Cnt >= ENCODER_OFF_TIME ){
		CG_Encoder.Power_On_Flag = YES;
		//IO_EN_5V_ON;
		otherGPIO_SetOutput( OTHER_OUTPUT_EN_5V, HIGH );
	}else{
	    //IO_EN_5V_OFF;
	    otherGPIO_SetOutput( OTHER_OUTPUT_EN_5V, LOW );
	}

#else
	CG_Encoder.Power_On_Flag = YES;
#endif

}

/*===========================================================================================
    Function Name    : captureEncoderInfo
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void captureEncoderInfo( void )
{

	//CG_Encoder.cap_speed = CG_Encoder.current_10mrpm_abs;
	//CG_Encoder.cap_index = LPC_QEI->INXCNT;
	//CG_Encoder.cap_pos	 = LPC_QEI->POS;

}

/*===========================================================================================
    Function Name    : encoder_CalculateSpeed
    Input            : 1.encoder
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoder_CalculateSpeed( Struct_Basic_Encoder* encoder )
{

	//Struct_Basic_Encoder* encoder;
	//encoder = ( Struct_Basic_Encoder*) &CG_Encoder.Motor_0;

	if( encoder->PosLat_Update_Flag == YES ){
		encoder->PosLat_Update_Flag = NO;

		encoder->Delta_PosLat_Sum += encoder->Delta_PosLat;
		encoder->Delta_PosLat_Cnt++;

		//if( encoder->Delta_PosLat_Cnt >= ENCODER_SMOOTH_FACTOR1 ){
		if( encoder->Delta_PosLat_Cnt >= encoder->UpdateRate_Factor_1 ){

			//encoder->Smooth_RPM = ( encoder->Delta_PosLat_Sum * 60  / ( encoder->FullPos / ENCODER_SMOOTH_FACTOR2 ) );
		    encoder->Smooth_RPM = ( encoder->Delta_PosLat_Sum * 60 * encoder->UpdateRate_Factor_2 / encoder->FullPos );

			encoder->Delta_PosLat_Cnt = 0;
			encoder->Delta_PosLat_Sum = 0;

			encoder->Smooth_RPM_Abs = encoder->Smooth_RPM;
			if( encoder->Smooth_RPM_Abs < 0 ){
				encoder->Smooth_RPM_Abs *= -1;
				encoder->Direction = DIR_CCW;
			}else if( encoder->Smooth_RPM_Abs > 0 ){
			    encoder->Direction = DIR_CW;
			}

			if( encoder->Smooth_RPM_Abs == 0 ){
			    if( encoder->Stall_Timer < 1000000 ){
			        encoder->Stall_Timer++;
			    }
			}else{
			    encoder->Stall_Timer = 0;
			}

		}
	}

}

/*===========================================================================================
    Function Name    : encoderGetGuessPos
    Input            : 1.enconder_reg
                        2.encoder
                        3.io_bitf_encoder
                        4.io_bitf_hall
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoderGetGuessPos( struct EQEP_REGS *enconder_reg, Struct_Basic_Encoder* encoder, uint8_t io_bitf_encoder, uint8_t io_bitf_hall )
{
#if(1)
	//uint32_t dummy_pos;

	if( CG_Encoder.Power_On_Flag == YES ){

		if( encoder->Hall_Checked == NO ){

		    switch( encoder->Type ){
		    case ENCODER_TYPE_TAMAGAWA:
		        encoder->InputState = io_bitf_encoder;
		        encoder->Hall_State = Const_Encoder_Hall[ encoder->InputState ];

		        if( encoder->Hall_State != 0x07 && encoder->Hall_State != 0x00 ){

		            if( encoder->Hall_Check_IsFirstTime ){
		                encoder->Hall_Check_IsFirstTime = NO;
		                encoder->Hall_Check_First_Time = CURRENT_TIMER_CNT;
		            }

		            encoder->Guess_Pos_T0 = encoder->Pos_Est_Const + Const_Encoder_Distance_Tamagawa[ encoder->Hall_State ] * encoder->Phase_Length;

		            encoder->Hall_Check_Current_Time = CURRENT_TIMER_CNT;
		            encoder->Hall_Check_Time_Pass = encoder->Hall_Check_First_Time - encoder->Hall_Check_Current_Time;

		            if( encoder->Hall_Check_Time_Pass >= encoder->Hall_Check_Checking_Time ){
		                encoder->Hall_Checked = YES;
		                enconder_reg->QEPCTL.bit.SWI = 1;
		            }

		        }

		        break;
		    case ENCODER_TYPE_HALL_ENCODER_STD:
		        encoder->Hall_State = io_bitf_hall;

		        if( encoder->Hall_State != 0x07 && encoder->Hall_State != 0x00 ){

		            if( encoder->Hall_Check_IsFirstTime ){
                        encoder->Hall_Check_IsFirstTime = NO;
                        encoder->Hall_Check_First_Time = CURRENT_TIMER_CNT;
                    }

                    if( encoder->Hall_Sequence == HALL_SEQUENCE_A ){
                        //encoder->Guess_Pos_T0 = encoder->Pos_Est_Const + Const_Encoder_Distance_HallA[ encoder->Hall_State ] * encoder->Phase_Length;
                        //encoder->Guess_Pos_T0 = encoder->Phase_Length + Const_Encoder_Distance_HallA[ encoder->Hall_State ] * encoder->Phase_Length;
                        encoder->Guess_Pos_T0 = encoder->Pos_Est_Offset + Const_Encoder_Distance_HallA[ encoder->Hall_State ] * encoder->Phase_Length;

                    }else{
                        //encoder->Guess_Pos_T0 = encoder->Pos_Est_Const + Const_Encoder_Distance_HallB[ encoder->Hall_State ] * encoder->Phase_Length;
                        //encoder->Guess_Pos_T0 = Const_Encoder_Distance_HallB[ encoder->Hall_State ] * encoder->Phase_Length;
                        encoder->Guess_Pos_T0 = encoder->Pos_Est_Offset + Const_Encoder_Distance_HallB[ encoder->Hall_State ] * encoder->Phase_Length;
                    }

#if(1)
                    encoder->Guess_Pos_T0 = encoder->Guess_Pos_T0 % encoder->MaxPos_ForFOC;
#else
                    if( encoder->Guess_Pos_T0 > encoder->MaxPos_ForFOC ){
                        encoder->Guess_Pos_T0 -= encoder->MaxPos_ForFOC;
                    }
#endif

                    //encoder->Hall_Checked = YES;
                    //Control register : reset position.
                    //enconder_reg->QEPCTL.bit.SWI = 1;
                    //encoder->State = ENCODER_STATE_READY;
                    encoder->Hall_Check_Current_Time = CURRENT_TIMER_CNT;
                    encoder->Hall_Check_Time_Pass = encoder->Hall_Check_First_Time - encoder->Hall_Check_Current_Time;

                    if( encoder->Hall_Check_Time_Pass >= encoder->Hall_Check_Checking_Time ){
                        encoder->Hall_Checked = YES;
                        //Control register : reset position.
                        enconder_reg->QEPCTL.bit.SWI = 1;
                        encoder->State = ENCODER_STATE_READY;
                    }
		        }

		        break;
		    case ENCODER_TYPE_HALL_ENCODER_AB:
                encoder->Hall_State = io_bitf_hall;

                if( encoder->Hall_State != 0x07 && encoder->Hall_State != 0x00 ){

                    if( encoder->Hall_Check_IsFirstTime ){
                        encoder->Hall_Check_IsFirstTime = NO;
                        encoder->Hall_Check_First_Time = CURRENT_TIMER_CNT;
                    }

                    if( encoder->Hall_Sequence == HALL_SEQUENCE_A ){
                        encoder->Guess_Pos_T0 = encoder->Pos_Est_Const + Const_EncoderAB_Distance_HallA[ encoder->Hall_State ] * encoder->Phase_Length;
                    }else{
                        encoder->Guess_Pos_T0 = encoder->Pos_Est_Const + Const_EncoderAB_Distance_HallB[ encoder->Hall_State ] * encoder->Phase_Length;
                    }

                    //encoder->Hall_Checked = YES;
                    //Control register : reset position.
                    //enconder_reg->QEPCTL.bit.SWI = 1;
                    //encoder->State = ENCODER_STATE_READY;
                    encoder->Hall_Check_Current_Time = CURRENT_TIMER_CNT;
                    encoder->Hall_Check_Time_Pass = encoder->Hall_Check_First_Time - encoder->Hall_Check_Current_Time;

                    if( encoder->Hall_Check_Time_Pass >= encoder->Hall_Check_Checking_Time ){
                        encoder->Hall_Checked = YES;
                        //Control register : reset position.
                        enconder_reg->QEPCTL.bit.SWI = 1;
                        encoder->State = ENCODER_STATE_READY;
                    }
                }

                break;

		    case ENCODER_TYPE_ALLEGRO:

		        if( encoder->Pos_PWM != 0 && encoder->Pos_PWM != PI_DUTY_RESOLUTION ){

		            if( encoder->Hall_Check_IsFirstTime ){
                        encoder->Hall_Check_IsFirstTime = NO;
                        encoder->Hall_Check_First_Time = CURRENT_TIMER_CNT;
                    }

                    encoder->Pos_PWM_T0 = encoder->Pos_PWM;
                    encoder->Guess_Pos_T0 = ( encoder->Pos_PWM_T0 - ENCODER_ALLEGRO_PWM_CONST ) * encoder->MaxPos / ENCODER_ALLEGRO_PWM_RESOLUTION;

                    //encoder->Hall_Checked = YES;
                    //Control register : reset position.
                    //enconder_reg->QEPCTL.bit.SWI = 1;
                    //encoder->State = ENCODER_STATE_READY;

                    encoder->Hall_Check_Current_Time = CURRENT_TIMER_CNT;
                    encoder->Hall_Check_Time_Pass = encoder->Hall_Check_First_Time - encoder->Hall_Check_Current_Time;

                    if( encoder->Hall_Check_Time_Pass >= encoder->Hall_Check_Checking_Time ){
                        encoder->Hall_Checked = YES;
                        //Control register : reset position.
                        enconder_reg->QEPCTL.bit.SWI = 1;
                        encoder->State = ENCODER_STATE_READY;
                    }
		        }

		        break;

		    case ENCODER_TYPE_SIRUBA:

		        encoder->Hall_State = io_bitf_hall;
		        encoder->Hall_State = ( ~encoder->Hall_State ) & 0x07;

		        if( encoder->Hall_State != 0x07 && encoder->Hall_State != 0x00 ){

		            if( encoder->Hall_Check_IsFirstTime ){
                        encoder->Hall_Check_IsFirstTime = NO;
                        encoder->Hall_Check_First_Time = CURRENT_TIMER_CNT;
                    }

                    encoder->Guess_Pos_T0 = encoder->Pos_Est_Const + Const_Encoder_Distance_Siruba[ encoder->Hall_State ] * encoder->Phase_Length;

                    //encoder->Hall_Checked = YES;
                    //Control register : reset position.
                    //enconder_reg->QEPCTL.bit.SWI = 1;
                    //encoder->State = ENCODER_STATE_READY;
                    encoder->Hall_Check_Current_Time = CURRENT_TIMER_CNT;
                    encoder->Hall_Check_Time_Pass = encoder->Hall_Check_First_Time - encoder->Hall_Check_Current_Time;

                    if( encoder->Hall_Check_Time_Pass >= encoder->Hall_Check_Checking_Time ){
                        encoder->Hall_Checked = YES;
                        //Control register : reset position.
                        enconder_reg->QEPCTL.bit.SWI = 1;
                        encoder->State = ENCODER_STATE_READY;
                    }
		        }

		        break;
		    default:
		        // Error
		        break;
		    }

		}else if( encoder->State == ENCODER_STATE_NOT_READY ){

		    encoder->Hall_Check_Current_Time = CURRENT_TIMER_CNT;
            encoder->Hall_Check_Time_Pass = encoder->Hall_Check_First_Time - encoder->Hall_Check_Current_Time;

            if( encoder->Hall_Check_Time_Pass >= encoder->Hall_Check_Settling_Time ){
                encoder->State = ENCODER_STATE_READY;
            }

		}

	}
#endif

}

/*===========================================================================================
    Function Name    : encoderOffset
    Input            : encoder : basic encoder
    				   index : offset index
					   pos : offset pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void encoderOffset ( Struct_Basic_Encoder* encoder, int32_t index, int32_t pos )
{
	encoder->Offset_Index = encoder->Offset_Index + index;
	encoder->Offset_Pos = encoder->Offset_Pos + pos;

	if( encoder->Offset_Pos >= encoder->FullPos ){
		encoder->Offset_Index++;
		encoder->Offset_Pos -= encoder->FullPos;
	}else if( encoder->Offset_Pos < 0 ){
		encoder->Offset_Index--;
		encoder->Offset_Pos += encoder->FullPos;
	}
}

/*===========================================================================================
    Function Name    : encoderGetPosition
    Input            : 1.encoder
                        2.pos_reg: position from encoder peripheral
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : When doing this fuction, make sure Interrupt is turned off
//==========================================================================================*/
void encoderGetPosition ( Struct_Basic_Encoder* encoder, int32_t pos_reg )
{
#if(1)

	//static int32_t cnt = 0;

    int32_t current_pos = pos_reg;

	if( encoder->Z_Processed_Flag == NO ){

		if( encoder->Z_Got_Flag == YES ){
			//cnt = 1;

			encoderOffset ( encoder, 0, encoder->MaxPos - encoder->LastPos_B4Z );

			/*
			if( encoder->Type == ENCODER_TYPE_SIRUBA ){

                if( encoder->LastIndex_B4Z == 1 ){

                    encoder->Dummy_Index++;
                    encoder->Dummy_Pos = 0;

                }else{
                    //CG_Move.B4Z_Index = -1;

                    encoder->Dummy_Pos = encoder->MaxPos;
                }

			}else{

			    if( encoder->LastIndex_B4Z == 1 ){
                    encoder->Dummy_Index = 1;
                    encoder->Dummy_Pos = 0;
                }else{
                    encoder->Dummy_Index = -1;
                    encoder->Dummy_Pos = encoder->MaxPos;
                }

			}
			*/
			encoder->Dummy_Index++;
			encoder->Dummy_Pos = 0;

			encoder->Z_Processed_Flag = YES;
		}
	}

	if( current_pos - encoder->Dummy_Pos > encoder->PosErrorMax_P ){
		encoder->Dummy_Index--;
	}else if( current_pos - encoder->Dummy_Pos < encoder->PosErrorMax_N ){
		encoder->Dummy_Index++;
	}

	encoder->Index = encoder->Dummy_Index - encoder->Offset_Index;
	encoder->Pos = current_pos - encoder->Offset_Pos;

	//encoder->Position = ( encoder->Index * encoder->MaxPos ) + encoder->Pos;

	if( encoder->Pos >= encoder->MaxPos ){
		encoder->Index++;
		encoder->Pos -= encoder->MaxPos;
	}else if( encoder->Pos < 0 ){
		encoder->Index--;
		encoder->Pos += encoder->MaxPos;
	}

	encoder->Dummy_Pos = current_pos;

#endif

}

/*===========================================================================================
    Function Name    : encoderGetAngle
    Input            : 1.encoder
                        2.pos_reg: position from encoder peripheral
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t encoderGetAngle ( Struct_Basic_Encoder* encoder, int32_t pos_reg )
{
    int32_t angle;
    int32_t current_pos = pos_reg;

    encoder->Pos_Reg = current_pos;
    if( encoder->Z_Got_Flag ){
        if( encoder->Dir_Def == FORWARD_DIR_TOP ){
            angle = current_pos + encoder->Offset;
        }else{
            angle = encoder->MaxPos - current_pos + encoder->Offset;
        }
    }else{
        if( encoder->Dir_Def == FORWARD_DIR_TOP ){
            angle = current_pos + encoder->Guess_Pos_T0;
        }else{
            angle = encoder->MaxPos - current_pos + encoder->Guess_Pos_T0;
        }
        angle += encoder->Offset;
    }

    //angle = angle * SINE_TABLE_RESOLUTION / encoder->MaxPos_ForFOC;
    //angle = MOD( angle, SINE_TABLE_RESOLUTION );
    angle = (int32_t)( (float)( angle * SINE_TABLE_RESOLUTION ) / (float)encoder->MaxPos_ForFOC );
    angle = angle - ( ( int32_t )( (float)angle / (float)SINE_TABLE_RESOLUTION ) ) * SINE_TABLE_RESOLUTION;

    return angle;

}

/*===========================================================================================
    Function Name    : il_SetUp_EncoderPin
    Input            : 1.enconder_reg
                        2.encoder
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup Encoder pin
//==========================================================================================*/
__inline void il_encoder_isr( struct EQEP_REGS *enconder_reg, Struct_Basic_Encoder* encoder )
{
    int32_t pos_reg;
    uint32_t dummy_pos = 0;

    if( enconder_reg->QFLG.bit.UTO != 0 ){ //   Unit time out interrupt

        dummy_pos = enconder_reg->QPOSLAT;

        if( encoder->First_Z_Event_Flag == YES){
            encoder->First_Z_Event_Flag = NO;
        }else{
            encoder->Delta_PosLat_Dummy = dummy_pos - encoder->PosLat_Old;
        }

        encoder->PosLat_Old = dummy_pos;

        if( encoder->Delta_PosLat_Dummy > encoder->PosErrorMax_P ){
            encoder->Delta_PosLat_Dummy -= encoder->MaxPos;
        }else if( encoder->Delta_PosLat_Dummy < encoder->PosErrorMax_N ){
            encoder->Delta_PosLat_Dummy += encoder->MaxPos;
        }

        encoder->Delta_PosLat = encoder->Delta_PosLat_Dummy;

        //
        encoder->Delta_Pos_Integration += encoder->Delta_PosLat_Dummy;
        //

        encoder->PosLat_Update_Flag = YES;

        enconder_reg->QCLR.bit.UTO = 1;
        enconder_reg->QCLR.bit.INT = 1;

    }

    if( enconder_reg->QFLG.bit.IEL != 0 ){

        if( encoder->State != ENCODER_STATE_NOT_READY ){

            if( encoder->Z_Got_Flag == NO ){

                encoder->First_Z_Event_Flag = YES;

                encoder->LastPos_B4Z = enconder_reg->QPOSILAT;
                //encoder->LastIndex_B4Z = enconder_reg->QEPSTS.bit.QDF * 2 - 1; // CW => 1, CCW => -1

                //
                pos_reg = encoder->LastPos_B4Z;
                if( pos_reg - encoder->Dummy_Pos > encoder->PosErrorMax_P ){
                    encoder->Dummy_Index--;
                }else if( pos_reg - encoder->Dummy_Pos < encoder->PosErrorMax_N ){
                    encoder->Dummy_Index++;
                }
                encoder->Dummy_Pos = pos_reg;
                //

                enconder_reg->QEPCTL.bit.SWI = 1;
                enconder_reg->QEPCTL.bit.PCRM = 0;          // PCRM=00 mode - QPOSCNT reset on index event

            }

            encoder->Z_Got_Flag = YES;

        }

        //
        encoder->Delta_Pos_Integration = 0;
        //

        enconder_reg->QCLR.bit.IEL = 1;
        enconder_reg->QCLR.bit.INT = 1;

    }



}



/*===========================================================================================
    Function Name    : motor_0_encoder_isr
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The QEI ( Encoder ) interrupt event
//==========================================================================================*/
__interrupt void motor_0_encoder_isr( void )
{
	struct EQEP_REGS *enconder_reg;
	Struct_Basic_Encoder* encoder;

	enconder_reg = ( struct EQEP_REGS * )&EQep1Regs;
	encoder = ( Struct_Basic_Encoder*) &CG_Encoder.Motor_0;

	il_encoder_isr( enconder_reg, encoder );

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;   	// Acknowledge interrupt to PIE
}

/*===========================================================================================
    Function Name    : motor_1_encoder_isr
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The QEI ( Encoder ) interrupt event
//==========================================================================================*/
/*
__interrupt void motor_1_encoder_isr( void )
{
	struct EQEP_REGS *enconder_reg;
	Struct_Basic_Encoder* encoder;

	enconder_reg = ( struct EQEP_REGS * )&EQep2Regs;
	encoder = ( Struct_Basic_Encoder*) &CG_Encoder.Motor_1;

	il_encoder_isr( enconder_reg, encoder );

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;   	// Acknowledge interrupt to PIE
}
*/

/*===========================================================================================
    Function Name    : ecap5_encoder_0_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__interrupt void ecap5_encoder_0_isr(void)
{
    int32_t pos_reg;
    struct EQEP_REGS *enconder_reg;
    Struct_Basic_Encoder* encoder;
    //uint8_t state_z = MOTOR_S2_STATE_M0;
    uint8_t state = MOTOR_S2S1S0_SIGNAL_M0;

    enconder_reg = ( struct EQEP_REGS * )&EQep1Regs;
    encoder = ( Struct_Basic_Encoder*) &CG_Encoder.Motor_0;
    /*
    if( ( encoder->Delta_Pos_Integration > encoder->ThresholdPos_P && state_z == HIGH ) ||
        ( encoder->Delta_Pos_Integration < encoder->ThresholdPos_N && state_z == LOW ) ){

       if( encoder->Z_Got_Flag == NO ){
            encoder->First_Z_Event_Flag = YES;
            encoder->LastPos_B4Z = enconder_reg->QPOSCNT;
            encoder->LastIndex_B4Z = state_z * 2 - 1; // CW => 1, CCW => -1
        }
        encoder->Delta_Pos_Integration = 0;
        enconder_reg->QEPCTL.bit.SWI = 1;
        encoder->Z_Got_Flag = YES;
    }*/

    if( encoder->Z_Got_Flag == NO ){
        if( ( encoder->Delta_Pos_Integration > encoder->ThresholdPos_P / 2 && state == encoder->ThresholdPos_P_HallState ) ||
            ( encoder->Delta_Pos_Integration < encoder->ThresholdPos_N / 2 && state == encoder->ThresholdPos_N_HallState ) ){
            encoder->First_Z_Event_Flag = YES;
            encoder->LastPos_B4Z = enconder_reg->QPOSCNT;
            //encoder->LastIndex_B4Z = ( state == encoder->ThresholdPos_P_HallState ) * 2 - 1; // CW => 1, CCW => -1
            //
            pos_reg = encoder->LastPos_B4Z;
            if( pos_reg - encoder->Dummy_Pos > encoder->PosErrorMax_P ){
                encoder->Dummy_Index--;
            }else if( pos_reg - encoder->Dummy_Pos < encoder->PosErrorMax_N ){
                encoder->Dummy_Index++;
            }
            encoder->Dummy_Pos = pos_reg;
            //

            encoder->Hall_Cnt = 0;

            encoder->Delta_Pos_Integration = 0;
            enconder_reg->QEPCTL.bit.SWI = 1;
            encoder->Z_Got_Flag = YES;
        }
    }else{
        //if( ( encoder->Delta_Pos_Integration > encoder->ThresholdPos_P && state == encoder->ThresholdPos_P_HallState ) ||
        //    ( encoder->Delta_Pos_Integration < encoder->ThresholdPos_N && state == encoder->ThresholdPos_N_HallState ) ){
        if( ( encoder->Hall_Cnt > encoder->Threshold_HallCnt_P && state == encoder->ThresholdPos_P_HallState ) ||
            ( encoder->Hall_Cnt < encoder->Threshold_HallCnt_N && state == encoder->ThresholdPos_N_HallState ) ){

            encoder->Hall_Cnt_Latch = encoder->Hall_Cnt;
            encoder->Hall_Cnt = 0;

            encoder->Delta_Pos_Integration = 0;
            //encoder->First_Z_Event_Flag = YES;
            enconder_reg->QEPCTL.bit.SWI = 1;
            encoder->Z_Got_Flag = YES;
        }
    }

    //
    ECap5Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
    // Acknowledge this interrupt to receive more interrupts from group 4
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP4;
}

/*===========================================================================================
    Function Name    : ecap6_encoder_1_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
#if(0)
__interrupt void ecap6_encoder_1_isr(void)
{
    int32_t pos_reg;
    struct EQEP_REGS *enconder_reg;
    Struct_Basic_Encoder* encoder;
    //uint8_t state_z = MOTOR_S2_STATE_M1;
    uint8_t state = MOTOR_S2S1S0_SIGNAL_M1;

    enconder_reg = ( struct EQEP_REGS * )&EQep2Regs;
    encoder = ( Struct_Basic_Encoder*) &CG_Encoder.Motor_1;

    /*
    if( ( encoder->Delta_Pos_Integration > encoder->ThresholdPos_P && state_z == HIGH ) ||
        ( encoder->Delta_Pos_Integration < encoder->ThresholdPos_N && state_z == LOW ) ){

       if( encoder->Z_Got_Flag == NO ){
            encoder->First_Z_Event_Flag = YES;
            encoder->LastPos_B4Z = enconder_reg->QPOSCNT;
            encoder->LastIndex_B4Z = state_z * 2 - 1; // CW => 1, CCW => -1
        }
        encoder->Delta_Pos_Integration = 0;
        enconder_reg->QEPCTL.bit.SWI = 1;
        encoder->Z_Got_Flag = YES;
    }
    */
    if( encoder->Z_Got_Flag == NO ){
        if( ( encoder->Delta_Pos_Integration > encoder->ThresholdPos_P / 2 && state == encoder->ThresholdPos_P_HallState ) ||
            ( encoder->Delta_Pos_Integration < encoder->ThresholdPos_N / 2 && state == encoder->ThresholdPos_N_HallState ) ){
            encoder->First_Z_Event_Flag = YES;
            encoder->LastPos_B4Z = enconder_reg->QPOSCNT;
            //encoder->LastIndex_B4Z = ( state == encoder->ThresholdPos_P_HallState ) * 2 - 1; // CW => 1, CCW => -1
            //
            pos_reg = encoder->LastPos_B4Z;
            if( pos_reg - encoder->Dummy_Pos > encoder->PosErrorMax_P ){
                encoder->Dummy_Index--;
            }else if( pos_reg - encoder->Dummy_Pos < encoder->PosErrorMax_N ){
                encoder->Dummy_Index++;
            }
            encoder->Dummy_Pos = pos_reg;
            //

            encoder->Delta_Pos_Integration = 0;
            enconder_reg->QEPCTL.bit.SWI = 1;
            encoder->Z_Got_Flag = YES;
        }
    }else{
        if( ( encoder->Delta_Pos_Integration > encoder->ThresholdPos_P && state == encoder->ThresholdPos_P_HallState ) ||
            ( encoder->Delta_Pos_Integration < encoder->ThresholdPos_N && state == encoder->ThresholdPos_N_HallState ) ){

            encoder->Delta_Pos_Integration = 0;
            enconder_reg->QEPCTL.bit.SWI = 1;
            encoder->Z_Got_Flag = YES;
        }
    }
    //

    ECap6Regs.ECCLR.all = ( 1UL << 0 ) | ( 1UL << 1 ) | ( 1UL << 2 ) | ( 1UL << 3 ) | ( 1UL << 4 );
    // Acknowledge this interrupt to receive more interrupts from group 4
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP4;
}
#endif

/************************** <END OF FILE> *****************************************/


