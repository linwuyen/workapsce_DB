/*
 * C2000_Timer.h
 *
 *  Created on: 2015/4/22
 *      Author: chaim.chen
 */

#ifndef C2000_TIMER_H_
#define C2000_TIMER_H_

#define FREE_RUN_TIMER  			CpuTimer1Regs
#define FREE_RUN_TIMER_START		( FREE_RUN_TIMER.TCR.bit.TSS = 0 ) 	// Use write-only instruction to set TSS bit = 0
#define CURRENT_TIMER_CNT			( FREE_RUN_TIMER.TIM.all )


#define TIMER_TYPE_INCREASE         0
#define TIMER_TYPE_DECREASE         1
#define TIMER_TYPE                  TIMER_TYPE_DECREASE

/*===========================================================================================
    Function Name    : il_Delay
    Input            :
					   1.delay_time
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_Delay( uint32_t delay_time )
{

	uint32_t	timer_1;
	uint32_t	timer_2;

	timer_1 = CURRENT_TIMER_CNT;
	while(1){
		timer_2 = timer_1 - CURRENT_TIMER_CNT;
		if( timer_2 >= delay_time ){
			break;
		}
	}

}

#endif /* C2000_TIMER_H_ */
