/*===========================================================================================
    File Name       : IDA1_BLDC_CTRL.c
    Built Date      : 2014-08-15
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for BLDC motor control.			
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"
#include "MultiDriveCMD.h"

//volatile Struct_BLDC_CTRL 				CG_BLDC_CTRL;

volatile Struct_BLDC_CTRL                   CG_BLDC_CTRL_M0;
//volatile Struct_BLDC_CTRL                   CG_BLDC_CTRL_M1;


/************************** EXTERNAL VARIABLES ********************************/
//extern volatile Struct_BLDC_Drive 			CG_BLDC_Drive;
extern volatile Struct_Pretect 				CG_Protect;
extern volatile Struct_IO					CG_IO;
extern volatile Struct_IO_FUNC              CG_IO_Func_M0;
//extern volatile Struct_IO_FUNC              CG_IO_Func_M1;
extern volatile Struct_ComProtocol_01		CG_ComProtocol_01;
extern volatile Struct_ADC 					CG_ADC;
extern volatile Struct_GPIO 				CG_GPIO;
extern volatile Struct_Parameter			CG_Parameter;
extern volatile Struct_Encoder 				CG_Encoder;
extern volatile Struct_Move 				CG_Move;
//extern volatile Struct_Speed 				CG_Speed;
extern volatile Struct_HallSensor           CG_Hall_M0;
//extern volatile Struct_HallSensor           CG_Hall_M1;
extern volatile Struct_OPMode 				CG_OPMode;
extern volatile Struct_HWEEP				CG_HWEEP;
//extern volatile Struct_PhaseAdv 			CG_PhaseAdv;
extern volatile Struct_MD 					CG_MD;								// Main.c global variable data structure.
extern volatile Struct_SPK 					CG_SPK;

extern void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void );


//! Function Call for Motor State Machine	
void ( *const motor_State_Handler[ MOTOR_STATE_TOTALNUM ] ) ( Struct_BLDC_CTRL* bldc_ctrl ) =
{
	motor_Stop, motor_Starting, motor_Running, motor_Braking, motor_Freeing, motor_Fault , motor_Wait, motor_Moving, motor_Lock, motor_STO
};

/*===========================================================================================
    Function Name    : variableReset_S_Curve
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableReset_S_Curve ( Struct_BLDC_CTRL* bldc_ctrl )
{
    bldc_ctrl->Accelerate = 0;
    bldc_ctrl->Decelerate = 0;
    bldc_ctrl->Speed_Diff = 0;
    bldc_ctrl->Accelerate_Buffer = 0;
    bldc_ctrl->Decelerate_Buffer = 0;
    bldc_ctrl->AccDec_Step = 0;
    bldc_ctrl->AccDec_StepRest = 0;
}

/*===========================================================================================
    Function Name    : variableInitial_BLDC
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_BLDC initial
//==========================================================================================*/
void variableInitial_BLDC ( Struct_BLDC_CTRL* bldc_ctrl )
{

    bldc_ctrl->Motor_State          	= MOTOR_STATE_WAIT;

    bldc_ctrl->Restart_Cnt = 0;
    bldc_ctrl->Stop_Delay_Cnt = 0;
    bldc_ctrl->Driver_Enable_Flag = NO;
    //bldc_ctrl->EBrake_Flag = NO;
    bldc_ctrl->LockTimer = 0;
    bldc_ctrl->MDL_Enabled = NO;
    bldc_ctrl->Duty_Compensation = 0;

    bldc_ctrl->Dir_Def = FORWARD_DIR_BOTTOM;

	// ==

    bldc_ctrl->Target_ToUpdate_BITF = 0;
    bldc_ctrl->Torque_Limit_Acc = 0;
    bldc_ctrl->Torque_Limit_Acc_Rest = 0;
    bldc_ctrl->Torque_Limit_Acc_Time = 1;

    bldc_ctrl->Torque_Limit_Dec = 0;
    bldc_ctrl->Torque_Limit_Dec_Rest = 0;
    bldc_ctrl->Torque_Limit_Dec_Time = 1;
	
	bldc_ctrl->Ctrl_Step_Limit_Pa = 100;
	//bldc_ctrl->Ctrl_Step_Limit_Pa = 5;
	//bldc_ctrl->Torque_Limit_Kp = 10;
	bldc_ctrl->Current_Restraint_Flag = NO;
	//bldc_ctrl->Current_Restraint_Step_Limit = 100;
	//bldc_ctrl->Current_Restraint_Step_Limit = 5;
	bldc_ctrl->Current_Restraint_Step = 0;
	bldc_ctrl->Current_Restraint_Step_Rest = 0;
	
	bldc_ctrl->Current_Dir = 0;

	bldc_ctrl->Bemf_Duty = 0;
	bldc_ctrl->ReverseEmergency_Cnt = 0;

	bldc_ctrl->Current_Duty_Display = 0;

	bldc_ctrl->Tq_Act_Time = 0;
	bldc_ctrl->Tq_Rec_Time = 0;
	bldc_ctrl->Stall_Time = 0;

	bldc_ctrl->Tq_P_Const = 0;
	bldc_ctrl->Tq_I_Const = 0;

	bldc_ctrl->Path_Spd_Limit = 0;

	bldc_ctrl->BusVRef_ADC = ADC_MAX_VALUE;

	bldc_ctrl->VR_Speed = ( int32_t* )&CG_ADC.Value_Mapping[ ADC_Index_A0X ];

	bldc_ctrl->AlarmLED_State = LOW;
	bldc_ctrl->STO_LED_Flash_Timer = 0;
	bldc_ctrl->WAIT_LED_Flash_Timer = 0;

	//
	bldc_ctrl->Position_Mode = POSITION_DEF_MODE_ENCODER;

	bldc_ctrl->Running_Flag = NO;

	bldc_ctrl->CS_Flag = NO;

	bldc_ctrl->TSPD = 0;

	bldc_ctrl->PowerOn_Run_Checked = NO;

	bldc_ctrl->ServoOff_Delay_TimerMs = 0;

	//
	bldc_ctrl->FOCTest_Flag = NO;
	bldc_ctrl->FOCTest_Angle = 0;
	//

	variableReset_S_Curve( bldc_ctrl );

	setupInitial_PositionControl ( (Struct_PositionControl*) &bldc_ctrl->PositionCtrl );

	bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_CMD ] = MULTI_CMD_NULL_AND_NOECHO;
	bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_DATA1 ] = 0;
	bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_DATA2 ] = 0;


	bldc_ctrl->MultiDriveLite_CMD[ MULTI_DRIVE_LITE_CMD ] = MULTI_CMD_NULL_AND_NOECHO;
    bldc_ctrl->MultiDriveLite_CMD[ MULTI_DRIVE_LITE_DATA ] = 0;
}

/*===========================================================================================
    Function Name    : mcGetCurrent information
    Input            : bldc_ctrl
    Return           : information
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Multi-Command
//==========================================================================================*/
int32_t mcGetCurrentSpeed ( Struct_BLDC_CTRL* bldc_ctrl )
{
    return bldc_ctrl->Current_RPM;
}
int32_t mcGetCurrentDirection ( Struct_BLDC_CTRL* bldc_ctrl )
{
    return bldc_ctrl->Current_Dir;
}
int32_t mcGetCurrentIndex ( Struct_BLDC_CTRL* bldc_ctrl )
{
    Struct_Basic_Encoder* encoder = bldc_ctrl->Encoder_Ptr;

    bldc_ctrl->Capture_Index = encoder->Index;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return bldc_ctrl->Capture_Index;
    }else{
        return ( (int16_t)( ( ( encoder->Index * encoder->FullPos + encoder->Pos ) >> 16 ) & 0xFFFF ) ) ;
    }
}

int32_t mcGetCurrentPos ( Struct_BLDC_CTRL* bldc_ctrl )
{
    Struct_Basic_Encoder* encoder = bldc_ctrl->Encoder_Ptr;

    bldc_ctrl->Capture_Pos = bldc_ctrl->Encoder_Ptr->Pos;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return bldc_ctrl->Capture_Pos;
    }else{
        return ( (int16_t)( ( encoder->Index * encoder->FullPos + encoder->Pos ) & 0xFFFF ) ) ;
    }
}

/*===========================================================================================
    Function Name    : moveIndexDisplay_Current
    Input            : 1.bldc_ctrl
    Return           : index in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcIndexDisplay_Current( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = bldc_ctrl->Encoder_Ptr->Index;
    int32_t pos = bldc_ctrl->Encoder_Ptr->Pos;
    int32_t max = bldc_ctrl->Encoder_Ptr->FullPos;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return index;
    }else{
        return ( (int16_t)( ( ( index * max + pos ) >> 16 ) & 0xFFFF ) ) ;
    }
}

/*===========================================================================================
    Function Name    : moveIndexDisplay_Target
    Input            : 1.bldc_ctrl
    Return           : index in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcIndexDisplay_Target( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = bldc_ctrl->PositionCtrl.Target_Index;
    int32_t pos = bldc_ctrl->PositionCtrl.Target_Pos;
    int32_t max = bldc_ctrl->Encoder_Ptr->FullPos;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return index;
    }else{
        return ( (int16_t)( ( ( index * max + pos ) >> 16 ) & 0xFFFF ) ) ;
    }
}

/*===========================================================================================
    Function Name    : mcIndexDisplay_CurrentTarget
    Input            : 1.bldc_ctrl
    Return           : index in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcIndexDisplay_CurrentTarget( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = bldc_ctrl->PositionCtrl.Current_Target_Index;
    int32_t pos = bldc_ctrl->PositionCtrl.Current_Target_Pos;
    int32_t max = bldc_ctrl->Encoder_Ptr->FullPos;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return index;
    }else{
        return ( (int16_t)( ( ( index * max + pos ) >> 16 ) & 0xFFFF ) ) ;
    }
}

/*===========================================================================================
    Function Name    : movePosDisplay_Current
    Input            : 1.bldc_ctrl
    Return           : pos in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcPosDisplay_Current( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = bldc_ctrl->Encoder_Ptr->Index;
    int32_t pos = bldc_ctrl->Encoder_Ptr->Pos;
    int32_t max = bldc_ctrl->Encoder_Ptr->FullPos;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return pos;
    }else{
        return ( (int16_t)( ( index * max + pos ) & 0xFFFF ) ) ;
    }
}

/*===========================================================================================
    Function Name    : movePosDisplay_Target
    Input            : 1.bldc_ctrl
    Return           : pos in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcPosDisplay_Target( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = bldc_ctrl->PositionCtrl.Target_Index;
    int32_t pos = bldc_ctrl->PositionCtrl.Target_Pos;
    int32_t max = bldc_ctrl->Encoder_Ptr->FullPos;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return pos;
    }else{
        return ( (int16_t)( ( index * max + pos ) & 0xFFFF ) ) ;
    }
}


/*===========================================================================================
    Function Name    : movePosDisplay_CurrentTarget
    Input            : 1.bldc_ctrl
    Return           : pos in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcPosDisplay_CurrentTarget( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = bldc_ctrl->PositionCtrl.Current_Target_Index;
    int32_t pos = bldc_ctrl->PositionCtrl.Current_Target_Pos;
    int32_t max = bldc_ctrl->Encoder_Ptr->FullPos;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        return pos;
    }else{
        return ( (int16_t)( ( index * max + pos ) & 0xFFFF ) ) ;
    }
}

/*===========================================================================================
    Function Name    : mcCS
    Input            : 1.bldc_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mcCS ( Struct_BLDC_CTRL* bldc_ctrl )
{
    //int32_t current_pos;
    int32_t index = bldc_ctrl->N_H[ POS_CS ];
    int32_t pos = bldc_ctrl->N_L[ POS_CS ];

    int32_t dummy_position;
    int32_t dummy_index;
    int32_t pos_reg;
    Struct_Basic_Encoder* encoder = bldc_ctrl->Encoder_Ptr;

    DINT;

    if(  bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        if( pos > encoder->FullPos ){
            pos = encoder->FullPos;
        }
    }else{

        dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

        index = dummy_position / encoder->FullPos;
        pos = ( int16_t )( ( dummy_position % encoder->FullPos ) & 0xFFFF );

        if( ( int16_t )pos < 0 ){
            pos += encoder->FullPos;
            index --;
        }

    }
    // Capture_Index = Encoder_Index - Offset_Index_Old
    // Encoder_Index = Capture_Index + Offset_Index_Old
    // CS_Index = Encoder_Index - Offset_Index_New;
    // Offset_Index_New = Encoder_Index - CS_Index
    //                  = Capture_Index + Offset_Index_Old - CS_Index
    // Same Process for Pos calculation

    encoder->Offset_Index = bldc_ctrl->Capture_Index + encoder->Offset_Index - index;
    encoder->Offset_Pos = bldc_ctrl->Capture_Pos + encoder->Offset_Pos - pos;

    if( encoder->Z_Processed_Flag == YES ){

        // If Z Interrupt was processed, then keep Encoder index small ( to prevent Encoder index overflow )
        // Index = Encoder_Index - Offset_Index
        // Offset_Index = Offset_Index - Encoder_Index
        // Encoder_Index = Encoder_Index - Encoder_Index = 0

        encoder->Offset_Index -= encoder->Dummy_Index;
        encoder->Dummy_Index = 0;

    }

    dummy_index = encoder->Offset_Pos / encoder->FullPos;

    encoder->Offset_Index  += dummy_index;
    encoder->Offset_Pos = encoder->Offset_Pos - ( encoder->FullPos * dummy_index );

    if( bldc_ctrl->MultiDrive_Src == SRC_MULTI_DRIVE_M0 ){
        pos_reg = EQep1Regs.QPOSCNT;
    }else{
        pos_reg = EQep2Regs.QPOSCNT;
    }

    encoderGetPosition ( encoder, pos_reg );

    il_SpeedControl_Set_Index ( ( Struct_DriverMotorInfor* ) &bldc_ctrl->PositionCtrl.Drive_Infor, encoder->Index);
    il_SpeedControl_Set_Pos ( ( Struct_DriverMotorInfor* ) &bldc_ctrl->PositionCtrl.Drive_Infor, encoder->Pos);

    il_EncoderPositionProcess ( (Struct_Basic_Encoder*) bldc_ctrl->Encoder_Ptr );

    if( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING ){
        bldc_ctrl->CS_CtrlSkip_Flag = YES;
    }

    bldc_ctrl->PositionCtrl.Current_Target_Index = index;
    bldc_ctrl->PositionCtrl.Current_Target_Pos = pos;

    bldc_ctrl->PositionCtrl.Target_Index = index;
    bldc_ctrl->PositionCtrl.Target_Pos = pos;

    bldc_ctrl->PositionCtrl.Drive_Infor.Pos_Old = encoder->Pos;

    EINT;   // Enable Global interrupt INTM
}


/*===========================================================================================
    Function Name    : mcCMA
    Input            : 1.bldc_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mcCMA ( Struct_BLDC_CTRL* bldc_ctrl )
{
    //int32_t current_pos;
    int32_t index = (int16_t)bldc_ctrl->N_H[ POS_MA ];
    int32_t pos = (int16_t)bldc_ctrl->N_L[ POS_MA ];
    int32_t dummy_position;

    DINT;

    if(  bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        if( pos > bldc_ctrl->PositionCtrl.MaxPos ){
            pos = bldc_ctrl->PositionCtrl.MaxPos;
        }
    }else{

        dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

        index = dummy_position / bldc_ctrl->PositionCtrl.MaxPos;
        pos = ( int16_t )( ( dummy_position % bldc_ctrl->PositionCtrl.MaxPos ) & 0xFFFF );

        if( ( int16_t )pos < 0 ){
            pos += bldc_ctrl->PositionCtrl.MaxPos;
            index --;
        }

    }

    bldc_ctrl->PositionCtrl.Target_Index = index;
    bldc_ctrl->PositionCtrl.Target_Pos = pos;

    if( bldc_ctrl->PositionCtrl.Target_Pos >= bldc_ctrl->PositionCtrl.MaxPos ){
        bldc_ctrl->PositionCtrl.Target_Index++;
        bldc_ctrl->PositionCtrl.Target_Pos -= bldc_ctrl->PositionCtrl.MaxPos;
    }else if( bldc_ctrl->PositionCtrl.Target_Pos < 0 ){
        bldc_ctrl->PositionCtrl.Target_Index--;
        bldc_ctrl->PositionCtrl.Target_Pos += bldc_ctrl->PositionCtrl.MaxPos;
    }

    bldc_ctrl->PositionCtrl.Meat_Target_Flag = NO;

    EINT;   // Enable Global interrupt INTM

}

/*===========================================================================================
    Function Name    : mcCMR
    Input            : 1.bldc_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mcCMR ( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = (int16_t)bldc_ctrl->N_H[ POS_MR ];
    int32_t pos = (int16_t)bldc_ctrl->N_L[ POS_MR ];
    int32_t dummy_position;

    DINT;

    if(  bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        if( pos > bldc_ctrl->PositionCtrl.MaxPos ){
            pos = bldc_ctrl->PositionCtrl.MaxPos;
        }
    }else{

        dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

        index = dummy_position / bldc_ctrl->PositionCtrl.MaxPos;
        pos = ( int16_t )( ( dummy_position % bldc_ctrl->PositionCtrl.MaxPos ) & 0xFFFF );

        if( ( int16_t )pos < 0 ){
            pos += bldc_ctrl->PositionCtrl.MaxPos;
            index --;
        }

    }

    bldc_ctrl->PositionCtrl.Target_Index = bldc_ctrl->PositionCtrl.Current_Target_Index + index;
    bldc_ctrl->PositionCtrl.Target_Pos = bldc_ctrl->PositionCtrl.Current_Target_Pos + pos;

    if( bldc_ctrl->PositionCtrl.Target_Pos >= bldc_ctrl->PositionCtrl.MaxPos ){
        bldc_ctrl->PositionCtrl.Target_Index++;
        bldc_ctrl->PositionCtrl.Target_Pos -= bldc_ctrl->PositionCtrl.MaxPos;
    }else if( bldc_ctrl->PositionCtrl.Target_Pos < 0 ){
        bldc_ctrl->PositionCtrl.Target_Index--;
        bldc_ctrl->PositionCtrl.Target_Pos += bldc_ctrl->PositionCtrl.MaxPos;
    }

    bldc_ctrl->PositionCtrl.Meat_Target_Flag = NO;

    EINT;   // Enable Global interrupt INTM
}

/*===========================================================================================
    Function Name    : mcCMR_AtRun
    Input            : 1.bldc_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mcCMR_AtRun ( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = (int16_t)bldc_ctrl->N_H[ POS_MR ];
    int32_t pos = (int16_t)bldc_ctrl->N_L[ POS_MR ];
    int32_t dummy_position;

    if(  bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        if( pos > bldc_ctrl->PositionCtrl.MaxPos ){
            pos = bldc_ctrl->PositionCtrl.MaxPos;
        }
    }else{

        dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

        index = dummy_position / bldc_ctrl->PositionCtrl.MaxPos;
        pos = ( int16_t )( ( dummy_position % bldc_ctrl->PositionCtrl.MaxPos ) & 0xFFFF );

        if( ( int16_t )pos < 0 ){
            pos += bldc_ctrl->PositionCtrl.MaxPos;
            index --;
        }

    }

    DINT;

    //bldc_ctrl->PositionCtrl.Target_Index = bldc_ctrl->PositionCtrl.Drive_Infor.Index_Now + index;
    //bldc_ctrl->PositionCtrl.Target_Pos = bldc_ctrl->PositionCtrl.Drive_Infor.Pos_Now + pos;
    bldc_ctrl->PositionCtrl.Target_Index = bldc_ctrl->Capture_Index + index;
    bldc_ctrl->PositionCtrl.Target_Pos = bldc_ctrl->Capture_Pos + pos;

    if( bldc_ctrl->PositionCtrl.Target_Pos >= bldc_ctrl->PositionCtrl.MaxPos ){
        bldc_ctrl->PositionCtrl.Target_Index++;
        bldc_ctrl->PositionCtrl.Target_Pos -= bldc_ctrl->PositionCtrl.MaxPos;
    }else if( bldc_ctrl->PositionCtrl.Target_Pos < 0 ){
        bldc_ctrl->PositionCtrl.Target_Index--;
        bldc_ctrl->PositionCtrl.Target_Pos += bldc_ctrl->PositionCtrl.MaxPos;
    }

    bldc_ctrl->PositionCtrl.Meat_Target_Flag = NO;

    EINT;   // Enable Global interrupt INTM
}

/*===========================================================================================
    Function Name    : mcIMR
    Input            : 1.bldc_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mcIMR ( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t index = (int16_t)bldc_ctrl->N_H[ POS_IMR ];
    int32_t pos = (int16_t)bldc_ctrl->N_L[ POS_IMR ];
    //int64_t dec_time;
    //int64_t spd_const = POSITION_CTRL_SPEED_CONST;

    if( bldc_ctrl->Position_Mode == POSITION_DEF_MODE_ENCODER ){
        bldc_ctrl->Buffer_IMR_CMD = ( ( int16_t )index ) * bldc_ctrl->PositionCtrl.MaxPos + pos;
    }else{
        bldc_ctrl->Buffer_IMR_CMD = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

    }

    if( bldc_ctrl->Buffer_IMR_CMD < 0 ){
        bldc_ctrl->Buffer_IMR_CMD = -1 * bldc_ctrl->Buffer_IMR_CMD;
    }else if( bldc_ctrl->Buffer_IMR_CMD == 0 ){
        bldc_ctrl->Buffer_IMR_CMD = 1;
    }


    index = bldc_ctrl->Buffer_IMR_CMD / bldc_ctrl->PositionCtrl.MaxPos;
    pos = bldc_ctrl->Buffer_IMR_CMD % bldc_ctrl->PositionCtrl.MaxPos;

    //dec_time = ( int64_t )bldc_ctrl->Buffer_IMR_CMD * 120000LL / ( bldc_ctrl->IMR_SpeedInitInRPM_Abs * bldc_ctrl->PositionCtrl.MaxPos );
    //dec_time = dec_time * spd_const / bldc_ctrl->IMR_SpeedInitInRPM_Abs;

    DINT;

    if( bldc_ctrl->Current_Dir == DIR_CW ){
        bldc_ctrl->PositionCtrl.Target_Index = bldc_ctrl->Capture_Index + index;
        bldc_ctrl->PositionCtrl.Target_Pos = bldc_ctrl->Capture_Pos + pos;
    }else{
        bldc_ctrl->PositionCtrl.Target_Index = bldc_ctrl->Capture_Index - index;
        bldc_ctrl->PositionCtrl.Target_Pos = bldc_ctrl->Capture_Pos - pos;
    }

    if( bldc_ctrl->PositionCtrl.Target_Pos >= bldc_ctrl->PositionCtrl.MaxPos ){
        bldc_ctrl->PositionCtrl.Target_Index++;
        bldc_ctrl->PositionCtrl.Target_Pos -= bldc_ctrl->PositionCtrl.MaxPos;
    }else if( bldc_ctrl->PositionCtrl.Target_Pos < 0 ){
        bldc_ctrl->PositionCtrl.Target_Index--;
        bldc_ctrl->PositionCtrl.Target_Pos += bldc_ctrl->PositionCtrl.MaxPos;
    }

    /*
    if( bldc_ctrl->Target_Dir == DIR_CW ){
        bldc_ctrl->PositionCtrl.Path_Spd = bldc_ctrl->IMR_SpeedInitInRPM_Abs * bldc_ctrl->PositionCtrl.MaxPos / 60;
    }else{
        bldc_ctrl->PositionCtrl.Path_Spd = -bldc_ctrl->IMR_SpeedInitInRPM_Abs * bldc_ctrl->PositionCtrl.MaxPos / 60;
    }*/

    //bldc_ctrl->IMR_Dec_Time = dec_time;

    bldc_ctrl->PositionCtrl.Meat_Target_Flag = NO;


    bldc_ctrl->IMR_Flag = YES;

    EINT;   // Enable Global interrupt INTM

}

/*===========================================================================================
    Function Name    : management_StopDelayTimer
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @1ms timer event
//==========================================================================================*/
void management_StopDelayTimer( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
	if( bldc_ctrl->Current_Duty == bldc_ctrl->Target_Duty ){
		if( bldc_ctrl->Stop_Delay_Cnt < 65536 ){
		    bldc_ctrl->Stop_Delay_Cnt++;
		}
	}else{
	    bldc_ctrl->Stop_Delay_Cnt = 0;
	}
#endif

}

/*===========================================================================================
    Function Name    : management_TorqueLimit_StepDrive
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void management_TorqueLimit_StepDrive( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t restraint_step;
	int32_t restraint_step_limit = bldc_ctrl->Ctrl_Step_Limit_Pa * CTRL_FACTOR_1;
	int32_t dummy;
    Struct_Driver_Pretect   *protect;
    Struct_Motor_Analog     *adc;
    protect = bldc_ctrl->Protect_Ptr;
    adc = bldc_ctrl->ADC_Ptr;

	// Over current
#if(1)

	bldc_ctrl->Current_Restraint_Flag = NO;

	if( protect->OverPower_flag == YES ){
		if( adc->Power >= OVER_POWER_LIMIT ){
		    bldc_ctrl->Current_Restraint_Flag = YES;
			restraint_step = ( adc->Power - OVER_POWER_LIMIT ) * OVER_POWER_P_GAIN;
		}else{
			restraint_step_limit = ( OVER_POWER_LIMIT - adc->Power ) * OVER_POWER_P_GAIN + bldc_ctrl->Current_Restraint_Step_Rest;
		}
	}

	bldc_ctrl->Torque_Limit = bldc_ctrl->OpMode_Ptr->Torque_Limit;

	if( protect->OverLoad_flag == YES ){

		if( adc->Shunt_I >= bldc_ctrl->Torque_Limit ){
			dummy = ( adc->Shunt_I - bldc_ctrl->Torque_Limit ) * bldc_ctrl->Tq_P_Const;
			if( ( bldc_ctrl->Current_Restraint_Flag == YES && dummy > restraint_step ) ||
				( bldc_ctrl->Current_Restraint_Flag == NO ) ){
				restraint_step = dummy;
			}
			bldc_ctrl->Current_Restraint_Flag = YES;

		}else if( bldc_ctrl->Current_Restraint_Flag == NO ){
			dummy = ( bldc_ctrl->Torque_Limit - adc->Shunt_I ) * bldc_ctrl->Tq_P_Const;
			if( dummy < restraint_step_limit ){
				restraint_step_limit = dummy;
			}
		}
	}

	if( protect->FWCR_flag == YES ){
		if( adc->Shunt_I >= OVER_CURRENT_LIMIT ){
			dummy = ( adc->Shunt_I - OVER_CURRENT_LIMIT ) * bldc_ctrl->Tq_P_Const;
			if( ( bldc_ctrl->Current_Restraint_Flag == YES && dummy > restraint_step ) ||
				( bldc_ctrl->Current_Restraint_Flag == NO ) ){
				restraint_step = dummy;
			}
			bldc_ctrl->Current_Restraint_Flag = YES;

		}else if( bldc_ctrl->Current_Restraint_Flag == NO ){
			dummy = ( OVER_CURRENT_LIMIT - adc->Shunt_I ) * bldc_ctrl->Tq_P_Const;
			if( dummy < restraint_step_limit ){
				restraint_step_limit = dummy;
			}

		}

	}

	if( bldc_ctrl->Current_Restraint_Flag == YES ){
		dummy = restraint_step + bldc_ctrl->Current_Restraint_Step_Rest;
		bldc_ctrl->Current_Restraint_Step = dummy / CTRL_FACTOR_1;
		bldc_ctrl->Current_Restraint_Step_Limit = 0;
	}else{
		if( protect->HWCR_Lock_Flag == HIGH ){
			dummy = 0;
		}else{
			dummy = restraint_step_limit + bldc_ctrl->Current_Restraint_Step_Rest;
		}
		bldc_ctrl->Current_Restraint_Step_Limit = dummy / CTRL_FACTOR_1;
	}

	bldc_ctrl->Current_Restraint_Step_Rest = dummy % CTRL_FACTOR_1;

#endif
}

/*===========================================================================================
    Function Name    : management_TorqueLimit_FOCDrive
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void management_TorqueLimit_FOCDrive( Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t tq_limit_target;
	int32_t dummy;
    Struct_Driver_Pretect   *protect;
    protect = bldc_ctrl->Protect_Ptr;

	if( protect->FWCR_flag ){
		tq_limit_target = bldc_ctrl->ADC_Ptr->FWOCP;
	}else{
		tq_limit_target = bldc_ctrl->ADC_Ptr->HWOCP;
	}

	if( protect->OverLoad_flag || bldc_ctrl->Tq_Act_Time == 0 ){
		if( tq_limit_target > bldc_ctrl->OpMode_Ptr->Torque_Limit ){
			tq_limit_target = bldc_ctrl->OpMode_Ptr->Torque_Limit;
		}
	}

	if( bldc_ctrl->Motor_State == MOTOR_STATE_STARTING ){
		bldc_ctrl->Torque_Limit = tq_limit_target;
	    //tq_limit_target = bldc_ctrl->OpMode_Ptr->Torque_Limit;
	}else{

		dummy = TORQUE_1A_CONST + bldc_ctrl->Torque_Limit_Acc_Rest;
		bldc_ctrl->Torque_Limit_Acc = dummy / bldc_ctrl->Torque_Limit_Acc_Time;
		bldc_ctrl->Torque_Limit_Acc_Rest = dummy % bldc_ctrl->Torque_Limit_Acc_Time;

		dummy = TORQUE_1A_CONST + bldc_ctrl->Torque_Limit_Dec_Rest;
		bldc_ctrl->Torque_Limit_Dec = dummy / bldc_ctrl->Torque_Limit_Dec_Time;
		bldc_ctrl->Torque_Limit_Dec_Rest = dummy % bldc_ctrl->Torque_Limit_Dec_Time;

		/*
		if( bldc_ctrl->Torque_Limit + bldc_ctrl->Torque_Limit_Acc < tq_limit_target ){
			bldc_ctrl->Torque_Limit += bldc_ctrl->Torque_Limit_Acc;
		}else if( bldc_ctrl->Torque_Limit - bldc_ctrl->Torque_Limit_Acc > tq_limit_target ){
			bldc_ctrl->Torque_Limit -= bldc_ctrl->Torque_Limit_Acc;
		}else{
			bldc_ctrl->Torque_Limit = tq_limit_target;
			bldc_ctrl->Torque_Limit_Acc_Rest = 0;
		}
		*/

		if( bldc_ctrl->Torque_Limit + bldc_ctrl->Torque_Limit_Acc < tq_limit_target ){
            bldc_ctrl->Torque_Limit += bldc_ctrl->Torque_Limit_Acc;
        }else if( bldc_ctrl->Torque_Limit - bldc_ctrl->Torque_Limit_Dec > tq_limit_target ){
            bldc_ctrl->Torque_Limit -= bldc_ctrl->Torque_Limit_Dec;
        }else{
            bldc_ctrl->Torque_Limit = tq_limit_target;
            bldc_ctrl->Torque_Limit_Acc_Rest = 0;
            bldc_ctrl->Torque_Limit_Dec_Rest = 0;
        }

	}

}

/*===========================================================================================
    Function Name    : reduceDuty
    Input            : 1.target_duty: target duty
					   2.step_duty : One step reduced duty
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : reduce duty
//==========================================================================================*/
static void reduceDuty( int32_t* target_duty, int32_t step_duty )
{
	if( *target_duty > 0 ){
		*target_duty -= step_duty;
	}else if( *target_duty < 0 ){
		*target_duty += step_duty;
	}
}

/*===========================================================================================
    Function Name    : calculateTargetDuty
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current duty at open loop.
//==========================================================================================*/
void calculateTargetDuty ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;
    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;
    int32_t acc_time = op_mode->Acc_Time;
    int32_t dec_time = op_mode->Dec_Time;
	int32_t dummy;
	// target duty

	bldc_ctrl->Target_Duty_Abs = op_mode->Target_Duty_Abs;

	if( bldc_ctrl->Target_Duty_Abs > bldc_drive->Period_Limit ){
		bldc_ctrl->Target_Duty_Abs = bldc_drive->Period_Limit;
	}

#define SERVO_OFF_CONDITION   ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 && bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0 )

	if( SERVO_OFF_CONDITION ||
	    ( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == LOW &&
	     !bldc_ctrl->EForward_Flag &&
	     !bldc_ctrl->EReverse_Flag ) ){

		bldc_ctrl->Target_Duty_Abs = 0;
		bldc_ctrl->Target_Duty = 0;
		//bldc_ctrl->Current_Duty  = 0;

	}else if( bldc_ctrl->EForward_Flag ){

	    bldc_ctrl->Target_Duty_Abs = bldc_ctrl->Drive_Ptr->Duty_Min_Abs +
	            bldc_ctrl->Drive_Ptr->Duty_Resolution * ( op_mode->Digit_Duty[ op_mode->Digit_Num ] ) / DUTY_100_PERCENT;

	    bldc_ctrl->Target_Duty = bldc_ctrl->Target_Duty_Abs;

	    acc_time = bldc_ctrl->Emergency_Acc_Time;
	    dec_time = bldc_ctrl->Emergency_Dec_Time;

	}else if( bldc_ctrl->EReverse_Flag ){

	    bldc_ctrl->Target_Duty_Abs = bldc_ctrl->Drive_Ptr->Duty_Min_Abs +
                bldc_ctrl->Drive_Ptr->Duty_Resolution * ( op_mode->Digit_Duty[ op_mode->Digit_Num ] ) / DUTY_100_PERCENT;

        bldc_ctrl->Target_Duty = -bldc_ctrl->Target_Duty_Abs;

        acc_time = bldc_ctrl->Emergency_Acc_Time;
        dec_time = bldc_ctrl->Emergency_Dec_Time;

	}else{
		if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CW ){
			bldc_ctrl->Target_Duty = bldc_ctrl->Target_Duty_Abs;
		}else{
			bldc_ctrl->Target_Duty = -bldc_ctrl->Target_Duty_Abs;
		}
	}

	// decide acc/dec

	dummy = bldc_drive->Duty_Resolution + bldc_ctrl->AccDec_Rest;

	bldc_ctrl->Acc = ( acc_time == 0 ? bldc_drive->Duty_Resolution : dummy / acc_time );
	bldc_ctrl->Dec = ( dec_time == 0 ? bldc_drive->Duty_Resolution : dummy / dec_time );

	if( bldc_ctrl->Current_Duty > 0 ){

		if( bldc_ctrl->Current_Duty + bldc_ctrl->Acc < bldc_ctrl->Target_Duty ){
			bldc_ctrl->Current_Duty += bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % acc_time;
		}else if( bldc_ctrl->Current_Duty - bldc_ctrl->Dec > bldc_ctrl->Target_Duty ){
			bldc_ctrl->Current_Duty -= bldc_ctrl->Dec;
			if( bldc_ctrl->Current_Duty < 0 ){
				bldc_ctrl->Current_Duty = 0;
				bldc_ctrl->AccDec_Rest = 0;
			}else{
				bldc_ctrl->AccDec_Rest = dummy % dec_time;
			}
		}else{
			bldc_ctrl->Current_Duty = bldc_ctrl->Target_Duty;
			bldc_ctrl->AccDec_Rest = 0;
		}

	}else if( bldc_ctrl->Current_Duty < 0 ){

		if( bldc_ctrl->Current_Duty - bldc_ctrl->Acc > bldc_ctrl->Target_Duty ){
			bldc_ctrl->Current_Duty -= bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % acc_time;
		}else if( bldc_ctrl->Current_Duty + bldc_ctrl->Dec < bldc_ctrl->Target_Duty ){
			bldc_ctrl->Current_Duty += bldc_ctrl->Dec;
			if( bldc_ctrl->Current_Duty > 0 ){
				bldc_ctrl->Current_Duty = 0;
				bldc_ctrl->AccDec_Rest = 0;
			}else{
				bldc_ctrl->AccDec_Rest = dummy % dec_time;
			}
		}else{
			bldc_ctrl->Current_Duty = bldc_ctrl->Target_Duty;
			bldc_ctrl->AccDec_Rest = 0;
		}

	}else{

		if( bldc_ctrl->Current_Duty + bldc_ctrl->Acc < bldc_ctrl->Target_Duty ){
			bldc_ctrl->Current_Duty += bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % acc_time;
		}else if( bldc_ctrl->Current_Duty - bldc_ctrl->Acc > bldc_ctrl->Target_Duty ){
			bldc_ctrl->Current_Duty -= bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % acc_time;
		}else{
			bldc_ctrl->Current_Duty = bldc_ctrl->Target_Duty;
			bldc_ctrl->AccDec_Rest = 0;
		}

	}

	// decide direction

	if( bldc_ctrl->Current_Duty > 0 ){
		bldc_ctrl->Target_Dir = DIR_CW;
		bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
	}else if( bldc_ctrl->Current_Duty < 0 ){
		bldc_ctrl->Target_Dir = DIR_CCW;
		bldc_ctrl->Current_Duty_Abs = -bldc_ctrl->Current_Duty;
	}else{
		bldc_ctrl->Current_Duty_Abs = 0;
	}

#endif

}

/*===========================================================================================
    Function Name    : calculate_Acc
    Input            :  1. bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : acc caluculate
//==========================================================================================*/
void calculate_Acc ( Struct_BLDC_CTRL *bldc_ctrl )
{
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;
    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;
    int32_t acc_time = op_mode->Acc_Time;

    int32_t dummy;

    if( bldc_ctrl->EForward_Flag || bldc_ctrl->EReverse_Flag ){
        acc_time = bldc_ctrl->Emergency_Acc_Time;
    }

    dummy = SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest;
    bldc_ctrl->Acc = ( acc_time == 0 ? SPEED_CONST_MAX : dummy / acc_time );

    if( bldc_ctrl->Acc < 1 ){
        bldc_ctrl->Accelerate_Buffer = 0;
    }else{
        bldc_ctrl->Accelerate_Buffer = bldc_ctrl->Accelerate * bldc_ctrl->Accelerate * op_mode->Acc_Buffer_Time / ( 2 * bldc_ctrl->Acc );
    }
    bldc_ctrl->Acc_Time_Const = acc_time * op_mode->Acc_Buffer_Time;
    if( bldc_ctrl->Acc_Time_Const == 0 ){
        bldc_ctrl->Acc_Time_Const = 1;
    }
    bldc_ctrl->AccDec_Step = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_StepRest ) / ( bldc_ctrl->Acc_Time_Const );
    bldc_ctrl->AccDec_StepRest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_StepRest ) % ( bldc_ctrl->Acc_Time_Const );

    bldc_ctrl->Decelerate = 0;

    if( bldc_ctrl->Speed_Diff_Abs > bldc_ctrl->Accelerate_Buffer ){
        bldc_ctrl->Accelerate += bldc_ctrl->AccDec_Step;
        if( bldc_ctrl->Accelerate > bldc_ctrl->Acc ){
            bldc_ctrl->Accelerate = bldc_ctrl->Acc;
        }
    }else{
        bldc_ctrl->Accelerate -= bldc_ctrl->AccDec_Step;
        if( bldc_ctrl->Accelerate < 1 ){
            bldc_ctrl->Accelerate = 1;
        }
    }
}

/*===========================================================================================
    Function Name    : calculate_Dec
    Input            :  1. bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : dec caluculate
//==========================================================================================*/
void calculate_Dec ( Struct_BLDC_CTRL *bldc_ctrl )
{
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;
    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;
    int32_t dec_time = op_mode->Dec_Time;
    int32_t dummy;

    if( bldc_ctrl->EForward_Flag || bldc_ctrl->EReverse_Flag ){
        dec_time = bldc_ctrl->Emergency_Dec_Time;
    }

    dummy = SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest;
    bldc_ctrl->Dec = ( dec_time == 0 ? SPEED_CONST_MAX : dummy / dec_time );
    if( bldc_ctrl->Dec < 1 ){
        bldc_ctrl->Decelerate_Buffer = 0;
    }else{
        bldc_ctrl->Decelerate_Buffer = bldc_ctrl->Decelerate * bldc_ctrl->Decelerate * op_mode->Dec_Buffer_Time / ( 2 * bldc_ctrl->Dec );
    }
    bldc_ctrl->Dec_Time_Const = dec_time * op_mode->Dec_Buffer_Time;
    if( bldc_ctrl->Dec_Time_Const == 0 ){
        bldc_ctrl->Dec_Time_Const = 1;
    }
    bldc_ctrl->AccDec_Step = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_StepRest ) / ( bldc_ctrl->Dec_Time_Const );
    bldc_ctrl->AccDec_StepRest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_StepRest ) % ( bldc_ctrl->Dec_Time_Const );

    bldc_ctrl->Accelerate = 0;

    if( bldc_ctrl->Speed_Diff_Abs > bldc_ctrl->Decelerate_Buffer ){
        bldc_ctrl->Decelerate += bldc_ctrl->AccDec_Step;
        if( bldc_ctrl->Decelerate > bldc_ctrl->Dec ){
            bldc_ctrl->Decelerate = bldc_ctrl->Dec;
        }
    }else{
        bldc_ctrl->Decelerate -= bldc_ctrl->AccDec_Step;
        if( bldc_ctrl->Decelerate < 1 ){
            bldc_ctrl->Decelerate = 1;
        }
    }
}

/*===========================================================================================
    Function Name    : speed_Management
    Input            : 1. bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : speed_Management
//==========================================================================================*/
void speed_Management ( Struct_BLDC_CTRL *bldc_ctrl )
{
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;
    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;
    int32_t acc_time = op_mode->Acc_Time;
    int32_t dec_time = op_mode->Dec_Time;

    if( bldc_ctrl->EForward_Flag || bldc_ctrl->EReverse_Flag ){
        acc_time = bldc_ctrl->Emergency_Acc_Time;
        dec_time = bldc_ctrl->Emergency_Dec_Time;
    }

    bldc_ctrl->Speed_Diff = bldc_ctrl->Target_Speed_ERPM - bldc_ctrl->Current_Target_Speed_ERPM;
    bldc_ctrl->Speed_Diff_Abs = ( bldc_ctrl->Speed_Diff >= 0 ? bldc_ctrl->Speed_Diff : -bldc_ctrl->Speed_Diff );

    if( bldc_ctrl->Current_Target_Speed_ERPM > 0 ){       //  condition A
        if( bldc_ctrl->Speed_Diff > 0 ){    // needs to add speed
            calculate_Acc ( bldc_ctrl );
            if( bldc_ctrl->Current_Target_Speed_ERPM + bldc_ctrl->Accelerate < bldc_ctrl->Target_Speed_ERPM ){
                bldc_ctrl->Current_Target_Speed_ERPM += bldc_ctrl->Accelerate;
                bldc_ctrl->AccDec_Rest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest ) % ( acc_time );
            }else{
                bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
                bldc_ctrl->AccDec_Rest = 0;
            }
        }else if( bldc_ctrl->Speed_Diff < 0 ){                  // needs to reduce speed
            calculate_Dec ( bldc_ctrl );
            if( bldc_ctrl->Current_Target_Speed_ERPM - bldc_ctrl->Decelerate > bldc_ctrl->Target_Speed_ERPM ){
                bldc_ctrl->Current_Target_Speed_ERPM -= bldc_ctrl->Decelerate;
                bldc_ctrl->AccDec_Rest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest ) % ( dec_time );
            }else{
                bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
                bldc_ctrl->AccDec_Rest = 0;
            }
        }else{
            bldc_ctrl->Accelerate = 0;
            bldc_ctrl->Decelerate = 0;
            bldc_ctrl->AccDec_StepRest = 0;
            bldc_ctrl->AccDec_Rest = 0;
        }

    }else if( bldc_ctrl->Current_Target_Speed_ERPM < 0 ){
        if( bldc_ctrl->Speed_Diff < 0 ){    // needs to add speed
            calculate_Acc ( bldc_ctrl );
            if( bldc_ctrl->Current_Target_Speed_ERPM - bldc_ctrl->Accelerate > bldc_ctrl->Target_Speed_ERPM ){
                bldc_ctrl->Current_Target_Speed_ERPM -= bldc_ctrl->Accelerate;
                bldc_ctrl->AccDec_Rest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest ) % ( acc_time );
            }else{
                bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
                bldc_ctrl->AccDec_Rest = 0;
            }
        }else if( bldc_ctrl->Speed_Diff > 0 ){                  // needs to reduce speed
            calculate_Dec ( bldc_ctrl );
            if( bldc_ctrl->Current_Target_Speed_ERPM + bldc_ctrl->Decelerate < bldc_ctrl->Target_Speed_ERPM ){
                bldc_ctrl->Current_Target_Speed_ERPM += bldc_ctrl->Decelerate;
                bldc_ctrl->AccDec_Rest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest ) % ( dec_time );
            }else{
                bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
                bldc_ctrl->AccDec_Rest = 0;
            }
        }else{
            bldc_ctrl->Accelerate = 0;
            bldc_ctrl->Decelerate = 0;
            bldc_ctrl->AccDec_StepRest = 0;
            bldc_ctrl->AccDec_Rest = 0;

        }

    }else{

        if( bldc_ctrl->Speed_Diff > 0 ){    // needs to add speed
            calculate_Acc ( bldc_ctrl );
            if( bldc_ctrl->Current_Target_Speed_ERPM + bldc_ctrl->Accelerate < bldc_ctrl->Target_Speed_ERPM ){
                bldc_ctrl->Current_Target_Speed_ERPM += bldc_ctrl->Accelerate;
                bldc_ctrl->AccDec_Rest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest ) % ( acc_time );
            }else{
                bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
                bldc_ctrl->AccDec_Rest = 0;
            }

        }else if( bldc_ctrl->Speed_Diff < 0 ){  // needs to add speed
            calculate_Acc ( bldc_ctrl );
            if( bldc_ctrl->Current_Target_Speed_ERPM - bldc_ctrl->Accelerate > bldc_ctrl->Target_Speed_ERPM ){
                bldc_ctrl->Current_Target_Speed_ERPM -= bldc_ctrl->Accelerate;
                bldc_ctrl->AccDec_Rest = ( SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest ) % ( acc_time );
            }else{
                bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
                bldc_ctrl->AccDec_Rest = 0;
            }

        }else{
            bldc_ctrl->Accelerate = 0;
            bldc_ctrl->Decelerate = 0;
            bldc_ctrl->AccDec_StepRest = 0;
            bldc_ctrl->AccDec_Rest = 0;

        }

    }

    bldc_ctrl->Current_Target_Speed_RPM = bldc_ctrl->Current_Target_Speed_ERPM / bldc_drive->Pole_Factor;

    if( bldc_ctrl->Current_Target_Speed_ERPM >= 0 ){
        bldc_ctrl->Current_Target_Speed_ERPM_Abs = bldc_ctrl->Current_Target_Speed_ERPM;
        bldc_ctrl->Current_Target_Speed_RPM_Abs = bldc_ctrl->Current_Target_Speed_RPM;
    }else {
        bldc_ctrl->Current_Target_Speed_ERPM_Abs = -bldc_ctrl->Current_Target_Speed_ERPM;
        bldc_ctrl->Current_Target_Speed_RPM_Abs = -bldc_ctrl->Current_Target_Speed_RPM;
    }
}

/*===========================================================================================
    Function Name    : calculateTargetSpeed
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void calculateTargetSpeed ( Struct_BLDC_CTRL* bldc_ctrl )
{
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;
    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;
    //int32_t acc_time = op_mode->Acc_Time;
    //int32_t dec_time = op_mode->Dec_Time;
	//int32_t dummy;
	// target duty

	bldc_ctrl->Target_Speed_RPM_Abs = op_mode->Target_RPM_Abs;
	bldc_ctrl->Target_Speed_ERPM_Abs = bldc_ctrl->Target_Speed_RPM_Abs * bldc_drive->Pole_Factor;

	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == LOW &&
        !bldc_ctrl->EForward_Flag &&
        !bldc_ctrl->EReverse_Flag ){

        bldc_ctrl->Target_Speed_RPM_Abs = 0;
        bldc_ctrl->Target_Speed_ERPM_Abs = 0;
        bldc_ctrl->Target_Speed_RPM = 0;
        bldc_ctrl->Target_Speed_ERPM = 0;

    }else if( bldc_ctrl->EForward_Flag ){

        bldc_ctrl->Target_Speed_RPM_Abs = op_mode->Digit_Speed[ op_mode->Digit_Num ];
        bldc_ctrl->Target_Speed_ERPM_Abs = bldc_ctrl->Target_Speed_RPM_Abs * bldc_drive->Pole_Factor;

        bldc_ctrl->Target_Speed_RPM = bldc_ctrl->Target_Speed_RPM_Abs;
        bldc_ctrl->Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM_Abs;

        //acc_time = bldc_ctrl->Emergency_Acc_Time;
        //dec_time = bldc_ctrl->Emergency_Dec_Time;

    }else if( bldc_ctrl->EReverse_Flag ){

        bldc_ctrl->Target_Speed_RPM_Abs = op_mode->Digit_Speed[ op_mode->Digit_Num ];
        bldc_ctrl->Target_Speed_ERPM_Abs = bldc_ctrl->Target_Speed_RPM_Abs * bldc_drive->Pole_Factor;

        bldc_ctrl->Target_Speed_RPM = -bldc_ctrl->Target_Speed_RPM_Abs;
        bldc_ctrl->Target_Speed_ERPM = -bldc_ctrl->Target_Speed_ERPM_Abs;

        //acc_time = bldc_ctrl->Emergency_Acc_Time;
        //dec_time = bldc_ctrl->Emergency_Dec_Time;

	}else{
		//bldc_ctrl->Lock2Point_Flag = NO;
		if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CW ){
			bldc_ctrl->Target_Speed_RPM = bldc_ctrl->Target_Speed_RPM_Abs;
			bldc_ctrl->Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM_Abs;
		}else{
			bldc_ctrl->Target_Speed_RPM = -bldc_ctrl->Target_Speed_RPM_Abs;
			bldc_ctrl->Target_Speed_ERPM = -bldc_ctrl->Target_Speed_ERPM_Abs;
		}

	}
	// decide acc/dec
	speed_Management ( bldc_ctrl );

#if(0)
	dummy = SPEED_CONST_MAX + bldc_ctrl->AccDec_Rest;

	bldc_ctrl->Acc = ( op_mode->Acc_Time == 0 ? SPEED_CONST_MAX : dummy / op_mode->Acc_Time );
	bldc_ctrl->Dec = ( op_mode->Dec_Time == 0 ? SPEED_CONST_MAX : dummy / op_mode->Dec_Time );

	if( bldc_ctrl->Current_Target_Speed_ERPM > 0 ){

		if( bldc_ctrl->Current_Target_Speed_ERPM + bldc_ctrl->Acc < bldc_ctrl->Target_Speed_ERPM ){
			bldc_ctrl->Current_Target_Speed_ERPM += bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % op_mode->Acc_Time;
		}else if( bldc_ctrl->Current_Target_Speed_ERPM - bldc_ctrl->Dec > bldc_ctrl->Target_Speed_ERPM ){
			bldc_ctrl->Current_Target_Speed_ERPM -= bldc_ctrl->Dec;
			if( bldc_ctrl->Current_Target_Speed_ERPM < 0 ){
				bldc_ctrl->Current_Target_Speed_ERPM = 0;
				bldc_ctrl->AccDec_Rest = 0;
			}else{
				bldc_ctrl->AccDec_Rest = dummy % op_mode->Dec_Time;
			}
		}else{
			bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
			bldc_ctrl->AccDec_Rest = 0;
		}

	}else if( bldc_ctrl->Current_Target_Speed_ERPM < 0 ){

		if( bldc_ctrl->Current_Target_Speed_ERPM - bldc_ctrl->Acc > bldc_ctrl->Target_Speed_ERPM ){
			bldc_ctrl->Current_Target_Speed_ERPM -= bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % op_mode->Acc_Time;
		}else if( bldc_ctrl->Current_Target_Speed_ERPM + bldc_ctrl->Dec < bldc_ctrl->Target_Speed_ERPM ){
			bldc_ctrl->Current_Target_Speed_ERPM += bldc_ctrl->Dec;
			if( bldc_ctrl->Current_Target_Speed_ERPM > 0 ){
				bldc_ctrl->Current_Target_Speed_ERPM = 0;
				bldc_ctrl->AccDec_Rest = 0;
			}else{
				bldc_ctrl->AccDec_Rest = dummy % op_mode->Dec_Time;
			}
		}else{
			bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
			bldc_ctrl->AccDec_Rest = 0;
		}

	}else{

		if( bldc_ctrl->Current_Target_Speed_ERPM + bldc_ctrl->Acc < bldc_ctrl->Target_Speed_ERPM ){
			bldc_ctrl->Current_Target_Speed_ERPM += bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % op_mode->Acc_Time;
		}else if( bldc_ctrl->Current_Target_Speed_ERPM - bldc_ctrl->Acc > bldc_ctrl->Target_Speed_ERPM ){
			bldc_ctrl->Current_Target_Speed_ERPM -= bldc_ctrl->Acc;
			bldc_ctrl->AccDec_Rest = dummy % op_mode->Acc_Time;
		}else{
			bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Target_Speed_ERPM;
			bldc_ctrl->AccDec_Rest = 0;
		}

	}

	bldc_ctrl->Current_Target_Speed_RPM = bldc_ctrl->Current_Target_Speed_ERPM / bldc_drive->Pole_Factor;

    if( bldc_ctrl->Current_Target_Speed_ERPM >= 0 ){
        bldc_ctrl->Current_Target_Speed_ERPM_Abs = bldc_ctrl->Current_Target_Speed_ERPM;
        bldc_ctrl->Current_Target_Speed_RPM_Abs = bldc_ctrl->Current_Target_Speed_RPM;
    }else {
        bldc_ctrl->Current_Target_Speed_ERPM_Abs = -bldc_ctrl->Current_Target_Speed_ERPM;
        bldc_ctrl->Current_Target_Speed_RPM_Abs = -bldc_ctrl->Current_Target_Speed_RPM;
    }
#endif

}

/*===========================================================================================
    Function Name    : bldcSpeedCtrl_Run
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void bldcSpeedCtrl_Run ( Struct_BLDC_CTRL *bldc_ctrl )
{
	Struct_PositionControl *position_ctrl = ( Struct_PositionControl * )&bldc_ctrl->PositionCtrl;
	Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;

	if( bldc_drive->Sensor_Type == SENSOR_TYPE_HALL ){

		il_SpeedControl_Set_Pos ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Hall_Ptr->Position );
		il_SpeedControl_Set_Speed ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Hall_Ptr->Ecycle_ERPM );
		il_SpeedControl_Set_Target_ERPM ( &position_ctrl->SpdCtrl, bldc_ctrl->Current_Target_Speed_ERPM );

		il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Current_Restraint_Step_Limit );
		//il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Ctrl_Step_Limit_Pa );

		il_SpeedControl_Set_Loop_2_MaxMin ( (Struct_SpeedControl*) &position_ctrl->SpdCtrl, bldc_drive->Period_Limit, -(bldc_drive->Period_Limit) );

		if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
            il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Ctrl_Step_Limit_Pa );
            il_PID_Set_MaxMin( (Struct_PID*)&position_ctrl->SpdCtrl.Loop_2_SpeedPID, bldc_ctrl->Torque_Limit, -bldc_ctrl->Torque_Limit );
        }else{
            il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Current_Restraint_Step_Limit );
            il_SpeedControl_Set_Loop_2_MaxMin ( (Struct_SpeedControl*) &position_ctrl->SpdCtrl, bldc_drive->Period_Limit, -(bldc_drive->Period_Limit) );
        }

		il_SpeedControl_Run ( &position_ctrl->SpdCtrl, &position_ctrl->Drive_Infor );

	}else{

	    il_SpeedControl_Set_Index ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Encoder_Ptr->Index);
		il_SpeedControl_Set_Pos ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Encoder_Ptr->Pos );

		il_EncoderPositionProcess ( (Struct_Basic_Encoder*) bldc_ctrl->Encoder_Ptr );

		position_ctrl->Drive_Infor.Pos_Delta = bldc_ctrl->Encoder_Ptr->Pos_Delta;

		il_SpeedControl_Set_Speed ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Encoder_Ptr->Inst_Speed_New );

		il_SpeedControl_Set_Target_ERPM ( &position_ctrl->SpdCtrl, bldc_ctrl->Current_Target_Speed_ERPM );

		if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
		    il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Ctrl_Step_Limit_Pa );
		    il_PID_Set_MaxMin( (Struct_PID*)&position_ctrl->SpdCtrl.Loop_2_SpeedPID, bldc_ctrl->Torque_Limit, -bldc_ctrl->Torque_Limit );
		}else{
		    il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Current_Restraint_Step_Limit );
		    il_PID_Set_MaxMin( (Struct_PID*)&position_ctrl->SpdCtrl.Loop_2_SpeedPID, bldc_drive->Period_Limit, -bldc_drive->Period_Limit );
		}

		if( bldc_ctrl->CS_CtrlSkip_Flag ){
		    bldc_ctrl->CS_CtrlSkip_Flag = NO;
		}else{
		    il_SpeedControl_Run_Advance ( &position_ctrl->SpdCtrl, &position_ctrl->Drive_Infor );
		}

#if(TEST_CTRL_IQ)
		if( position_ctrl->SpdCtrl.Output > 0 ){
		    bldc_ctrl->Target_Dir = DIR_CW;
		}else if( position_ctrl->SpdCtrl.Output < 0 ){
		    bldc_ctrl->Target_Dir = DIR_CCW;
		}
#endif

	}

}

/*===========================================================================================
    Function Name    : bldcPositionCtrl_Run
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void bldcPositionCtrl_Run ( Struct_BLDC_CTRL *bldc_ctrl )
{
#if(1)
    int32_t dummy;

	Struct_PositionControl *position_ctrl = ( Struct_PositionControl * )&bldc_ctrl->PositionCtrl;
	Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;

	if( bldc_drive->Sensor_Type == SENSOR_TYPE_HALL ){

		il_SpeedControl_Set_Pos ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Hall_Ptr->Position );
		il_SpeedControl_Set_Speed ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Hall_Ptr->Ecycle_ERPM );

		if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
            il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Ctrl_Step_Limit_Pa );
            il_PID_Set_MaxMin( (Struct_PID*)&position_ctrl->SpdCtrl.Loop_2_SpeedPID, bldc_ctrl->Torque_Limit, -bldc_ctrl->Torque_Limit );
        }else{
            il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Current_Restraint_Step_Limit );
            il_SpeedControl_Set_Loop_2_MaxMin ( (Struct_SpeedControl*) &position_ctrl->SpdCtrl, bldc_drive->Period_Limit, -(bldc_drive->Period_Limit) );
        }

		if( position_ctrl->Run2Move_Flag ){
			position_ctrl->Run2Move_Flag = NO;

            position_ctrl->Meat_Target_Flag = NO;
            position_ctrl->SpdCtrl.Target_Pos_Step_Rest = 0;

            position_ctrl->Pos_error = position_ctrl->SpdCtrl.Loop_1_Target / position_ctrl->SpdCtrl.Loop_1_Kp;
            position_ctrl->Current_Target_Pos = position_ctrl->Drive_Infor.Pos_Now + position_ctrl->Pos_error;

            //position_ctrl->Path_Spd = 6 * CG_BLDC_CTRL.Current_Target_Speed_ERPM / 60;
            position_ctrl->Path_Spd = bldc_ctrl->Current_Target_Speed_ERPM / 10;	// The effect is same as above

            int32_t distance;
            distance = ( position_ctrl->Target_Index - position_ctrl->Current_Target_Index ) * position_ctrl->MaxPos + ( position_ctrl->Target_Pos - position_ctrl->Current_Target_Pos );
            position_ctrl->distance_abs = ( distance >= 0 ? distance : -distance );


		}else{

			il_PositionControl_Run ( position_ctrl );
			bldc_ctrl->Target_ToUpdate_BITF |= ( 1UL << TOUPDATE_BIFT_POSITION_HALL );

			//il_PositionControl_Set_Path_Spd_Limit ( position_ctrl, bldc_ctrl->OpMode_Ptr->Digit_RPM_Abs * position_ctrl->MaxPos / 60 );
			//il_PositionControl_Set_Path_AccDEC ( position_ctrl, bldc_ctrl->OpMode_Ptr->Acc_Time, bldc_ctrl->OpMode_Ptr->Dec_Time );
			//il_PositionControl_PathRun ( position_ctrl );

		}

	}else{

	    il_SpeedControl_Set_Index ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Encoder_Ptr->Index);
		il_SpeedControl_Set_Pos ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Encoder_Ptr->Pos);

		il_EncoderPositionProcess ( (Struct_Basic_Encoder*) bldc_ctrl->Encoder_Ptr );

		il_SpeedControl_Set_Speed ( ( Struct_DriverMotorInfor* ) &position_ctrl->Drive_Infor, bldc_ctrl->Encoder_Ptr->Inst_Speed_New );

		if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
		    il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Ctrl_Step_Limit_Pa );
            il_PID_Set_MaxMin( (Struct_PID*)&position_ctrl->SpdCtrl.Loop_2_SpeedPID, bldc_ctrl->Torque_Limit, -bldc_ctrl->Torque_Limit );
        }else{
            il_SpeedControl_Set_Loop_2_StepLimit ( &position_ctrl->SpdCtrl, bldc_ctrl->Current_Restraint_Step_Limit );
            il_PID_Set_MaxMin( (Struct_PID*)&position_ctrl->SpdCtrl.Loop_2_SpeedPID, bldc_drive->Period_Limit, -bldc_drive->Period_Limit );
        }

		//
		//il_PositionControl_Set_Path_Spd_Limit ( position_ctrl, bldc_ctrl->OpMode_Ptr->Digit_RPM_Abs * position_ctrl->MaxPos / 60 );
		//il_PositionControl_Set_Path_AccDEC ( position_ctrl, bldc_ctrl->OpMode_Ptr->Acc_Time, bldc_ctrl->OpMode_Ptr->Dec_Time );
		//

		if( position_ctrl->Run2Move_Flag ){
			position_ctrl->Run2Move_Flag = NO;


            position_ctrl->Meat_Target_Flag = NO;
            position_ctrl->SpdCtrl.Target_Pos_Step_Rest = 0;

            position_ctrl->Pos_error = position_ctrl->SpdCtrl.Loop_1_Target * SPDCTRL_LOOP_1_KP_SCALE_CONST / position_ctrl->SpdCtrl.Loop_1_Kp;

            position_ctrl->Current_Target_Index = position_ctrl->Drive_Infor.Index_Now;
            position_ctrl->Current_Target_Pos = position_ctrl->Drive_Infor.Pos_Now + position_ctrl->Pos_error;

            dummy = position_ctrl->Current_Target_Pos / position_ctrl->MaxPos;
            position_ctrl->Current_Target_Index = position_ctrl->Current_Target_Index + dummy;
            position_ctrl->Current_Target_Pos = position_ctrl->Current_Target_Pos - dummy * position_ctrl->MaxPos;

            if( position_ctrl->Current_Target_Pos >= position_ctrl->MaxPos ){
                position_ctrl->Current_Target_Index++;
                position_ctrl->Current_Target_Pos -= position_ctrl->MaxPos;
            }else if( position_ctrl->Current_Target_Pos < 0 ){
                position_ctrl->Current_Target_Index--;
                position_ctrl->Current_Target_Pos += position_ctrl->MaxPos;
            }

            position_ctrl->Path_Spd = position_ctrl->MaxPos * bldc_ctrl->Current_Target_Speed_ERPM / ( bldc_drive->Pole_Factor * 60 );

            int32_t distance;
            distance = ( position_ctrl->Target_Index - position_ctrl->Current_Target_Index ) * position_ctrl->MaxPos + ( position_ctrl->Target_Pos - position_ctrl->Current_Target_Pos );
            position_ctrl->distance_abs = ( distance >= 0 ? distance : -distance );

            bldc_ctrl->Target_ToUpdate_BITF |= ( 1UL << TOUPDATE_BIFT_POSITION_ENCODER );

		}else{

			il_PositionControl_Run_Advance( position_ctrl, YES );
			bldc_ctrl->Target_ToUpdate_BITF |= ( 1UL << TOUPDATE_BIFT_POSITION_ENCODER );

			//il_PositionControl_Set_Path_Spd_Limit ( position_ctrl, bldc_ctrl->OpMode_Ptr->Digit_RPM_Abs * position_ctrl->MaxPos / 60 );
			//il_PositionControl_Set_Path_AccDEC ( position_ctrl, bldc_ctrl->OpMode_Ptr->Acc_Time, bldc_ctrl->OpMode_Ptr->Dec_Time );
			//il_PositionControl_PathRun_Advance ( position_ctrl, YES );

		}

		//
		//il_PositionControl_Run ( position_ctrl );
#if(TEST_CTRL_IQ)
		if( position_ctrl->SpdCtrl.Output > 0 ){
		    bldc_ctrl->Target_Dir = DIR_CW;
		}else if( position_ctrl->SpdCtrl.Output < 0 ){
		    bldc_ctrl->Target_Dir = DIR_CCW;
		}
#endif


	}
#endif

}


/*===========================================================================================
    Function Name    : rtCtrl_MotorRun
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void rtCtrl_MotorRun( Struct_BLDC_CTRL *bldc_ctrl )
{	
#if(1)
	int32_t dummy_limit;
	Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;

	if( bldc_ctrl->InstStop_CMD == YES  ){
		management_BrakePWMDuty( bldc_ctrl );
	}else{
		switch( bldc_ctrl->Control_Mode ){
			case CTRL_OPENLOOP:

				if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
					calculateTargetDuty( bldc_ctrl );
					dummy_limit = ( bldc_ctrl->Current_Duty_Abs * CONST_SQRT3_OVER_3 ) >> CONST_1_BIT_NUM;
					il_PID_Set_MaxMin( (Struct_PID*)&bldc_drive->FOC.Iq_Controller, dummy_limit, -dummy_limit );
				}else{
					if( bldc_ctrl->Current_Restraint_Flag == YES ){
						reduceDuty( ( int32_t* )&bldc_ctrl->Current_Duty, bldc_ctrl->Current_Restraint_Step );
						// duty output
						if( bldc_ctrl->Current_Duty >= 0 ){
						    bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
						}else{
						    bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty * (-1);
						}

					}else{
					    calculateTargetDuty( bldc_ctrl );
					}

					if( bldc_drive->Mode != BLDCDRIVE_FOC ){
                        bldc_drive->Duty_Out( bldc_ctrl->Current_Duty_Abs,
                                              bldc_ctrl->Current_Duty_Abs,
                                              bldc_ctrl->Current_Duty_Abs );
					}

				}

				break;
			case CTRL_CLOSELOOP_PID:
			default:

				//CG_MD.Test_tp1			= FREE_RUN_TIMER.TIM.all;
				//calculateTargetSpeed( bldc_ctrl );
			    bldc_ctrl->Target_ToUpdate_BITF |= ( 1UL << TOUPDATE_BIFT_SPEED );
				//CG_MD.Test_tp2			= FREE_RUN_TIMER.TIM.all;
				//CG_MD.Test_time 		= CG_MD.Test_tp1 - CG_MD.Test_tp2;	// 380 clk ticks

				if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
					
					bldcSpeedCtrl_Run( bldc_ctrl );
					
				}else{
				    /*
					if( bldc_ctrl->Current_Restraint_Flag == YES ){
						reduceDuty( ( int32_t* )&bldc_ctrl->PositionCtrl.SpdCtrl.Output, bldc_ctrl->Current_Restraint_Step );
					}else{
						//CG_MD.Test_tp1			= FREE_RUN_TIMER.TIM.all;
						bldcSpeedCtrl_Run( bldc_ctrl );
						//CG_MD.Test_tp2			= FREE_RUN_TIMER.TIM.all;
						//CG_MD.Test_time 		= CG_MD.Test_tp1 - CG_MD.Test_tp2;	// 851 clk ticks
					}*/
				    //CG_MD.Test_tp1            = FREE_RUN_TIMER.TIM.all;
                    bldcSpeedCtrl_Run( bldc_ctrl );
                    //CG_MD.Test_tp2            = FREE_RUN_TIMER.TIM.all;
                    //CG_MD.Test_time       = CG_MD.Test_tp1 - CG_MD.Test_tp2;  // 851 clk ticks
                    if( bldc_ctrl->Current_Restraint_Flag == YES ){
                        reduceDuty( ( int32_t* )&bldc_ctrl->PositionCtrl.SpdCtrl.Output, bldc_ctrl->Current_Restraint_Step );
                    }

					#if( !TEST_CTRL_BUSV_USED )
					bldc_ctrl->Current_Duty = (int16_t)bldc_ctrl->PositionCtrl.SpdCtrl.Output;

					if( bldc_ctrl->Current_Duty > 0 ){
						bldc_ctrl->Target_Dir = DIR_CW;
						bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
					}else if( bldc_ctrl->Current_Duty < 0 ){
						bldc_ctrl->Target_Dir = DIR_CCW;
						bldc_ctrl->Current_Duty_Abs = -bldc_ctrl->Current_Duty;
					}else{
						bldc_ctrl->Current_Duty_Abs = 0;
					}

					if( bldc_drive->Mode != BLDCDRIVE_FOC ){
                        bldc_drive->Duty_Out( bldc_ctrl->Current_Duty_Abs,
                                              bldc_ctrl->Current_Duty_Abs,
                                              bldc_ctrl->Current_Duty_Abs );
					}

                    #endif

				}

				break;
		}
	
		
	}
#endif
}

/*===========================================================================================
    Function Name    : rtCtrl_MotorMove
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void rtCtrl_MotorMove( Struct_BLDC_CTRL *bldc_ctrl )
{
#if(1)
    //int32_t dummy_limit;
    Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;

    //if( bldc_ctrl->InstStop_CMD == YES  ){
        //management_BrakePWMDuty( bldc_ctrl );
    //}else{

        if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
            bldcPositionCtrl_Run( bldc_ctrl );
        }else{

            /*
            if( bldc_ctrl->Current_Restraint_Flag == YES ){
                reduceDuty( ( int32_t* )&bldc_ctrl->PositionCtrl.SpdCtrl.Output, bldc_ctrl->Current_Restraint_Step );
            }else{
                bldcPositionCtrl_Run( bldc_ctrl );
            }*/

            bldcPositionCtrl_Run( bldc_ctrl );
            if( bldc_ctrl->Current_Restraint_Flag == YES ){
                reduceDuty( ( int32_t* )&bldc_ctrl->PositionCtrl.SpdCtrl.Output, bldc_ctrl->Current_Restraint_Step );
            }

            #if( !TEST_CTRL_BUSV_USED )
            bldc_ctrl->Current_Duty = (int16_t)bldc_ctrl->PositionCtrl.SpdCtrl.Output;

            if( bldc_ctrl->Current_Duty > 0 ){
                bldc_ctrl->Target_Dir = DIR_CW;
                bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
            }else if( bldc_ctrl->Current_Duty < 0 ){
                bldc_ctrl->Target_Dir = DIR_CCW;
                bldc_ctrl->Current_Duty_Abs = -bldc_ctrl->Current_Duty;
            }else{
                bldc_ctrl->Current_Duty_Abs = 0;
            }
            if( bldc_drive->Mode != BLDCDRIVE_FOC ){
                if( bldc_drive->Mode != BLDCDRIVE_FOC ){
                    bldc_drive->Duty_Out( bldc_ctrl->Current_Duty_Abs,
                                          bldc_ctrl->Current_Duty_Abs,
                                          bldc_ctrl->Current_Duty_Abs );
                }
            }
            #endif

        }

    //}
#endif
}

/*===========================================================================================
    Function Name    : management_BrakePWMDuty
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void management_BrakePWMDuty( Struct_BLDC_CTRL *bldc_ctrl )
{	
#if(1)
	int32_t dummy;
	Struct_BLDC_Drive *bldc_drive = bldc_ctrl->Drive_Ptr;


	if( bldc_drive->EBrake_Flag == NO ){

		bldc_ctrl->Target_Duty = bldc_drive->Period_Limit_Brake;
		bldc_ctrl->Current_Duty = bldc_drive->Period_Limit;

		bldc_ctrl->Target_Duty_Abs = bldc_ctrl->Target_Duty;
		bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;

		bldc_ctrl->Stop_Delay_Cnt = 0;
		bldc_ctrl->AccDec_Rest = 0;

		if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
        }

		bldc_drive->Commutation_Out( 'C' );

		bldc_drive->Duty_Out( bldc_ctrl->Current_Duty_Abs,
		                      bldc_ctrl->Current_Duty_Abs,
		                      bldc_ctrl->Current_Duty_Abs );

		bldc_drive->Commutation_Out( 'B' );

	}else{


		dummy = bldc_drive->Duty_Max_Abs + bldc_ctrl->AccDec_Rest;
		bldc_ctrl->Dec = ( 	bldc_ctrl->Emergency_Dec_Time == 0 ? bldc_drive->Duty_Max_Abs: dummy / bldc_ctrl->Emergency_Dec_Time );

		if( bldc_ctrl->Current_Duty <= bldc_ctrl->Target_Duty ){
			if( bldc_ctrl->Current_Duty + bldc_ctrl->Dec < bldc_ctrl->Target_Duty ){
				bldc_ctrl->Current_Duty += bldc_ctrl->Dec;
				bldc_ctrl->AccDec_Rest = dummy % bldc_ctrl->Emergency_Dec_Time;
			}else{
				bldc_ctrl->Current_Duty = bldc_ctrl->Target_Duty;
				bldc_ctrl->AccDec_Rest = 0;
			}
		}else{
			if( bldc_ctrl->Current_Duty - bldc_ctrl->Dec > bldc_ctrl->Target_Duty ){
				bldc_ctrl->Current_Duty -= bldc_ctrl->Dec;
				bldc_ctrl->AccDec_Rest = dummy % bldc_ctrl->Emergency_Dec_Time;
			}else{
				bldc_ctrl->Current_Duty = bldc_ctrl->Target_Duty;
				bldc_ctrl->AccDec_Rest = 0;
			}
		}

		// duty output
		if( bldc_ctrl->Current_Duty >= 0 ){
			bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
		}else{
			bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty * (-1);
		}

		bldc_drive->Duty_Out( bldc_ctrl->Current_Duty_Abs,
		                      bldc_ctrl->Current_Duty_Abs,
		                      bldc_ctrl->Current_Duty_Abs );

	}
#endif

}

/*===========================================================================================
    Function Name    : motor_Stop
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Stop Routine
//==========================================================================================*/
void motor_Stop ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)

    bldc_ctrl->AlarmLED_State = HIGH;


    bldc_ctrl->Target_Speed_RPM = 0;
    bldc_ctrl->Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Target_Speed_ERPM = 0;
    bldc_ctrl->Target_Speed_ERPM_Abs = 0;
	
    bldc_ctrl->Current_Target_Speed_RPM = 0;
    bldc_ctrl->Current_Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Current_Target_Speed_ERPM = 0;
    bldc_ctrl->Current_Target_Speed_ERPM_Abs = 0;

    //output_EnableOUT ( bldc_ctrl );
	velocityArrive( bldc_ctrl );
	velocityArrive2( bldc_ctrl );
	velocityArrive_EN( bldc_ctrl );
	
	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
	OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
				   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();


	if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
	    DINT;
        bldc_ctrl->Drive_Ptr->SineWaveToStep();
        EINT;
	}

	if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        EINT;
    }

	if( bldc_ctrl->MotorStop_Behavior == MOTOR_STOP_BEHAVIOR_FREE ){
	    bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
	    DINT;
	    bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
	    EINT;
	}else if( bldc_ctrl->MotorStop_Behavior == MOTOR_STOP_BEHAVIOR_BRAKE ){
	    bldc_ctrl->Drive_Ptr->Duty_Out( bldc_ctrl->Drive_Ptr->Period_Limit_Brake,
	                                    bldc_ctrl->Drive_Ptr->Period_Limit_Brake,
	                                    bldc_ctrl->Drive_Ptr->Period_Limit_Brake  );

		if( bldc_ctrl->Drive_Ptr->EBrake_Flag == NO ){

		    DINT;
            bldc_ctrl->Drive_Ptr->Commutation_Out( 'B' );
            EINT;
		}

	}else if( bldc_ctrl->MotorStop_Behavior == MOTOR_STOP_BEHAVIOR_LOCK &&
	          bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL){
	    resetReg_SPK( bldc_ctrl->SPK_Ptr );
	    bldc_ctrl->Motor_State = MOTOR_STATE_LOCK;
	}

#define	E_FORWARD_STATE ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_EFORWARD) )
#define E_REVERSE_STATE	( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_EREVERSE) )

#define E_FORWARD_REVERSE_CONDITION  ( bldc_ctrl->E_ForwardReverse_Enable == NO || ( bldc_ctrl->E_Lock_Flag == NO && E_FORWARD_STATE == 0 && E_FORWARD_STATE == 0 ) )


	if( ( RUN_CONDITION_1 || RUN_CONDITION_2 || SERVO_ON_CONDITION ) &&
		CG_MD.Relay_On_Cnt > RELAY_ON_DELAY_TIME &&
		E_FORWARD_REVERSE_CONDITION  ){
		
		if( bldc_ctrl->Protect_Ptr->first_fault == FAULT_STATE_NO_FAULT ){
		    bldc_ctrl->Motor_State = MOTOR_STATE_STARTING;
		    bldc_ctrl->Restart_Cnt = 0;

		    DINT;
            bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
            EINT;
            bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
		}
			
	}

	if( bldc_ctrl->CS_Flag ){
	    bldc_ctrl->CS_Flag = NO;
	    mcCS ( bldc_ctrl );
	}
			
	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_EBRAKE ] == HIGH ){
	    bldc_ctrl->Motor_State = MOTOR_STATE_EBRAKING;
		
	    bldc_ctrl->Ctrl_Updated = NO;

		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

		DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
	}
	
	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ] == HIGH ){
	    bldc_ctrl->Motor_State = MOTOR_STATE_FREEING;
		
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

		DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
		
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
		
	}
	
	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 &&
	    bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0  ){

	    bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;
	    DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
	}

	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

	    bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

    if( bldc_ctrl->Motor_State == MOTOR_STATE_LOCK ){
        DINT;
        bldc_ctrl->Current_Duty_Abs = 0;
        bldc_ctrl->Current_Duty = 0;
        bldc_ctrl->SPK_Ptr->Start();
        EINT;
    }

	bldc_ctrl->Running_Flag = NO;

#endif

}

/*===========================================================================================
    Function Name    : motor_Starting
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Starting Routine
//==========================================================================================*/
void motor_Starting ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)

    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) );

    bldc_ctrl->Running_Flag = YES;

    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
	OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
				   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();

	bldc_ctrl->Drive_Ptr->Commutation_Enable = YES;
	
	
	DINT;
    bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );

    bldc_ctrl->Target_ToUpdate_BITF = 0;
    bldc_ctrl->Target_Duty = 0;
    bldc_ctrl->InstStop_CMD = NO;
    bldc_ctrl->AccDec_Rest = 0;
	//bldc_ctrl->Torque_Limit_Acc_Rest = 0;
    bldc_ctrl->Current_Restraint_Flag = NO;
    bldc_ctrl->RealTimeCtrl_Cnt = 0;
    bldc_ctrl->RealTimeCtrl_Const = bldc_ctrl->Drive_Ptr->Frequency / CTRL_FREQ_HZ;
    bldc_ctrl->IMR_Flag = NO;

    bldc_ctrl->CS_CtrlSkip_Flag = NO;

    // bldc_ctrl->LockTimer = 0;
    variableReset_S_Curve( bldc_ctrl );

    variableReset_HallSensor ( bldc_ctrl->Hall_Ptr );

	if( bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL ){
	    hall_Reset_Stall_Timer( bldc_ctrl->Hall_Ptr );

		il_SpeedControl_Set_Pos ( ( Struct_DriverMotorInfor* ) &bldc_ctrl->PositionCtrl.Drive_Infor, bldc_ctrl->Hall_Ptr->Position );
		il_PositionControl_Set_Current_Target_Pos ( ( Struct_PositionControl* ) &bldc_ctrl->PositionCtrl, bldc_ctrl->Hall_Ptr->Position );
		il_PositionControl_Set_Target_Pos ( ( Struct_PositionControl* ) &bldc_ctrl->PositionCtrl, bldc_ctrl->Hall_Ptr->Position );

	}else{
	    encoder_Reset_Stall_Timer( bldc_ctrl->Encoder_Ptr );

	    il_SpeedControl_Set_Index ( ( Struct_DriverMotorInfor* ) &bldc_ctrl->PositionCtrl.Drive_Infor, bldc_ctrl->Encoder_Ptr->Index);
		il_SpeedControl_Set_Pos ( ( Struct_DriverMotorInfor* ) &bldc_ctrl->PositionCtrl.Drive_Infor, bldc_ctrl->Encoder_Ptr->Pos );

		il_PositionControl_Set_Current_Target_Index ( ( Struct_PositionControl* ) &bldc_ctrl->PositionCtrl, bldc_ctrl->Encoder_Ptr->Index );
		il_PositionControl_Set_Current_Target_Pos ( ( Struct_PositionControl* ) &bldc_ctrl->PositionCtrl, bldc_ctrl->Encoder_Ptr->Pos );

		il_PositionControl_Set_Target_Index ( ( Struct_PositionControl* ) &bldc_ctrl->PositionCtrl, bldc_ctrl->Encoder_Ptr->Index );
		il_PositionControl_Set_Target_Pos ( ( Struct_PositionControl* ) &bldc_ctrl->PositionCtrl, bldc_ctrl->Encoder_Ptr->Pos );

		il_EncoderPositionProcess ( (Struct_Basic_Encoder*) bldc_ctrl->Encoder_Ptr );

	}

	resetReg_PositionControl ( (Struct_PositionControl*) &bldc_ctrl->PositionCtrl );

	EINT;   // Enable Global interrupt INTM

	//DINT;

#if(0)
	

	setupInitial_PID ( ( Struct_PID* ) &CG_BLDC_CTRL.SpeedPID );

	moveResetCtrlLoop();
	moveInitMotionData();

	CG_BLDC_CTRL.Torque_Limit = 900;////SHUNT_I_HWP;
	CG_BLDC_CTRL.Torque_Traj = CG_BLDC_CTRL.Torque_Limit;
	CG_BLDC_CTRL.Torque_Step_Rest = 0;

	CG_BLDC_CTRL.Lock2Point_Flag = NO;
	CG_BLDC_CTRL.LockTimer = 0;

#endif
	
	//CG_BLDC_CTRL.BusVRef_ADC = CTRL_REF_BUSV_VOLTAGE * ADC_MAX_VALUE / BUSV_PHYSIC_MAX;
	bldc_ctrl->Stall_Timer = 0;
    bldc_ctrl->Current_Duty_Abs = 0;
    bldc_ctrl->Current_Duty = 0;
    bldc_ctrl->Target_Dir = bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_DIR ];
    bldc_ctrl->Target_Dir_CMD = bldc_ctrl->Target_Dir;
    bldc_ctrl->Delta_Angle_Rest = 0;
    bldc_ctrl->Adjust_Angle = 30;

	if( bldc_ctrl->Drive_Ptr->Mode == BLDCDRIVE_FOC ){

#if(TEST_CTRL_IQ)
	    if( bldc_ctrl->Control_Mode == CTRL_OPENLOOP && bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
	        il_PID_Set_MaxMin( (Struct_PID*)&bldc_ctrl->Drive_Ptr->FOC.Iq_Controller, 0, 0 );
	    }else{
			int32_t dummy_limit = ( ( bldc_ctrl->Drive_Ptr->Period_Limit ) * CONST_SQRT3_OVER_3 ) >> CONST_1_BIT_NUM;
			il_PID_Set_MaxMin( (Struct_PID*)&bldc_ctrl->Drive_Ptr->FOC.Iq_Controller, dummy_limit, -dummy_limit );
		}
		management_TorqueLimit_FOCDrive( bldc_ctrl );
#endif

		setupInitial_PID ( ( Struct_PID* ) &bldc_ctrl->Drive_Ptr->FOC.Id_Controller );
		setupInitial_PID ( ( Struct_PID* ) &bldc_ctrl->Drive_Ptr->FOC.Iq_Controller );
		DINT;
		bldc_ctrl->Drive_Ptr->StepToSineWave();
		EINT;   // Enable Global interrupt INTM
	}else{

		if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
		    DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
		}

		bldc_ctrl->Drive_Ptr->Duty_Out( 0,
		                                0,
		                                0 );

		bldc_ctrl->Commutation = bldc_ctrl->Drive_Ptr->Commutation_Table[ bldc_ctrl->Target_Dir ][ bldc_ctrl->Hall_Ptr->Current_State ];
		
		DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

	}

	if( RUN_CONDITION_2 || SERVO_ON_CONDITION ){
	    bldc_ctrl->Motor_State = MOTOR_STATE_MOVE;
	}else{
	    bldc_ctrl->Motor_State = MOTOR_STATE_RUNNING;
	}

	//EINT;   // Enable Global interrupt INTM
#endif

}

/*===========================================================================================
    Function Name    : motor_Running
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Running Routine
//==========================================================================================*/
void motor_Running ( Struct_BLDC_CTRL* bldc_ctrl )
{
	//int32_t buffer;
	//int32_t index;
	//int32_t pos;
	//int32_t lock_point;
	//int32_t offset;
    uint8_t is_imr_cmd = ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_IMR)) != 0 );
    uint8_t is_cma_cmd = ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_CMA)) != 0 );
    uint8_t is_cmr_cmd = ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_CMR)) != 0 );

    bldc_ctrl->Running_Flag = YES;

    //output_EnableOUT ( bldc_ctrl );
    velocityArrive( bldc_ctrl );
    velocityArrive2( bldc_ctrl );
    velocityArrive_EN( bldc_ctrl );

    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();


	// Stop Mode
	#define INST_STOP_CONDITION_1	( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == LOW && ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_STOP_MODE) ) != 0 )
	#define INST_STOP_CONDITION_1_INDEX		1
	// E brake
	//#define INST_STOP_CONDITION_2   ( CMD_STATE_EBRAKE == HIGH )
	//#define INST_STOP_CONDITION_2_INDEX		2

	if( INST_STOP_CONDITION_1 ){
	    bldc_ctrl->InstStop_CMD = YES;
	    /*
	    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
	        DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }*/
	}

	if( bldc_ctrl->Ctrl_Updated == NO ){
	    bldc_ctrl->Ctrl_Updated  = YES;

		if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
			management_TorqueLimit_FOCDrive( bldc_ctrl );
		}else{
			management_TorqueLimit_StepDrive( bldc_ctrl );
		}

		//management_TorqueLimit_StepDrive();

		//management_PWMDuty( CG_BLDC_CTRL.Control_Mode );
	}


	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == LOW ||
	    bldc_ctrl->InstStop_CMD == YES ){

		#define STOP_HOLD_CONDITION			( bldc_ctrl->Stop_Delay_Cnt >= bldc_ctrl->Stop_Delay_Time )
        #define LOW_SPEED_CONDITION         ( bldc_ctrl->Current_RPM_Abs < CONST_LOW_SPEED )
		#define STOP_CONDITION_CLOSELOOP	( LOW_SPEED_CONDITION || STOP_HOLD_CONDITION )
		#define STOP_CONDITION_OPENLOOP		( ( bldc_ctrl->Drive_Ptr->Motor_Type == MOTOR_BDC && STOP_HOLD_CONDITION ) || ( bldc_ctrl->Drive_Ptr->Motor_Type == MOTOR_BLDC && STOP_CONDITION_CLOSELOOP ) )

		switch( bldc_ctrl->Control_Mode ){
			case CTRL_OPENLOOP:
				if( ( bldc_ctrl->InstStop_CMD == NO  && bldc_ctrl->Current_Duty_Abs <= bldc_ctrl->Drive_Ptr->Duty_Min_Abs && STOP_HOLD_CONDITION ) ||
					( ( bldc_ctrl->InstStop_CMD == YES && bldc_ctrl->Drive_Ptr->EBrake_Flag == YES ) && bldc_ctrl->Current_Duty == bldc_ctrl->Target_Duty && STOP_CONDITION_OPENLOOP )  ){
					
				    bldc_ctrl->Motor_State = MOTOR_STATE_STOP;

				    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
				        DINT;
                        bldc_ctrl->Drive_Ptr->SineWaveToStep();
                        EINT;
                    }

                    DINT;
                    bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
                    EINT;
					
				}			
				break;
			case CTRL_CLOSELOOP_PID:
			case CTRL_POSITION:

			    if( ( bldc_ctrl->InstStop_CMD == NO  && LOW_SPEED_CONDITION ) ||
                    ( ( bldc_ctrl->InstStop_CMD == YES && bldc_ctrl->Drive_Ptr->EBrake_Flag == YES ) && bldc_ctrl->Current_Duty == bldc_ctrl->Target_Duty && STOP_CONDITION_CLOSELOOP )  ){

			        bldc_ctrl->Motor_State = MOTOR_STATE_STOP;

			        bldc_ctrl->Ctrl_Updated = NO;

			        if( !is_imr_cmd &&  // No IMR, No CMA and No CMR CMD
                        !is_cma_cmd &&  // Meet IMR, CMA or CMR CMD means no needs to turn off PWM
                        !is_cmr_cmd ){

                        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
                            DINT;
                            bldc_ctrl->Drive_Ptr->SineWaveToStep();
                            EINT;
                        }

                        DINT;
                        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
                        EINT;
			        }
                }

				break;
			default:
				break;			
		}
		
	}

    if( bldc_ctrl->CS_Flag ){
        bldc_ctrl->CS_Flag = NO;
        mcCS ( bldc_ctrl );
    }
		
	if( is_imr_cmd ){
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
		mcIMR( bldc_ctrl);
		bldc_ctrl->PositionCtrl.Run2Move_Flag = YES;
		bldc_ctrl->Motor_State = MOTOR_STATE_MOVE;
	}
	
    if( is_cma_cmd ){
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );
        mcCMA( bldc_ctrl );
        bldc_ctrl->PositionCtrl.Run2Move_Flag = YES;
        bldc_ctrl->Motor_State = MOTOR_STATE_MOVE;
    }

    if( is_cmr_cmd ){
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
        mcCMR_AtRun( bldc_ctrl );
        bldc_ctrl->PositionCtrl.Run2Move_Flag = YES;
        bldc_ctrl->Motor_State = MOTOR_STATE_MOVE;
    }

    //

    if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH ){
        bldc_ctrl->Target_Dir_CMD = bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_DIR ];
    }

    if( bldc_ctrl->E_ForwardReverse_Enable ){

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_EFORWARD) ) != 0 ||
            ( bldc_ctrl->EForward_State == YES && bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH  )  ){
            bldc_ctrl->EForward_State = YES;
        }else{
            bldc_ctrl->EForward_State = NO;
            bldc_ctrl->EForward_Flag = NO;
        }

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_EREVERSE) ) != 0 ||
            ( bldc_ctrl->EReverse_State == YES && bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH  )  ){
            bldc_ctrl->EReverse_State = YES;
        }else{
            bldc_ctrl->EReverse_State = NO;
            bldc_ctrl->EReverse_Flag = NO;
        }

        if( bldc_ctrl->EForward_State == YES &&
            bldc_ctrl->Target_Dir_CMD == DIR_CCW &&
            bldc_ctrl->E_Lock_Flag == NO ){

            bldc_ctrl->EForward_Flag = YES;
            bldc_ctrl->EReverse_Flag = NO;
            bldc_ctrl->E_Lock_Flag = YES;

        }else if( bldc_ctrl->EReverse_State == YES &&
                  bldc_ctrl->Target_Dir_CMD == DIR_CW &&
                  bldc_ctrl->E_Lock_Flag == NO ){

            bldc_ctrl->EForward_Flag = NO;
            bldc_ctrl->EReverse_Flag = YES;
            bldc_ctrl->E_Lock_Flag = YES;

        }

    }

    //

	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_EBRAKE ]  == HIGH ){
	    bldc_ctrl->Motor_State = MOTOR_STATE_EBRAKING;

	    bldc_ctrl->Ctrl_Updated = NO;

		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

		if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
		    DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }

		DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
	}

	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ]  == HIGH ){
	    bldc_ctrl->Motor_State = MOTOR_STATE_FREEING;
		
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

		if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
		    DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }

		DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
		
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

	}

	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 &&
	    bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0  ){

	    if( bldc_ctrl->ServoOff_Delay_TimerMs >= bldc_ctrl->ServoOff_Delay_TimeMs_Pa ){

            if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
                DINT;
                bldc_ctrl->Drive_Ptr->SineWaveToStep();
                EINT;
            }

            bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;
            DINT;
            bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
            EINT;

            bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
	    }
	}

	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

	    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }

        bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

}

/*===========================================================================================
    Function Name    : motor_Moving
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Moving Routine
//==========================================================================================*/
void motor_Moving ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
	//int32_t buffer;
	//int32_t index;
	//int32_t pos;

    if( bldc_ctrl->Current_RPM_Abs > CONST_LOW_SPEED ){
        bldc_ctrl->Running_Flag = YES;
    }else{
        bldc_ctrl->Running_Flag = NO;
    }

    //output_EnableOUT ( bldc_ctrl );
    velocityArrive( bldc_ctrl );
    velocityArrive2( bldc_ctrl );
    velocityArrive_EN( bldc_ctrl );

    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();

    /*
    if( INST_STOP_CONDITION_1 ){
        bldc_ctrl->InstStop_CMD = YES;

        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }
    }*/

    //
    if( bldc_ctrl->Drive_Ptr->Mode == BLDCDRIVE_FOC ){
        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == NO ){
            DINT;
            bldc_ctrl->Drive_Ptr->StepToSineWave();
            EINT;   // Enable Global interrupt INTM
        }
    }
    //

    if( bldc_ctrl->Ctrl_Updated == NO ){
        bldc_ctrl->Ctrl_Updated  = YES;

        if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
            management_TorqueLimit_FOCDrive( bldc_ctrl );
        }else{
            management_TorqueLimit_StepDrive( bldc_ctrl );
        }

        //management_TorqueLimit_StepDrive();

        //management_PWMDuty( CG_BLDC_CTRL.Control_Mode );
    }


    if( bldc_ctrl->Control_Mode == CTRL_POSITION ){

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_MR)) != 0 ){
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
            mcCMR( bldc_ctrl);
        }

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_MA)) != 0 ){
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
            mcCMA( bldc_ctrl);
        }

        if( bldc_ctrl->CS_Flag ){
            bldc_ctrl->CS_Flag = NO;
            mcCS ( bldc_ctrl );
        }

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_IMR)) != 0 ){
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
            mcIMR( bldc_ctrl);
        }

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_CMA)) != 0 ){
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );
            mcCMA( bldc_ctrl );
        }

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_CMR)) != 0 ){
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
            mcCMR( bldc_ctrl );
        }

        if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH ){
            variableReset_S_Curve( bldc_ctrl );
            bldc_ctrl->Motor_State = MOTOR_STATE_RUNNING;
        }

        if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_STOP)) != 0 ){
            if( bldc_ctrl->Current_Target_Speed_RPM_Abs != 0 ){
                variableReset_S_Curve( bldc_ctrl );
                bldc_ctrl->Motor_State = MOTOR_STATE_RUNNING;
            }
        }

    }else{

        if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH ){
            variableReset_S_Curve( bldc_ctrl );
            bldc_ctrl->Motor_State = MOTOR_STATE_RUNNING;
        }

        if( bldc_ctrl->MotorStop_Behavior != MOTOR_STOP_BEHAVIOR_LOCK ||
            bldc_ctrl->Control_Mode == CTRL_OPENLOOP   ){
            bldc_ctrl->Motor_State = MOTOR_STATE_STOP;
        }

    }


	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_EBRAKE ]  == HIGH ){
        bldc_ctrl->Motor_State = MOTOR_STATE_EBRAKING;

        bldc_ctrl->Ctrl_Updated = NO;

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }

        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
    }

    if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ]  == HIGH ){
        bldc_ctrl->Motor_State = MOTOR_STATE_FREEING;

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }

        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 &&
        bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0  ){

        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }

        bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
    }

    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

        if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            DINT;
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
            EINT;
        }

        bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

#endif

}
/*===========================================================================================
    Function Name    : motor_Lock
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Andrew.An@trumman.com.tw
    Description      : Motor Hall Lock function
//==========================================================================================*/
void motor_Lock ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
    bldc_ctrl->Running_Flag = NO;

    bldc_ctrl->AlarmLED_State = HIGH;

    bldc_ctrl->Target_Speed_RPM = 0;
    bldc_ctrl->Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Target_Speed_ERPM = 0;
    bldc_ctrl->Target_Speed_ERPM_Abs = 0;

    bldc_ctrl->Current_Target_Speed_RPM = 0;
    bldc_ctrl->Current_Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Current_Target_Speed_ERPM = 0;
    bldc_ctrl->Current_Target_Speed_ERPM_Abs = 0;

    //output_EnableOUT ( bldc_ctrl );
    velocityArrive( bldc_ctrl );
    velocityArrive2( bldc_ctrl );
    velocityArrive_EN( bldc_ctrl );

    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();

    if( bldc_ctrl->MotorStop_Behavior == MOTOR_STOP_BEHAVIOR_FREE ||
        bldc_ctrl->MotorStop_Behavior == MOTOR_STOP_BEHAVIOR_BRAKE ||
        RUN_CONDITION_1 ){
        DINT;
	    bldc_ctrl->SPK_Ptr->Stop();
	    EINT;
	    bldc_ctrl->Motor_State = MOTOR_STATE_STOP;

	}

    if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_EBRAKE ]  == HIGH ){
        bldc_ctrl->Motor_State = MOTOR_STATE_EBRAKING;

        bldc_ctrl->Ctrl_Updated = NO;

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
    }

    if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ]  == HIGH ){
        bldc_ctrl->Motor_State = MOTOR_STATE_FREEING;

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 &&
        bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0  ){

        bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
    }

    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

        bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }


#endif

}

/*===========================================================================================
    Function Name    : motor_Braking
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Braking Routine
//==========================================================================================*/
void motor_Braking ( Struct_BLDC_CTRL* bldc_ctrl )
{

#if(1)
    bldc_ctrl->Running_Flag = NO;

	//CG_Move.IMR_Flag = NO;

    bldc_ctrl->Target_Speed_RPM = 0;
    bldc_ctrl->Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Target_Speed_ERPM = 0;
    bldc_ctrl->Target_Speed_ERPM_Abs = 0;

    bldc_ctrl->Current_Target_Speed_RPM = 0;
    bldc_ctrl->Current_Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Current_Target_Speed_ERPM = 0;
    bldc_ctrl->Current_Target_Speed_ERPM_Abs = 0;

    //output_EnableOUT ( bldc_ctrl );
    velocityArrive( bldc_ctrl );
    velocityArrive2( bldc_ctrl );
    velocityArrive_EN( bldc_ctrl );

    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
        DINT;
        bldc_ctrl->Drive_Ptr->SineWaveToStep();
        EINT;
    }

    if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        EINT;
    }

    /*
	if( bldc_ctrl->Ctrl_Updated == NO ){
	    bldc_ctrl->Ctrl_Updated  = YES;
		DINT;
		management_BrakePWMDuty( bldc_ctrl );
		EINT;
	}
	*/

	if( bldc_ctrl->CS_Flag ){
        bldc_ctrl->CS_Flag = NO;
        mcCS ( bldc_ctrl );
    }

	if(  bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_EBRAKE ] == LOW  ){
		if( STOP_CONDITION_OPENLOOP ){
		    bldc_ctrl->Motor_State = MOTOR_STATE_STOP;
		}
	}else{
	    if( STOP_CONDITION_CLOSELOOP ){
	        bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
            OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                           [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();

        }
	}

	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ]  == HIGH ){
        bldc_ctrl->Motor_State = MOTOR_STATE_FREEING;

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 &&
        bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0  ){

        bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
    }

    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

        bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

#endif

}

/*===========================================================================================
    Function Name    : motor_Freeing
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Freeing Routine
//==========================================================================================*/
void motor_Freeing ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
    bldc_ctrl->Running_Flag = NO;

    //CG_Move.IMR_Flag = NO;

    bldc_ctrl->Target_Speed_RPM = 0;
    bldc_ctrl->Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Target_Speed_ERPM = 0;
    bldc_ctrl->Target_Speed_ERPM_Abs = 0;

    bldc_ctrl->Current_Target_Speed_RPM = 0;
    bldc_ctrl->Current_Target_Speed_RPM_Abs = 0;
    bldc_ctrl->Current_Target_Speed_ERPM = 0;
    bldc_ctrl->Current_Target_Speed_ERPM_Abs = 0;

    //output_EnableOUT ( bldc_ctrl );
    velocityArrive( bldc_ctrl );
    velocityArrive2( bldc_ctrl );
    velocityArrive_EN( bldc_ctrl );

    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
        DINT;
        bldc_ctrl->Drive_Ptr->SineWaveToStep();
        EINT;
    }

    if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        EINT;
    }

    DINT;
    bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
    EINT;

    bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );


    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();
	
    if( bldc_ctrl->CS_Flag ){
        bldc_ctrl->CS_Flag = NO;
        mcCS ( bldc_ctrl );
    }

	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ] == LOW ){
	    bldc_ctrl->Motor_State = MOTOR_STATE_STOP;
	}

	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 &&
        bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0  ){

        bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
    }

	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

        bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

#endif

}


/*===========================================================================================
    Function Name    : motor_Fault
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Fault Routine
//==========================================================================================*/
void motor_Fault ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
	uint8_t AlmResetFlag 	= NO;
	
	bldc_ctrl->Running_Flag = NO;

    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

	//CG_Move.IMR_Flag = NO;

	if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
	    DINT;
        bldc_ctrl->Drive_Ptr->SineWaveToStep();
        EINT;
    }

	if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        EINT;
	}

	DINT;
    bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
    EINT;

    bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

	/*
	if( CG_SPK.Tq_Restraint_flag == YES ){
		setupSPK_PWM_Stop();
	}*/

	if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ] == HIGH ){
	    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
	}else{
	    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
	}

    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();

	// Motor_Fault related variable setup
		
	// Physical IO reset check
    AlmResetFlag = protect_io_reset_check_routine ( bldc_ctrl->Protect_Ptr, bldc_ctrl, 10, bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] );
	
	// Communication reset command check
	if ( bldc_ctrl->Protect_Ptr->ToReset ) {
	    bldc_ctrl->Protect_Ptr->ToReset = NO;
		AlmResetFlag = YES;
	}
		
	// auto reset check

	if( ( 1UL << bldc_ctrl->Protect_Ptr->first_fault_user ) & bldc_ctrl->Protect_Ptr->AutoReset_Mask_BITF ){
		
		if( bldc_ctrl->Protect_Ptr->AutoReset_Time == 0 ){
			
			if( CMD_STATE_RUN == LOW ){
				AlmResetFlag = YES;
			}
		}else{
			if( bldc_ctrl->Protect_Ptr->auto_reset_timer >= bldc_ctrl->Protect_Ptr->AutoReset_Time ){
				AlmResetFlag = YES;
			}
		}
		
	}
	
	// Alarm led routine
	protect_signal_AlmLED ( bldc_ctrl->Protect_Ptr, bldc_ctrl, bldc_ctrl->Protect_Ptr->first_fault_user );
	
	// Alarm related output routine
	
	// Alarm rested procedure
	if (( AlmResetFlag == YES) && (protect_is_alarm_reset_allowed( bldc_ctrl->Protect_Ptr )==YES) ) {
	    bldc_ctrl->Protect_Ptr->first_fault 			= FAULT_STATE_NO_FAULT;
	    bldc_ctrl->Protect_Ptr->first_fault_user     = FAULT_STATE_NO_FAULT;
	    bldc_ctrl->Motor_State        = MOTOR_STATE_STOP;
	    bldc_ctrl->Protect_Ptr->HisSaved_Flag 		= NO;						// Reset HisSaved flag.
	    bldc_ctrl->Protect_Ptr->UVP_Save_Flag		= NO;

	    bldc_ctrl->Protect_Ptr->LED_flash_count      = 0;
	    bldc_ctrl->Protect_Ptr->LED_flash_timer 	 = 0;
		
	    bldc_ctrl->AlarmLED_State = HIGH;
		
	    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_OUT];
		OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_OUT ] ]
					   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_ALM_OUT ] ]();
		
		bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_PLUSE ];
		OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] ]
					   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_ALM_PLUSE ] ]();
		
	}
	
	if( bldc_ctrl->CS_Flag ){
        bldc_ctrl->CS_Flag = NO;
        mcCS ( bldc_ctrl );
    }

	
	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 &&
        bldc_ctrl->Driver_Enable_Mode != DRIVER_EN_MODE_0  ){

        bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;

        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );
    }

	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

        bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

	
#endif

}

/*===========================================================================================
    Function Name    : motor_Wait
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor Wait Routine
//==========================================================================================*/
void motor_Wait ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)

    bldc_ctrl->Running_Flag = NO;

    //bldc_ctrl->AlarmLED_State = HIGH;

    bldc_ctrl->E_Lock_Flag = NO;
    bldc_ctrl->EForward_Flag = NO;
    bldc_ctrl->EReverse_Flag = NO;

    bldc_ctrl->EForward_State = NO;
    bldc_ctrl->EReverse_State = NO;


    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

    //CG_Move.IMR_Flag = NO;

    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
        DINT;
        bldc_ctrl->Drive_Ptr->SineWaveToStep();
        EINT;
    }

    if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        EINT;
    }

    DINT;
    bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
    EINT;

    bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

	bldc_ctrl->Driver_Enable_Flag = NO;

	if( bldc_ctrl->CS_Flag ){
        bldc_ctrl->CS_Flag = NO;
        mcCS ( bldc_ctrl );
    }

	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE_RELEASE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE_RELEASE ];
	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BR_ALL ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BR_ALL ];
	
	switch( bldc_ctrl->Driver_Enable_Mode ){
	case DRIVER_EN_MODE_0:
	default:
	    bldc_ctrl->Driver_Enable_Flag  = YES;

		if( CMD_STATE_FREE == HIGH ){
		    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
		}

		break;
	case DRIVER_EN_MODE_1:
		if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) != 0 ){
		    bldc_ctrl->Driver_Enable_Flag = YES;
		}

		if( CMD_STATE_FREE == HIGH ){
		    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
		}
		break;
	case DRIVER_EN_MODE_2:

	    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];

		if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) != 0 ){
		    bldc_ctrl->Driver_Enable_Flag  = YES;
		}
		break;
	}
	
    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();

    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE_RELEASE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE_RELEASE ] ]();

    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BR_ALL ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_BR_ALL ] ]();

	if( bldc_ctrl->Driver_Enable_Flag  == YES &&
	    CG_MD.Pwr_On_Cnt >= POWER_ON_TIME &&
		CG_ADC.BusV >= bldc_ctrl->Protect_Ptr->under_vbus_recover_value
	){
	    bldc_ctrl->AlarmLED_State = HIGH;
	    //CG_MD.PowerRelay_Ready2Open 	= YES;
	    bldc_ctrl->Motor_State          	= MOTOR_STATE_STOP;
	    bldc_ctrl->Torque_Limit = bldc_ctrl->OpMode_Ptr->Torque_Limit;
		
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_FREE_BIT) );
		io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );

		//updateSpeceilParameter();

		if( protect_is_alarm_reset_allowed( bldc_ctrl->Protect_Ptr ) ){

		    bldc_ctrl->Protect_Ptr->first_fault 		= FAULT_STATE_NO_FAULT;
		    bldc_ctrl->Protect_Ptr->first_fault_user    = FAULT_STATE_NO_FAULT;
		    bldc_ctrl->Protect_Ptr->HisSaved_Flag 		= NO;						// Reset HisSaved flag.
		    bldc_ctrl->Protect_Ptr->UVP_Save_Flag		= NO;

		}
		
		bldc_ctrl->Protect_Ptr->LED_flash_count         = 0;
		bldc_ctrl->Protect_Ptr->LED_flash_timer 		= 0;
		
		//CG_MD.Relay_On_Cnt = 0;
		
		/*
		if( !bldc_ctrl->PowerOn_Run_Checked ){
		    bldc_ctrl->PowerOn_Run_Checked = YES;
			protect_PWR_On_RUN_Error ( bldc_ctrl->Protect_Ptr, CMD_STATE_RUN, bldc_ctrl->Protect_Ptr->PowerOn_Run );
		}
		*/

	}

	if( !bldc_ctrl->PowerOn_Run_Checked &&
	    CG_MD.Pwr_On_Cnt >= 2 ){
        bldc_ctrl->PowerOn_Run_Checked = YES;
        protect_PWR_On_RUN_Error ( bldc_ctrl->Protect_Ptr, CMD_STATE_RUN, bldc_ctrl->Protect_Ptr->PowerOn_Run );
    }

	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_OUT ];
	OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_OUT ] ]
				   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_ALM_OUT ] ]();
	
	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_PLUSE ];
	OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] ]
				   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_ALM_PLUSE ] ]();
	
	if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) == 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) == 0    ){

        bldc_ctrl->Motor_State = MOTOR_STATE_STO;
        DINT;
        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
        bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    }

#endif

}

/*===========================================================================================
    Function Name    : motor_STO
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Motor STO Routine
//==========================================================================================*/
void motor_STO ( Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)

    bldc_ctrl->Running_Flag = NO;

    //bldc_ctrl->AlarmLED_State = HIGH;

    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );

    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
    io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );

    //CG_Move.IMR_Flag = NO;

    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
        DINT;
        bldc_ctrl->Drive_Ptr->SineWaveToStep();
        EINT;
    }

    if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
        DINT;
        bldc_ctrl->SPK_Ptr->Stop();
        EINT;
    }

    DINT;
    bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
    EINT;

    bldc_ctrl->Drive_Ptr->Duty_Out( 0, 0, 0  );

    if( bldc_ctrl->CS_Flag ){
        bldc_ctrl->CS_Flag = NO;
        mcCS ( bldc_ctrl );
    }

    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];

    switch( bldc_ctrl->Driver_Enable_Mode ){
    case DRIVER_EN_MODE_0:
    default:
        if( CMD_STATE_FREE == HIGH ){
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
        }

        break;
    case DRIVER_EN_MODE_1:
        if( CMD_STATE_FREE == HIGH ){
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
        }
        break;
    case DRIVER_EN_MODE_2:
        bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_PARK_BRAKE ];
        break;
    }

    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE ] ]();


    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_0 ) ) != 0 &&
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STO_1 ) ) != 0    ){

        bldc_ctrl->Motor_State = MOTOR_STATE_WAIT;

    }

    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_OUT ];
    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_OUT ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_ALM_OUT ] ]();

    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_PLUSE ];
    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_ALM_PLUSE ] ]();

#endif

}

/*===========================================================================================
    Function Name    : output_EnableOUT
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : EN_OUT funciton. Output active if current speed is over the target.
//==========================================================================================*/
void output_EnableOUT ( Struct_BLDC_CTRL* bldc_ctrl )
{
    Struct_IO_FUNC* io_func = ( Struct_IO_FUNC* )bldc_ctrl->IO_Func_Ptr;

	#define EN_SPEED_DIF	bldc_ctrl->VA_Speed//100
	#define EN_SPEED		bldc_ctrl->EN_Speed

	if ( bldc_ctrl->Motor_State != MOTOR_STATE_RUNNING) {
	    io_func->Output_State[ OUTPUT_EN_OUT ] = 1 - io_func->ActState_of_Func[ OUTPUT_EN_OUT ];
	} else {
		// Enable Out ON (active)
		if ( ( bldc_ctrl->Current_RPM_Abs >= EN_SPEED ) && ( io_func->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH ) ) {
		    io_func->Output_State[ OUTPUT_EN_OUT ] =io_func->ActState_of_Func[ OUTPUT_EN_OUT ];
		}

		// Enable Out OFF (inactive)
		if ( ( bldc_ctrl->Current_RPM_Abs < ( EN_SPEED - EN_SPEED_DIF ) ) || ( io_func->CMD[ SRC_ALL ][ CMD_RUN ] == LOW) ) {
		    io_func->Output_State[ OUTPUT_EN_OUT ] = 1 - io_func->ActState_of_Func[ OUTPUT_EN_OUT ];
		}
	}

	OutputYn_action[ io_func->Output_State[ OUTPUT_EN_OUT ] ]
				   [ io_func->OutputPin_of_Func[ OUTPUT_EN_OUT ] ]();

}

/*===========================================================================================
    Function Name    : velocityArrive
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Output active if current speed meet the target.
//==========================================================================================*/
void velocityArrive( Struct_BLDC_CTRL* bldc_ctrl )
{
    Struct_IO_FUNC* io_func = ( Struct_IO_FUNC* )bldc_ctrl->IO_Func_Ptr;
	int32_t speed_ditance;

	if( bldc_ctrl->Current_RPM >= bldc_ctrl->Target_Speed_RPM ){
		speed_ditance = bldc_ctrl->Current_RPM - bldc_ctrl->Target_Speed_RPM;
	}else{
		speed_ditance = bldc_ctrl->Target_Speed_RPM - bldc_ctrl->Current_RPM;
	}

	if( speed_ditance <= bldc_ctrl->VA_Speed ){
	    io_func->Output_State[ OUTPUT_VA_OUT ] = io_func->ActState_of_Func[ OUTPUT_VA_OUT ];
	}else{
	    io_func->Output_State[ OUTPUT_VA_OUT ] = 1 - io_func->ActState_of_Func[ OUTPUT_VA_OUT ];
	}

	OutputYn_action[ io_func->Output_State[ OUTPUT_VA_OUT ] ]
				   [ io_func->OutputPin_of_Func[ OUTPUT_VA_OUT ] ]();


}

/*===========================================================================================
    Function Name    : velocityArrive2
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 	1. Output active if current speed meet the target.
    					2. If target speed = 0, output off
//==========================================================================================*/
void velocityArrive2( Struct_BLDC_CTRL* bldc_ctrl )
{
    Struct_IO_FUNC* io_func = ( Struct_IO_FUNC* )bldc_ctrl->IO_Func_Ptr;
	int32_t speed_ditance;

	if( bldc_ctrl->Current_RPM >= bldc_ctrl->Target_Speed_RPM ){
        speed_ditance = bldc_ctrl->Current_RPM - bldc_ctrl->Target_Speed_RPM;
    }else{
        speed_ditance = bldc_ctrl->Target_Speed_RPM - bldc_ctrl->Current_RPM;
    }

	if( speed_ditance <= bldc_ctrl->VA_Speed && bldc_ctrl->Target_Speed_RPM != 0 ){
	    io_func->Output_State[ OUTPUT_VA2_OUT ] = io_func->ActState_of_Func[ OUTPUT_VA2_OUT ];
	}else{
	    io_func->Output_State[ OUTPUT_VA2_OUT ] = 1 - io_func->ActState_of_Func[ OUTPUT_VA2_OUT ];
	}

	OutputYn_action[ io_func->Output_State[ OUTPUT_VA2_OUT ] ]
				   [ io_func->OutputPin_of_Func[ OUTPUT_VA2_OUT ] ]();


}

/*===========================================================================================
    Function Name    : velocityArrive_EN
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 	1. When RUN is on : if current speed meet the target => output on. Else => output off
    					2. When RUN is off : if speed is over EN-Speed => output on. Else => output off
//==========================================================================================*/
void velocityArrive_EN( Struct_BLDC_CTRL* bldc_ctrl )
{
    Struct_IO_FUNC* io_func = ( Struct_IO_FUNC* )bldc_ctrl->IO_Func_Ptr;
	int32_t speed_ditance;

	if( bldc_ctrl->Current_RPM >= bldc_ctrl->Target_Speed_RPM ){
        speed_ditance = bldc_ctrl->Current_RPM - bldc_ctrl->Target_Speed_RPM;
    }else{
        speed_ditance = bldc_ctrl->Target_Speed_RPM - bldc_ctrl->Current_RPM;
    }

	if( io_func->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH ){
		if( speed_ditance <= bldc_ctrl->VA_Speed ){
		    io_func->Output_State[ OUTPUT_VA_EN_OUT ] = io_func->ActState_of_Func[ OUTPUT_VA_EN_OUT];
		}else{
		    io_func->Output_State[ OUTPUT_VA_EN_OUT ] = 1 - io_func->ActState_of_Func[ OUTPUT_VA_EN_OUT];
		}
	}else{
		if( bldc_ctrl->Current_RPM_Abs >= bldc_ctrl->EN_Speed ){
		    io_func->Output_State[ OUTPUT_VA_EN_OUT ] = io_func->ActState_of_Func[ OUTPUT_VA_EN_OUT];
		}else{
		    io_func->Output_State[ OUTPUT_VA_EN_OUT ] = 1 - io_func->ActState_of_Func[ OUTPUT_VA_EN_OUT];
		}
	}

	OutputYn_action[ io_func->Output_State[ OUTPUT_VA_EN_OUT ] ]
				   [ io_func->OutputPin_of_Func[ OUTPUT_VA_EN_OUT ] ]();


}


/*===========================================================================================
    Function Name    : output_Encoder_Pulse
    Input            : 1.bldc_ctrl
                       2.pos
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void output_Encoder_Pulse( Struct_BLDC_CTRL* bldc_ctrl, int32_t pos )
{
    int32_t delta_pos;
    Struct_IO_FUNC *io_func = bldc_ctrl->IO_Func_Ptr;
    Struct_Basic_Encoder *encoder = bldc_ctrl->Encoder_Ptr;

    if( bldc_ctrl->IO_Func_Ptr->EncoderPulse_Enable == YES ){

        pos = pos + encoder->LastPos_B4Z;
        if( pos > encoder->MaxPos ){
            pos -= encoder->MaxPos;
        }

        delta_pos = pos - io_func->EncoderPulse_Stamp;

        if( delta_pos > encoder->PosErrorMax_P ){
            delta_pos = delta_pos - encoder->MaxPos;
        }else if( delta_pos < encoder->PosErrorMax_N ){
            delta_pos = delta_pos + encoder->MaxPos;
        }

        if( delta_pos > io_func->EncoderPulse_Divider_P ){
            io_func->EncoderPulse_Stamp += io_func->EncoderPulse_Divider;
            io_func->EncoderPulse_Direction = DIR_CW;
            //bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_DIR_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_DIR_OUT ];
            io_func->EncoderPulse_State = ( io_func->EncoderPulse_State + 1 ) & 0x03;
            if( io_func->EncoderPulse_Stamp > encoder->MaxPos ){
                io_func->EncoderPulse_Stamp -= encoder->MaxPos;
            }
        }else if( delta_pos < io_func->EncoderPulse_Divider_N ){
            io_func->EncoderPulse_Stamp -= io_func->EncoderPulse_Divider;
            io_func->EncoderPulse_Direction = DIR_CCW;
            //bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_DIR_OUT ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_DIR_OUT ];
            io_func->EncoderPulse_State = ( io_func->EncoderPulse_State - 1 ) & 0x03;
            if( io_func->EncoderPulse_Stamp < 0 ){
                io_func->EncoderPulse_Stamp += encoder->MaxPos;
            }
        }

        switch( io_func->EncoderPulse_State ){
        case 0:
        case 2:
            io_func->Output_State[ OUTPUT_SPD_OUT ] = io_func->ActState_of_Func[ OUTPUT_SPD_OUT ];
            break;
        case 1:
        case 3:
        default:
            io_func->Output_State[ OUTPUT_SPD_OUT ] = 1 - io_func->ActState_of_Func[ OUTPUT_SPD_OUT ];
            break;
        }

        if( io_func->EncoderPulse_Direction == DIR_CCW ){
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_DIR_OUT ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_DIR_OUT ];
        }else{
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_DIR_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_DIR_OUT ];
        }

        OutputYn_action[ io_func->Output_State[ OUTPUT_SPD_OUT ] ][ io_func->OutputPin_of_Func[ OUTPUT_SPD_OUT ] ]();
        OutputYn_action[ io_func->Output_State[ OUTPUT_DIR_OUT ] ][ io_func->OutputPin_of_Func[ OUTPUT_DIR_OUT ] ]();

    }

}

/*===========================================================================================
    Function Name    : call_1ms_bldc_ctrl
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void call_1ms_bldc_ctrl( Struct_BLDC_CTRL* bldc_ctrl )
{
    static uint32_t timer = 0;
    uint8_t duty;

    int32_t foc_duty;

    bldc_ctrl->Ctrl_Updated = NO;

    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_KEY_SWITCH ) ) == 0 ){
        if( bldc_ctrl->ServoOff_Delay_TimerMs < 0xFFFF ){
            bldc_ctrl->ServoOff_Delay_TimerMs++;
        }
    }else{
        bldc_ctrl->ServoOff_Delay_TimerMs = 0;
    }

    if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP &&
        bldc_ctrl->Drive_Ptr->EBrake_Flag != YES ){

        foc_duty = -bldc_ctrl->Drive_Ptr->FOC.Vq * CONST_1 / CONST_SQRT3_OVER_3;
        if( bldc_ctrl->Dir_Def == FORWARD_DIR_BOTTOM ){
            foc_duty *= -1;
        }
        if( bldc_ctrl->Control_Mode != CTRL_OPENLOOP ){
            bldc_ctrl->Current_Duty = foc_duty;
            if( bldc_ctrl->Current_Duty >= 0 ){
                bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Current_Duty;
            }else{
                bldc_ctrl->Current_Duty_Abs = -bldc_ctrl->Current_Duty;
            }
        }

        bldc_ctrl->Current_Duty_Display = foc_duty * FULL_DUTY / bldc_ctrl->Drive_Ptr->Period;
        bldc_ctrl->Drive_Ptr->Duty_Apply_Abs = ( foc_duty < 0 ? -foc_duty : foc_duty );

    }else{
        bldc_ctrl->Current_Duty_Display = bldc_ctrl->Current_Duty * FULL_DUTY / bldc_ctrl->Drive_Ptr->Period;
        bldc_ctrl->Drive_Ptr->Duty_Apply_Abs = bldc_ctrl->Current_Duty_Abs;
    }

    if( bldc_ctrl->Motor_State != MOTOR_STATE_FAULT ){
        bldc_ctrl->Protect_Ptr->ToReset = NO;
    }

    //if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( 1UL << FUNC_STOP ) ) != 0 ){
    if( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_IO ] & ( 1UL << FUNC_STOP ) ) != 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_EEP ] & ( 1UL << FUNC_STOP ) ) != 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_UART ] & ( 1UL << FUNC_STOP ) ) != 0 ||
        ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_OTHERS ] & ( 1UL << FUNC_STOP ) ) != 0 ){
        io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
    }

    if( bldc_ctrl->Motor_State == MOTOR_STATE_STO ){
        if( ++bldc_ctrl->STO_LED_Flash_Timer >= LED_FLASH_PULSE_WIDTH ){
            bldc_ctrl->STO_LED_Flash_Timer = 0;
            bldc_ctrl->AlarmLED_State = 1 ^ bldc_ctrl->AlarmLED_State;
        }
    }else{
        bldc_ctrl->STO_LED_Flash_Timer = 0;
    }

    if( bldc_ctrl->Motor_State == MOTOR_STATE_WAIT ){
        if( ++bldc_ctrl->WAIT_LED_Flash_Timer >= LED_FLASH_PULSE_WIDTH_WAIT ){
            bldc_ctrl->WAIT_LED_Flash_Timer = 0;
            bldc_ctrl->AlarmLED_State = 1 ^ bldc_ctrl->AlarmLED_State;
        }
    }else{
        bldc_ctrl->WAIT_LED_Flash_Timer = 0;
    }

    if( bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL ){
        hall_1ms_Routine( bldc_ctrl->Hall_Ptr );
        bldc_ctrl->Current_RPM = bldc_ctrl->Hall_Ptr->Current_RPM;
        bldc_ctrl->Current_RPM_Abs = bldc_ctrl->Hall_Ptr->Current_RPM_Abs;
        //bldc_ctrl->Current_ERPM = bldc_ctrl->Hall_Ptr->Current_ERPM;
        //bldc_ctrl->Current_ERPM_Abs = bldc_ctrl->Hall_Ptr->Current_ERPM_Abs;

        bldc_ctrl->Stall_Timer = bldc_ctrl->Hall_Ptr->Stall_Timer;
        bldc_ctrl->Current_Dir = bldc_ctrl->Hall_Ptr->Current_Dir;
    }else{
        bldc_ctrl->Current_RPM = bldc_ctrl->Encoder_Ptr->Smooth_RPM;
        bldc_ctrl->Current_RPM_Abs = bldc_ctrl->Encoder_Ptr->Smooth_RPM_Abs;
        //bldc_ctrl->Current_ERPM = bldc_ctrl->Encoder_Ptr->Smooth_ERPM;
        //bldc_ctrl->Current_ERPM_Abs = bldc_ctrl->Encoder_Ptr->Smooth_ERPM_Abs;

        bldc_ctrl->Stall_Timer = bldc_ctrl->Encoder_Ptr->Stall_Timer;
        bldc_ctrl->Current_Dir = bldc_ctrl->Encoder_Ptr->Direction;
    }
    bldc_ctrl->Bemf_Duty = bldc_ctrl->Current_RPM * bldc_ctrl->Drive_Ptr->Period / bldc_ctrl->Drive_Ptr->Full_Speed_Rpm_Abs;

    management_StopDelayTimer( bldc_ctrl );

    if( bldc_ctrl->Current_RPM_Abs < CONST_LOW_SPEED && CMD_STATE_RUN == LOW ){
        bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_RUN_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_RUN_OUT ];
    }else{
        bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_RUN_OUT ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_RUN_OUT ];
    }

    if( bldc_ctrl->IO_Func_Ptr->EncoderPulse_Enable == NO ){
        if( bldc_ctrl->Current_Dir == DIR_CCW ){
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_DIR_OUT ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_DIR_OUT ];
        }else{
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_DIR_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_DIR_OUT ];
        }

        OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_DIR_OUT ] ]
                       [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_DIR_OUT ] ]();

    }

    if( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING ||
        bldc_ctrl->Motor_State == MOTOR_STATE_EBRAKING ||
        bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ||
        bldc_ctrl->Motor_State == MOTOR_STATE_LOCK ){

        bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_OUT ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BUSY_OUT ];
        bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_ALM_PLUSE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BUSY_ALM_PLUSE ];

    }else{

        bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_OUT ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BUSY_OUT ];

        if( bldc_ctrl->Motor_State != MOTOR_STATE_FAULT ){
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_ALM_PLUSE ] = 1- bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BUSY_ALM_PLUSE ];
        }

    }

#define TIME_CONST  60000
#define PERIOD  4
#define DUTY    duty

    duty = PERIOD;
    timer = ( ++timer ) & 0x03;

    if( CG_ADC.BusV > CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ ADVANCE_FUNC_BATTERY_GAUGE_1 ] ){

        bldc_ctrl->IO_Func_Ptr->Battery_Gauge_Timer_Ms = 0;
        // GAUGE_1 = High ( Green = On )
        // GAUGE_2 = Low ( Red = Off )

        if( timer >= DUTY ){
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_1 ];
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_2 ];
        }else{
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_1 ];
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_2 ];
        }

    }else if( CG_ADC.BusV < CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ ADVANCE_FUNC_BATTERY_GAUGE_2 ] ){

        bldc_ctrl->IO_Func_Ptr->Battery_Gauge_Timer_Ms = TIME_CONST;

        // GAUGE_1 = Low ( Green = Off )
        // GAUGE_2 = High ( Red = On )
        if( timer >= DUTY ){
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_1 ];
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_2 ];
        }else{
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_1 ];
            bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_2 ];
        }

    }else{
        if( ++bldc_ctrl->IO_Func_Ptr->Battery_Gauge_Timer_Ms > TIME_CONST ){

            bldc_ctrl->IO_Func_Ptr->Battery_Gauge_Timer_Ms = TIME_CONST;

            // GAUGE_1 = Low => High => Low => High...
            // GAUGE_2 = High => Low => High => Low...

            if( timer >= DUTY ){
                bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_1 ];
                bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_2 ];
            }else{
                if( timer % 2 ){
                    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_1 ];
                    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_2 ];
                }else{
                    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_1 ];
                    bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BATTERY_GAUGE_2 ];
                }
            }

        }
    }

    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_PARK_BRAKE_RELEASE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_PARK_BRAKE_RELEASE ] ]();

    OutputYn_action [ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_1 ] ]
                    [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_BATTERY_GAUGE_1 ] ]();

    OutputYn_action [ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BATTERY_GAUGE_2 ] ]
                    [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_BATTERY_GAUGE_2 ] ]();


    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_RUN_OUT ] ]
                     [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_RUN_OUT ] ]();

    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_OUT ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_BUSY_OUT ] ]();

    OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_ALM_PLUSE ] ]
                   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_BUSY_ALM_PLUSE ] ]();


}

/*===========================================================================================
    Function Name    : call_MainLoop_bldc_ctrl
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void call_MainLoop_bldc_ctrl( Struct_BLDC_CTRL* bldc_ctrl )
{
    int64_t dec_time;
    int64_t spd_const = POSITION_CTRL_SPEED_CONST;

    if( bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_CMD ] != MULTI_CMD_NULL_AND_NOECHO ){
        mdCMD_Execute ( bldc_ctrl, bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_CMD ], bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_DATA1 ], bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_DATA2 ] );
        bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_CMD ] = MULTI_CMD_NULL_AND_NOECHO;
        bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_DATA1 ] = 0;
        bldc_ctrl->MultiDrive_CMD[ MULTI_DRIVE_DATA2 ] = 0;

        // The following 2lines are needed, because we needs to set Capture_Index and Capture_Pos
        mcGetCurrentIndex( bldc_ctrl );
        mcGetCurrentPos( bldc_ctrl );
        //
    }

    if( bldc_ctrl->MultiDriveLite_CMD[ MULTI_DRIVE_LITE_CMD ] != MDL_CMD_NULL ){
        mdlCMD_Execute ( bldc_ctrl, bldc_ctrl->MultiDriveLite_CMD[ MULTI_DRIVE_LITE_CMD ], bldc_ctrl->MultiDriveLite_CMD[ MULTI_DRIVE_LITE_DATA ] );
        bldc_ctrl->MultiDriveLite_CMD[ MULTI_DRIVE_LITE_CMD ] = MDL_CMD_NULL;
        bldc_ctrl->MultiDriveLite_CMD[ MULTI_DRIVE_LITE_DATA ] = 0;

        //
        mcGetCurrentIndex( bldc_ctrl );
        mcGetCurrentPos( bldc_ctrl );
        //
    }

    if( bldc_ctrl->Drive_Ptr->Motor_Type == MOTOR_BDC ){
        bldc_ctrl->Hall_Ptr->Current_State = HALL_SIGNAL_CONST;
    }

    if( bldc_ctrl->Motor_State != MOTOR_STATE_MOVE || bldc_ctrl->PositionCtrl.Meat_Target_Flag ){
        bldc_ctrl->IMR_Flag = NO;
    }

    if( ( bldc_ctrl->Target_ToUpdate_BITF >> TOUPDATE_BIFT_SPEED ) & 0x01 ){
        bldc_ctrl->Target_ToUpdate_BITF &= ~( 1UL << TOUPDATE_BIFT_SPEED );
        calculateTargetSpeed( bldc_ctrl );
    }

    if( ( bldc_ctrl->Target_ToUpdate_BITF >> TOUPDATE_BIFT_POSITION_HALL ) & 0x01 ){
        bldc_ctrl->Target_ToUpdate_BITF &= ~( 1UL << TOUPDATE_BIFT_POSITION_HALL );
        if( bldc_ctrl->IMR_Flag ){
            il_PositionControl_Set_Path_Spd_Limit ( &bldc_ctrl->PositionCtrl, bldc_ctrl->IMR_SpeedInitInRPM_Abs * bldc_ctrl->PositionCtrl.MaxPos / 60 );

            if( bldc_ctrl->Current_Target_Speed_RPM_Abs != 0 ){
                dec_time = ( int64_t )bldc_ctrl->PositionCtrl.distance_abs * 120000LL / ( bldc_ctrl->Current_Target_Speed_RPM_Abs * bldc_ctrl->PositionCtrl.MaxPos );
                dec_time = dec_time * spd_const / bldc_ctrl->Current_Target_Speed_RPM_Abs;
            }else{
                dec_time = 100000;
            }

            bldc_ctrl->IMR_Dec_Time = dec_time;

            il_PositionControl_Set_Path_AccDEC ( &bldc_ctrl->PositionCtrl, bldc_ctrl->IMR_Dec_Time, bldc_ctrl->IMR_Dec_Time );

            bldc_ctrl->PositionCtrl.Path_Buffer = bldc_ctrl->Buffer_IMR_CMD;
        }else{
            il_PositionControl_Set_Path_Spd_Limit ( &bldc_ctrl->PositionCtrl, bldc_ctrl->OpMode_Ptr->Digit_RPM_Abs * bldc_ctrl->PositionCtrl.MaxPos / 60 );
            il_PositionControl_Set_Path_AccDEC ( &bldc_ctrl->PositionCtrl, bldc_ctrl->OpMode_Ptr->Acc_Time, bldc_ctrl->OpMode_Ptr->Dec_Time );
            il_PositionControl_Calculate_Path_Buffer ( &bldc_ctrl->PositionCtrl );
        }

        il_PositionControl_PathRun ( &bldc_ctrl->PositionCtrl );

        //
        bldc_ctrl->Current_Target_Speed_RPM = bldc_ctrl->PositionCtrl.Path_Spd * 60 / bldc_ctrl->PositionCtrl.MaxPos;
        bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Current_Target_Speed_RPM * bldc_ctrl->Drive_Ptr->Pole_Factor;

        if( bldc_ctrl->Current_Target_Speed_RPM >= 0 ){
            bldc_ctrl->Current_Target_Speed_RPM_Abs = bldc_ctrl->Current_Target_Speed_RPM;
            bldc_ctrl->Current_Target_Speed_ERPM_Abs = bldc_ctrl->Current_Target_Speed_ERPM;
        }else{
            bldc_ctrl->Current_Target_Speed_RPM_Abs = -bldc_ctrl->Current_Target_Speed_RPM;
            bldc_ctrl->Current_Target_Speed_ERPM_Abs = -bldc_ctrl->Current_Target_Speed_ERPM;
        }
        //

    }

    if( ( bldc_ctrl->Target_ToUpdate_BITF >> TOUPDATE_BIFT_POSITION_ENCODER ) & 0x01 ){
        bldc_ctrl->Target_ToUpdate_BITF &= ~( 1UL << TOUPDATE_BIFT_POSITION_ENCODER );

        if( bldc_ctrl->IMR_Flag ){

            il_PositionControl_Set_Path_Spd_Limit ( &bldc_ctrl->PositionCtrl, bldc_ctrl->IMR_SpeedInitInRPM_Abs * bldc_ctrl->PositionCtrl.MaxPos / 60 );

            if( bldc_ctrl->Current_Target_Speed_RPM_Abs != 0 ){
                dec_time = ( int64_t )bldc_ctrl->PositionCtrl.distance_abs * 120000LL / ( bldc_ctrl->Current_Target_Speed_RPM_Abs * bldc_ctrl->PositionCtrl.MaxPos );
                dec_time = dec_time * spd_const / bldc_ctrl->Current_Target_Speed_RPM_Abs;
            }else{
                dec_time = 100000;
            }

            bldc_ctrl->IMR_Dec_Time = dec_time;

            il_PositionControl_Set_Path_AccDEC ( &bldc_ctrl->PositionCtrl, bldc_ctrl->IMR_Dec_Time, bldc_ctrl->IMR_Dec_Time );

            bldc_ctrl->PositionCtrl.Path_Buffer = bldc_ctrl->Buffer_IMR_CMD;
        }else{
            il_PositionControl_Set_Path_Spd_Limit ( &bldc_ctrl->PositionCtrl, bldc_ctrl->OpMode_Ptr->Digit_RPM_Abs * bldc_ctrl->PositionCtrl.MaxPos / 60 );
            il_PositionControl_Set_Path_AccDEC ( &bldc_ctrl->PositionCtrl, bldc_ctrl->OpMode_Ptr->Acc_Time, bldc_ctrl->OpMode_Ptr->Dec_Time );
            il_PositionControl_Calculate_Path_Buffer ( &bldc_ctrl->PositionCtrl );
        }

        il_PositionControl_PathRun_Advance( &bldc_ctrl->PositionCtrl, YES );

        //
        bldc_ctrl->Current_Target_Speed_RPM = bldc_ctrl->PositionCtrl.Path_Spd * 60 / bldc_ctrl->PositionCtrl.MaxPos;
        bldc_ctrl->Current_Target_Speed_ERPM = bldc_ctrl->Current_Target_Speed_RPM * bldc_ctrl->Drive_Ptr->Pole_Factor;

        if( bldc_ctrl->Current_Target_Speed_RPM >= 0 ){
            bldc_ctrl->Current_Target_Speed_RPM_Abs = bldc_ctrl->Current_Target_Speed_RPM;
            bldc_ctrl->Current_Target_Speed_ERPM_Abs = bldc_ctrl->Current_Target_Speed_ERPM;
        }else{
            bldc_ctrl->Current_Target_Speed_RPM_Abs = -bldc_ctrl->Current_Target_Speed_RPM;
            bldc_ctrl->Current_Target_Speed_ERPM_Abs = -bldc_ctrl->Current_Target_Speed_ERPM;
        }
        //

    }

    if( (  ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_CW_LIMIT)) != 0 && bldc_ctrl->Current_Target_Speed_ERPM > 0  ) ||
        (  ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & (1UL << FUNC_CCW_LIMIT)) != 0 && bldc_ctrl->Current_Target_Speed_ERPM < 0  )    ){

        if( bldc_ctrl->MultiDrive_Src == SRC_MULTI_DRIVE_M0 ){
            io_ValSet_DI_XN_BITF( SRC_OTHERS, _BIT( SRC_OTHERS_M0_STOP_BIT ) );
        }/*else{
            io_ValSet_DI_XN_BITF( SRC_OTHERS, _BIT( SRC_OTHERS_M1_STOP_BIT ) );
        }*/

    }else{

        if( bldc_ctrl->MultiDrive_Src == SRC_MULTI_DRIVE_M0 ){
            io_ValClr_DI_XN_BITF( SRC_OTHERS, _BIT( SRC_OTHERS_M0_STOP_BIT ) );
        }/*else{
            io_ValClr_DI_XN_BITF( SRC_OTHERS, _BIT( SRC_OTHERS_M1_STOP_BIT ) );
        }*/

    }


    /*
    if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
        spkOutputDuty_ByADC( bldc_ctrl->SPK_Ptr, bldc_ctrl );
    }
    */

}

/************************** <END OF FILE> *****************************************/
