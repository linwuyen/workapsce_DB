/*===========================================================================================
    File Name       : HallSensor.h
    Built Date      : 2020/06/24
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for Hall sensor speed detect
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */


#ifndef HALL_SENSOR_H
#define HALL_SENSOR_H

#define SPEED_CONST	( 600 )//( 450 )

//#define ZERO_SPEED_CNT	( 10000 / ( 30 * CG_BLDC_Drive.Pole_Factor ) )//160
#define HALL_ZERO_SPEED_CONST  ( 30 )   // 30 = 30 RPM
#define SMOOTH_RPM_THRESHOLD                    10  // 10 = 10RPM

#define PHASE_ANDVACE_CONST         128

#define HALL_SEC_MAX	            121//61

#define PA_OPEN_CNT                 24

extern const uint8_t Const_Hall_Next_State_TOP[2][8];		// For Hall A
extern const uint8_t Const_Hall_Next_State_BOTTOM[2][8];	// For Hall B

#define HALL_SIGNAL_CONST 2

/*===========================================================================================
    Direction Defines
//==========================================================================================*/
#ifndef DIR_CW
#define DIR_CW      0
#endif

#ifndef DIR_CCW
#define DIR_CCW     1
#endif

#ifndef DIR_UNKNOWN
#define DIR_UNKNOWN     -1
#endif

// Commutation type
enum{
    COMMUTATION_TYPE_ACC         = 0,
    COMMUTATION_TYPE_DEC         = 1,
    COMMUTATION_TYPE_NUM         = 2
};


typedef struct{

    int8_t      Sequence;
    int8_t      Pole_Factor;
    int8_t		Dir_Def;
    uint8_t  	(*Next_State_Table)[8];

    //
    uint8_t  	Current_State;
    int8_t      PA_State;
    int8_t      PA_State_Old;

    int32_t 	Position;
    int32_t  	Current_Dir;
    int32_t     Old_Dir;

	uint32_t 	Zero_Cnt;
	uint32_t	Stall_Timer;
	uint8_t		Reverse_Flag;

    uint8_t  	INT_Flag;
    uint32_t 	INT_Times;
    uint8_t  	Updated_Flag;
	
	// ==
	
	int32_t 	Smooth_RPM_Abs;
	int32_t 	Smooth_RPM;
	int32_t 	Smooth_ERPM_Abs;
	int32_t 	Smooth_ERPM;
	 
	int32_t 	Current_ERPM_Abs;
	int32_t 	Current_ERPM;
	int32_t 	Current_RPM_Abs;
	int32_t 	Current_RPM;
	 
	int32_t 	Rapid_RPM_Abs;
	int32_t 	Rapid_RPM;
	int32_t 	Rapid_ERPM_Abs;
	int32_t 	Rapid_ERPM;
	 
	int32_t 	Ecycle_ERPM_Abs;
	int32_t 	Ecycle_ERPM;
	int32_t 	Ecycle_RPM_Abs;
	int32_t 	Ecycle_RPM;
	
	//

    uint8_t     Next_State_If_CW;
    uint8_t     Next_State_If_CCW;

    uint32_t    INT_Time_New;

    uint32_t    INT_TP_1;
    uint32_t    INT_TP_2;

    uint32_t    INT_Time_Period[ HALL_SEC_MAX ];
    uint32_t    INT_Time_Sum[ HALL_SEC_MAX ];

    uint32_t    INT_E_Period;
    int8_t      INT_E_Last_Pointer;

    int8_t      Pointer;
    int8_t      Last_Pointer;
    int8_t      Current_Pointer;

    uint32_t    Phase_Length;

    //
    uint8_t     Smooth_Flag;                        // Indicate if the motor run at a steady state
    uint32_t    Smooth_Cnt;
    int32_t     Smooth_Spd_Threshold;
    int32_t     Smooth_Speed_Old;

    // PA = Phase Advance
    int8_t      PA_Enabled;
    int8_t      PA_Angle;
    int8_t      PA_Ticks;

    int8_t      PA_Flag;
    int8_t      PA_Commutation;
    int8_t      PA_Commutation_Type;

    uint32_t    PA_Time_Stamp;
    uint32_t    PA_Time_Pass;
    uint32_t    PA_Time_Threshold;


}Struct_HallSensor;


/*===========================================================================================
    Function Name    : variableInitial_HallSensor
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_HallSensor ( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : variableReset_HallSensor
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableReset_HallSensor ( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : hall_ResetPosition
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Reset hall position count
//==========================================================================================*/
void hall_ResetPosition ( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : hall_Reset_Stall_Timer
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_Reset_Stall_Timer( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : hall_PeriodCalculation
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void hall_PeriodCalculation( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : hall_ZeroSpeed_Determine
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Determine if motor is zero speed.
//==========================================================================================*/
void hall_ZeroSpeed_Determine( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : hall_Speed_Calculations
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate motor's speed.
//==========================================================================================*/
void hall_Speed_Calculations( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : hall_1ms_Routine
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_1ms_Routine( Struct_HallSensor* hall );

/*===========================================================================================
    Function Name    : il_Hall_PhaseAdvance
    Input            : 1.hall
                       2.commutation
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_Hall_PhaseAdvance( Struct_HallSensor* hall, int8_t commutation )
{
    uint32_t current_time;
    hall->PA_Time_Stamp = hall->INT_Time_New;
    current_time = CURRENT_TIMER_CNT;
    hall->PA_Time_Pass = hall->PA_Time_Stamp - current_time;

    hall->PA_Commutation = commutation;
    if( hall->PA_Time_Pass > hall->PA_Time_Threshold ){
        if(  ( hall->Current_Dir == DIR_CW  && hall->PA_Commutation_Type == COMMUTATION_TYPE_ACC ) ||
             ( hall->Current_Dir == DIR_CCW && hall->PA_Commutation_Type == COMMUTATION_TYPE_DEC ) ){
            if( ++hall->PA_Commutation > 5 ){
                hall->PA_Commutation = 0;
            }
        }else{
            if( --hall->PA_Commutation < 0 ){
                hall->PA_Commutation = 5;
            }
        }
    }

    if( hall->PA_Enabled &&
        hall->Smooth_Flag &&
        hall->INT_Times > PA_OPEN_CNT ){
        hall->PA_Flag = YES;
    }else{
        hall->PA_Flag = NO;
    }
    //
}


#endif

/************************** <END OF FILE> *****************************************/

