/*
 * IO_Expander.h
 *
 *  Created on: 2020�~7��13��
 *      Author: Chaim.Chen
 */

#ifndef MODULE_A_IO_EXPANDER_H_
#define MODULE_A_IO_EXPANDER_H_

#include "IncludeFiles.h"

#define IO_EXPANDER_ADDRESS              0x20
#define IO_EXPANDER_TYPE                 0//EEPTYPE_2KBIT

#define IO_EXPANDER_ACT_BITF_INIT        0x031F


// Output actions
#define IO_EXP_EN_5V_ON                 ioExp_SetOutput( IO_EXP_EN_5V, 1 );
#define IO_EXP_EN_5V_OFF                ioExp_SetOutput( IO_EXP_EN_5V, 0 );

#define IO_EXP_HALL_PH_ON               ioExp_SetOutput( IO_EXP_HALL_PH, 1 );
#define IO_EXP_HALL_PH_OFF              ioExp_SetOutput( IO_EXP_HALL_PH, 0 );

#define IO_EXP_M1_LED_ON                ioExp_SetOutput( IO_EXP_M1_LED, 1 );
#define IO_EXP_M1_LED_OFF               ioExp_SetOutput( IO_EXP_M1_LED, 0 );

#define IO_EXP_M2_LED_ON                ioExp_SetOutput( IO_EXP_M2_LED, 1 );
#define IO_EXP_M2_LED_OFF               ioExp_SetOutput( IO_EXP_M2_LED, 0 );

#define IO_EXP_STA_LED_ON               ioExp_SetOutput( IO_EXP_STA_LED, 1 );
#define IO_EXP_STA_LED_OFF              ioExp_SetOutput( IO_EXP_STA_LED, 0 );

#define IO_EXP_Y1_ON                    ioExp_SetOutput( IO_EXP_Y1, 1 );
#define IO_EXP_Y1_OFF                   ioExp_SetOutput( IO_EXP_Y1, 0 );

#define IO_EXP_YH0_SEL_ON               ioExp_SetOutput( IO_EXP_YH0_SEL, 1 );
#define IO_EXP_YH0_SEL_OFF              ioExp_SetOutput( IO_EXP_YH0_SEL, 0 );

#define IO_EXP_YH1_SEL_ON               ioExp_SetOutput( IO_EXP_YH1_SEL, 1 );
#define IO_EXP_YH1_SEL_OFF              ioExp_SetOutput( IO_EXP_YH1_SEL, 0 );

#define IO_EXP_485_CAN_SEL_ON           ioExp_SetOutput( IO_EXP_485_CAN_SEL, 1 );
#define IO_EXP_485_CAN_SEL_OFF          ioExp_SetOutput( IO_EXP_485_CAN_SEL, 0 );


enum{

    IO_EXP_REG_INPUT_0          = 0,
    IO_EXP_REG_INPUT_1          = 1,
    IO_EXP_REG_OUTPUT_0         = 2,
    IO_EXP_REG_OUTPUT_1         = 3,

    IO_EXP_REG_POLARITY_INV_0   = 4,
    IO_EXP_REG_POLARITY_INV_1   = 5,

    IO_EXP_REG_CONFIG_0         = 6,
    IO_EXP_REG_CONFIG_1         = 7,
    IO_EXP_REG_NUM              = 8
};


enum{
    // Version A
    IO_EXP_HALL_PH      = 0,    // ok
    IO_EXP_EN_5V_VER_A  = 1,    // ok
    IO_EXP_Y1           = 2,    // ok

    // Version B
    IO_EXP_EN_5V_VER_B  = 0,    // ok
    IO_EXP_HALL_PH_M1   = 1,    // ok
    IO_EXP_HALL_PH_M2   = 2,    // ok

    // Common
    IO_EXP_YH0_SEL      = 3,    // ok
    IO_EXP_YH1_SEL      = 4,    // ok


    IO_EXP_M1_LED       = 5,    // ok
    IO_EXP_M2_LED       = 6,    // ok
    IO_EXP_STA_LED      = 7,    // ok


    IO_EXP_485_CAN_SEL  = 8,    // ok

    IO_EXP_CAN_EN       = 9,    // ok

    // Version A
    IO_EXP_RES10        = 10,
    IO_EXP_RES11        = 11,
    IO_EXP_RES12        = 12,
    IO_EXP_RES13        = 13,

    // Version B
    IO_EXP_COMM_ID_SW0  = 10,
    IO_EXP_COMM_ID_SW1  = 11,
    IO_EXP_MBRAKE_SENSE_M1 = 12,
    IO_EXP_MBRAKE_SENSE_M2 = 13,

    // Common
    IO_EXP_M1_ER        = 14,
    IO_EXP_M2_ER        = 15,
    IO_EXP_NUM          = 16

};

typedef struct{

    uint16_t Configure;

    uint16_t Xn_State_BITF;                                  // I/O state.
    uint16_t XnNormState_BITF;                               // I/O active state.

    uint16_t Yn_State_BITF;                                  // I/O state.
    uint16_t YnActState_BITF;                                // I/O active state.

    uint16_t Data_Flag;

    //

}Struct_IO_Expander;

/*===========================================================================================
    Function Name    : setupInitial_IO_Expander
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t setupInitial_IO_Expander();

/*===========================================================================================
    Function Name    : ioExp_SetOutput
    Input            : 1.index
                       2.state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void ioExp_SetOutput( int32_t index, int32_t state );

/*===========================================================================================
    Function Name    : ioExp_ToggleOutput
    Input            : 1.index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void ioExp_ToggleOutput( int32_t index );

/*===========================================================================================
    Function Name    : readData_IOExp
    Input            :
                       1.slaveID: S2S1S0
                       2.address: EEP address
                       3.num    : data length.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Read data from EEP
//==========================================================================================*/
uint16_t readData_IOExp( uint8_t slaveID, uint32_t address, uint8_t num );

/*===========================================================================================
    Function Name    : ioExp_RoutineWork
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Put at 10ms event
//==========================================================================================*/
void ioExp_RoutineWork();


#endif /* MODULE_A_IO_EXPANDER_H_ */

/************************** <END OF FILE> *****************************************/


