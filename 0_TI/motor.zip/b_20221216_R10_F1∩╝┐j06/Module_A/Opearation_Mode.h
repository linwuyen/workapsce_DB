/*===========================================================================================
    File Name       : Opearation_Mode.h
    Built Date      : 2014-08-29
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for opearation mode.			
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef OPEARATION_MODE_H
#define OPEARATION_MODE_H
#include "Opearation_Mode_TypeDef.h"


#define TQ_100_PERCENT		1000	// 1000 = 100.0% ( Tq )
#define DUTY_100_PERCENT	1000	// 1000 = 100.0% ( Duty )
#define SCALE_100_PERCENT	1000	// 1000 = 100.0% ( scale )


//#define ACC_TIME		( *CG_OPMode.Digit_Acc_Time [ digit_num ] )
//#define DEC_TIME		( *CG_OPMode.Digit_Dec_Time [ digit_num ] )


#define VR_OFF_SET_V_PA         CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_OFF_SET_VOLTAGE ]
//#define VR_OFF_SET_V            ( VR_OFF_SET_V_PA * THROTTLE_MULTIFY )
//#define VR_OFF_SET_SPD          CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_VR_OFF_SET_SPD ]
//#define VR_GAIN_VALUE           ( CG_Parameter.RAM_data[ PARAMETER_SPEED ][SPD_VR_GAIN ] )

#define VR_STOP_V_DISTANCE      10
#define VR_RUN_V_DISTANCE      	5
#define VR_STOP_VALUE_RISING	( VR_OFF_SET_V_PA <= VR_STOP_V_DISTANCE + 4 ? 4 : VR_OFF_SET_V_PA - VR_STOP_V_DISTANCE )
#define VR_RUN_VALUE_RISING		( VR_OFF_SET_V_PA <  VR_STOP_V_DISTANCE + 1 ? 6 : VR_OFF_SET_V_PA - VR_RUN_V_DISTANCE  )

#define VR_MAX_PA               CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_SIGNAL_MAX ]

#define VR_STOP_VALUE_FALLING   ( VR_MAX_PA + VR_STOP_V_DISTANCE >= SCALE_100_PERCENT ? SCALE_100_PERCENT - VR_STOP_V_DISTANCE : VR_MAX_PA + VR_STOP_V_DISTANCE )
#define VR_RUN_VALUE_FALLING    ( VR_MAX_PA + VR_STOP_V_DISTANCE >= SCALE_100_PERCENT ? SCALE_100_PERCENT - VR_RUN_V_DISTANCE : VR_MAX_PA + VR_RUN_V_DISTANCE  )

#define INTVR_MIN_VALUE			20
#define ADC_INTVR_RANGE_CONST	35//20
#define INTVR_STOP_VALUE		( INTVR_MIN_VALUE - VR_STOP_V_DISTANCE )
#define INTVR_RUN_VALUE			( INTVR_MIN_VALUE - VR_RUN_V_DISTANCE  )


#define SPEED_CONST_MAX			( 3000UL * bldc_drive->Pole_Factor )


/*
#define ACCDEC_SPEED_CONST_MAX		( 300000UL * CG_BLDC_CTRL.Pole_Factor )
#define ACCDEC_SPEED_CONST			( 300 * CG_BLDC_CTRL.Pole_Factor )	// update / 10ms >>>  300; update / 1ms >>> 30
#define ACCDEC_MOVE_CONST			( 3000 * CG_BLDC_CTRL.Pole_Factor )
#define DUTY_CONST					100									// update / 10ms >>>   10; update / 1ms >>> 100
#define BUFFER_CONST				12000UL
#define PATH_SPEED_CONST			20
*/

enum{
	OP_MODE0 					= 0,
	OP_MODE1 					= 1,
	OP_MODE2                    = 2,
	OP_MODE3                    = 3,
	OP_MODE4                    = 4,
	OP_MODE_MULTI_DRIVE_LITE    = 4,
	OP_MODE_THROTTLE_ANALOG     = 5,
	OP_MODE_THROTTLE_PULSE      = 6,
	OP_MODE_THROTTLE_BV         = 7,

	OP_MODE_SPECIAL_0           = 9,
	OP_MODE_NUM 				= 10
};

enum{
	DIGIT_SET_0				= 0,
	DIGIT_SET_1				= 1,
	DIGIT_SET_2				= 2,
	DIGIT_SET_3				= 3,
	
	DIGIT_SET_NUM			= 4
};

enum{

	AD_MODE_5V			= 0,
	AD_MODE_10V			= 1,
    AD_MODE_Num         = 2

};

/*===========================================================================================
    Speed control target determine method Defines
//==========================================================================================*/
enum{
	SPEED_TAR_EXT_VR_SINGLE_ENDED 		= Throttle_SINGLE_ENDED,
	SPEED_TAR_EXT_VR_SINGLE_ENDED_R 	= Throttle_SINGLE_ENDED_R,
	SPEED_TAR_EXT_VR_WIG_WAG		 	= Throttle_WIG_WAG,
	SPEED_TAR_EXT_VR_WIG_WAG_R		 	= Throttle_WIG_WAG_R,
	SPEED_TAR_EXT_VR_UNIPOLAR			= Throttle_UNIPOLAR,
	SPEED_TAR_INT_VR 					= 5,
	SPEED_TAR_DIO	 					= 6,
	SPEED_TAR_PULSE_FREQ	 			= 7,
	SPEED_TAR_PULSE_DUTY	 			= 8,
	SPEED_TAR_TOTALNUM					= 9,
	
	SPEED_TAR_THROT	 = 10,	// res for e-bike.
	SPEED_TAR_LEVEL	 = 11,   // res for e-bike.
	SPEED_TAR_PADDLE = 12,   // res for e-bike.
	SPEED_TAR_TQ	 = 13   // res for e-bike.
};

enum{
    THROTTLE_RESTRAINT_MODE_DISABLE                 = 0,
    THROTTLE_RESTRAINT_MODE_SINGLE_ENDED            = 1,
    THROTTLE_RESTRAINT_MODE_SINGLE_ENDED_REVERSE    = 2,

    THROTTLE_RESTRAINT_MODE_NUM                     = 3
};

/*===========================================================================================
    OPMode global variable data structure
//==========================================================================================*/
typedef struct{
		
	// ==
	uint8_t		AD_Mode;

	int32_t		AD_Gain;
	int32_t		AD_Offset;
	int32_t		AD_Offset_Spd;

	int32_t     Throttle_Type;
	int32_t     Throttle_Max;
	int32_t     Throttle_Map;
	int32_t     Throttle_DeadBand;
	int32_t     Throttle_DeadBand_PA;

	//
	int32_t 	Speed_Max;
	int32_t 	Speed_Min;

	int32_t 	Duty_Max;
	int32_t 	Duty_Min;

	int32_t 	Tq_Limit_Max;
	int32_t 	Tq_Limit_Min;

	int32_t 	AccDec_Polarity;
	int32_t		AccDec_Max;
	int32_t		AccDec_Min;

	int32_t     PW_Max;
	int32_t     PW_Min;

	//
	int32_t     Throttle_Restraint_Mode;
	int32_t     Scale_Max_Pa;
	int32_t     Scale_Min_Pa;

    int32_t     Scale_Factor;
    int32_t     Scaled_Limit_RPM_max;
    int32_t     Scaled_Limit_Duty_max;

	//
	Struct_Basic_OPMode Motor_0;
	//Struct_Basic_OPMode Motor_1;

}Struct_OPMode;

/*===========================================================================================
    Function Name    : variableInitial_OPMode
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void variableInitial_OPMode( void );

/*===========================================================================================
    Function Name    : call_1ms_OPMode
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 1ms time up event of OPMode.
//==========================================================================================*/
void call_1ms_OPMode ( void );

/*===========================================================================================
    Function Name    : setOpMode_SingleOperation_n
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SingleOperation Mode
//==========================================================================================*/
void setOpMode_SingleOperation_0 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );
void setOpMode_SingleOperation_1 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );
void setOpMode_SingleOperation_2 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );
void setOpMode_SingleOperation_3 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );

/*===========================================================================================
    Function Name    : setOpMode_Multi_Drive_Lite
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Multi_Drive_Lite ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );

/*===========================================================================================
    Function Name    : setOpMode_Throttle_Analog
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Throttle_Analog ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );

/*===========================================================================================
    Function Name    : setOpMode_Throttle_Pulse
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Throttle_Pulse ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );

/*===========================================================================================
    Function Name    : setOpMode_Throttle_BV
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Throttle_BV ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );

/*===========================================================================================
    Function Name    : setOpMode_Special_0
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : For Assisted Bicycle Application
//==========================================================================================*/
void setOpMode_Special_0 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );

/*===========================================================================================
    Function Name    : setOpMode_MultiCommand
    Input            :
                       1.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Digital Mode
//==========================================================================================*/
void setOpMode_MultiCommand ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num );

#endif


/************************** <END OF FILE> *****************************************/


