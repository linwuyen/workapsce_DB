/*===========================================================================================

    File Name       : FOC.h

    Version         : V1.00_a

    Built Date      : 2017/11/21

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef FOC_H
#define FOC_H
#include "Type.h"
#include "PIDControl.h"

#define CONST_SQRT_3						1773	// ( 3 ^ 0.5 ) * CONST_1
#define CONST_SQRT3_OVER_2					886		// ( 3 ^ 0.5 ) * CONST_1 / 2
#define CONST_SQRT3_OVER_3					591		// ( 3 ^ 0.5 ) * CONST_1 / 3
#define CONST_3								3072	// ( 3UL << 10 )
#define CONST_1								1024	// ( 1UL << 10 )
#define CONST_1_BIT_NUM						10

#define SINE_TABLE_RESOLUTION				360
#define SINE_TABLE_DEGREE_90				90
#define SINE_TABLE_CONST_1					8192
#define SINE_TABLE_BIT_NUM					13	// The greatest value = 2 ^ 13 = 8192


extern const int32_t Const_Sector_Table[ 8 ];
extern const int16_t Const_Sine_Table[ SINE_TABLE_RESOLUTION * 5 / 4 + 1 ];

/*===========================================================================================
    Function Name    : il_Sine
    Input            : angle: 0 ~�@360
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_Sine( int32_t angle )
{
		return Const_Sine_Table[ angle ];
}

/*===========================================================================================
    Function Name    : il_Cosine
    Input            : angle : Range = 0 to 360
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_Cosine( int32_t angle )
{
	return Const_Sine_Table[ angle + SINE_TABLE_DEGREE_90 ];

}


typedef struct{

	//
	int32_t			Shunt_Ia;
	int32_t			Shunt_Ib;
	int32_t			Shunt_Ic;

	int32_t			Shunt_Ialpha;
	int32_t			Shunt_Ibeta;

	int32_t			Shunt_Id;
	int32_t			Shunt_Iq;

	//
	int32_t			Va;
	int32_t			Vb;
	int32_t			Vc;

	int32_t			Valpha;
	int32_t			Vbeta;

	int32_t			Vd;
	int32_t			Vq;

	//
	int32_t         SensorAngle;
	int32_t			Angle;

	Struct_PID		Id_Controller;
	Struct_PID		Iq_Controller;

	//

	int32_t			SVM_V1;
	int32_t			SVM_V2;
	int32_t			SVM_V3;

	int32_t			SVM_Condtion_A;
	int32_t			SVM_Condtion_B;
	int32_t			SVM_Condtion_C;
	int32_t			SVM_Sector;

	int32_t			SVM_T1;
	int32_t			SVM_T2;
	int32_t			SVM_T0;
	int32_t			SVM_T_Max;

	//

}Struct_FOC;


/*===========================================================================================
    Function Name    : il_FOC_Set_Shunt_Ia
    Input            : 1.foc
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Set_Shunt_Ia ( Struct_FOC* foc, int32_t input )
{
	foc->Shunt_Ia = input;
}

/*===========================================================================================
    Function Name    : il_FOC_Set_Shunt_Ib
    Input            : 1.foc
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Set_Shunt_Ib ( Struct_FOC* foc, int32_t input )
{
	foc->Shunt_Ib = input;
}

/*===========================================================================================
    Function Name    : il_FOC_Set_Shunt_Ic
    Input            : 1.foc
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Set_Shunt_Ic ( Struct_FOC* foc, int32_t input )
{
	foc->Shunt_Ic = input;
}

/*===========================================================================================
    Function Name    : il_FOC_Set_Angle
    Input            : 1.foc
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Set_Angle ( Struct_FOC* foc, int32_t angle )
{
	foc->Angle = angle;
}

/*===========================================================================================
    Function Name    : il_FOC_Set_Vd
    Input            : 1.foc
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Set_Vd ( Struct_FOC* foc, int32_t input )
{
	foc->Vd = input;
}

/*===========================================================================================
    Function Name    : il_FOC_Set_Vq
    Input            : 1.foc
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Set_Vq ( Struct_FOC* foc, int32_t input )
{
	foc->Vq = input;
}

/*===========================================================================================
    Function Name    : il_FOC_Set_SVM_T_Max
    Input            : 1.foc
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Set_SVM_T_Max ( Struct_FOC* foc, int32_t input )
{
	foc->SVM_T_Max = input;
}


/*===========================================================================================
    Function Name    : il_FOC_Get_Id
    Input            : 1.foc
    Return           : Id
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_FOC_Get_Id ( Struct_FOC* foc )
{
	int32_t value = foc->Shunt_Id;
	return value;
}

/*===========================================================================================
    Function Name    : il_FOC_Get_Iq
    Input            : 1.foc
    Return           : Iq
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_FOC_Get_Iq ( Struct_FOC* foc )
{
	int32_t value = foc->Shunt_Iq;
	return value;
}

/*===========================================================================================
    Function Name    : il_FOC_Get_Va
    Input            : 1.foc
    Return           : Iq
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_FOC_Get_Va ( Struct_FOC* foc )
{
	int32_t value = foc->Va;
	return value;
}

/*===========================================================================================
    Function Name    : il_FOC_Get_Vb
    Input            : 1.foc
    Return           : Iq
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_FOC_Get_Vb ( Struct_FOC* foc )
{
	int32_t value = foc->Vb;
	return value;
}

/*===========================================================================================
    Function Name    : il_FOC_Get_Vc
    Input            : 1.foc
    Return           : Iq
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_FOC_Get_Vc ( Struct_FOC* foc )
{
	int32_t value = foc->Vc;
	return value;
}

/*===========================================================================================
    Function Name    : il_FOC_Shunt_I_Run
    Input            : 1.foc
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_Shunt_I_Run ( Struct_FOC* foc )
{
	//foc->Shunt_Ialpha = ( 2 * foc->Shunt_Ia - foc->Shunt_Ib - foc->Shunt_Ic ) / 3;
	//foc->Shunt_Ibeta = ( foc->Shunt_Ib - foc->Shunt_Ic ) * CONST_SQRT_3 / CONST_3;

    foc->Shunt_Ialpha = (int32_t)( ( (float)( 2 * foc->Shunt_Ia - foc->Shunt_Ib - foc->Shunt_Ic ) ) / 3.0 );
    foc->Shunt_Ibeta = (int32_t)( ( (float)( ( foc->Shunt_Ib - foc->Shunt_Ic ) * CONST_SQRT_3 ) ) / (float)CONST_3 );

	//foc->Shunt_Id = ( il_Cosine( foc->Angle ) * foc->Shunt_Ialpha + il_Sine( foc->Angle ) * foc->Shunt_Ibeta ) >> SINE_TABLE_BIT_NUM;
	//foc->Shunt_Iq = ( il_Cosine( foc->Angle ) * foc->Shunt_Ibeta - il_Sine( foc->Angle ) * foc->Shunt_Ialpha ) >> SINE_TABLE_BIT_NUM;
	foc->Shunt_Id = ( il_Cosine( foc->Angle ) * foc->Shunt_Ialpha + il_Sine( foc->Angle ) * foc->Shunt_Ibeta ) / SINE_TABLE_CONST_1;
	foc->Shunt_Iq = ( il_Cosine( foc->Angle ) * foc->Shunt_Ibeta - il_Sine( foc->Angle ) * foc->Shunt_Ialpha ) / SINE_TABLE_CONST_1;

}

/*===========================================================================================
    Function Name    : il_FOC_IPark_Run
    Input            : 1.foc
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_FOC_IPark_Run ( Struct_FOC* foc )
{
	//foc->Valpha = ( il_Cosine( foc->Angle ) * foc->Vd - il_Sine( foc->Angle ) * foc->Vq ) >> SINE_TABLE_BIT_NUM;
	//foc->Vbeta = ( il_Sine( foc->Angle ) * foc->Vd + il_Cosine( foc->Angle ) * foc->Vq ) >> SINE_TABLE_BIT_NUM;
	foc->Valpha = ( il_Cosine( foc->Angle ) * foc->Vd - il_Sine( foc->Angle ) * foc->Vq ) / SINE_TABLE_CONST_1;
	foc->Vbeta = ( il_Sine( foc->Angle ) * foc->Vd + il_Cosine( foc->Angle ) * foc->Vq ) / SINE_TABLE_CONST_1;
}

/*===========================================================================================
    Function Name    : il_SVPWM_Run
    Input            : 1.foc
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SVPWM_Run ( Struct_FOC* foc )
{
	int32_t T_Sum = 0;

	foc->SVM_V1 = foc->Vbeta;
	foc->SVM_V2 = ( (  CONST_SQRT_3 * foc->Valpha / CONST_1 ) - foc->Vbeta ) / 2;
	foc->SVM_V3 = ( ( -CONST_SQRT_3 * foc->Valpha / CONST_1 ) - foc->Vbeta ) / 2;


	if( foc->SVM_V1 > 0  ){
		foc->SVM_Condtion_A = 1;
	}else{
		foc->SVM_Condtion_A = 0;
	}
	if( foc->SVM_V2 > 0  ){
		foc->SVM_Condtion_B = 1;
	}else{
		foc->SVM_Condtion_B = 0;
	}
	if( foc->SVM_V3 > 0  ){
		foc->SVM_Condtion_C = 1;
	}else{
		foc->SVM_Condtion_C = 0;
	}

	foc->SVM_Sector = Const_Sector_Table[ ( foc->SVM_Condtion_C * 4 + foc->SVM_Condtion_B * 2 + foc->SVM_Condtion_A ) ];

	switch( foc->SVM_Sector ){

	// Can not reach here!!
	case 0:
	case 7:
	default:
		foc->Va = 0;
		foc->Vb = 0;
		foc->Vc = 0;

		break;
	case 1:

		foc->SVM_T1 = CONST_SQRT_3 * foc->SVM_V2 / CONST_1;
		foc->SVM_T2 = CONST_SQRT_3 * foc->SVM_V1 / CONST_1;

		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum > foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->Va = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0 / 2;
		foc->Vb = foc->SVM_T2 + foc->SVM_T0 / 2;
		foc->Vc = foc->SVM_T0 / 2;

		break;
	case 2:
		foc->SVM_T1 = -CONST_SQRT_3 * foc->SVM_V3 / CONST_1;
		foc->SVM_T2 = -CONST_SQRT_3 * foc->SVM_V2 / CONST_1;
		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum > foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->Va = foc->SVM_T1 + foc->SVM_T0 / 2;
		foc->Vb = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0 / 2;
		foc->Vc = foc->SVM_T0 / 2;
		break;
	case 3:
		foc->SVM_T1 = CONST_SQRT_3 * foc->SVM_V1 / CONST_1;
		foc->SVM_T2 = CONST_SQRT_3 * foc->SVM_V3 / CONST_1;
		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum > foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->Va = foc->SVM_T0 / 2;
		foc->Vb = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0 / 2;
		foc->Vc = foc->SVM_T2 + foc->SVM_T0 / 2;
		break;
	case 4:
		foc->SVM_T1 = -CONST_SQRT_3 * foc->SVM_V2 / CONST_1;
		foc->SVM_T2 = -CONST_SQRT_3 * foc->SVM_V1 / CONST_1;
		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum > foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->Va = foc->SVM_T0 / 2;
		foc->Vb = foc->SVM_T1 + foc->SVM_T0 / 2;
		foc->Vc = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0 / 2;
		break;
	case 5:
		foc->SVM_T1 = CONST_SQRT_3 * foc->SVM_V3 / CONST_1;
		foc->SVM_T2 = CONST_SQRT_3 * foc->SVM_V2 / CONST_1;
		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum > foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->Va = foc->SVM_T2 + foc->SVM_T0 / 2;
		foc->Vb = foc->SVM_T0 / 2;
		foc->Vc = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0 / 2;
		break;
	case 6:
		foc->SVM_T1 = -CONST_SQRT_3 * foc->SVM_V1 / CONST_1;
		foc->SVM_T2 = -CONST_SQRT_3 * foc->SVM_V3 / CONST_1;
		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum > foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->Va = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0 / 2;
		foc->Vb = foc->SVM_T0 / 2;
		foc->Vc = foc->SVM_T1 + foc->SVM_T0 / 2;
		break;
	}
}

/*===========================================================================================
    Function Name    : il_SVPWM_RunSimple
    Input            : 1.foc
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SVPWM_RunSimple ( Struct_FOC* foc )
{
	int32_t T_Sum = 0;
	int32_t dummy_v2;
	int32_t dummy_v3;


	foc->SVM_V1 = foc->Vbeta;
	//foc->SVM_V2 = ( (  CONST_SQRT_3 * foc->Valpha / CONST_1 ) - foc->Vbeta ) / 2;
	//foc->SVM_V3 = ( ( -CONST_SQRT_3 * foc->Valpha / CONST_1 ) - foc->Vbeta ) / 2;
	dummy_v2 = CONST_SQRT_3 * foc->Valpha - foc->Vbeta * CONST_1;
	dummy_v3 = -CONST_SQRT_3 * foc->Valpha - foc->Vbeta * CONST_1;

	if( foc->SVM_V1 > 0  ){
		foc->SVM_Condtion_A = 1;
	}else{
		foc->SVM_Condtion_A = 0;
	}
	if( dummy_v2 > 0  ){
		foc->SVM_Condtion_B = 1;
	}else{
		foc->SVM_Condtion_B = 0;
	}
	if( dummy_v3 > 0  ){
		foc->SVM_Condtion_C = 1;
	}else{
		foc->SVM_Condtion_C = 0;
	}

	foc->SVM_Sector = Const_Sector_Table[ ( foc->SVM_Condtion_C * 4 + foc->SVM_Condtion_B * 2 + foc->SVM_Condtion_A ) ];

	switch( foc->SVM_Sector ){

	// Can not reach here!!
	case 0:
	case 7:
	default:
		foc->Va = 0;
		foc->Vb = 0;
		foc->Vc = 0;

		break;
	case 1:	// foc->SVM_Condtion_A = +; foc->SVM_Condtion_B = +;

		foc->SVM_T1 = ( CONST_SQRT3_OVER_2 * ( dummy_v2 >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;
		foc->SVM_T2 = ( CONST_SQRT_3 * foc->SVM_V1 ) >> CONST_1_BIT_NUM;

		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum > foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->SVM_T0 = ( foc->SVM_T0 >> 1 );

		//foc->Va = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0;
		foc->Vb = foc->SVM_T2 + foc->SVM_T0;
		foc->Vc = foc->SVM_T0;

		foc->Va = foc->SVM_T1 + foc->Vb;

		break;
	case 2:	// foc->SVM_Condtion_B = -; foc->SVM_Condtion_C = -;

		foc->SVM_T1 = ( CONST_SQRT3_OVER_2 * ( ( -dummy_v3 ) >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;
		foc->SVM_T2 = ( CONST_SQRT3_OVER_2 * ( ( -dummy_v2 ) >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;

		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum >= foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->SVM_T0 = ( foc->SVM_T0 >> 1 );

		foc->Va = foc->SVM_T1 + foc->SVM_T0;
		//foc->Vb = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0;
		foc->Vc = foc->SVM_T0;

		foc->Vb = foc->Va + foc->SVM_T2;

		break;
	case 3:	// foc->SVM_Condtion_A = +; foc->SVM_Condtion_C = +;

		foc->SVM_T1 = ( CONST_SQRT_3 * foc->SVM_V1 ) >> CONST_1_BIT_NUM;
		foc->SVM_T2 = ( CONST_SQRT3_OVER_2 * ( dummy_v3 >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;

		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum >= foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->SVM_T0 = ( foc->SVM_T0 >> 1 );

		foc->Va = foc->SVM_T0;
		//foc->Vb = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0;
		foc->Vc = foc->SVM_T2 + foc->SVM_T0;

		foc->Vb = foc->SVM_T1 + foc->Vc;

		break;
	case 4: // foc->SVM_Condtion_A = -; foc->SVM_Condtion_B = -;
		foc->SVM_T1 = ( CONST_SQRT3_OVER_2 * ( ( -dummy_v2 ) >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;
		foc->SVM_T2 = ( -CONST_SQRT_3 * foc->SVM_V1 ) >> CONST_1_BIT_NUM;

		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum >= foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->SVM_T0 = ( foc->SVM_T0 >> 1 );

		foc->Va = foc->SVM_T0;
		foc->Vb = foc->SVM_T1 + foc->SVM_T0;
		//foc->Vc = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0;

		foc->Vc = foc->Vb + foc->SVM_T2;

		break;
	case 5:	// foc->SVM_Condtion_B = +; foc->SVM_Condtion_C = +;

		foc->SVM_T1 = ( CONST_SQRT3_OVER_2 * ( dummy_v3 >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;
		foc->SVM_T2 = ( CONST_SQRT3_OVER_2 * ( dummy_v2 >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;

		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum >= foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->SVM_T0 = ( foc->SVM_T0 >> 1 );

		foc->Va = foc->SVM_T2 + foc->SVM_T0;
		foc->Vb = foc->SVM_T0;
		//foc->Vc = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0;

		foc->Vc = foc->Va + foc->SVM_T1;

		break;
	case 6: // foc->SVM_Condtion_A = -; foc->SVM_Condtion_C = -;

		foc->SVM_T1 = ( -CONST_SQRT_3 * foc->SVM_V1 ) >> CONST_1_BIT_NUM;
		foc->SVM_T2 = ( CONST_SQRT3_OVER_2 * ( ( -dummy_v3 ) >> CONST_1_BIT_NUM ) ) >> CONST_1_BIT_NUM;

		T_Sum = foc->SVM_T1 + foc->SVM_T2;
		if( T_Sum >= foc->SVM_T_Max ){
			foc->SVM_T1 = foc->SVM_T1 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T2 = foc->SVM_T2 * foc->SVM_T_Max / T_Sum;
			foc->SVM_T0 = 0;
		}else{
			foc->SVM_T0 = foc->SVM_T_Max - foc->SVM_T1 - foc->SVM_T2;
		}

		foc->SVM_T0 = ( foc->SVM_T0 >> 1 );

		//foc->Va = foc->SVM_T1 + foc->SVM_T2 + foc->SVM_T0;
		foc->Vb = foc->SVM_T0;
		foc->Vc = foc->SVM_T1 + foc->SVM_T0;

		foc->Va = foc->Vc + foc->SVM_T2;

		break;
	}
}

#endif

/************************** <END OF FILE> *****************************************/
