/*===========================================================================================
    File Name       : IO_Func.h
    Built Date      : 2014-08-29
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     :This file provides the IO function command of the driver. (replaced io functions of original BLDC_CTRL)
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef IO_FUNC_H
#define IO_FUNC_H

#include "MD.h"
#include "IO.h"


#define IO_FUNC_MOTOR_CONST         100

extern const uint8_t const_SC_CC_SEL[ 2 ][ 5 ];

/*===========================================================================================
    Command Defines
//==========================================================================================*/
enum{
	CMD_RUN 				= 0,	            // To run motor.
	CMD_FREE				= 1,	            // To free motor.
	CMD_EBRAKE	 			= 2,	            // To brake motor.
	CMD_DIR					= 3,				// To decide motor's spin direction
	CMD_CHANGE_SPEED		= 4,	            // To change motor's speed.
	CMD_NUM					= 5
};


/*===========================================================================================
    IO_func SRC Defines for fixed functions. ( SRC_OTHERS )
//==========================================================================================*/
/*
enum {
	SRC_OTHERS_STOP_BIT				= 0,
	SRC_OTHERS_START_STOP_BIT		= 1,
	SRC_OTHERS_CW_CCW_BIT			= 2,

	SRC_OTHERS_FREE_BIT				= 5,
	SRC_OTHERS_STOP_MODE_BIT		= 6,

	SRC_OTHERS_IMR_BIT				= 9,
	SRC_OTHERS_MR_BIT				= 10,
	SRC_OTHERS_MA_BIT				= 11,

	SRC_OTHERS_CMR_BIT				= 12,

	SRC_OTHERS_EBRAKE_BIT			= 13,

	SRC_OTHERS_KEYSWITCH_BIT		= 14,

	SRC_OTHERS_CMA_BIT				= 15
};
*/

enum {
    SRC_OTHERS_M0_STOP_BIT             = 0,
    //SRC_OTHERS_M1_STOP_BIT             = 1
};

enum {
    SRC_MULTI_DRIVE_STOP_BIT             = 0,
    SRC_MULTI_DRIVE_START_STOP_BIT       = 1,
    SRC_MULTI_DRIVE_CW_CCW_BIT           = 2,

    SRC_MULTI_DRIVE_FREE_BIT             = 5,
    SRC_MULTI_DRIVE_STOP_MODE_BIT        = 6,

    SRC_MULTI_DRIVE_IMR_BIT              = 9,
    SRC_MULTI_DRIVE_MR_BIT               = 10,
    SRC_MULTI_DRIVE_MA_BIT               = 11,

    SRC_MULTI_DRIVE_CMR_BIT              = 12,

    SRC_MULTI_DRIVE_EBRAKE_BIT           = 13,

    SRC_MULTI_DRIVE_KEYSWITCH_BIT        = 14,

    SRC_MULTI_DRIVE_CMA_BIT              = 15
};


/*===========================================================================================
    I/O act functions Define
//==========================================================================================*/
enum{
	FUNC_NO_ACTION			= 0,
	FUNC_START_STOP			= 1,
	FUNC_CW_CCW				= 2,
	FUNC_CW_STOP			= 1,
	FUNC_CCW_STOP			= 2,
	//FUNC_CW_STOP			= 3,
	//FUNC_CCW_STOP			= 4,
	FUNC_FREE				= 5,
	FUNC_STOP_MODE			= 6,
	FUNC_EBA_RESET			= 7,
	FUNC_ALARM_RESET		= 8,
	//FUNC_INT_EXT			= 9,
	FUNC_STOP_MODE2			= 9,
	FUNC_M0					= 10,
	FUNC_M1					= 11,
	//FUNC_M2					= 12,
	FUNC_EBRAKE				= 13,
	FUNC_KEY_SWITCH			= 14,
	FUNC_EFORWARD			= 15,
	FUNC_EREVERSE			= 16,
	
	FUNC_STOP				= 17,		// Do stop when active.
	FUNC_MOS_OT             = 18,
	FUNC_MOTOR_OT           = 19,
	FUNC_RGN_OT             = 20,
	FUNC_EXT_ERROR			= 21,
	//FUNC_KEY_SWITCH2        = 22,
	FUNC_STO_0              = 23,
	FUNC_STO_1              = 24,

	FUNC_CW_LIMIT           = 25,
	FUNC_CCW_LIMIT          = 26,

	FUNC_IMR                = 27,
	FUNC_MR                 = 28,
	FUNC_MA					= 29,

	FUNC_CMR                = 30,
	FUNC_CMA				= 31,

	FUNC_NUM				= 32

};

enum{
	OUTPUT_NC		 		= 0,
	OUTPUT_SPD_OUT 			= 1,
	OUTPUT_ALM_OUT 			= 2,
	OUTPUT_BUSY_OUT  		= 3,
	OUTPUT_VA_OUT 	 		= 4,
	OUTPUT_EN_OUT	 		= 5,
	OUTPUT_ALM_PLUSE		= 6,
	OUTPUT_BUSY_ALM_PLUSE	= 7,
	OUTPUT_WNG				= 8,
	OUTPUT_TLC				= 9,
	OUTPUT_ALM2_OUT			= 10,
	OUTPUT_RUN_OUT		 	= 11,
	OUTPUT_DIR_OUT		 	= 12,
	OUTPUT_PARK_BRAKE 	 	= 13,
	OUTPUT_PARK_BRAKE_RELEASE = 14,
	OUTPUT_VA2_OUT 	 		= 15,
	OUTPUT_VA_EN_OUT		= 16,

	OUTPUT_RELAY_OUT        = 17,
	OUTPUT_BATTERY_GAUGE_1  = 18,
    OUTPUT_BATTERY_GAUGE_2  = 19,
    OUTPUT_RGN_OUT          = 20,

	OUTPUT_BR_ALL           = 21,

	OUTPUT_FUNC_NUM  		= 22
};

typedef struct{
	
	uint8_t 	SC_CC_Mode;							// SC / CC Mode

	uint8_t 	CMD[ SRC_NUM ][ CMD_NUM ];			// commands, see Command Defines at line28 
	uint8_t 	CMD_SRC[ CMD_NUM ];
	uint32_t	IOF_STAT_BITF[ SRC_NUM ];			// IO function state bitfield.
	
	uint8_t		Output_State[ OUTPUT_FUNC_NUM ];
    uint8_t     OutputPin_of_Func[ OUTPUT_FUNC_NUM ];
    uint8_t     ActState_of_Func[ OUTPUT_FUNC_NUM ];

    //
    uint8_t     EncoderPulse_Enable;

    int32_t     EncoderPulse_Stamp;

    int32_t     EncoderPulse_Divider;
    int32_t     EncoderPulse_Divider_P;
    int32_t     EncoderPulse_Divider_N;

    int16_t     EncoderPulse_State;
    int16_t     EncoderPulse_Direction;

    //
    uint32_t    Battery_Gauge_Timer_Ms;

}Struct_IO_FUNC;

/*===========================================================================================
    Function Name    : variableInitial_IO_Func
    Input            : io_func
    Return           : Null
    Programmer       : Gear.Frng@trumman.com.tw
    Description      : Variable io_func initial
                       Should be execute only after parameter initial.
//==========================================================================================*/
void variableInitial_IO_Func ( Struct_IO_FUNC* io_func );

/*===========================================================================================
    Function Name    : ioFunc_NoAction
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : IO command function
//==========================================================================================*/
uint32_t ioFunc_NoAction ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_StartStop
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of START/STOP to determine the CMD_RUN state.
//==========================================================================================*/
uint32_t ioFunc_StartStop ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_CWCCW
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of CW/CCW to determine CMD_DIR state.
//==========================================================================================*/
uint32_t ioFunc_CWCCW ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_CWStop
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of CW/STOP to determine RUN and DIR state.
//==========================================================================================*/
uint32_t ioFunc_CWStop ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_CCWStop
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of CW/STOP to determine RUN and DIR state.
//==========================================================================================*/
uint32_t ioFunc_CCWStop ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_EBrake
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of EBrake to determine CMD_EBRAKE state.
//==========================================================================================*/
uint32_t ioFunc_EBrake ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_EBAReset
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command EBAReset to determine CMD_EBRAKE state.
//==========================================================================================*/
uint32_t ioFunc_EBAReset ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_KeySwitch
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_KeySwitch ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_Free
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command to determine CMD_FREE.
//==========================================================================================*/
uint32_t ioFunc_Free ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_StopMode
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_StopMode ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_NormalIO
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_NormalIO ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_STOP
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_STOP ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_MOS_OT
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command of IO type OT.
//==========================================================================================*/
uint32_t ioFunc_MOS_OT ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_MOTOR_OT
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command of IO type OT.
//==========================================================================================*/
uint32_t ioFunc_MOTOR_OT ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_RGN_OT
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command of IO type OT.
//==========================================================================================*/
uint32_t ioFunc_RGN_OT ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_EXT_ERROR
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command.
//==========================================================================================*/
uint32_t ioFunc_EXT_ERROR ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 );

/*===========================================================================================
    Function Name    : ioFunc_Polling_routine
    Input            : 1. io
                       2. io_func_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : io Stat routine. Called in main loop.
//==========================================================================================*/
void ioFunc_Polling_routine ( Struct_IO* io, Struct_IO_FUNC* io_func_m0 );

/*===========================================================================================
    Function Name    : stop_command_determine
    Input            : Null
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Determine the FUNC_STOP of VR ( or zero speed sill in consideration )
                       Called in main loop.
//==========================================================================================*/
void stop_command_determine ( void );

/*===========================================================================================
    Function Name    : vrFunc_StartStop
    Input            : 
                       1.adc_value: ADC value
                       2.stop value : Stop value
                       3.run_value : Run value
                       4.stop_bit
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Function for VR Min stop.
//==========================================================================================*/
void vrFunc_StartStop ( uint32_t adc_value, uint32_t stop_value, uint32_t run_value, int32_t stop_bit );

/*===========================================================================================
    Function Name    : vrFunc_Advance
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void vrFunc_Advance ( void );

/*===========================================================================================
    Function Name    : output_ShowInBITF
    Input            : Struct_IO_FUNC* io_func
    Return           : Output state in BITF.
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Return BITF of all outputs
                        bit0 = NC
                        bit1 = Output function 1 status
                        bit2 = output function 2 status...
//==========================================================================================*/
int32_t output_ShowInBITF ( Struct_IO_FUNC* io_func );

#endif

/************************** <END OF FILE> *****************************************/
