/*===========================================================================================

    File Name       : IDA1_Parameter.c

    Version         : V1_00_00_a

    Built Date      : 2015/03/12

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw

    Description     : This file provides the functions for parameter acessing.
				
    =========================================================================================

    History         : 2015/03/12 Perlimary version.  ( by Chaim )
					  

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

extern volatile Struct_MD CG_MD;

		volatile Struct_Parameter						CG_Parameter;
/************************** EXTERNAL VARIABLES ********************************/
//extern 	volatile Struct_PhaseAdv 					CG_PhaseAdv;
extern 	volatile Struct_ADC 							CG_ADC;
extern  volatile Struct_IO								CG_IO;
extern volatile Struct_IO_FUNC                          CG_IO_Func_M0;
//extern volatile Struct_IO_FUNC                          CG_IO_Func_M1;
extern volatile Struct_Encoder 							CG_Encoder;
extern volatile Struct_GPIO                 			CG_GPIO;
extern volatile Struct_IO								CG_IO;
extern volatile Struct_Pretect 							CG_Protect;
//extern volatile Struct_BLDC_CTRL 						CG_BLDC_CTRL;
extern volatile Struct_BLDC_CTRL                        CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL                        CG_BLDC_CTRL_M1;
extern volatile Struct_OPMode 							CG_OPMode;
extern volatile Struct_BLDC_Drive 						CG_BLDC_Drive_M0;
//extern volatile Struct_Speed 							CG_Speed;
extern volatile Struct_HWEEP							CG_HWEEP;	/* HWEEP for hardware limit */
extern volatile Struct_Move 							CG_Move;
extern volatile Struct_Modbus_Slave						CG_Modbus_Slave;
extern volatile Struct_Modbus_Slave						CG_Modbus_Slave_485;
extern volatile Struct_ComProtocol_01					CG_ComProtocol_01;
extern volatile Struct_I2C 								CG_I2C;
extern volatile Struct_UART485  						CG_UART485;
extern volatile Struct_SPK 								CG_SPK;
extern volatile Struct_PI                               CG_PI;
extern volatile Struct_MDL                              CG_MDL;
//extern volatile Struct_IO_Expander                      CG_IO_Expander;
extern volatile Struct_CAN                              CG_CAN;

extern void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void );

extern void ( *const opMode_Handler[ OP_MODE_NUM ] ) ( uint32_t digit_num );


// Parameter real time updated allowed setting bit field (0: can only change when motor not running, 1: can change while motor is running)
const uint32_t CG_RealTime_Paramter_BITF[ PARAMETER_MAJOR_NUM ] =
	{
		// bit0 means minor 0
		_0B32(00000000, 00000000, 00000000, 00000000),
		_0B32(00000000, 00000000, 00000000, 00000000),
		_0B32(00001111, 11111111, 00001111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(00000000, 00000000, 00000000, 00000000),
		_0B32(00000000, 00000000, 00000000, 00000000),
		_0B32(00000000, 00000000, 00000000, 00000000),
		_0B32(00000000, 00000000, 00000000, 00000000),
		_0B32(00000000, 00000001, 00000000, 00000000)

	};

// Parameter write enable setting bit field ( 0: Read only, 1: write/read )
const uint32_t CG_WriteEn_Paramter_BITF[ PARAMETER_MAJOR_NUM ] =
	{
		// bit0 means minor 0
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111),
		_0B32(11111111, 11111111, 11111111, 11111111)

	};

/*===========================================================================================
    Function Name    : variableInitial_Parameter
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Parameter initial
//==========================================================================================*/
void variableInitial_Parameter( void )
{
	int32_t i;
	
	for( i = 0; i < PARAMETER_MONITOR_DATA_NUM; i++ ){
		CG_Parameter.Monitor_data_M0		[ i ] = 0;
		//CG_Parameter.Monitor_data_M1        [ i ] = 0;
		CG_Parameter.Monitor_data_Engineer	[ i ] = 0;
	}
	
	for( i = 0; i < PARAMETER_MINOR_NUM; i++ ){
	    CG_Parameter.dynamic_data[i] = 0;
	}

}

/*===========================================================================================
    Function Name    : update_MonitorData
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : update monitor data
//==========================================================================================*/
void update_MonitorData( void )
{
#if(1)
#if(TEST_MONITOR_DATA_OPEN)

	static int8_t user = 0;

	user ^= 1;

	if( user ){

	    CG_Parameter.Monitor_data_M0[0] = CG_BLDC_CTRL_M0.Motor_State & 65535;
	    CG_Parameter.Monitor_data_M0[1] = CG_BLDC_CTRL_M0.Protect_Ptr->first_fault_user & 65535;
	    CG_Parameter.Monitor_data_M0[2] = CG_BLDC_CTRL_M0.OpMode_Ptr->Digit_Num & 65535;

	    CG_Parameter.Monitor_data_M0[3] = CG_BLDC_CTRL_M0.Target_Speed_RPM & 65535;
	    CG_Parameter.Monitor_data_M0[4] = CG_BLDC_CTRL_M0.Current_RPM & 65535;
	    CG_Parameter.Monitor_data_M0[5] = CG_GPIO.Xn_State_BITF & 65535;

	    CG_Parameter.Monitor_data_M0[6] = CG_BLDC_CTRL_M0.ADC_Ptr->Power & 65535;
	    CG_Parameter.Monitor_data_M0[7] = CG_ADC.BusV & 65535;
	    CG_Parameter.Monitor_data_M0[8] = CG_BLDC_CTRL_M0.Current_Duty_Display & 65535;
	    CG_Parameter.Monitor_data_M0[9] = ( CG_BLDC_CTRL_M0.ADC_Ptr->Shunt_I_Avg / TORQUE_J06TOI04_GAIN ) & 65535;
	    CG_Parameter.Monitor_data_M0[10] = ( CG_BLDC_CTRL_M0.OpMode_Ptr->Torque_Limit / TORQUE_J06TOI04_GAIN ) & 65535;

	    CG_Parameter.Monitor_data_M0[11] = CG_BLDC_CTRL_M0.OpMode_Ptr->Acc_Time & 65535;
	    CG_Parameter.Monitor_data_M0[12] = CG_BLDC_CTRL_M0.OpMode_Ptr->Dec_Time & 65535;

	    CG_Parameter.Monitor_data_M0[13] = ( CG_ADC.Value_Mapping[ ADC_Index_A0X ] / THROTTLE_MULTIFY ) & 65535;
	    CG_Parameter.Monitor_data_M0[14] = ( CG_ADC.Value_Mapping[ ADC_Index_A1X ] / THROTTLE_MULTIFY ) & 65535;
	    CG_Parameter.Monitor_data_M0[15] = ( CG_PI.Channel[ PI_XH0 ].Image_VR / PI_MULTIFY ) & 65535;
	    CG_Parameter.Monitor_data_M0[16] = CG_PI.Channel[ PI_XH0 ].Freq & 65535;

	    CG_Parameter.Monitor_data_M0[17] = CG_GPIO.Yn_State_BITF & 65535;

	    CG_Parameter.Monitor_data_M0[18] = CG_BLDC_CTRL_M0.Hall_Ptr->Position & 65535;
	    CG_Parameter.Monitor_data_M0[19] = mcIndexDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
	    CG_Parameter.Monitor_data_M0[20] = mcPosDisplay_Target( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
	    CG_Parameter.Monitor_data_M0[21] = mcIndexDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
	    CG_Parameter.Monitor_data_M0[22] = mcPosDisplay_Current( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;

	    //
	    CG_Parameter.Monitor_data_M0[23] = ( CG_PI.Channel[ PI_XH1 ].Image_VR / PI_MULTIFY ) & 65535;
        CG_Parameter.Monitor_data_M0[24] = CG_PI.Channel[ PI_XH1 ].Freq & 65535;

        CG_Parameter.Monitor_data_M0[25] = HALL_SIGNAL_M0;  // This is encoder/hall signals ( Motor ABC )
        CG_Parameter.Monitor_data_M0[26] = MOTOR_S2S1S0_SIGNAL_M0;  // This is motor S2 S1 S0 signals
        CG_Parameter.Monitor_data_M0[27] = CG_Encoder.Motor_0.Pos_Reg & 65535;
        CG_Parameter.Monitor_data_M0[28] = CG_BLDC_CTRL_M0.Drive_Ptr->FOC.SensorAngle & 65535;

        CG_Parameter.Monitor_data_M0[29] = CG_Protect.Motor_0.MosNTC_1.Temperature & 65535;
        CG_Parameter.Monitor_data_M0[30] = CG_Protect.Motor_0.MosNTC_2.Temperature & 65535;
        CG_Parameter.Monitor_data_M0[31] = CG_Protect.Motor_0.MosNTC_3.Temperature & 65535;

	} else{

	    CG_Parameter.Monitor_data_Engineer[0] = CG_ADC.Value_Avg[ ADC_Index_M0_Shunt_U ] & 65535;
        CG_Parameter.Monitor_data_Engineer[1] = CG_ADC.Value_Avg[ ADC_Index_M0_Shunt_V ] & 65535;
        CG_Parameter.Monitor_data_Engineer[2] = CG_ADC.Value_Avg[ ADC_Index_M0_Shunt_W ] & 65535;
        CG_Parameter.Monitor_data_Engineer[3] = CG_ADC.Value_Inst[ ADC_Index_MosOT_1 ] & 65535;
        CG_Parameter.Monitor_data_Engineer[4] = CG_ADC.Value_Inst[ ADC_Index_MosOT_2 ] & 65535;
        CG_Parameter.Monitor_data_Engineer[5] = CG_ADC.Value_Inst[ ADC_Index_MosOT_3 ] & 65535;
        CG_Parameter.Monitor_data_Engineer[6] = CG_ADC.Value_Avg[ ADC_Index_A0X ] & 65535;
        CG_Parameter.Monitor_data_Engineer[7] = CG_ADC.Value_Avg[ ADC_Index_A1X ] & 65535;
        CG_Parameter.Monitor_data_Engineer[8] = CG_ADC.Value_Avg[ ADC_Index_BusV ] & 65535;
        CG_Parameter.Monitor_data_Engineer[9] = CG_ADC.Value_Inst[ ADC_Index_VCC5V_SENSE ] & 65535;
        CG_Parameter.Monitor_data_Engineer[10] = CG_ADC.Value_Inst[ ADC_Index_POUT1_FB ] & 65535;


        CG_Parameter.Monitor_data_Engineer[11] = CG_ADC.Value_Inst[ ADC_Index_POUT2_FB ] & 65535;
        CG_Parameter.Monitor_data_Engineer[12] = CG_ADC.Value_Inst[ ADC_Index_M0_BEMF_U ] & 65535;
        CG_Parameter.Monitor_data_Engineer[13] = CG_ADC.Value_Inst[ ADC_Index_M0_BEMF_V ] & 65535;
        CG_Parameter.Monitor_data_Engineer[14] = CG_ADC.Value_Inst[ ADC_Index_M0_BEMF_W ] & 65535;

        CG_Parameter.Monitor_data_Engineer[15] = CG_I2C.is_OK_Flag & 65535;

        //

        CG_Parameter.Monitor_data_Engineer[16] = ( CG_BLDC_Drive_M0.FOC.Vq ) & 65535;
        CG_Parameter.Monitor_data_Engineer[17] = ( CG_BLDC_Drive_M0.FOC.Vd ) & 65535;

        CG_Parameter.Monitor_data_Engineer[18] = ( CG_BLDC_Drive_M0.FOC.Shunt_Iq ) & 65535;
        CG_Parameter.Monitor_data_Engineer[19] = ( CG_BLDC_Drive_M0.FOC.Shunt_Id ) & 65535;

        CG_Parameter.Monitor_data_Engineer[20] = ( CG_BLDC_Drive_M0.FOC.Angle ) & 65535;
        CG_Parameter.Monitor_data_Engineer[21] = CG_BLDC_Drive_M0.FOC.SensorAngle & 65535;

        //
        CG_Parameter.Monitor_data_Engineer[22] = 0;
        CG_Parameter.Monitor_data_Engineer[23] = 0;
        CG_Parameter.Monitor_data_Engineer[24] = 0;
        CG_Parameter.Monitor_data_Engineer[25] = 0;
        CG_Parameter.Monitor_data_Engineer[26] = 0;

        CG_Parameter.Monitor_data_Engineer[27] = 0;
        CG_Parameter.Monitor_data_Engineer[28] = 0;
        CG_Parameter.Monitor_data_Engineer[29] = 0;
        CG_Parameter.Monitor_data_Engineer[30] = CG_GPIO.OtherInput_State_BITF & 65535;
        CG_Parameter.Monitor_data_Engineer[31] = CG_GPIO.OtherOutput_State_BITF & 65535;

	}
#endif
#endif

}

/*===========================================================================================
    Function Name    : readFWEEP
    Input            : Null
    Return           : result : 1 = good, 0 = bad
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : readFWEEP
//==========================================================================================*/
uint32_t readFWEEP( void )
{
	uint32_t result 	= 1;
#if( TEST_EEP_OPEN )
	uint32_t i;

	for ( i = 0; i < PARAMETER_MAJOR_NUM; i++ ) {
		result &= readEEPParameter( i );		 // current value
		result &= readEEPParameter( i+10 );   // default
		result &= readEEPParameter( i+20 );   // max
		result &= readEEPParameter( i+30 );   // min
		ServiceDog();
	}

	readEEP ( 50, HIST_ARRAY_SIZE, (int32_t*)&CG_Protect.Alarm_His_EEP );
	updateSpeceilParameter();
#endif

	return result;
}

/*===========================================================================================
    Function Name    : readEEP
    Input            : 1. major_index: Data major index.
					   2. data_num: the number of data to load.
					   3. *dst: the destination array to put data.
    Return           : true or false, return flase if EEP error (out of flash range).
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Load EEP data of a major to the destiny data array. 
//==========================================================================================*/
uint32_t readEEP ( const uint32_t major_index, const uint32_t data_num, int32_t* dst )
{
	uint32_t result 	= 1;

	uint32_t address 	= PARAMETER_EEP_ADDRESS( major_index );
	uint8_t  dummy_data[ PARAMETER_MULTI_ACCESS_SIZE ] = {0};
	int32_t  temp_data;
	uint32_t i; // functional counter

	readData_I2C( FW_EEP_ADDRESS, FW_EEP_TYPE, address, dummy_data, PARAMETER_MULTI_ACCESS_SIZE );

	for (i=0; i<data_num; i++) {
		
		temp_data = dummy_data[ i * 2 + 0 ] * 256 + 
                    dummy_data[ i * 2 + 1 ];
		
		*(dst++)  = temp_data;

	}
	
	return (result);
}

/*===========================================================================================
    Function Name    : readEEPParameter
    Input            : 1. major_index: Data major index
    Return           : true or false, return flase if EEP error (out of flash range).
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Load EEP data to parameter 
//==========================================================================================*/
uint32_t readEEPParameter( uint32_t major_index )
{
	uint32_t 	result = 1;

    uint8_t 	dummy_data[ PARAMETER_MULTI_ACCESS_SIZE ] = {0};
    uint32_t 	address = 0;
    int32_t 	temp_data;
    int32_t 	i;

    address = PARAMETER_EEP_ADDRESS( major_index );

    readData_I2C( FW_EEP_ADDRESS, FW_EEP_TYPE, address, dummy_data, PARAMETER_MULTI_ACCESS_SIZE );
  

    for( i = 0; i < PARAMETER_MINOR_NUM; i++ ){
            
        temp_data = dummy_data[ i * 2 + 0 ] * 256 +
                    dummy_data[ i * 2 + 1 ];

		// Range check with const table.
#if(0)
        //if( temp_data > CG_CONST_eep_parameter_Max[ major_index % 10 ][ i ] ||
		//	temp_data < CG_CONST_eep_parameter_Min[ major_index % 10 ][ i ] ){
		if( temp_data > CG_CONST_eep_parameter_Max[ MOD( major_index, 10 ) ][ i ] ||
			temp_data < CG_CONST_eep_parameter_Min[ MOD( major_index, 10 ) ][ i ] ){
		
			result = 0;
		}
#endif
        if( major_index < 10 ){

            CG_Parameter.RAM_data[ major_index ][ i ] = temp_data;
			CG_Parameter.EEP_data[ major_index ][ i ] = temp_data;			

        }else{

            if( major_index / 10 == 1 ){
                
                //CG_Parameter.EEP_data_default[ major_index % 10 ][ i ] = temp_data;
				CG_Parameter.EEP_data_default[ MOD( major_index, 10 ) ][ i ] = temp_data;

            }else if( major_index / 10 == 2 ){

                //CG_Parameter.EEP_data_max[ major_index % 10 ][ i ] = temp_data;
				CG_Parameter.EEP_data_max[ MOD( major_index, 10 ) ][ i ] = temp_data;//CG_CONST_eep_parameter_Max[ MOD( major_index, 10 ) ][ i ];

            }else if( major_index / 10 == 3 ){

                //CG_Parameter.EEP_data_min[ major_index % 10 ][ i ] = temp_data;
				CG_Parameter.EEP_data_min[ MOD( major_index , 10 ) ][ i ] = temp_data;//CG_CONST_eep_parameter_Min[ MOD( major_index, 10 ) ][ i ];

            }

        }

    } 

	
	return result;
}

/*===========================================================================================
    Function Name    : saveEEPParameter
    Input            : 1. major_index: Data major index
					   2. minor_index: Data minor index
					   3. data:		   Data that will be saved.
					   4. eepWO: EEP write only flag. 1:eep write only, 0: eep write and check.
    Return           : Result: when write and check return the check result: 1:eep ok, 0:eep bad(data not match).
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Save single parameter to EEP. (and update RAM)
//==========================================================================================*/
uint8_t saveEEPParameter_Single( const uint32_t major_index, const uint32_t minor_index, const int32_t data, const uint32_t eepWO )
{
	uint8_t Result =1;

	uint8_t dummy_data[2] = {0};
    int32_t address = 0;


    address = PARAMETER_EEP_ADDRESS( major_index ) + minor_index * PARAMETER_DATA_SIZE;

    dummy_data[0] = data / 256;
    //dummy_data[1] = data % 256;
	dummy_data[1] = MOD( data, 256 );

	if (eepWO == YES) {
		writeData_I2C( FW_EEP_ADDRESS, FW_EEP_TYPE, address, dummy_data, PARAMETER_DATA_SIZE );
	} else {
		Result &= writeAndCheckDataEEP( FW_EEP_ADDRESS, FW_EEP_TYPE, address, dummy_data, PARAMETER_DATA_SIZE );
	}

	if ( major_index < (COM_PA_EEP_INDEX+9) ) {
		//CG_Parameter.RAM_data[ major_index%PARAMETER_MAJOR_NUM ][ minor_index%PARAMETER_MINOR_NUM ] = data;
		//CG_Parameter.EEP_data[ major_index%PARAMETER_MAJOR_NUM ][ minor_index%PARAMETER_MINOR_NUM ] = data;
		CG_Parameter.RAM_data[ MOD( major_index, PARAMETER_MAJOR_NUM ) ][ MOD( minor_index, PARAMETER_MINOR_NUM ) ] = data;
		CG_Parameter.EEP_data[ MOD( major_index, PARAMETER_MAJOR_NUM ) ][ MOD( minor_index, PARAMETER_MINOR_NUM ) ] = data;
	}

	return (Result);
}

#if(0)
/*===========================================================================================
    Function Name    : saveEEPParameter_Multiple
    Input            : 1. major_index : major address of the start address of pa.
					   2. minor_index : minor address of the start address of pa.
					   3. quant_of_reg : the data quantity to save.
					   4. *data : CG_Modbus_Slave.req_pdu_data[i]. the data value.
					   5. eepWO: EEP write only flag. 1:eep write only, 0: eep write and check.
    Return           : Result: when write and check return the check result: 1:eep ok, 0:eep bad(data not match).
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Save multiple parameter to EEP. (and update RAM)
					   Each data takes 2 bytes.
					   The max quantity of bytes can be saved to EEP is limited by the EEP (MAX_OP_BYTE_NUM).
					   If the bytes to be saved is more than this number. Then seperate the data
					   into groups for several times.
//==========================================================================================*/
uint8_t saveEEPParameter_Multiple( const uint32_t major_index, const uint8_t minor_index,
							    const int32_t quant_of_reg, const int32_t *data, const uint32_t eepWO )
{

    uint8_t Result =1;

	uint32_t byte_num 		= 2 * quant_of_reg;  		// byte number of parameter set. 2 bytes for each reg.
	uint32_t dummy_counter	= 0;
	uint32_t major_loop		= 0;						// the number of outter for loop.
	uint32_t minor_loop		= 0;                        // the number of inner for loop.
	uint32_t i				= 0;
	uint32_t j				= 0;
	uint8_t dummy_data[ MAX_OP_BYTE_NUM ];
	uint32_t address 		= 0;
	uint32_t last_i			= 0;
	uint32_t sec_colom_num	= 0;
	
	major_loop = byte_num / MAX_OP_BYTE_NUM;
	//minor_loop = byte_num % MAX_OP_BYTE_NUM;
	minor_loop = MOD( byte_num, MAX_OP_BYTE_NUM );
	
	for( i = 0; i < major_loop; i++ ){
		// Save each sector in EEP each time.
        for( j = 0; j < MAX_OP_BYTE_NUM;  ){

            dummy_data[ j ]     = data[ dummy_counter ]/256;
			//dummy_data[ j + 1 ] = data[ dummy_counter ]%256; 
			dummy_data[ j + 1 ] = MOD( data[ dummy_counter ], 256 ); 
                
            j+= 2;
            dummy_counter++;
            
        }   

		// address = start adress + number of register to write at once.
		address = PARAMETER_EEP_ADDRESS( major_index ) + minor_index * PARAMETER_DATA_SIZE + i*MAX_OP_BYTE_NUM;

		if (eepWO == YES) {
			writeData_I2C( FW_EEP_ADDRESS, FW_EEP_TYPE, address,
						  ( unsigned char * ) ( dummy_data ), MAX_OP_BYTE_NUM );
		} else {
			Result &= writeAndCheckDataEEP( FW_EEP_ADDRESS, FW_EEP_TYPE, address,
						  ( unsigned char * ) ( dummy_data ), MAX_OP_BYTE_NUM );
		}

        //for(j=0;j<80000;j++);
    }
	
	last_i		 = i;
	
	// dummy_data clear
	for( j = 0; j < MAX_OP_BYTE_NUM; j++ ){
        dummy_data[j] = 0;
    }
	
	// last section to write..
	for( i = 0; i < minor_loop; ){
		dummy_data[ i ]     = data[ dummy_counter ]/256 ;
        //dummy_data[ i + 1 ] = data[ dummy_counter ]%256;
		dummy_data[ i + 1 ] = MOD( data[ dummy_counter ], 256 );
        i+= 2 ;
        dummy_counter++;
    }
	
	if( minor_loop != 0 ){
		address = PARAMETER_EEP_ADDRESS( major_index ) + minor_index * PARAMETER_DATA_SIZE + last_i*MAX_OP_BYTE_NUM;
		
		if (eepWO == YES) {
			writeData_I2C( FW_EEP_ADDRESS, FW_EEP_TYPE, address,
						  ( unsigned char * ) ( dummy_data ), minor_loop );	//minor_loop
		} else {
			Result &= writeAndCheckDataEEP( FW_EEP_ADDRESS, FW_EEP_TYPE, address,
						  ( unsigned char * ) ( dummy_data ), minor_loop );
		}
	}
	
	// check if paramter
	if ( major_index < (COM_PA_EEP_INDEX+9) ) {
		if ( (minor_index + quant_of_reg) > PARAMETER_MINOR_NUM ) {
			// update next major if parameter
			j = PARAMETER_MINOR_NUM - minor_index;
			sec_colom_num = quant_of_reg - j;
			for (i=0; i<sec_colom_num; i++) {
				//CG_Parameter.EEP_data[ (major_index+1)%PARAMETER_MAJOR_NUM ][ i%PARAMETER_MINOR_NUM ] = data[j+i];
				//CG_Parameter.RAM_data[ (major_index+1)%PARAMETER_MAJOR_NUM ][ i%PARAMETER_MINOR_NUM ] = data[j+i];
				
				CG_Parameter.EEP_data[ MOD( major_index + 1, PARAMETER_MAJOR_NUM ) ][ MOD( i, PARAMETER_MINOR_NUM ) ] = data[j+i];
				CG_Parameter.RAM_data[ MOD( major_index + 1, PARAMETER_MAJOR_NUM ) ][ MOD( i, PARAMETER_MINOR_NUM ) ] = data[j+i];
				
			}
		} else {
			j = quant_of_reg;
		}
		for (i=0; i<j; i++) {
			//CG_Parameter.EEP_data[ (major_index)%PARAMETER_MAJOR_NUM ][ (minor_index+i)%PARAMETER_MINOR_NUM ] = data[i];
			//CG_Parameter.RAM_data[ (major_index)%PARAMETER_MAJOR_NUM ][ (minor_index+i)%PARAMETER_MINOR_NUM ] = data[i];
			
			CG_Parameter.EEP_data[ MOD( major_index, PARAMETER_MAJOR_NUM ) ][ MOD( minor_index+i, PARAMETER_MINOR_NUM ) ] = data[i];
			CG_Parameter.RAM_data[ MOD( major_index, PARAMETER_MAJOR_NUM ) ][ MOD( minor_index+i, PARAMETER_MINOR_NUM ) ] = data[i];
		}
	}

	return (Result);
	
}
#else
/*===========================================================================================
    Function Name    : saveEEPParameter_Multiple
    Input            : 1. major_index : major address of the start address of pa.
                       2. minor_index : minor address of the start address of pa.
                       3. quant_of_reg : the data quantity to save.
                       4. *data : CG_Modbus_Slave.req_pdu_data[i]. the data value.
                       5. eepWO: EEP write only flag. 1:eep write only, 0: eep write and check.
    Return           : Result: when write and check return the check result: 1:eep ok, 0:eep bad(data not match).
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Save multiple parameter to EEP. (and update RAM)
                       Each data takes 2 bytes.
                       The max quantity of bytes can be saved to EEP is limited by the EEP (MAX_OP_BYTE_NUM).
                       If the bytes to be saved is more than this number. Then seperate the data
                       into groups for several times.
//==========================================================================================*/
uint8_t saveEEPParameter_Multiple( const uint32_t major_index, const uint8_t minor_index,
                                const int32_t quant_of_reg, const int32_t *data, const uint32_t eepWO )
{

    uint8_t Result =1;
    uint32_t i;
    uint8_t dummy_data[ MAX_OP_BYTE_NUM ];
    uint32_t address        = 0;
    uint32_t address_limit;
    uint32_t address_dummy;
    uint32_t byte_cnt = 0;         // byte number of parameter set. 2 bytes for each reg

    address = PARAMETER_EEP_ADDRESS( major_index ) + minor_index * PARAMETER_DATA_SIZE;
    address_dummy = address;
    address_limit = address & ( ~( 0x0001F ) );
    address_limit += MAX_OP_BYTE_NUM;

    for( i = 0; i < quant_of_reg; i++ ){

        dummy_data[ byte_cnt++ ] = data[ i ] / 256;
        dummy_data[ byte_cnt++ ] = MOD( data[ i ], 256 );
        address_dummy += PARAMETER_DATA_SIZE;

        if( address_dummy >= address_limit || i == quant_of_reg - 1 ){

            if (eepWO == YES) {
                writeData_I2C( FW_EEP_ADDRESS, FW_EEP_TYPE, address,
                              ( unsigned char * ) ( dummy_data ), byte_cnt );
            } else {
                Result &= writeAndCheckDataEEP( FW_EEP_ADDRESS, FW_EEP_TYPE, address,
                              ( unsigned char * ) ( dummy_data ), byte_cnt );
            }

            byte_cnt = 0;
            address = address_limit;
            address_limit += MAX_OP_BYTE_NUM;

        }

    }

    // check if paramter
    if ( major_index < PARAMETER_MAJOR_NUM ) {
        for( i = 0; i < quant_of_reg; i++ ){
            if( minor_index + i < PARAMETER_MINOR_NUM ){
                CG_Parameter.EEP_data[ major_index ][ minor_index + i ] = data[i];
                CG_Parameter.RAM_data[ major_index ][ minor_index + i ] = data[i];
            }
        }
    }

    return (Result);

}

#endif

/*===========================================================================================
    Function Name    : copy_Single_EEP_to_RAM_Pa
    Input            : 
					   1. major: Data major index
					   2. minor: Data minor index
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update speceil parameters.
//==========================================================================================*/
void copy_Single_EEP_to_RAM_Pa( uint8_t major, uint8_t minor )
{
	// % added to avoid hard fault.
	//CG_Parameter.RAM_data[ major%PARAMETER_MAJOR_NUM ][ minor%PARAMETER_MINOR_NUM ] =
	//CG_Parameter.EEP_data[ major%PARAMETER_MAJOR_NUM ][ minor%PARAMETER_MINOR_NUM ];
	
	CG_Parameter.RAM_data[ MOD( major, PARAMETER_MAJOR_NUM ) ][ MOD( minor, PARAMETER_MINOR_NUM ) ] =
	CG_Parameter.EEP_data[ MOD( major, PARAMETER_MAJOR_NUM ) ][ MOD( minor, PARAMETER_MINOR_NUM ) ];
}

/*===========================================================================================
    Function Name    : parameter_Range_Check
    Input            : 1. major: modbus address_h - 1 (mapping from com address to eep address)
					   2. minor: minor index of the parameter.
					   3. data: value to check.
    Return           : return_value: true or false, return flase if out of range.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : check parameter, def range with max, min.
					   check max, min with constant flash table
//==========================================================================================*/
uint8_t parameter_Range_Check ( int32_t major, int32_t minor, int32_t data )
{
	int32_t DataMax = 0;
	int32_t DataMin = 0;
	uint8_t return_value = 0;
	major = major - 1;	// mapping com address to eep address.
		
	if ( (major < (COM_MAX_EEP_INDEX-1)) || (major >= (COM_PA_RAM_INDEX-1)) ) {	// Value and default
		//DataMax = CG_Parameter.EEP_data_max[ (major%10) ][ minor ];
		//DataMin = CG_Parameter.EEP_data_min[ (major%10) ][ minor ];
		
		DataMax = CG_Parameter.EEP_data_max[ MOD( major, 10 ) ][ minor ];
		DataMin = CG_Parameter.EEP_data_min[ MOD( major, 10 ) ][ minor ];
	} else {	// max and min
		//DataMax = CG_CONST_eep_parameter_Max[ (major%10) ][ minor ];
		//DataMin = CG_CONST_eep_parameter_Min[ (major%10) ][ minor ];
		
		DataMax = EEP_PARAMETER_MAX;//CG_CONST_eep_parameter_Max[ MOD( major, 10 ) ][ minor ];
		DataMin = EEP_PARAMETER_MIN;//CG_CONST_eep_parameter_Min[ MOD( major, 10 ) ][ minor ];
	}
	
	if ( (data <= DataMax) && (data >= DataMin) ) {
		return_value =  1;
	} else {
		return_value =  0;
	}


	return (return_value);

}

/*===========================================================================================
    Function Name    : multi_parameter_Range_Check
    Input            : 1. major: modbus address_h - 1 (mapping from com address to eep address)
					   2. minor: minor index of the parameter.
					   3. quantity_of_data : the data number to check.
					   4. *data : the data value array pointer.
    Return           : return_value: true or false, return false if out of range.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : check multiple parameter range.
//==========================================================================================*/
uint8_t multi_parameter_Range_Check ( int32_t major, int32_t minor, int32_t quantity_of_data, int32_t *data,
									   int32_t *fault_major,  int32_t *fault_minor )
{
	uint8_t i;
	uint8_t return_value = 1;
	
	for ( i=0; i<quantity_of_data; i++ ) {
	
		return_value &= parameter_Range_Check ( major, minor, data[i] );
		
		if ( return_value == 0 ) {
			//*fault_major = (major%10);
			*fault_major = MOD( major, 10 );
			*fault_minor = minor+1;
			return ( return_value );
		}

		if ( (++minor) == PARAMETER_MINOR_NUM ) {
			major += 1;
			minor = 0;
		}		
	}	
	

	return (return_value);

}

/*===========================================================================================
    Function Name    : multi_parameter_WriteEn_Check
    Input            : 1. major: major index of the parameter.
					   2. minor: minor index of the parameter.
					   3. data_num: the data number to check.
    Return           : return_value: true or false, return false if any of the value is not allowed to change.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : check multiple data write with the writeEN bit field.
					   Return false if any of the value is not allowed to change.
//==========================================================================================*/
uint8_t multi_parameter_WriteEn_Check ( uint8_t major, uint8_t minor, int32_t data_num )
{
	uint8_t i;
	uint8_t return_value = 1;
	
	for (i=0; i<data_num; i++) {
		return_value  &= ((CG_WriteEn_Paramter_BITF[ major ] >> minor) & 0x01);

		if ( (++minor) == PARAMETER_MINOR_NUM ) {
			major += 1;
			minor = 0;
		}
	}
	
	return (return_value);
}

/*===========================================================================================
    Function Name    : parameter_RealTime_Check
    Input            : 1. major: major index of the parameter.
                       2. minor: minor index of the parameter.
    Return           : return_value: true or false
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Return false if the value is not allowed to change while motor is running.
//==========================================================================================*/
uint8_t parameter_RealTime_Check ( uint8_t major, uint8_t minor )
{
    uint8_t return_value;
    return_value = ( CG_RealTime_Paramter_BITF[ major ] >> minor ) & 0x01;

    return return_value;
}

/*===========================================================================================
    Function Name    : updateSpeceilParameter
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Update speceil parameters.
//==========================================================================================*/
void updateSpeceilParameter( void  )
{

	uint32_t i;
	uint32_t dummy;
	uint8_t function_index;
	uint8_t NormState_old;
	uint32_t duty;
	int32_t offset;
    Struct_BLDC_CTRL *bldc_ctrl;
    Struct_BLDC_Drive *bldc_drive;
    Struct_IO_FUNC *io_func;
    uint8_t is_eep_dir_m0;
    //uint8_t is_eep_dir_m1;

	for( i = 0; i < CG_MD.Driver_Num; i++ ){
	    if( i == 0 ){
	        bldc_ctrl = (Struct_BLDC_CTRL *)&CG_BLDC_CTRL_M0;
	        offset = 0;
	    }/*else{
	        bldc_ctrl = (Struct_BLDC_CTRL *)&CG_BLDC_CTRL_M1;
	        offset = PARAMETER_OFFSET;
	    }*/

	    bldc_drive = bldc_ctrl->Drive_Ptr;


	    // == P1

	    bldc_drive->Pole_Factor = ( CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_POLE_NUMBER ] < 2 ? 1 : CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_POLE_NUMBER ] / 2 );
	    il_SpeedControl_Set_Pole_Factor ( (Struct_DriverMotorInfor*)&bldc_ctrl->PositionCtrl.Drive_Infor, bldc_drive->Pole_Factor );

	    bldc_drive->Full_Speed_Rpm_Abs = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_FULL_SPEED ];
        if( bldc_drive->Full_Speed_Rpm_Abs < 1){
            bldc_drive->Full_Speed_Rpm_Abs = 1;
        }

        bldc_ctrl->Hall_Ptr->Sequence = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_HALL_SEQUENCE ];
        bldc_ctrl->Hall_Ptr->Pole_Factor = bldc_drive->Pole_Factor;
        //bldc_ctrl->Hall_Ptr->Dir_Def = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_FORWARD_DIR ];

        if( bldc_drive->Sensor_Type == SENSOR_TYPE_HALL ){

            if( ( bldc_ctrl->Hall_Ptr->Sequence == HALL_SEQUENCE_B && bldc_ctrl->Hall_Ptr->Dir_Def == FORWARD_DIR_TOP ) ||
                ( bldc_ctrl->Hall_Ptr->Sequence == HALL_SEQUENCE_A && bldc_ctrl->Hall_Ptr->Dir_Def == FORWARD_DIR_BOTTOM )   ){

                bldc_ctrl->Hall_Ptr->Next_State_Table = ( uint8_t(*)[8] )Const_Hall_Next_State_BOTTOM;

                bldc_ctrl->Hall_Ptr->PA_Commutation_Type = COMMUTATION_TYPE_DEC;


            }else{
                bldc_ctrl->Hall_Ptr->Next_State_Table = ( uint8_t(*)[8] )Const_Hall_Next_State_TOP;
                bldc_ctrl->Hall_Ptr->PA_Commutation_Type = COMMUTATION_TYPE_ACC;
            }
        }else{

            if( bldc_ctrl->Dir_Def == FORWARD_DIR_TOP ){
                bldc_ctrl->Hall_Ptr->Next_State_Table = ( uint8_t(*)[8] )Const_Hall_Next_State_BOTTOM;
                bldc_ctrl->Hall_Ptr->PA_Commutation_Type = COMMUTATION_TYPE_DEC;
            }else{
                bldc_ctrl->Hall_Ptr->Next_State_Table = ( uint8_t(*)[8] )Const_Hall_Next_State_TOP;
                bldc_ctrl->Hall_Ptr->PA_Commutation_Type = COMMUTATION_TYPE_ACC;
            }

        }

        bldc_ctrl->Hall_Ptr->Next_State_If_CW = bldc_ctrl->Hall_Ptr->Next_State_Table[ DIR_CW  ][ bldc_ctrl->Hall_Ptr->Current_State ];
        bldc_ctrl->Hall_Ptr->Next_State_If_CCW = bldc_ctrl->Hall_Ptr->Next_State_Table[ DIR_CCW ][ bldc_ctrl->Hall_Ptr->Current_State ];

        if( bldc_ctrl->Hall_Ptr->Dir_Def == FORWARD_DIR_TOP ){
            bldc_drive->Commutation_Table = ( uint8_t(*)[8] )Const_Hall_TableA;
        }else{
            bldc_drive->Commutation_Table = ( uint8_t(*)[8] )Const_Hall_TableB;
        }

        bldc_ctrl->Encoder_Ptr->Offset = (int16_t)CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_ENCODER_OFFSET ];

        bldc_ctrl->Encoder_Ptr->Hall_Check_Checking_Time = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_ENCODER_CHECKING_TIME ] * CPU_FREQ_IN_M * 1000;
        bldc_ctrl->Encoder_Ptr->Hall_Check_Settling_Time = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_ENCODER_SETTLING_TIME ] * CPU_FREQ_IN_M * 1000;

        bldc_ctrl->Encoder_Ptr->Pos_Est_Offset = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_ENCODER_HALL_OFFSET ];

        bldc_ctrl->Driver_Enable_Mode = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][  offset + MOTOR_SERVO_ON_MODE ];
        if( bldc_ctrl->Driver_Enable_Mode >= DRIVER_EN_MODE_NUM ){
            bldc_ctrl->Driver_Enable_Mode = DRIVER_EN_MODE_0;
        }
        //
        DINT;
        //
        bldc_ctrl->Control_Mode = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_CTRL_MODE ];

        if( bldc_ctrl->Control_Mode >= CTRL_METHOD_NUM ){
            bldc_ctrl->Control_Mode = CTRL_CLOSELOOP_PID;
        }
        //
        if( bldc_ctrl->Control_Mode == CTRL_OPENLOOP && bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ){
            bldc_ctrl->Motor_State = MOTOR_STATE_STOP;
            il_PID_Set_MaxMin( (Struct_PID*)&bldc_ctrl->Drive_Ptr->FOC.Iq_Controller, 0, 0 );
        }
        EINT;
        //

        bldc_ctrl->OpMode_Ptr->Mode_Num2 = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_OPERATION_MODE_SPD ];
        if( bldc_ctrl->OpMode_Ptr->Mode_Num2 >= OP_MODE_NUM ){
            bldc_ctrl->OpMode_Ptr->Mode_Num2 = OP_MODE0;
        }

        //
        if( bldc_ctrl->Control_Mode != CTRL_POSITION && bldc_ctrl->OpMode_Ptr->Mode_Num2 == OP_MODE_THROTTLE_BV ){
            bldc_ctrl->E_ForwardReverse_Enable = YES;
        }else{
            bldc_ctrl->E_ForwardReverse_Enable = NO;
        }

        //
        if( bldc_ctrl->OpMode_Ptr->Mode_Num2 == OP_MODE_MULTI_DRIVE_LITE || bldc_ctrl->Control_Mode == CTRL_POSITION ){
            bldc_ctrl->MDL_Enabled = YES;
        }else{
            bldc_ctrl->MDL_Enabled = NO;
        }

        if( bldc_ctrl->MDL_Enabled == NO ){

            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_STOP_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CW_CCW_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_FREE_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_KEYSWITCH_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
            io_ValClr_DI_XN_BITF( bldc_ctrl->MultiDrive_Src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );
        }

        if ( CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_VR_MINVALUE_DEF ] == 0 ) {
            CG_IO.DIn_Func[ SRC_EEP ][ i + SRC_EEP_IO_STOP_BIT_M0 ] = ( i + CMD_MOTOR_0_INDEX ) * IO_FUNC_MOTOR_CONST + FUNC_STOP;				// For VR stop function.
        } else {
            CG_IO.DIn_Func[ SRC_EEP ][ i + SRC_EEP_IO_STOP_BIT_M0 ]	= FUNC_NO_ACTION;
        }

        bldc_ctrl->MotorStop_Behavior = CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ offset + MOTOR_MOTOR_STOP_BEHAVIOR ];
        if( bldc_ctrl->MotorStop_Behavior >= MOTOR_STOP_BEHAVIOR_NUM ){
            bldc_ctrl->MotorStop_Behavior = MOTOR_STOP_BEHAVIOR_FREE;
        }

        // == P2

        bldc_ctrl->Encoder_Ptr->UpdateRate_Pa = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_ENCODER_UPDATE_RATE ];
        if( bldc_ctrl->Encoder_Ptr->UpdateRate_Pa >= ENCODER_UPDATE_RATE_NUM ){
            bldc_ctrl->Encoder_Ptr->UpdateRate_Pa = ENCODER_UPDATE_RATE_10HZ;
        }
        bldc_ctrl->Encoder_Ptr->UpdateRate_Factor_1 = Const_Encoder_UpdateRate_Factor[ bldc_ctrl->Encoder_Ptr->UpdateRate_Pa ];
        bldc_ctrl->Encoder_Ptr->UpdateRate_Factor_2 = ( 1000 / bldc_ctrl->Encoder_Ptr->UpdateRate_Factor_1 );

        // == P3
        bldc_ctrl->Stall_Time = CG_Parameter.RAM_data[ PARAMETER_SPEED ][ offset + SPD_TQ_STALL_TIME ];
        bldc_ctrl->Tq_Act_Time = CG_Parameter.RAM_data[ PARAMETER_SPEED ][ offset + SPD_TQ_ACT_TIME ] * TIME_CONST_100MS;
        bldc_ctrl->Tq_Rec_Time = CG_Parameter.RAM_data[ PARAMETER_SPEED ][ offset + SPD_TQ_REC_TIME ] * TIME_CONST_100MS;

        // == P4

        // == P5
        bldc_ctrl->Protect_Ptr->PowerOn_Run = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_PWR_ON_RUN ];
        bldc_ctrl->Protect_Ptr->MotorFB = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_FEEDBACK_SENSOR_PROTECT_ENABLE ];
        bldc_ctrl->Protect_Ptr->OverSpeed = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OVERSPEED_RPM ];
        bldc_ctrl->Protect_Ptr->AutoReset_Time = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_AUTORESET_TIME ];
        bldc_ctrl->Protect_Ptr->AutoReset_Mask_BITF = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_RESETTABLE_ALARMS ];

        bldc_ctrl->Protect_Ptr->Encoder_Error_Sensitivity = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_ENCODER_ERROR_SENSITIVITY ];

        bldc_ctrl->Protect_Ptr->over_vbus_behavior = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_ERROR_BEHAVIOR_OVP_UVP ];
        bldc_ctrl->Protect_Ptr->under_vbus_behavior = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_ERROR_BEHAVIOR_OVP_UVP ];
        bldc_ctrl->Protect_Ptr->hall_error_behavior = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_ERROR_BEHAVIOR_HALL ];

        bldc_ctrl->Protect_Ptr->over_vbus_value          = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OV_FAULT ];
        bldc_ctrl->Protect_Ptr->over_vbus_recover_value  = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OV_RECOVER ];

        bldc_ctrl->Protect_Ptr->low_vbus_value           = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_LV_FAULT ];
        bldc_ctrl->Protect_Ptr->low_vbus_recover_value   = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_LV_RECOVER ];
        bldc_ctrl->Protect_Ptr->under_vbus_value         = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_UV_FAULT ];
        bldc_ctrl->Protect_Ptr->under_vbus_recover_value = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_UV_RECOVER ];

        bldc_ctrl->Protect_Ptr->OC_Fault_EN = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OC_FAULT_EN ];
        bldc_ctrl->Protect_Ptr->OP_Fault_EN = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OP_FAULT_EN ];


        bldc_ctrl->Protect_Ptr->TimeOut_Behavior = CG_Parameter.RAM_data[ PARAMETER_PROTECT][ PROTECT_COMM_ERROR_BEHAVIOR ];
        if( bldc_ctrl->Protect_Ptr->TimeOut_Behavior >= UART_TIMEOUT_BEHAVIOR_NUM ){
            bldc_ctrl->Protect_Ptr->TimeOut_Behavior = UART_TIMEOUT_BEHAVIOR_ONLY_ALARM;
        }

        bldc_ctrl->Protect_Ptr->RGN_On_Allowed_Cnt = CG_Parameter.RAM_data[ PARAMETER_PROTECT][ PROTECT_RGN_ERROR ];

        // == P6
        bldc_ctrl->IO_Func_Ptr->SC_CC_Mode = ( uint16_t )CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_SC_CC_MODE ];
        if( bldc_ctrl->IO_Func_Ptr->SC_CC_Mode >= SC_CC_MODE_NUM ){
            bldc_ctrl->IO_Func_Ptr->SC_CC_Mode = SC_MODE;
        }

        bldc_ctrl->VA_Speed = CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_VA_VALUE ];
        bldc_ctrl->EN_Speed = CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_EN_SPD ];

        // == P7

        bldc_ctrl->Algorithm = CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_CTRL_ALGORITHM ];
        if( bldc_ctrl->Drive_Ptr->Mode != BLDCDRIVE_FOC && bldc_ctrl->Algorithm >= SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
            bldc_ctrl->Algorithm = SPDCTRL_ALGOROTHM_2ND_ORDER_LOOP;
        }

        if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
            bldc_ctrl->Ctrl_Step_Limit_Pa = bldc_ctrl->ADC_Ptr->HWOCP;
        }else{
            bldc_ctrl->Ctrl_Step_Limit_Pa = bldc_drive->Period * CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_STEP_DUTY_MAX ] / 5000;
        }

        bldc_ctrl->Tq_P_Const = bldc_drive->Period * CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_TQ_PID_P ] / 5000;
        bldc_ctrl->Tq_P_Const /= 16;
        if( bldc_ctrl->Tq_P_Const < 1 ){
            bldc_ctrl->Tq_P_Const = 1;
        }

        bldc_ctrl->PositionCtrl.SpdCtrl.Allowed_Erpm_Error_Const = CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_ALLOWED_ERPM_ERROR_CONST ];

        //
        bldc_ctrl->PI_Ptr->Timeout_PA = CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_SPECIAL_0 ];
        bldc_ctrl->PI_Ptr->Type_PA = CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_SPECIAL_1 ];
        if( bldc_ctrl->PI_Ptr->Type_PA >= PI_TYPE_NUM ){
            bldc_ctrl->PI_Ptr->Type_PA = PI_TYPE_2_PULSE;
        }
        bldc_ctrl->OpMode_Ptr->EVR_WeightFactor = CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_SPECIAL_2 ];
        //
        if( bldc_ctrl->Control_Mode == CTRL_OPENLOOP &&
            CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_SPECIAL_3 ] == TRUMMAN_PASSWORD ){
            bldc_ctrl->FOCTest_Flag = YES;
        }else{
            bldc_ctrl->FOCTest_Flag = NO;
        }
        bldc_ctrl->FOCTest_Angle = CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_SPECIAL_4 ];
        if( bldc_ctrl->FOCTest_Angle >= SINE_TABLE_RESOLUTION ){
            bldc_ctrl->FOCTest_Angle = 0;
        }
        //

        if( bldc_drive->Sensor_Type == SENSOR_TYPE_HALL ){

            il_SpeedControl_Set_Loop_1_Kp ( (Struct_SpeedControl*)&bldc_ctrl->PositionCtrl.SpdCtrl, CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_KP ] * 32 );

            il_PID_Set_KpKiKd ( ( Struct_PID* ) &bldc_ctrl->PositionCtrl.SpdCtrl.Loop_2_SpeedPID,
                                CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_CONST_1 ] * bldc_drive->Period / 40000,
                                CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_CONST_2 ],
                                0 );

            //il_SpeedControl_Set_Pos_Const ( ( Struct_SpeedControl*) &bldc_ctrl->PositionCtrl.SpdCtrl, 6 );
            il_SpeedControl_Set_Pos_Const ( ( Struct_SpeedControl*) &bldc_ctrl->PositionCtrl.SpdCtrl, 6 * bldc_drive->Pole_Factor );

            il_PositionControl_Set_Path_Spd_Const ( ( Struct_PositionControl*) &bldc_ctrl->PositionCtrl, 6 * bldc_drive->Pole_Factor * POSITION_CTRL_SPEED_CONST / 60 );
            il_PositionControl_Set_MaxPos ( ( Struct_PositionControl*) &bldc_ctrl->PositionCtrl, 6 * bldc_drive->Pole_Factor );
            il_SpeedControl_Set_Loop_2_MaxMin ( (Struct_SpeedControl*) &bldc_ctrl->PositionCtrl.SpdCtrl, bldc_drive->Period_Limit, -(bldc_drive->Period_Limit) );

        }else{

            il_SpeedControl_Set_Loop_1_Kp ( (Struct_SpeedControl*)&bldc_ctrl->PositionCtrl.SpdCtrl, CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_KP ] );

            if( bldc_ctrl->Algorithm == SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP ){
                il_PID_Set_KpKiKd ( ( Struct_PID* ) &bldc_ctrl->PositionCtrl.SpdCtrl.Loop_2_SpeedPID,
                                    CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_CONST_1 ] * 8,
                                    CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_CONST_2 ],
                                    0 );
            }else{
                il_PID_Set_KpKiKd ( ( Struct_PID* ) &bldc_ctrl->PositionCtrl.SpdCtrl.Loop_2_SpeedPID,
                                    CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_CONST_1 ] * bldc_drive->Period / 2500,
                                    CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_CONST_2 ],
                                    0 );
            }

            //il_SpeedControl_Set_Pos_Const ( ( Struct_SpeedControl*) &bldc_ctrl->PositionCtrl.SpdCtrl, bldc_ctrl->Encoder_Ptr->FullPos / bldc_drive->Pole_Factor );
            il_SpeedControl_Set_Pos_Const ( ( Struct_SpeedControl*) &bldc_ctrl->PositionCtrl.SpdCtrl, bldc_ctrl->Encoder_Ptr->FullPos );

            il_PositionControl_Set_Path_Spd_Const ( ( Struct_PositionControl*) &bldc_ctrl->PositionCtrl, bldc_ctrl->Encoder_Ptr->FullPos * POSITION_CTRL_SPEED_CONST / 60 );
            il_PositionControl_Set_MaxPos ( ( Struct_PositionControl*) &bldc_ctrl->PositionCtrl, bldc_ctrl->Encoder_Ptr->FullPos );

            bldc_ctrl->Duty_Compensation = CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_DUTY_COMPENSATION ];
            if( bldc_ctrl->Duty_Compensation > (int32_t)bldc_drive->DeadTime * 2 ){
                bldc_ctrl->Duty_Compensation = 0;
            }

        }

        if( bldc_drive->Mode == BLDCDRIVE_FOC ){
            il_PID_Set_KpKiKd ( ( Struct_PID* ) &bldc_drive->FOC.Iq_Controller,
                                CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_IQ_PID_P ] * bldc_drive->Period / 5000,
                                CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_IQ_PID_I ] * bldc_drive->Period / 6250,
                                0 );

            il_PID_Set_KpKiKd ( ( Struct_PID* ) &bldc_drive->FOC.Id_Controller,
                                CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_ID_PID_P ] * bldc_drive->Period / 5000,
                                CG_Parameter.RAM_data[ PARAMETER_DIGITAL ][ offset + DIGITAL_ID_PID_I ] * bldc_drive->Period / 6250,
                                0 );
        }

        // == P8

        bldc_ctrl->ServoOff_Delay_TimeMs_Pa = TIME_CONST_100MS * CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_SERVO_OFF_DELAY_TIME ];
        if( bldc_ctrl->E_ForwardReverse_Enable == NO ){
            bldc_ctrl->ServoOff_Delay_TimeMs_Pa = 0;
        }

        dummy = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_TQ_ACC_DEC_TIME ];
        if( dummy == 0 ){
            bldc_ctrl->Torque_Limit_Acc_Time = 1;
        }else{
            bldc_ctrl->Torque_Limit_Acc_Time = dummy;
        }

        dummy = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_TQ_DEC_TIME ];
        if( dummy == 0 ){
            bldc_ctrl->Torque_Limit_Dec_Time = bldc_ctrl->Torque_Limit_Acc_Time;
        }else{
            bldc_ctrl->Torque_Limit_Dec_Time = dummy;
        }

        setSPK_Parameter( bldc_ctrl->SPK_Ptr,
                          CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_TQ_ACC_DEC_TIME ],
                          CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_SPK_TQ_PERCENTAGE1 ],
                          CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_SPK_TQ_PERCENTAGE2 ],
                          CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_SPK_BRAKE_LOCK_TIME ] );

        bldc_ctrl->Hall_Ptr->PA_Enabled = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_PHASE_ADVANCE_ENABLED ];
        bldc_ctrl->Hall_Ptr->PA_Angle = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_PHASE_ADVANCE_RATIO ];
        if( bldc_ctrl->Hall_Ptr->PA_Angle < PHASE_ANDVACE_CONST ){
            bldc_ctrl->Hall_Ptr->PA_Angle = PHASE_ANDVACE_CONST;
        }else if( bldc_ctrl->Hall_Ptr->PA_Angle >= PHASE_ANDVACE_CONST * 2 ){
            bldc_ctrl->Hall_Ptr->PA_Angle = PHASE_ANDVACE_CONST * 2;
        }

        bldc_ctrl->Hall_Ptr->PA_Angle -= PHASE_ANDVACE_CONST;

        bldc_ctrl->Hall_Ptr->PA_Ticks = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_PHASE_ADVANCE_TICK ];

        bldc_ctrl->Inverse_Mode = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_REVERSE_MODE ];
        if( bldc_ctrl->Inverse_Mode >= 2 ){
            bldc_ctrl->Inverse_Mode = DISABLE;
        }

        bldc_ctrl->Stop_Delay_Time = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_STOP_DELAY_TIME ] * TIME_CONST_100MS;
        bldc_ctrl->Emergency_Acc_Time = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_EMERGENCY_ACC ] * TIME_CONST_100MS;
        bldc_ctrl->Emergency_Dec_Time = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_EMERGENCY_DEC ] * TIME_CONST_100MS;

        bldc_ctrl->IO_Func_Ptr->EncoderPulse_Divider = CG_Parameter.RAM_data[ PARAMETER_ADVANCE_FUNC ][ offset + ADVANCE_FUNC_ENCODER_DIVIDER ];

        if( bldc_ctrl->IO_Func_Ptr->EncoderPulse_Divider == 0 ){
            bldc_ctrl->IO_Func_Ptr->EncoderPulse_Divider = 1;
            bldc_ctrl->IO_Func_Ptr->EncoderPulse_Enable = NO;
        }else{
            if( bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL ){
                bldc_ctrl->IO_Func_Ptr->EncoderPulse_Enable = NO;
            }else{
                bldc_ctrl->IO_Func_Ptr->EncoderPulse_Enable = YES;
            }
        }

        bldc_ctrl->IO_Func_Ptr->EncoderPulse_Divider_P = bldc_ctrl->IO_Func_Ptr->EncoderPulse_Divider;
        bldc_ctrl->IO_Func_Ptr->EncoderPulse_Divider_N = -bldc_ctrl->IO_Func_Ptr->EncoderPulse_Divider;

	}

	// == P2
	CG_OPMode.Speed_Max = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_SPD_MAX ];
    CG_OPMode.Speed_Min = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_SPD_MIN ];

    CG_OPMode.AccDec_Max = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_ACCDEC_MAX ];
    CG_OPMode.AccDec_Min = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_ACCDEC_MIN ];

    CG_OPMode.Tq_Limit_Max = SHUNT_I_FWP * CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_TQ_MAX ] / TQ_100_PERCENT;
    CG_OPMode.Tq_Limit_Min = SHUNT_I_FWP * CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_TQ_MIN ] / TQ_100_PERCENT;

    CG_OPMode.Duty_Max = CG_BLDC_CTRL_M0.Drive_Ptr->Duty_Min_Abs + ( CG_BLDC_CTRL_M0.Drive_Ptr->Duty_Resolution * CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_DUTY_MAX ] / DUTY_100_PERCENT );
    CG_OPMode.Duty_Min = CG_BLDC_CTRL_M0.Drive_Ptr->Duty_Min_Abs + ( CG_BLDC_CTRL_M0.Drive_Ptr->Duty_Resolution * CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_DUTY_MIN ] / DUTY_100_PERCENT );


    CG_OPMode.AD_Mode = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_AD_MODE ];
    if( CG_OPMode.AD_Mode >= AD_MODE_Num ){
        CG_OPMode.AD_Mode = AD_MODE_5V;
    }

    CG_OPMode.AD_Gain = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_GAIN ];
    CG_OPMode.AD_Offset = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_OFF_SET_VOLTAGE ] * THROTTLE_MULTIFY;
    CG_OPMode.AD_Offset_Spd = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_OFF_SET_SPD ];

    CG_OPMode.Throttle_Type = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_TYPE ];
    if( CG_OPMode.Throttle_Type >= Throttle_NUM ){
        CG_OPMode.Throttle_Type = Throttle_SINGLE_ENDED;
    }

    CG_OPMode.PW_Max = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_PULSE_MAX ] * CPU_FREQ_IN_M;
    CG_OPMode.PW_Min = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_PULSE_MIN ] * CPU_FREQ_IN_M;

    if( CG_OPMode.Throttle_Type == Throttle_WIG_WAG || CG_OPMode.Throttle_Type == Throttle_WIG_WAG_R ){
        if( ( CG_BLDC_CTRL_M0.Control_Mode != CTRL_POSITION ) &&
            ( CG_BLDC_CTRL_M0.OpMode_Ptr->Mode_Num2 == OP_MODE_THROTTLE_ANALOG ||
              CG_BLDC_CTRL_M0.OpMode_Ptr->Mode_Num2 == OP_MODE_THROTTLE_PULSE ||
              CG_BLDC_CTRL_M0.OpMode_Ptr->Mode_Num2 == OP_MODE_THROTTLE_BV ) ){
            is_eep_dir_m0 = YES;
        }else{
            is_eep_dir_m0 = NO;
        }

        /*
        if( ( CG_BLDC_CTRL_M1.Control_Mode != CTRL_POSITION ) &&
            ( CG_BLDC_CTRL_M1.OpMode_Ptr->Mode_Num2 == OP_MODE_THROTTLE_ANALOG || CG_BLDC_CTRL_M1.OpMode_Ptr->Mode_Num2 == OP_MODE_THROTTLE_PULSE ) ){
            is_eep_dir_m1 = YES;
        }else{
            is_eep_dir_m1 = NO;
        }*/
    }else{
        is_eep_dir_m0 = NO;
        //is_eep_dir_m1 = NO;
    }

    if( is_eep_dir_m0 ){
        CG_IO.DIn_Func[ SRC_EEP ][ SRC_EEP_IO_DIR_BIT_M0 ] = CMD_MOTOR_0_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CW_CCW;
    }else{
        CG_IO.DIn_Func[ SRC_EEP ][ SRC_EEP_IO_DIR_BIT_M0 ] = FUNC_NO_ACTION;
    }

    /*
    if( is_eep_dir_m1 ){
        CG_IO.DIn_Func[ SRC_EEP ][ SRC_EEP_IO_DIR_BIT_M1 ] = CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST + FUNC_CW_CCW;
    }else{
        CG_IO.DIn_Func[ SRC_EEP ][ SRC_EEP_IO_DIR_BIT_M1 ] = FUNC_NO_ACTION;
    }*/

    CG_OPMode.Throttle_Max = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_SIGNAL_MAX ] * THROTTLE_MULTIFY;
    CG_OPMode.Throttle_Map = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_MAP ];
    CG_OPMode.Throttle_DeadBand_PA = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_DEAD_BAND ] ;
    if( CG_OPMode.Throttle_DeadBand_PA <= VR_STOP_V_DISTANCE ){
        CG_OPMode.Throttle_DeadBand_PA = VR_STOP_V_DISTANCE + 1;
    }

    CG_OPMode.Throttle_DeadBand = CG_OPMode.Throttle_DeadBand_PA * THROTTLE_MULTIFY;

    CG_BLDC_CTRL_M0.Path_Mode = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_PATH_MODE ];
    CG_BLDC_CTRL_M0.Position_Mode = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_POSITION_DEF_MODE ];


    CG_OPMode.Throttle_Restraint_Mode = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_THROTTLE_RESTRAINT_MODE ];
    if( CG_OPMode.Throttle_Restraint_Mode >= THROTTLE_RESTRAINT_MODE_NUM ){
        CG_OPMode.Throttle_Restraint_Mode = THROTTLE_RESTRAINT_MODE_DISABLE;
    }

    /*
    CG_BLDC_CTRL_M1.Path_Mode = CG_BLDC_CTRL_M0.Path_Mode;
    CG_BLDC_CTRL_M1.Position_Mode = CG_BLDC_CTRL_M0.Position_Mode;
    */

    /*
	CG_OPMode.AccDec_Polarity = CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_ACCDEC_POLARITY ];
	if( CG_OPMode.AccDec_Polarity > Throttle_SINGLE_ENDED_R ){
		CG_OPMode.AccDec_Polarity = Throttle_SINGLE_ENDED;
	}*/

    //CG_IO_Expander.YnActState_BITF = IO_EXPANDER_ACT_BITF_INIT ^ CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_IO_EXPANDER_ACT_BITF ];

    CG_GPIO.OtherOutput_ActState_BITF = OTHER_OUTPUT_ACT_BITF_INIT ^ CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_IO_EXPANDER_ACT_BITF ];

	// P3
	// == P4

	// == P5
    if( BUSV_PHYSIC_MAX == 0 || CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_ERROR_BEHAVIOR_OVP_UVP ] == 0 ){

        if( BUSV_PHYSIC_MAX == 0 ){
            CG_Protect.OverBusV_Clamping = ADC_MAX_VALUE;
        }else{
            CG_Protect.OverBusV_Clamping = ADC_MAX_VALUE * CG_HWEEP.HW_Info[ HWEEP_IDX_OVP ] / BUSV_PHYSIC_MAX;
        }

        CG_Protect.UnderBusV_Clamping = 0;

    }else{
        CG_Protect.OverBusV_Clamping = ADC_MAX_VALUE * CG_Protect.Motor_0.over_vbus_value / BUSV_PHYSIC_MAX;
        CG_Protect.UnderBusV_Clamping = ADC_MAX_VALUE * CG_Protect.Motor_0.under_vbus_value / BUSV_PHYSIC_MAX;
    }

    if( CG_Protect.OverBusV_Clamping > ADC_MAX_VALUE ){
        CG_Protect.OverBusV_Clamping = ADC_MAX_VALUE;
    }

    if( CG_Protect.UnderBusV_Clamping > ADC_MAX_VALUE ){
        CG_Protect.UnderBusV_Clamping = ADC_MAX_VALUE;
    }

    CG_Modbus_Slave.Time_Out_num = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_232_TIME_OUT_TICKS ];
    CG_Modbus_Slave.COM_Alm_num  = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_232_COM_ALM_NUM ];

    CG_Modbus_Slave_485.Time_Out_num = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_485_TIME_OUT_TICKS ];
    CG_Modbus_Slave_485.COM_Alm_num  = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_485_COM_ALM_NUM ];

    CG_CAN.Timeout_Pa_Ms = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_CAN_TIME_OUT_TICKS ];

    CG_Modbus_Slave.ExceptionMode = EXCEPTION_MODE_NORMAL;//( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_PHYSICAL_SETTINGS ] >> PHYSICAL_EXCEPTION_BIT ) & 0x01;
    CG_Modbus_Slave_485.ExceptionMode = CG_Modbus_Slave.ExceptionMode;

    CG_Protect.Alarm_Mode = CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_ALARM_MODE ];

	// == P6
    for( i = DIO_X0; i <= DIO_X13; i++ ){
       dummy = CG_Parameter.RAM_data[ PARAMETER_IO ][ i ];
       if( ( dummy % IO_FUNC_MOTOR_CONST ) >= FUNC_NUM ){
           CG_IO.DIn_Func[ SRC_IO ][ i ] = FUNC_NO_ACTION;
       }else{
           CG_IO.DIn_Func[ SRC_IO ][ i ] = dummy;
       }
    }

	CG_GPIO.XnNormState_BITF = CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_X_ACT_BITF ];
	// X5 reversed
	if( ( CG_GPIO.XnNormState_BITF >> 5 ) & 0x01 ){
	    CG_GPIO.XnNormState_BITF &= ~( 1UL << 5 );
	}else{
	    CG_GPIO.XnNormState_BITF |=  ( 1UL << 5 );
	}

    CG_GPIO.YnActState_BITF = CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_Y_ACT_BITF ];
    /*
    //CG_GPIO.YnActState_BITF = CG_GPIO.YnActState_BITF ^ ( ( 1UL << 6 ) | ( 1UL << 7 ) );    // Bit6 = BR1, Bit7 = BR2, different logic from other output
    if( ( CG_GPIO.YnActState_BITF >> 6 ) & 0x01 ){
        CG_GPIO.YnActState_BITF &= ~( 1UL << 6 );
    }else{
        CG_GPIO.YnActState_BITF |=  ( 1UL << 6 );
    }

    if( ( CG_GPIO.YnActState_BITF >> 7 ) & 0x01 ){
        CG_GPIO.YnActState_BITF &= ~( 1UL << 7 );
    }else{
        CG_GPIO.YnActState_BITF |=  ( 1UL << 7 );
    }*/

    for( i = 0 ; i < OUTPUT_FUNC_NUM; i++ ){
        CG_BLDC_CTRL_M0.IO_Func_Ptr->OutputPin_of_Func[ i ] = OUTPUT_NC;
        //CG_BLDC_CTRL_M1.IO_Func_Ptr->OutputPin_of_Func[ i ] = OUTPUT_NC;
    }

    if( CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_MBRAKE_TYPE ] != 0 ){
        duty = CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_MBRAKE_TYPE ] % MBRAKE_FULL_DUTY;
        CG_PI.PWM_Duty_Pa = CG_PI.PWM_Period * duty / MBRAKE_FULL_DUTY;

        CG_GPIO.Out1_PwmTimeMs_Pa = ( ( CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_MBRAKE_TYPE ] / MBRAKE_FULL_DUTY ) % 100 ) * 100;
        CG_GPIO.Out2_PwmTimeMs_Pa = CG_GPIO.Out1_PwmTimeMs_Pa;

        if( CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_MBRAKE_TYPE ] >= 10000 ){
            CG_GPIO.Out1_IsDependsOnBusV = YES;
            CG_GPIO.Out2_IsDependsOnBusV = YES;

            if( CG_HWEEP.HW_Info[ HWEEP_IDX_OVPR ] > VOLTAGE_48V ){
                CG_PI.PWM_RatingVoltage = VOLTAGE_48V;
            }else{
                CG_PI.PWM_RatingVoltage = VOLTAGE_24V;
            }
            CG_PI.PWM_MinimumVoltage = CG_PI.PWM_RatingVoltage * duty / MBRAKE_FULL_DUTY;

        }else{
            CG_GPIO.Out1_IsDependsOnBusV = NO;
            CG_GPIO.Out2_IsDependsOnBusV = NO;
            CG_PI.PWM_Duty = CG_PI.PWM_Duty_Pa;
            ECap7Regs.CAP4 = CG_PI.PWM_Period - CG_PI.PWM_Duty;
        }
    }else{
        CG_GPIO.Out1_PwmTimer_Flag = NO;
        CG_GPIO.Out1_PwmTimerMs = 0;
        CG_GPIO.Out1_Pwm_Flag = NO;

        CG_GPIO.Out2_PwmTimer_Flag = NO;
        CG_GPIO.Out2_PwmTimerMs = 0;
        CG_GPIO.Out2_Pwm_Flag = NO;
    }

    for( i = 0; i < OUTPUT_NUM; i ++ ){
        function_index = CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_Y0 + i ];

        /*
        if( function_index >= CMD_MOTOR_1_INDEX * IO_FUNC_MOTOR_CONST ){
            io_func = (Struct_IO_FUNC*)CG_BLDC_CTRL_M1.IO_Func_Ptr;
        }else{
            io_func = (Struct_IO_FUNC*)CG_BLDC_CTRL_M0.IO_Func_Ptr;
        }*/
        io_func = (Struct_IO_FUNC*)CG_BLDC_CTRL_M0.IO_Func_Ptr;

        function_index = function_index % IO_FUNC_MOTOR_CONST;
        if( function_index >= OUTPUT_FUNC_NUM ){
            function_index = OUTPUT_NC;
        }

        io_func->OutputPin_of_Func[ function_index ] = i + 1;

        //
        #define IS_PARK_BRAKE       (   function_index == OUTPUT_PARK_BRAKE ||  \
                                        function_index == OUTPUT_PARK_BRAKE_RELEASE )

        if( i == OUTPUT_Y4 ){ // POUT1
            if( CG_MD.HW_Ver == HW_VER_A ){
                CG_GPIO.Out1_Type = OUT_TYPE_GPIO;
            }else{
                if( IS_PARK_BRAKE &&
                    CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_MBRAKE_TYPE ] != 0 ){
                    CG_GPIO.Out1_Type = OUT_TYPE_PWM;
                }else{
                    CG_GPIO.Out1_Type = OUT_TYPE_GPIO;
                }
            }
        }

        if( i == OUTPUT_Y5 ){ // POUT2
            if( IS_PARK_BRAKE &&
                CG_Parameter.RAM_data[ PARAMETER_IO ][ DIO_MBRAKE_TYPE ] != 0 ){
                CG_GPIO.Out2_Type = OUT_TYPE_PWM;
            }else{
                CG_GPIO.Out2_Type = OUT_TYPE_GPIO;
            }
        }

        //
        NormState_old = io_func->ActState_of_Func[ function_index ];
        dummy = ( CG_GPIO.YnActState_BITF >> i ) & 0x01;
        io_func->ActState_of_Func[ function_index ] = dummy;

        if( function_index == OUTPUT_NC ){
            /*
            if( 1 - dummy ){
                CG_GPIO.Yn_State_BITF |= ( 1UL << i );
            }else{
                CG_GPIO.Yn_State_BITF &= ~( 1UL << i );
            }*/
            OutputYn_action[ 1 - dummy ][ i + 1 ]();

        }else{
            if( io_func->Output_State[ function_index ] == NormState_old ){
                io_func->Output_State[ function_index ] = io_func->ActState_of_Func[ function_index ];
            }else{
                io_func->Output_State[ function_index ] = 1 - io_func->ActState_of_Func[ function_index ];
            }
            OutputYn_action[ io_func->Output_State[ function_index ] ]
                           [ io_func->OutputPin_of_Func[ function_index ] ]();
        }

    }


#if(1)
	// P7

    // P8

    // == P9
    for( i = COM_PA_X1_FUNC; i <= COM_PA_X15_FUNC; i++ ){
        dummy = CG_Parameter.RAM_data[ PARAMETER_COM ][ i ];
        if( ( dummy % IO_FUNC_MOTOR_CONST ) >= FUNC_NUM ){
            CG_IO.DIn_Func[ SRC_UART ][ i ] = FUNC_NO_ACTION;
        }else{
            CG_IO.DIn_Func[ SRC_UART ][ i ] = dummy;
        }
    }

    CG_ComProtocol_01.COM_IO_NormState_BITF = CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_X_ACT_BITF ];

    CG_UART485.rtu_frame_length_limit = CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_485_FRAME_LENGTH_LIMIT ];
    if( CG_UART485.rtu_frame_length_limit >= FRAME_LENGTH_NUM ){
        CG_UART485.rtu_frame_length_limit = FRAME_LENGTH_1750US;
    }

    if( CG_UART485.BaudRate != 0 ){
        CG_UART485.rtu_time_frame_length = ( CPU_FREQ / CG_UART485.BaudRate ) * 35; // ( 35 = 10 bit * 3.5 char length )
    }

    if( CG_UART485.rtu_time_frame_length < const_ModbusRTU_FrameLength_Limit[ CG_UART485.rtu_frame_length_limit ] ){
        CG_UART485.rtu_time_frame_length = const_ModbusRTU_FrameLength_Limit[ CG_UART485.rtu_frame_length_limit ];
    }

    CG_MD.RS485_CAN_SEL_State = CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_RS485_CAN_SELECT ];

#endif

}


/************************** <END OF FILE> *****************************************/

