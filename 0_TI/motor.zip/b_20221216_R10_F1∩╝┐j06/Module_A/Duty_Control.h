/*===========================================================================================

    File Name       : Duty_Control.h

    Version         : V1_00_00_a

    Built Date      : 2013/01/29

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : 
				
    =========================================================================================

    History         : 2013/01/29 Perlimary version.  ( by Chaim )

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef DUTY_CTRL_H
#define DUTY_CTRL_H

#define FACTOR_P	1000
#define FACTOR_I	1000
#define FACTOR_D	1000

/*===========================================================================================
    Function Name    : calculateTargetDuty
    Input            : 1.acc_dec_mode: 0 = normal mode ( current target += acc )
									   1 = with emr acc / dec.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current duty at open loop.
//==========================================================================================*/
void calculateTargetDuty ( uint32_t acc_dec_mode );

/*===========================================================================================
    Function Name    : calculateBrakeDuty
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current duty at open loop.
//==========================================================================================*/
void calculateBrakeDuty ( void );

/*===========================================================================================
    Function Name    : calculateTargetSpeed
    Input            : 
					   1.acc_dec_mode: 0 = normal mode ( current target += acc )
									   1 = base on the current speed ( current target = current speed + acc ).
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current speed.
//==========================================================================================*/
void calculateTargetSpeed ( uint32_t acc_dec_mode );

/*===========================================================================================
    Function Name    : calculateBrakeSpeed
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate target brake speed.
//==========================================================================================*/
void calculateBrakeSpeed ( void );

/*===========================================================================================
    Function Name    : currentRestraint
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Restraint current.
//==========================================================================================*/
void currentRestraint( void );

/*===========================================================================================
    Function Name    : reduceDuty
    Input            : 1.target_duty: target duty
					   2.step_duty : One step reduced duty
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : reduce duty
//==========================================================================================*/
void reduceDuty( int32_t* target_duty, int32_t step_duty );

/*===========================================================================================
    Function Name    : speedController_PID
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
void speedController_PID ( void );

/*===========================================================================================
    Function Name    : speedController_Duty
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Duty = pre_duty + fb_duty
//==========================================================================================*/
void speedController_Duty ( void );

/*===========================================================================================
    Function Name    : speedController_PID_Encoder
    Input            : type: PID Type
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
void speedController_PID_Encoder ( int32_t type );


#endif

/************************** <END OF FILE> *****************************************/


