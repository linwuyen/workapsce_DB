/*===========================================================================================

    File Name       : SpeedControl.h

    Version         : V0200

    Built Date      : 2018/05/25

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef SPEED_CONTROL_H
#define SPEED_CONTROL_H

//#include "Type.h"
//#include "PIDControl.h"


#ifndef SPDCTRL_SCALE_CONST
#define SPDCTRL_SCALE_CONST                 1000L
#endif

//#ifndef SPDCTRL_ALLOWED_ERPM_ERROR_CONST
//#define SPDCTRL_ALLOWED_ERPM_ERROR_CONST    160L//640L//160L
//#define SPDCTRL_ALLOWED_ERPM_ERROR_CONST    160L
//#endif

#ifndef SPDCTRL_LOOP_1_KP_INIT
//#define SPDCTRL_LOOP_1_KP_INIT              100000L
#define SPDCTRL_LOOP_1_KP_INIT              100L
#endif

#ifndef SPDCTRL_LOOP_1_KP_SCALE_CONST
//#define SPDCTRL_LOOP_1_KP_SCALE_CONST       1024L
#define SPDCTRL_LOOP_1_KP_SCALE_CONST       16L
#endif


#ifndef SPDCTRL_LOOP_2_P_INIT
#define SPDCTRL_LOOP_2_P_INIT               100L
#endif


#ifndef SPDCTRL_LOOP_2_STEP_LIMIT_INIT
#define SPDCTRL_LOOP_2_STEP_LIMIT_INIT      10L
#endif

#ifndef SPDCTRL_TIME_CONST
#define SPDCTRL_TIME_CONST                  60000L
#endif


typedef struct{

    int32_t Pole_Factor;

    // Motor position feedback information
    int32_t Pos_Now;
    int32_t Pos_Old;
    int32_t Pos_Delta;
    int32_t SpeedERPM;

    //
    int32_t Index_Now;

}Struct_DriverMotorInfor;

typedef struct{

    // Target speed
    int32_t Target_ERPM;

    // Target path planning
    int32_t Target_Pos_Step;
    int32_t Target_Pos_Step_Rest;

    // Target step pos = erpm x pos_const / SPDCTRL_TIME_CONST
    int32_t Pos_Const;

    // Loop 1 : pos error x kp = target ( where target = speed erpm )
    int32_t Loop_1_Kp;
    int32_t Loop_1_Target;
    int32_t Loop_1_Rest;

    // Loop 2 : Speed control
    Struct_PID  Loop_2_SpeedPID;
    int32_t Loop_2_StepLimit;

    // Final output
    int32_t Output;

    //
    uint8_t Big_Loop_Kp_Flag;

    int32_t Allowed_Erpm_Error_Const;

}Struct_SpeedControl;

/*===========================================================================================
    Function Name    : setupInitial_SpeedControl
    Input            :  1. speedctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_SpeedControl ( Struct_SpeedControl* speedctrl );

/*===========================================================================================
    Function Name    : resetReg_SpeedControl
    Input            :  1. speedctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void resetReg_SpeedControl ( Struct_SpeedControl* speedctrl );

/*===========================================================================================
    Function Name    : setupInitial_DriverMotorInfor
    Input            :  1. infor
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_DriverMotorInfor ( Struct_DriverMotorInfor* infor );

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Pole_Factor
    Input            :  1. infor
                        2. pole_factor
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Pole_Factor ( Struct_DriverMotorInfor* infor, int32_t pole_factor )
{
    infor->Pole_Factor = pole_factor;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Index
    Input            :  1. infor
                        2. index
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Index ( Struct_DriverMotorInfor* infor, int32_t index )
{
    infor->Index_Now = index;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Pos
    Input            :  1. infor
                        2. Pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Pos ( Struct_DriverMotorInfor* infor, int32_t pos )
{
    infor->Pos_Now = pos;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Pos_Old
    Input            :  1. infor
                        2. Pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Pos_Old ( Struct_DriverMotorInfor* infor, int32_t pos )
{
    infor->Pos_Old = pos;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Calculate_Delta_Pos
    Input            :  1. infor
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Calculate_Delta_Pos ( Struct_DriverMotorInfor* infor )
{
    // Get pos change between step and step
    infor->Pos_Delta = infor->Pos_Now - infor->Pos_Old;
    infor->Pos_Old = infor->Pos_Now;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Pos
    Input            :  1. infor
                        2. spd
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Speed ( Struct_DriverMotorInfor* infor, int32_t spd )
{
    infor->SpeedERPM = spd;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Pos_Const
    Input            :  1. speedctrl
                        2. spd
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Pos_Const ( Struct_SpeedControl* speedctrl, int32_t pos_const )
{
    speedctrl->Pos_Const = pos_const;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Loop_1_Kp
    Input            :  1. speedctrl
                        2. spd
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Loop_1_Kp ( Struct_SpeedControl* speedctrl, int32_t kp )
{
    speedctrl->Loop_1_Kp = ( kp < 1 ? 1 : kp );
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Loop_2_PID
    Input            :  1. speedctrl
                        2. p_const
                        3. i_Const
                        4. d_const
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Loop_2_PID ( Struct_SpeedControl* speedctrl, int32_t p_const, int32_t i_const, int32_t d_const )
{
    p_const = ( p_const < 1 ? 1 : p_const );
    il_PID_Set_KpKiKd ( &speedctrl->Loop_2_SpeedPID, p_const, i_const, d_const );
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Loop_2_PID
    Input            :  1. speedctrl
                        2. output_max
                        3. output_min
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Loop_2_MaxMin ( Struct_SpeedControl* speedctrl, int32_t output_max, int32_t output_min )
{
    il_PID_Set_MaxMin ( &speedctrl->Loop_2_SpeedPID, output_max, output_min );
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Loop_2_StepLimit
    Input            :  1. speedctrl
                        2. step_limit
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Loop_2_StepLimit ( Struct_SpeedControl* speedctrl, int32_t step_limit )
{
    speedctrl->Loop_2_StepLimit = step_limit;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Target_ERPM
    Input            :  1. speedctrl
                        2. target_erpm
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Target_ERPM ( Struct_SpeedControl* speedctrl, int32_t target_erpm )
{
    speedctrl->Target_ERPM = target_erpm;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Set_Output
    Input            :  1. speedctrl
                        2. value
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Set_Output ( Struct_SpeedControl* speedctrl, int32_t value )
{
    speedctrl->Output = value;
}

/*===========================================================================================
    Function Name    : il_SpeedControl_Get_Output
    Input            :  1. speedctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_SpeedControl_Get_Output ( Struct_SpeedControl* speedctrl )
{
    return speedctrl->Output;
}


/*===========================================================================================
    Function Name    : il_SpeedControl_Run
    Input            :  1. speedctrl
                        2. infor
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Run ( Struct_SpeedControl* speedctrl, Struct_DriverMotorInfor* infor )
{
    int32_t dummy;
    int32_t limit;
    int32_t step;
    int32_t ctrl_time_const = SPDCTRL_TIME_CONST * infor->Pole_Factor;

    // Get pos change between step and step
    infor->Pos_Delta = infor->Pos_Now - infor->Pos_Old;
    infor->Pos_Old = infor->Pos_Now;

    // Decide target step pos

    dummy = ( speedctrl->Target_ERPM * speedctrl->Pos_Const ) + speedctrl->Target_Pos_Step_Rest;
    //speedctrl->Target_Pos_Step = dummy / SPDCTRL_TIME_CONST;
    //speedctrl->Target_Pos_Step_Rest = MOD( dummy, SPDCTRL_TIME_CONST );
    speedctrl->Target_Pos_Step = dummy / ctrl_time_const;
    speedctrl->Target_Pos_Step_Rest = MOD( dummy, ctrl_time_const );

    // To get loop 1 target ( It is sub-speed control target speed )
    dummy = (  speedctrl->Target_Pos_Step - infor->Pos_Delta ) * speedctrl->Loop_1_Kp;
    speedctrl->Loop_1_Target += dummy;
    //speedctrl->Loop_1_Rest = MOD( dummy, SPDCTRL_SCALE_CONST );

    // Sub-speed control loop
    speedctrl->Loop_2_SpeedPID.Input = speedctrl->Loop_1_Target;
    speedctrl->Loop_2_SpeedPID.Feedback = infor->SpeedERPM;
    il_PID_Run_P ( &speedctrl->Loop_2_SpeedPID );

    // Step Limit
    step = speedctrl->Loop_2_SpeedPID.Output - speedctrl->Output;

    if( step > speedctrl->Loop_2_StepLimit ){
        step = speedctrl->Loop_2_StepLimit;
    }else if( step < -speedctrl->Loop_2_StepLimit ){
        step = -speedctrl->Loop_2_StepLimit;
    }

    speedctrl->Output += step;

    // Speed control output could be limit by some reason ( ex: torque limit )
    // Once the output is limited, loop_1 target should also be limit ( Output = loop 1 target x PID_P )

#if(1)
    dummy = infor->SpeedERPM + speedctrl->Output * AC_PID_CONST / speedctrl->Loop_2_SpeedPID.Kp_Const;
    if( dummy < 0 ){
        dummy *= -1;
    }

    /*
    limit = speedctrl->Target_Pos_Step * speedctrl->Loop_1_Kp;

    if( limit < 0 ){
        limit *= -1;
    }

    limit += SPDCTRL_ALLOWED_ERPM_ERROR_CONST;
    */
    limit = speedctrl->Target_Pos_Step;
    if( limit < 0 ){
        limit *= -1;
    }
    limit++;

    limit = limit * speedctrl->Loop_1_Kp;

    limit *= 2;
    limit += speedctrl->Allowed_Erpm_Error_Const;

    dummy += limit;

    if( speedctrl->Loop_1_Target > dummy  ){
        speedctrl->Loop_1_Target = dummy;
    }else if( speedctrl->Loop_1_Target < -dummy ){
        speedctrl->Loop_1_Target = -dummy;
    }
#endif

}

/*===========================================================================================
    Function Name    : il_SpeedControl_Run_Advance
    Input            :  1. speedctrl
                        2. infor
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_Run_Advance ( Struct_SpeedControl* speedctrl, Struct_DriverMotorInfor* infor )
{
    int32_t dummy;
    int32_t dummy2;
    int32_t limit;
    int32_t step;
    int32_t kp = speedctrl->Loop_1_Kp;
    int32_t ctrl_time_const = SPDCTRL_TIME_CONST * infor->Pole_Factor;

    // Get pos change between step and step
    //infor->Pos_Delta = infor->Pos_Now - infor->Pos_Old;
    //infor->Pos_Old = infor->Pos_Now;

    // Decide target step pos

    dummy = ( speedctrl->Target_ERPM * speedctrl->Pos_Const ) + speedctrl->Target_Pos_Step_Rest;
    /*
    speedctrl->Target_Pos_Step = dummy / SPDCTRL_TIME_CONST;
    //speedctrl->Target_Pos_Step_Rest = MOD( dummy, SPDCTRL_TIME_CONST );
    speedctrl->Target_Pos_Step_Rest = dummy - speedctrl->Target_Pos_Step * SPDCTRL_TIME_CONST;*/
    speedctrl->Target_Pos_Step = dummy / ctrl_time_const;
    //speedctrl->Target_Pos_Step_Rest = MOD( dummy, SPDCTRL_TIME_CONST );
    speedctrl->Target_Pos_Step_Rest = dummy - speedctrl->Target_Pos_Step * ctrl_time_const;

    // To get loop 1 target ( It is sub-speed control target speed )
    dummy = (  speedctrl->Target_Pos_Step - infor->Pos_Delta ) * kp;
    dummy2 = dummy / SPDCTRL_LOOP_1_KP_SCALE_CONST;
    speedctrl->Loop_1_Target += dummy2;
    //speedctrl->Loop_1_Rest = MOD( dummy, SPDCTRL_LOOP_1_KP_SCALE_CONST );
    speedctrl->Loop_1_Rest = dummy - dummy2 * SPDCTRL_LOOP_1_KP_SCALE_CONST;

    // Sub-speed control loop
    speedctrl->Loop_2_SpeedPID.Input = speedctrl->Loop_1_Target;
    speedctrl->Loop_2_SpeedPID.Feedback = infor->SpeedERPM;
    il_PID_Run_P ( &speedctrl->Loop_2_SpeedPID );

    // Step Limit
    step = speedctrl->Loop_2_SpeedPID.Output - speedctrl->Output;

    if( step > speedctrl->Loop_2_StepLimit ){
        step = speedctrl->Loop_2_StepLimit;
    }else if( step < -speedctrl->Loop_2_StepLimit ){
        step = -speedctrl->Loop_2_StepLimit;
    }

    speedctrl->Output += step;

    // Speed control output could be limit by some reason ( ex: torque limit )
    // Once the output is limited, loop_1 target should also be limit ( Output = loop 1 target x PID_P )

    dummy = infor->SpeedERPM + speedctrl->Output * AC_PID_CONST / speedctrl->Loop_2_SpeedPID.Kp_Const;
    if( dummy < 0 ){
        dummy *= -1;
    }

    /*
    limit = speedctrl->Target_Pos_Step * kp / SPDCTRL_LOOP_1_KP_SCALE_CONST;

    if( limit < 0 ){
        limit *= -1;
    }

    limit += SPDCTRL_ALLOWED_ERPM_ERROR_CONST;
    */

    limit = speedctrl->Target_Pos_Step;
    if( limit < 0 ){
        limit *= -1;
    }
    limit++;

    limit = limit * kp / SPDCTRL_LOOP_1_KP_SCALE_CONST;
    limit++;

    limit *= 2;
    limit += speedctrl->Allowed_Erpm_Error_Const;

    dummy += limit;

    if( speedctrl->Loop_1_Target > dummy  ){
        speedctrl->Loop_1_Target = dummy;
    }else if( speedctrl->Loop_1_Target < -dummy ){
        speedctrl->Loop_1_Target = -dummy;
    }

}

/*===========================================================================================
    Function Name    : il_SpeedControl_ReduceOutput
    Input            : 1.speedctrl
                       2.step_value
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_SpeedControl_ReduceOutput( Struct_SpeedControl* speedctrl, int32_t step_value )
{
    int32_t step;
    static int32_t rest = 0;
    int32_t dummy;

    dummy = step_value + rest;
    step = dummy / SPDCTRL_SCALE_CONST;
    rest = MOD( dummy, SPDCTRL_SCALE_CONST );


    if( speedctrl->Output > 0 ){
        speedctrl->Output -= step;
    }else if( speedctrl->Output  < 0 ){
        speedctrl->Output += step;
    }

}

#endif

/************************** <END OF FILE> *****************************************/
