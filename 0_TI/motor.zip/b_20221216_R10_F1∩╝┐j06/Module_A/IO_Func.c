/*===========================================================================================
    File Name       : IO_Func.c  
    Built Date      : 2014-08-29
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file provides the IO function command of the driver. (replaced io functions of original BLDC_CTRL)
    =========================================================================================
    History         : 2014-08-29 Perlimary version.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_IO_FUNC						        CG_IO_Func_M0;
//volatile Struct_IO_FUNC                             CG_IO_Func_M1;

extern volatile Struct_MD                           CG_MD;
extern 	volatile Struct_IO							CG_IO;
extern 	volatile Struct_Parameter					CG_Parameter;
//extern volatile Struct_BLDC_CTRL 					CG_BLDC_CTRL;
extern volatile Struct_BLDC_CTRL                    CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL                    CG_BLDC_CTRL_M1;
extern volatile Struct_OPMode                       CG_OPMode;

extern void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void );

/*===========================================================================================
    SC CC mode selection const array
//==========================================================================================*/
const uint8_t const_SC_CC_SEL[ 2 ][ 5 ]= { 0, 1, 2, 1, 2,
										   0, 3, 4, 3, 4 };

//! Input Xn functions	
uint32_t ( *const inputXn_action[ FUNC_NUM ] ) ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 ) =
{
	ioFunc_NoAction,	ioFunc_StartStop,	ioFunc_CWCCW ,		ioFunc_CWStop,		ioFunc_CCWStop,
	    ioFunc_Free,	ioFunc_StopMode,	ioFunc_NormalIO,	ioFunc_NormalIO,	ioFunc_NoAction,
	ioFunc_NormalIO,	ioFunc_NormalIO,	ioFunc_NormalIO,	ioFunc_EBrake,      ioFunc_KeySwitch,
	ioFunc_NormalIO,	ioFunc_NormalIO,	ioFunc_STOP,        ioFunc_MOS_OT,    	ioFunc_MOTOR_OT,
	ioFunc_RGN_OT,		ioFunc_EXT_ERROR,	ioFunc_NormalIO,	ioFunc_NormalIO,	ioFunc_NormalIO,
	ioFunc_NormalIO,	ioFunc_NormalIO,    ioFunc_NormalIO,    ioFunc_NormalIO,    ioFunc_NormalIO,
	ioFunc_NormalIO,    ioFunc_NormalIO
};

/*===========================================================================================
    Function Name    : variableInitial_IO_Func
    Input            : io_func
    Return           : Null
    Programmer       : Gear.Frng@trumman.com.tw
    Description      : Variable io_func initial
					   Should be execute only after parameter initial.
//==========================================================================================*/
void variableInitial_IO_Func ( Struct_IO_FUNC* io_func )
{
	uint8_t i, j;
	
	io_func->SC_CC_Mode = 0;

	for( i = 0; i < CMD_NUM; i++ ){
	    io_func->CMD_SRC[i] = SRC_ALL;
	}
	
	for( i = 0; i < OUTPUT_FUNC_NUM; i++ ){
	    //io_func->Output_State[ i ] = 1 - CG_IO.ActState_of_Func[ i ];
	    io_func->Output_State[ i ] = 0;
	    //io_func->ActState_of_Func[ i ] = LOW;
	    io_func->ActState_of_Func[ i ] = HIGH;
	    io_func->OutputPin_of_Func[ i ] = 0;
	}
	
	for( i = 0; i < SRC_NUM; i++ ){
	    io_func->IOF_STAT_BITF[i] = 0;
		for( j = 0; j < CMD_NUM; j++ ){
		    io_func->CMD[ i ][ j ] = 0;
		}
	}

	//
	io_func->EncoderPulse_Enable = NO;
	io_func->EncoderPulse_Stamp = 0;
	io_func->EncoderPulse_State = 0;
	io_func->EncoderPulse_Direction = DIR_CW;

	//
	io_func->Battery_Gauge_Timer_Ms = 0;
}

/*===========================================================================================
    Function Name    : ioFunc_NoAction
    Input            : 1. io_func
					   2. motor_state: BLDC motor state.
					   3. pa1: NULL.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : IO command function
//==========================================================================================*/
uint32_t ioFunc_NoAction ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
	return (1);
}

/*===========================================================================================
    Function Name    : ioFunc_StartStop
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of START/STOP to determine the CMD_RUN state.
//==========================================================================================*/
uint32_t ioFunc_StartStop ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //uint32_t cw_limit_state;
    //uint32_t ccw_limit_state;
    //io_func->IOF_STAT_BITF					  = state;


    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];

	state = ( ( ( iof_state_bitf >> FUNC_START_STOP ) & 0x01 ) &
			  (~((iof_state_bitf >> FUNC_STOP) & 0x01)) );

	//
	/*
	cw_limit_state = ( iof_state_bitf >> FUNC_CW_LIMIT ) & 0x01;
	ccw_limit_state = ( iof_state_bitf >> FUNC_CCW_LIMIT ) & 0x01;
	if( ( io_func->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CW && cw_limit_state ) ||
	    ( io_func->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CCW && ccw_limit_state )   ){
	    state = LOW;
	}*/
	//

	io_func->CMD[ SRC_ALL ][ CMD_RUN ] 		  = state;
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_CWCCW
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of CW/CCW to determine CMD_DIR state.
//==========================================================================================*/
uint32_t ioFunc_CWCCW ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{	
    uint32_t state;
    //io_func->IOF_STAT_BITF					= state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];

	state = ((iof_state_bitf >> FUNC_CW_CCW) & 0x01);
	
	switch( pa1 ){
		case DISABLE:
			
			if(  motor_state != MOTOR_STATE_RUNNING && motor_state != MOTOR_STATE_EBRAKING  ){
				
				if( state == HIGH ){
				    io_func->CMD[ SRC_ALL ][ CMD_DIR ] 	= DIR_CCW;
				}else{
				    io_func->CMD[ SRC_ALL ][ CMD_DIR ] 	= DIR_CW;
				}	
					
			}
		
			break;
		case ENABLE:
			
			if( motor_state != MOTOR_STATE_EBRAKING ){
				if( state == HIGH ){
				    io_func->CMD[ SRC_ALL ][ CMD_DIR ] 	= DIR_CCW;
				}else{
				    io_func->CMD[ SRC_ALL ][ CMD_DIR ] 	= DIR_CW;
				}
			}
		
			break;
		default:
			break;	
		
		
	}

    return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_CWStop
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of CW/STOP to determine RUN and DIR state.
//==========================================================================================*/
uint32_t ioFunc_CWStop ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{	
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];

	state = ( ((iof_state_bitf >> FUNC_CW_STOP) & 0x01) &
			  (~((iof_state_bitf >> FUNC_STOP) & 0x01)) );
	
	switch( pa1 ){
		
		case DISABLE:
			
			if(  ( io_func->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH && io_func->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CCW ) ||
				 ( ( iof_state_bitf & (1UL << FUNC_CCW_STOP)) != 0 ) ){
					
				// Do nothing
				// 2013_0319 by Gear.
				if ( (( iof_state_bitf >> FUNC_STOP) & 0x01) != 0 ) {
				    io_func->CMD[ SRC_ALL ][ CMD_RUN ] = LOW;
				}	
			}else{
				
			    io_func->CMD[ SRC_ALL ][ CMD_RUN ] = state;
				
				if( state == HIGH ){
				    io_func->CMD[ SRC_ALL ][ CMD_DIR ] = DIR_CW;
				}
			}
		
			break;
		case ENABLE:
			
			if(  ( io_func->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH && io_func->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CCW ) ||
				 ( ( iof_state_bitf & (1UL << FUNC_CCW_STOP)) != 0 ) ){
				
				if( state == HIGH )	 
				    io_func->CMD[ SRC_ALL ][ CMD_RUN ] = LOW;
			}else{
			
			    io_func->CMD[ SRC_ALL ][ CMD_RUN ] = state;
				if( state == HIGH ){
				    io_func->CMD[ SRC_ALL ][ CMD_DIR ] = DIR_CW;
				}
			}
		
			break;
		default:
			break;		
	}
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_CCWStop
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of CW/STOP to determine RUN and DIR state.
//==========================================================================================*/
uint32_t ioFunc_CCWStop ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	
	state = ( ((iof_state_bitf >> FUNC_CCW_STOP) & 0x01) &
			  (~((iof_state_bitf >> FUNC_STOP) & 0x01)) );
	
	switch( pa1 ){
		
		case DISABLE:
			
			if(  ( io_func->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH && io_func->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CW ) ||
				 ( (iof_state_bitf & (1UL << FUNC_CW_STOP)) != 0 ) ){
				
				// Do nothing
				// 2013_0319 by Gear.
				if ( ((iof_state_bitf >> FUNC_STOP) & 0x01) != 0 ) {
				    io_func->CMD[ SRC_ALL ][ CMD_RUN ] = LOW;
				}
				
			}else{
				
				io_func->CMD[ SRC_ALL ][ CMD_RUN ] = state;
				
				if( state == HIGH ){
				    io_func->CMD[ SRC_ALL ][ CMD_DIR ] = DIR_CCW;
				}
			}
		
			break;
		case ENABLE:
			
			if(  ( io_func->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH && io_func->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CW ) ||
				 ( (iof_state_bitf & (1UL << FUNC_CW_STOP)) != 0 ) ){
				if( state == HIGH )	
					io_func->CMD[ SRC_ALL ][ CMD_RUN ] = LOW;
			}else{
			
				io_func->CMD[ SRC_ALL ][ CMD_RUN ] = state;
				if( state == HIGH ){
					io_func->CMD[ SRC_ALL ][ CMD_DIR ] = DIR_CCW;
				}
			}
		
			break;
		default:
			break;		
	}	
	
	return (state);
	
}

/*===========================================================================================
    Function Name    : ioFunc_EBrake
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command of EBrake to determine CMD_EBRAKE state.
//==========================================================================================*/
uint32_t ioFunc_EBrake ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	
	if( iof_state_bitf & ( ( 1UL << FUNC_EBRAKE ) | ( 1UL << FUNC_EBA_RESET ) ) ){
		io_func->CMD[ SRC_ALL ][ CMD_EBRAKE ] 		= HIGH;
	}else{
		io_func->CMD[ SRC_ALL ][ CMD_EBRAKE ] 		= LOW;
	}
	state = io_func->CMD[ SRC_ALL ][ CMD_EBRAKE ];

	return (state);	
}

/*===========================================================================================
    Function Name    : ioFunc_EBAReset
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command EBAReset to determine CMD_EBRAKE state.
//==========================================================================================*/
uint32_t ioFunc_EBAReset ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	
	if( iof_state_bitf & ( ( 1UL << FUNC_EBRAKE ) | ( 1UL << FUNC_EBA_RESET ) ) ){
		io_func->CMD[ SRC_ALL ][ CMD_EBRAKE ] 		= HIGH;
	}else{
		io_func->CMD[ SRC_ALL ][ CMD_EBRAKE ] 		= LOW;
	}
	state = io_func->CMD[ SRC_ALL ][ CMD_EBRAKE ];

	return (state);	
}

/*===========================================================================================
    Function Name    : ioFunc_KeySwitch
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_KeySwitch ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	state = ((iof_state_bitf >> FUNC_KEY_SWITCH) & 0x01);
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_Free
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command to determine CMD_FREE.
//==========================================================================================*/
uint32_t ioFunc_Free ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	state = ((iof_state_bitf >> FUNC_FREE) & 0x01);
	io_func->CMD[ SRC_ALL ][ CMD_FREE ]			= state;
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_StopMode
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_StopMode ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	state = ((iof_state_bitf >> FUNC_STOP_MODE) & 0x01);
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_NormalIO
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_NormalIO ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    //io_func->IOF_STAT_BITF                    = state;
    //state = io_func->IOF_STAT_BITF;
	return (1);
}

/*===========================================================================================
    Function Name    : ioFunc_STOP
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : IO command function.
//==========================================================================================*/
uint32_t ioFunc_STOP ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];

	state = ((iof_state_bitf >> FUNC_STOP) & 0x01);

	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_MOS_OT
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command of IO type OT.
//==========================================================================================*/
uint32_t ioFunc_MOS_OT ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	state = ((iof_state_bitf >> FUNC_MOS_OT) & 0x01);
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_MOTOR_OT
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command of IO type OT.
//==========================================================================================*/
uint32_t ioFunc_MOTOR_OT ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	state = ((iof_state_bitf >> FUNC_MOTOR_OT) & 0x01);
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_RGN_OT
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command of IO type OT.
//==========================================================================================*/
uint32_t ioFunc_RGN_OT ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	state = ((iof_state_bitf >> FUNC_RGN_OT) & 0x01);
	
	return (state);
}

/*===========================================================================================
    Function Name    : ioFunc_EXT_ERROR
    Input            : 1. io_func
                       2. motor_state: BLDC motor state.
                       3. pa1: NULL.
    Return           : IO Func state.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : IO command.
//==========================================================================================*/
uint32_t ioFunc_EXT_ERROR ( Struct_IO_FUNC* io_func, const uint8_t motor_state, const int32_t pa1 )
{
    uint32_t state;
    //io_func->IOF_STAT_BITF                    = state;
    uint32_t iof_state_bitf = io_func->IOF_STAT_BITF[ SRC_ALL ];
	state = ((iof_state_bitf >> FUNC_EXT_ERROR) & 0x01);
	
	return (state);
}


/*===========================================================================================
    Function Name    : ioFunc_Polling_routine
    Input            : 1. io
                       2. io_func_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : io Stat routine. Called in main loop.
//==========================================================================================*/
void ioFunc_Polling_routine ( Struct_IO* io, Struct_IO_FUNC* io_func_m0 )
{
    uint8_t i;
    uint8_t j;
    uint32_t state;
    uint32_t func;
    uint8_t driver;
    uint32_t dummy_io_func_m0;
    //uint32_t dummy_io_func_m1;

    uint32_t io_func_all_m0 = 0;
    //uint32_t io_func_all_m1 = 0;

    for( j = 0; j < SRC_ALL; j++ ){

        dummy_io_func_m0 = 0;
        //dummy_io_func_m1 = 0;

        for( i = 0; i < XN_MAX_NUM; i++ ){

            state = ( io->DI_XN_BITF[ j ] >> i ) & 0x01;
            func = io->DIn_Func[ j ][ i ];

            driver = func / IO_FUNC_MOTOR_CONST;
            func = func % IO_FUNC_MOTOR_CONST;

            switch( driver ){
            case CMD_MOTOR_ALL_INDEX:
                dummy_io_func_m0 |= ( state << func );
                //dummy_io_func_m1 |= ( state << func );
                break;
            case CMD_MOTOR_0_INDEX:
                dummy_io_func_m0 |= ( state << func );
                break;
            case CMD_MOTOR_1_INDEX:
                //dummy_io_func_m1 |= ( state << func );
                break;
            default:
                // Error
                break;

            }

        }

        io_func_all_m0 |= dummy_io_func_m0;
        //io_func_all_m1 |= dummy_io_func_m1;

        io_func_m0->IOF_STAT_BITF[j] = dummy_io_func_m0;
        //io_func_m1->IOF_STAT_BITF[j] = dummy_io_func_m1;

    }

    io_func_m0->IOF_STAT_BITF[ SRC_ALL ] = io_func_all_m0;
    //io_func_m1->IOF_STAT_BITF[ SRC_ALL ] = io_func_all_m1;

}

/*===========================================================================================
    Function Name    : stop_command_determine
    Input            : Null
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Determine the FUNC_STOP of VR ( or zero speed sill in consideration )
					   Called in main loop.
//==========================================================================================*/
void stop_command_determine ( void )
{
    Struct_BLDC_CTRL *bldc_ctrl;
    int32_t speed_src;
    int32_t i;
    int32_t stop_bit;

    for( i = 0; i < CG_MD.Driver_Num; i++ ){

        if( i == 0 ){
            bldc_ctrl = ( Struct_BLDC_CTRL* )&CG_BLDC_CTRL_M0;
            stop_bit = SRC_EEP_IO_STOP_BIT_M0;
        }/*else{
            bldc_ctrl = ( Struct_BLDC_CTRL* )&CG_BLDC_CTRL_M1;
            stop_bit = SRC_EEP_IO_STOP_BIT_M1;
        }*/

        speed_src = bldc_ctrl->OpMode_Ptr->Stop_Cmd_Src;

        switch ( speed_src ) {
            case SPEED_TAR_INT_VR:
                vrFunc_StartStop( *bldc_ctrl->VR_Speed / THROTTLE_MULTIFY, INTVR_STOP_VALUE, INTVR_RUN_VALUE, stop_bit );
                break;
            case SPEED_TAR_EXT_VR_SINGLE_ENDED:
            case SPEED_TAR_PULSE_DUTY:
            case SPEED_TAR_PULSE_FREQ:
                vrFunc_StartStop( *bldc_ctrl->VR_Speed / THROTTLE_MULTIFY, VR_STOP_VALUE_RISING, VR_RUN_VALUE_RISING, stop_bit );
                break;
            case SPEED_TAR_DIO:
            default:
                CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
                break;

        }
    }

}

/*===========================================================================================
    Function Name    : vrFunc_StartStop
    Input            : 
					   1.adc_value: ADC value
					   2.stop value : Stop value
					   3.run_value : Run value
					   4.stop_bit
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Function for VR Min stop.
//==========================================================================================*/
void vrFunc_StartStop ( uint32_t adc_value, uint32_t stop_value, uint32_t run_value, int32_t stop_bit )
{

	if( ( CG_IO.DI_XN_BITF[ SRC_EEP ] & _BIT( stop_bit ) ) == 0 ){	// already run
		
		if( adc_value >= stop_value ){
			CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
		}else{
			CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( stop_bit );
		}
	}else{ 																			// stop
		
		if( adc_value >= run_value ){
			CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
		}else{
			CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( stop_bit );
		}
	}
	
}

/*===========================================================================================
    Function Name    : vrFunc_Stop
    Input            : 1.adc_value: ADC value
                       2.stop value : Stop value
                       3.run_value : Run value
                       4.stop_bit
                       5.is_reverse
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Function for VR Min stop.
//==========================================================================================*/
void vrFunc_Stop ( uint32_t adc_value, uint32_t stop_value, uint32_t run_value, int32_t stop_bit, int32_t is_reverse )
{

    if( ( CG_IO.DI_XN_BITF[ SRC_EEP ] & _BIT( stop_bit ) ) == 0 ){  // already run
        if( ( adc_value >= stop_value && !is_reverse ) ||
            ( adc_value <= stop_value && is_reverse )    ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
        }else{
            CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( stop_bit );
        }
    }else{                                                          // stop
        if( ( adc_value >= run_value && !is_reverse ) ||
            ( adc_value <= run_value && is_reverse ) ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
        }else{
            CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( stop_bit );
        }
    }

}

/*===========================================================================================
    Function Name    : vrFunc_WigWag
    Input            : 1.adc_value: ADC value
                       2.vr_mid
                       3.vr_deadband
                       4.run_distance
                       5.stop_distance
                       6.stop_bit
                       7.dir_bit
                       8.type
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Function for VR Min stop.
//==========================================================================================*/
void vrFunc_WigWag ( uint32_t adc_value, int32_t vr_mid, int32_t vr_deadband, int32_t run_distance, int32_t stop_distance, int32_t stop_bit, int32_t dir_bit, int32_t type )
{
    int32_t mid_low_run = vr_mid - vr_deadband + run_distance;
    int32_t mid_high_run = vr_mid + vr_deadband - run_distance;
    int32_t mid_low_stop = vr_mid - vr_deadband + stop_distance;
    int32_t mid_high_stop = vr_mid + vr_deadband - stop_distance;

    if( ( CG_IO.DI_XN_BITF[ SRC_EEP ] & _BIT( stop_bit ) ) == 0 ){  // already run
        if( adc_value <= mid_low_stop || adc_value >= mid_high_stop ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
        }else{
            CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( stop_bit );
        }
    }else{                                                          // stop
        if( adc_value <= mid_low_run || adc_value >= mid_high_run ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
        }else{
            CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( stop_bit );
        }
    }

    if( type == SPEED_TAR_EXT_VR_WIG_WAG ){
        if( adc_value >= mid_high_stop ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( dir_bit );
        }else if( adc_value <= mid_low_stop ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( dir_bit );
        }
    }else if( type == SPEED_TAR_EXT_VR_WIG_WAG_R ){
        if( adc_value >= mid_high_stop ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( dir_bit );
        }else if( adc_value <= mid_low_stop ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( dir_bit );
        }
    }else{
        CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( dir_bit );
    }


}

/*===========================================================================================
    Function Name    : vrFunc_Advance
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void vrFunc_Advance ( void )
{
    Struct_BLDC_CTRL *bldc_ctrl;
    int32_t speed_src;
    int32_t i;
    int32_t stop_bit;
    int32_t dir_bit;

    for( i = 0; i < CG_MD.Driver_Num; i++ ){

        if( i == 0 ){
            bldc_ctrl = ( Struct_BLDC_CTRL* )&CG_BLDC_CTRL_M0;
            stop_bit = SRC_EEP_IO_STOP_BIT_M0;
            dir_bit = SRC_EEP_IO_DIR_BIT_M0;
        }/*else{
            bldc_ctrl = ( Struct_BLDC_CTRL* )&CG_BLDC_CTRL_M1;
            stop_bit = SRC_EEP_IO_STOP_BIT_M1;
            dir_bit = SRC_EEP_IO_DIR_BIT_M1;
        }*/

        speed_src = bldc_ctrl->OpMode_Ptr->Stop_Cmd_Src;

        switch ( speed_src ) {
            case SPEED_TAR_INT_VR:
                vrFunc_Stop( *bldc_ctrl->VR_Speed / THROTTLE_MULTIFY, INTVR_STOP_VALUE, INTVR_RUN_VALUE, stop_bit, NO );
                CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( dir_bit );
                break;
            case SPEED_TAR_EXT_VR_SINGLE_ENDED:
            case SPEED_TAR_PULSE_DUTY:
            case SPEED_TAR_PULSE_FREQ:
                vrFunc_Stop( *bldc_ctrl->VR_Speed / THROTTLE_MULTIFY, VR_STOP_VALUE_RISING, VR_RUN_VALUE_RISING, stop_bit, NO );
                CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( dir_bit );
                break;
            case SPEED_TAR_EXT_VR_SINGLE_ENDED_R:
                vrFunc_Stop( *bldc_ctrl->VR_Speed / THROTTLE_MULTIFY, VR_STOP_VALUE_FALLING, VR_RUN_VALUE_FALLING, stop_bit, YES );
                CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( dir_bit );
                break;
            case SPEED_TAR_EXT_VR_WIG_WAG:
            case SPEED_TAR_EXT_VR_WIG_WAG_R:
            case SPEED_TAR_EXT_VR_UNIPOLAR:
                vrFunc_WigWag ( *bldc_ctrl->VR_Speed / THROTTLE_MULTIFY,
                                ( ( CG_OPMode.AD_Offset + CG_OPMode.Throttle_Max ) / THROTTLE_MULTIFY ) >> 1,
                                CG_OPMode.Throttle_DeadBand_PA,
                                VR_RUN_V_DISTANCE,
                                VR_STOP_V_DISTANCE,
                                stop_bit,
                                dir_bit,
                                speed_src );

                break;
            case SPEED_TAR_DIO:
            default:
                CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( stop_bit );
                CG_IO.DI_XN_BITF[ SRC_EEP ] &= ~_BIT( dir_bit );
                break;

        }

        // STOP if Pulse signal lost
        if( bldc_ctrl->Control_Mode != CTRL_POSITION &&
            bldc_ctrl->OpMode_Ptr->Mode_Num2 == OP_MODE_THROTTLE_PULSE &&
            *bldc_ctrl->OpMode_Ptr->PW == 0 ){
            CG_IO.DI_XN_BITF[ SRC_EEP ] |= _BIT( stop_bit );
        }
        //

    }
}

/*===========================================================================================
    Function Name    : output_ShowInBITF
    Input            : Struct_IO_FUNC* io_func
    Return           : Output state in BITF.
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Return BITF of all outputs
						bit0 = NC
						bit1 = Output function 1 status
						bit2 = output function 2 status...
//==========================================================================================*/
int32_t output_ShowInBITF ( Struct_IO_FUNC* io_func )
{
	int32_t Output_BIFT = 0;

	int32_t i;

	for( i = OUTPUT_SPD_OUT; i < OUTPUT_FUNC_NUM; i++ ){
		//Output_BIFT |= ( io_func->Output_State[ i ] << i );
		Output_BIFT |= ( ( io_func->Output_State[ i ] == io_func->ActState_of_Func[ i ] ) << i );
	}


	return Output_BIFT;
}


/************************** <END OF FILE> *****************************************/
