/*===========================================================================================
    File Name       : Type.h
    Version         : V1.02a
    Built Date      : 2012-10-24
    Release Date    : Not Yet
    Programmer      : Chaim.Chen@trumman.com.tw
    Description     : This file provide type defines for C language.
    =========================================================================================
    History         : 2012-10-24 first released version
					  2014-07-22 V1.01r(R8): Declaration format modified.
					  2014-08-01 V1.02a(R8): Binary expression macro added.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */


#ifndef TYPE_H
#define TYPE_H

    /* exact-width signed integer types */
typedef   signed          char int8_t;
//typedef   signed short     int int16_t;
//typedef   signed           long int32_t;
//typedef   signed       __int64 int64_t;

    /* exact-width unsigned integer types */
typedef unsigned          char uint8_t;
//typedef unsigned short     int uint16_t;
//typedef unsigned           long uint32_t;
//typedef unsigned       __int64 uint64_t;

#ifndef NULL
#define NULL    ((void *)0)
#endif

#ifndef FALSE
#define FALSE   (0)
#endif

#ifndef TRUE
#define TRUE    (1)
#endif

#ifndef HIGH
#define HIGH    (1)
#endif

#ifndef LOW
#define LOW     (0)
#endif

#ifndef NO
#define NO		(0)
#endif

#ifndef YES
#define YES !NO
#endif


typedef enum {RESET = 0, SET = !RESET} FlagStatus, ITStatus;
typedef enum {DISABLE = 0, ENABLE = !DISABLE} FunctionalState;

//#define MOD( a, b ) 		( (a) % (b) )
#define MOD( a, b )		( (a) - ( (a) / (b) ) * (b) )

/* _BIT(n) sets the bit at position "n"
 * _BIT(n) is intended to be used in "OR" and "AND" expressions:
 * e.g., "(_BIT(3) | _BIT(7))".
 */
#undef _BIT
/* Set bit macro */
#define _BIT(n)	(1UL<<n)

/* Macro for binary expression to get it's value */
#define HEX__(n)	0x##n##LU
#define B8__(x)	((x&0x0000000FLU)?1:0) \
				+((x&0x000000F0LU)?2:0) \
				+((x&0x00000F00LU)?4:0) \
				+((x&0x0000F000LU)?8:0) \
				+((x&0x000F0000LU)?16:0) \
				+((x&0x00F00000LU)?32:0) \
				+((x&0x0F000000LU)?64:0) \
				+((x&0xF0000000LU)?128:0)

#define _0B8(d) ((unsigned char)B8__(HEX__(d)))
#define _0B16(dmsb,dlsb) (((unsigned short)_0B8(dmsb)<<8) + _0B8(dlsb))
#define _0B32(dmsb,db2,db3,dlsb) \
(((unsigned long)_0B8(dmsb)<<24) \
+ ((unsigned long)_0B8(db2)<<16) \
+ ((unsigned long)_0B8(db3)<<8) \
+ _0B8(dlsb))

#endif
