/*===========================================================================================
    File Name       : C2000_PhaseAdv.c
    Built Date      : 2015-03-12
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for BLDC motor phase advance.			
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile 		Struct_PhaseAdv 					CG_PhaseAdv;
//extern volatile Struct_BLDC_CTRL 					CG_BLDC_CTRL;
//extern volatile Struct_Speed 						CG_Speed;
extern volatile Struct_BLDC_Drive 					CG_BLDC_Drive;
extern volatile Struct_Parameter					CG_Parameter;

/*===========================================================================================
    Function Name    : variableInitial_PhaseAdv
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_PhaseAdv initial
//==========================================================================================*/
void variableInitial_PhaseAdv ( void )
{
	CG_PhaseAdv.Enabled = 0;
	CG_PhaseAdv.pre_advance = -128;
	CG_PhaseAdv.adj_advance = 128;
	CG_PhaseAdv.advance_tick = 0;
	
	CpuTimer2Regs.TCR.bit.TSS = 1;		// Make sure timers are stopped:
	EALLOW;  // This is needed to write to EALLOW protected registers
	PieVectTable.TIMER2_INT = &cpu_timer2_isr;
	EDIS;    // This is needed to disable write to EALLOW protected registers

	CpuTimer2Regs.TCR.bit.TIE = 1;
	CpuTimer2Regs.TCR.bit.TIF = 1;

	IER |= M_INT14;

}


/*===========================================================================================
    Function Name    : il_timerStart_2
    Input            : 
					   1.time : indicate when to make an interrupt
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup the phase advance timer.
					   ( Here timer1 was used ).
//==========================================================================================*/
#if(0)
__inline void il_timerStart_2( uint32_t time )
{
	CpuTimer2Regs.TCR.bit.TSS = 1;
	CpuTimer2Regs.TCR.bit.TIF = 1;
	CpuTimer2Regs.PRD.all = time;
	CpuTimer2Regs.TCR.bit.TRB = 1;
	CpuTimer2Regs.TCR.bit.TSS = 0; // Use write-only instruction to set TSS bit = 0      // Counter enable
		
}
#endif


/*===========================================================================================
    Function Name    : phaseAdvance
    Input            : 
					   1.enabled: 1 = use phase advance, 0 = not to use.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Phase advance.
//==========================================================================================*/
void phaseAdvance( int enabled )
{
#if(0)
    static uint32_t angle = 0;
	
	     
	CG_PhaseAdv.phase_adcance = CG_PhaseAdv.pre_advance + CG_PhaseAdv.adj_advance;
		
	if( CG_PhaseAdv.phase_adcance >= 0 ){                                 //== Phase advance
		
		if( CG_PhaseAdv.phase_changed == NO ){		
				
			commutation_output[ CG_BLDC_Drive.Mode ]( CG_BLDC_CTRL.Commutation );
			
		}
			
		CG_PhaseAdv.phase_changed = NO;

		
		CG_PhaseAdv.pa_Commutation = CG_BLDC_CTRL.Commutation;		
		
		if(  ( CG_Speed.current_dir == DIR_CW  && CG_PhaseAdv.pa_Commutation_Type ==  PA_COMMUTATION_TYPE_ACC ) ||
			 ( CG_Speed.current_dir == DIR_CCW && CG_PhaseAdv.pa_Commutation_Type ==  PA_COMMUTATION_TYPE_DEC )	){
			if( ++CG_PhaseAdv.pa_Commutation > 5 )
				CG_PhaseAdv.pa_Commutation = 0;
		}else{
			if( --CG_PhaseAdv.pa_Commutation < 0 )
				CG_PhaseAdv.pa_Commutation = 5;
		}	
		
		angle = ( CG_Speed.phase_length / PHASE_ADV_MAX ) * ( PHASE_ADV_MAX -  CG_PhaseAdv.phase_adcance ) ;
		if( angle > CG_PhaseAdv.advance_tick ){
			angle -= CG_PhaseAdv.advance_tick;
		}else{
			angle = 0;
		}
		
		il_timerStart_2( angle );

	}else if( CG_PhaseAdv.phase_adcance < 0 ){                            //== Phase delay
		
		
		if( CG_PhaseAdv.phase_changed == NO ){

			CG_PhaseAdv.pa_Commutation = CG_BLDC_CTRL.Commutation;
			if(  ( CG_Speed.current_dir == DIR_CW  && CG_PhaseAdv.pa_Commutation_Type ==  PA_COMMUTATION_TYPE_ACC ) ||
				 ( CG_Speed.current_dir == DIR_CCW && CG_PhaseAdv.pa_Commutation_Type ==  PA_COMMUTATION_TYPE_DEC )	){
				if( --CG_PhaseAdv.pa_Commutation < 0 )
					CG_PhaseAdv.pa_Commutation = 5;
			}else{
				if( ++CG_PhaseAdv.pa_Commutation > 5 )
					CG_PhaseAdv.pa_Commutation = 0;
			}
			
			commutation_output[ CG_BLDC_Drive.Mode ]( CG_PhaseAdv.pa_Commutation );
	
		}  
		
				
		
		CG_PhaseAdv.phase_changed = NO;
		CG_PhaseAdv.pa_Commutation = CG_BLDC_CTRL.Commutation;

		angle = ( CG_Speed.phase_length / PHASE_ADV_MAX ) * ( -1 * CG_PhaseAdv.phase_adcance );
		il_timerStart_2( angle );
	}
#endif
	
}

/*===========================================================================================
    Function Name    : cpu_timer2_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : phase advance IRQ event
//==========================================================================================*/
__interrupt void cpu_timer2_isr (void)
{
#if(0)
	CG_PhaseAdv.phase_changed = YES;

	if( CG_BLDC_CTRL.Motor_State == MOTOR_STATE_RUNNING || CG_BLDC_CTRL.Motor_State == MOTOR_STATE_MOVE ){
		commutation_output[ CG_BLDC_Drive.Mode ]( CG_PhaseAdv.pa_Commutation );
	}
#endif

	PA_TIMER_DISABLE;       							// Counter disable
	PA_TIMER_IR_CLEAR;



}


/************************** <END OF FILE> *****************************************/

