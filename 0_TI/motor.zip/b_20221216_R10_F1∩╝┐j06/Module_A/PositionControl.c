/*===========================================================================================

    File Name       : PositionControl.c

    Version         : V0200

    Built Date      : 2018/07/19

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */
//#include "PositionControl.h"
#include "IncludeFiles.h"

/*===========================================================================================
    Function Name    : setupInitial_PositionControl
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_PositionControl ( Struct_PositionControl* positionctrl )
{
	positionctrl->Meat_Target_Flag = YES;
	positionctrl->Run2Move_Flag = NO;

	// Target Pos
	positionctrl->MaxPos = 1;
	positionctrl->Target_Index = 0;
	positionctrl->Target_Pos = 0;
	positionctrl->Current_Target_Index = 0;
	positionctrl->Current_Target_Pos = 0;
	positionctrl->Pos_error = 0;

	// Path speed
	positionctrl->Path_Spd_Const = POSITION_CTRL_SPEED_CONST;
	positionctrl->Path_Spd_Limit = 0;
	positionctrl->Path_Spd = 0;
	positionctrl->Path_Acc_Time = 0;
	positionctrl->Path_Dec_Time = 0;

	positionctrl->PathAcc_Rest = 0;
	positionctrl->PathDec_Rest = 0;

	positionctrl->Pulse_Stamp_1 = 0;
	positionctrl->Pulse_Stamp_2 = 0;
	positionctrl->Pulse_Delta = 0;

	positionctrl->Inst_Speed_1 = 0;
	positionctrl->Inst_Speed_2 = 0;

	positionctrl->Inst_Acc = 0;
	positionctrl->Inst_Speed_Acc_Const = 0;


	setupInitial_SpeedControl ( ( Struct_SpeedControl* ) &positionctrl->SpdCtrl );
	setupInitial_DriverMotorInfor ( ( Struct_DriverMotorInfor* ) &positionctrl->Drive_Infor );

}

/*===========================================================================================
    Function Name    : resetReg_PositionControl
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void resetReg_PositionControl ( Struct_PositionControl* positionctrl )
{
	positionctrl->Meat_Target_Flag = YES;
	positionctrl->Run2Move_Flag = NO;

	// Path speed
	positionctrl->Path_Spd = 0;
	positionctrl->Path_Buffer = 0;
	positionctrl->PathAcc_Rest = 0;
	positionctrl->PathDec_Rest = 0;
	positionctrl->Pos_error = 0;

	positionctrl->Pulse_Stamp_2 = positionctrl->Drive_Infor.Pos_Now;
	positionctrl->Inst_Speed_2 = 0;
	
    positionctrl->Drive_Infor.Pos_Old = positionctrl->Drive_Infor.Pos_Now;

	resetReg_SpeedControl ( ( Struct_SpeedControl* ) &positionctrl->SpdCtrl );

}

/*===========================================================================================
    Function Name    : positionCtrl_SetTargetPos
    Input            :  1. positionctrl
    					2. signal_position
    					3. cw_limit
    					4. ccw_limit
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void positionCtrl_SetTargetPos ( Struct_PositionControl* positionctrl, int32_t signal_position, int32_t cw_limit, int32_t ccw_limit )
{
	if( cw_limit == HIGH && ccw_limit == HIGH ){
		positionctrl->Target_Pos = positionctrl->Drive_Infor.Pos_Now;
	}else if( cw_limit == HIGH && ccw_limit == LOW ){
		if( signal_position > positionctrl->Drive_Infor.Pos_Now ){
			positionctrl->Target_Pos = positionctrl->Drive_Infor.Pos_Now;
		}else{
			positionctrl->Target_Pos = signal_position;
		}
	}else if( cw_limit == LOW && ccw_limit == HIGH ){
		if( signal_position < positionctrl->Drive_Infor.Pos_Now ){
			positionctrl->Target_Pos = positionctrl->Drive_Infor.Pos_Now;
		}else{
			positionctrl->Target_Pos = signal_position;
		}
	}else{
		positionctrl->Target_Pos = signal_position;
	}

}


/************************** <END OF FILE> *****************************************/
