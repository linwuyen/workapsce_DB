/*===========================================================================================
    File Name       : C2000_PhaseAdv.h
    Built Date      : 2015-03-12
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for BLDC motor phase advance.			
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef PHASE_ADV_H
#define PHASE_ADV_H


#define PA_TIMER_DISABLE	( CpuTimer2Regs.TCR.bit.TSS = 1 )
#define PA_TIMER_IR_CLEAR   ( CpuTimer2Regs.TCR.bit.TIF = 1 )


#define PHASE_ADV_MAX   		128

#define PA_OPEN_CNT				24

// Phase advance commutation type
enum{
    PA_COMMUTATION_TYPE_ACC         = 0,
	PA_COMMUTATION_TYPE_DEC         = 1,
	PA_COMMUTATION_TYPE_NUM         = 2
};

typedef struct{

	int32_t  phase_adcance;
	int32_t  pre_advance;
	int32_t  adj_advance;
	int32_t  advance_tick;

	uint8_t	 phase_changed;
	 int8_t	 pa_Commutation;
	 int8_t	 pa_Commutation_Type;

	int8_t	 Enabled;
	
}Struct_PhaseAdv;


/*===========================================================================================
    Function Name    : variableInitial_PhaseAdv
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_PhaseAdv initial
//==========================================================================================*/
void variableInitial_PhaseAdv ( void );


/*===========================================================================================
    Function Name    : phaseAdvance
    Input            : 
					   1.enabled: 1 = use phase advance, 0 = not to use.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Phase advance.
//==========================================================================================*/
void phaseAdvance( int enabled );


/*===========================================================================================
    Function Name    : il_PhaseAdv_DisableTimer
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Phase advance disable timer.
//==========================================================================================*/
static __inline void il_PhaseAdv_DisableTimer( void )
{
	PA_TIMER_DISABLE;
	PA_TIMER_IR_CLEAR;
}

/*===========================================================================================
    Function Name    : cpu_timer2_isr
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : phase advance IRQ event
//==========================================================================================*/
__interrupt void cpu_timer2_isr (void);

#endif


/************************** <END OF FILE> *****************************************/

