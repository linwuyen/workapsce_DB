/*===========================================================================================
    File Name       : Opearation_Mode_TypeDef.h
    Built Date      : 2020-08-17
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Chaim.Chen@trumman.com.tw
    Description     :
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef OPEARATION_MODE_TYPEDEF_H
#define OPEARATION_MODE_TYPEDEF_H

#define EVR_BUFFER_SIZE           128//16
#define EVR_BUFFER_SIZE_BIT       7//4

/*===========================================================================================
    OPMode global variable data structure
//==========================================================================================*/
typedef struct{

    // ==
    int32_t     *Digit_Speed;
    int32_t     *Digit_Acc_Time;
    int32_t     *Digit_Dec_Time;
    int32_t     *Digit_Acc_Buffer_Time;
    int32_t     *Digit_Dec_Buffer_Time;
    int32_t     *Digit_Tq;
    int32_t     *Digit_Duty;

    uint8_t     Mode_Num1;                          // Analog setting mode
    uint8_t     Mode_Num2;                          // Analog setting mode
    uint8_t     Digit_Num;                          // Digit num decided by M0 M1 M2
    uint8_t     Stop_Cmd_Src;
    uint32_t    Image_VR_DIO;

    uint8_t     M0_State;
    uint8_t     M1_State;
    //uint8_t       M2_State;
    //

    int32_t     Target_RPM_Abs;
    int32_t     Target_Duty_Abs;
    int32_t     Torque_Limit;

    int32_t     Acc_Time;   // unit = 1ms
    int32_t     Dec_Time;   // unit = 1ms

    int32_t     Acc_Buffer_Time;    // unit = 1ms
    int32_t     Dec_Buffer_Time;    // unit = 1ms

    //
    int32_t     Digit_RPM_Abs;
    int32_t     *EVR;
    int32_t     *PFM;
    int32_t     *PWM;

    int32_t     *PW;
    int32_t     PW_Throttle;

    //

    uint16_t    EVR_Buff[ EVR_BUFFER_SIZE ];
    int32_t     EVR_Sum;
    int32_t     EVR_Avg;
    int32_t     EVR_Pointer;
    int32_t     EVR_WeightFactor;
    int32_t     EVR_Factor;
}Struct_Basic_OPMode;




#endif


/************************** <END OF FILE> *****************************************/


