/*===========================================================================================
    File Name       : Protect_Setting.c
    Built Date      : 2012-12-07
	Version         : V1.01a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file contains the settings of protection of driver and the alarm routine.
    =========================================================================================
    History         : 2012-12-07 Perlimary version.  ( by Chaim )
					  2013-03-19 (R10)
                        - Alarm history added.
                        - Fault routine determine added.
                      2014-08-06 V1.01a revision
					  2014-09-04 Motor_state set to fault should be quick.
					  2014-12-09
						- Add HWEEP_Setting module for Hardware limit variable from HWEEP.
						- Power limit values macro (currently map to HWEEP):
							- OVER_POWER_LIMIT
							- OVER_POWER_BOOST_TIME
							- OVER_POWER_REST_TIME
					  2014-12-23
						- OVER_CURRENT_LIMIT from SHUNT_I_FWP (CG_HWEEP.HW_Info[56])
						- OVER_CURRENT_BOOST_TIME from CG_HWEEP.HW_Info[57]  // msec
						- OVER_CURRENT_REST_TIME from CG_HWEEP.HW_Info[58]   // msec
						- OVER_LOAD_LIMIT from SHUNT_I_HWP (CG_HWEEP.HW_Info[63])
						- OVER_LOAD_BOOST_TIME, OVER_LOAD_REST_TIME from FW parameter setup.
						- Alarm History16 as paramter limit error HWEEP index. If index == total number: Normal.
                        - 3 functions added for the paramter check:
                            protect_ParameterError_Max()
                            protect_ParameterError_Min()
                            protect_ParameterError_check() 
                        - Function protect_ParameterError() modified to work as intended.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_Pretect 	CG_Protect;

/************************** EXTERNAL VARIABLES ********************************/
extern volatile Struct_MD                   CG_MD;
extern volatile Struct_ADC                 	CG_ADC;
extern volatile Struct_IO					CG_IO;
extern volatile Struct_IO_FUNC              CG_IO_Func_M0;
//extern volatile Struct_IO_FUNC              CG_IO_Func_M1;
extern volatile Struct_Parameter			CG_Parameter;
//extern volatile Struct_BLDC_CTRL 			CG_BLDC_CTRL;
//extern volatile Struct_BLDC_Drive 			CG_BLDC_Drive;
//extern volatile Struct_Speed 				CG_Speed;
extern volatile Struct_Encoder 				CG_Encoder;
extern volatile Struct_Move 				CG_Move;
extern volatile Struct_HWEEP				CG_HWEEP;	/* HWEEP for hardware limit */
extern volatile Struct_ComProtocol_01 		CG_ComProtocol_01;
extern volatile Struct_OPMode 				CG_OPMode;
//extern volatile Struct_IO_Expander                  CG_IO_Expander;
extern volatile Struct_GPIO                 CG_GPIO;

extern void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void );


/*===========================================================================================
    Function Name    : variableInitial_DriverProtect
    Input            : protect
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable initial
//==========================================================================================*/
void variableInitial_DriverProtect ( Struct_Driver_Pretect* protect )
{

    protect->Fault_BITF = 0;
    protect->first_fault = 0;

    protect->ErrorCode_LimitTime = 0;

    protect->HWCR_State = 0;

    //protect->IPM_Fault_Lock_Flag = NO;
    //protect->IPM_time_fault = 0;
    //protect->IPM_time_recover = 0;
    protect->HWCR_Lock_Flag = NO;
    protect->HWCR_time_fault = 0;
    protect->HWCR_time_recover = 0;

    protect->FWCR_flag = NO;
    protect->FWCR_Lock_flag = NO;
    protect->FWCR_time_fault = 0;
    protect->FWCR_time_recover = 0;

    protect->OverLoad_flag = NO;
    protect->OverLoad_Lock_flag = NO;
    protect->OverLoad_time_fault = 0;
    protect->OverLoad_time_recover = 0;

    protect->OverPower_flag = NO;
    protect->OverPower_Lock_flag = NO;
    protect->OverPower_time_fault = 0;
    protect->OverPower_time_recover = 0;

    protect->auto_reset_timer = 0;
    protect->first_fault_user = 0;

    protect->under_vbus_timer = 0;
    protect->over_vbus_timer = 0;
    protect->hall_error_timer = 0;

    protect->MosOT_BITF = 0;
    protect->MosOT_time_fault = 0;
    variableInitial_NTC_Temperature ( (Struct_NTC_Temperature *)&protect->MosNTC_1 );
    variableInitial_NTC_Temperature ( (Struct_NTC_Temperature *)&protect->MosNTC_2 );
    variableInitial_NTC_Temperature ( (Struct_NTC_Temperature *)&protect->MosNTC_3 );

    protect->MotorOT_time_fault = 0;
    protect->RGNOT_time_fault = 0;
    protect->RGN_Error_BITF = 0;
    protect->RGN_On_Cnt = 0;
    protect->HisSaved_Flag = NO;
    protect->TimeOut_Behavior = UART_TIMEOUT_BEHAVIOR_ONLY_ALARM;

    protect->StartFail_Cnt = 0;

    protect->Encoder_Error_BITF = 0;
    protect->Encoder_Overflow_Mode = ENCODER_OVERFLOW_DISABLE;
    protect->Encoder_Error_Sensitivity = 0;
    protect->Encoder_Error_Cnt = 0;

    protect->ComAlarm_Req_Flag = NO;

    protect->ToReset = NO;
    protect->Dependent_Error_Cnt = 0;

    protect->Fault_Stop_Mask_BITF         = _BIT(FAULT_STATE_HALL_FAULT) | _BIT(FAULT_STATE_MOTOR_COIL) |
                                              _BIT(FAULT_STATE_RESTART_FAULT) | _BIT(FAULT_STATE_BUSV_UNDER) |
                                              _BIT(FAULT_STATE_OT_MOS) | _BIT(FAULT_STATE_OT_MOTOR) |
                                              _BIT(FAULT_STATE_OT_RGN) | _BIT(FAULT_STATE_LOAD_OVER) |
                                              _BIT(FAULT_STATE_COMM_ERROR) | _BIT(FAULT_STATE_PHASE_FAULT) |
                                              _BIT(FAULT_STATE_BUSV_OVER) | _BIT(FAULT_STATE_IPM_FAULT) |
                                              _BIT(FAULT_STATE_BUSV_LOW) | _BIT(FAULT_STATE_PARAMETER_ERROR) |
                                              _BIT(FAULT_STATE_EXT_ERROR) | _BIT(FAULT_STATE_PWR_ON_RUN) |
                                              _BIT(FAULT_STATE_EEP_ERROR) | _BIT( FAULT_STATE_SPEED_OVER ) |
                                              _BIT(FAULT_STATE_ENCODER_FAULT) | _BIT(FAULT_STATE_PWR_ERROR);
}


/*===========================================================================================
    Function Name    : variableInitial_Protect
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Protect initial
//==========================================================================================*/
void variableInitial_Protect ( void )
{	
	int8_t i = 0;

	for( i = 0; i < HIST_ARRAY_SIZE; i++ ){
		CG_Protect.Warning_His_RAM[i] = 0;
	}
	
	variableInitial_DriverProtect ( (Struct_Driver_Pretect*)&CG_Protect.Motor_0 );
	//variableInitial_DriverProtect ( (Struct_Driver_Pretect*)&CG_Protect.Motor_1 );

	CG_Protect.Motor_0.History_Index = HISTORY_INDEX_M0;
	//CG_Protect.Motor_1.History_Index = HISTORY_INDEX_M1;

	CG_Protect.OverBusV_Clamping = ADC_MAX_VALUE;
	CG_Protect.UnderBusV_Clamping = 0;

	CG_Protect.PA_Limit_Check_Cnt = 0;

}

/*===========================================================================================
    Function Name    : protect_fault_stop_check_routine
    Input            : 1. protect
                       2. bldc_ctrl
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the fault state to determine to stop the motor and free the output.
					   Polling check in main loop.
					   CG_Protect.Fault_Stop_Mask_BITF is the mask to corresponding fault the cus stop.
//==========================================================================================*/
void protect_fault_stop_check_routine ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
    Struct_IO_FUNC *io_func = bldc_ctrl->IO_Func_Ptr;

	if( ( protect->first_fault   != FAULT_STATE_NO_FAULT) &&
		( bldc_ctrl->Motor_State != MOTOR_STATE_WAIT ) &&
		( bldc_ctrl->Motor_State != MOTOR_STATE_STO ) &&
		( (protect->Fault_Stop_Mask_BITF & (1UL << protect->first_fault)) != 0)
	){
	    bldc_ctrl->Motor_State          	= MOTOR_STATE_FAULT;

	    DINT;
	    if( bldc_ctrl->Drive_Ptr->FOC_Start_Flag == YES ){
            bldc_ctrl->Drive_Ptr->SineWaveToStep();
        }
	    if( bldc_ctrl->SPK_Ptr->Tq_Restraint_flag ){
	        bldc_ctrl->SPK_Ptr->Stop();
	    }

        bldc_ctrl->Drive_Ptr->Commutation_Out( 'C' );
        EINT;
		
        io_func->Output_State[ OUTPUT_ALM_OUT ] = io_func->ActState_of_Func[ OUTPUT_ALM_OUT ];

		OutputYn_action[ io_func->Output_State[ OUTPUT_ALM_OUT ] ]
					   [ io_func->OutputPin_of_Func[ OUTPUT_ALM_OUT ] ]();

		
		protect->first_fault_user = protect_UserEC_Convert( protect->first_fault );
		protect_Fault_History_Handler(  protect );

	}
#endif
	
}

/*===========================================================================================
    Function Name    : protect_Fault_History_Handler
    Input            : protect
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Save Fault Error Code into EEP.
//==========================================================================================*/
void protect_Fault_History_Handler ( Struct_Driver_Pretect* protect )
{
	int i;
	int Is_Save_allowed = NO;
	
	// UVP check to avoid Power Off as UVP
	if ( protect->first_fault == FAULT_STATE_BUSV_UNDER ) {

		if ( protect->UVP_Save_Flag == YES ) {
			Is_Save_allowed = YES;
		}
	
	}  else {
		Is_Save_allowed = YES;
	}
	
    if ( ( protect->HisSaved_Flag == NO) && (Is_Save_allowed == YES) ) {
		for ( i = protect->History_Index + HIST_NUM - 1 ; i > protect->History_Index; i--) {
			CG_Protect.Alarm_His_EEP[i] = CG_Protect.Alarm_His_EEP[i-1];
		}
		
		for ( i = protect->History_Index + HISTORY_OFFSET - 2 ; i > protect->History_Index + HIST_NUM; i--) {
			CG_Protect.Alarm_His_EEP[i] = CG_Protect.Alarm_His_EEP[i-1];
		}

		CG_Protect.Alarm_His_EEP[ protect->History_Index ] = protect->first_fault_user;
		CG_Protect.Alarm_His_EEP[ protect->History_Index + HIST_NUM] = protect->first_fault;
		CG_Protect.Alarm_His_EEP[ protect->History_Index + HISTORY_INDEX_PA_ERROR ] = protect->OverLimit_Index;
		
		// Multiple EEP access time. ErrorCode_LimitTime must decrease in a time routine in main.c (100ms)
		if( protect->ErrorCode_LimitTime == 0 ){
		    protect->ErrorCode_LimitTime = 5;
			
			saveEEPParameter_Multiple( PA_ALM_HIS_ADDS_INDEX, protect->History_Index, HISTORY_OFFSET, (int32_t*)&CG_Protect.Alarm_His_EEP[ protect->History_Index ], PA_EEP_WR_AND_CHECK );
		}
		
		
		protect->HisSaved_Flag = YES;
	}

}

/*===========================================================================================
    Function Name    : protectSetup_OVP
    Input            : 1.protect
                       2.OVP: Over voltage protect
					   3.OVPR: Over voltage protect recovery
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup over V bus pretect.
//==========================================================================================*/
void protectSetup_OVP ( Struct_Driver_Pretect* protect, int32_t OVP, int32_t OVPR )
{
	protect->over_vbus_value			= OVP;
	protect->over_vbus_recover_value	= OVPR;
}

/*===========================================================================================
    Function Name    : protectSetup_LVP
    Input            : 1.protect
                       2.LVP: lower voltage protect
					   3.LVPR: lower voltage protect recovery
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup lower V bus pretect.
//==========================================================================================*/
void protectSetup_LVP ( Struct_Driver_Pretect* protect, int32_t LVP, int32_t LVPR )
{
    protect->low_vbus_value			= LVP;
    protect->low_vbus_recover_value	= LVPR;
}

/*===========================================================================================
    Function Name    : protectSetup_UVP
    Input            : 1.protect
                       2.UVP: Under voltage protect
					   3.UVPR: Under voltage protect recovery
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup under V bus pretect.
//==========================================================================================*/
void protectSetup_UVP ( Struct_Driver_Pretect* protect, int32_t UVP, int32_t UVPR )
{
    protect->under_vbus_value 		= UVP;
    protect->under_vbus_recover_value = UVPR;
}


/*===========================================================================================
    Function Name    : protect_BusV_Under
    Input            : 1.protect
                       2.busV: V bus value
					   3.fault_value: fault value.
					   4.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Under V bus pretect.
//==========================================================================================*/
void protect_BusV_Under ( Struct_Driver_Pretect* protect, const uint32_t busV, const uint32_t fault_value, const uint32_t recover_value  )
{
	if( busV <= fault_value ){

		if( ++protect->under_vbus_timer > CNT_LIMT ){
		    protect->under_vbus_timer = CNT_LIMT;
		}
		
		if( protect->under_vbus_behavior == ERROR_BEHAVIOR_ALARM ||
		        protect->under_vbus_timer >= protect->under_vbus_behavior ){
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
			    protect->first_fault = FAULT_STATE_BUSV_UNDER;
			}

			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_BUSV_UNDER );

			CG_MD.Vcc12V_Ctrl_State = LOW;

		}
		
	}else if( busV >= recover_value ){

		protect->under_vbus_timer = 0;
		protect->Fault_BITF &= ~( 1UL << FAULT_STATE_BUSV_UNDER );

		CG_MD.Vcc12V_Ctrl_State = HIGH;

	}


}

/*===========================================================================================
    Function Name    : protect_BusV_Low
    Input            : 1.protect
                       2.busV: V bus value
					   3.fault_value: fault value.
					   4.recover_value: recover value.
    Return           : NULL.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Low V bus pretect.
//==========================================================================================*/
void protect_BusV_Low ( Struct_Driver_Pretect* protect, const uint32_t busV, const uint32_t fault_value, const uint32_t recover_value  )
{

	if( busV <= fault_value ){
		
		if ( protect->BUSV_Low_cnt >= BUSV_LOW_TIME) {
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_BUSV_LOW;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_BUSV_LOW );
			protect->UVP_Save_Flag = YES;
		} else {
			protect->BUSV_Low_cnt++;
		}
		protect->BUSV_LowRec_cnt = 0;
		
	}else if( busV >= recover_value ){
		
        if (protect->BUSV_LowRec_cnt >= BUSV_LOW_REC_TIME) {
			protect->BUSV_Low_cnt = 0;
			protect->UVP_Save_Flag = NO;
			protect->Fault_BITF &= ~( 1UL << FAULT_STATE_BUSV_LOW );
		
		} else {
			protect->BUSV_LowRec_cnt++;
		}
	}

}

/*===========================================================================================
    Function Name    : protect_BusV_Over
    Input            : 1.protect
                       2.busV: V bus value
					   3.fault_value: fault value.
					   4.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : High V bus pretect.
//==========================================================================================*/
void protect_BusV_Over ( Struct_Driver_Pretect* protect, const uint32_t busV, const uint32_t fault_value, const uint32_t recover_value )
{

	if( busV >= fault_value ){

		if( ++protect->over_vbus_timer > CNT_LIMT ){
			protect->over_vbus_timer = CNT_LIMT;
		}

		if( protect->over_vbus_behavior == ERROR_BEHAVIOR_ALARM ||
			protect->over_vbus_timer >= protect->over_vbus_behavior ){

			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_BUSV_OVER;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_BUSV_OVER );
		}

	}else if( busV <= recover_value ){
		protect->over_vbus_timer = 0;
		protect->Fault_BITF &= ~( 1UL << FAULT_STATE_BUSV_OVER );
	}
}

/*===========================================================================================
    Function Name    : protect_IPM_fault
    Input            : 1.protect
                       2.IPM_input: IPM fault input
					   3.fault_state: fault state.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : IPM fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_IPM_fault ( Struct_Driver_Pretect* protect, uint32_t IPM_input, uint8_t fault_state )
{
	/*
	if( IPM_input == fault_state ){

		if( protect->first_fault == FAULT_STATE_NO_FAULT ){
			protect->first_fault = FAULT_STATE_IPM_FAULT;
		}
		protect->Fault_BITF |=  ( 1UL << FAULT_STATE_IPM_FAULT );
	
	}else {
		protect->Fault_BITF &= ~( 1UL << FAULT_STATE_IPM_FAULT );
	}
	*/
}

/*===========================================================================================
    Function Name    : detect_HWOCP
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void detect_HWOCP( void )
{
#if(1)
    /*
    if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
        CG_Protect.Motor_0.HWCR_State = HWCR_STATE_M0;
        if( CG_Protect.Motor_0.HWCR_State == HIGH ){
            EALLOW;  // This is needed to write to EALLOW protected register
            HWCR_CLEAR_M0;
            EDIS;
            CG_Protect.Motor_0.HWCR_time_recover = 0;
            if( CG_MD.Relay_On_Cnt >= RELAY_ON_DELAY_TIME ){
                CG_Protect.Motor_0.HWCR_Lock_Flag = YES;
            }
        }

        CG_Protect.Motor_1.HWCR_State = HWCR_STATE_M1;
        if( CG_Protect.Motor_1.HWCR_State == HIGH ){
            EALLOW;  // This is needed to write to EALLOW protected register
            HWCR_CLEAR_M1;
            EDIS;
            CG_Protect.Motor_1.HWCR_time_recover = 0;
            if( CG_MD.Relay_On_Cnt >= RELAY_ON_DELAY_TIME ){
                CG_Protect.Motor_1.HWCR_Lock_Flag = YES;
            }
        }
    }else{

        CG_Protect.Motor_0.HWCR_State = HWCR_STATE_M0 | HWCR_STATE_M1;
        if( CG_Protect.Motor_0.HWCR_State == HIGH ){
            EALLOW;  // This is needed to write to EALLOW protected register
            HWCR_CLEAR_M0;
            HWCR_CLEAR_M1;
            EDIS;
            CG_Protect.Motor_0.HWCR_time_recover = 0;
            if( CG_MD.Relay_On_Cnt >= RELAY_ON_DELAY_TIME ){
                CG_Protect.Motor_0.HWCR_Lock_Flag = YES;
            }
        }

    }*/
    CG_Protect.Motor_0.HWCR_State = HWCR_STATE_M0;
    if( CG_Protect.Motor_0.HWCR_State == HIGH ){
        EALLOW;  // This is needed to write to EALLOW protected register
        HWCR_CLEAR_M0;
        EDIS;
        CG_Protect.Motor_0.HWCR_time_recover = 0;
        if( CG_MD.Relay_On_Cnt >= RELAY_ON_DELAY_TIME ){
            CG_Protect.Motor_0.HWCR_Lock_Flag = YES;
        }
    }

#endif

}

/*===========================================================================================
    Function Name    : protect_HW_CurrentRestraint
    Input            : 1.protect
                       2.bldc_ctrl
                       3.IPM_input: IPM fault input
					   4.fault_state: fault state.
					   5.limit_time: limit time
					   6.recover_time: recover time.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : HW CurrentRestraint pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_HW_CurrentRestraint ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t IPM_input, uint8_t fault_state, uint32_t limit_time, uint32_t recover_time  )
{
#if(1)
	if( IPM_input == fault_state ){

		if( ++protect->HWCR_time_fault > 1000000 ){
			protect->HWCR_time_fault = 1000000;
		}

		protect->HWCR_time_recover = 0;
		bldc_ctrl->Restart_Cnt = 0;

		if( protect->HWCR_time_fault >= 1000 &&
		    bldc_ctrl->Stall_Timer >= 1000  ){

			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_IPM_FAULT;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_IPM_FAULT );

		}


	}else {

		if( ++protect->HWCR_time_recover > 1000000 ){
			protect->HWCR_time_recover = 1000000;
		}

		if( protect->HWCR_time_recover > 20 ){
			if( --protect->HWCR_time_fault < 0 ){
				protect->HWCR_time_fault = 0;
			}

			protect->HWCR_Lock_Flag = NO;

		}else{

			if( ++protect->HWCR_time_fault > 1000000 ){
				protect->HWCR_time_fault = 1000000;
			}

		}

		if( protect->HWCR_time_recover >= recover_time ){

			protect->Fault_BITF &= ~( 1UL << FAULT_STATE_IPM_FAULT );
			protect->HWCR_time_fault = 0;
		}

	}
#endif
}

/*===========================================================================================
    Function Name    : protect_FW_CurrentRestraint
    Input            : 1.protect
                       2.bldc_ctrl
                       3.OverLoad_input: OverLoad fault input
					   4.fault_state: fault state.
					   5.limit_time: limit time
					   6.recover_time: recover time.
					   7.fault_en : fault_en = 1 means when protect->FWCR_flag == YES, motor state will be seted to fault.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Over Load fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_FW_CurrentRestraint ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t OverLoad_input, uint32_t fault_state, uint32_t limit_time, uint32_t recover_time, int32_t fault_en )
{
#if(1)
	
	if( OverLoad_input > fault_state ){
		
		if( ++protect->FWCR_time_fault > 1000000 ){
			protect->FWCR_time_fault = 1000000;
		}
				
		protect->FWCR_time_recover = 0;
		protect->FWCR_Lock_flag = YES;
		
		if( protect->FWCR_time_fault >= limit_time ){
		
			protect->FWCR_flag = YES;
			bldc_ctrl->Restart_Cnt = 0;

			if( fault_en == YES ){
				if( protect->first_fault == FAULT_STATE_NO_FAULT ){
					protect->first_fault = FAULT_STATE_LOAD_OVER;
				}
				protect->Fault_BITF |=  ( 1UL << FAULT_STATE_LOAD_OVER );
			}
			
		}					
		
	}else {

		
		if( ++protect->FWCR_time_recover > 1000000 ){
			protect->FWCR_time_recover = 1000000;
		}
		
		if( protect->FWCR_time_recover > 20 ){
					
			if( --protect->FWCR_time_fault < 0 ){
				protect->FWCR_time_fault = 0;
			}
			protect->FWCR_Lock_flag = NO;
			
		}else{
			
			if( ++protect->FWCR_time_fault > 1000000 ){
				protect->FWCR_time_fault = 1000000;
			}
			
		}
		
		if( protect->FWCR_time_recover >= recover_time ){
					
			protect->FWCR_flag = NO;
			protect->FWCR_time_fault = 0;
			protect->Fault_BITF &= ~( 1UL << FAULT_STATE_LOAD_OVER );
		}
		
	}
#endif
}

/*===========================================================================================
    Function Name    : protect_OverLoad_fault
    Input            : 1.protect
                       2.bldc_ctrl
                       3.OverLoad_input: OverLoad fault input
					   4.fault_state: fault state.
					   5.limit_time: limit time
					   6.recover_time: recover time.
					   7.stall_time: when motor stuck, driver will be : 0 = still run state, 1000 = 1000ms later fall into alarm.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Over Load fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_OverLoad_fault ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t OverLoad_input, uint32_t fault_state, uint32_t limit_time, uint32_t recover_time, uint32_t stall_time )
{
	
#if(1)
	if( OverLoad_input > fault_state ){
		
		if( ++protect->OverLoad_time_fault > 1000000 ){
			protect->OverLoad_time_fault = 1000000;
		}
				
		protect->OverLoad_time_recover = 0;
	
		protect->OverLoad_Lock_flag = YES;
		if( protect->OverLoad_time_fault >= limit_time ){
		
			protect->OverLoad_flag = YES;
			bldc_ctrl->Restart_Cnt = 0;

		}
		
		/*
		if( protect->OverLoad_flag == YES && //protect->OverLoad_time_fault >= stall_time &&
		    bldc_ctrl->Stall_Timer >= stall_time &&
		    bldc_ctrl->Current_RPM_Abs == 0 &&
			//CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_RUN ] ][ CMD_RUN ] == HIGH &&
			stall_time != 0 ){*/

#define OVERLOAD_CONDITION_1   (    ( ( OVER_CURRENT_FAULT >> 1 ) & 0x01 ) == 0 && \
                                    bldc_ctrl->Stall_Timer >= stall_time && \
                                    bldc_ctrl->Current_RPM_Abs == 0 &&    \
                                    stall_time != 0 )

#define OVERLOAD_CONDITION_2    (   ( ( OVER_CURRENT_FAULT >> 1 ) & 0x01 ) && \
                                    protect->OverLoad_time_fault >= limit_time + stall_time )

        if( protect->OverLoad_flag == YES &&
            ( OVERLOAD_CONDITION_1 || OVERLOAD_CONDITION_2 ) ){
		
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_LOAD_OVER;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_LOAD_OVER );
			
		}						
		
	}else {
	
		
		if( ++protect->OverLoad_time_recover > 1000000 ){
			protect->OverLoad_time_recover = 1000000;
		}
		
		if( protect->OverLoad_time_recover > 20 ){
					
			if( --protect->OverLoad_time_fault < 0 ){
				protect->OverLoad_time_fault = 0;
			}
			protect->OverLoad_Lock_flag = NO;
			
		}else{
			
			if( ++protect->OverLoad_time_fault > 1000000 ){
				protect->OverLoad_time_fault = 1000000;
			}
			
		}
		
		if( protect->OverLoad_time_recover >= recover_time ){
					
			protect->OverLoad_flag = NO;

			protect->OverLoad_time_fault = 0;
			
			protect->Fault_BITF &= ~( 1UL << FAULT_STATE_LOAD_OVER );
		}
		
	}
#endif

}

/*===========================================================================================
    Function Name    :protect_OverPower_fault
    Input            : 1.protect
                       2.bldc_ctrl
                       3.OverPower_input: OverPower fault input
					   4.fault_state: fault state.
					   5.limit_time: limit time
					   6.recover_time: recover time.
					   7.fault_en : fault_en = 1 means when protect->FWCR_flag == YES, motor state will be seted to fault.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Over Power fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_OverPower_fault ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t OverPower_input, uint32_t fault_state, uint32_t limit_time, uint32_t recover_time, uint32_t fault_en )
{
	
#if(1)
	if( OverPower_input > fault_state ){
		
		if( ++protect->OverPower_time_fault > 1000000 ){
			protect->OverPower_time_fault = 1000000;
		}
				
		protect->OverPower_time_recover = 0;
	
		protect->OverPower_Lock_flag = YES;
		
		if( protect->OverPower_time_fault >= limit_time ){
		
			protect->OverPower_flag = YES;
			bldc_ctrl->Restart_Cnt = 0;
			
			if( fault_en == YES ){
				if( protect->first_fault == FAULT_STATE_NO_FAULT ){
					protect->first_fault = FAULT_STATE_LOAD_OVER;
				}
				protect->Fault_BITF |=  ( 1UL << FAULT_STATE_LOAD_OVER );
			}
			
		}							
		
	}else {
	
		
		if( ++protect->OverPower_time_recover > 1000000 ){
			protect->OverPower_time_recover = 1000000;
		}
		
		#if(1)
		if( protect->OverPower_time_recover > 20 ){
					
			if( --protect->OverPower_time_fault < 0 ){
				protect->OverPower_time_fault = 0;
			}
			protect->OverPower_Lock_flag = NO;
			
		}else{
			
			if( ++protect->OverPower_time_fault > 1000000 ){
				protect->OverPower_time_fault = 1000000;
			}
			
		}
		#endif
		
		if( protect->OverPower_time_recover >= recover_time ){
					
			protect->OverPower_flag = NO;

			protect->OverPower_time_fault = 0;
			
			protect->Fault_BITF &= ~( 1UL << FAULT_STATE_LOAD_OVER );
		}
		
	}
#endif

}

/*===========================================================================================
    Function Name    : protect_Hall_state
    Input            : 1.protect
                       2.hall_state: hall state
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Hall sensor state pretect.
					   Without noise filter.
//==========================================================================================*/
void protect_Hall_state ( Struct_Driver_Pretect* protect, const uint32_t hall_state )
{

	// One hall phase lock will be override by 000,111 due to not sense in hall isr.
	// so use hall fault only: Power, Hall noise ...

	if( hall_state == HALL_FAULT_STATE_0 || hall_state == HALL_FAULT_STATE_1 ){

		if( ++protect->hall_error_timer > CNT_LIMT ){
			protect->hall_error_timer = CNT_LIMT;
		}

		if( protect->hall_error_behavior == ERROR_BEHAVIOR_ALARM ||
			protect->hall_error_timer >= protect->hall_error_behavior ){

			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_HALL_FAULT;
			}
			protect->Fault_BITF |= ( 1UL << FAULT_STATE_HALL_FAULT );

		}

	} else {
		protect->hall_error_timer = 0;
		protect->Fault_BITF &= ~( 1UL << FAULT_STATE_HALL_FAULT );
	}


}

/*===========================================================================================
    Function Name    : protect_Encoder
    Input            : 1.protect
                       2.bldc_ctrl
                       3.encoder
                       4.index: encoder index value
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 1. Encoder check, make sure encoder is installed
                       2. Index check, make sure that encoder's index is between -32768 ~ 32767
//==========================================================================================*/
void protect_Encoder ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, Struct_Basic_Encoder* encoder, const int32_t index )
{
#if( TEST_ENCODER_PROTECT_OPEN )

    int32_t delta_pos_integration_max;
    //int32_t error_bit;

    /*
    if( bldc_ctrl->MultiDrive_Src == SRC_MULTI_DRIVE_M0 ){
        error_bit = IO_EXP_M1_ER;
    }else{
        error_bit = IO_EXP_M2_ER;
    }*/

	// CG_Encoder.hall_checked == NO means encoder signal has not been detected
	// This fault can not be resetted, user needs to reopen driver power
	if( encoder->Hall_Checked == NO ){
		if( protect->first_fault == FAULT_STATE_NO_FAULT ){
			protect->first_fault = FAULT_STATE_ENCODER_FAULT;
		}
		protect->Fault_BITF |=  ( 1UL << FAULT_STATE_ENCODER_FAULT );

	}else{

	    delta_pos_integration_max = encoder->FullPos * 9 / 8;

        #define ENCODER_ERROR_CONDITION_1   ( ( index < -32768 || index > 32767 ) && bldc_ctrl->Control_Mode == CTRL_POSITION && \
                                                protect->Encoder_Overflow_Mode != ENCODER_OVERFLOW_DISABLE )
        #define ENCODER_ERROR_CONDITION_2   ( protect->Encoder_Error_Sensitivity != 0 && ( encoder->Delta_Pos_Integration > delta_pos_integration_max || encoder->Delta_Pos_Integration < -delta_pos_integration_max ) )

        #define ENCODER_ERROR_CONDITION_3   ( protect->Encoder_Error_Sensitivity != 0 && protect->Encoder_Error_Cnt >= protect->Encoder_Error_Sensitivity )
		//if( ENCODER_ERROR_CONDITION_1 || ENCODER_ERROR_CONDITION_2 ){	//

	    //if( ( ( CG_IO_Expander.Xn_State_BITF >> error_bit ) & 0x01 ) == 0 ){
	    if( ( ( CG_GPIO.OtherInput_State_BITF >> OTHER_INPUT_M_ER ) & 0x01 ) == 0 ){
	        if( protect->Encoder_Error_Cnt < 65536 ){
	            protect->Encoder_Error_Cnt++;
	        }
	    }else{
	        protect->Encoder_Error_Cnt = 0;
	    }

	    /*
	    if( ENCODER_ERROR_CONDITION_1 ||
	        ENCODER_ERROR_CONDITION_2 ||
	        ENCODER_ERROR_CONDITION_3 ){
		    encoder->Delta_Pos_Integration = 0;
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_ENCODER_FAULT;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_ENCODER_FAULT );
		}else{
			protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_ENCODER_FAULT );
		}*/

	    if( ENCODER_ERROR_CONDITION_1 ){
	        protect->Encoder_Error_BITF |= ( 1UL << ENCODER_ERROR_BIT_OVERFLOW );
	    }else{
	        protect->Encoder_Error_BITF &= ~( 1UL << ENCODER_ERROR_BIT_OVERFLOW );
	    }

	    if( ENCODER_ERROR_CONDITION_2 ){
	        encoder->Delta_Pos_Integration = 0;
            protect->Encoder_Error_BITF |= ( 1UL << ENCODER_ERROR_BIT_Z_LOSS );
        }

	    if( ENCODER_ERROR_CONDITION_3 ){
            protect->Encoder_Error_BITF |= ( 1UL << ENCODER_ERROR_BIT_XOR_ERR );
        }

	    if( protect->Encoder_Error_BITF != 0 ){
	        if( protect->first_fault == FAULT_STATE_NO_FAULT ){
                protect->first_fault = FAULT_STATE_ENCODER_FAULT;
            }
            protect->Fault_BITF |=  ( 1UL << FAULT_STATE_ENCODER_FAULT );
	    }else{
            protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_ENCODER_FAULT );
        }

	}

#endif

}

/*===========================================================================================
    Function Name    : protect_Restart_fault
    Input            : 1.protect
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 
//==========================================================================================*/
void protect_Restart_fault ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl )
{
#if(1)
	int duty_abs;

	duty_abs = bldc_ctrl->Current_Duty_Display;
	if( duty_abs < 0 ){
		duty_abs *= -1;
	}

	if( bldc_ctrl->Control_Mode != CTRL_OPENLOOP &&
	    bldc_ctrl->Drive_Ptr->EBrake_Flag == NO &&
		( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING || bldc_ctrl->Motor_State == MOTOR_STATE_MOVE || bldc_ctrl->Motor_State == MOTOR_STATE_LOCK ) &&
		duty_abs >= FULL_DUTY / 4 &&
		bldc_ctrl->ADC_Ptr->Shunt_I_Avg < bldc_ctrl->ADC_Ptr->FWOCP / 8 &&
		bldc_ctrl->Current_RPM_Abs < 60 ){

		if( ++protect->StartFail_Cnt > 1000 ){
			protect->StartFail_Cnt = 1000;
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_RESTART_FAULT;
			}
			protect->Fault_BITF |= ( 1UL << FAULT_STATE_RESTART_FAULT );
		}

	}else {

		if( protect->StartFail_Cnt > 0 ){
			protect->StartFail_Cnt--;
		}

		protect->Fault_BITF &= ~( 1UL << FAULT_STATE_RESTART_FAULT );
	}
#endif

}

/*===========================================================================================
    Function Name    : protect_OT_Mos
    Input            : 1.protect
                       2.value: input value
					   3.sensor_index: MosOT 1 2 3 4
					   4.mode: 0 = normal mode, big value => big real value
							   1 = reverse mode: big value => small real value
					   5.fault_value: fault value.
					   6.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Mos OT pretect.
//==========================================================================================*/
void protect_OT_Mos ( Struct_Driver_Pretect* protect, const uint32_t value, const uint8_t sensor_index, const uint8_t mode, const uint32_t fault_value, const uint32_t recover_value )
{

	if( ( value >= fault_value && mode == OT_MODE_NORM ) ||
		( value <= fault_value && mode == OT_MODE_REV  )   	){
			
		if( ++protect->MosOT_time_fault > 100000 ){
			protect->MosOT_time_fault = 100000;
		}
		
		if( protect->MosOT_time_fault >= OT_DEBOUNCE_CONST ){
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_OT_MOS;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_OT_MOS );

			protect->MosOT_BITF |=  ( 1UL << sensor_index );
		}
		
	}else if( ( value <= recover_value && mode == OT_MODE_NORM ) ||
			  ( value >= recover_value && mode == OT_MODE_REV  )    ){

		protect->MosOT_time_fault = 0;
		protect->MosOT_BITF &= ~( 1UL << sensor_index );
		
		if( protect->MosOT_BITF == 0 ){
			protect->Fault_BITF &= ~( 1UL << FAULT_STATE_OT_MOS );
		}

	}

}

/*===========================================================================================
    Function Name    : protect_OT_Motor
    Input            : 1.protect
                       2.value: input value
					   3.mode: 0 = normal mode, big value => big real value
							   1 = reverse mode: big value => small real value
					   4.fault_value: fault value.
					   5.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Mos OT pretect.
//==========================================================================================*/
void protect_OT_Motor ( Struct_Driver_Pretect* protect, const uint32_t value, const uint8_t mode, const uint32_t fault_value, const uint32_t recover_value )
{
    if( mode == OT_MODE_DISABLE ){
        protect->MotorOT_time_fault = 0;
        protect->Fault_BITF &= ~( 1UL << FAULT_STATE_OT_MOTOR );
    }else{
        if( ( value >= fault_value && mode == OT_MODE_NORM ) ||
            ( value <= fault_value && mode == OT_MODE_REV  )   	){

            if( ++protect->MotorOT_time_fault > 100000 ){
                protect->MotorOT_time_fault = 100000;
            }

            if( protect->MotorOT_time_fault >= OT_DEBOUNCE_CONST ){
                if( protect->first_fault == FAULT_STATE_NO_FAULT ){
                    protect->first_fault = FAULT_STATE_OT_MOTOR;
                }
                protect->Fault_BITF |=  ( 1UL << FAULT_STATE_OT_MOTOR );
            }

        }else if( ( value <= recover_value && mode == OT_MODE_NORM ) ||
                  ( value >= recover_value && mode == OT_MODE_REV  )    ){

            protect->MotorOT_time_fault = 0;
            protect->Fault_BITF &= ~( 1UL << FAULT_STATE_OT_MOTOR );
        }
    }
}

/*===========================================================================================
    Function Name    : protect_OT_RGN
    Input            : 1.protect
                       2.value: OT_RGN state
					   3.mode: Normal open or close.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : RGN OT pretect.
//==========================================================================================*/
void protect_OT_RGN ( Struct_Driver_Pretect* protect, const uint32_t state, const uint8_t mode )
{
    // Bit 0
	if( ( mode == OT_MODE_NORM && state == HIGH ) ||
		( mode == OT_MODE_REV  && state == LOW  )	){
			
		if( ++protect->RGNOT_time_fault > 100000 ){
			protect->RGNOT_time_fault = 100000;
		}

		if( protect->RGNOT_time_fault >= OT_DEBOUNCE_CONST ){
		    protect->RGN_Error_BITF |= ( 1UL << RGN_ERROR_BIT_OT );
		}
			
	}else{
		protect->RGNOT_time_fault = 0;
		protect->RGN_Error_BITF &= ~( 1UL << RGN_ERROR_BIT_OT );
	}

	// Bit 1
	if( protect->RGN_On_Allowed_Cnt != 0 ){
        if( CG_ADC.BusV > protect->over_vbus_recover_value ){
            if( protect->RGN_On_Cnt < 65535 ){
                protect->RGN_On_Cnt++;
            }
        }else{
            if( protect->RGN_On_Cnt > 0 ){
                protect->RGN_On_Cnt--;
            }
        }
        if( protect->RGN_On_Cnt >= protect->RGN_On_Allowed_Cnt ){
            protect->RGN_Error_BITF |= ( 1UL << RGN_ERROR_BIT_WRONG_POWER_IN );
        }
	}else{
	    protect->RGN_On_Cnt = 0;
	    protect->RGN_Error_BITF &= ~( 1UL << RGN_ERROR_BIT_WRONG_POWER_IN );
	}

	if( protect->RGN_Error_BITF != 0 ){
	    if( protect->first_fault == FAULT_STATE_NO_FAULT ){
            protect->first_fault = FAULT_STATE_OT_RGN;
        }
        protect->Fault_BITF |=  ( 1UL << FAULT_STATE_OT_RGN );
	}else{
	    protect->Fault_BITF &= ~( 1UL << FAULT_STATE_OT_RGN );
	}

}

/*===========================================================================================
    Function Name    : protect_EXT_ERROR
    Input            : 1.protect
                       2.value: EXT_ERROR IO state
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : RGN OT pretect.
//==========================================================================================*/
void protect_EXT_ERROR ( Struct_Driver_Pretect* protect, const uint32_t state )
{
    /*
    Struct_Driver_Pretect* another_protect;
    if( protect->History_Index == HISTORY_INDEX_M0 ){
        another_protect = (Struct_Driver_Pretect*)&CG_Protect.Motor_1;
    }else{
        another_protect = (Struct_Driver_Pretect*)&CG_Protect.Motor_0;
    }

    if( CG_Protect.Alarm_Mode == ALARM_MODE_DEPENDENT ){
        if( another_protect->first_fault_user != 0 ){
            if( protect->Dependent_Error_Cnt < 2 ){
                protect->Dependent_Error_Cnt++;
            }else{
                if( protect->first_fault == FAULT_STATE_NO_FAULT ){
                    protect->first_fault = FAULT_STATE_EXT_ERROR;
                }
                protect->auto_reset_timer = another_protect->auto_reset_timer;
            }
        }else{
            protect->Dependent_Error_Cnt = 0;
        }
    }*/

	if( state == HIGH ) {
		if( protect->first_fault == FAULT_STATE_NO_FAULT ){
			protect->first_fault = FAULT_STATE_EXT_ERROR;
		}
		protect->Fault_BITF |=  ( 1UL << FAULT_STATE_EXT_ERROR );
	}else{
		protect->Fault_BITF &= ~( 1UL << FAULT_STATE_EXT_ERROR );
	}
}

/*===========================================================================================
    Function Name    : protect_OverSpeed
    Input            : 1.protect
                       2.bldc_ctrl
                       3.speed: Current speed.
					   4.limit_speed: Restraint value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Over speed pretect.
//==========================================================================================*/
void protect_OverSpeed ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, const uint32_t speed, const uint32_t limit_speed )
{
#if(1)
	//if( speed > limit_speed ){
	if( speed > limit_speed && limit_speed != 0 ){
		if( ( bldc_ctrl->Hall_Ptr->INT_Times > 12 * bldc_ctrl->Hall_Ptr->Pole_Factor && bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL ) ||
		    bldc_ctrl->Drive_Ptr->Sensor_Type != SENSOR_TYPE_HALL ){

			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_SPEED_OVER;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_SPEED_OVER );
		}
			
	}else{
		protect->Fault_BITF &= ~( 1UL << FAULT_STATE_SPEED_OVER );
		
	}
#endif
}

/*===========================================================================================
    Function Name    : protect_ParameterError
    Input            : 1.protect
                       2.bldc_ctrl
                       3.*Com_BITF: com_protocol bitfield to check if parameter limit check req.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Check if the setting will make damage to driver.
					   Determine and set the fault flag only after each parameter change or Config from communication.
//==========================================================================================*/
void protect_ParameterError ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t *Com_BITF )
{
#if(1)
    uint8_t good_setting = YES;
	
	if ( (*Com_BITF & _BIT(COM_PA_LIMIT_CHECK_REQ_BIT)) != 0 ) {
		
		// Put Parameter check here
		good_setting = protect_ParameterError_check( protect, bldc_ctrl );
		
		
		if( good_setting == NO ){
			
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_PARAMETER_ERROR;
			}
				protect->Fault_BITF |=  ( 1UL << FAULT_STATE_PARAMETER_ERROR );
			
		}else{
			protect->Fault_BITF &= ~( 1UL << FAULT_STATE_PARAMETER_ERROR );
			
		}
		CG_Protect.PA_Limit_Check_Cnt++;
		if( CG_Protect.PA_Limit_Check_Cnt == DRIVER_NUM ){
		    CG_Protect.PA_Limit_Check_Cnt = 0;
		    *Com_BITF &= ~_BIT( COM_PA_LIMIT_CHECK_REQ_BIT );
		}
	}
#endif

}

/*===========================================================================================
    Function Name    : protect_Hall_Seguence
    Input            : 1.protect
                       2.bldc_ctrl
                       3.enabled: Enable this protection
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Hall sequence pretect.
//==========================================================================================*/
void protect_Hall_Seguence ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint8_t enabled )
{
#if(1)

	#define PROTECT_HALL_SEQUENCE_CNT	2000

	if( bldc_ctrl->ReverseEmergency_Cnt <= PROTECT_HALL_SEQUENCE_CNT ){
	    bldc_ctrl->ReverseEmergency_Cnt++;
	}

	if( ( enabled &&
	      bldc_ctrl->Control_Mode == CTRL_CLOSELOOP_PID &&
	      bldc_ctrl->Drive_Ptr->EBrake_Flag == NO &&
	      //bldc_ctrl->Hall_Ptr->INT_Times > 24 &&
	      bldc_ctrl->ReverseEmergency_Cnt >= PROTECT_HALL_SEQUENCE_CNT ) ){

		if( bldc_ctrl->Current_Duty - bldc_ctrl->Bemf_Duty > bldc_ctrl->Drive_Ptr->Period ||
		    bldc_ctrl->Current_Duty - bldc_ctrl->Bemf_Duty < -1 * bldc_ctrl->Drive_Ptr->Period	){

			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_PHASE_FAULT;
			}
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_PHASE_FAULT );
		}
	}
#endif

}

/*===========================================================================================
    Function Name    : protect_COM_Alarm
    Input            : 1.protect
                       2. *Com_BITF: COM_Protocol bit field.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : COM alarm fault check.
//==========================================================================================*/
void protect_COM_Alarm ( Struct_Driver_Pretect* protect, uint32_t *Com_BITF )
{
#if(1)
	//if ( (*Com_BITF & _BIT( COM_COM_ALM_REQ_BIT )) != 0  ) {			// If COM alarm
		//*Com_BITF			  &=  ~_BIT( COM_COM_ALM_REQ_BIT );			// Clear COM alm flag if fault state updated.

    if( protect->ComAlarm_Req_Flag  ){
        protect->ComAlarm_Req_Flag = NO;

		if( protect->TimeOut_Behavior == UART_TIMEOUT_BEHAVIOR_ONLY_ALARM ||
			protect->TimeOut_Behavior == UART_TIMEOUT_BEHAVIOR_CLEAR_NET_IO_AND_ALARM ){

			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_COMM_ERROR;
			}

			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_COMM_ERROR );

		}else{
			protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_COMM_ERROR );
		}

		if( protect->TimeOut_Behavior == UART_TIMEOUT_BEHAVIOR_CLEAR_NET_IO ||
			protect->TimeOut_Behavior == UART_TIMEOUT_BEHAVIOR_CLEAR_NET_IO_AND_ALARM ){

			CG_ComProtocol_01.COM_IO_Xn_BITF = 0;
		}
		
	} else if ( (*Com_BITF & _BIT( COM_TIME_OUT_BIT )) == 0 ) {			// If not COM alarm and not time out.
	
		protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_COMM_ERROR );
		
	}
#endif

}

/*===========================================================================================
    Function Name    : protect_PWR_On_RUN_Error
    Input            : 1.protect
                       2. CMD_RUN: the state of CMD_RUN command at start.
					   3. is_enable: YES=InitStartError enabled, NO=InitStartError disabled.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Fault of Power on when RUN_CMD is active (function can be set by parameter).					   
					   Should be called at Initial after the IO, paramter related setup and pollings. (with enable setup by paramter)
					   protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_INIT_START ) should be called in call_1ms_Protect()
					   after power on delay.
//==========================================================================================*/
void protect_PWR_On_RUN_Error ( Struct_Driver_Pretect* protect, const uint8_t CMD_RUN, const int32_t is_enable )
{

	if (is_enable == YES) {
		if ( CMD_RUN == HIGH ) {
			if( protect->first_fault == FAULT_STATE_NO_FAULT ){
				protect->first_fault = FAULT_STATE_PWR_ON_RUN;
			}		
			protect->Fault_BITF |=  ( 1UL << FAULT_STATE_PWR_ON_RUN );
		}
	} else {
		protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_PWR_ON_RUN );
	}

}

/*===========================================================================================
    Function Name    : protect_EEP_Error
    Input            : 1.protect
                       2. is_eep_ok: EEP ok flag.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : EEP error of Data Bus, Address, WriteEN, Content.
					   Can NOT be reset by alarm reset.
//==========================================================================================*/
void protect_EEP_Error ( Struct_Driver_Pretect* protect, const uint8_t is_eep_ok )
{
	if (is_eep_ok == NO) {		
		if( protect->first_fault == FAULT_STATE_NO_FAULT ){
			protect->first_fault = FAULT_STATE_EEP_ERROR;
		}		
		protect->Fault_BITF |=  ( 1UL << FAULT_STATE_EEP_ERROR );
	}
}

/*===========================================================================================
    Function Name    : protect_IO_Type_fault_handler
    Input            : 1.protect
                       2. IO_Func_State: IOF_STAT_BITF from IO_Func
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Convert IO_STAT_BITF of fault related funciton bit into IO_TYPE_FAULT bit field.
//==========================================================================================*/
void protect_IO_Type_fault_handler ( Struct_Driver_Pretect* protect, uint32_t IO_Func_State )
{

	uint32_t OT_MOS_Bit		= ( ((IO_Func_State>>FUNC_MOS_OT) & 0x01) << IO_TYPE_FAULT_OT_MOS );
	uint32_t OT_MOTOR_Bit	= ( ((IO_Func_State>>FUNC_MOTOR_OT) & 0x01) << IO_TYPE_FAULT_OT_MOTOR );
	uint32_t OT_RGN_Bit		= ( ((IO_Func_State>>FUNC_RGN_OT) & 0x01) << IO_TYPE_FAULT_OT_RGN );
	uint32_t EXT_ERROR_Bit	= ( ((IO_Func_State>>FUNC_EXT_ERROR) & 0x01) << IO_TYPE_FAULT_EXT_ERROR );
	
    protect->IO_Type_Fault_BITF = 0;

	protect->IO_Type_Fault_BITF = ( OT_MOS_Bit | OT_MOTOR_Bit | OT_RGN_Bit | EXT_ERROR_Bit );

}

/*===========================================================================================
    Function Name    : protect_UserEC_Convert
    Input            : 1. fault: fault number to convert
    Return           : user_error_code
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Convert RD Fault number into user error code number.
//==========================================================================================*/
uint8_t protect_UserEC_Convert ( const uint8_t fault )
{
	uint8_t user_error_code = 0;
	
	if ( fault == FAULT_STATE_BUSV_LOW ) {
		user_error_code = FAULT_STATE_BUSV_UNDER;
	} else {
		user_error_code = fault;
	}
	return (user_error_code);
}

/*===========================================================================================
    Function Name    : protect_signal_AlmLED
    Input            : 1.protect
                       2.bldc_ctrl
                       3.fault_index : error index
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : This function output LED flash according to the fault index
//==========================================================================================*/
void protect_signal_AlmLED ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, const uint8_t fault_index )
{

	if ( ( protect->Alm_tick_Time_BITF & (1UL << ALM_TICK_10MS_BIT ) ) != 0 ) {
		protect->Alm_tick_Time_BITF    &= ~(1UL << ALM_TICK_10MS_BIT );

		if( ++protect->LED_flash_timer >= LED_FLASH_PULSE_WIDTH ){
			protect->LED_flash_timer = 0;
			protect->LED_flash_count++;
		}
	}
  
    //if( ( protect->LED_flash_count % 2 ) == 1 && ( protect->LED_flash_count / 2 ) < fault_index  ){
	if( MOD( protect->LED_flash_count, 2 ) == 1 && ( protect->LED_flash_count / 2 ) < fault_index  ){
		//ALARM_LED_ON;
		bldc_ctrl->AlarmLED_State = HIGH;
		bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_PLUSE ];
		bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_ALM_PLUSE ] = bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BUSY_ALM_PLUSE ];
		
    }else{
    	//ALARM_LED_OFF;
        bldc_ctrl->AlarmLED_State = LOW;
    	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] = 1 - bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_ALM_PLUSE ];
    	bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_ALM_PLUSE ] = 1- bldc_ctrl->IO_Func_Ptr->ActState_of_Func[ OUTPUT_BUSY_ALM_PLUSE ];
	
        //if( protect->LED_flash_count > fault_index * 2 + 5 ){	// 1000ms
		if( protect->LED_flash_count > fault_index * 2 + 6 ){	// 1500ms
            protect->LED_flash_count = 0;
        }
    }

	OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_ALM_PLUSE ] ]
				   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_ALM_PLUSE ] ]();
	
	OutputYn_action[ bldc_ctrl->IO_Func_Ptr->Output_State[ OUTPUT_BUSY_ALM_PLUSE ] ]
				   [ bldc_ctrl->IO_Func_Ptr->OutputPin_of_Func[ OUTPUT_BUSY_ALM_PLUSE ] ]();

	
}

/*===========================================================================================
    Function Name    : protect_is_alarm_reset_allowed
    Input            : 1.protect
    Return           : YES or NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Alarm reset allowed check. Only when a fault situation solved.
//==========================================================================================*/
uint8_t protect_is_alarm_reset_allowed ( Struct_Driver_Pretect* protect )
{

    uint8_t return_value = NO;

	if ( (protect->Fault_BITF & (1UL << protect->first_fault)) == 0 )
	{
		// fault cleared, reset allowed.
		return_value = YES;
	} else {
		// fault still exist, NO reset allowed.
		return_value = NO;
	}

			
	return ( return_value );
}

/*===========================================================================================
    Function Name    : protect_WDT_occured_record
    Input            : NULL
    Return           : NULL
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Record WDT record in last ALM His EEP if WDT occured.
					   Should be called in WDT warning ISR.
//==========================================================================================*/
void protect_WDT_occured_record ( void )
{
	CG_Protect.Alarm_His_EEP[HIST_ARRAY_SIZE-1] = FAULT_WDT_ISSUE;
	saveEEPParameter_Single( PA_ALM_HIS_ADDS_INDEX, (HIST_ARRAY_SIZE-1), CG_Protect.Alarm_His_EEP[HIST_ARRAY_SIZE-1], PA_EEP_WO );
}

/*===========================================================================================
    Function Name    : protect_io_reset_check_routine
    Input            : 1.protect
                       2.bldc_ctrl
                       3. check_tick: the ticks to check for IO reset.
					   4. CMD_RUN: command of motor run operation.
    Return           : AlmRstFlag: AlmResetFlag
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Alarm reset by IO check routine.
//==========================================================================================*/
uint8_t protect_io_reset_check_routine ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint8_t check_tick, const uint8_t CMD_RUN )
{
	uint8_t  AlmRstFlag = NO;
	#if(1)
	
    if ( (protect->Alm_tick_Time_BITF & (1UL << ALM_TICK_1MS_BIT))    != 0 ) {
		
	    protect->Alm_tick_Time_BITF    &= ~(1UL << ALM_TICK_1MS_BIT );
			
		if ( CMD_RUN == LOW ) {
			
			if(  ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_ALL ] & ( ( 1UL << FUNC_ALARM_RESET ) | ( 1UL << FUNC_EBA_RESET ) ) ) != 0 ){
				
				if( ++protect->IO_RST_on_Cnt >= check_tick ){
					protect->IO_RST_on_Cnt = check_tick;
					protect->IO_RST_State = IO_RESET_STEP_READY;
				}
				
			}else{

				if( protect->IO_RST_State == IO_RESET_STEP_READY ){
					protect->IO_RST_State = IO_RESET_STEP_DONE;
				}else{
					protect->IO_RST_on_Cnt = 0;
				}

			}

		} else {		
			protect->IO_RST_on_Cnt = 0;
			protect->IO_RST_State = IO_RESET_STAND_BY;
		}
	}
	
	if ( protect->IO_RST_State == IO_RESET_STEP_DONE ) {
		protect->IO_RST_State 			= IO_RESET_STAND_BY;
		protect->IO_RST_on_Cnt			= 0;
		AlmRstFlag 							= YES;
	}
#endif
	
	return (AlmRstFlag);
}

/*===========================================================================================
    Function Name    : protect_ParameterError_Max
    Input            : 1.protect
                       2. limit: limit value from HWEEP.
					   3. data: data to check.
					   4. hw_eep_Index: HWEEP Index of the data.
    Return           : result: 0:BAD data is over max, 1:GOOD data is normal.
					   *Save HWIndex to OverLimit_Index if BAD.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Max check. Check if the setting will make damage to driver. 
//==========================================================================================*/
uint8_t protect_ParameterError_Max ( Struct_Driver_Pretect* protect, const int32_t limit, const int32_t data, const uint32_t hw_eep_Index )
{
	uint8_t result = 1;

	if (data > limit) {
		result = 0;
		protect->OverLimit_Index =  hw_eep_Index;
	}

	return (result);	
}

/*===========================================================================================
    Function Name    : protect_ParameterError_Min
    Input            : 1.protect
                       2. limit: limit value from HWEEP.
					   3. data: data to check.
					   4. hw_eep_Index: HWEEP Index of the data.
    Return           : result: 0:BAD data is under min, 1:GOOD data is normal.
					   *Save HWIndex to OverLimit_Index if BAD.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Min check. Check if the setting will make damage to driver.
//==========================================================================================*/
uint8_t protect_ParameterError_Min ( Struct_Driver_Pretect* protect, const int32_t limit, const int32_t data, const uint32_t hw_eep_Index )
{
	uint8_t result = 1;

	if (data < limit) {
		result = 0;
		protect->OverLimit_Index =  hw_eep_Index;
	}
	
	return (result);
}

/*===========================================================================================
    Function Name    : protect_ParameterError_Special_Case
    Input            : 1.protect
                       2. condition1: condition1.
					   3. condition2: condition2.
					   4. hw_eep_Index: HWEEP Index of the data.
    Return           : result: 0:BAD,  2 conditions are true, setting will make trouble;
     	 	 	 	 	 	   1:GOOD, settng is good;
					   *Save HWIndex to OverLimit_Index if BAD.
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : for condition1 and 2, if all 2 of them are true, it's not a good setting
//==========================================================================================*/
uint8_t protect_ParameterError_Special_Case ( Struct_Driver_Pretect* protect, const int32_t condition1, const int32_t condition2, const uint32_t hw_eep_Index )
{
	uint8_t result = 1;

	if ( condition1 && condition2 ) {
		result = 0;
		protect->OverLimit_Index =  hw_eep_Index;
	}

	return (result);
}

/*===========================================================================================
    Function Name    : protect_ParameterError_check
    Input            : 1.protect
                       2.bldc_ctrl
    Return           : 1. result: 0:BAD any of the data is incorrect, 1:GOOD all data is normal.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check if the setting will make damage to driver.
					   Set OverLimit_Index to def is GOOD.
//==========================================================================================*/
uint8_t protect_ParameterError_check ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl )
{

	uint8_t result = 1;
#if(1)
	
	result &= protect_ParameterError_Max( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_OVP ], 	protect->over_vbus_value, 			HWEEP_IDX_OVP );
	result &= protect_ParameterError_Max( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_OVPR ], 	protect->over_vbus_recover_value, 	HWEEP_IDX_OVPR );
	
	result &= protect_ParameterError_Min( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_UVP ], 	protect->under_vbus_value, 			HWEEP_IDX_UVP );
	result &= protect_ParameterError_Min( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_UVPR ], 	protect->under_vbus_recover_value, 	HWEEP_IDX_UVPR );
	result &= protect_ParameterError_Min( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_UVP ], 	protect->low_vbus_value, 				HWEEP_IDX_UVP );
	result &= protect_ParameterError_Min( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_UVPR ], 	protect->low_vbus_recover_value, 		HWEEP_IDX_UVPR );

	// Tq_Max check
	/*
	if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
	    result &= protect_ParameterError_Max( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ], bldc_ctrl->OpMode_Ptr->Torque_Limit, HWEEP_IDX_TQ_MAX );
	}else{
	    result &= protect_ParameterError_Max( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] * 2, bldc_ctrl->OpMode_Ptr->Torque_Limit, HWEEP_IDX_TQ_MAX );
	}*/
	result &= protect_ParameterError_Max( protect, CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] * TORQUE_J06TOI04_GAIN, bldc_ctrl->OpMode_Ptr->Torque_Limit, HWEEP_IDX_TQ_MAX );

	// I rate check
	
	// Special setting check
	result &= protect_ParameterError_Special_Case( protect, bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL, RUN_CONDITION_2, HWEEP_IDX_DRIVE_TYPE );
	//result &= protect_ParameterError_Special_Case( protect, bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL, bldc_ctrl->Drive_Ptr->Mode == BLDCDRIVE_FOC, HWEEP_IDX_DRIVE_TYPE );

	if (result == 1) {
		protect->OverLimit_Index = HWEEP_IDX_TOL;
	}
#endif
	
	return (result);	
}

/*===========================================================================================
    Function Name    : call_1ms_Protect
    Input            : 1. protect
					   2. bldc_ctrl
					   3. mos_ot_value
					   4. *Com_BITF: COM_Protocol bit field.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : 1 ms time up event of Protect.
//==========================================================================================*/
void call_1ms_Protect ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, int32_t mos_ot_value, uint32_t *Com_BITF )
{
#if(1)

    protect->Alm_tick_Time_BITF |= (1UL << ALM_TICK_1MS_BIT );

	if ( CG_MD.Relay_On_Cnt >= RELAY_ON_DELAY_TIME ){

		protect_BusV_Over 	( protect, CG_ADC.BusV, protect->over_vbus_value, protect->over_vbus_recover_value );
		protect_BusV_Low    ( protect, CG_ADC.BusV, protect->low_vbus_value, protect->low_vbus_recover_value );
		protect_BusV_Under  ( protect, CG_ADC.BusV, protect->under_vbus_value, protect->under_vbus_recover_value );

		#if(1)

		protect_OT_Mos   ( protect,
		                   protect->MosNTC_1.Temperature,//mos_ot_value,
						   1,
						   CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_TYPE ],
						   CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_VALUE ],
						   CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_REC ]  );
		
		protect_OT_Mos   ( protect,
		                   protect->MosNTC_2.Temperature,//mos_ot_value,
                           2,
                           CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_TYPE ],
                           CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_VALUE ],
                           CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_REC ]  );

		protect_OT_Mos   ( protect,
		                   protect->MosNTC_3.Temperature,//mos_ot_value,
                           3,
                           CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_TYPE ],
                           CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_VALUE ],
                           CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_REC ]  );

		protect_OT_RGN   ( protect, ((protect->IO_Type_Fault_BITF>>IO_TYPE_FAULT_OT_RGN) & 0x01), 0 );

		protect_OT_Motor ( protect,
		                   ( ( CG_GPIO.OtherInput_State_BITF >> OTHER_INPUT_S0_TEMP ) & 0x01 ) * ADC_MAX_VALUE,
		                   CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_MOTOROT_SENSOR_TYPE ],
		                   ADC_MAX_VALUE >> 1,
		                   ADC_MAX_VALUE >> 1 );

		#endif
		
		protect_OverSpeed( protect, bldc_ctrl, bldc_ctrl->Current_RPM_Abs, protect->OverSpeed );

		if( bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_HALL ){
			protect_Hall_Seguence ( protect, bldc_ctrl, protect->MotorFB );
			protect_Hall_state( protect, bldc_ctrl->Hall_Ptr->Current_State );
		}else{
			protect_Encoder ( protect, bldc_ctrl, bldc_ctrl->Encoder_Ptr, 0 );
		}
		
		protect_Restart_fault( protect, bldc_ctrl );
		
		//protect_IPM_fault ( protect->IPM_Fault_State, HIGH );

		protect_HW_CurrentRestraint ( protect, bldc_ctrl, protect->HWCR_State, HIGH, 1000, 1000 );
		
		protect_FW_CurrentRestraint ( protect,
		                              bldc_ctrl,
		                              bldc_ctrl->ADC_Ptr->Shunt_I_Avg,//CG_ADC.Shunt_I,
		                              bldc_ctrl->ADC_Ptr->FWOCP,
									  OVER_CURRENT_BOOST_TIME	, 	// 100 = 100ms
									  OVER_CURRENT_REST_TIME	,   // 100 = 100ms
									  //OVER_CURRENT_FAULT );
									  OVER_CURRENT_FAULT & 0x01 );
							
		protect_OverLoad_fault( protect,
                                bldc_ctrl,
                                bldc_ctrl->ADC_Ptr->Shunt_I_Avg,
                                bldc_ctrl->OpMode_Ptr->Torque_Limit,
                                bldc_ctrl->Tq_Act_Time,
                                bldc_ctrl->Tq_Rec_Time,
                                bldc_ctrl->Stall_Time );
							
		protect_OverPower_fault ( protect,
	                              bldc_ctrl,
	                              bldc_ctrl->ADC_Ptr->Power,
								  OVER_POWER_LIMIT,
								  OVER_POWER_BOOST_TIME * TIME_CONST_100MS,
								  OVER_POWER_REST_TIME * TIME_CONST_100MS,
								  OVER_POWER_FAULT );
		

		protect_EXT_ERROR ( protect, ((protect->IO_Type_Fault_BITF>>IO_TYPE_FAULT_EXT_ERROR) & 0x01) );
		
		protect_COM_Alarm ( protect, Com_BITF );
		
		// Clear INIT FAULT after powered on delay for alarm reset.
		if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == LOW ){
			protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_PWR_ON_RUN );
		}

	}
	
	protect_ParameterError( protect, bldc_ctrl, Com_BITF );
		
	protect_fault_stop_check_routine( protect, bldc_ctrl );

	//BUSV_RELAY_CTRL( busV_relay_ON );
#endif
	
}

/*===========================================================================================
    Function Name    : call_100ms_Protect
    Input            : protect
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 100 ms time up event of Protect.
//==========================================================================================*/
void call_100ms_Protect( Struct_Driver_Pretect* protect )
{
    // Error Code EEP save delay time.
    if( protect->ErrorCode_LimitTime > 0 ){
        protect->ErrorCode_LimitTime--;
    }

    // Auto Reset Tick only increase when no any fault remains.
    if( protect->Fault_BITF == 0 ){
        if( ++protect->auto_reset_timer > 65535 ){
            protect->auto_reset_timer = 65535;
        }
    }else{
        protect->auto_reset_timer = 0;
    }

}
/************************** <END OF FILE> *****************************************/
