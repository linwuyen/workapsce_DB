/*===========================================================================================
    File Name       : Protect_Setting.h
    Built Date      : 2012-12-07
	Version         : V1.01a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file contains the settings of protection of driver and the alarm routine.
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef PROTECT_H
#define PROTECT_H

#include "Protect_TypeDef.h"


#define OT_DEBOUNCE_CONST					1000
//#define IPM_FAULT_STATE						( PWM_U.TZFLG.bit.OST )//( GpioDataRegs.GPADAT.bit.GPIO31 )
//#define	IPM_FAULT_CLEAR						{ PWM_U.TZCLR.bit.OST = 1; PWM_V.TZCLR.bit.OST = 1; PWM_W.TZCLR.bit.OST = 1; }

#define ENCODER_OVERFLOW_DISABLE            2

/*===========================================================================================
    Hardware limit from HWEEP
//==========================================================================================*/
#define 	OVER_CURRENT_LIMIT		SHUNT_I_FWP// Unit: 0.01A
#define		OVER_CURRENT_BOOST_TIME	CG_HWEEP.HW_Info[ HWEEP_IDX_I_OB ]// Unit: msec
#define		OVER_CURRENT_REST_TIME	CG_HWEEP.HW_Info[ HWEEP_IDX_I_RS ]// Unit: msec
#define		OVER_CURRENT_FAULT		CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OC_FAULT_EN ]// behavior when linmit: NO=Foldback, YES=fault.

#define 	OVER_LOAD_LIMIT			SHUNT_I_HWP// Unit: 0.01A
#define		OVER_LOAD_BOOST_TIME	CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_TQ_ACT_TIME ]// Unit: 0.1 sec
#define		OVER_LOAD_REST_TIME		CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_TQ_REC_TIME ]// Unit: 0.1 sec

#define 	OVER_POWER_LIMIT		CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_MAX ]	// Unit: W
#define		OVER_POWER_BOOST_TIME   CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_OB ]    // Unit: 0.1 sec
#define		OVER_POWER_REST_TIME	CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_RS ]	// Unit: 0.1 sec
#define		OVER_POWER_P_GAIN 		CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_P_GAIN ]
#define		OVER_POWER_FAULT		CG_Parameter.RAM_data[ PARAMETER_PROTECT ][ PROTECT_OP_FAULT_EN ]// behavior when linmit: NO=Foldback, YES=fault.

/*===========================================================================================
    Protection Basic setup
//==========================================================================================*/
#define		HIST_NUM			10
#define 	HIST_ARRAY_SIZE		32
#define		BUSV_LOW_TIME       5000
#define		BUSV_LOW_REC_TIME   1000

#define		LED_FLASH_PULSE_WIDTH 	30//25	// unit : 10ms; ex : 1 => 10ms
#define     LED_FLASH_PULSE_WIDTH_WAIT   80

#define 	RESTART_FAULT_TIME	6

#define     HISTORY_OFFSET      16
#define     HISTORY_INDEX_M0    0
#define     HISTORY_INDEX_M1    HISTORY_OFFSET

#define     HISTORY_INDEX_PA_ERROR  15


#define 	CNT_LIMT			100000UL

#if(1)	// 120 degress Hall, Fault: 000, 111
	#define HALL_FAULT_STATE_0	0
	#define HALL_FAULT_STATE_1  7
#else	// 60 degress Hall, Fault: 010, 101	
	#define HALL_FAULT_STATE_0	2
	#define HALL_FAULT_STATE_1  5
#endif

#define		OVP_VDC				CG_Protect.over_vbus_value				//41500				
#define		OVPR_VDC            CG_Protect.over_vbus_recover_value 		//36200
#define		LVP_VDC             CG_Protect.low_vbus_value				//21800
#define		LVPR_VDC			CG_Protect.low_vbus_recover_value		//26350
#define		UVP_VDC             CG_Protect.under_vbus_value				//10000//18600
#define		UVPR_VDC			CG_Protect.under_vbus_recover_value		//12000//26350

/*===========================================================================================
    Error behavior Defines
//==========================================================================================*/
enum{
	ERROR_BEHAVIOR_ALARM	= 0,
	ERROR_BEHAVIOR_FREE		= 1,
	ERROR_BEHAVIOR_NUM		= 2
};

/*===========================================================================================
    IO Reset state Defines
//==========================================================================================*/
enum{
	IO_RESET_STAND_BY		= 0,
	IO_RESET_STEP_READY	 	= 1,
	IO_RESET_STEP_DONE  	= 2
};

/*===========================================================================================
    Alm_tick_Time_BITF Defines
//==========================================================================================*/
enum{
	ALM_TICK_1MS_BIT		= 0,
	ALM_TICK_10MS_BIT	 	= 1,
	ALM_TICK_100MS_BIT  	= 2
};

/*===========================================================================================
    OT switch Senosr Type
//==========================================================================================*/
enum{
	OT_MODE_NORM 		= 0,
	OT_MODE_REV 		= 1,
	OT_MODE_DISABLE     = 2,
	OT_MODE_NUM 	    = 3
};

/*===========================================================================================
    IO Type Fault Defines
//==========================================================================================*/
enum{
	IO_TYPE_FAULT_OT_MOS		= 0,
	IO_TYPE_FAULT_OT_MOTOR	 	= 1,
	IO_TYPE_FAULT_OT_RGN	  	= 2,
	IO_TYPE_FAULT_EXT_ERROR		= 3
};

/*===========================================================================================
    Fault State Defines
//==========================================================================================*/ 
enum{
	FAULT_STATE_NO_FAULT        = 0,            // No fault.
	FAULT_STATE_IPM_FAULT 		= 1,			// IPM over current fault. 								(Do free)
	FAULT_STATE_LOAD_OVER		= 2,			// Motor running over load.
	FAULT_STATE_HALL_FAULT	 	= 3,			// Hall fault of sensed exceptions.						(Do free)	
	FAULT_STATE_BUSV_OVER		= 4,			// Vbus over voltage.									(Do free)
	FAULT_STATE_BUSV_UNDER		= 5,			// Vbus under voltage.									(Do free)
	FAULT_STATE_OT_MOS			= 6,
	
	FAULT_STATE_RESTART_FAULT	= 7,			// Failed restart.
	FAULT_STATE_EEP_ERROR		= 8,
	FAULT_STATE_OT_RGN			= 9,
	FAULT_STATE_OT_MOTOR		= 10,	
	FAULT_STATE_MOTOR_COIL		= 11,
	
	
	FAULT_STATE_SPEED_OVER		= 12,
	//FAULT_STATE_POSITION_FAULT	= 13,
	FAULT_STATE_ENCODER_FAULT	= 13,
	FAULT_STATE_PWR_ON_RUN		= 14,
	FAULT_STATE_EXT_ERROR		= 15,

	//FAULT_STATE_PWR_LOSS		= 16,			// Power loss fault. 			 						(Do free)
	FAULT_STATE_PWR_ERROR		= 16,			// Power loss fault.
	FAULT_STATE_INIT_SENSOR		= 17,
	
	FAULT_STATE_BUSV_LOW		= 18,			// Vbus low voltage
	
	
	FAULT_STATE_OVER_TORQUE		= 19,			// Motor running over torque.
	FAULT_STATE_PHASE_FAULT		= 20,			// Hall sensor phase error.
	
	FAULT_STATE_COMM_ERROR		= 21,
	FAULT_STATE_PARAMETER_ERROR	= 22,

	FAULT_STATE_TOTALNUM		= 23,
	
	FAULT_WDT_ISSUE				= 101
};

enum{
    ALARM_MODE_INDEPENDENT  = 0,
    ALARM_MODE_DEPENDENT    = 1,
    ALARM_MODE_NUM          = 2
};

/*===========================================================================================
    Protect variable data structure
//==========================================================================================*/
typedef struct{

    uint8_t     Alarm_Mode;         // 0 = Motor 0 and Motor 1 independence
                                    // 1 = any motor alarms, another motor follow it

	int32_t		Alarm_His_EEP 	[ HIST_ARRAY_SIZE ];		// Fault alarm history. with EEP.
	int32_t		Warning_His_RAM [ HIST_ARRAY_SIZE ];		// Warning history. ram only.

	int32_t     PA_Limit_Check_Cnt;

    uint32_t    OverBusV_Clamping;
    uint32_t    UnderBusV_Clamping;

	Struct_Driver_Pretect   Motor_0;
	//Struct_Driver_Pretect   Motor_1;

}Struct_Pretect;


/*===========================================================================================
    Function Name    : variableInitial_Protect
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Protect initial
//==========================================================================================*/
void variableInitial_Protect ( void );

/*===========================================================================================
    Function Name    : protect_fault_stop_check_routine
    Input            : 1. protect
                       2. bldc_ctrl
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the fault state to determine to stop the motor and free the output.
                       Polling check in main loop.
                       CG_Protect.Fault_Stop_Mask_BITF is the mask to corresponding fault the cus stop.
//==========================================================================================*/
void protect_fault_stop_check_routine ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : protect_Fault_History_Handler
    Input            : protect
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Save Fault Error Code into EEP.
//==========================================================================================*/
void protect_Fault_History_Handler ( Struct_Driver_Pretect* protect );

/*===========================================================================================
    Function Name    : protectSetup_OVP
    Input            : 1.protect
                       2.OVP: Over voltage protect
                       3.OVPR: Over voltage protect recovery
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup over V bus pretect.
//==========================================================================================*/
void protectSetup_OVP ( Struct_Driver_Pretect* protect, int32_t OVP, int32_t OVPR );

/*===========================================================================================
    Function Name    : protectSetup_LVP
    Input            : 1.protect
                       2.LVP: lower voltage protect
                       3.LVPR: lower voltage protect recovery
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup lower V bus pretect.
//==========================================================================================*/
void protectSetup_LVP ( Struct_Driver_Pretect* protect, int32_t LVP, int32_t LVPR );

/*===========================================================================================
    Function Name    : protectSetup_UVP
    Input            : 1.protect
                       2.UVP: Under voltage protect
                       3.UVPR: Under voltage protect recovery
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Setup under V bus pretect.
//==========================================================================================*/
void protectSetup_UVP ( Struct_Driver_Pretect* protect, int32_t UVP, int32_t UVPR );

/*===========================================================================================
    Function Name    : protect_BusV_Under
    Input            : 1.protect
                       2.busV: V bus value
                       3.fault_value: fault value.
                       4.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Under V bus pretect.
//==========================================================================================*/
void protect_BusV_Under ( Struct_Driver_Pretect* protect, const uint32_t busV, const uint32_t fault_value, const uint32_t recover_value  );

/*===========================================================================================
    Function Name    : protect_BusV_Low
    Input            : 1.protect
                       2.busV: V bus value
                       3.fault_value: fault value.
                       4.recover_value: recover value.
    Return           : NULL.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Low V bus pretect.
//==========================================================================================*/
void protect_BusV_Low ( Struct_Driver_Pretect* protect, const uint32_t busV, const uint32_t fault_value, const uint32_t recover_value  );

/*===========================================================================================
    Function Name    : protect_BusV_Over
    Input            : 1.protect
                       2.busV: V bus value
                       3.fault_value: fault value.
                       4.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : High V bus pretect.
//==========================================================================================*/
void protect_BusV_Over ( Struct_Driver_Pretect* protect, const uint32_t busV, const uint32_t fault_value, const uint32_t recover_value );

/*===========================================================================================
    Function Name    : protect_IPM_fault
    Input            : 1.protect
                       2.IPM_input: IPM fault input
                       3.fault_state: fault state.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : IPM fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_IPM_fault ( Struct_Driver_Pretect* protect, uint32_t IPM_input, uint8_t fault_state );

/*===========================================================================================
    Function Name    : detect_HWOCP
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void detect_HWOCP( void );

/*===========================================================================================
    Function Name    : protect_HW_CurrentRestraint
    Input            : 1.protect
                       2.bldc_ctrl
                       3.IPM_input: IPM fault input
                       4.fault_state: fault state.
                       5.limit_time: limit time
                       6.recover_time: recover time.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : HW CurrentRestraint pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_HW_CurrentRestraint ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t IPM_input, uint8_t fault_state, uint32_t limit_time, uint32_t recover_time  );

/*===========================================================================================
    Function Name    : protect_FW_CurrentRestraint
    Input            : 1.protect
                       2.bldc_ctrl
                       3.OverLoad_input: OverLoad fault input
                       4.fault_state: fault state.
                       5.limit_time: limit time
                       6.recover_time: recover time.
                       7.fault_en : fault_en = 1 means when protect->FWCR_flag == YES, motor state will be seted to fault.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Over Load fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_FW_CurrentRestraint ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t OverLoad_input, uint32_t fault_state, uint32_t limit_time, uint32_t recover_time, int32_t fault_en );


/*===========================================================================================
    Function Name    : protect_OverLoad_fault
    Input            : 1.protect
                       2.bldc_ctrl
                       3.OverLoad_input: OverLoad fault input
                       4.fault_state: fault state.
                       5.limit_time: limit time
                       6.recover_time: recover time.
                       7.stall_time: when motor stuck, driver will be : 0 = still run state, 1000 = 1000ms later fall into alarm.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Over Load fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_OverLoad_fault ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t OverLoad_input, uint32_t fault_state, uint32_t limit_time, uint32_t recover_time, uint32_t stall_time );

/*===========================================================================================
    Function Name    :protect_OverPower_fault
    Input            : 1.protect
                       2.bldc_ctrl
                       3.OverPower_input: OverPower fault input
                       4.fault_state: fault state.
                       5.limit_time: limit time
                       6.recover_time: recover time.
                       7.fault_en : fault_en = 1 means when protect->FWCR_flag == YES, motor state will be seted to fault.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Over Power fault pretect. ( It should be puted at 1ms event )
//==========================================================================================*/
void protect_OverPower_fault ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t OverPower_input, uint32_t fault_state, uint32_t limit_time, uint32_t recover_time, uint32_t fault_en );


/*===========================================================================================
    Function Name    : protect_OT_Mos
    Input            : 1.protect
                       2.value: input value
                       3.sensor_index: MosOT 1 2 3 4
                       4.mode: 0 = normal mode, big value => big real value
                               1 = reverse mode: big value => small real value
                       5.fault_value: fault value.
                       6.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Mos OT pretect.
//==========================================================================================*/
void protect_OT_Mos ( Struct_Driver_Pretect* protect, const uint32_t value, const uint8_t sensor_index, const uint8_t mode, const uint32_t fault_value, const uint32_t recover_value );

/*===========================================================================================
    Function Name    : protect_OT_Motor
    Input            : 1.protect
                       2.value: input value
                       3.mode: 0 = normal mode, big value => big real value
                               1 = reverse mode: big value => small real value
                       4.fault_value: fault value.
                       5.recover_value: recover value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Mos OT pretect.
//==========================================================================================*/
void protect_OT_Motor ( Struct_Driver_Pretect* protect, const uint32_t value, const uint8_t mode, const uint32_t fault_value, const uint32_t recover_value );

/*===========================================================================================
    Function Name    : protect_OT_RGN
    Input            : 1.protect
                       2.value: OT_RGN state
                       3.mode: Normal open or close.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : RGN OT pretect.
//==========================================================================================*/
void protect_OT_RGN ( Struct_Driver_Pretect* protect, const uint32_t state, const uint8_t mode );

/*===========================================================================================
    Function Name    : protect_EXT_ERROR
    Input            : 1.protect
                       2.value: EXT_ERROR IO state
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : RGN OT pretect.
//==========================================================================================*/
void protect_EXT_ERROR ( Struct_Driver_Pretect* protect, const uint32_t state );

/*===========================================================================================
    Function Name    : protect_OverSpeed
    Input            : 1.protect
                       2.bldc_ctrl
                       3.speed: Current speed.
                       4.limit_speed: Restraint value.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Over speed pretect.
//==========================================================================================*/
void protect_OverSpeed ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, const uint32_t speed, const uint32_t limit_speed );

/*===========================================================================================
    Function Name    : protect_Hall_Seguence
    Input            : 1.protect
                       2.bldc_ctrl
                       3.enabled: Enable this protection
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Hall sequence pretect.
//==========================================================================================*/
void protect_Hall_Seguence ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint8_t enabled );

/*===========================================================================================
    Function Name    : protect_Hall_state
    Input            : 1.protect
                       2.hall_state: hall state
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Hall sensor state pretect.
                       Without noise filter.
//==========================================================================================*/
void protect_Hall_state ( Struct_Driver_Pretect* protect, const uint32_t hall_state );

/*===========================================================================================
    Function Name    : protect_Encoder
    Input            : 1.protect
                       2.bldc_ctrl
                       3.encoder
                       4.index: encoder index value
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 1. Encoder check, make sure encoder is installed
                       2. Index check, make sure that encoder's index is between -32768 ~ 32767
//==========================================================================================*/
void protect_Encoder ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, Struct_Basic_Encoder* encoder, const int32_t index );

/*===========================================================================================
    Function Name    : protect_Restart_fault
    Input            : 1.protect
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 
//==========================================================================================*/
void protect_Restart_fault ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : protect_COM_Alarm
    Input            : 1.protect
                       2. *Com_BITF: COM_Protocol bit field.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : COM alarm fault check.
//==========================================================================================*/
void protect_COM_Alarm ( Struct_Driver_Pretect* protect, uint32_t *Com_BITF );

/*===========================================================================================
    Function Name    : protect_PWR_On_RUN_Error
    Input            : 1.protect
                       2. CMD_RUN: the state of CMD_RUN command at start.
                       3. is_enable: YES=InitStartError enabled, NO=InitStartError disabled.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Fault of Power on when RUN_CMD is active (function can be set by parameter).
                       Should be called at Initial after the IO, paramter related setup and pollings. (with enable setup by paramter)
                       protect->Fault_BITF &=  ~( 1UL << FAULT_STATE_INIT_START ) should be called in call_1ms_Protect()
                       after power on delay.
//==========================================================================================*/
void protect_PWR_On_RUN_Error ( Struct_Driver_Pretect* protect, const uint8_t CMD_RUN, const int32_t is_enable );

/*===========================================================================================
    Function Name    : protect_EEP_Error
    Input            : 1.protect
                       2. is_eep_ok: EEP ok flag.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : EEP error of Data Bus, Address, WriteEN, Content.
                       Can NOT be reset by alarm reset.
//==========================================================================================*/
void protect_EEP_Error ( Struct_Driver_Pretect* protect, const uint8_t is_eep_ok );

/*===========================================================================================
    Function Name    : protect_IO_Type_fault_handler
    Input            : 1.protect
                       2. IO_Func_State: IOF_STAT_BITF from IO_Func
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Convert IO_STAT_BITF of fault related funciton bit into IO_TYPE_FAULT bit field.
//==========================================================================================*/
void protect_IO_Type_fault_handler ( Struct_Driver_Pretect* protect, uint32_t IO_Func_State );

/*===========================================================================================
    Function Name    : protect_UserEC_Convert
    Input            : 1. fault: fault number to convert
    Return           : user_error_code
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Convert RD Fault number into user error code number.
//==========================================================================================*/
uint8_t protect_UserEC_Convert ( const uint8_t fault );

/*===========================================================================================
    Function Name    : protect_signal_AlmLED
    Input            : 1.protect
                       2.bldc_ctrl
                       3.fault_index : error index
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : This function output LED flash according to the fault index
//==========================================================================================*/
void protect_signal_AlmLED ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, const uint8_t fault_index );

/*===========================================================================================
    Function Name    : protect_is_alarm_reset_allowed
    Input            : 1.protect
    Return           : YES or NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Alarm reset allowed check. Only when a fault situation solved.
//==========================================================================================*/
uint8_t protect_is_alarm_reset_allowed ( Struct_Driver_Pretect* protect );

/*===========================================================================================
    Function Name    : protect_WDT_occured_record
    Input            : NULL
    Return           : NULL
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Record WDT record in last ALM His EEP if WDT occured.
					   Should be called in WDT warning ISR.
//==========================================================================================*/
void protect_WDT_occured_record ( void );

/*===========================================================================================
    Function Name    : protect_io_reset_check_routine
    Input            : 1.protect
                       2.bldc_ctrl
                       3. check_tick: the ticks to check for IO reset.
                       4. CMD_RUN: command of motor run operation.
    Return           : AlmRstFlag: AlmResetFlag
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Alarm reset by IO check routine.
//==========================================================================================*/
uint8_t protect_io_reset_check_routine ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint8_t check_tick, const uint8_t CMD_RUN );

/*===========================================================================================
    Function Name    : protect_ParameterError_Max
    Input            : 1.protect
                       2. limit: limit value from HWEEP.
                       3. data: data to check.
                       4. hw_eep_Index: HWEEP Index of the data.
    Return           : result: 0:BAD data is over max, 1:GOOD data is normal.
                       *Save HWIndex to OverLimit_Index if BAD.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Max check. Check if the setting will make damage to driver. 
//==========================================================================================*/
uint8_t protect_ParameterError_Max ( Struct_Driver_Pretect* protect, const int32_t limit, const int32_t data, const uint32_t hw_eep_Index );

/*===========================================================================================
    Function Name    : protect_ParameterError_Min
    Input            : 1.protect
                       2. limit: limit value from HWEEP.
                       3. data: data to check.
                       4. hw_eep_Index: HWEEP Index of the data.
    Return           : result: 0:BAD data is under min, 1:GOOD data is normal.
                       *Save HWIndex to OverLimit_Index if BAD.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Min check. Check if the setting will make damage to driver.
//==========================================================================================*/
uint8_t protect_ParameterError_Min ( Struct_Driver_Pretect* protect, const int32_t limit, const int32_t data, const uint32_t hw_eep_Index );

/*===========================================================================================
    Function Name    : protect_ParameterError_Special_Case
    Input            : 1.protect
                       2. condition1: condition1.
                       3. condition2: condition2.
                       4. hw_eep_Index: HWEEP Index of the data.
    Return           : result: 0:BAD,  2 conditions are true, setting will make trouble;
                               1:GOOD, settng is good;
                       *Save HWIndex to OverLimit_Index if BAD.
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : for condition1 and 2, if all 2 of them are true, it's not a good setting
//==========================================================================================*/
uint8_t protect_ParameterError_Special_Case ( Struct_Driver_Pretect* protect, const int32_t condition1, const int32_t condition2, const uint32_t hw_eep_Index );

/*===========================================================================================
    Function Name    : protect_ParameterError_check
    Input            : 1.protect
                       2.bldc_ctrl
    Return           : 1. result: 0:BAD any of the data is incorrect, 1:GOOD all data is normal.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check if the setting will make damage to driver.
                       Set OverLimit_Index to def is GOOD.
//==========================================================================================*/
uint8_t protect_ParameterError_check ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : protect_ParameterError
    Input            : 1.protect
                       2.bldc_ctrl
                       3.*Com_BITF: com_protocol bitfield to check if parameter limit check req.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Check if the setting will make damage to driver.
                       Determine and set the fault flag only after each parameter change or Config from communication.
//==========================================================================================*/
void protect_ParameterError ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, uint32_t *Com_BITF );

/*===========================================================================================
    Function Name    : call_1ms_Protect
    Input            : 1. protect
                       2. bldc_ctrl
                       3. mos_ot_value
                       4. *Com_BITF: COM_Protocol bit field.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : 1 ms time up event of Protect.
//==========================================================================================*/
void call_1ms_Protect ( Struct_Driver_Pretect* protect, Struct_BLDC_CTRL* bldc_ctrl, int32_t mos_ot_value, uint32_t *Com_BITF );

/*===========================================================================================
    Function Name    : call_100ms_Protect
    Input            : protect
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 100 ms time up event of Protect.
//==========================================================================================*/
void call_100ms_Protect( Struct_Driver_Pretect* protect );

#endif

/************************** <END OF FILE> *****************************************/
