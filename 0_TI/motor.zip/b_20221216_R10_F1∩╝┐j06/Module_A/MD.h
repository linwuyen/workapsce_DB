/*===========================================================================================
    File Name       : MD.h ( Main Drive )
    Built Date      : 2012-11-02
	Version         : V1.01a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file provides the struct define(s) and macros for main.c  
    =========================================================================================
    History         : 2012-11-30 first released version
					  2012-11-30 SysTick_Flag renamed into SysTick_BITF. To emphasize the bit field use.
					  2014-07-22 V1.01a(R8): Declaration format modified.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef MD_H
#define MD_H

#define CPU_FREQ    			100E6
#define SYSTEM_FREQUENCE		CPU_FREQ
#define CPU_FREQ_IN_M 			100


#define HW_VERSION_A            0
#define HW_VERSION_B            1
#define HW_VERSION_C            2

//#define HW_VERSION              HW_VERSION_A
#define HW_VERSION              HW_VERSION_B    // This variable is different from CG_MD.HW_Ver
                                                // Since HW Version C has something to do with I2C ( we get CG_MD.HW_Ver from I2C )
                                                // Thus we distinguish it from CG_MD.HW_Ver ( CG_MD.HW_Ver still have its function )

#define DRIVER_NUM              2

#define PWR_ON_RUN_BIT			0
#define PWR_ON_I2C_DETECT_BIT   1
#define PWM_ON_SET_Y0_BIT       2
#define PWM_ON_CHECK_HALL_BIT   3
#define PWM_ON_HALL_INT_BIT     4

#define CMD_MOTOR_ALL_INDEX     0
#define CMD_MOTOR_0_INDEX       1
#define CMD_MOTOR_1_INDEX       2


#define PERCENTAGE_100			1000
#define TIME_CONST_100MS		100
#define PWM_PERIOD_LIMIT		1000//990
#define PWM_PERIOD_LIMIT_BRAKE	1000//10

#define	TORQUE_1A_CONST			100
//#define TORQUE_1A_CONST         10
#define TORQUE_J06TOI04_GAIN    10

#define ADC_SMOOTH_CONST		3

#define CAP_PWM_FREQ            20000UL
#define MBRAKE_FULL_DUTY        100     // 100 = 100%duty
#define VOLTAGE_48V             4800    // 4800 = 48.00V
#define VOLTAGE_24V             2400    // 4800 = 48.00V


#define DRIVER_MODE                     CG_Parameter.EEP_data[ PARAMETER_GENERAL ][ GENERAL_DRIVER_MODE ]
#define DRIVE_METHOD                    CG_HWEEP.HW_Info[ HWEEP_IDX_DRIVE_TYPE ]    //CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ MOTOR_DRIVE_METHOD ]
#define DRIVE_FREQUENCE                 CG_Parameter.EEP_data[ PARAMETER_GENERAL ][ GENERAL_POWER_PWM_FREQ ]//CG_HWEEP.HW_Info[ HWEEP_IDX_PWM_FREQUENCE ]
#define DRIVE_DEAD_TIME                 CG_HWEEP.HW_Info[ HWEEP_IDX_DEAD_TIME ]

enum{
    PA_DRIVER_MODE_2SMALL_MOTOR       = 0,
    PA_DRIVER_MODE_1BIG_MOTOR         = 1,
    PA_DRIVER_MODE_NUM                = 2
};

enum{
    PA_DRIVE_BIT_MOTOR_TYPE     = 0,
    PA_DRIVE_BIT_SENSOR_TYPE    = 2,
    PA_DRIVE_BIT_DRIVE_MODE     = 5,
    PA_DRIVE_BIT_NUM            = 7
};

#define MOTOR_TYPE_MOTOR_0              ( CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_AND_SENSOR_TYPE ] & 0x03 )
//#define MOTOR_TYPE_MOTOR_1              ( CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_AND_SENSOR_TYPE + PARAMETER_OFFSET ] & 0x03 )

#define ENCODER_TYPE_MOTOR_0            ( ( CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_AND_SENSOR_TYPE ] >> PA_DRIVE_BIT_SENSOR_TYPE ) & 0x07 )//CG_Parameter.EEP_data[ PARAMETER_GENERAL ][ GENERAL_SENSOR_TYPE ]
//#define ENCODER_TYPE_MOTOR_1            ( ( CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_AND_SENSOR_TYPE + PARAMETER_OFFSET ] >> PA_DRIVE_BIT_SENSOR_TYPE ) & 0x07 )//CG_Parameter.EEP_data[ PARAMETER_GENERAL ][ GENERAL_SENSOR_TYPE ]

#define DRIVE_TYPE_MOTOR_0              ( ( CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_AND_SENSOR_TYPE ] >> PA_DRIVE_BIT_DRIVE_MODE ) & 0x03 )
//#define DRIVE_TYPE_MOTOR_1              ( ( CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_AND_SENSOR_TYPE + PARAMETER_OFFSET ] >> PA_DRIVE_BIT_DRIVE_MODE ) & 0x03 )

#define MOTOR_FOLAR_NUM_MOTOR_0			CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_POLE_NUMBER ]
//#define MOTOR_FOLAR_NUM_MOTOR_1         CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_POLE_NUMBER + PARAMETER_OFFSET ]

#define ENCODER_RESOLUTION_MOTOR_0		CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_ENCODER_RESOLUTION ]
//#define ENCODER_RESOLUTION_MOTOR_1		CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_ENCODER_RESOLUTION + PARAMETER_OFFSET ]

#define POLAR_FACTOR_MOTOR_0			( MOTOR_FOLAR_NUM_MOTOR_0 < 2 ? 1 : MOTOR_FOLAR_NUM_MOTOR_0 / 2 )
//#define POLAR_FACTOR_MOTOR_1			( MOTOR_FOLAR_NUM_MOTOR_1 < 2 ? 1 : MOTOR_FOLAR_NUM_MOTOR_1 / 2 )

#define DIRECTION_DEFINE_MOTOR_0		CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_FORWARD_DIR ]		// 0
//#define DIRECTION_DEFINE_MOTOR_1		CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_FORWARD_DIR + PARAMETER_OFFSET ]

#define HALL_SEQUENCE_MOTOR_0           CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_HALL_SEQUENCE ]
//#define HALL_SEQUENCE_MOTOR_1           CG_Parameter.EEP_data[ PARAMETER_MOTOR ][ MOTOR_HALL_SEQUENCE + PARAMETER_OFFSET ]

#define RS232_BAUDRATE			115200L
#define RS232_ID				17

#define RELAY_ON_DELAY_TIME                     10      // 10= 100ms
#define RELAY_ON_MAX_TIME                       1000    // 1000 = 10s
#define POWER_ON_TIME_MAX                       1000    //  1000 = 100s
#define POWER_ON_TIME                           120//100      //  50 = 0.5s

#define CTRL_REF_BUSV_VOLTAGE   31113L

#define ENCODER_1_DIGIT_FILTER_CONST		64
#define IPM_ENCODER_2_DIGIT_FILTER_CONST	255	// IPM fault = GPIO10, Encoder 2 A = GPIO14, GPIO8 ~ 15 use the same setting
#define TRUMMAN_PASSWORD                    225

// QSEL_CONST
// 0: Synchronous
// 1: 3-sample qualification
// 2: 6-sample qualification
// 3: Asynchronous
#define ENCODER_QSEL_CONST					2
#define IPM_FAULT_QSEL_CONST				2

#define HALL_FILTER_CONST                   128

//

#define TEST_EEP_OPEN					1
#define TEST_IPM_FALUT_OPEN				1
#define TEST_HWOCP_OPEN					1
#define TEST_ENCODER_PROTECT_OPEN		1
#define TEST_MONITOR_DATA_OPEN			1
#define TEST_ENCODER_CN_ORDER_IS_EV     1
#define TEST_CTRL_IQ					1
#define TEST_CALCULATE_TIME_COST        1


//#define TEST_KP_SCALE_DOWN				1
#define TEST_CTRL_BUSV_USED             0

#define TEST_DUTY_UPDATE_FROM_ADC       0

#define TEST_DEBUG_JTAG_ENABLED         0
#define TEST_485_DEBUG_TOOL				0

#define TEST_CAN_MASTER                 0
#define TEST_HW_VER_B                   0

#define TEST_FAKE_HALL_SENSOR           0

//



/*===========================================================================================
    MD Macro and Settings
//==========================================================================================*/
#define POWERFREQ  		33				// Power management frequence
#define FW_VER_CHARS	28				// Total characters of firmware ver
#define PART_NUM_CHARS  28				// Total characters of part number
#define SN_CHARS		16 				// Total characters of S/N number


/*===========================================================================================
    MD Declaration
//==========================================================================================*/
//!  Bit field definition of system tick
#define TICK_1MS 	(1 << 1)
#define TICK_10MS 	(1 << 2)
#define TICK_100MS 	(1 << 3)
#define TICK_1S 	(1 << 4)
#define TICK_PFMS 	(1 << 5)

#define TICK_TIME	22000


enum{
    RS485_CAN_SEL_ALL   = 0,
    RS485_CAN_SEL_RS485,
    RS485_CAN_SEL_CAN,
    RS485_CAN_SEL_NUM
};

                                               
//! Main global variable structure
typedef struct{

    //uint8_t Driver_Mode;            // // 0 = drive 2 motors, 1 = drive 1 motor with 2 channels
    uint8_t Driver_Num;
        
    uint32_t SysTickCnt;			// Basic timer tick count of 1 ms
    uint32_t SysTick_BITF;			// Flag bit field of systick
	uint32_t PowerFreq;				// Power frequency of the power source ( currently using constant 60 Hz )

	//uint32_t TestData[14];			// Test Data variable. for debug use
	
	int32_t Code_Ver[5];			// Code version.
	uint8_t	FW_Ver[ FW_VER_CHARS * 2 ];	// Firmware ver character array
	uint8_t PN[ PART_NUM_CHARS * 2 ];   // Part number character array
	uint8_t HW_SN[ SN_CHARS * 2 ];		// Serial Number character array

	//
	uint8_t Motor_Sensor;
	uint8_t Drive_Method;

	uint8_t HW_Ver;
	//uint8_t IPM_FAULT_Select;


    uint8_t PowerRelay_Flag;                                // Indicate whether power relay is on.
    uint8_t PowerRelay_Ready2Open;                          // Indicate whether power relay is ready to open.
    int32_t Relay_On_Cnt;                                   // Count starts after busv relay on
    int32_t Pwr_On_Cnt;                                     // Count starts after power on
    //
	uint32_t Start_Cnt;

	uint32_t Test_cnt;
	//uint32_t Test_cnt2;
	//uint8_t Test_cnt3;

	uint32_t Test_tp1;
	uint32_t Test_tp2;
	uint32_t Test_time;

#if(TEST_CALCULATE_TIME_COST)

    uint32_t ADC_TP_New;
    uint32_t ADC_TP_Old;
    uint32_t ADC_Cost_Time;

    uint32_t Main_TP_New;
    uint32_t Main_TP_Old;
    uint32_t Main_Cost_Time;

    uint32_t Event1ms_TP_New;
    uint32_t Event1ms_TP_Old;
    uint32_t Event1ms_Cost_Time;

    uint32_t Event10ms_TP_New;
    uint32_t Event10ms_TP_Old;
    uint32_t Event10ms_Cost_Time;

    uint32_t Event100ms_TP_New;
    uint32_t Event100ms_TP_Old;
    uint32_t Event100ms_Cost_Time;

    uint32_t Event1000ms_TP_New;
    uint32_t Event1000ms_TP_Old;
    uint32_t Event1000ms_Cost_Time;
#endif

	uint32_t PwrOn_BITF;

	//
	uint8_t HallPH_State_M0;
	//uint8_t HallPH_State_M1;
	uint8_t DI_5V_State;
	uint8_t Vcc12V_Ctrl_State;
	uint8_t STA_LED_State;

	uint8_t STA_LED_State_RS485;
	uint8_t STA_LED_State_CAN;

	//uint8_t YH0_SEL_State;
	//uint8_t YH1_SEL_State;
    uint8_t RS485_CAN_SEL_State;
    uint8_t CAN_EN_State;

    uint32_t Comm_ID;

    //

#if(TEST_FAKE_HALL_SENSOR)
    uint32_t FakeHall_Timer;
    uint32_t FakeHall_Point;
    uint32_t FakeHall_TimeConst;

#endif

    //

	int64_t test_i1;
	int64_t test_i2;
	int64_t test_i3;

	//float test_f1;
	//float test_f2;
	//float test_f3;

}Struct_MD;


//! Code Ver defines
enum {
	CV_COM = 0,
	CV_HWE = 1,
	CV_FWE = 2,
	CV_HWV = 3,
	CV_FWV = 4
};


/*===========================================================================================
    Function Name    : variableInitial_MD
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw ( Modified by Gear.Feng@trumman.com.tw )
    Description      : Variable CG_MD initial
//==========================================================================================*/
void variableInitial_MD (void);


/*===========================================================================================
    Function Name    : SysTick_Set
    Input            : NULL
    Return           : Null
    Programmer       : 
    Description      : 22Mhz , 1ms*22M
//==========================================================================================*/
void SysTick_Set(uint32_t ticks);

/*===========================================================================================
    Function Name    : management_PowerRelay
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Decide if open power relay
//==========================================================================================*/
void management_PowerRelay( void );

/*===========================================================================================
    Function Name    : management_RGN_DAC
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Decide if turn on RGNEN
//==========================================================================================*/
void management_RGN_DAC( void );

#endif
