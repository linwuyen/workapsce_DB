/*===========================================================================================
    File Name       : Opearation_Mode.c
    Built Date      : 2014-08-29
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for opearation mode.
    =========================================================================================
    History         :
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"


	   volatile Struct_OPMode 					CG_OPMode;

extern volatile Struct_MD                       CG_MD;
//extern volatile Struct_BLDC_CTRL 				CG_BLDC_CTRL;
extern volatile Struct_BLDC_CTRL                CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL                CG_BLDC_CTRL_M1;
extern volatile Struct_ADC 						CG_ADC;
//extern volatile Struct_BLDC_Drive 				CG_BLDC_Drive;
extern volatile Struct_Parameter				CG_Parameter;
extern volatile Struct_HWEEP					CG_HWEEP;	/* HWEEP for hardware limit */
extern volatile Struct_Move						CG_Move;
extern volatile Struct_Encoder					CG_Encoder;
extern volatile Struct_IO_FUNC                  CG_IO_Func_M0;
//extern volatile Struct_IO_FUNC                  CG_IO_Func_M1;
extern volatile Struct_ComProtocol_01 			CG_ComProtocol_01;
extern volatile Struct_PI                       CG_PI;

const int32_t Const_AD_Max[ AD_MODE_Num ] = { 480 * THROTTLE_MULTIFY, 980 * THROTTLE_MULTIFY };

//! Function Call for OPMode functions
void ( *const opMode_Handler[ OP_MODE_NUM ] ) ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num ) =
{
	setOpMode_SingleOperation_0, setOpMode_SingleOperation_1, setOpMode_SingleOperation_2, setOpMode_SingleOperation_3, setOpMode_Multi_Drive_Lite,
	setOpMode_Throttle_Analog, setOpMode_Throttle_Pulse, setOpMode_Throttle_BV, setOpMode_SingleOperation_1,
	setOpMode_SingleOperation_1
};


/*===========================================================================================
    Function Name    : variableInitial_BasicOPMode
    Input            : basic_opmode
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_BasicOPMode( Struct_Basic_OPMode* basic_opmode )
{
    int i;
    basic_opmode->Mode_Num2 = 0;
    basic_opmode->Mode_Num1 = 0;
    basic_opmode->Image_VR_DIO = 0;
    basic_opmode->Digit_RPM_Abs = 0;

    //

    for( i = 0; i < EVR_BUFFER_SIZE; i ++ ){
        basic_opmode->EVR_Buff[i] = 0;
    }

    basic_opmode->EVR_Sum = 0;
    basic_opmode->EVR_Avg = 0;
    basic_opmode->EVR_Pointer = 0;
    basic_opmode->EVR_WeightFactor = 1;

}

/*===========================================================================================
    Function Name    : variableInitial_OPMode
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_OPMode( void )
{

	CG_OPMode.AD_Mode = 0;
	CG_OPMode.AD_Gain = 0;
	CG_OPMode.AD_Offset = 0;
	CG_OPMode.AD_Offset_Spd = 0;

	CG_OPMode.Throttle_Type = Throttle_SINGLE_ENDED;
	CG_OPMode.Throttle_Max = 0xFFFF;
	CG_OPMode.Throttle_Map = THROTTLE_50_PERCENT;
	CG_OPMode.Throttle_DeadBand = 0;
	CG_OPMode.Throttle_DeadBand_PA = 0;

	variableInitial_BasicOPMode( (Struct_Basic_OPMode*)&CG_OPMode.Motor_0 );
	//variableInitial_BasicOPMode( (Struct_Basic_OPMode*)&CG_OPMode.Motor_1 );

	// digid settings
	// M0
    CG_OPMode.Motor_0.Digit_Speed	    = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_DIGIT_SPD_0 ];
	CG_OPMode.Motor_0.Digit_Tq          = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_DIGIT_TQ_0 ];
    CG_OPMode.Motor_0.Digit_Duty        = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_DIGIT_DUTY_0 ];

    CG_OPMode.Motor_0.Digit_Acc_Time    = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_DIGIT_ACC_0 ];
    CG_OPMode.Motor_0.Digit_Dec_Time    = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_DIGIT_DEC_0 ];

    CG_OPMode.Motor_0.Digit_Acc_Buffer_Time = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_S_CURVE_ACC_0 ];
    CG_OPMode.Motor_0.Digit_Dec_Buffer_Time = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_S_CURVE_DEC_0 ];

    CG_OPMode.Motor_0.EVR               = (int32_t*)&CG_ADC.Value_Mapping[ ADC_Index_A0X ];
    CG_OPMode.Motor_0.PFM               = (int32_t*)&CG_PI.Channel[ PI_XH0 ].Image_VR_PFM;
    CG_OPMode.Motor_0.PWM               = (int32_t*)&CG_PI.Channel[ PI_XH0 ].Image_VR;
    CG_OPMode.Motor_0.PW                = (int32_t*)&CG_PI.Channel[ PI_XH0 ].Pulse_Width;

    // M1
    /*
    CG_OPMode.Motor_1.Digit_Speed       = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_DIGIT_SPD_0 + PARAMETER_OFFSET ];
    CG_OPMode.Motor_1.Digit_Tq          = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_DIGIT_TQ_0 + PARAMETER_OFFSET ];
    CG_OPMode.Motor_1.Digit_Duty        = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_DIGIT_DUTY_0 + PARAMETER_OFFSET ];

    CG_OPMode.Motor_1.Digit_Acc_Time    = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_DIGIT_ACC_0 + PARAMETER_OFFSET ];
    CG_OPMode.Motor_1.Digit_Dec_Time    = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_DIGIT_DEC_0 + PARAMETER_OFFSET ];

    CG_OPMode.Motor_1.Digit_Acc_Buffer_Time = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_S_CURVE_ACC_0 + PARAMETER_OFFSET ];
    CG_OPMode.Motor_1.Digit_Dec_Buffer_Time = ( int32_t* )&CG_Parameter.RAM_data[ PARAMETER_ACC_DEC ][ ACC_DEC_S_CURVE_DEC_0 + PARAMETER_OFFSET ];

    CG_OPMode.Motor_1.EVR               = (int32_t*)&CG_ADC.Value_Mapping[ ADC_Index_A1X ];
    CG_OPMode.Motor_1.PFM               = (int32_t*)&CG_PI.Channel[ PI_XH2 ].Image_VR_PFM;
    CG_OPMode.Motor_1.PWM               = (int32_t*)&CG_PI.Channel[ PI_XH2 ].Image_VR;
    CG_OPMode.Motor_1.PW                = (int32_t*)&CG_PI.Channel[ PI_XH2 ].Pulse_Width;
    */
}

/*===========================================================================================
    Function Name    : call_1ms_OPMode
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 1ms time up event of OPMode.
//==========================================================================================*/
void call_1ms_OPMode ( void )
{
    Struct_IO_FUNC          *io_func;
    Struct_Basic_OPMode     *op_mode;
    Struct_BLDC_CTRL        *bldc_ctrl;
    int16_t i;

    for( i = 0; i < CG_MD.Driver_Num; i++ ){

        if( i == 0 ){
            io_func = ( Struct_IO_FUNC* )&CG_IO_Func_M0;
            op_mode = ( Struct_Basic_OPMode* )&CG_OPMode.Motor_0;
            bldc_ctrl = ( Struct_BLDC_CTRL* )&CG_BLDC_CTRL_M0;
        }/*else{
            io_func = ( Struct_IO_FUNC* )&CG_IO_Func_M1;
            op_mode = ( Struct_Basic_OPMode* )&CG_OPMode.Motor_1;
            bldc_ctrl = ( Struct_BLDC_CTRL* )&CG_BLDC_CTRL_M1;
        }*/

        op_mode->M0_State = ( io_func->IOF_STAT_BITF[ SRC_ALL ] >> FUNC_M0 ) & 0x01;
        op_mode->M1_State = ( io_func->IOF_STAT_BITF[ SRC_ALL ] >> FUNC_M1 ) & 0x01;

        if( bldc_ctrl->E_ForwardReverse_Enable ){
            op_mode->Digit_Num = op_mode->M0_State;
        }else{
            op_mode->Digit_Num = op_mode->M1_State * 2 + op_mode->M0_State;
        }

        if( op_mode->Digit_Num >= DIGIT_SET_NUM ){
            op_mode->Digit_Num = 0;
        }

        op_mode->Digit_RPM_Abs = op_mode->Digit_Speed[ op_mode->Digit_Num ];

        switch( bldc_ctrl->Control_Mode ){
            case CTRL_OPENLOOP:
            case CTRL_CLOSELOOP_PID:
            default:
                opMode_Handler[ op_mode->Mode_Num2 ]( bldc_ctrl, op_mode->Digit_Num );
                break;
            case CTRL_POSITION:
                setOpMode_MultiCommand ( bldc_ctrl, op_mode->Digit_Num );
                break;
        }
    }

}

// =====================================================================
// Single Operation Setting
//======================================================================

/*===========================================================================================
    Function Name    : setOpMode_SingleOperation_0
    Input            : 1.bldc_ctrl
					   2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Int / EXT VR mode
//==========================================================================================*/
void setOpMode_SingleOperation_0 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    op_mode->Stop_Cmd_Src = SPEED_TAR_EXT_VR_SINGLE_ENDED;
    bldc_ctrl->VR_Speed = op_mode->EVR;

    if( bldc_ctrl->Control_Mode == CTRL_CLOSELOOP_PID ){

        op_mode->Target_RPM_Abs = calculate_AD_Input_to_Spd( 	*bldc_ctrl->VR_Speed,
                                                                CG_OPMode.AD_Offset,
                                                                CG_OPMode.AD_Offset_Spd,
                                                                CG_OPMode.Speed_Max,
                                                                CG_OPMode.Speed_Min,
                                                                CG_OPMode.AD_Gain );
    }else{

        op_mode->Target_Duty_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                        Const_AD_Max[ CG_OPMode.AD_Mode ],
                                                        CG_OPMode.AD_Offset,
                                                        CG_OPMode.Duty_Max,
                                                        CG_OPMode.Duty_Min,
                                                        THROTTLE_50_PERCENT,
                                                        Throttle_SINGLE_ENDED,
                                                        CG_OPMode.Throttle_DeadBand );

    }

#endif
	// ==

}

/*===========================================================================================
    Function Name    : setOpMode_SingleOperation_1
    Input            :
					   1.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Digital Mode
//==========================================================================================*/
void setOpMode_SingleOperation_1 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Stop_Cmd_Src = SPEED_TAR_DIO;
    bldc_ctrl->VR_Speed = (int32_t*)&op_mode->Image_VR_DIO;

	op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

	op_mode->Target_RPM_Abs 	= op_mode->Digit_Speed	[ digit_num ];
	op_mode->Target_Duty_Abs 	= bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( op_mode->Digit_Duty[ digit_num ] ) / DUTY_100_PERCENT;
#endif

}

/*===========================================================================================
    Function Name    : setOpMode_SingleOperation_2
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XH PFM
//==========================================================================================*/
void setOpMode_SingleOperation_2 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    op_mode->Stop_Cmd_Src = SPEED_TAR_PULSE_FREQ;
    bldc_ctrl->VR_Speed = op_mode->PFM;

    if( bldc_ctrl->Control_Mode == CTRL_CLOSELOOP_PID ){

        op_mode->Target_RPM_Abs = calculate_AD_Input_to_Spd(    *bldc_ctrl->VR_Speed,
                                                                CG_OPMode.AD_Offset,
                                                                CG_OPMode.AD_Offset_Spd,
                                                                CG_OPMode.Speed_Max,
                                                                CG_OPMode.Speed_Min,
                                                                CG_OPMode.AD_Gain );
    }else{

        op_mode->Target_Duty_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                        Const_AD_Max[ CG_OPMode.AD_Mode ],
                                                        CG_OPMode.AD_Offset,
                                                        CG_OPMode.Duty_Max,
                                                        CG_OPMode.Duty_Min,
                                                        THROTTLE_50_PERCENT,
                                                        Throttle_SINGLE_ENDED,
                                                        CG_OPMode.Throttle_DeadBand );

    }

#endif
    // ==

}

/*===========================================================================================
    Function Name    : setOpMode_SingleOperation_3
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : XH PWM
//==========================================================================================*/
void setOpMode_SingleOperation_3 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    op_mode->Stop_Cmd_Src = SPEED_TAR_PULSE_DUTY;
    bldc_ctrl->VR_Speed = op_mode->PWM;

    if( bldc_ctrl->Control_Mode == CTRL_CLOSELOOP_PID ){

        op_mode->Target_RPM_Abs = calculate_AD_Input_to_Spd(    *bldc_ctrl->VR_Speed,
                                                                CG_OPMode.AD_Offset,
                                                                CG_OPMode.AD_Offset_Spd,
                                                                CG_OPMode.Speed_Max,
                                                                CG_OPMode.Speed_Min,
                                                                CG_OPMode.AD_Gain );
    }else{

        op_mode->Target_Duty_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                        Const_AD_Max[ CG_OPMode.AD_Mode ],
                                                        CG_OPMode.AD_Offset,
                                                        CG_OPMode.Duty_Max,
                                                        CG_OPMode.Duty_Min,
                                                        THROTTLE_50_PERCENT,
                                                        Throttle_SINGLE_ENDED,
                                                        CG_OPMode.Throttle_DeadBand );

    }

#endif
    // ==

}

/*===========================================================================================
    Function Name    : setOpMode_Multi_Drive_Lite
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Multi_Drive_Lite ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
    uint32_t rpm;
    uint32_t duty;
    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Stop_Cmd_Src = SPEED_TAR_DIO;

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    rpm = bldc_ctrl->TSPD;
    if( rpm > 0 && rpm < LIMIT_SPEED_RPM ){
        rpm = LIMIT_SPEED_RPM;
    }

    op_mode->Target_RPM_Abs  = rpm;

    duty = bldc_ctrl->TSPD;
    if( duty >= DUTY_100_PERCENT ){
        duty = DUTY_100_PERCENT;
    }
    op_mode->Target_Duty_Abs   = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * duty / DUTY_100_PERCENT;

    // ==

}

/*===========================================================================================
    Function Name    : setOpMode_Throttle_Analog
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Throttle_Analog ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    op_mode->Stop_Cmd_Src = CG_OPMode.Throttle_Type;
    bldc_ctrl->VR_Speed = op_mode->EVR;

    if( bldc_ctrl->Control_Mode == CTRL_CLOSELOOP_PID ){

        op_mode->Target_RPM_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                      CG_OPMode.Throttle_Max,
                                                      CG_OPMode.AD_Offset,
                                                      op_mode->Digit_Speed[ digit_num ],
                                                      CG_OPMode.Speed_Min,
                                                      CG_OPMode.Throttle_Map,
                                                      CG_OPMode.Throttle_Type,
                                                      CG_OPMode.Throttle_DeadBand );
    }else{

        op_mode->Target_Duty_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                        CG_OPMode.Throttle_Max,
                                                        CG_OPMode.AD_Offset,
                                                        bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( op_mode->Digit_Duty[ digit_num ] ) / DUTY_100_PERCENT,
                                                        CG_OPMode.Duty_Min,
                                                        CG_OPMode.Throttle_Map,
                                                        CG_OPMode.Throttle_Type,
                                                        CG_OPMode.Throttle_DeadBand );

    }

#endif
    // ==

}

/*===========================================================================================
    Function Name    : setOpMode_Throttle_Pulse
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Throttle_Pulse ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    op_mode->Stop_Cmd_Src = CG_OPMode.Throttle_Type;

    op_mode->PW_Throttle = calibration( *op_mode->PW,
                                        CG_OPMode.PW_Min, 0,
                                        CG_OPMode.PW_Max, PI_DUTY_RESOLUTION );

    bldc_ctrl->VR_Speed = ( int32_t* )&op_mode->PW_Throttle;

    if( bldc_ctrl->Control_Mode == CTRL_CLOSELOOP_PID ){

        op_mode->Target_RPM_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                      CG_OPMode.Throttle_Max,
                                                      CG_OPMode.AD_Offset,
                                                      op_mode->Digit_Speed[ digit_num ],
                                                      CG_OPMode.Speed_Min,
                                                      CG_OPMode.Throttle_Map,
                                                      CG_OPMode.Throttle_Type,
                                                      CG_OPMode.Throttle_DeadBand );
    }else{

        op_mode->Target_Duty_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                        CG_OPMode.Throttle_Max,
                                                        CG_OPMode.AD_Offset,
                                                        bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( op_mode->Digit_Duty[ digit_num ] ) / DUTY_100_PERCENT,
                                                        CG_OPMode.Duty_Min,
                                                        CG_OPMode.Throttle_Map,
                                                        CG_OPMode.Throttle_Type,
                                                        CG_OPMode.Throttle_DeadBand );

    }

#endif
    // ==

}

/*===========================================================================================
    Function Name    : setOpMode_Throttle_BV
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setOpMode_Throttle_BV ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)
    int32_t *spd_data;
    int32_t *duty_data;
    uint32_t duty_max_pa;
    uint32_t duty_min_pa;
    uint32_t duty_max;
    uint32_t duty_min;
    uint32_t spd_max;
    uint32_t spd_min;

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    if( digit_num < 1 ){
        spd_data = (int32_t*) &CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_VR_MAX_CW_0 ];
        duty_data = (int32_t*) &CG_Parameter.RAM_data[ PARAMETER_SPEED ][ DUTY_VR_MAX_CW_0 ];
    }else{
        digit_num = 1;
        spd_data = (int32_t*) &CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_VR_MAX_CW_1 ];
        duty_data = (int32_t*) &CG_Parameter.RAM_data[ PARAMETER_SPEED ][ DUTY_VR_MAX_CW_1 ];
    }

    enum{
        MAX_CW = 0,
        MIN_CW = 1,
        MAX_CCW = 2,
        MIN_CCW = 3
    };

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    op_mode->Stop_Cmd_Src = CG_OPMode.Throttle_Type;
    bldc_ctrl->VR_Speed = op_mode->EVR;

    //
    if( CG_OPMode.Throttle_Restraint_Mode == THROTTLE_RESTRAINT_MODE_DISABLE ){
        CG_OPMode.Scale_Factor = PERCENTAGE_100;
    }else{
        CG_OPMode.Scale_Factor = calculate_Throttle( CG_ADC.Value_Mapping[ ADC_Index_A1X ],
                                                    CG_OPMode.Throttle_Max,
                                                    CG_OPMode.AD_Offset,
                                                    CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_SPEED_SCALE_MAX ],
                                                    CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_SPEED_SCALE_MIN ],
                                                    THROTTLE_50_PERCENT,
                                                    CG_OPMode.Throttle_Restraint_Mode - 1,
                                                    CG_OPMode.Throttle_DeadBand );
    }


    if( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_DIR ] == DIR_CW ){
        spd_max = spd_data[ MAX_CW ];
        spd_min = spd_data[ MIN_CW ];

        duty_max_pa = duty_data[ MAX_CW ];
        duty_min_pa = duty_data[ MIN_CW ];

        //duty_max = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( duty_data[ MAX_CW ] ) / DUTY_100_PERCENT
        //duty_min = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( duty_data[ MIN_CW ] ) / DUTY_100_PERCENT

    }else{
        spd_max = spd_data[ MAX_CCW ];
        spd_min = spd_data[ MIN_CCW ];

        duty_max_pa = duty_data[ MAX_CCW ];
        duty_min_pa = duty_data[ MIN_CCW ];
        //duty_max = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( duty_data[ MAX_CW ] ) / DUTY_100_PERCENT
        //duty_min = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( duty_data[ MIN_CW ] ) / DUTY_100_PERCENT
    }


    //

    if( bldc_ctrl->Control_Mode == CTRL_CLOSELOOP_PID ){

        CG_OPMode.Scaled_Limit_RPM_max = spd_min + ( spd_max - spd_min ) * CG_OPMode.Scale_Factor / SCALE_100_PERCENT;

        op_mode->Target_RPM_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                      CG_OPMode.Throttle_Max,
                                                      CG_OPMode.AD_Offset,
                                                      CG_OPMode.Scaled_Limit_RPM_max,
                                                      spd_min,
                                                      CG_OPMode.Throttle_Map,
                                                      CG_OPMode.Throttle_Type,
                                                      CG_OPMode.Throttle_DeadBand );
    }else{

        duty_max = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( duty_max_pa ) / DUTY_100_PERCENT;
        duty_min = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( duty_min_pa ) / DUTY_100_PERCENT;

        CG_OPMode.Scaled_Limit_Duty_max = duty_min + ( duty_max - duty_min ) * CG_OPMode.Scale_Factor / SCALE_100_PERCENT;

        op_mode->Target_Duty_Abs = calculate_Throttle( *bldc_ctrl->VR_Speed,
                                                        CG_OPMode.Throttle_Max,
                                                        CG_OPMode.AD_Offset,
                                                        CG_OPMode.Scaled_Limit_Duty_max,
                                                        duty_min,
                                                        CG_OPMode.Throttle_Map,
                                                        CG_OPMode.Throttle_Type,
                                                        CG_OPMode.Throttle_DeadBand );

    }

#endif
    // ==

}

/*===========================================================================================
    Function Name    : setOpMode_Special_0
    Input            : 1.bldc_ctrl
                       2.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : For Assisted Bicycle Application
//==========================================================================================*/
void setOpMode_Special_0 ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;
    uint16_t new_value = *op_mode->EVR;
    uint16_t old_value = op_mode->EVR_Buff[ op_mode->EVR_Pointer ];
    float factor;
    int32_t avg;
    static float evr_smooth = 0.0;

    op_mode->Stop_Cmd_Src = SPEED_TAR_DIO;
    bldc_ctrl->VR_Speed = (int32_t*)&op_mode->Image_VR_DIO;

    op_mode->Target_RPM_Abs     = op_mode->Digit_Speed  [ digit_num ];
    op_mode->Target_Duty_Abs    = bldc_ctrl->Drive_Ptr->Duty_Min_Abs + bldc_ctrl->Drive_Ptr->Duty_Resolution * ( op_mode->Digit_Duty[ digit_num ] ) / DUTY_100_PERCENT;

    //

    op_mode->EVR_Sum -= old_value;
    op_mode->EVR_Buff[ op_mode->EVR_Pointer ] = new_value;
    op_mode->EVR_Sum += new_value;

    if( ++op_mode->EVR_Pointer >= EVR_BUFFER_SIZE ){
        op_mode->EVR_Pointer = 0;
    }

    if( op_mode->EVR_WeightFactor == 0 ){
        op_mode->EVR_Avg = op_mode->EVR_Sum >> EVR_BUFFER_SIZE_BIT;
    }else{

        avg = (*op_mode->EVR);
        if( evr_smooth < avg ){
            evr_smooth = avg;
        }else{
            //op_mode->EVR_Avg = op_mode->EVR_Sum >> EVR_BUFFER_SIZE_BIT;
            /*
            factor = ( 1L << op_mode->EVR_WeightFactor ) - 1;
            op_mode->EVR_Factor = factor;
            op_mode->EVR_Avg = ( op_mode->EVR_Avg * factor + (*op_mode->EVR) ) >> op_mode->EVR_WeightFactor;
            */

            //avg = op_mode->EVR_Sum >> EVR_BUFFER_SIZE_BIT;
            factor = op_mode->EVR_WeightFactor - 1;
            evr_smooth = ( evr_smooth * factor + (float)avg ) / (float)op_mode->EVR_WeightFactor;
            //evr_smooth = ( evr_smooth * 32767.0 + (float)avg ) / 32768.0;

        }

        op_mode->EVR_Avg = evr_smooth;
    }

    //

    if( bldc_ctrl->PI_Ptr->DirCnt > 1 ){
        op_mode->Torque_Limit = calculate_Throttle( op_mode->EVR_Avg,
                                                    CG_OPMode.Throttle_Max,
                                                    CG_OPMode.AD_Offset,
                                                    SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT,
                                                    0,
                                                    THROTTLE_50_PERCENT,
                                                    Throttle_SINGLE_ENDED,
                                                    CG_OPMode.Throttle_DeadBand );
        /*
        if( CG_MD.Driver_Mode == PA_DRIVER_MODE_2SMALL_MOTOR ){
            if( op_mode->Torque_Limit > CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] ){
                op_mode->Torque_Limit = CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ];
            }
        }else{
            if( op_mode->Torque_Limit > CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] * 2 ){
                op_mode->Torque_Limit = CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] * 2;
            }
        }*/
        if( op_mode->Torque_Limit > CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] * TORQUE_J06TOI04_GAIN ){
            op_mode->Torque_Limit = CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] * TORQUE_J06TOI04_GAIN;
        }

    }else{
        op_mode->Torque_Limit = 0;
        //op_mode->Target_RPM_Abs = 0;
        //op_mode->Target_Duty_Abs = 0;
    }

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];



}

/*===========================================================================================
    Function Name    : setOpMode_MultiCommand
    Input            :
                       1.digit_num: digit_num
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Digital Mode
//==========================================================================================*/
void setOpMode_MultiCommand ( Struct_BLDC_CTRL *bldc_ctrl, uint32_t digit_num )
{
#if(1)

    Struct_Basic_OPMode *op_mode = bldc_ctrl->OpMode_Ptr;

    op_mode->Stop_Cmd_Src = SPEED_TAR_DIO;
    bldc_ctrl->VR_Speed = (int32_t*)&op_mode->Image_VR_DIO;

    op_mode->Torque_Limit = SHUNT_I_FWP * ( op_mode->Digit_Tq [ digit_num ] ) / TQ_100_PERCENT;

    op_mode->Acc_Time = op_mode->Digit_Acc_Time [ digit_num ];
    op_mode->Dec_Time = op_mode->Digit_Dec_Time [ digit_num ];

    op_mode->Acc_Buffer_Time = op_mode->Digit_Acc_Buffer_Time[ digit_num ];
    op_mode->Dec_Buffer_Time = op_mode->Digit_Dec_Buffer_Time[ digit_num ];

    op_mode->Target_RPM_Abs     = bldc_ctrl->TSPD;
    op_mode->Target_Duty_Abs    = 0;
#endif

}


/************************** <END OF FILE> *****************************************/


