/*===========================================================================================
    File Name       : HWEEP_Setting.c
	Built Date      : 2014-07-29
    Version         : V1.00a 
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : 1. This file provides the functions of accessing HWEEP to the predefined ram.
	
	Module required:  - EEP_Setting: For EEP Data access.
					  - LPC11XX_I2C: Used by EEP_Setting for I2C BUS access.
    =========================================================================================
    History         : 2014-07-29 Perlimary version.  ( by Gear )
				      2014-09-09 2k-bits hweep method added.
					  2014-12-02 Add functions to write HW eep.
								 Add variables to read HW eep Info.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_HWEEP	CG_HWEEP;
extern volatile Struct_MD 									CG_MD;
extern volatile Struct_I2C                                  CG_I2C;

/*===========================================================================================
    Function Name    : readTotalHWEEP
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : readTotalHWEEP
//==========================================================================================*/
void readTotalHWEEP( void )
{
#if( TEST_EEP_OPEN )
	uint32_t i;
	uint8_t dummyData[32];	// HWEEP read buffer.

	readHWEEP( (uint8_t*)&CG_MD.Code_Ver[ CV_HWE ],(uint8_t*)&CG_MD.Code_Ver[ CV_HWV ], (uint8_t*)&CG_MD.PN, PART_NUM_CHARS, (uint8_t*)&CG_MD.HW_SN, SN_CHARS );
	readHW_Ver ( ( Struct_HWEEP* )&CG_HWEEP );

	for( i = 0; i < 80; i++ ){
		readData_I2C( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B3_ADDRESS + i * 2, (uint8_t*)dummyData, 2 );
		CG_HWEEP.HW_Info[ i ] = dummyData[0] * 256 + dummyData[1];
	}
#endif

}

 
/*===========================================================================================
    Function Name    : readHWEEP
    Input            : 1. *hweep_ver: hweep_ver ram
					   2. *pn_ver: part number ver
					   3. *pn: part number ram
					   4. pn_chars: number of chars of part number
					   5. *sn: SN ram
					   6. sn_chars: number of chars of SN
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Read data from HW EEP.
					   Include: HWEEP_CODE_VER, PART_NUM_CODE_VER, Part Number, S/N,
								1 byte Info, 2 byte Info
//==========================================================================================*/
void readHWEEP( uint8_t *hweep_ver, uint8_t *pn_ver, uint8_t *pn, const uint8_t pn_chars, uint8_t *sn, const uint8_t sn_chars )
{
	uint8_t dummy_data[32];
	uint8_t i=0;

    // HWEEP ver and PN ver
	readData_I2C( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 0, dummy_data, 2 );

	if( ( CG_MD.PwrOn_BITF >> PWR_ON_I2C_DETECT_BIT ) & 0x01 ){
	    CG_MD.PwrOn_BITF &= ~( 1UL << PWR_ON_I2C_DETECT_BIT );
	}

	*hweep_ver = dummy_data[0];
	*pn_ver	   = dummy_data[1];

	readData_I2C( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 2, dummy_data, PART_NUM_CHARS );
	for ( i = 0; i < PART_NUM_CHARS; i++ ){
		*(pn++) =  dummy_data[ i ];
	}
	
	readData_I2C( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B2_ADDRESS, dummy_data, SN_CHARS );
	for ( i = 0; i < SN_CHARS; i++ ){
		*(sn++) =  dummy_data[ i ];
	}
}

/*===========================================================================================
    Function Name    : writeHWEEP_CV
    Input            : 1. data: data to write HWEEP.
					   2. addr: communication address to determine HWEEP_CV(1) or PN_CV(3)
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  HWEEP_CODE_VER, PART_NUM_CODE_VER
//==========================================================================================*/
uint8_t writeHWEEP_CV ( const uint8_t data, const uint8_t addr )
{
	uint8_t result = 1;
	uint8_t dummyData[2];	// HWEEP data dummy buffer.
	
	//dummyData[0] = data % 256;
	dummyData[0] = data;
				
	if( addr == 1 ){
		result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 0, &dummyData[ 0 ],  1 );
	}else{
		result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 1, &dummyData[ 0 ],  1 );
	}
	
	return (result);

}

/*===========================================================================================
    Function Name    : writeHWEEP_PN
    Input            : 1. data: data to write HWEEP.
					   2. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  PN
//==========================================================================================*/
uint8_t writeHWEEP_PN ( const uint8_t *data, const uint8_t data_num )
{
	uint8_t result = 1;
	uint8_t i;
	uint8_t dummyData[32];	// HWEEP data dummy buffer.

	for( i = 0; i < 8; i++ ){
					
		if( i < data_num ){
			dummyData[ i * 4 + 0 ] = data[ i * 4 ];
			dummyData[ i * 4 + 1 ] = data[ i * 4 + 1 ];
			dummyData[ i * 4 + 2 ] = data[ i * 4 + 2 ];
			dummyData[ i * 4 + 3 ] = data[ i * 4 + 3 ];
		}else{
			dummyData[ i * 4 + 0 ] = 0;
			dummyData[ i * 4 + 1 ] = 0;
			dummyData[ i * 4 + 2 ] = 0;
			dummyData[ i * 4 + 3 ] = 0;
		}
		
	}
	
	result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 8 * 0 + 2, &dummyData[ 0 ],  6 );
	result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 8 * 1,	 	&dummyData[ 6 ],  8 );
	result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 8 * 2, 	&dummyData[ 14 ], 8 );
	result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B1_ADDRESS + 8 * 3,		&dummyData[ 22 ], 8 );
	
	return (result);

}

/*===========================================================================================
    Function Name    : writeHWEEP_SN
    Input            : 1. data: data to write HWEEP.
					   2. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  SN
//==========================================================================================*/
uint8_t writeHWEEP_SN ( const uint8_t *data, const uint8_t data_num )
{
	uint8_t result = 1;
	uint8_t i;
	uint8_t dummyData[32];	// HWEEP data dummy buffer.
	
	for( i = 0; i < 8; i++ ){
					
		if( i < data_num ){
			dummyData[ i * 4 + 0 ] = data[ i * 4 ];
			dummyData[ i * 4 + 1 ] = data[ i * 4 + 1 ];
			dummyData[ i * 4 + 2 ] = data[ i * 4 + 2 ];
			dummyData[ i * 4 + 3 ] = data[ i * 4 + 3 ];
		}else{
			dummyData[ i * 4 + 0 ] = 0;
			dummyData[ i * 4 + 1 ] = 0;
			dummyData[ i * 4 + 2 ] = 0;
			dummyData[ i * 4 + 3 ] = 0;
		}
		
	}
	
	result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B2_ADDRESS + 8 * 0, &dummyData[ 0 ],  8 );
	result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B2_ADDRESS + 8 * 1, &dummyData[ 8 ],  8 );
	//result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B2_ADDRESS + 8 * 2, &dummyData[ 16 ], 8 );
	//result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HW_EEP_B2_ADDRESS + 8 * 3, &dummyData[ 24 ], 8 );
	
	return (result);

}

/*===========================================================================================
    Function Name    : writeHW_Ver
    Input            : 1. data: data to write HWEEP.
					   2. addr: communication address
					   3. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t writeHW_Ver ( const int32_t *data, const uint8_t addr, const uint8_t data_num )
{
	uint8_t result = 1;
	uint8_t i;
	uint8_t dummyData[ HW_VER_LENGTH ];	// HWEEP data dummy buffer.

	if( addr + data_num <= HW_VER_LENGTH && data_num >= 1 ){
		for( i = 0; i < data_num; i++ ){
			dummyData[ i ] = MOD( data[ i ], 256 );
		}
		result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, HWEEP_HWVER_ADDRESS + addr, &dummyData[ 0 ],  data_num );
	}else{
		result = 0;
	}

	return (result);
}

/*===========================================================================================
    Function Name    : readHW_Ver
    Input            : 1. hweep
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void readHW_Ver ( Struct_HWEEP *hweep )
{
	uint8_t dummy_data[ HW_VER_LENGTH ];
	readData_I2C( HW_EEP_ADDRESS, HW_EEP_TYPE, HWEEP_HWVER_ADDRESS, dummy_data, HW_VER_LENGTH );
	hweep->HW_Ver[0] = dummy_data[0];
}

/*===========================================================================================
    Function Name    : writeHWEEP_Info
    Input            : 1. data: data to write HWEEP. (2 byte data)
					   2. addr: communication address
					   3. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  Info
//==========================================================================================*/
uint8_t writeHWEEP_Info ( const int32_t *data, const uint8_t addr, const uint8_t data_num )
{
	uint8_t result = 1;
	uint8_t i;
	uint8_t dummyData[32];	// HWEEP data dummy buffer.
	uint8_t offset_address;
	
	for( i = 0; i < data_num; i++ ){
		dummyData[ i * 2 + 0 ] = data[ i ] / 256;
		//dummyData[ i * 2 + 1 ] = data[ i ] % 256;	
		dummyData[ i * 2 + 1 ] = MOD( data[ i ], 256 );
	}
	
	offset_address = addr * 2 + HW_EEP_B3_ADDRESS;
	result &= writeAndCheckDataEEP( HW_EEP_ADDRESS, HW_EEP_TYPE, offset_address + 8 * 0, &dummyData[ 0 ],  data_num * 2 );
	
	return (result);
}

/*===========================================================================================
    Function Name    : hweep_WatchUpdate
    Input            : 1. page_sel: page select
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update HWEEP Watch data
//==========================================================================================*/
void hweep_WatchUpdate ( const int32_t page_sel )
{
	if ( page_sel == 0 ) {

		CG_HWEEP.WatchData[0] = 0;	// Reserved
		CG_HWEEP.WatchData[1] = 0;  // Reserved
		CG_HWEEP.WatchData[2] = CG_HWEEP.HW_Info[ HWEEP_IDX_BUSV1 ] & 0xFFFF;
		CG_HWEEP.WatchData[3] = CG_HWEEP.HW_Info[ HWEEP_IDX_BUSV2 ] & 0xFFFF;
		CG_HWEEP.WatchData[4] = CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_U_H ] & 0xFFFF;
		CG_HWEEP.WatchData[5] = CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_V_H ] & 0xFFFF;
		CG_HWEEP.WatchData[6] = CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_W_H ] & 0xFFFF;
		CG_HWEEP.WatchData[7] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD0_L0 ] & 0xFFFF;
		CG_HWEEP.WatchData[8] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD0_H0 ] & 0xFFFF;
		CG_HWEEP.WatchData[9] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD0_L1 ] & 0xFFFF;
		CG_HWEEP.WatchData[10] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD0_H1 ] & 0xFFFF;
		CG_HWEEP.WatchData[11] = CG_HWEEP.HW_Info[ HWEEP_IDX_HALL_FILTER ] & 0xFFFF;	// Reserved
		CG_HWEEP.WatchData[12] = CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_TYPE ] & 0xFFFF;	// Reserved
		CG_HWEEP.WatchData[13] = CG_HWEEP.HW_Info[ HWEEP_IDX_DEAD_TIME ] & 0xFFFF;	// Reserved
		CG_HWEEP.WatchData[14] = CG_HWEEP.HW_Info[ HWEEP_IDX_PWM_FREQUENCE ] & 0xFFFF; 	// Reserved
		CG_HWEEP.WatchData[15] = CG_HWEEP.HW_Info[ HWEEP_IDX_DRIVE_TYPE ] & 0xFFFF;
	
	}else if( page_sel == 1 ) {

		CG_HWEEP.WatchData[0] = 0;	// Reserved
		CG_HWEEP.WatchData[1] = 0;  // Reserved
		CG_HWEEP.WatchData[2] = CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_VALUE ] & 0xFFFF;
		CG_HWEEP.WatchData[3] = CG_HWEEP.HW_Info[ HWEEP_IDX_MOSOT_REC ] & 0xFFFF;
		CG_HWEEP.WatchData[4] = CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_U_OFFSET ] & 0xFFFF;
		CG_HWEEP.WatchData[5] = CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_V_OFFSET ] & 0xFFFF;
		CG_HWEEP.WatchData[6] = CG_HWEEP.HW_Info[ HWEEP_IDX_M0_SHUNT_I_W_OFFSET ] & 0xFFFF;
		CG_HWEEP.WatchData[7] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD1_L0 ] & 0xFFFF;
		CG_HWEEP.WatchData[8] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD1_H0 ] & 0xFFFF;
		CG_HWEEP.WatchData[9] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD1_L1 ] & 0xFFFF;
		CG_HWEEP.WatchData[10] = CG_HWEEP.HW_Info[ HWEEP_IDX_AD1_H1 ] & 0xFFFF;
		CG_HWEEP.WatchData[11] = CG_HWEEP.HW_Info[ HWEEP_IDX_PGA_INDEX ] & 0xFFFF;
		CG_HWEEP.WatchData[12] = CG_HWEEP.HW_Info[ HWEEP_IDX_CTRIP_PRESCALE ] & 0xFFFF;
		CG_HWEEP.WatchData[13] = CG_HWEEP.HW_Info[ HWEEP_IDX_NEG_HWP_EN ] & 0xFFFF;
		CG_HWEEP.WatchData[14] = CG_HWEEP.HW_Ver[0] & 0xFFFF;
		CG_HWEEP.WatchData[15] = 0;

	} else {

		CG_HWEEP.WatchData[0] = 0;	// Reserved
		CG_HWEEP.WatchData[1] = 0;  // Reserved
		CG_HWEEP.WatchData[2] = CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_MAX ] & 0xFFFF;
		CG_HWEEP.WatchData[3] = CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_OB ] & 0xFFFF;
		CG_HWEEP.WatchData[4] = CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_RS ] & 0xFFFF;
		CG_HWEEP.WatchData[5] = CG_HWEEP.HW_Info[ HWEEP_IDX_PWR_P_GAIN ] & 0xFFFF;
		CG_HWEEP.WatchData[6] = CG_HWEEP.HW_Info[ HWEEP_IDX_I_MAX ] & 0xFFFF;
		CG_HWEEP.WatchData[7] = CG_HWEEP.HW_Info[ HWEEP_IDX_I_OB ] & 0xFFFF;
		CG_HWEEP.WatchData[8] = CG_HWEEP.HW_Info[ HWEEP_IDX_I_RS ] & 0xFFFF;
		CG_HWEEP.WatchData[9] = CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_MAX ] & 0xFFFF;
		CG_HWEEP.WatchData[10] = CG_HWEEP.HW_Info[ HWEEP_IDX_TQ_RATE ] & 0xFFFF;
		CG_HWEEP.WatchData[11] = CG_HWEEP.HW_Info[ HWEEP_IDX_HWP ] & 0xFFFF;
		CG_HWEEP.WatchData[12] = CG_HWEEP.HW_Info[ HWEEP_IDX_UVP ] & 0xFFFF;
		CG_HWEEP.WatchData[13] = CG_HWEEP.HW_Info[ HWEEP_IDX_UVPR ] & 0xFFFF;
		CG_HWEEP.WatchData[14] = CG_HWEEP.HW_Info[ HWEEP_IDX_OVP ] & 0xFFFF;
		CG_HWEEP.WatchData[15] = CG_HWEEP.HW_Info[ HWEEP_IDX_OVPR ] & 0xFFFF;
	
	}

	CG_HWEEP.WatchData[0 + 16 ] = 0;  // Reserved
    CG_HWEEP.WatchData[1 + 16 ] = 0;  // Reserved
    CG_HWEEP.WatchData[2 + 16 ] = 0;
    CG_HWEEP.WatchData[3 + 16 ] = 0;
    CG_HWEEP.WatchData[4 + 16 ] = 0;
    CG_HWEEP.WatchData[5 + 16 ] = 0;
    CG_HWEEP.WatchData[6 + 16 ] = 0;
    CG_HWEEP.WatchData[7 + 16 ] = 0;
    CG_HWEEP.WatchData[8 + 16 ] = 0;
    CG_HWEEP.WatchData[9 + 16 ] = 0;
    CG_HWEEP.WatchData[10 + 16 ] = 0;
    CG_HWEEP.WatchData[11 + 16 ] = 0;    // Reserved
    CG_HWEEP.WatchData[12 + 16 ] = 0; // Reserved
    CG_HWEEP.WatchData[13 + 16 ] = 0;  // Reserved
    CG_HWEEP.WatchData[14 + 16 ] = 0;  // Reserved
    CG_HWEEP.WatchData[15 + 16 ] = 0;

}

