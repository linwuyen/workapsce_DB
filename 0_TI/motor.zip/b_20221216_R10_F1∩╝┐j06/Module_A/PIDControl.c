/*===========================================================================================

    File Name       : PIDControl.c

    Version         : V1_00_10_a

    Built Date      : 2017/10/02

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */
#include "IncludeFiles.h"
//#include <PIDControl.h>


/*===========================================================================================
    Function Name    : setupInitial_PID
    Input            : 1.pid
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_PID ( Struct_PID* pid )
{
	pid->Error_Last = 0;
	pid->P_Term_Rest = 0;
	pid->I_Term_Rest = 0;
	pid->D_Term_Rest = 0;
	pid->Output_I_Term = 0;
	pid->Output = 0;

}


/************************** <END OF FILE> *****************************************/
