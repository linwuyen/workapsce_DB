/*===========================================================================================
    File Name       : IO.c  
    Built Date      : 2012-12-27
	Version         : V1.02a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file provides the IO state function system of the driver.
	
	Module required:  - IO_Func: For IO Function defeines.
	
    =========================================================================================
    History         : 2012-12-27 Perlimary version.
	                  2013-01-04 Update from B01_VDC_V1_06_pa_2012_1213
						- Fixed a bug of not clear DIn_Func_STAT_ASM_BITF when change io_func without setting it to NoAction first.
						- OT type ioSTAT_SET_OT_XXX functions added to solve the active state issue.
						- Fixed a bug of IO polling check. ( mapping index wrong ).
					  2013-03-29 OT type combined.
                      2014-08-29  v1.01a (R8): Porting to D01. Integrate Input and Output.
                      2015-11-11 V1.02a (R8): Add bit field set and clear public function. Increase DIn_Func_Xn_Mask_BITF[1]
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_IO								CG_IO;
extern volatile Struct_GPIO 					CG_GPIO;
extern volatile Struct_MD 						CG_MD;

const uint8_t const_funcStat_Index[ 4 ] = { 0, 0, 1, 1 };		 			// the minor index of io function stat bit field.


// Programmable Output Mechanism Function call
void ( *const  OutputYn_action[ 2 ][ OUTPUT_NUM + 1 ] ) ( void ) = 
{
	{ f_Y_NC, f_Y0_OFF, f_Y1_OFF, f_Y2_OFF, f_Y3_OFF, f_Y4_OFF, f_Y5_OFF, f_Y6_OFF },
	{ f_Y_NC, f_Y0_ON , f_Y1_ON,  f_Y2_ON , f_Y3_ON,  f_Y4_ON , f_Y5_ON,  f_Y6_ON  }
};

void f_Y_NC( void )
{
}

// On
void f_Y0_ON( void )
{
	IO_Y0_ON;
	//CG_GPIO.Yn_State_BITF |= ( 1 << 0 );
	CG_GPIO.Yn_State_BITF_MCU |= ( 1 << 0 );
	//CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
	CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y1_ON( void )
{
    IO_Y1_ON;

	//CG_GPIO.Yn_State_BITF |= ( 1 << 1 );
    CG_GPIO.Yn_State_BITF_MCU |= ( 1 << 1 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}  

void f_Y2_ON( void )
{
    IO_Y2_ON;
    //CG_GPIO.Yn_State_BITF |= ( 1 << 2 );
    CG_GPIO.Yn_State_BITF_MCU |= ( 1 << 2 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y3_ON( void )
{
    if( CG_MD.HW_Ver == HW_VER_A ){
        IO_Y3_ON_A;
    }else{
        IO_Y3_ON_B;
    }
    //CG_GPIO.Yn_State_BITF |= ( 1 << 3 );
    CG_GPIO.Yn_State_BITF_MCU |= ( 1 << 3 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y4_ON( void )
{
    //CG_GPIO.Yn_State_BITF |= ( 1 << 4 );
    // Bit6 = BR1, Bit7 = BR2, different logic from other output
    CG_GPIO.Out1_PwmTimer_Flag = YES;

    EALLOW;

    if( CG_MD.HW_Ver == HW_VER_A ){
        IO_Y4_ON_A;

        if( CG_GPIO.Out1_Pwm_Flag == NO ){
            PWM_Y4_OFF_A;
        }else{
            PWM_Y4_ON_A;
        }
    }else{
        IO_Y4_ON_B;

        if( CG_GPIO.Out1_Pwm_Flag == NO ){
            PWM_Y4_OFF_B;
        }else{
            PWM_Y4_ON_B;
        }
    }

    EDIS;

    CG_GPIO.Yn_State_BITF_MCU |= ( 1 << 4 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y5_ON( void )
{

    IO_Y5_ON;
    //CG_GPIO.Yn_State_BITF |= ( 1 << 5 );
    // Bit6 = BR1, Bit7 = BR2, different logic from other output
    CG_GPIO.Out2_PwmTimer_Flag = YES;

    // 0 = CMPSS7.CTRIPOUTH ( Output Low )
    // 1 = CMPSS7.CTRIPOUTH_OR_CTRIPOUTL ( Output High )
    // 2 = ADCBEVT3
    // 3 = ECAP7OUT
    EALLOW;
    if( CG_GPIO.Out2_Pwm_Flag == NO ){
        //OutputXbarRegs.OUTPUT4MUX0TO15CFG.bit.MUX12 = 0;
        PWM_Y5_OFF;
    }else{
        //OutputXbarRegs.OUTPUT4MUX0TO15CFG.bit.MUX12 = 3;
        PWM_Y5_ON;
    }
    EDIS;

    CG_GPIO.Yn_State_BITF_MCU |= ( 1 << 5 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;

}

void f_Y6_ON( void )
{
    IO_Y6_ON;
    //CG_GPIO.Yn_State_BITF |= ( 1 << 6 );
    CG_GPIO.Yn_State_BITF_MCU |= ( 1 << 6 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

// Off
void f_Y0_OFF( void )
{
	IO_Y0_OFF;
	//CG_GPIO.Yn_State_BITF &= ~( 1 << 0 );
	CG_GPIO.Yn_State_BITF_MCU &= ~( 1 << 0 );
	//CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
	CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y1_OFF( void )
{
    IO_Y1_OFF;

	//CG_GPIO.Yn_State_BITF &= ~( 1 << 1 );
    CG_GPIO.Yn_State_BITF_MCU &= ~( 1 << 1 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y2_OFF( void )
{
    IO_Y2_OFF;
    //CG_GPIO.Yn_State_BITF &= ~( 1 << 2 );
    CG_GPIO.Yn_State_BITF_MCU &= ~( 1 << 2 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y3_OFF( void )
{
    if( CG_MD.HW_Ver == HW_VER_A ){
        IO_Y3_OFF_A;
    }else{
        IO_Y3_OFF_B;
    }
    //CG_GPIO.Yn_State_BITF &= ~( 1 << 3 );
    CG_GPIO.Yn_State_BITF_MCU &= ~( 1 << 3 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y4_OFF( void )
{

    EALLOW;
    if( CG_MD.HW_Ver == HW_VER_A ){
        IO_Y4_OFF_A;
        PWM_Y4_OFF_A;
    }else{
        IO_Y4_OFF_B;
        PWM_Y4_OFF_B;
    }
    EDIS;

    CG_GPIO.Out1_PwmTimer_Flag = NO;
    CG_GPIO.Out1_PwmTimerMs = 0;
    CG_GPIO.Out1_Pwm_Flag = NO;

    CG_GPIO.Yn_State_BITF_MCU &= ~( 1 << 4 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y5_OFF( void )
{
    IO_Y5_OFF;
    //CG_GPIO.Yn_State_BITF &= ~( 1 << 5 );
    // Bit6 = BR1, Bit7 = BR2, different logic from other output
    // 0 = CMPSS7.CTRIPOUTH ( Output Low )
    // 1 = CMPSS7.CTRIPOUTH_OR_CTRIPOUTL ( Output High )
    // 2 = ADCBEVT3
    // 3 = ECAP7OUT
    EALLOW;
    //OutputXbarRegs.OUTPUT4MUX0TO15CFG.bit.MUX12 = 1;
    PWM_Y5_OFF;
    EDIS;
    CG_GPIO.Out2_PwmTimer_Flag = NO;
    CG_GPIO.Out2_PwmTimerMs = 0;
    CG_GPIO.Out2_Pwm_Flag = NO;

    CG_GPIO.Yn_State_BITF_MCU &= ~( 1 << 5 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

void f_Y6_OFF( void )
{
    IO_Y6_OFF;
    //CG_GPIO.Yn_State_BITF &= ~( 1 << 6 );
    CG_GPIO.Yn_State_BITF_MCU &= ~( 1 << 6 );
    //CG_GPIO.Yn_State_BITF = ~( CG_GPIO.Yn_State_BITF_MCU ^ CG_GPIO.YnActState_BITF );
    CG_GPIO.Yn_State_BITF = CG_GPIO.Yn_State_BITF_MCU;
}

/*===========================================================================================
    Function Name    : variableInitial_IO
    Input            : Null
    Return           : Null
    Programmer       : Gear.Frng@trumman.com.tw
    Description      : Variable CG_IO initial
					   Should be execute only after parameter initial.
//==========================================================================================*/
void variableInitial_IO (void)
{
    int8_t i;
    int8_t j;

    for( i = 0; i < SRC_NUM; i++ ){
        CG_IO.DI_XN_BITF[ i ] = 0;
        for( j = 0; j < XN_MAX_NUM; j++ ){
            CG_IO.DIn_Func[ i ][ j ] = 0;
        }
    }


}

/*===========================================================================================
    Function Name    : io_ValSet_DI_XN
    Input            : 1. lc_src: Src of the DIn_Func to set.
                       2. state
    Return           : The updated value of DI_XN_BITF
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set the value of DI_XN_BITF[ src ]
//==========================================================================================*/
uint32_t io_ValSet_DI_XN ( const uint8_t lc_src, const uint32_t state )
{
    uint32_t return_value = CG_IO.DI_XN_BITF[ lc_src ] = state;

    return (return_value);
}


/*===========================================================================================
    Function Name    : io_ValSet_DIn_Func
    Input            : 1. lc_src: Src of the DIn_Func to set.
					   2. lc_funcBit: Bit of the function to set.
					   3. lc_func: Command function to set.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the value of DIn_Func[ src ][ function bit ]
//==========================================================================================*/
void io_ValSet_DIn_Func ( const uint8_t lc_src, const uint32_t lc_funcBit, const uint32_t lc_func )
{
	CG_IO.DIn_Func[ lc_src ][ lc_funcBit ]			= lc_func;
}

/*===========================================================================================
    Function Name    : io_ValSet_DI_XN_BITF
    Input            : 1. lc_src: Src of the DIn_Func to set.
					   2. lc_funcBitfield: Bit field of the function to set.
    Return           : The updated value of DI_XN_BITF
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the value of DI_XN_BITF[ src ]
//==========================================================================================*/
uint32_t io_ValSet_DI_XN_BITF ( const uint8_t lc_src, const uint32_t lc_funcBitfield )
{
	uint32_t return_value = CG_IO.DI_XN_BITF[ lc_src ] |= (lc_funcBitfield);

	return (return_value);
}

/*===========================================================================================
    Function Name    : io_ValClr_DI_XN_BITF
    Input            : 1. lc_src: Src of the DIn_Func to clear.
					   2. lc_funcBitfield:  Bit field of the function to clear.
    Return           : The updated value of DI_XN_BITF
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Clear certain bits of DI_XN_BITF[ src ]
//==========================================================================================*/
uint32_t io_ValClr_DI_XN_BITF ( const uint8_t lc_src, const uint32_t lc_funcBitfield )
{
	uint32_t return_value = CG_IO.DI_XN_BITF[ lc_src ] &= ~(lc_funcBitfield);

	return (return_value);
}





/************************** <END OF FILE> *****************************************/
