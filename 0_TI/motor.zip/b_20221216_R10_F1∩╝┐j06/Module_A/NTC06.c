/*===========================================================================================

    File Name       : NTC06.c

    Version         : V1.00_a

    Built Date      : 2022/03/07

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"
#include "NTC06.h"

const int16_t Const_NTC06_Table[ NTC06_FULL_RANGE ] =
{
     2783, 2663, 2549, 2441, 2337,      2239, 2145, 2056, 1971, 1890,
     1813, 1740, 1670, 1603, 1539,      1478, 1420, 1364, 1311, 1261,
     1212, 1166, 1122, 1079, 1039,      1000,  963,  927,  893,  861,
      830,  800,  771,  744,  717,       692,  668,  645,  622,  601,
      581,  561,  542,  524,  506,       489,  473,  457,  442,  428,
      414,  401,  388,  376,  364,       352,  341,  331,  320,  310,
      301,  292,  283,  274,  266,       258,  250,  243,  236,  229,
      222,  216,  210,  204,  198,       192,  187,  181,  176,  171,
      167,  162,  158,  153,  149,       145,  141,  137,  134,  130,
      127,  123,  120,  117,  114,       111,  108,  105,  103,  100
};

/*===========================================================================================
    Function Name    : variableInitial_NTC_Temperature
    Input            : ntc
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_NTC_Temperature ( Struct_NTC_Temperature *ntc )
{
    ntc->Temperature_Left = NTC06_INDEX_0_TEMP;
    ntc->Temperature_Right = NTC06_INDEX_MAX_TEMP;

    ntc->Temperature = 0;
}

/*===========================================================================================
    Function Name    : calculate_NTCADC
    Input            : 1.temp
    Return           : ADC
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t calculate_NTCADC( uint32_t temp )
{
    int32_t adc = 0;
    int32_t resistor;

    if( temp < NTC06_FULL_RANGE ){
        resistor = Const_NTC06_Table[ temp ];
        adc = resistor * ADC_MAX_VALUE / ( resistor + NTC06_DIVIDER_RESISTOR );

        adc = adc * 3;// MCU OP GAIN
    }

    return adc;
}

/*===========================================================================================
    Function Name    : calculate_NTCResistor
    Input            : 1.adc_value: ADC value
    Return           : Resistor ( Unit: 0.01 KOhm )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t calculate_NTCResistor( uint32_t adc_value )
{
    int32_t resistor;

    /*
    resistor / ( resistor + 330 ) = adc_value / ADC_MAX_VALUE;

    resistor * ADC_MAX_VALUE = adc_value * ( resistor + 330 )
        = adc_value * resistor + adc_value * 330

    resistor * ( ADC_MAX_VALUE - adc_value ) = adc_value * 330
    */
    adc_value = adc_value / 3; // MCU OP GAIN

    if( ADC_MAX_VALUE > adc_value ){
        resistor = adc_value * NTC06_DIVIDER_RESISTOR / ( ADC_MAX_VALUE - adc_value );
    }else{
        resistor = adc_value * NTC06_DIVIDER_RESISTOR;
    }

    return resistor;

}

/*===========================================================================================
    Function Name    : calculate_NTCResistor
    Input            : 1.ntc
                       2.adc_value: ADC value
    Return           : Temperature ( Unit: 1 degree C )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t calculate_NTCTemp( Struct_NTC_Temperature *ntc, uint32_t adc_value )
{
    int32_t resistor = calculate_NTCResistor( adc_value );
    int32_t r_left;
    int32_t r_right;
    int32_t r_mid;
    int32_t t_mid;

    r_left = Const_NTC06_Table[ ntc->Temperature_Left ];
    r_right = Const_NTC06_Table[ ntc->Temperature_Right ];

    if( resistor > r_left ){ // Temperature < Temperature_Left

        if( ntc->Temperature_Left > NTC06_INDEX_0_TEMP ){
            ntc->Temperature_Left--;
        }

        ntc->Temperature_Right = ntc->Temperature_Left + 1;

    }else if( resistor < r_right ){ // Temperature > Temperature_Right

        if( ntc->Temperature_Right < NTC06_INDEX_MAX_TEMP ){
            ntc->Temperature_Right++;
        }

        ntc->Temperature_Left = ntc->Temperature_Right - 1;

    }else{
        t_mid = ( ntc->Temperature_Left + ntc->Temperature_Right ) >> 1;
        r_mid = Const_NTC06_Table[ t_mid ];

        if( resistor < r_mid ){
            ntc->Temperature_Right = t_mid;
        }else{
            ntc->Temperature_Left = t_mid;
        }

    }

    ntc->Temperature = ( ntc->Temperature_Left + ntc->Temperature_Right ) >> 1;

    return ntc->Temperature;
}

/************************** <END OF FILE> *****************************************/
