/*===========================================================================================

    File Name       : SlightPositionKeeping_TypeDef.h

    Version         : V1_00_00_a

    Built Date      : 2016/08/31

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */


#ifndef SLIGHT_POSITION_KEEPING_TYPEDEF_H
#define SLIGHT_POSITION_KEEPING_TYPEDEF_H

enum{

    SPK_MODE_SHORT_BRAKE        = 0,
    SPK_MODE_SPK                = 1,
    SPK_MODE_NUM                = 2
};

/*===========================================================================================
    BLDC global variable data structure
//==========================================================================================*/
typedef struct{

	//Andrew test2016/08/15
    int32_t     Mode;
	int32_t		Hall_Lock_pointer;
	int32_t		Hall_Lock_pointer_Abs;
	int32_t		Hall_Lock_pointer_Abs_Old;
	int32_t		Hall_Lock_pointer_Effect;
	int32_t		Hall_Lock_pointer_Trend;

	int8_t		Tq_Restraint_flag;

	int32_t		Target_Tq;
	int32_t		Current_Target_Tq;

	int32_t		Tq_Percentage_1; // The Keeping torque when position error = 0
	int32_t		Tq_Percentage_2; // The Keeping torque when lock_pointer != 0

	int32_t		Tq_Acc;	// Target current acc
	int32_t		Tq_Dec;	// Target current dec

	int32_t		Tq_AccDec_Time;
	int32_t     Tq_AccDec_Rest;

	int32_t		Step_duty_Max;

	int32_t		Lock_Timer;
	int32_t		Moved_Flag;

	int32_t		BrakeLock_Time;

	//

	uint32_t	SVM_Point;
	uint32_t	SVM_Point_CW;
	uint32_t	SVM_Point_CCW;

	int8_t 		SVM_Commutation;                       	// UVW Output signal

	int32_t		SVM_Duty_U;
	int32_t		SVM_Duty_V;
	int32_t		SVM_Duty_W;

	int32_t		SVM_Va;
	int32_t		SVM_Vb;
	int32_t		SVM_Vc;

	int32_t		SVM_T1;
	int32_t		SVM_T2;
	int32_t		SVM_T0;

	//
    void (*Start)( void );
    void (*Stop)( void );

	//int32_t		Test_Cnt;

}Struct_SPK;


#endif /* MODULE_D_SLIGHTPOSITIONKEEPING_H_ */

/************************** <END OF FILE> *****************************************/


