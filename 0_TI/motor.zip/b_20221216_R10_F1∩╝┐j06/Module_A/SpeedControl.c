/*===========================================================================================

    File Name       : SpeedControl.c

    Version         : V0200

    Built Date      : 2018/05/25

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */
#include "IncludeFiles.h"
//#include "SpeedControl.h"



/*===========================================================================================
    Function Name    : setupInitial_SpeedControl
    Input            :  1. speedctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_SpeedControl ( Struct_SpeedControl* speedctrl )
{
    resetReg_SpeedControl( speedctrl );

    // Loop 1 : pos error x kp = target ( where target = speed erpm )
    speedctrl->Loop_1_Kp = SPDCTRL_LOOP_1_KP_INIT;
    speedctrl->Pos_Const = 0;

    speedctrl->Allowed_Erpm_Error_Const = 0;

    // Loop 2 : Speed control
    il_PID_Set_KpKiKd ( &speedctrl->Loop_2_SpeedPID, SPDCTRL_LOOP_2_P_INIT, 0, 0 );
    il_PID_Set_MaxMin ( &speedctrl->Loop_2_SpeedPID, 0, 0 );

}

/*===========================================================================================
    Function Name    : resetReg_SpeedControl
    Input            :  1. speedctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void resetReg_SpeedControl ( Struct_SpeedControl* speedctrl )
{
	
    // Target speed planning
    speedctrl->Target_ERPM = 0;

    // Target path planning
    speedctrl->Target_Pos_Step = 0;
    speedctrl->Target_Pos_Step_Rest = 0;

    // Loop 1 : pos error x kp = target ( where target = speed erpm )
    speedctrl->Loop_1_Target = 0;
    speedctrl->Loop_1_Rest = 0;

    // Loop 2 : Speed control
    setupInitial_PID ( &speedctrl->Loop_2_SpeedPID );

    speedctrl->Loop_2_StepLimit = SPDCTRL_LOOP_2_STEP_LIMIT_INIT;

    // Final output
    speedctrl->Output = 0;

}

/*===========================================================================================
    Function Name    : setupInitial_DriverMotorInfor
    Input            :  1. infor
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_DriverMotorInfor ( Struct_DriverMotorInfor* infor )
{
    infor->Pole_Factor = 1;

    infor->Pos_Now = 0;
    infor->Pos_Old = 0;
    infor->Pos_Delta = 0;

    infor->SpeedERPM = 0;

}



/************************** <END OF FILE> *****************************************/
