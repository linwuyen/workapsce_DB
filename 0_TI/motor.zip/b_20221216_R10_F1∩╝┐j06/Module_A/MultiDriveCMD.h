/*===========================================================================================
    File Name       : MultiDriveCMD.h
    Version         : V1.00a
    Built Date      : 2021-06-10
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     :
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef MULTI_DRIVE_CMD_H
#define MULTI_DRIVE_CMD_H
#include "Type.h"

#include "IDA1_BLDC_CTRL.h"

/*===========================================================================================
    Function Name    : com_CMD_CS
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command CS processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_CS ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_FREE
    Input            : 1.data1
                       2.data2
                       3.index: 0 = Motor 0, 1 = Motor 1
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command FREE processing routine.
                       FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_FREE ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_SVON
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command SVON (Servo ON) processing routine.
                       FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_SVON ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_SVOFF
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The Multi command SVOFF processing routine.
                       FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_SVOFF ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_IMR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command IMR processing routine.
                       FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_IMR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_MR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command MR processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_MR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_MA
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command MA processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_MA ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_CMA
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command MA processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_CMA ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_CMR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command CMR processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_CMR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_JG0
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JG0 processing routine.
                       Condition check, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JG0 ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_JGF
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JGF processing routine.
                       Condition check, FUNC flags set, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JGF ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_JGR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JGR processing routine.
                       Condition check, FUNC flags set, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JGR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_JGS
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JGS processing routine.
                       Condition check, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JGS ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_JG
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JG processing routine.
                       Condition check, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JG ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_STOP
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command STOP processing routine.
                       Condition check, FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_STOP ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : com_CMD_NetIO
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
static uint8_t com_CMD_NetIO ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 );

/*===========================================================================================
    Function Name    : mdCMD_Execute
    Input            : 1.bldc_ctrl
                       2.cmd
                       3.data1
                       4.data2
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
//==========================================================================================*/
uint8_t mdCMD_Execute ( Struct_BLDC_CTRL *bldc_ctrl, int32_t cmd, int32_t data1, int32_t data2 );




#endif

/************************** <END OF FILE> *****************************************/


