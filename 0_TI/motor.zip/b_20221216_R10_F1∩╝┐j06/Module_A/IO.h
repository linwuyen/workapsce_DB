/*===========================================================================================
    File Name       : IO.h
    Built Date      : 2012-12-27
	Version         : V1.02a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file provides the IO state function system of the driver.
	
	Module required:  - IO_Func: For IO Function defeines.
	
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef IO_H
#define IO_H

#include "../Module_D/I04_GPIO.h"

#define XN_MAX_NUM          16

/*===========================================================================================
    Command SRC Defines
//==========================================================================================*/
enum{
    SRC_IO                  = 0,
    SRC_EEP                 = 1,
    SRC_UART                = 2,
    SRC_OTHERS              = 3,
    SRC_MULTI_DRIVE_M0      = 4,
    SRC_MULTI_DRIVE_M1      = 5,

    SRC_ALL                 = 6,
    SRC_NUM                 = 7
};

typedef struct{

    uint32_t    DIn_Func[ SRC_NUM ][ XN_MAX_NUM ];      // Function setting of each point xn by different source.
    uint32_t    DI_XN_BITF[ SRC_NUM ];                  // Xn state bit field of each source.

}Struct_IO;

/*===========================================================================================
    IO SRC Defines for fixed functions. ( SRC_EEP )
//==========================================================================================*/
enum {
	SRC_EEP_IO_STOP_BIT_M0		= 0,
	SRC_EEP_IO_STOP_BIT_M1      = 1,

	SRC_EEP_IO_DIR_BIT_M0       = 2,
	SRC_EEP_IO_DIR_BIT_M1       = 3,

	SRC_EEP_IO_DIR_BIT		    = 4
};

/*===========================================================================================
    Function Name    : variableInitial_IO
    Input            : Null
    Return           : Null
    Programmer       : Gear.Frng@trumman.com.tw
    Description      : Variable CG_IO initial
					   Should be execute only after parameter initial.
//==========================================================================================*/
void variableInitial_IO (void);

/*===========================================================================================
    Function Name    : io_ValSet_DI_XN
    Input            : 1. lc_src: Src of the DIn_Func to set.
                       2. state
    Return           : The updated value of DI_XN_BITF
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set the value of DI_XN_BITF[ src ]
//==========================================================================================*/
uint32_t io_ValSet_DI_XN ( const uint8_t lc_src, const uint32_t state );


/*===========================================================================================
    Function Name    : io_ValSet_DIn_Func
    Input            : 1. lc_src: Src of the DIn_Func to set.
					   2. lc_funcBit: Bit of the function to set.
					   3. lc_func: Command function to set.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the value of DIn_Func[ src ][ function bit ]
//==========================================================================================*/
void io_ValSet_DIn_Func ( const uint8_t lc_src, const uint32_t lc_funcBit, const uint32_t lc_func );

/*===========================================================================================
    Function Name    : io_ValSet_DI_XN_BITF
    Input            : 1. lc_src: Src of the DIn_Func to set.
					   2. lc_funcBitfield: Bit field of the function to set.
    Return           : The updated value of DI_XN_BITF
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the value of DI_XN_BITF[ src ]
//==========================================================================================*/
uint32_t io_ValSet_DI_XN_BITF ( const uint8_t lc_src, const uint32_t lc_funcBitfield );

/*===========================================================================================
    Function Name    : io_ValClr_DI_XN_BITF
    Input            : 1. lc_src: Src of the DIn_Func to clear.
					   2. lc_funcBitfield:  Bit field of the function to clear.
    Return           : The updated value of DI_XN_BITF
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Clear certain bits of DI_XN_BITF[ src ]
//==========================================================================================*/
uint32_t io_ValClr_DI_XN_BITF ( const uint8_t lc_src, const uint32_t lc_funcBitfield );

/*===========================================================================================
    Output Action functions
//==========================================================================================*/
void f_Y_NC( void );
void f_Y0_ON( void );
void f_Y1_ON( void );
void f_Y2_ON( void );
void f_Y3_ON( void );
void f_Y4_ON( void );
void f_Y5_ON( void );
void f_Y6_ON( void );
void f_Y7_ON( void );
void f_Y8_ON( void );

void f_Y0_OFF( void );
void f_Y1_OFF( void );
void f_Y2_OFF( void );
void f_Y3_OFF( void );
void f_Y4_OFF( void );
void f_Y5_OFF( void );
void f_Y6_OFF( void );
void f_Y7_OFF( void );
void f_Y8_OFF( void );

#endif

/************************** <END OF FILE> *****************************************/
