/*===========================================================================================
    File Name       : Protect_TypeDef.h
    Built Date      : 2020/0813
	Version         : V1.01a
    Release Date    : Not Yet
    Programmer      : Chaim.Chen@trumman.com.tw
    Description     :
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef PROTECT_TYPEDEF_H
#define PROTECT_TYPEDEF_H
#include "NTC06.h"

enum{
    ENCODER_ERROR_BIT_OVERFLOW  = 0,
    ENCODER_ERROR_BIT_Z_LOSS    = 1,
    ENCODER_ERROR_BIT_XOR_ERR   = 2,
    ENCODER_ERROR_BIT_NUM       = 3
};

enum{
    RGN_ERROR_BIT_OT                = 0,
    RGN_ERROR_BIT_WRONG_POWER_IN    = 1,
    RGN_ERROR_BIT_NUM
};


enum{
    EXT_ERROR_BIT_IO                = 0,
    EXT_ERROR_BIT_DEPENDENT         = 1,
    EXT_ERROR_BIT_NUM
};

/*===========================================================================================
    Protect variable data structure
//==========================================================================================*/
typedef struct{

    uint32_t    Fault_BITF;
    uint32_t    Fault_Stop_Mask_BITF;

    uint8_t     first_fault;
    uint8_t     first_fault_user;

    uint32_t    ErrorCode_LimitTime;
    uint8_t     HisSaved_Flag;                              // Flag indicate error code saved.
    uint8_t     UVP_Save_Flag;                              // Flag indicate to save UVP.

    // Parameter settings
    uint8_t     PowerOn_Run;
    uint8_t     MotorFB;
    uint32_t    OverSpeed;
    uint32_t    AutoReset_Time;
    uint32_t    AutoReset_Mask_BITF;
    uint8_t     OC_Fault_EN;
    uint8_t     OP_Fault_EN;
    int32_t     TimeOut_Behavior;

    //

    uint32_t    under_vbus_value;
    uint32_t    under_vbus_recover_value;
    uint32_t    under_vbus_behavior;
    uint32_t    under_vbus_timer;

    uint32_t    over_vbus_value;
    uint32_t    over_vbus_recover_value;
    uint32_t    over_vbus_behavior;
    uint32_t    over_vbus_timer;

    uint32_t    low_vbus_value;
    uint32_t    low_vbus_recover_value;

    uint32_t    hall_error_behavior;
    uint32_t    hall_error_timer;

    uint32_t    BUSV_Low_cnt;                               // BusV low counter.
    uint32_t    BUSV_LowRec_cnt;                            // BusV low recover counter.

    uint8_t     Alm_tick_Time_BITF;                         // timer tick flag bit field

    uint8_t     LED_flash_timer;                            // led flash timer (based on tick)
    uint8_t     LED_flash_count;

    uint8_t     IO_RST_State;                               // State indicate IO reset.
    uint8_t     IO_RST_on_Cnt;                              // IO reset ON counter
    uint8_t     IO_RST_off_Cnt;                             // IO reset ON counter

    uint32_t    MosOT_BITF;

    int32_t     MosOT_time_fault;
    int32_t     MotorOT_time_fault;
    int32_t     RGNOT_time_fault;
    Struct_NTC_Temperature MosNTC_1;
    Struct_NTC_Temperature MosNTC_2;
    Struct_NTC_Temperature MosNTC_3;

    uint32_t    RGN_Error_BITF;
    int32_t     RGN_On_Allowed_Cnt;
    int32_t     RGN_On_Cnt;

    uint32_t    IO_Type_Fault_BITF;


    //uint8_t   IPM_Fault_State;
    //uint8_t   IPM_Fault_Lock_Flag;

    //int32_t   IPM_time_fault;
    //int32_t   IPM_time_recover;

    uint8_t     HWCR_State;
    uint8_t     HWCR_Lock_Flag;

    int32_t     HWCR_time_fault;
    int32_t     HWCR_time_recover;

    int32_t     FWCR_time_fault;
    int32_t     FWCR_time_recover;
    uint8_t     FWCR_flag;
    uint8_t     FWCR_Lock_flag;

    int32_t     OverLoad_time_fault;
    int32_t     OverLoad_time_recover;
    uint8_t     OverLoad_flag;
    uint8_t     OverLoad_Lock_flag;

    int32_t     OverPower_time_fault;
    int32_t     OverPower_time_recover;
    uint8_t     OverPower_flag;
    uint8_t     OverPower_Lock_flag;

    uint32_t    auto_reset_timer;

    int32_t     StartFail_Cnt;

    uint32_t    Encoder_Error_BITF;
    uint16_t    Encoder_Overflow_Mode;
    uint32_t    Encoder_Error_Sensitivity;
    uint32_t    Encoder_Error_Cnt;

    uint8_t     ComAlarm_Req_Flag;

    uint8_t     OverLimit_Index;        // Indicate the over limit HWEEP index.

    //
    uint8_t     ToReset;

    int16_t     History_Index;

    int32_t     Dependent_Error_Cnt;
    uint32_t    EXT_Error_BITF;

}Struct_Driver_Pretect;



#endif

/************************** <END OF FILE> *****************************************/
