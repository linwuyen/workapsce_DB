/*===========================================================================================

    File Name       : PIDControl.h

    Version         : V1_00_10_a

    Built Date      : 2017/10/02

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */
#ifndef PIDCONTROL_H_
#define PIDCONTROL_H_

//#include "Type.h"


#define	AC_PID_CONST	1024L

enum{
	PID_TYPE_P	= 0,
	PID_TYPE_PI,
	PID_TYPE_PID,
	PID_TYPE_NUM
};


typedef struct{

	//
	int32_t Input;
	int32_t Feedback;

	int32_t Error;
	int32_t Error_Last;

	int32_t Kp_Const;
	int32_t Ki_Const;
	int32_t Kd_Const;

	int32_t P_Term_Rest;
	int32_t I_Term_Rest;
	int32_t D_Term_Rest;

	int32_t Output_P_Term;
	int32_t Output_I_Term;
	int32_t Output_D_Term;

	int32_t Output;
	int32_t Output_Restraint_Max;
	int32_t Output_Restraint_Min;

}Struct_PID;

/*===========================================================================================
    Function Name    : setupInitial_PID
    Input            : 1.pid
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_PID ( Struct_PID* pid );

/*===========================================================================================
    Function Name    : il_PID_Set_Input
    Input            : 1.pid
    				   2.input
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PID_Set_Input ( Struct_PID* pid, int32_t input )
{
	pid->Input = input;
}

/*===========================================================================================
    Function Name    : il_PID_Set_Feedback
    Input            : 1.pid
    				   2.feedback
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PID_Set_Feedback ( Struct_PID* pid, int32_t feedback )
{
	pid->Feedback = feedback;
}

/*===========================================================================================
    Function Name    : il_PID_Set_KpKiKd
    Input            : 1.pid
    				   2.kp
    				   3.ki
    				   4.kd
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PID_Set_KpKiKd ( Struct_PID* pid, int32_t kp, int32_t ki, int32_t kd )
{
	pid->Kp_Const = kp;
	pid->Ki_Const = ki;
	pid->Kd_Const = kd;
}

/*===========================================================================================
    Function Name    : il_PID_Set_MaxMin
    Input            : 1.pid
    				   2.max
    				   3.min
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PID_Set_MaxMin ( Struct_PID* pid, int32_t max, int32_t min )
{
	pid->Output_Restraint_Max = max;
	pid->Output_Restraint_Min = min;
}

/*===========================================================================================
    Function Name    : il_PID_CLR_I_Term
    Input            : 1.pid
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PID_CLR_I_Term ( Struct_PID* pid )
{
	pid->Output_I_Term = 0;
	pid->I_Term_Rest = 0;
}

/*===========================================================================================
    Function Name    : il_PID_Get_Output
    Input            : 1.pid
    Return           : Output
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_PID_Get_Output ( Struct_PID* pid )
{
	int32_t value = pid->Output;
	return value;
}

/*===========================================================================================
    Function Name    : il_PID_Get_Kp
    Input            : 1.pid
    Return           : Kp
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_PID_Get_Kp ( Struct_PID* pid )
{
	int32_t value = pid->Kp_Const;
	return value;
}

/*===========================================================================================
    Function Name    : il_PID_Get_Feedback
    Input            : 1.pid
    Return           : Feedback
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline int32_t il_PID_Get_Feedback ( Struct_PID* pid )
{
	int32_t value = pid->Feedback;
	return value;
}

/*===========================================================================================
    Function Name    : il_PID_Run_PID
    Input            : 1.pid
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
__inline void il_PID_Run_PID ( Struct_PID* pid )
{
	int32_t dummy;

	pid->Error_Last = pid->Error;
	pid->Error = pid->Input - pid->Feedback;
	// P
	dummy = pid->Error * pid->Kp_Const + pid->P_Term_Rest;
	pid->Output_P_Term = dummy / AC_PID_CONST;
	pid->P_Term_Rest = MOD( dummy, AC_PID_CONST );

	// I
	dummy = pid->Output_P_Term * pid->Ki_Const + pid->I_Term_Rest;
	//dummy = pid->Error * pid->Ki_Const + pid->I_Term_Rest;
	pid->Output_I_Term += dummy / AC_PID_CONST;
	pid->I_Term_Rest = MOD( dummy, AC_PID_CONST );

	if( pid->Output_I_Term > pid->Output_Restraint_Max ){
		pid->Output_I_Term = pid->Output_Restraint_Max;
	}else if( pid->Output_I_Term < pid->Output_Restraint_Min ){
		pid->Output_I_Term = pid->Output_Restraint_Min;
	}

	// D
	dummy = ( pid->Error - pid->Error_Last ) * pid->Kd_Const + pid->D_Term_Rest;
	pid->Output_D_Term = dummy / AC_PID_CONST;
	pid->D_Term_Rest = MOD( dummy, AC_PID_CONST );

	// Output
	pid->Output = pid->Output_P_Term + pid->Output_I_Term + pid->Output_D_Term;

	if( pid->Output > pid->Output_Restraint_Max ){
		pid->Output = pid->Output_Restraint_Max;
	}else if( pid->Output < pid->Output_Restraint_Min ){
		pid->Output = pid->Output_Restraint_Min;
	}

}

/*===========================================================================================
    Function Name    : il_PID_Run_PI
    Input            : 1.pid
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
__inline void il_PID_Run_PI ( Struct_PID* pid )
{
	int32_t dummy;

	pid->Error = pid->Input - pid->Feedback;
	// P
	dummy = pid->Error * pid->Kp_Const + pid->P_Term_Rest;
	pid->Output_P_Term = dummy / AC_PID_CONST;
	pid->P_Term_Rest = MOD( dummy, AC_PID_CONST );

	// I
	dummy = pid->Output_P_Term * pid->Ki_Const + pid->I_Term_Rest;
	//dummy = pid->Error * pid->Ki_Const + pid->I_Term_Rest;
	pid->Output_I_Term += dummy / AC_PID_CONST;
	pid->I_Term_Rest = MOD( dummy, AC_PID_CONST );

	if( pid->Output_I_Term > pid->Output_Restraint_Max ){
		pid->Output_I_Term = pid->Output_Restraint_Max;
	}else if( pid->Output_I_Term < pid->Output_Restraint_Min ){
		pid->Output_I_Term = pid->Output_Restraint_Min;
	}

	// Output
	pid->Output = pid->Output_P_Term + pid->Output_I_Term;

	if( pid->Output > pid->Output_Restraint_Max ){
		pid->Output = pid->Output_Restraint_Max;
	}else if( pid->Output < pid->Output_Restraint_Min ){
		pid->Output = pid->Output_Restraint_Min;
	}

}

/*===========================================================================================
    Function Name    : il_PID_Run_P
    Input            : 1.pid
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
__inline void il_PID_Run_P ( Struct_PID* pid )
{
	int32_t dummy;

	pid->Error = pid->Input - pid->Feedback;
	// P
	dummy = pid->Error * pid->Kp_Const + pid->P_Term_Rest;
	pid->Output_P_Term = dummy / AC_PID_CONST;
	pid->P_Term_Rest = MOD( dummy, AC_PID_CONST );

	// Output
	pid->Output = pid->Output_P_Term;

	if( pid->Output > pid->Output_Restraint_Max ){
		pid->Output = pid->Output_Restraint_Max;
	}else if( pid->Output < pid->Output_Restraint_Min ){
		pid->Output = pid->Output_Restraint_Min;
	}

}

#endif /* AUTOCONTROL_H_ */
/************************** <END OF FILE> *****************************************/
