/*===========================================================================================

    File Name       : MotorMove.h

    Version         : V1_00_10_a

    Built Date      : 2015/06/09

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : 

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef MOTOR_MOVE_H
#define MOTOR_MOVE_H
#include "IDA1_BLDC_CTRL.h"
#include "MotorMove_TypeDef.h"


#define IMR_MAX_DEC_CONST		1000			// 1000 = 0.1s from 3000 RPM to 0
#define IMR_MIN_DEC_CONST		1				// 1	= 100s from 3000 RPM to 0
#define MAX_PI_FREQUENCE		2500


#define	MOVE_CTRL_CONST			1024L


/*===========================================================================================
    Function Name    : variableInitial_Move
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Move initial
//==========================================================================================*/
void variableInitial_Move( void );

/*===========================================================================================
    Function Name    : moveResetCtrlLoop
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveResetCtrlLoop( void );

/*===========================================================================================
    Function Name    : moveSetChangeSpdFlag
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveSetChangeSpdFlag( int32_t state );

/*===========================================================================================
    Function Name    : moveInitMotionData
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveInitMotionData( void );

/*===========================================================================================
    Function Name    : moveGetCurrent information
    Input            : NULL
    Return           : information
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
int32_t moveGetCurrentSpeed ( void );
int32_t moveGetCurrentDirection ( void );
int32_t moveGetCurrentIndex ( void );
int32_t moveGetCurrentPos ( void );

/*===========================================================================================
    Function Name    : moveIndexDisplay
    Input            : index in encoder form, pos in encoder form
    Return           : index in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t moveIndexDisplay( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : movePosDisplay
    Input            : index in encoder form, pos in encoder form
    Return           : pos in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t movePosDisplay( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveOffset
    Input            : index : offset index
					   pos : offset pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveOffset ( int32_t index, int32_t pos );


/*===========================================================================================
    Function Name    : moveOffset
    Input            : index : offset index
					   pos : offset pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveCS ( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveDistance
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : P2 - P1
//==========================================================================================*/
int32_t moveDistance ( int32_t P1_index, int32_t P1_pos, int32_t P2_index, int32_t P2_pos );

/*===========================================================================================
    Function Name    : moveGetPosition
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : When doing this fuction, make sure Interrupt is turned off
//==========================================================================================*/
void moveGetPosition ( void );

/*===========================================================================================
    Function Name    : movePositionController_PID_Encoder
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
void movePositionController_PID_Encoder ( void );

/*===========================================================================================
    Function Name    : movePathManage
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void movePathManage ( void );

/*===========================================================================================
    Function Name    : runPathManage
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void runPathManage ( void );

/*===========================================================================================
    Function Name    : moveRun2Move
    Input            : dir = direction, index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveRun2Move ( int32_t dir, int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveRun2Move2
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveRun2Move2 ( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveLock2Move
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveLock2Move ( void );

/*===========================================================================================
    Function Name    : moveMA
    Input            : index = abs index, pos = abs pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveMA ( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveMR
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveMR ( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveIMR
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveIMR ( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveCMA
    Input            : index = abs index, pos = abs pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveCMA ( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveCMR
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveCMR ( int32_t index, int32_t pos );

/*===========================================================================================
    Function Name    : moveCMR_AtRun
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveCMR_AtRun ( int32_t index, int32_t pos );


#if(0)
/*===========================================================================================
    Function Name    : il_MovePositionProcess
    Input            :  1. move = CG_Move
    					2. encoder = CG_Encoder
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_MovePositionProcess ( Struct_Move *move, Struct_Encoder *encoder )
{
#if(0)
	move->Pulse_Stamp_1 = move->Pulse_Stamp_2;
	move->Pulse_Stamp_2 = move->Current_Pos;

	move->Inst_Speed_1 = move->Inst_Speed_2;

	move->Pulse_Delta = move->Pulse_Stamp_2 - move->Pulse_Stamp_1;
	if( move->Pulse_Delta > encoder->PosErrorMax_P ){
		move->Pulse_Delta = move->Pulse_Delta - encoder->MaxPos;
	}else if( move->Pulse_Delta < encoder->PosErrorMax_N ){
		move->Pulse_Delta = move->Pulse_Delta + encoder->MaxPos;
	}
	move->Inst_Speed_2 = move->Pulse_Delta * move->Inst_Speed_Acc_Const;
	move->Inst_Acc = move->Inst_Speed_2 - move->Inst_Speed_1;
#endif

}


/*===========================================================================================
    Function Name    : il_MoveGetPosition
    Input            : 1. move
    				   2. encoder
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : When doing this fuction, make sure Interrupt is turned off
//==========================================================================================*/
__inline void il_MoveGetPosition ( Struct_Move *move, Struct_Encoder *encoder )
{

#if(0)
	int32_t current_pos;
	static int32_t cnt = 0;
	current_pos = EQep1Regs.QPOSCNT;

	if( cnt == 0 ){
		if( encoder->Z_Got_Flag == YES ){
			cnt = 1;
			moveOffset ( 0, encoder->MaxPos - encoder->LastPos_b4Z );
			if( encoder->LastIndex_b4Z == 1 ){
				move->B4Z_Index = 1;
				move->B4Z_Last_Pos = 0;
			}else{
				move->B4Z_Index = -1;
				move->B4Z_Last_Pos = encoder->MaxPos;
			}
			move->Z_Processed_Flag = YES;
		}
	}

	if( current_pos - move->B4Z_Last_Pos > encoder->PosErrorMax_P ){
		move->B4Z_Index--;
	}else if( current_pos - move->B4Z_Last_Pos < encoder->PosErrorMax_N ){
		move->B4Z_Index++;
	}

	move->Current_Index = move->B4Z_Index - move->Offset_Index;
	move->Current_Pos = current_pos - move->Offset_Pos;


	if( move->Current_Pos >= encoder->MaxPos ){
		move->Current_Index++;
		move->Current_Pos -= encoder->MaxPos;
	}else if( move->Current_Pos < 0 ){
		move->Current_Index--;
		move->Current_Pos += encoder->MaxPos;
	}

	move->B4Z_Last_Pos = current_pos;
#endif

}

/*===========================================================================================
    Function Name    : il_RunPathManage
    Input            : 1. bldc_ctrl
    				   2. move
    				   3. encoder
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_RunPathManage ( Struct_BLDC_CTRL *bldc_ctrl, Struct_Move *move, Struct_Encoder *encoder )
{
#if(0)
	int32_t dummy = 0;
	int32_t limit;
	int32_t kp;
	#define CONST_KP_1		1000


	if( move->ChangeSpdFlag == YES ){
		kp = bldc_ctrl->Kp_Const;
		if( bldc_ctrl->target_erpm == move->Inst_Speed_2 ){
			move->ChangeSpdFlag = NO;
		}
	}else{
		kp = bldc_ctrl->Kp1_Const;
	}

	//dummy = bldc_ctrl->Inst_Speed_2 + CG_BLDC_CTRL.fb_duty * AC_PID_CONST / il_PID_Get_Kp( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID );
	dummy = move->Inst_Speed_2 +  bldc_ctrl->SpeedPID.Output * AC_PID_CONST / bldc_ctrl->SpeedPID.Kp_Const;

	if( dummy < 0 ){
		dummy *= -1;
	}

	#define ALLOWED_ERPM_ERROR	1000UL//160

	limit = move->Step_Pos;

	if( limit < 0 ){
		limit *= -1;
	}

	if( limit < ALLOWED_ERPM_ERROR ){
		limit = ALLOWED_ERPM_ERROR;
	}

	dummy += limit;

	if( move->Loop_1_Target > dummy  ){
		move->Loop_1_Target = dummy;
	}else if( move->Loop_1_Target < -dummy ){
		move->Loop_1_Target = -dummy;
	}

	dummy = ( move->Step_Pos - move->Pulse_Delta ) * kp + move->Loop_1_Rest;
	move->Loop_1_Target += dummy / MOVE_CTRL_CONST;
	move->Loop_1_Rest = MOD( dummy, MOVE_CTRL_CONST );


	move->Target_Erpm = move->Loop_1_Target;

#if(1)
	// ==
	//dummy = ( ( bldc_ctrl->current_target_erpm / bldc_ctrl->Pole_Factor ) * encoder->MaxPos ) + move->Step_Pos_Rest;
	dummy = ( ( bldc_ctrl->current_target_erpm / bldc_ctrl->Pole_Factor ) * encoder->MaxPos * 2 ) + move->Step_Pos_Rest;	// GaoLin Motor
	move->Step_Pos = ( dummy / encoder->PosError_Const );
	move->Step_Pos_Rest = MOD( dummy, encoder->PosError_Const );
#else

	dummy = ( ( bldc_ctrl->current_target_erpm / bldc_ctrl->Pole_Factor ) * encoder->MaxPos * 2 ) + move->Step_Pos_Rest;	// GaoLin Motor

	if( bldc_ctrl->current_target_erpm == 0 ){

		move->Step_Pos = ( dummy / encoder->PosError_Const );
		move->Step_Pos_Rest = MOD( dummy, encoder->PosError_Const );

	}else{
		move->Step_Pos = ( dummy / encoder->PosError_Const );
		move->Step_Pos_Rest = MOD( dummy, encoder->PosError_Const );

	}



#endif
#endif

}

/*===========================================================================================
    Function Name    : il_SpeedController_PID_Encoder
    Input            : 1. bldc_ctrl
    				   2. move
    				   3. type
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
__inline void il_SpeedController_PID_Encoder ( Struct_BLDC_CTRL *bldc_ctrl, Struct_Move *move, int32_t type )
{
#if(0)
	int32_t dummy;

	// Speed Control Loop With Torque Control Loop

	bldc_ctrl->SpeedPID.Input = move->Target_Erpm;
	bldc_ctrl->SpeedPID.Feedback = move->Inst_Speed_2;

	dummy = ( *bldc_ctrl->Torque_Const ) + bldc_ctrl->Torque_Step_Rest;
	bldc_ctrl->Torque_Step = dummy / bldc_ctrl->Torque_Step_Const;
	bldc_ctrl->Torque_Step_Rest = MOD( dummy, bldc_ctrl->Torque_Step_Const );

	if( bldc_ctrl->Torque_Traj + bldc_ctrl->Torque_Step < bldc_ctrl->Torque_Limit ){
		bldc_ctrl->Torque_Traj += bldc_ctrl->Torque_Step;
	}else{
		bldc_ctrl->Torque_Traj = bldc_ctrl->Torque_Limit;
	}

	bldc_ctrl->SpeedPID.Output_Restraint_Max = bldc_ctrl->Torque_Traj;
	bldc_ctrl->SpeedPID.Output_Restraint_Min = -bldc_ctrl->Torque_Traj;

	switch( type ){
	case PID_TYPE_P:
		il_PID_Run_P ( (Struct_PID*) &bldc_ctrl->SpeedPID );
		break;
	case PID_TYPE_PI:
		il_PID_Run_PI ( (Struct_PID*) &bldc_ctrl->SpeedPID );
		break;
	case PID_TYPE_PID:
	default:
		il_PID_Run_PID ( (Struct_PID*) &bldc_ctrl->SpeedPID );
		break;

	}
#endif

}

/*===========================================================================================
    Function Name    : il_MovePositionController_PID_Encoder
    Input            : 1. bldc_ctrl
    				   2. move
    				   3. encoder
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
__inline void il_MovePositionController_PID_Encoder ( Struct_BLDC_CTRL *bldc_ctrl, Struct_Move *move, Struct_Encoder *encoder )
{
#if(0)
	int32_t	dummy;
	int32_t kp;

	if( move->Meat_Target_Flag == YES ){
		kp = bldc_ctrl->Kp1_Const;
	}else{
		//kp = CG_BLDC_CTRL.D_Const;
		kp = bldc_ctrl->Kp_Const;
	}

	// Error calculation
	move->PosError =  ( move->Current_Target_Index - move->Current_Index ) * encoder->MaxPos + ( move->Current_Target_Pos - move->Current_Pos );
	// Step duty
	// For control mode translation ( speed -> position ), the following code is needed.
	if( move->Run2Move_Flag == YES ){
		move->Run2Move_Flag = NO;

		move->Loop_1_Target = move->Inst_Speed_2 +  bldc_ctrl->SpeedPID.Output * AC_PID_CONST / bldc_ctrl->SpeedPID.Kp_Const;
		move->Loop_1_Rest = 0;
		move->Loop_2_Target = move->Loop_1_Target;
		move->Loop_2_Rest = 0;
		move->Meat_Target_Flag = NO;
		move->Step_Pos_Rest = 0;
		move->IMR_Dec_Rest = 0;

		move->PosError = move->Loop_1_Target * AC_PID_CONST / bldc_ctrl->Kp_Const;

		move->Current_Target_Index = move->Current_Index;
		move->Current_Target_Pos = move->Current_Pos + move->PosError;

		dummy = move->Current_Target_Pos / encoder->MaxPos;
		move->Current_Target_Index = move->Current_Target_Index + dummy;
		move->Current_Target_Pos = move->Current_Target_Pos - dummy * encoder->MaxPos ;

		if( move->Current_Target_Pos >= encoder->MaxPos ){
			move->Current_Target_Index++;
			move->Current_Target_Pos -= encoder->MaxPos;
		}else if( move->Current_Target_Pos < 0 ){
			move->Current_Target_Index--;
			move->Current_Target_Pos += encoder->MaxPos;
		}

		move->Target_Index = move->Current_Target_Index;
		move->Target_Pos = move->Current_Target_Pos;

		if( move->Target_Index % 2 == 0 ){
			dummy = encoder->MaxPos * 2 - move->Target_Pos;
		}else{
			dummy = encoder->MaxPos - move->Target_Pos;
		}

		dummy += encoder->OriginPoint_Offset + bldc_ctrl->LockPoint;

		dummy = dummy % ( encoder->MaxPos * 2 );

		move->Target_Pos += dummy;
		move->Target_Index += move->Target_Pos / encoder->MaxPos;
		move->Target_Pos = move->Target_Pos % encoder->MaxPos;


		/*
		dummy = bldc_ctrl->LockPoint - move->Offset_Pos;

		if( dummy < 0 ){
			dummy += encoder->MaxPos;
		}

		if( dummy < move->Target_Pos ){
			move->Target_Index++;
		}
		move->Target_Pos = dummy;

		if( move->Z_Index % 2 == 0 && move->Target_Index % 2 != 0 ||
			move->Z_Index % 2 != 0 && move->Target_Index % 2 == 0 ){

			move->Target_Index++;
		}
		*/


	}else{

		dummy = move->PosError * kp + move->Loop_1_Rest;
		move->Loop_1_Target = dummy / MOVE_CTRL_CONST;
		move->Loop_1_Rest = MOD( dummy, MOVE_CTRL_CONST );

		/*
		dummy = ( move->Loop_1_Target - move->Loop_2_Target ) * CONST_KP_1 + move->Loop_2_Rest;
		move->Loop_2_Target += dummy / PERCENTAGE_100;
		move->Loop_2_Rest = MOD( dummy, PERCENTAGE_100 );

		move->Target_Erpm = move->Loop_2_Target;
		*/
		move->Target_Erpm = move->Loop_1_Target;



		// Can not use CG_Move.Target_Erpm as refrence speed
		// Because torque limit works bad in that way
		//CG_BLDC_CTRL.pre_duty = CG_BLDC_CTRL.current_target_erpm * CG_BLDC_Drive.period / CG_BLDC_Drive.full_speed_rpm_abs  / CG_BLDC_CTRL.Pole_Factor;
		//CG_BLDC_CTRL.pre_duty = 0;//CG_BLDC_CTRL.current_target_erpm * CG_BLDC_Drive.period / CG_BLDC_Drive.full_speed_rpm_abs  / CG_BLDC_CTRL.Pole_Factor;

		if( move->Meat_Target_Flag == YES ){
			//speedController_PID_Encoder( PID_TYPE_PI );
			il_SpeedController_PID_Encoder ( bldc_ctrl, move, PID_TYPE_PI );
		}else{
			il_PID_CLR_I_Term ( (Struct_PID*) &bldc_ctrl->SpeedPID );
			//speedController_PID_Encoder( PID_TYPE_P );
			il_SpeedController_PID_Encoder ( bldc_ctrl, move, PID_TYPE_P );
		}

	}
#endif

}

/*===========================================================================================
    Function Name    : il_MovePathManage
    Input            : 1. bldc_ctrl
    				   2. move
    				   3. encoder
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_MovePathManage ( Struct_BLDC_CTRL *bldc_ctrl, Struct_Move *move, Struct_Encoder *encoder )
{
#if(0)
	int32_t	dummy;
	int32_t limit;
	int32_t distance = 0;				// Target - Current
	int32_t buffer = 0;
	int32_t accdec_speed_const = 30 * bldc_ctrl->Pole_Factor;
	int32_t path_speed_min = bldc_ctrl->Pole_Factor;


	// distance
	distance = ( move->Target_Index - move->Current_Target_Index ) * encoder->MaxPos + ( move->Target_Pos - move->Current_Target_Pos );

	if( distance == 0 ){

		if( move->Inst_Speed_2 == 0 ){
			move->Meat_Target_Flag = YES;
		}
		move->Path_Speed_ERPM = 0;
		bldc_ctrl->current_target_erpm = 0;
		bldc_ctrl->current_target_rpm_abs = 0;
		move->Step_Pos_Rest = 0;
		move->IMR_Flag = NO;

	}else if( move->IMR_Flag == YES ){


		move->IMR_SpeedInitInMs = bldc_ctrl->current_target_rpm_abs * encoder->MaxPos / ( 60 *  ADC_UPDATE_DUTY_FREQUENCE );
		move->IMR_Dec_Const = bldc_ctrl->current_target_rpm_abs * bldc_ctrl->Pole_Factor * move->IMR_SpeedInitInMs / 2;
		if( move->IMR_Dec_Const == 0 ){
			move->IMR_Dec_Const = 1;
		}

		move->Buffer_IMR = distance;
		if( move->Buffer_IMR < 0 ){
			move->Buffer_IMR *= -1;
		}else if( move->Buffer_IMR == 0 ){
			move->Buffer_IMR = 1;
		}

		dummy = move->IMR_Dec_Const + move->IMR_Dec_Rest;
		move->IMR_Dec = dummy / move->Buffer_IMR;
		move->IMR_Dec_Rest = MOD( dummy, move->Buffer_IMR );

		if( distance > 0 ){
			move->Meat_Target_Flag = NO;
			if( bldc_ctrl->current_target_erpm >= 0 ){
				if( bldc_ctrl->current_target_erpm - move->IMR_Dec > path_speed_min ){
					bldc_ctrl->current_target_erpm -= move->IMR_Dec;
				}else{
					bldc_ctrl->current_target_erpm = path_speed_min;
				}
			}else{
				bldc_ctrl->current_target_erpm = 0;
				move->Current_Target_Index = move->Target_Index;
				move->Current_Target_Pos = move->Target_Pos;
			}
		}else if( distance < 0 ){
			move->Meat_Target_Flag = NO;
			if( bldc_ctrl->current_target_erpm <= 0 ){
				if( bldc_ctrl->current_target_erpm + move->IMR_Dec < -path_speed_min ){
					bldc_ctrl->current_target_erpm += move->IMR_Dec;
				}else{
					bldc_ctrl->current_target_erpm = -path_speed_min;
				}
			}else{
				bldc_ctrl->current_target_erpm = 0;
				move->Current_Target_Index = move->Target_Index;
				move->Current_Target_Pos = move->Target_Pos;
			}
		}


	}else{

		// The distance for stop
		buffer = bldc_ctrl->current_target_rpm_abs * bldc_ctrl->current_target_rpm_abs * ( encoder->MaxPos * bldc_ctrl->Pole_Factor / move->Buffer_Norm_GCD );
		buffer = buffer / ( BUFFER_CONST * move->Dec / move->Buffer_Norm_GCD );

		if( distance > 0 ){
			move->Meat_Target_Flag = NO;
			move->Path_Speed_ERPM_Limit = move->digital_target_rpm_abs * bldc_ctrl->Pole_Factor;

			// Speed is on right direction
			if(  bldc_ctrl->current_target_erpm >= 0 ){

				// Too far => add speed
				if( distance > buffer ){
					if( bldc_ctrl->current_target_erpm + bldc_ctrl->speed_acc < move->Path_Speed_ERPM_Limit ){
						bldc_ctrl->current_target_erpm += bldc_ctrl->speed_acc;
						//bldc_ctrl->acc_dec_rest = ( accdec_speed_const + bldc_ctrl->acc_dec_rest ) % bldc_ctrl->acc_time;
						dummy = accdec_speed_const + bldc_ctrl->acc_dec_rest;
						bldc_ctrl->acc_dec_rest = MOD( dummy, *bldc_ctrl->acc_time );
					}else{
						bldc_ctrl->current_target_erpm = move->Path_Speed_ERPM_Limit;
						bldc_ctrl->acc_dec_rest = 0;
					}
				// Inside the buffer => reduce speed
				}else{
					if( bldc_ctrl->current_target_erpm - bldc_ctrl->speed_dec > path_speed_min ){
						bldc_ctrl->current_target_erpm -= bldc_ctrl->speed_dec;
						//bldc_ctrl->acc_dec_rest = ( accdec_speed_const + bldc_ctrl->acc_dec_rest ) % bldc_ctrl->dec_time;
						dummy = accdec_speed_const + bldc_ctrl->acc_dec_rest;
						bldc_ctrl->acc_dec_rest = MOD( dummy, *bldc_ctrl->dec_time );
					}else{
						bldc_ctrl->current_target_erpm = path_speed_min;
						bldc_ctrl->acc_dec_rest = 0;
					}
				}
			// Speed is on wrong direction
			}else{

				if( bldc_ctrl->current_target_erpm + bldc_ctrl->speed_dec < 1 ){
					bldc_ctrl->current_target_erpm += bldc_ctrl->speed_dec;
					//bldc_ctrl->acc_dec_rest = ( accdec_speed_const + bldc_ctrl->acc_dec_rest ) % bldc_ctrl->dec_time;
					dummy = accdec_speed_const + bldc_ctrl->acc_dec_rest;
					bldc_ctrl->acc_dec_rest = MOD( dummy, *bldc_ctrl->dec_time );
				}else{
					bldc_ctrl->current_target_erpm = 1;
					bldc_ctrl->acc_dec_rest = 0;
				}
			}

		}else if( distance < 0 ){
			move->Meat_Target_Flag = NO;
			move->Path_Speed_ERPM_Limit = -move->digital_target_rpm_abs * bldc_ctrl->Pole_Factor;

			// Speed is right direction
			if(  bldc_ctrl->current_target_erpm <= 0 ){
				// Too far => add speed
				if( distance < -buffer ){
					if( bldc_ctrl->current_target_erpm - bldc_ctrl->speed_acc > move->Path_Speed_ERPM_Limit ){
						bldc_ctrl->current_target_erpm -= bldc_ctrl->speed_acc;
						//bldc_ctrl->acc_dec_rest = ( accdec_speed_const + bldc_ctrl->acc_dec_rest ) % bldc_ctrl->acc_time;
						dummy = accdec_speed_const + bldc_ctrl->acc_dec_rest;
						bldc_ctrl->acc_dec_rest = MOD( dummy, *bldc_ctrl->acc_time );
					}else{
						bldc_ctrl->current_target_erpm = move->Path_Speed_ERPM_Limit;
						bldc_ctrl->acc_dec_rest = 0;
					}
				// Inside the buffer => reduce speed
				}else{
					if( bldc_ctrl->current_target_erpm + bldc_ctrl->speed_dec < -path_speed_min ){
						bldc_ctrl->current_target_erpm += bldc_ctrl->speed_dec;
						//bldc_ctrl->acc_dec_rest = ( accdec_speed_const + bldc_ctrl->acc_dec_rest ) % bldc_ctrl->dec_time;
						dummy = accdec_speed_const + bldc_ctrl->acc_dec_rest;
						bldc_ctrl->acc_dec_rest = MOD( dummy, *bldc_ctrl->dec_time );
					}else{
						bldc_ctrl->current_target_erpm = -path_speed_min;
						bldc_ctrl->acc_dec_rest = 0;
					}
				}
			// Speed is wrong direction
			}else{

				if( bldc_ctrl->current_target_erpm - bldc_ctrl->speed_dec > -1 ){
					bldc_ctrl->current_target_erpm -= bldc_ctrl->speed_dec;
					//bldc_ctrl->acc_dec_rest = ( accdec_speed_const + bldc_ctrl->acc_dec_rest ) % bldc_ctrl->dec_time;
					dummy = accdec_speed_const + bldc_ctrl->acc_dec_rest;
					bldc_ctrl->acc_dec_rest = MOD( dummy, *bldc_ctrl->dec_time );
				}else{
					bldc_ctrl->current_target_erpm = -1;
					bldc_ctrl->acc_dec_rest = 0;
				}

			}
		}
	}


	if( bldc_ctrl->current_target_erpm >= 0 ){
		bldc_ctrl->current_target_rpm_abs = bldc_ctrl->current_target_erpm / bldc_ctrl->Pole_Factor;
	}else{
		bldc_ctrl->current_target_rpm_abs = -1 * bldc_ctrl->current_target_erpm / bldc_ctrl->Pole_Factor;
	}
	bldc_ctrl->target_rpm_abs = bldc_ctrl->current_target_rpm_abs;


	//dummy = ( ( bldc_ctrl->current_target_erpm / bldc_ctrl->Pole_Factor ) * encoder->MaxPos ) + move->Step_Pos_Rest;
	dummy = ( ( bldc_ctrl->current_target_erpm / bldc_ctrl->Pole_Factor ) * encoder->MaxPos * 2 ) + move->Step_Pos_Rest;	// GaoLin Motor

	move->Step_Pos = ( dummy / encoder->PosError_Const );
	move->Step_Pos_Rest = MOD( dummy, encoder->PosError_Const );

	if( ( distance > 0 && distance - move->Step_Pos < 0 ) ||
		( distance < 0 && distance - move->Step_Pos > 0 ) ){

		move->Step_Pos = distance;
	}

	//


	dummy = move->Inst_Speed_2 + bldc_ctrl->SpeedPID.Output * AC_PID_CONST / bldc_ctrl->SpeedPID.Kp_Const;


	if( dummy < 0 ){
		dummy *= -1;
	}

	limit = move->Step_Pos;

	if( limit < 0 ){
		limit *= -1;
	}

	if( limit < ALLOWED_ERPM_ERROR ){
		limit = ALLOWED_ERPM_ERROR;
	}

	dummy += limit;

	if( move->Loop_1_Target > dummy ||
		move->Loop_1_Target < -dummy ){

		move->Step_Pos = 0;
		move->Step_Pos_Rest = 0;

	}
	//

	move->Current_Target_Pos = move->Current_Target_Pos + move->Step_Pos;

	if( move->Current_Target_Pos >= encoder->MaxPos ){
		move->Current_Target_Pos -= encoder->MaxPos;
		move->Current_Target_Index++;
	}else if( move->Current_Target_Pos < 0 ){
		move->Current_Target_Pos += encoder->MaxPos;
		move->Current_Target_Index--;
	}
	#endif

}

#endif
#endif

/************************** <END OF FILE> *****************************************/
