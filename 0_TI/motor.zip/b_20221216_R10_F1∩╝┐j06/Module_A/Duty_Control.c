/*===========================================================================================

    File Name       : Duty_Control.c

    Version         : V1_00_00_a

    Built Date      : 2013/01/29

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : This file provides the functions / algorithm for duty control. 

    =========================================================================================

    History         : 

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

extern volatile Struct_BLDC_CTRL 			CG_BLDC_CTRL;
extern volatile Struct_Parameter			CG_Parameter;
extern volatile Struct_GPIO 				CG_GPIO;
extern volatile Struct_BLDC_Drive 			CG_BLDC_Drive;
extern volatile Struct_ADC 					CG_ADC;
extern volatile Struct_Pretect 				CG_Protect;
extern volatile Struct_OPMode 				CG_OPMode;
extern volatile Struct_Encoder 				CG_Encoder;
extern volatile Struct_IO_FUNC				CG_IO_Func;
extern volatile Struct_Speed 				CG_Speed;
extern volatile Struct_HWEEP				CG_HWEEP;
extern volatile Struct_Move 				CG_Move;


/*===========================================================================================
    Function Name    : calculateTargetDuty
    Input            : 1.acc_dec_mode: 0 = normal mode ( current target += acc )
									   1 = with emr acc / dec.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current duty at open loop.
//==========================================================================================*/
void calculateTargetDuty ( uint32_t acc_dec_mode )
{
	// target duty
	
	CG_BLDC_CTRL.target_duty_abs = CG_OPMode.digital_target_duty_abs;
	
	if( CG_BLDC_CTRL.target_duty_abs == CG_BLDC_Drive.period ){
		CG_BLDC_CTRL.target_duty_abs--;
	}

	if( CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_RUN ] ][ CMD_RUN ] == LOW ){
		
		CG_BLDC_CTRL.target_duty_abs = CG_BLDC_Drive.duty_min_abs;
		
		if( CG_BLDC_CTRL.current_duty > 0 ){
			CG_BLDC_CTRL.target_duty = CG_BLDC_Drive.duty_min_abs;
		}else{
			CG_BLDC_CTRL.target_duty = -1 * CG_BLDC_Drive.duty_min_abs;
		}
		
	}else{
		
		if( CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_DIR ] ][ CMD_DIR ] == DIR_CW ){
			CG_BLDC_CTRL.target_duty = CG_BLDC_CTRL.target_duty_abs;
		}else{
			CG_BLDC_CTRL.target_duty = -1 * CG_BLDC_CTRL.target_duty_abs;
		}	
		
	}
	
	
	
	
	if( CG_BLDC_CTRL.Inverse_Mode == DISABLE ||
		CG_BLDC_CTRL.Brake_Enabled == NO ||
		( CG_IO_Func.IOF_STAT_BITF & (1UL << FUNC_STOP_MODE)) == 0 ){			
		CG_BLDC_CTRL.ACC_DEC_Mode = REVERSE_NORMAL;				
	}else{
		
		if( CG_BLDC_CTRL.ACC_DEC_Mode == REVERSE_EMERGENCY ){
			
			if( CG_BLDC_CTRL.current_duty == CG_BLDC_CTRL.target_duty ){
				CG_BLDC_CTRL.ACC_DEC_Mode = REVERSE_NORMAL;
			}
			
		}else{
			
			if( CG_BLDC_CTRL.Last_Cmd_Dir != CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_DIR ] ][ CMD_DIR ] ){
				CG_BLDC_CTRL.ACC_DEC_Mode = REVERSE_EMERGENCY;
				CG_BLDC_CTRL.ReverseEmergency_Cnt = 0;
			}	
			
		}
				
	}
	
	CG_BLDC_CTRL.Last_Cmd_Dir = CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_DIR ] ][ CMD_DIR ];
	
	// decide acc/dec 
	
	switch( CG_BLDC_CTRL.ACC_DEC_Mode ){
		
		case REVERSE_NORMAL:
			
			CG_BLDC_CTRL.duty_acc = ( CG_OPMode.acc_time == 0 ? CG_BLDC_Drive.duty_resolution : ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_OPMode.acc_time );
			CG_BLDC_CTRL.duty_dec = ( CG_OPMode.dec_time == 0 ? CG_BLDC_Drive.duty_resolution : ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_OPMode.dec_time );


			if( CG_BLDC_CTRL.target_dir == DIR_CW ){
				if( CG_BLDC_CTRL.current_duty + CG_BLDC_CTRL.duty_acc < CG_BLDC_CTRL.target_duty && CG_OPMode.acc_time != 0 ){
					CG_BLDC_CTRL.current_duty += CG_BLDC_CTRL.duty_acc;		
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.acc_time;
				}else if( CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.duty_dec > CG_BLDC_CTRL.target_duty && CG_OPMode.dec_time != 0 ){
					CG_BLDC_CTRL.current_duty -= CG_BLDC_CTRL.duty_dec;
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.dec_time;
				}else{
					CG_BLDC_CTRL.current_duty = CG_BLDC_CTRL.target_duty;
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}

				if( CG_BLDC_CTRL.current_duty < 0 ){
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}

			}else{

				if( CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.duty_acc > CG_BLDC_CTRL.target_duty && CG_OPMode.acc_time != 0 ){
					CG_BLDC_CTRL.current_duty -= CG_BLDC_CTRL.duty_acc;
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.acc_time;
				}else if( CG_BLDC_CTRL.current_duty + CG_BLDC_CTRL.duty_dec < CG_BLDC_CTRL.target_duty && CG_OPMode.dec_time != 0 ){
					CG_BLDC_CTRL.current_duty += CG_BLDC_CTRL.duty_dec;
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.dec_time;
				}else{
					CG_BLDC_CTRL.current_duty = CG_BLDC_CTRL.target_duty;
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}

				if( CG_BLDC_CTRL.current_duty > 0 ){
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}
			}
			
			break;
		default:
			
			CG_BLDC_CTRL.ebrake_duty_acc = ( CG_BLDC_CTRL.ebrake_acc_time == 0 ? CG_BLDC_Drive.duty_resolution : ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_BLDC_CTRL.ebrake_acc_time );
			CG_BLDC_CTRL.ebrake_duty_dec = ( CG_BLDC_CTRL.ebrake_dec_time == 0 ? CG_BLDC_Drive.duty_resolution : ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_BLDC_CTRL.ebrake_dec_time );

			if( CG_BLDC_CTRL.target_dir == DIR_CW ){			
				if( CG_BLDC_CTRL.current_duty + CG_BLDC_CTRL.ebrake_duty_acc < CG_BLDC_CTRL.target_duty && CG_BLDC_CTRL.ebrake_acc_time != 0 ){
					CG_BLDC_CTRL.current_duty += CG_BLDC_CTRL.ebrake_duty_acc;
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_acc_time;
				}else if( CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.ebrake_duty_dec > CG_BLDC_CTRL.target_duty && CG_BLDC_CTRL.ebrake_dec_time != 0 ){
					CG_BLDC_CTRL.current_duty -= CG_BLDC_CTRL.ebrake_duty_dec;
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_dec_time;
				}else{
					CG_BLDC_CTRL.current_duty = CG_BLDC_CTRL.target_duty;
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}

				if( CG_BLDC_CTRL.current_duty < 0 ){
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}

			}else{		
				if( CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.ebrake_duty_acc > CG_BLDC_CTRL.target_duty && CG_BLDC_CTRL.ebrake_acc_time != 0 ){
					CG_BLDC_CTRL.current_duty -= CG_BLDC_CTRL.ebrake_duty_acc;
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_acc_time;
				}else if( CG_BLDC_CTRL.current_duty + CG_BLDC_CTRL.ebrake_duty_dec < CG_BLDC_CTRL.target_duty && CG_BLDC_CTRL.ebrake_dec_time != 0 ){
					CG_BLDC_CTRL.current_duty += CG_BLDC_CTRL.ebrake_duty_dec;
					CG_BLDC_CTRL.acc_dec_rest = ( CG_BLDC_Drive.duty_resolution / DUTY_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_dec_time;
				}else{
					CG_BLDC_CTRL.current_duty = CG_BLDC_CTRL.target_duty;
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}
				if( CG_BLDC_CTRL.current_duty > 0 ){
					CG_BLDC_CTRL.acc_dec_rest = 0;
				}
			}
	
			break;
		
	}
	
	
	// decide direction
	if( CG_BLDC_CTRL.current_duty > 0 ){
		CG_BLDC_CTRL.target_dir = DIR_CW;
	}else if( CG_BLDC_CTRL.current_duty < 0 ){
		CG_BLDC_CTRL.target_dir = DIR_CCW;
	}
	
	// duty output
	if( CG_BLDC_CTRL.current_duty >= CG_BLDC_Drive.period ){
		CG_BLDC_CTRL.current_duty = CG_BLDC_Drive.period;	
	}else if( CG_BLDC_CTRL.current_duty <= -1 * ( CG_BLDC_Drive.period ) ){
		CG_BLDC_CTRL.current_duty = -1 * ( CG_BLDC_Drive.period );	
	}
	
	if( CG_BLDC_CTRL.current_duty >= 0 ){
		CG_BLDC_CTRL.current_duty_abs = CG_BLDC_CTRL.current_duty;
	}else{
		CG_BLDC_CTRL.current_duty_abs = CG_BLDC_CTRL.current_duty * (-1);
	}	
	
}


/*===========================================================================================
    Function Name    : calculateBrakeDuty
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate target brake duty.
//==========================================================================================*/
void calculateBrakeDuty ( void )
{
	
	
}


/*===========================================================================================
    Function Name    : calculateTargetSpeed
    Input            : 
					   1.acc_dec_mode: 0 = normal mode ( current target += acc )
									   1 = with emr acc / dec.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current speed.
//==========================================================================================*/
void calculateTargetSpeed ( uint32_t acc_dec_mode )
{
	// target speed
	
	
	CG_BLDC_CTRL.target_rpm_abs = CG_OPMode.digital_target_rpm_abs;//60;
		
	if( CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_RUN ] ][ CMD_RUN ] == LOW ){

		if( CG_BLDC_CTRL.LockPoint == 0 ){

			CG_BLDC_CTRL.target_erpm = 0;
			CG_BLDC_CTRL.target_erpm_abs = 0;
			CG_BLDC_CTRL.target_rpm_abs = 0;
			CG_BLDC_CTRL.target_rpm = 0;

		}else{

			CG_BLDC_CTRL.target_rpm = CG_Parameter.RAM_data[ PARAMETER_SPEED ][ SPD_VR_SPD_MIN ];
			CG_BLDC_CTRL.target_rpm_abs = CG_BLDC_CTRL.target_rpm;
			CG_BLDC_CTRL.target_erpm = CG_BLDC_CTRL.target_rpm * CG_BLDC_CTRL.Pole_Factor;
			CG_BLDC_CTRL.target_erpm_abs = CG_BLDC_CTRL.target_erpm;

		}


	}else{
		
		CG_BLDC_CTRL.Lock2Point_Flag = NO;

		CG_BLDC_CTRL.target_erpm_abs = CG_BLDC_CTRL.target_rpm_abs * CG_BLDC_CTRL.Pole_Factor;
		if( CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_DIR ] ][ CMD_DIR ] == DIR_CW ){
			CG_BLDC_CTRL.target_erpm = CG_BLDC_CTRL.target_erpm_abs;
			CG_BLDC_CTRL.target_rpm  = CG_BLDC_CTRL.target_rpm_abs;
		}else{
			CG_BLDC_CTRL.target_erpm = -1 * CG_BLDC_CTRL.target_erpm_abs;
			CG_BLDC_CTRL.target_rpm  = -1 * CG_BLDC_CTRL.target_rpm_abs;
		}	
	}	
	
	if( CG_BLDC_CTRL.Inverse_Mode == DISABLE ||
		CG_BLDC_CTRL.Brake_Enabled == NO ||
		( CG_IO_Func.IOF_STAT_BITF & (1UL << FUNC_STOP_MODE)) == 0 ){			
		CG_BLDC_CTRL.ACC_DEC_Mode = REVERSE_NORMAL;				
	}else{
		
		
		
		if( CG_BLDC_CTRL.ACC_DEC_Mode == REVERSE_EMERGENCY ){
			
			if( CG_BLDC_CTRL.current_target_erpm == CG_BLDC_CTRL.target_erpm ){
				CG_BLDC_CTRL.ACC_DEC_Mode = REVERSE_NORMAL;
			}
			
		}else{
			
			if( CG_BLDC_CTRL.Last_Cmd_Dir != CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_DIR ] ][ CMD_DIR ] ){
				CG_BLDC_CTRL.ACC_DEC_Mode = REVERSE_EMERGENCY;
				CG_BLDC_CTRL.ReverseEmergency_Cnt = 0;
			}	
			
		}
				
	}
	
	CG_BLDC_CTRL.Last_Cmd_Dir = CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_DIR ] ][ CMD_DIR ];

	// decide acc/dec 
	
	
	switch( CG_BLDC_CTRL.ACC_DEC_Mode ){
	
		case REVERSE_NORMAL:

				//CG_BLDC_CTRL.speed_acc = ( CG_OPMode.acc_time == 0 ? ACCDEC_SPEED_CONST_MAX : ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_OPMode.acc_time );
				//CG_BLDC_CTRL.speed_dec = ( CG_OPMode.dec_time == 0 ? ACCDEC_SPEED_CONST_MAX : ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_OPMode.dec_time );

				if( CG_BLDC_CTRL.current_target_erpm > 0 ){		//	condition A

					if( CG_BLDC_CTRL.current_target_erpm + CG_BLDC_CTRL.speed_acc < CG_BLDC_CTRL.target_erpm && CG_OPMode.acc_time != 0 ){
						CG_BLDC_CTRL.current_target_erpm += CG_BLDC_CTRL.speed_acc;
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.acc_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.speed_acc * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;
						
					}else if( CG_BLDC_CTRL.current_target_erpm - CG_BLDC_CTRL.speed_dec > CG_BLDC_CTRL.target_erpm && CG_OPMode.dec_time != 0 ){
						CG_BLDC_CTRL.current_target_erpm -= CG_BLDC_CTRL.speed_dec;					
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.dec_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.speed_dec * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;

					}else{
					
						CG_BLDC_CTRL.current_target_erpm = CG_BLDC_CTRL.target_erpm;
						CG_BLDC_CTRL.acc_dec_rest = 0;
						
					}	


					if( CG_BLDC_CTRL.current_target_erpm <= 0 ){	// condition A-
						CG_BLDC_CTRL.acc_dec_rest = 0;

						if( CG_Speed.ecycle_rpm > SPEED_CONST &&
							( CG_BLDC_CTRL.DEC_Feature == FEATRUE_NO_BRAKE || CG_BLDC_CTRL.Brake_Enabled == NO )){

							CG_BLDC_CTRL.current_target_erpm = 1;
						}
					}


				}else{		//	condition A-

					if( CG_BLDC_CTRL.current_target_erpm - CG_BLDC_CTRL.speed_acc > CG_BLDC_CTRL.target_erpm && CG_OPMode.acc_time != 0 ){
						CG_BLDC_CTRL.current_target_erpm -= CG_BLDC_CTRL.speed_acc;
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.acc_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.speed_acc * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;
									
					}else if( CG_BLDC_CTRL.current_target_erpm + CG_BLDC_CTRL.speed_dec < CG_BLDC_CTRL.target_erpm && CG_OPMode.dec_time != 0 ){
						CG_BLDC_CTRL.current_target_erpm += CG_BLDC_CTRL.speed_dec;
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_OPMode.dec_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.speed_dec * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;

					}else{
						
						CG_BLDC_CTRL.current_target_erpm = CG_BLDC_CTRL.target_erpm;
						CG_BLDC_CTRL.acc_dec_rest = 0;
			
					}

					if( CG_BLDC_CTRL.current_target_erpm > 0 ){		//	condition A
						CG_BLDC_CTRL.acc_dec_rest = 0;

						if( CG_Speed.ecycle_rpm < -1 * SPEED_CONST &&
							( CG_BLDC_CTRL.DEC_Feature == FEATRUE_NO_BRAKE || CG_BLDC_CTRL.Brake_Enabled == NO )){

							CG_BLDC_CTRL.current_target_erpm = -1;
						}
						
					}
				}

				break;
				
		default:
			
				CG_BLDC_CTRL.ebrake_speed_acc  = ( CG_BLDC_CTRL.ebrake_acc_time  == 0 ? ACCDEC_SPEED_CONST_MAX : ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_BLDC_CTRL.ebrake_acc_time  );
				CG_BLDC_CTRL.ebrake_speed_dec  = ( CG_BLDC_CTRL.ebrake_dec_time  == 0 ? ACCDEC_SPEED_CONST_MAX : ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) / CG_BLDC_CTRL.ebrake_dec_time  );

				if( CG_BLDC_CTRL.current_target_erpm > 0 ){		// condition A
					if( CG_BLDC_CTRL.current_target_erpm + CG_BLDC_CTRL.ebrake_speed_acc < CG_BLDC_CTRL.target_erpm && CG_BLDC_CTRL.ebrake_acc_time != 0 ){
						CG_BLDC_CTRL.current_target_erpm += CG_BLDC_CTRL.ebrake_speed_acc;
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_acc_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.ebrake_speed_acc * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;
						
					}else if( CG_BLDC_CTRL.current_target_erpm - CG_BLDC_CTRL.ebrake_speed_dec > CG_BLDC_CTRL.target_erpm && CG_BLDC_CTRL.ebrake_dec_time != 0 ){
						CG_BLDC_CTRL.current_target_erpm -= CG_BLDC_CTRL.ebrake_speed_dec;
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_dec_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.ebrake_speed_dec * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;

					}else{
					
						CG_BLDC_CTRL.current_target_erpm = CG_BLDC_CTRL.target_erpm;
						CG_BLDC_CTRL.acc_dec_rest = 0;
						
					}

					if( CG_BLDC_CTRL.current_target_erpm <= 0 ){	// condition A-
						CG_BLDC_CTRL.acc_dec_rest = 0;
					}

				}else{		// condition A-
					if( CG_BLDC_CTRL.current_target_erpm - CG_BLDC_CTRL.ebrake_speed_acc > CG_BLDC_CTRL.target_erpm && CG_BLDC_CTRL.ebrake_acc_time != 0  ){
						CG_BLDC_CTRL.current_target_erpm -= CG_BLDC_CTRL.ebrake_speed_acc;
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_acc_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.ebrake_speed_acc * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;
								
					}else if( CG_BLDC_CTRL.current_target_erpm + CG_BLDC_CTRL.ebrake_speed_dec < CG_BLDC_CTRL.target_erpm && CG_BLDC_CTRL.ebrake_dec_time != 0  ){
						CG_BLDC_CTRL.current_target_erpm += CG_BLDC_CTRL.ebrake_speed_dec;
						moveSetChangeSpdFlag( YES );
						CG_BLDC_CTRL.acc_dec_rest = ( ACCDEC_SPEED_CONST + CG_BLDC_CTRL.acc_dec_rest ) % CG_BLDC_CTRL.ebrake_dec_time;
						CG_BLDC_CTRL.acc_limit = CG_BLDC_CTRL.ebrake_speed_dec * ACC_LIMIT_CONST / CG_BLDC_CTRL.Pole_Factor;
						
					}else{
						
						CG_BLDC_CTRL.current_target_erpm = CG_BLDC_CTRL.target_erpm;
						CG_BLDC_CTRL.acc_dec_rest = 0;
			
					}

					if( CG_BLDC_CTRL.current_target_erpm > 0 ){		//	condition A
						CG_BLDC_CTRL.acc_dec_rest = 0;
					}

				}
				break;
	}
		
	if( CG_BLDC_CTRL.current_target_erpm >= 0 ){
		CG_BLDC_CTRL.current_target_rpm_abs = CG_BLDC_CTRL.current_target_erpm / CG_BLDC_CTRL.Pole_Factor;
	}else{
		CG_BLDC_CTRL.current_target_rpm_abs = -1 * CG_BLDC_CTRL.current_target_erpm / CG_BLDC_CTRL.Pole_Factor;
	}	
	
	if( CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ MOTOR_FULL_SPEED ] != 0 ){	
		CG_BLDC_CTRL.pre_duty = CG_BLDC_CTRL.current_target_erpm * CG_BLDC_Drive.period / CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ MOTOR_FULL_SPEED ]  / CG_BLDC_CTRL.Pole_Factor;
	}
		
}

/*===========================================================================================
    Function Name    : calculateBrakeSpeed
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate target brake speed.
//==========================================================================================*/
void calculateBrakeSpeed ( void )
{
		
}

/*===========================================================================================
    Function Name    : currentRestraint
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Restraint current.
//==========================================================================================*/
void currentRestraint( void )
{
	// Over current
	
	int32_t duty_step;

	#define CURRENT_ERROR	( CG_ADC.Shunt_I - CG_BLDC_CTRL.torque_I )	
	#define CURRENT_ERROR_R	( CG_BLDC_CTRL.torque_I - CG_ADC.Shunt_I )
	
	CG_BLDC_CTRL.current_restraint_flag = NO;
	CG_BLDC_CTRL.current_restraint_step_duty_max = CG_BLDC_CTRL.Step_Duty_Max_Parameter * 1000;
	
	if( CG_Protect.OverPower_flag == YES ){
					
		if( CG_ADC.Power >= OVER_POWER_LIMIT ){
			
			CG_BLDC_CTRL.current_restraint_flag = YES;
			
			CG_BLDC_CTRL.current_restraint_step_duty_max = ( CG_ADC.Power - OVER_POWER_LIMIT ) * OVER_POWER_P_GAIN;
						
		}else{	
			
			CG_BLDC_CTRL.current_restraint_step_duty_max = ( OVER_POWER_LIMIT - CG_ADC.Power ) * OVER_POWER_P_GAIN;
			
		}
		
	}
		
	
	if( CG_Protect.OverLoad_flag == YES ){

		if( CG_ADC.Shunt_I >= CG_BLDC_CTRL.torque_I ){
		
			duty_step = CURRENT_ERROR * CG_BLDC_CTRL.Tq_P_Const;
			
			if( ( CG_BLDC_CTRL.current_restraint_flag == YES && duty_step > CG_BLDC_CTRL.current_restraint_step_duty_max ) ||
				( CG_BLDC_CTRL.current_restraint_flag == NO ) ){
				CG_BLDC_CTRL.current_restraint_step_duty_max = duty_step;
			}		
			CG_BLDC_CTRL.current_restraint_flag = YES;
			
		}else if( CG_BLDC_CTRL.current_restraint_flag == NO ){
						
			duty_step = CURRENT_ERROR_R * CG_BLDC_CTRL.Tq_P_Const;
			
			if( duty_step < CG_BLDC_CTRL.current_restraint_step_duty_max ){
				CG_BLDC_CTRL.current_restraint_step_duty_max = duty_step;
			}		
		}
		
	}
	
	if( CG_Protect.FWCR_flag == YES ){

		if( CG_ADC.Shunt_I >= SHUNT_I_FWP ){
			

			duty_step = ( CG_ADC.Shunt_I - SHUNT_I_FWP ) * CG_BLDC_CTRL.Tq_P_Const;
			
			if( ( CG_BLDC_CTRL.current_restraint_flag == YES && duty_step > CG_BLDC_CTRL.current_restraint_step_duty_max ) ||
				( CG_BLDC_CTRL.current_restraint_flag == NO )){
				CG_BLDC_CTRL.current_restraint_step_duty_max = duty_step;
			}
			
			CG_BLDC_CTRL.current_restraint_flag = YES;
			
		}else if( CG_BLDC_CTRL.current_restraint_flag == NO ){
					
			duty_step = ( SHUNT_I_FWP - CG_ADC.Shunt_I ) * CG_BLDC_CTRL.Tq_P_Const;
			
			if( duty_step < CG_BLDC_CTRL.current_restraint_step_duty_max ){
					  
				CG_BLDC_CTRL.current_restraint_step_duty_max = duty_step;
			}

		}

	}
	
	
	if( CG_BLDC_CTRL.current_restraint_step_duty_max > CG_BLDC_CTRL.Step_Duty_Max_Parameter * 1000 ){
		CG_BLDC_CTRL.current_restraint_step_duty_max = CG_BLDC_CTRL.Step_Duty_Max_Parameter * 1000;
	}
	
	CG_BLDC_CTRL.current_restraint_reduce_duty = CG_BLDC_CTRL.current_restraint_step_duty_max;

	//if( CG_Protect.IPM_Fault_State == HIGH ){
	if( CG_Protect.HWCR_Lock_Flag == HIGH || CG_BLDC_CTRL.current_restraint_flag == YES || CG_ADC.BusV_Clammping_Flag == YES ){
		CG_BLDC_CTRL.current_restraint_step_duty_max = 0;
	}

	
}

/*===========================================================================================
    Function Name    : reduceDuty
    Input            : 1.target_duty: target duty
					   2.step_duty : One step reduced duty
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : reduce duty
//==========================================================================================*/
void reduceDuty( int32_t* target_duty, int32_t step_duty )
{
	int32_t	step;
	static int32_t rest = 0;
	int32_t dummy;
	
	#if(0)			
	if( CG_BLDC_CTRL.current_duty > 0 ){
		
		*target_duty -= step_duty;
		
	}else if( CG_BLDC_CTRL.current_duty < 0 ){
		
		*target_duty += step_duty;
		
	}
	#else
	
	dummy = step_duty + rest;
		
	step = dummy / 1000;
	//rest = dummy % 1000;
	rest = MOD( dummy, 1000 );
	
	
	if( CG_BLDC_CTRL.current_duty > 0 ){		
		
		*target_duty -= step;
		
	}else if( CG_BLDC_CTRL.current_duty < 0 ){
		
		*target_duty += step;
		
	}
	
	#endif
	
}

/*===========================================================================================
    Function Name    : speedController_PID
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
void speedController_PID ( void )
{
	int32_t	dummy;
	int32_t acc;
	
	//====  calculate errors === //
	
	//  direct error
	if( CG_Speed.hall_int_times < 8 * CG_BLDC_CTRL.Pole_Factor  ){
		CG_BLDC_CTRL.SpdErr_Erpm = CG_BLDC_CTRL.current_target_erpm - CG_Speed.rapid_erpm;
	}else{
		CG_BLDC_CTRL.SpdErr_Erpm = CG_BLDC_CTRL.current_target_erpm - CG_Speed.ecycle_erpm;
	}
	

	// percentage error

	if( CG_BLDC_Drive.full_speed_rpm_abs != 0 ){
		if( CG_BLDC_CTRL.target_rpm_abs > CG_Speed.current_rpm_abs ){
			CG_BLDC_CTRL.SpdErr_Percentage = ( CG_BLDC_CTRL.target_rpm_abs - CG_Speed.current_rpm_abs ) * 1000 / CG_BLDC_Drive.full_speed_rpm_abs;
		}else{
			CG_BLDC_CTRL.SpdErr_Percentage = ( CG_Speed.current_rpm_abs - CG_BLDC_CTRL.target_rpm_abs ) * 1000 / CG_BLDC_Drive.full_speed_rpm_abs;
		}
	}

	
	//=== max duty step ===//
	if( CG_Speed.hall_int_times == 0 ){
		CG_BLDC_CTRL.Step_Duty_Max = 1;
	}else if( CG_BLDC_CTRL.SpdErr_Percentage > 100 ){
		CG_BLDC_CTRL.Step_Duty_Max	 = CG_BLDC_CTRL.Step_Duty_Max_Parameter * 4;
	}else if( CG_BLDC_CTRL.SpdErr_Percentage > 50 ){
		CG_BLDC_CTRL.Step_Duty_Max	 = CG_BLDC_CTRL.Step_Duty_Max_Parameter * 2;
	}else{
		CG_BLDC_CTRL.Step_Duty_Max	 = CG_BLDC_CTRL.Step_Duty_Max_Parameter;
	}

	
	if( CG_BLDC_CTRL.Step_Duty_Max > ( CG_BLDC_CTRL.current_restraint_step_duty_max / 1000 ) ){
		CG_BLDC_CTRL.Step_Duty_Max = ( CG_BLDC_CTRL.current_restraint_step_duty_max / 1000 );
	}

	
	//=== P term ===//
	dummy = CG_BLDC_CTRL.SpdErr_Erpm * CG_BLDC_CTRL.P_Const + CG_BLDC_CTRL.I_Term;

	CG_BLDC_CTRL.P_Term = dummy / FACTOR_P;
	CG_BLDC_CTRL.I_Term = MOD( dummy, FACTOR_P );
	
	//=== D term ===//
	if( CG_Speed.hall_int_times > 8 * CG_BLDC_CTRL.Pole_Factor ){
		CG_BLDC_CTRL.delta_erpm_within_hall_int = CG_Speed.smooth_erpm - CG_BLDC_CTRL.erpm_old;
	}else{
		CG_BLDC_CTRL.delta_erpm_within_hall_int = 0;
	}		
	
	CG_BLDC_CTRL.erpm_old = CG_Speed.smooth_erpm;
	

	#define BOUND_NEAR	100
	#define BOUND_FAR	200
	#define ACC_CONST_NOLIMIT	300000
	#define ACC_CONST_FAR		30000
	#define ACC_CONST_NEAR		15000//3000
	
	
	if( CG_BLDC_CTRL.SpdErr_Percentage > BOUND_FAR ){
		
		//CG_BLDC_CTRL.acc_limit = ACC_CONST_NOLIMIT;
		
	}else if( CG_BLDC_CTRL.SpdErr_Percentage > BOUND_NEAR ){
				
		CG_BLDC_CTRL.acc_limit = ACC_CONST_FAR;
			
	}else{
		CG_BLDC_CTRL.acc_limit = ACC_CONST_FAR * CG_BLDC_CTRL.SpdErr_Percentage / BOUND_NEAR;
		
		if( CG_BLDC_CTRL.acc_limit < ACC_CONST_NEAR ){
			CG_BLDC_CTRL.acc_limit = ACC_CONST_NEAR;
		}
	}

	if( CG_BLDC_CTRL.D_Const != 0 ){

		acc = CG_BLDC_CTRL.delta_erpm_within_hall_int * CG_Speed.smooth_rpm_abs;

		if( CG_BLDC_CTRL.P_Term > 0 ){

			if( acc > CG_BLDC_CTRL.acc_limit  ){

				if( CG_BLDC_CTRL.target_rpm != 0 ){
					dummy = ( -1 * CG_BLDC_CTRL.delta_erpm_within_hall_int ) * CG_BLDC_CTRL.D_Const;
					CG_BLDC_CTRL.P_Term = dummy / FACTOR_D;
					CG_BLDC_CTRL.I_Term = MOD( dummy, FACTOR_D );
				}else{
					CG_BLDC_CTRL.P_Term = 0;
					CG_BLDC_CTRL.I_Term = 0;
				}

			}else if( acc < -1 * CG_BLDC_CTRL.acc_limit ){

				dummy = ( -1 * CG_BLDC_CTRL.delta_erpm_within_hall_int * CG_BLDC_CTRL.D_Const ) + CG_BLDC_CTRL.I_Term;

				CG_BLDC_CTRL.P_Term += ( dummy / FACTOR_D );
				CG_BLDC_CTRL.I_Term = MOD( dummy, FACTOR_D );

			}

		}else if( CG_BLDC_CTRL.P_Term < 0 ){

			if( acc < -1 * CG_BLDC_CTRL.acc_limit  ){

				if( CG_BLDC_CTRL.target_rpm != 0 ){
					dummy = ( -1 * CG_BLDC_CTRL.delta_erpm_within_hall_int ) * CG_BLDC_CTRL.D_Const;
					CG_BLDC_CTRL.P_Term = dummy / FACTOR_D;
					CG_BLDC_CTRL.I_Term = MOD( dummy, FACTOR_D );
				}else{
					CG_BLDC_CTRL.P_Term = 0;
					CG_BLDC_CTRL.I_Term = 0;
				}

			}else if( acc > CG_BLDC_CTRL.acc_limit ){

				dummy = ( -1 * CG_BLDC_CTRL.delta_erpm_within_hall_int ) * CG_BLDC_CTRL.D_Const + CG_BLDC_CTRL.I_Term;

				CG_BLDC_CTRL.P_Term += ( dummy / FACTOR_D );
				CG_BLDC_CTRL.I_Term = MOD( dummy, FACTOR_D );

			}

		}
	}

	
	CG_BLDC_CTRL.Step_Duty = CG_BLDC_CTRL.P_Term;
	
	
	if( CG_BLDC_CTRL.Step_Duty > CG_BLDC_CTRL.Step_Duty_Max && CG_BLDC_CTRL.current_duty > 0 ){
	//if( CG_BLDC_CTRL.Step_Duty > CG_BLDC_CTRL.Step_Duty_Max ){
		CG_BLDC_CTRL.Step_Duty = CG_BLDC_CTRL.Step_Duty_Max;
		CG_BLDC_CTRL.I_Term = 0;
	}else if( CG_BLDC_CTRL.Step_Duty < -1 * CG_BLDC_CTRL.Step_Duty_Max && CG_BLDC_CTRL.current_duty < 0 ){
	//}else if( CG_BLDC_CTRL.Step_Duty < -1 * CG_BLDC_CTRL.Step_Duty_Max ){
		CG_BLDC_CTRL.Step_Duty = -1 * CG_BLDC_CTRL.Step_Duty_Max; 
		CG_BLDC_CTRL.I_Term = 0;
	}	
	
	CG_BLDC_CTRL.fb_duty += CG_BLDC_CTRL.Step_Duty;
	

}


/*===========================================================================================
    Function Name    : speedController_Duty
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Duty = pre_duty + fb_duty
//==========================================================================================*/
void speedController_Duty ( void )
{
	#define REVERSE_DUTY_LIMIT_1	( CG_BLDC_Drive.period * 50 / PERCENTAGE_100 )
	#define REVERSE_DUTY_LIMIT_2	( CG_BLDC_Drive.period * 500 / PERCENTAGE_100 )

	int32_t reverse_duty_limit = CG_BLDC_Drive.period - CG_BLDC_Drive.deadtime * 2 - REVERSE_DUTY_LIMIT_1;
	if( reverse_duty_limit < REVERSE_DUTY_LIMIT_2 ){
		reverse_duty_limit = REVERSE_DUTY_LIMIT_2;
	}
	
	if( CG_BLDC_CTRL.pre_duty > -CG_BLDC_Drive.duty_min_abs && CG_BLDC_CTRL.pre_duty < CG_BLDC_Drive.duty_min_abs ){
		if( CG_BLDC_CTRL.fb_duty > 0 ){
			CG_BLDC_CTRL.pre_duty = CG_BLDC_Drive.duty_min_abs;
		}else if( CG_BLDC_CTRL.fb_duty < 0 ){
			CG_BLDC_CTRL.pre_duty = -CG_BLDC_Drive.duty_min_abs;
		}else{
			CG_BLDC_CTRL.pre_duty = 0;
		}
	}
	
	
	CG_BLDC_CTRL.current_duty = CG_BLDC_CTRL.pre_duty + CG_BLDC_CTRL.fb_duty;

	//

	//#define SPEED_CONST	( 400 )
	#define CONDITION_CW_DEC  ( CG_BLDC_CTRL.current_target_erpm > 0 && CG_BLDC_CTRL.target_erpm > 0 && CG_BLDC_CTRL.current_target_erpm > CG_BLDC_CTRL.target_erpm && CG_Speed.rapid_rpm > 0 )
	#define CONDITION_CCW_DEC ( CG_BLDC_CTRL.current_target_erpm < 0 && CG_BLDC_CTRL.target_erpm < 0 && CG_BLDC_CTRL.current_target_erpm < CG_BLDC_CTRL.target_erpm && CG_Speed.rapid_rpm < 0 )
	#define CONDITION_REVERSING_TOO_FAST	( CG_Speed.ecycle_rpm_abs > SPEED_CONST )// && ( CG_BLDC_CTRL.Last_Cmd_Dir != CG_IO_Func.CMD[ CG_IO_Func.CMD_SRC[ CMD_DIR ] ][ CMD_DIR ] ) )

	if( ( CG_Speed.rapid_rpm > 0 && CG_BLDC_CTRL.current_duty < 0 ) ||
		( CG_Speed.rapid_rpm < 0 && CG_BLDC_CTRL.current_duty > 0 )	){

		//if( ( CG_BLDC_CTRL.target_rpm == 0 || CONDITION_CW_DEC || CONDITION_CCW_DEC || CONDITION_REVERSING_TOO_FAST ) &&
		//	( CG_BLDC_CTRL.DEC_Feature == FEATRUE_NO_BRAKE || CG_BLDC_CTRL.Brake_Enabled == NO ) ) {
		if( CG_BLDC_CTRL.target_rpm == 0 || CONDITION_CW_DEC || CONDITION_CCW_DEC ||
			( ( CONDITION_REVERSING_TOO_FAST ) &&
			  ( CG_BLDC_CTRL.DEC_Feature == FEATRUE_NO_BRAKE || CG_BLDC_CTRL.Brake_Enabled == NO ) ) ) {

			CG_BLDC_CTRL.current_duty = 0;

			CG_BLDC_CTRL.fb_duty = CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.pre_duty;
			CG_BLDC_CTRL.I_Term = 0;

		}else if( CG_BLDC_CTRL.current_duty > reverse_duty_limit  ){

			CG_BLDC_CTRL.current_duty = reverse_duty_limit;
			CG_BLDC_CTRL.fb_duty = CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.pre_duty;
			CG_BLDC_CTRL.I_Term = 0;

		}else if( CG_BLDC_CTRL.current_duty < -reverse_duty_limit ){

			CG_BLDC_CTRL.current_duty = -reverse_duty_limit;
			CG_BLDC_CTRL.fb_duty = CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.pre_duty;
			CG_BLDC_CTRL.I_Term = 0;

		}





	}else if( 	( CG_Speed.rapid_rpm > 0 && CG_BLDC_CTRL.current_duty > 0 ) ||
				( CG_Speed.rapid_rpm < 0 && CG_BLDC_CTRL.current_duty < 0 )	){


		if( ++CG_BLDC_CTRL.hall_check_cnt > 1000 ){
			CG_BLDC_CTRL.hall_check_cnt = 1000;
		}

	}

	if( ++CG_BLDC_CTRL.fb_cnt > 1000 ){
		CG_BLDC_CTRL.fb_cnt = 1000;
	}



	if( CG_BLDC_CTRL.current_duty >= CG_BLDC_Drive.period - 1 ){
		CG_BLDC_CTRL.current_duty = CG_BLDC_Drive.period - 1;

		CG_BLDC_CTRL.fb_duty = CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.pre_duty;

	}else if( CG_BLDC_CTRL.current_duty <= -1 * ( CG_BLDC_Drive.period - 1 ) ){
		CG_BLDC_CTRL.current_duty = -1 * ( CG_BLDC_Drive.period - 1 );

		CG_BLDC_CTRL.fb_duty = CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.pre_duty;
	}

	// decide direction

	if( CG_BLDC_CTRL.current_duty > 0 ){
		CG_BLDC_CTRL.target_dir = DIR_CW;
	}else if( CG_BLDC_CTRL.current_duty < 0 ){
		CG_BLDC_CTRL.target_dir = DIR_CCW;
	}

	// duty output
	if( CG_BLDC_CTRL.current_duty >= 0 ){
		CG_BLDC_CTRL.current_duty_abs = CG_BLDC_CTRL.current_duty;
	}else{
		CG_BLDC_CTRL.current_duty_abs = CG_BLDC_CTRL.current_duty * (-1);
	}

}
/*===========================================================================================
    Function Name    : speedController_PID_Encoder
    Input            : type: PID Type
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
void speedController_PID_Encoder ( int32_t type )
{
	int32_t dummy;
	//int32_t duty_step_limit;


	// Speed Control Loop With Torque Control Loop

	il_PID_Set_Input( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID, CG_Move.Target_Erpm );
	il_PID_Set_Feedback ( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID, CG_Move.Inst_Speed_2 );

	dummy = SHUNT_I_FWP + CG_BLDC_CTRL.Torque_Step_Rest;
	CG_BLDC_CTRL.Torque_Step = dummy / CG_BLDC_CTRL.Torque_Step_Const;
	CG_BLDC_CTRL.Torque_Step_Rest = dummy % CG_BLDC_CTRL.Torque_Step_Const;

	if( CG_BLDC_CTRL.Torque_Traj + CG_BLDC_CTRL.Torque_Step < CG_BLDC_CTRL.Torque_Limit ){
		CG_BLDC_CTRL.Torque_Traj += CG_BLDC_CTRL.Torque_Step;
	//}else if( CG_BLDC_CTRL.Torque_Traj - CG_BLDC_CTRL.Torque_Step > CG_BLDC_CTRL.Torque_Limit ){
	//	CG_BLDC_CTRL.Torque_Traj -= CG_BLDC_CTRL.Torque_Step;
	}else{
		CG_BLDC_CTRL.Torque_Traj = CG_BLDC_CTRL.Torque_Limit;
	}

	il_PID_Set_MaxMin ( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID,
						CG_BLDC_CTRL.Torque_Traj,
						-CG_BLDC_CTRL.Torque_Traj );

	switch( type ){
	case PID_TYPE_P:
		il_PID_Run_P ( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID );
		break;
	case PID_TYPE_PI:
		il_PID_Run_PI ( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID );
		break;
	case PID_TYPE_PID:
	default:
		il_PID_Run_PID ( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID );
		break;

	}

	//
	/*
	duty_step_limit = CG_BLDC_CTRL.Step_Duty_Max_Parameter;

	if( duty_step_limit > ( CG_BLDC_CTRL.current_restraint_step_duty_max / 1000 ) ){
		duty_step_limit = ( CG_BLDC_CTRL.current_restraint_step_duty_max / 1000 );
	}

	CG_Move.duty_change = il_PID_Get_Output( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID ) - CG_BLDC_CTRL.fb_duty;

	if( CG_Move.duty_change > duty_step_limit ){
		// shunt q < 0 => force = CW
		if( il_FOC_Get_Iq ( ( Struct_FOC* ) &CG_BLDC_Drive.FOC ) < 0 ){
			CG_Move.duty_change = duty_step_limit;
		}
	}else if( CG_Move.duty_change < -1 * duty_step_limit ){
		// shunt q > 0 => force = CCW
		if( il_FOC_Get_Iq ( ( Struct_FOC* ) &CG_BLDC_Drive.FOC ) > 0 ){
			CG_Move.duty_change = -1 * duty_step_limit;
		}
	}



	CG_BLDC_CTRL.fb_duty += CG_Move.duty_change;
	//CG_BLDC_CTRL.fb_duty = il_PID_Get_Output( (Struct_PID*) &CG_BLDC_CTRL.SpeedPID );


	if( CG_BLDC_CTRL.pre_duty > -CG_BLDC_Drive.duty_min_abs && CG_BLDC_CTRL.pre_duty < CG_BLDC_Drive.duty_min_abs ){
		if( CG_BLDC_CTRL.fb_duty > 0 ){
			CG_BLDC_CTRL.pre_duty = CG_BLDC_Drive.duty_min_abs;
		}else if( CG_BLDC_CTRL.fb_duty < 0 ){
			CG_BLDC_CTRL.pre_duty = -CG_BLDC_Drive.duty_min_abs;
		}else{
			CG_BLDC_CTRL.pre_duty = 0;
		}
	}

	CG_BLDC_CTRL.current_duty = CG_BLDC_CTRL.pre_duty + CG_BLDC_CTRL.fb_duty;
	
	if( CG_BLDC_CTRL.current_duty >= CG_BLDC_Drive.period - 1 ){
		CG_BLDC_CTRL.current_duty = CG_BLDC_Drive.period - 1;
		CG_BLDC_CTRL.fb_duty = CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.pre_duty;
	}else if( CG_BLDC_CTRL.current_duty <= -1 * ( CG_BLDC_Drive.period - 1 ) ){
		CG_BLDC_CTRL.current_duty = -1 * ( CG_BLDC_Drive.period - 1 );
		CG_BLDC_CTRL.fb_duty = CG_BLDC_CTRL.current_duty - CG_BLDC_CTRL.pre_duty;
	}
	
	// decide direction	
	if( CG_BLDC_CTRL.current_duty > 0 ){
		CG_BLDC_CTRL.target_dir = DIR_CW;
	}else if( CG_BLDC_CTRL.current_duty < 0 ){
		CG_BLDC_CTRL.target_dir = DIR_CCW;
	}

	// duty output
	if( CG_BLDC_CTRL.current_duty >= 0 ){
		CG_BLDC_CTRL.current_duty_abs = CG_BLDC_CTRL.current_duty;
	}else{
		CG_BLDC_CTRL.current_duty_abs = CG_BLDC_CTRL.current_duty * (-1);
	}
	*/

	
}




/************************** <END OF FILE> *****************************************/



