/*===========================================================================================
    File Name       : IDA1_BLDC_CTRL.h
    Version         : V1.00a
    Built Date      : 2019-03-04
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for BLDC motor control.
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef BLDC_CTRL_H
#define BLDC_CTRL_H
#include "Type.h"
#include "SpeedControl.h"
#include "PositionControl.h"
#include "MotorMove.h"
#include "Protect_TypeDef.h"
#include "Opearation_Mode_TypeDef.h"
#include "MotorMove_TypeDef.h"
#include "SlightPositionKeeping_TypeDef.h"

//#define LED_FLASH_PULSE_WIDTH					20      // unit : 10ms; ex : 1 => 10ms


#define CTRL_FACTOR_1							1024
#define CTRL_FACTOR_1_BITS						10

#define CTRL_FREQ_HZ							1000L	// 1000 = 1000Hz

#define SC_CC_MODE_STATE						( CG_Parameter.EEP_data[ PARAMETER_IO ][ DIO_SC_CC_MODE ] % SC_CC_MODE_NUM )

#define SET_COMMUTATION_STATE					( CG_BLDC_CTRL.Commutation = CG_BLDC_Drive.Commutation_Table[ CG_BLDC_CTRL.Target_Dir ][ CG_GPIO.HallState ] )
#define GET_COMMUTATION_STATE					( CG_BLDC_CTRL.Commutation )

#define CMD_STATE_RUN							( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] )
#define CMD_STATE_FREE							( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_FREE ] )
#define CMD_STATE_EBRAKE						( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_EBRAKE ] )
#define CMD_STATE_DIR							( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_DIR ] )

#define CONST_LOW_SPEED							30	// 30 = 30 RPM

#define RUN_CONDITION_1                         ( bldc_ctrl->IO_Func_Ptr->CMD[ SRC_ALL ][ CMD_RUN ] == HIGH )
#define RUN_CONDITION_2                         ( bldc_ctrl->Control_Mode == CTRL_POSITION )
#define SERVO_ON_CONDITION                      ( bldc_ctrl->Drive_Ptr->Sensor_Type == SENSOR_TYPE_ENCODER && bldc_ctrl->MotorStop_Behavior == MOTOR_STOP_BEHAVIOR_LOCK && bldc_ctrl->Control_Mode != CTRL_OPENLOOP )

enum{
	REVERSE_NORMAL 		= 0,
	REVERSE_EMERGENCY	= 1,
	REVERSE_METHOD_NUM 	= 2,
};

enum{
	DRIVER_EN_MODE_0			= 0,
	DRIVER_EN_MODE_1	 		= 1,
	DRIVER_EN_MODE_2	 		= 2,
	DRIVER_EN_MODE_NUM	 		= 3
};

enum{
	CTRL_CLOSELOOP_PID 		= 0,
	CTRL_OPENLOOP,
	CTRL_POSITION,

	CTRL_METHOD_NUM
};

enum{
    SPDCTRL_ALGOROTHM_PURE_PID          = 0,
    SPDCTRL_ALGOROTHM_2ND_ORDER_LOOP    = 1,
    SPDCTRL_ALGOROTHM_3RD_ORDER_LOOP    = 2,
    SPDCTRL_ALGOROTHM_NUM               = 3
};

enum{
    TOUPDATE_BIFT_SPEED = 0,
    TOUPDATE_BIFT_POSITION_HALL,
    TOUPDATE_BIFT_POSITION_ENCODER,
    TOUPDATE_BIFT_NUM
};

enum{
    MULTI_DRIVE_CMD     = 0,
    MULTI_DRIVE_DATA1   = 1,
    MULTI_DRIVE_DATA2   = 2,

    MULTI_DRIVE_NUM     = 3
};

enum{
    MULTI_DRIVE_LITE_CMD     = 0,
    MULTI_DRIVE_LITE_DATA    = 1,
    MULTI_DRIVE_LITE_NUM     = 2
};

/*===========================================================================================
    BLDC global variable data structure
//==========================================================================================*/
typedef struct{

	uint8_t		Driver_Enable_Mode;
	uint8_t     Algorithm;
	uint8_t		Control_Mode;
	uint8_t 	Inverse_Mode;						// Behavior for changing dir while running.
	uint8_t		DEC_Feature;
	uint8_t		ACC_DEC_Mode;
	uint8_t     Path_Mode;
	uint8_t     Position_Mode;
	uint8_t		MotorStop_Behavior;
	uint8_t     MDL_Enabled;
	
	int32_t		Stop_Delay_Time;
	int32_t		RealTimeCtrl_Const;

	int32_t     Duty_Compensation;

	int8_t      Dir_Def;

	//

	uint8_t 	Motor_State;                       	// Motor state: Stop, Run, Fault, and so on.
	uint32_t    Stall_Timer;

	//

	int32_t 	Stop_Delay_Cnt;
	int32_t		LockTimer;

	uint8_t		Driver_Enable_Flag;

	//uint8_t     EBrake_Flag;

	//
	
	uint8_t 	Ctrl_Updated;
	int32_t		RealTimeCtrl_Cnt;
	
	uint8_t   	InstStop_CMD;
	
	int32_t		Restart_Cnt;

	int8_t 		Commutation;                       	// UVW Output signal
	int8_t 		Target_Dir;

	int32_t		Start_Duty;

	int32_t		Target_Duty_Abs;
	int32_t		Target_Duty;
	
	int32_t     Bemf_Duty;

	int32_t     BusVRef_ADC;                        // This value = ( CTRL_REF_BUSV_VOLTAGE * ADC_MAX_VALUE / BUSV_PHYSIC_MAX )
	int32_t 	Current_Duty_Abs;
	int32_t 	Current_Duty;
	int32_t     Current_Duty_Display;
	
	uint32_t    Target_ToUpdate_BITF;
	int32_t		Target_Speed_RPM;
	int32_t		Target_Speed_RPM_Abs;
	int32_t		Target_Speed_ERPM;
	int32_t		Target_Speed_ERPM_Abs;
	
	int32_t		Current_Target_Speed_RPM;
	int32_t		Current_Target_Speed_RPM_Abs;
	int32_t		Current_Target_Speed_ERPM;
	int32_t		Current_Target_Speed_ERPM_Abs;
	
    int32_t     Current_ERPM_Abs;
    int32_t     Current_ERPM;
    int32_t     Current_RPM_Abs;
    int32_t     Current_RPM;

    int32_t     Current_Dir;

	int32_t		Emergency_Acc_Time;
	int32_t		Emergency_Dec_Time;
	int32_t     ReverseEmergency_Cnt;

	int32_t		Acc;
	int32_t		Dec;
	int32_t		AccDec_Rest;
	
	int32_t		*VR_Speed;
	int32_t		Target_Position;
	int32_t		Current_Target_Position;
	
	//
	int32_t		Ctrl_Step_Limit_Pa;
	uint8_t		Current_Restraint_Flag;
	int32_t		Current_Restraint_Step_Limit;
	int32_t		Current_Restraint_Step;
	int32_t		Current_Restraint_Step_Rest;
	
	int32_t		Torque_Limit;
	int32_t		Torque_Limit_Acc;
	int32_t		Torque_Limit_Acc_Rest;
	int32_t		Torque_Limit_Acc_Time;

	//
	int32_t     Torque_Limit_Dec;
	int32_t     Torque_Limit_Dec_Rest;
	int32_t     Torque_Limit_Dec_Time;
	//

	int32_t		Tq_Act_Time;
	int32_t		Tq_Rec_Time;
	int32_t		Stall_Time;

	//== Speed PID 
	Struct_PositionControl PositionCtrl;

	int32_t		Tq_P_Const;
	int32_t		Tq_I_Const;

	int32_t 	Path_Spd_Limit;

	int32_t		VA_Speed;
	int32_t		EN_Speed;

	// ==
	uint8_t     AlarmLED_State;
	int32_t     STO_LED_Flash_Timer;
	int32_t     WAIT_LED_Flash_Timer;

	uint8_t     PowerOn_Run_Checked;

	// ==
	uint8_t                 MultiDrive_Src;
	Struct_Motor_Analog     *ADC_Ptr;
	Struct_HallSensor       *Hall_Ptr;
	Struct_Basic_Encoder    *Encoder_Ptr;
	Struct_BLDC_Drive       *Drive_Ptr;
	Struct_IO_FUNC          *IO_Func_Ptr;
	Struct_Move             *Move_Ptr;
	Struct_Driver_Pretect   *Protect_Ptr;
	Struct_Basic_OPMode     *OpMode_Ptr;
	Struct_SPK              *SPK_Ptr;
	Struct_PI_CMD           *PI_Ptr;

	// ==
	uint8_t     Running_Flag;
	uint8_t     CS_Flag;
	uint8_t     CS_CtrlSkip_Flag;

	int32_t     TSPD;
    int32_t     N_H[ POS_DATA_NUM ];                        // Position Data high byte, IMR, MR, MA, CS...
    int32_t     N_L[ POS_DATA_NUM ];                        // Position Data low byte, IMR, MR, MA, CS...
    uint8_t     IMR_Flag;
    int32_t     Buffer_IMR_CMD;
    int32_t     IMR_SpeedInitInRPM_Abs;
    //int32_t     IMR_SpeedInitInERPM;
    int32_t     IMR_Dec_Time;

    int32_t     Capture_Index;
    int32_t     Capture_Pos;

    //
    int32_t     MultiDrive_CMD[ MULTI_DRIVE_NUM ];
    int32_t     MultiDriveLite_CMD[ MULTI_DRIVE_LITE_NUM ];

    //

    int32_t     Accelerate;
    int32_t     Decelerate;

    int32_t     Speed_Diff;
    int32_t     Speed_Diff_Abs;
    int32_t     Accelerate_Buffer;
    int32_t     Decelerate_Buffer;

    int32_t     AccDec_Step;
    int32_t     AccDec_StepRest;

    int32_t     Acc_Time_Const;
    int32_t     Dec_Time_Const;

    //
    int32_t     Hall_Angle;
    int32_t     Adjust_Angle;
    int32_t     Delta_Angle;
    int32_t     Delta_Angle_Rest;

	//
	uint32_t    Test_BITF;
	
	uint8_t     FOCTest_Flag;
	int32_t     FOCTest_Angle;

	//
	uint8_t     E_ForwardReverse_Enable;

	int8_t      Target_Dir_CMD;
    uint8_t     E_Lock_Flag;
    uint8_t     EForward_Flag;
    uint8_t     EReverse_Flag;

    uint8_t     EForward_State;
    uint8_t     EReverse_State;

    //
    uint32_t    ServoOff_Delay_TimeMs_Pa;
    uint32_t    ServoOff_Delay_TimerMs;


}Struct_BLDC_CTRL;


/*===========================================================================================
    Motor State Defines
//==========================================================================================*/
enum{
	MOTOR_STATE_STOP 		= 0,	            // Motor is stopped.
	MOTOR_STATE_STARTING	= 1,	            // Motor is in Starting procedure.
	MOTOR_STATE_RUNNING	 	= 2,	            // Motor is running.
	MOTOR_STATE_EBRAKING	= 3,	            // Motor is enmergency braking.
	MOTOR_STATE_FREEING		= 4,	            // Motor is freeing.
	MOTOR_STATE_FAULT		= 5,	            // 
	MOTOR_STATE_WAIT		= 6,	            // Motor is stopped and in parameter setting mode.
	MOTOR_STATE_MOVE		= 7,
	MOTOR_STATE_LOCK		= 8,
	MOTOR_STATE_STO         = 9,
	MOTOR_STATE_TOTALNUM	= 10
};


/*===========================================================================================
    Function Name    : variableInitial_BLDC
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_BLDC initial
//==========================================================================================*/
void variableInitial_BLDC ( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : mcGetCurrent information
    Input            : bldc_ctrl
    Return           : information
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Multi-Command
//==========================================================================================*/
int32_t mcGetCurrentSpeed ( Struct_BLDC_CTRL* bldc_ctrl );
int32_t mcGetCurrentDirection ( Struct_BLDC_CTRL* bldc_ctrl );
int32_t mcGetCurrentIndex ( Struct_BLDC_CTRL* bldc_ctrl );
int32_t mcGetCurrentPos ( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : moveIndexDisplay
    Input            : 1.bldc_ctrl
    Return           : index in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcIndexDisplay_Current( Struct_BLDC_CTRL* bldc_ctrl );
int32_t mcIndexDisplay_Target( Struct_BLDC_CTRL* bldc_ctrl );
int32_t mcIndexDisplay_CurrentTarget( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : movePosDisplay
    Input            : 1.bldc_ctrl
    Return           : pos in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t mcPosDisplay_Current( Struct_BLDC_CTRL* bldc_ctrl );
int32_t mcPosDisplay_Target( Struct_BLDC_CTRL* bldc_ctrl );
int32_t mcPosDisplay_CurrentTarget( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : mcCS
    Input            : 1.bldc_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mcCS ( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : management_StopDelayTimer
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : @1ms timer event
//==========================================================================================*/
void management_StopDelayTimer( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : calculateTargetDuty
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current duty at open loop.
//==========================================================================================*/
void calculateTargetDuty ( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : calculateTargetSpeed
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void calculateTargetSpeed ( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : bldcSpeedCtrl_Run
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void bldcSpeedCtrl_Run ( Struct_BLDC_CTRL *bldc_ctrl );

/*===========================================================================================
    Function Name    : bldcPositionCtrl_Run
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void bldcPositionCtrl_Run ( Struct_BLDC_CTRL *bldc_ctrl );

/*===========================================================================================
    Function Name    : management_TorqueLimit_StepDrive
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void management_TorqueLimit_StepDrive( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : management_TorqueLimit_FOCDrive
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void management_TorqueLimit_FOCDrive( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : management_BrakePWMDuty
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void management_BrakePWMDuty( Struct_BLDC_CTRL *bldc_ctrl );

/*===========================================================================================
    Function Name    : rtCtrl_MotorRun
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void rtCtrl_MotorRun( Struct_BLDC_CTRL *bldc_ctrl );

/*===========================================================================================
    Function Name    : rtCtrl_MotorMove
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void rtCtrl_MotorMove( Struct_BLDC_CTRL *bldc_ctrl );

/*===========================================================================================
    Function Name    : motor_state
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void motor_Stop ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Starting ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Running ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Braking ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Freeing ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Fault ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Wait ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Moving ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_Lock ( Struct_BLDC_CTRL* bldc_ctrl );
void motor_STO ( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : output_EnableOUT
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : EN_OUT funciton. Output active if current speed is over the target.
//==========================================================================================*/
void output_EnableOUT ( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : velocityArrive
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Output active if current speed meet the target.
//==========================================================================================*/
void velocityArrive( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : velocityArrive2
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :  1. Output active if current speed meet the target.
                        2. If target speed = 0, output off
//==========================================================================================*/
void velocityArrive2( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : velocityArrive_EN
    Input            : 1.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :  1. When RUN is on : if current speed meet the target => output on. Else => output off
                        2. When RUN is off : if speed is over EN-Speed => output on. Else => output off
//==========================================================================================*/
void velocityArrive_EN( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : output_Encoder_Pulse
    Input            : 1.bldc_ctrl
                       2.pos
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void output_Encoder_Pulse( Struct_BLDC_CTRL* bldc_ctrl, int32_t pos );

/*===========================================================================================
    Function Name    : call_1ms_bldc_ctrl
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void call_1ms_bldc_ctrl( Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : call_MainLoop_bldc_ctrl
    Input            : bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void call_MainLoop_bldc_ctrl( Struct_BLDC_CTRL* bldc_ctrl );


#endif

/************************** <END OF FILE> *****************************************/


