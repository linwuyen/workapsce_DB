/*===========================================================================================

    File Name       : MotorMove.c

    Version         : V1_00_10_a

    Built Date      : 2015/06/09

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : 

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_Move 							CG_Move;

volatile Struct_Move                            CG_Move_M0;
volatile Struct_Move                            CG_Move_M1;

extern volatile Struct_Encoder 					CG_Encoder;
//extern volatile Struct_BLDC_CTRL 				CG_BLDC_CTRL;
extern volatile Struct_BLDC_Drive 				CG_BLDC_Drive;
extern volatile Struct_Pretect 					CG_Protect;
extern volatile Struct_Parameter				CG_Parameter;
//extern volatile Struct_Speed 					CG_Speed;
extern volatile Struct_ADC 						CG_ADC;
extern volatile Struct_GPIO 					CG_GPIO;
extern volatile Struct_MD 						CG_MD;
extern volatile Struct_OPMode 					CG_OPMode;// Main.c global variable data structure.
/*===========================================================================================
    Function Name    : variableInitial_Move
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Move initial
//==========================================================================================*/
void variableInitial_Move( void )
{
	CG_Move.Position_Mode = POSITION_DEF_MODE_ENCODER;

	CG_Move.Target_RPM_abs = 0;
	
	CG_Move.Offset_Index = 0;
	CG_Move.Offset_Pos = 0;
	
	CG_Move.Target_Index = 0;
	CG_Move.Target_Pos = 0;
	
	CG_Move.Current_Target_Index = 0;
	CG_Move.Current_Target_Pos = 0;
	
	CG_Move.Current_Index = 0;
	CG_Move.Current_Pos = 0;
	
	CG_Move.B4Z_Index = 0;
	CG_Move.B4Z_Last_Pos = 0;
	
	CG_Move.duty_fb_old = 0;
	CG_Move.IMR_Flag = NO;
	
	CG_Move.Run2Move_Flag = NO;
	CG_Move.Lock2Move_Flag = NO;
	CG_Move.Move2Run_Flag = NO;
	
	CG_Move.JG_Step = 1;
	CG_Move.Integrated_Error = 0;

	CG_Move.Stop_Enabled = NO;

	CG_Move.Z_Processed_Flag = NO;

	CG_Move.IMR_SpeedInitInRPM = 0;
	CG_Move.IMR_SpeedInitInERPM = 0;

	CG_Move.Z_Index = 0;
	CG_Move.Z_Pos = 0;
	CG_Move.Min_Speed = 0;
		
}

/*===========================================================================================
    Function Name    : moveSetChangeSpdFlag
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveSetChangeSpdFlag( int32_t state )
{
	CG_Move.ChangeSpdFlag = state;
}


/*===========================================================================================
    Function Name    : moveResetCtrlLoop
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveResetCtrlLoop( void )
{
	CG_Move.Loop_1_Target = 0;
	CG_Move.Loop_2_Target = 0;
	CG_Move.Loop_3_Target = 0;
	CG_Move.Loop_4_Target = 0;

	CG_Move.Loop_1_Rest = 0;
	CG_Move.Loop_2_Rest = 0;
	CG_Move.Loop_3_Rest = 0;
	CG_Move.Loop_4_Rest = 0;

	CG_Move.Step_Pos = 0;
	CG_Move.Step_Pos_Rest = 0;

	CG_Move.IMR_Dec_Rest = 0;

	CG_Move.ChangeSpdFlag = YES;
	CG_Move.Meat_Target_Flag = YES;

}

/*===========================================================================================
    Function Name    : moveInitMotionData
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveInitMotionData( void )
{

	moveGetPosition();
	CG_Move.Pulse_Stamp_2 = CG_Move.Current_Pos;
	CG_Move.Pulse_Stamp_1 = CG_Move.Pulse_Stamp_2;

	CG_Move.Inst_Speed_1 = 0;
	CG_Move.Inst_Speed_2 = 0;

}
#if(1)
/*===========================================================================================
    Function Name    : moveGetCurrent information
    Input            : NULL
    Return           : information
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
int32_t moveGetCurrentSpeed ( void )
{
	return 0;//return CG_Encoder.current_10mrpm_abs;
}
int32_t moveGetCurrentDirection ( void )
{
	return 0;//return CG_Speed.current_dir;
}
int32_t moveGetCurrentIndex ( void )
{
	CG_Move.Capture_Index = CG_Move.Current_Index;
	
	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		return CG_Move.Capture_Index;
	}else{
		return 0;//return ( (int16_t)( ( ( CG_Move.Current_Index * CG_Encoder.MaxPos + CG_Move.Current_Pos ) >> 16 ) & 0xFFFF ) ) ;
	}
}

int32_t moveGetCurrentPos ( void )
{
	CG_Move.Capture_Pos = CG_Move.Current_Pos;
	
	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		return CG_Move.Capture_Pos;
	}else{
		return 0;//return ( (int16_t)( ( CG_Move.Current_Index * CG_Encoder.MaxPos + CG_Move.Current_Pos ) & 0xFFFF ) ) ;
	}
}

/*===========================================================================================
    Function Name    : moveIndexDisplay
    Input            : index in encoder form, pos in encoder form
    Return           : index in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t moveIndexDisplay( int32_t index, int32_t pos )
{
	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		return index;
	}else{
		return 0;//return ( (int16_t)( ( ( index * CG_Encoder.MaxPos + pos ) >> 16 ) & 0xFFFF ) ) ;
	}
}

/*===========================================================================================
    Function Name    : movePosDisplay
    Input            : index in encoder form, pos in encoder form
    Return           : pos in indicated form
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t movePosDisplay( int32_t index, int32_t pos )
{
	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		return pos;
	}else{
		return 0;//return ( (int16_t)( ( index * CG_Encoder.MaxPos + pos ) & 0xFFFF ) ) ;
	}
}

/*===========================================================================================
    Function Name    : moveOffset
    Input            : index : offset index
					   pos : offset pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveOffset ( int32_t index, int32_t pos )
{
#if(0)
	CG_Move.Offset_Index = CG_Move.Offset_Index + index;
	CG_Move.Offset_Pos = CG_Move.Offset_Pos + pos;
	
	if( CG_Move.Offset_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Offset_Index++;
		CG_Move.Offset_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Offset_Pos < 0 ){
		CG_Move.Offset_Index--;
		CG_Move.Offset_Pos += CG_Encoder.MaxPos;
	}
#endif
	//moveGetPosition();
	
}

/*===========================================================================================
    Function Name    : moveOffset
    Input            : index : offset index
					   pos : offset pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveCS ( int32_t index, int32_t pos )
{
#if(0)
	//int32_t current_pos;
	int32_t dummy_position;
	int32_t dummy_index;

	DINT;
	
	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		if( pos > CG_Encoder.MaxPos ){
			pos = CG_Encoder.MaxPos;
		}
	}else{

		dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

		index = dummy_position / CG_Encoder.MaxPos;
		pos = ( int16_t )( ( dummy_position % CG_Encoder.MaxPos ) & 0xFFFF );

		if( ( int16_t )pos < 0 ){
			pos	+= CG_Encoder.MaxPos;
			index --;
		}

	}

#if(0)

	current_pos = EQep1Regs.QPOSCNT;
	
	if( CG_Move.Z_Processed_Flag == YES ){
		CG_Move.Offset_Pos = current_pos - pos;
		CG_Move.B4Z_Index = 0;
		CG_Move.Offset_Index = -1 * index;
		CG_Move.B4Z_Last_Pos = current_pos;

	}else{
		moveGetPosition();
		CG_Move.Offset_Index = CG_Move.B4Z_Index - index;
		CG_Move.Offset_Pos = CG_Move.B4Z_Last_Pos - pos;
	}
	
	if( CG_Move.Offset_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Offset_Index++;
		CG_Move.Offset_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Offset_Pos < 0 ){
		CG_Move.Offset_Index--;
		CG_Move.Offset_Pos += CG_Encoder.MaxPos;
	}

	CG_Move.Current_Index = index;
	CG_Move.Current_Pos = pos;

	CG_Move.Current_Target_Index = index;
	CG_Move.Current_Target_Pos = pos;

	CG_Move.Target_Index = index;
	CG_Move.Target_Pos = pos;
#else

	// Capture_Index = Encoder_Index - Offset_Index_Old
	// Encoder_Index = Capture_Index + Offset_Index_Old
	// CS_Index = Encoder_Index - Offset_Index_New;
	// Offset_Index_New = Encoder_Index - CS_Index
	// 					= Capture_Index + Offset_Index_Old - CS_Index
	// Same Process for Pos calculation

	CG_Move.Offset_Index = CG_Move.Capture_Index + CG_Move.Offset_Index - index;
	CG_Move.Offset_Pos = CG_Move.Capture_Pos + CG_Move.Offset_Pos - pos;

	if( CG_Move.Z_Processed_Flag == YES ){

		// If Z Interrupt was processed, then keep Encoder index small ( to prevent Encoder index overflow )
		// Index = Encoder_Index - Offset_Index
		// Offset_Index = Offset_Index - Encoder_Index
		// Encoder_Index = Encoder_Index - Encoder_Index = 0

		CG_Move.Offset_Index -= CG_Move.B4Z_Index;
		CG_Move.B4Z_Index = 0;

	}

	dummy_index = CG_Move.Offset_Pos / CG_Encoder.MaxPos;

	CG_Move.Offset_Index  += dummy_index;
	CG_Move.Offset_Pos = CG_Move.Offset_Pos - ( CG_Encoder.MaxPos * dummy_index );


	moveGetPosition();

	CG_Move.Current_Target_Index = index;
	CG_Move.Current_Target_Pos = pos;

	CG_Move.Target_Index = index;
	CG_Move.Target_Pos = pos;

#endif

	EINT;   // Enable Global interrupt INTM
#endif
}

/*===========================================================================================
    Function Name    : moveGetPosition
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : When doing this fuction, make sure Interrupt is turned off
//==========================================================================================*/
void moveGetPosition ( void )
{
#if(0)
	int32_t current_pos;
	static int32_t cnt = 0;
	current_pos = EQep1Regs.QPOSCNT;
	
	if( cnt == 0 ){
		if( CG_Encoder.Z_Got_Flag == YES ){
			cnt = 1;
			moveOffset ( 0, CG_Encoder.MaxPos - CG_Encoder.LastPos_b4Z );
			if( CG_Encoder.LastIndex_b4Z == 1 ){
				//CG_Move.B4Z_Index = 1;

				if( CG_Encoder.Init_Z_State == 1 ){
					CG_Encoder.OriginPoint_Offset = CG_Encoder.LastPos_b4Z;
				}else{
					CG_Encoder.OriginPoint_Offset = CG_Encoder.MaxPos + CG_Encoder.LastPos_b4Z;
				}

				CG_Move.B4Z_Index++;
				CG_Move.B4Z_Last_Pos = 0;
			}else{
				//CG_Move.B4Z_Index = -1;

				if( CG_Encoder.Init_Z_State == 1 ){
					CG_Encoder.OriginPoint_Offset = CG_Encoder.LastPos_b4Z;
				}else{
					CG_Encoder.OriginPoint_Offset = CG_Encoder.MaxPos + CG_Encoder.LastPos_b4Z;
				}

				CG_Move.Z_Index = CG_Move.B4Z_Index + 2;
				CG_Move.Z_Pos = CG_Encoder.LastPos_b4Z;

				CG_Move.B4Z_Last_Pos = CG_Encoder.MaxPos;
			}
			CG_Move.Z_Processed_Flag = YES;
		}
	}

	if( current_pos - CG_Move.B4Z_Last_Pos > CG_Encoder.PosErrorMax_P ){
		CG_Move.B4Z_Index--;
	}else if( current_pos - CG_Move.B4Z_Last_Pos < CG_Encoder.PosErrorMax_N ){
		CG_Move.B4Z_Index++;
	}

	CG_Move.Current_Index = CG_Move.B4Z_Index - CG_Move.Offset_Index;
	CG_Move.Current_Pos = current_pos - CG_Move.Offset_Pos;
	
	
	if( CG_Move.Current_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Current_Index++;
		CG_Move.Current_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Current_Pos < 0 ){
		CG_Move.Current_Index--;
		CG_Move.Current_Pos += CG_Encoder.MaxPos;
	}
		
	CG_Move.B4Z_Last_Pos = current_pos;
#endif
}

/*===========================================================================================
    Function Name    : moveDistance
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : P2 - P1
//==========================================================================================*/
int32_t moveDistance ( int32_t P1_index, int32_t P1_pos, int32_t P2_index, int32_t P2_pos )
{
	int32_t distance = 0;
	
	//distance = ( P2_index - P1_index ) * CG_Encoder.MaxPos + ( P2_pos - P1_pos );
	
	return distance;
}


/*===========================================================================================
    Function Name    : movePositionController_PID_Encoder
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PID function
//==========================================================================================*/
void movePositionController_PID_Encoder ( void )
{

	


}

/*===========================================================================================
    Function Name    : movePathManage
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void movePathManage ( void )
{
	
}

/*===========================================================================================
    Function Name    : runPathManage
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void runPathManage ( void )
{


}

/*===========================================================================================
    Function Name    : moveRun2Move
    Input            : dir = direction, index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveRun2Move ( int32_t dir, int32_t index, int32_t pos )
{
#if(0)
	DINT;
	
	if( pos > CG_Encoder.MaxPos ){
		pos = CG_Encoder.MaxPos;
	}
	
	moveGetPosition();
		
	CG_Move.Current_Target_Index = CG_Move.Current_Index;
	CG_Move.Current_Target_Pos = CG_Move.Current_Pos;
		
	
	if( dir == DIR_CW ){
		CG_Move.Target_Index = CG_Move.Current_Index + index;
		CG_Move.Target_Pos = CG_Move.Current_Pos + pos;
	}else{
		CG_Move.Target_Index = CG_Move.Current_Index - index;
		CG_Move.Target_Pos = CG_Move.Current_Pos - pos;
	}
	
	if( CG_Move.Target_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Target_Index++;
		CG_Move.Target_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Target_Pos < 0 ){
		CG_Move.Target_Index--;
		CG_Move.Target_Pos += CG_Encoder.MaxPos;
	}
	
	CG_Move.Run2Move_Flag = YES;
	CG_BLDC_CTRL.Motor_State = MOTOR_STATE_MOVE;
	EINT;   // Enable Global interrupt INTM
#endif
}

/*===========================================================================================
    Function Name    : moveRun2Move2
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveRun2Move2 ( int32_t index, int32_t pos )
{
	DINT;
	
	moveIMR ( index, pos );
	
	CG_Move.Run2Move_Flag = YES;
	//CG_BLDC_CTRL.Motor_State = MOTOR_STATE_MOVE;
	
	EINT;   // Enable Global interrupt INTM
}


/*===========================================================================================
    Function Name    : moveLock2Move
    Input            : NULL
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveLock2Move ( void )
{
	DINT;
	moveGetPosition();
		
	CG_Move.Current_Target_Index 		= CG_Move.Current_Index;
	CG_Move.Current_Target_Pos 			= CG_Move.Current_Pos;
	
	CG_Move.Target_Index 				= CG_Move.Current_Index;
	CG_Move.Target_Pos 					= CG_Move.Current_Pos;
	
	CG_Move.Lock2Move_Flag = YES;
	//CG_BLDC_CTRL.Motor_State = MOTOR_STATE_MOVE;
	EINT;   // Enable Global interrupt INTM
}


/*===========================================================================================
    Function Name    : moveMA
    Input            : index = abs index, pos = abs pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveMA ( int32_t index, int32_t pos )
{
#if(0)
	int32_t dummy_position;

	DINT;
	
	#if(0)

	if( pos > CG_Encoder.MaxPos ){
		pos = CG_Encoder.MaxPos;
	}
	
	#else

	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		if( pos > CG_Encoder.MaxPos ){
			pos = CG_Encoder.MaxPos;
		}
	}else{

		dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

		index = dummy_position / CG_Encoder.MaxPos;
		pos = ( int16_t )( ( dummy_position % CG_Encoder.MaxPos ) & 0xFFFF );

		if( ( int16_t )pos < 0 ){
			pos	+= CG_Encoder.MaxPos;
			index --;
		}

	}

	#endif

	CG_Move.Target_Index = index;
	CG_Move.Target_Pos = pos;
	EINT;   // Enable Global interrupt INTM
#endif
}

/*===========================================================================================
    Function Name    : moveMR
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveMR ( int32_t index, int32_t pos )
{
#if(0)
	int32_t dummy_position;

	DINT;
	
	#if(0)

	if( pos > CG_Encoder.MaxPos ){
		pos = CG_Encoder.MaxPos;
	}
	
	#else

	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		if( pos > CG_Encoder.MaxPos ){
			pos = CG_Encoder.MaxPos;
		}
	}else{

		dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

		index = dummy_position / CG_Encoder.MaxPos;
		pos = ( int16_t )( ( dummy_position % CG_Encoder.MaxPos ) & 0xFFFF );

		if( ( int16_t )pos < 0 ){
			pos	+= CG_Encoder.MaxPos;
			index --;
		}

	}

	#endif

	moveGetPosition();
		
	//CG_Move.Current_Target_Index = CG_Move.Current_Index;
	//CG_Move.Current_Target_Pos = CG_Move.Current_Pos;
		
	CG_Move.Target_Index = CG_Move.Current_Target_Index + index;
	CG_Move.Target_Pos = CG_Move.Current_Target_Pos + pos;
	//CG_Move.Target_Index += index;
	//CG_Move.Target_Pos += pos;
	
	
	if( CG_Move.Target_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Target_Index++;
		CG_Move.Target_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Target_Pos < 0 ){
		CG_Move.Target_Index--;
		CG_Move.Target_Pos += CG_Encoder.MaxPos;
	}


	EINT;   // Enable Global interrupt INTM
#endif
}

/*===========================================================================================
    Function Name    : moveIMR
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void moveIMR ( int32_t index, int32_t pos )
{
#if(0)
	if( pos > CG_Encoder.MaxPos ){
		pos = CG_Encoder.MaxPos;
	}
			
	if( ( CG_Speed.current_dir == DIR_CW  && index >= 0 ) ||
		( CG_Speed.current_dir == DIR_CCW && index < 0 )	){
			
		CG_Move.Target_Index = CG_Move.Capture_Index + index;
		CG_Move.Target_Pos = CG_Move.Capture_Pos + pos;
		
	}else{
		CG_Move.Target_Index = CG_Move.Capture_Index - index;
		CG_Move.Target_Pos = CG_Move.Capture_Pos - pos;
	}
	
	if( CG_Move.Target_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Target_Index++;
		CG_Move.Target_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Target_Pos < 0 ){
		CG_Move.Target_Index--;
		CG_Move.Target_Pos += CG_Encoder.MaxPos;
	}
	

	CG_BLDC_CTRL.current_target_erpm = CG_Move.IMR_SpeedInitInERPM;
	CG_BLDC_CTRL.current_target_rpm_abs = CG_Move.IMR_SpeedInitInRPM;

	//CG_Move.Run2Move_Flag = YES;
	CG_Move.IMR_Flag = YES;
#endif
}

/*===========================================================================================
    Function Name    : moveCMA
    Input            : index = abs index, pos = abs pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveCMA ( int32_t index, int32_t pos )
{
#if(0)
	int32_t dummy_position;

	DINT;

	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		if( pos > CG_Encoder.MaxPos ){
			pos = CG_Encoder.MaxPos;
		}
	}else{

		dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

		index = dummy_position / CG_Encoder.MaxPos;
		pos = ( int16_t )( ( dummy_position % CG_Encoder.MaxPos ) & 0xFFFF );

		if( ( int16_t )pos < 0 ){
			pos	+= CG_Encoder.MaxPos;
			index --;
		}

	}

	CG_Move.Target_Index = index;
	CG_Move.Target_Pos = pos;

	if( CG_Move.Target_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Target_Index++;
		CG_Move.Target_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Target_Pos < 0 ){
		CG_Move.Target_Index--;
		CG_Move.Target_Pos += CG_Encoder.MaxPos;
	}

	//CG_Move.Run2Move_Flag = YES;

	EINT;   // Enable Global interrupt INTM
#endif

}

/*===========================================================================================
    Function Name    : moveCMR
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveCMR ( int32_t index, int32_t pos )
{
#if(0)
	int32_t dummy_position;

	DINT;

	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		if( pos > CG_Encoder.MaxPos ){
			pos = CG_Encoder.MaxPos;
		}
	}else{

		dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

		index = dummy_position / CG_Encoder.MaxPos;
		pos = ( int16_t )( ( dummy_position % CG_Encoder.MaxPos ) & 0xFFFF );

		if( ( int16_t )pos < 0 ){
			pos	+= CG_Encoder.MaxPos;
			index --;
		}

	}

	CG_Move.Target_Index = CG_Move.Current_Target_Index + index;
	CG_Move.Target_Pos = CG_Move.Current_Target_Pos + pos;


	if( CG_Move.Target_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Target_Index++;
		CG_Move.Target_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Target_Pos < 0 ){
		CG_Move.Target_Index--;
		CG_Move.Target_Pos += CG_Encoder.MaxPos;
	}
	//CG_Move.Run2Move_Flag = YES;

	EINT;   // Enable Global interrupt INTM
#endif
}

/*===========================================================================================
    Function Name    : moveCMR_AtRun
    Input            : index = related index, pos = related pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void moveCMR_AtRun ( int32_t index, int32_t pos )
{
#if(0)
	int32_t dummy_position;

	DINT;

	if( CG_Move.Position_Mode == POSITION_DEF_MODE_ENCODER ){
		if( pos > CG_Encoder.MaxPos ){
			pos = CG_Encoder.MaxPos;
		}
	}else{

		dummy_position = ( int32_t )( ( index << 16 ) | ( pos & 0xFFFF ) );

		index = dummy_position / CG_Encoder.MaxPos;
		pos = ( int16_t )( ( dummy_position % CG_Encoder.MaxPos ) & 0xFFFF );

		if( ( int16_t )pos < 0 ){
			pos	+= CG_Encoder.MaxPos;
			index --;
		}

	}

	moveGetPosition();

	CG_Move.Target_Index = CG_Move.Current_Index + index;
	CG_Move.Target_Pos = CG_Move.Current_Pos + pos;

	if( CG_Move.Target_Pos >= CG_Encoder.MaxPos ){
		CG_Move.Target_Index++;
		CG_Move.Target_Pos -= CG_Encoder.MaxPos;
	}else if( CG_Move.Target_Pos < 0 ){
		CG_Move.Target_Index--;
		CG_Move.Target_Pos += CG_Encoder.MaxPos;
	}
	//CG_Move.Run2Move_Flag = YES;

	EINT;   // Enable Global interrupt INTM
#endif
}
#endif

/************************** <END OF FILE> *****************************************/

