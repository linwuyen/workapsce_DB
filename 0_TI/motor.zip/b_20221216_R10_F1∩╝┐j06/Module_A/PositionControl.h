/*===========================================================================================

    File Name       : PositionControl.h

    Version         : V0200

    Built Date      : 2018/07/19

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef POSITION_CONTROL_H
#define POSITION_CONTROL_H
//#include "SpeedControl.h"
#include "HallSensor.h"
//#include "IncludeFiles.h"


#define POSITION_CTRL_SPEED_CONST					3000L		// 3000 = 3000 RPM
//#define POSITION_CTRL_SPEED_CONST					6500L		// positionctrl Const 1000
#define POSITION_CTRL_ACC_CONST						( POSITION_CTRL_SPEED_CONST )

#define	_1000MS_CONST								1000		// 1000 = 1000ms 
#define PATH_UPDATE_FREQUENCE_CONST					1000		// 1000 = 1000Hz



#define POSITION_CTRL_PATH_MIN_CONST				1L
#define POSITION_MEET_CONST							1L

typedef struct{

	uint8_t Meat_Target_Flag;
	uint8_t Run2Move_Flag;
	
	uint8_t Dir_Indicator;

    // Target Pos
	int32_t MaxPos;
	int32_t Target_Index;
    int32_t Target_Pos;
    int32_t Current_Target_Index;
    int32_t Current_Target_Pos;
    int32_t Pos_error;
	int32_t distance_abs;

    // Path speed
	int32_t Path_Spd_Const;
    int32_t Path_Spd_Limit;
	int32_t Path_Spd;
	int32_t Path_Acc_Time;		// Unit = 1ms
	int32_t Path_Dec_Time;		// Unit = 1ms
	int32_t Path_Buffer;

	//int32_t ERPM_Acc;
	//int32_t ERPM_Dec;
	
	int32_t PathAcc_Rest;
	int32_t PathDec_Rest;

	Struct_SpeedControl 	SpdCtrl;
    Struct_DriverMotorInfor Drive_Infor;

    int32_t Pulse_Stamp_1;
	int32_t Pulse_Stamp_2;
	int32_t Pulse_Delta;

	int32_t Inst_Speed_1;
	int32_t Inst_Speed_2;

	int32_t Inst_Acc;
	int32_t Inst_Speed_Acc_Const;

}Struct_PositionControl;

/*===========================================================================================
    Function Name    : setupInitial_PositionControl
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_PositionControl ( Struct_PositionControl* positionctrl );

/*===========================================================================================
    Function Name    : resetReg_PositionControl
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void resetReg_PositionControl ( Struct_PositionControl* positionctrl );

/*===========================================================================================
    Function Name    : positionCtrl_SetTargetPos
    Input            :  1. positionctrl
    					2. signal_position
    					3. cw_limit
    					4. ccw_limit
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void positionCtrl_SetTargetPos ( Struct_PositionControl* positionctrl, int32_t signal_position, int32_t cw_limit, int32_t ccw_limit );

/*===========================================================================================
    Function Name    : il_PositionCtrl_PositionProcess
    Input            :  1. position_ctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionCtrl_PositionProcess ( Struct_PositionControl *position_ctrl )
{

	position_ctrl->Pulse_Stamp_1 = position_ctrl->Pulse_Stamp_2;
	position_ctrl->Pulse_Stamp_2 = position_ctrl->Drive_Infor.Pos_Now;

	position_ctrl->Inst_Speed_1 = position_ctrl->Inst_Speed_2;
	position_ctrl->Pulse_Delta = position_ctrl->Pulse_Stamp_2 - position_ctrl->Pulse_Stamp_1;

	position_ctrl->Inst_Speed_2 = position_ctrl->Pulse_Delta * position_ctrl->Inst_Speed_Acc_Const;
	position_ctrl->Inst_Acc = position_ctrl->Inst_Speed_2 - position_ctrl->Inst_Speed_1;

}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_MaxPos
    Input            :  1. positionctrl
                        2. max_pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_MaxPos ( Struct_PositionControl* positionctrl, int32_t max_pos )
{
    positionctrl->MaxPos = max_pos;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Target_Index
    Input            :  1. positionctrl
                        2. index
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Target_Index ( Struct_PositionControl* positionctrl, int32_t index )
{
    positionctrl->Target_Index = index;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Target_Pos
    Input            :  1. positionctrl
                        2. pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Target_Pos ( Struct_PositionControl* positionctrl, int32_t pos )
{
	positionctrl->Target_Pos = pos;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Current_Target_Index
    Input            :  1. positionctrl
                        2. index
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Current_Target_Index ( Struct_PositionControl* positionctrl, int32_t index )
{
    positionctrl->Current_Target_Index = index;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Current_Target_Pos
    Input            :  1. positionctrl
                        2. pos
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Current_Target_Pos ( Struct_PositionControl* positionctrl, int32_t pos )
{
	positionctrl->Current_Target_Pos = pos;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Path_Spd_Const
    Input            :  1. positionctrl
                        2. spd_limit
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Path_Spd_Const ( Struct_PositionControl* positionctrl, int32_t spd_const )
{
	positionctrl->Path_Spd_Const = spd_const;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Path_Spd_Limit
    Input            :  1. positionctrl
                        2. spd_limit
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Path_Spd_Limit ( Struct_PositionControl* positionctrl, int32_t spd_limit )
{
	positionctrl->Path_Spd_Limit = spd_limit;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Path_Spd
    Input            :  1. positionctrl
                        2. spd
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Path_Spd ( Struct_PositionControl* positionctrl, int32_t spd )
{
	positionctrl->Path_Spd = spd;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Set_Path_AccDEC
    Input            :  1. positionctrl
                        2. acc_time: unit = 0.1s
                        3. dec_time: uint = 0.1s
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Set_Path_AccDEC ( Struct_PositionControl* positionctrl, int32_t acc_time, int32_t dec_time )
{
	if( acc_time < 0 ){
		acc_time = 1;
	}
	positionctrl->Path_Acc_Time = acc_time;	

	if( dec_time < 0 ){
		dec_time = 1;
	}
	positionctrl->Path_Dec_Time = dec_time;
}

/*===========================================================================================
    Function Name    : il_PositionControl_Calculate_Path_Buffer
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Calculate_Path_Buffer ( Struct_PositionControl* positionctrl )
{
    int64_t buffer;
    int64_t time;

    time = (int64_t)positionctrl->Path_Dec_Time * (int64_t)positionctrl->Path_Spd / (int64_t)positionctrl->Path_Spd_Const;
    buffer = (int64_t)positionctrl->Path_Spd * time / ( 2 * _1000MS_CONST );
    positionctrl->Path_Buffer = buffer;

}
/*===========================================================================================
    Function Name    : il_PositionControl_StepLimit
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_StepLimit ( Struct_PositionControl* positionctrl  )
{

    int32_t dummy;
    int32_t limit;

    // Speed control output could be limit by some reason ( ex: torque limit )
    // Once the output be limited, loop_1 target should also be limit ( Output = loop 1 target x PID_P )

    dummy = positionctrl->Drive_Infor.SpeedERPM + positionctrl->SpdCtrl.Output * AC_PID_CONST / positionctrl->SpdCtrl.Loop_2_SpeedPID.Kp_Const;

    if( dummy < 0 ){
        dummy *= -1;
    }

    /*
    limit = positionctrl->SpdCtrl.Target_Pos_Step * positionctrl->SpdCtrl.Loop_1_Kp;

    if( limit < 0 ){
        limit *= -1;
    }

    limit += SPDCTRL_ALLOWED_ERPM_ERROR_CONST;
    */
    limit = positionctrl->SpdCtrl.Target_Pos_Step;
    if( limit < 0 ){
        limit *= -1;
    }
    limit++;

    limit = limit * positionctrl->SpdCtrl.Loop_1_Kp;

    limit *= 2;
    limit += positionctrl->SpdCtrl.Allowed_Erpm_Error_Const;

    dummy += limit;


    if( ( positionctrl->SpdCtrl.Loop_1_Target > dummy && positionctrl->SpdCtrl.Target_Pos_Step > 0 ) ||
        ( positionctrl->SpdCtrl.Loop_1_Target < -dummy && positionctrl->SpdCtrl.Target_Pos_Step < 0 ) ){

        positionctrl->SpdCtrl.Target_Pos_Step = 0;
        positionctrl->SpdCtrl.Target_Pos_Step_Rest = 0;

    }

    //

    positionctrl->Current_Target_Pos = positionctrl->Current_Target_Pos + positionctrl->SpdCtrl.Target_Pos_Step;

}

/*===========================================================================================
    Function Name    : il_PositionControl_StepLimit_KpDownScale
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_StepLimit_KpDownScale ( Struct_PositionControl* positionctrl  )
{

    int32_t dummy;
    int32_t limit;

    // Speed control output could be limit by some reason ( ex: torque limit )
    // Once the output be limited, loop_1 target should also be limit ( Output = loop 1 target x PID_P )

    dummy = positionctrl->Drive_Infor.SpeedERPM + positionctrl->SpdCtrl.Output * AC_PID_CONST / positionctrl->SpdCtrl.Loop_2_SpeedPID.Kp_Const;

    if( dummy < 0 ){
        dummy *= -1;
    }

    /*
    limit = positionctrl->SpdCtrl.Target_Pos_Step * positionctrl->SpdCtrl.Loop_1_Kp / SPDCTRL_LOOP_1_KP_SCALE_CONST;

    if( limit < 0 ){
        limit *= -1;
    }

    limit += SPDCTRL_ALLOWED_ERPM_ERROR_CONST;
    */
    limit = positionctrl->SpdCtrl.Target_Pos_Step;
    if( limit < 0 ){
        limit *= -1;
    }
    limit++;

    limit = limit * positionctrl->SpdCtrl.Loop_1_Kp / SPDCTRL_LOOP_1_KP_SCALE_CONST;
    limit++;

    limit *= 2;
    limit += positionctrl->SpdCtrl.Allowed_Erpm_Error_Const;;

    dummy += limit;


    if( ( positionctrl->SpdCtrl.Loop_1_Target > dummy && positionctrl->SpdCtrl.Target_Pos_Step > 0 ) ||
        ( positionctrl->SpdCtrl.Loop_1_Target < -dummy && positionctrl->SpdCtrl.Target_Pos_Step < 0 ) ){

        positionctrl->SpdCtrl.Target_Pos_Step = 0;
        positionctrl->SpdCtrl.Target_Pos_Step_Rest = 0;

    }

    //

    positionctrl->Current_Target_Pos = positionctrl->Current_Target_Pos + positionctrl->SpdCtrl.Target_Pos_Step;

}

/*===========================================================================================
    Function Name    : il_PositionControl_PathRun
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_PathRun ( Struct_PositionControl* positionctrl  )
{

	int32_t	dummy;
	//int32_t limit;
	int32_t distance = 0;				// Target - Current
	int32_t	distance_abs = 0;
	int32_t buffer = positionctrl->Path_Buffer;
	int32_t spd_limit;
	//int32_t time;
	int32_t acc;
	int32_t dec;
	
	// distance
	distance = positionctrl->Target_Pos - positionctrl->Current_Target_Pos;
	distance_abs = ( distance >= 0 ? distance : -distance );
	positionctrl->distance_abs = distance_abs;

	if( distance == 0 ){

		if( positionctrl->Drive_Infor.SpeedERPM == 0 ){
			positionctrl->Meat_Target_Flag = YES;
		}
		positionctrl->Path_Spd = 0;
		positionctrl->PathAcc_Rest = 0;

	}else{

		if( distance_abs >= POSITION_MEET_CONST ){
			positionctrl->Meat_Target_Flag = NO;
		}

		// The distance for stop
		//time = positionctrl->Path_Dec_Time * positionctrl->Path_Spd / positionctrl->Path_Spd_Const;
		//buffer = positionctrl->Path_Spd * time / ( 2 * _1000MS_CONST );
		
		acc = ( positionctrl->Path_Spd_Const + positionctrl->PathAcc_Rest ) / positionctrl->Path_Acc_Time;
		dec = ( positionctrl->Path_Spd_Const + positionctrl->PathDec_Rest ) / positionctrl->Path_Dec_Time;
		positionctrl->PathAcc_Rest = ( positionctrl->Path_Spd_Const + positionctrl->PathAcc_Rest ) % positionctrl->Path_Acc_Time;
		positionctrl->PathDec_Rest = ( positionctrl->Path_Spd_Const + positionctrl->PathDec_Rest ) % positionctrl->Path_Dec_Time;
		
		if( distance > 0 ){

			positionctrl->Dir_Indicator = DIR_CW;
			
			spd_limit = positionctrl->Path_Spd_Limit;

			// Speed is on right direction
			if( positionctrl->Path_Spd >= 0 ){

				// Too far => add speed
				if( distance > buffer ){

					if( positionctrl->Path_Spd + acc < spd_limit ){
						positionctrl->Path_Spd += acc;
					}else if( positionctrl->Path_Spd - dec > spd_limit ){
						positionctrl->Path_Spd -= dec;
					}else{
						positionctrl->Path_Spd = spd_limit;
					}
				// Inside the buffer => reduce speed
				}else{
					if( positionctrl->Path_Spd - dec > POSITION_CTRL_PATH_MIN_CONST ){
						positionctrl->Path_Spd -= dec;
					}else{
						positionctrl->Path_Spd = POSITION_CTRL_PATH_MIN_CONST;
					}
				}
			// Speed is on wrong direction
			}else{

				if( positionctrl->Path_Spd + dec < 1 ){
					positionctrl->Path_Spd += dec;
				}else{
					positionctrl->Path_Spd = 1;
				}
			}

		}else if( distance < 0 ){
			
			positionctrl->Dir_Indicator = DIR_CCW;

			spd_limit = -positionctrl->Path_Spd_Limit;

			// Speed is right direction
			if(  positionctrl->Path_Spd <= 0 ){
				// Too far => add speed
				if( distance < -buffer ){
					if( positionctrl->Path_Spd - acc > spd_limit ){
						positionctrl->Path_Spd -= acc;
					}else if( positionctrl->Path_Spd + dec < spd_limit ){
						positionctrl->Path_Spd += dec;
					}else{
						positionctrl->Path_Spd = spd_limit;
					}
				// Inside the buffer => reduce speed
				}else{
					if( positionctrl->Path_Spd + dec < -POSITION_CTRL_PATH_MIN_CONST ){
						positionctrl->Path_Spd += dec;
					}else{
						positionctrl->Path_Spd = -POSITION_CTRL_PATH_MIN_CONST;
					}
				}
			// Speed is wrong direction
			}else{

				if( positionctrl->Path_Spd - dec > -1 ){
					positionctrl->Path_Spd -= dec;
				}else{
					positionctrl->Path_Spd = -1;
				}
			}
		}

		dummy = positionctrl->Path_Spd + positionctrl->SpdCtrl.Target_Pos_Step_Rest;
		positionctrl->SpdCtrl.Target_Pos_Step = ( dummy / PATH_UPDATE_FREQUENCE_CONST );
		positionctrl->SpdCtrl.Target_Pos_Step_Rest = MOD( dummy, PATH_UPDATE_FREQUENCE_CONST );

		if( ( distance > 0 && distance - positionctrl->SpdCtrl.Target_Pos_Step < 0 ) ||
			( distance < 0 && distance - positionctrl->SpdCtrl.Target_Pos_Step > 0 ) ){

			positionctrl->SpdCtrl.Target_Pos_Step = distance;
		}

		il_PositionControl_StepLimit ( positionctrl );

	}

}

/*===========================================================================================
    Function Name    : il_PositionControl_PathRun_Encoder_Advance
    Input            :  1. positionctrl
                        2. is_big_scale_flag
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_PathRun_Advance ( Struct_PositionControl* positionctrl, int32_t is_big_scale_flag  )
{

    int32_t dummy;
    //int32_t limit;
    int32_t distance = 0;               // Target - Current
    int32_t distance_abs = 0;
    int32_t buffer = positionctrl->Path_Buffer;
    int32_t spd_limit;
    //int32_t time;
    int32_t acc;
    int32_t dec;

    // distance
    //distance = positionctrl->Target_Pos - positionctrl->Current_Target_Pos;
    if( is_big_scale_flag ){
        distance = ( positionctrl->Target_Index - positionctrl->Current_Target_Index ) * positionctrl->MaxPos + ( positionctrl->Target_Pos - positionctrl->Current_Target_Pos );
    }else{
        distance = positionctrl->Target_Pos - positionctrl->Current_Target_Pos;
    }

    distance_abs = ( distance >= 0 ? distance : -distance );
    positionctrl->distance_abs = distance_abs;

    if( distance == 0 ){

        if( positionctrl->Drive_Infor.SpeedERPM == 0 ){
            positionctrl->Meat_Target_Flag = YES;
        }
        positionctrl->Path_Spd = 0;
        positionctrl->PathAcc_Rest = 0;

    }else{

        if( distance_abs >= POSITION_MEET_CONST ){
            positionctrl->Meat_Target_Flag = NO;
        }

        // The distance for stop
        //time = positionctrl->Path_Dec_Time * positionctrl->Path_Spd / positionctrl->Path_Spd_Const;
        //buffer = positionctrl->Path_Spd * time / ( 2 * _1000MS_CONST );

        acc = ( positionctrl->Path_Spd_Const + positionctrl->PathAcc_Rest ) / positionctrl->Path_Acc_Time;
        dec = ( positionctrl->Path_Spd_Const + positionctrl->PathDec_Rest ) / positionctrl->Path_Dec_Time;
        positionctrl->PathAcc_Rest = ( positionctrl->Path_Spd_Const + positionctrl->PathAcc_Rest ) % positionctrl->Path_Acc_Time;
        positionctrl->PathDec_Rest = ( positionctrl->Path_Spd_Const + positionctrl->PathDec_Rest ) % positionctrl->Path_Dec_Time;

        if( distance > 0 ){

            positionctrl->Dir_Indicator = DIR_CW;

            spd_limit = positionctrl->Path_Spd_Limit;

            // Speed is on right direction
            if( positionctrl->Path_Spd >= 0 ){

                // Too far => add speed
                if( distance > buffer ){

                    if( positionctrl->Path_Spd + acc < spd_limit ){
                        positionctrl->Path_Spd += acc;
                    }else if( positionctrl->Path_Spd - dec > spd_limit ){
                        positionctrl->Path_Spd -= dec;
                    }else{
                        positionctrl->Path_Spd = spd_limit;
                    }
                // Inside the buffer => reduce speed
                }else{
                    if( positionctrl->Path_Spd - dec > POSITION_CTRL_PATH_MIN_CONST ){
                        positionctrl->Path_Spd -= dec;
                    }else{
                        positionctrl->Path_Spd = POSITION_CTRL_PATH_MIN_CONST;
                    }
                }
            // Speed is on wrong direction
            }else{

                if( positionctrl->Path_Spd + dec < 1 ){
                    positionctrl->Path_Spd += dec;
                }else{
                    positionctrl->Path_Spd = 1;
                }
            }

        }else if( distance < 0 ){

            positionctrl->Dir_Indicator = DIR_CCW;

            spd_limit = -positionctrl->Path_Spd_Limit;

            // Speed is right direction
            if(  positionctrl->Path_Spd <= 0 ){
                // Too far => add speed
                if( distance < -buffer ){
                    if( positionctrl->Path_Spd - acc > spd_limit ){
                        positionctrl->Path_Spd -= acc;
                    }else if( positionctrl->Path_Spd + dec < spd_limit ){
                        positionctrl->Path_Spd += dec;
                    }else{
                        positionctrl->Path_Spd = spd_limit;
                    }
                // Inside the buffer => reduce speed
                }else{
                    if( positionctrl->Path_Spd + dec < -POSITION_CTRL_PATH_MIN_CONST ){
                        positionctrl->Path_Spd += dec;
                    }else{
                        positionctrl->Path_Spd = -POSITION_CTRL_PATH_MIN_CONST;
                    }
                }
            // Speed is wrong direction
            }else{

                if( positionctrl->Path_Spd - dec > -1 ){
                    positionctrl->Path_Spd -= dec;
                }else{
                    positionctrl->Path_Spd = -1;
                }
            }
        }

        dummy = positionctrl->Path_Spd + positionctrl->SpdCtrl.Target_Pos_Step_Rest;
        positionctrl->SpdCtrl.Target_Pos_Step = ( dummy / PATH_UPDATE_FREQUENCE_CONST );
        positionctrl->SpdCtrl.Target_Pos_Step_Rest = MOD( dummy, PATH_UPDATE_FREQUENCE_CONST );

        if( ( distance > 0 && distance - positionctrl->SpdCtrl.Target_Pos_Step < 0 ) ||
            ( distance < 0 && distance - positionctrl->SpdCtrl.Target_Pos_Step > 0 ) ){

            positionctrl->SpdCtrl.Target_Pos_Step = distance;
        }

        if( is_big_scale_flag ){
            il_PositionControl_StepLimit_KpDownScale ( positionctrl );
            if( positionctrl->Current_Target_Pos >= positionctrl->MaxPos ){
                positionctrl->Current_Target_Pos -= positionctrl->MaxPos;
                positionctrl->Current_Target_Index++;
            }else if( positionctrl->Current_Target_Pos < 0 ){
                positionctrl->Current_Target_Pos += positionctrl->MaxPos;
                positionctrl->Current_Target_Index--;
            }
        }else{
            il_PositionControl_StepLimit ( positionctrl );
        }

    }

}

__inline void il_PositionControl_PathRun_Advance2 ( Struct_PositionControl* positionctrl, int32_t is_big_scale_flag  )
{

    int32_t dummy;
    //int32_t limit;
    int32_t distance = 0;               // Target - Current
    int32_t distance_abs = 0;
    int32_t buffer = positionctrl->Path_Buffer;
    int32_t spd_limit;
    //int32_t time;
    int32_t acc;
    int32_t dec;

    // distance
    //distance = positionctrl->Target_Pos - positionctrl->Current_Target_Pos;
    if( is_big_scale_flag ){
        distance = ( positionctrl->Target_Index - positionctrl->Current_Target_Index ) * positionctrl->MaxPos + ( positionctrl->Target_Pos - positionctrl->Current_Target_Pos );
    }else{
        distance = positionctrl->Target_Pos - positionctrl->Current_Target_Pos;
    }

    distance_abs = ( distance >= 0 ? distance : -distance );
    positionctrl->distance_abs = distance_abs;


    if( distance_abs >= POSITION_MEET_CONST ){
        positionctrl->Meat_Target_Flag = NO;
    }

    // The distance for stop
    //time = positionctrl->Path_Dec_Time * positionctrl->Path_Spd / positionctrl->Path_Spd_Const;
    //buffer = positionctrl->Path_Spd * time / ( 2 * _1000MS_CONST );

    acc = ( positionctrl->Path_Spd_Const + positionctrl->PathAcc_Rest ) / positionctrl->Path_Acc_Time;
    dec = ( positionctrl->Path_Spd_Const + positionctrl->PathDec_Rest ) / positionctrl->Path_Dec_Time;
    positionctrl->PathAcc_Rest = ( positionctrl->Path_Spd_Const + positionctrl->PathAcc_Rest ) % positionctrl->Path_Acc_Time;
    positionctrl->PathDec_Rest = ( positionctrl->Path_Spd_Const + positionctrl->PathDec_Rest ) % positionctrl->Path_Dec_Time;

    if( distance > 0 ){

        positionctrl->Dir_Indicator = DIR_CW;

        spd_limit = positionctrl->Path_Spd_Limit;

        // Speed is on right direction
        if( positionctrl->Path_Spd >= 0 ){

            // Too far => add speed
            if( distance > buffer ){

                if( positionctrl->Path_Spd + acc < spd_limit ){
                    positionctrl->Path_Spd += acc;
                }else if( positionctrl->Path_Spd - dec > spd_limit ){
                    positionctrl->Path_Spd -= dec;
                }else{
                    positionctrl->Path_Spd = spd_limit;
                }
            // Inside the buffer => reduce speed
            }else{
                if( positionctrl->Path_Spd - dec > POSITION_CTRL_PATH_MIN_CONST ){
                    positionctrl->Path_Spd -= dec;
                }else{
                    positionctrl->Path_Spd = POSITION_CTRL_PATH_MIN_CONST;
                }
            }
        // Speed is on wrong direction
        }else{

            if( positionctrl->Path_Spd + dec < 1 ){
                positionctrl->Path_Spd += dec;
            }else{
                positionctrl->Path_Spd = 1;
            }
        }

    }else if( distance < 0 ){

        positionctrl->Dir_Indicator = DIR_CCW;

        spd_limit = -positionctrl->Path_Spd_Limit;

        // Speed is right direction
        if(  positionctrl->Path_Spd <= 0 ){
            // Too far => add speed
            if( distance < -buffer ){
                if( positionctrl->Path_Spd - acc > spd_limit ){
                    positionctrl->Path_Spd -= acc;
                }else if( positionctrl->Path_Spd + dec < spd_limit ){
                    positionctrl->Path_Spd += dec;
                }else{
                    positionctrl->Path_Spd = spd_limit;
                }
            // Inside the buffer => reduce speed
            }else{
                if( positionctrl->Path_Spd + dec < -POSITION_CTRL_PATH_MIN_CONST ){
                    positionctrl->Path_Spd += dec;
                }else{
                    positionctrl->Path_Spd = -POSITION_CTRL_PATH_MIN_CONST;
                }
            }
        // Speed is wrong direction
        }else{

            if( positionctrl->Path_Spd - dec > -1 ){
                positionctrl->Path_Spd -= dec;
            }else{
                positionctrl->Path_Spd = -1;
            }
        }
    }else{

        // Still have speed
        if( positionctrl->Path_Spd > 0 ){
            if( positionctrl->Path_Spd - dec > 0 ){
                positionctrl->Path_Spd -= dec;
            }else{
                positionctrl->Path_Spd = 0;
            }
        }else if( positionctrl->Path_Spd < 0 ){
            if( positionctrl->Path_Spd + dec < 0 ){
                positionctrl->Path_Spd += dec;
            }else{
                positionctrl->Path_Spd = 0;
            }

        }else{

            if( positionctrl->Drive_Infor.SpeedERPM == 0 ){
                positionctrl->Meat_Target_Flag = YES;
            }
            positionctrl->Path_Spd = 0;
            positionctrl->PathAcc_Rest = 0;

        }
    }

    dummy = positionctrl->Path_Spd + positionctrl->SpdCtrl.Target_Pos_Step_Rest;
    positionctrl->SpdCtrl.Target_Pos_Step = ( dummy / PATH_UPDATE_FREQUENCE_CONST );
    positionctrl->SpdCtrl.Target_Pos_Step_Rest = MOD( dummy, PATH_UPDATE_FREQUENCE_CONST );

    if( ( distance > 0 && distance - positionctrl->SpdCtrl.Target_Pos_Step < 0 ) ||
        ( distance < 0 && distance - positionctrl->SpdCtrl.Target_Pos_Step > 0 ) ){

        int32_t speed_lower_enough = positionctrl->MaxPos / 2;
        if( positionctrl->Path_Spd < speed_lower_enough &&
            positionctrl->Path_Spd > -speed_lower_enough ){
            positionctrl->SpdCtrl.Target_Pos_Step = distance;
            positionctrl->Path_Spd = 0;
            positionctrl->PathAcc_Rest = 0;
        }
    }

    if( is_big_scale_flag ){
        il_PositionControl_StepLimit_KpDownScale ( positionctrl );
        if( positionctrl->Current_Target_Pos >= positionctrl->MaxPos ){
            positionctrl->Current_Target_Pos -= positionctrl->MaxPos;
            positionctrl->Current_Target_Index++;
        }else if( positionctrl->Current_Target_Pos < 0 ){
            positionctrl->Current_Target_Pos += positionctrl->MaxPos;
            positionctrl->Current_Target_Index--;
        }
    }else{
        il_PositionControl_StepLimit ( positionctrl );
    }



}

/*===========================================================================================
    Function Name    : il_PositionControl_Run
    Input            :  1. positionctrl
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Run ( Struct_PositionControl* positionctrl )
{
    int32_t dummy;
    int32_t step;


    // Get pos change between step and step
    positionctrl->Pos_error = positionctrl->Current_Target_Pos - positionctrl->Drive_Infor.Pos_Now;
	//positionctrl->Pos_error = positionctrl->Target_Pos - positionctrl->Drive_Infor.Pos_Now;

    // To get loop 1 target ( It is sub-speed control target speed )
    dummy = positionctrl->Pos_error * positionctrl->SpdCtrl.Loop_1_Kp;
    positionctrl->SpdCtrl.Loop_1_Target = dummy;
    //positionctrl->SpdCtrl.Loop_1_Rest = MOD( dummy, SPDCTRL_SCALE_CONST );

    // Sub-speed control loop
    positionctrl->SpdCtrl.Loop_2_SpeedPID.Input = positionctrl->SpdCtrl.Loop_1_Target;
    positionctrl->SpdCtrl.Loop_2_SpeedPID.Feedback = positionctrl->Drive_Infor.SpeedERPM;

    if( positionctrl->Meat_Target_Flag ){
    	il_PID_Run_PI ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    }else{
    	il_PID_Run_P ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    	il_PID_CLR_I_Term ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    	//il_PID_Run_PI ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    }

    // Step Limit
    step = positionctrl->SpdCtrl.Loop_2_SpeedPID.Output - positionctrl->SpdCtrl.Output;

    if( step > positionctrl->SpdCtrl.Loop_2_StepLimit ){
        step = positionctrl->SpdCtrl.Loop_2_StepLimit;
    }else if( step < -positionctrl->SpdCtrl.Loop_2_StepLimit ){
        step = -positionctrl->SpdCtrl.Loop_2_StepLimit;
    }

    positionctrl->SpdCtrl.Output += step;

}

/*===========================================================================================
    Function Name    : il_PositionControl_Run_Advance
    Input            :  1. positionctrl
                        2. is_big_scale_flag
    Return           : NULL
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
__inline void il_PositionControl_Run_Advance  ( Struct_PositionControl* positionctrl, int32_t is_big_scale_flag )
{
    int32_t dummy;
    int32_t step;

    #define ERROR_INDEX_LIMIT   10
    // Get pos change between step and step
    if( is_big_scale_flag ){
        dummy = positionctrl->Current_Target_Index - positionctrl->Drive_Infor.Index_Now;
        if( dummy > ERROR_INDEX_LIMIT ){
            dummy = ERROR_INDEX_LIMIT;
        }else if( dummy < -ERROR_INDEX_LIMIT ){
            dummy = -ERROR_INDEX_LIMIT;
        }
        positionctrl->Pos_error = dummy * positionctrl->MaxPos + ( positionctrl->Current_Target_Pos - positionctrl->Drive_Infor.Pos_Now );
    }else{
        positionctrl->Pos_error = positionctrl->Current_Target_Pos - positionctrl->Drive_Infor.Pos_Now;
    }

    // To get loop 1 target ( It is sub-speed control target speed )
    dummy = positionctrl->Pos_error * positionctrl->SpdCtrl.Loop_1_Kp / SPDCTRL_LOOP_1_KP_SCALE_CONST;
    positionctrl->SpdCtrl.Loop_1_Target = dummy;
    positionctrl->SpdCtrl.Loop_1_Rest = MOD( dummy, SPDCTRL_LOOP_1_KP_SCALE_CONST );

    // Sub-speed control loop
    positionctrl->SpdCtrl.Loop_2_SpeedPID.Input = positionctrl->SpdCtrl.Loop_1_Target;
    positionctrl->SpdCtrl.Loop_2_SpeedPID.Feedback = positionctrl->Drive_Infor.SpeedERPM;

    if( positionctrl->Meat_Target_Flag ){
    	il_PID_Run_PI ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    }else{
    	il_PID_Run_P ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    	il_PID_CLR_I_Term ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    	//il_PID_Run_PI ( &positionctrl->SpdCtrl.Loop_2_SpeedPID );
    }

    // Step Limit
    step = positionctrl->SpdCtrl.Loop_2_SpeedPID.Output - positionctrl->SpdCtrl.Output;

    if( step > positionctrl->SpdCtrl.Loop_2_StepLimit ){
        step = positionctrl->SpdCtrl.Loop_2_StepLimit;
    }else if( step < -positionctrl->SpdCtrl.Loop_2_StepLimit ){
        step = -positionctrl->SpdCtrl.Loop_2_StepLimit;
    }

    positionctrl->SpdCtrl.Output += step;

}

#endif

/************************** <END OF FILE> *****************************************/
