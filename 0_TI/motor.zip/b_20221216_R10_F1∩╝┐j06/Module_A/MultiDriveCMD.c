/*===========================================================================================
    File Name       : MultiDriveCMD.c
    Built Date      : 2021-06-10
	Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for BLDC motor control.			
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

extern volatile Struct_ComProtocol_01       CG_ComProtocol_01;

/*===========================================================================================
    Function Name    : com_CMD_RESET
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
static uint8_t com_CMD_RESET ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    uint32_t fault_bitf;

    fault_bitf = bldc_ctrl->Protect_Ptr->Fault_BITF;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        fault_bitf == 0 ){

        bldc_ctrl->Protect_Ptr->ToReset = YES;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }

}

/*===========================================================================================
    Function Name    : com_CMD_BRAKE
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
static uint8_t com_CMD_BRAKE ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        bldc_ctrl->Motor_State != MOTOR_STATE_WAIT &&
        bldc_ctrl->Motor_State != MOTOR_STATE_STO  ){

        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_FREE_BIT) |
                                      _BIT(SRC_MULTI_DRIVE_START_STOP_BIT));

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_CS
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command CS processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_CS ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    //uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    #define CS_CONDITION_1  ( bldc_ctrl->Motor_State == MOTOR_STATE_MOVE && bldc_ctrl->Current_RPM_Abs < CONST_LOW_SPEED )
    #define CS_CONDITION_2  ( bldc_ctrl->Motor_State != MOTOR_STATE_MOVE )

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( CS_CONDITION_1 || CS_CONDITION_2 ) ){

        //CG_ComProtocol_01.CS_Flag[ index ] = YES;
        //CG_ComProtocol_01.N_H[ index ][ POS_CS ] = CG_ComProtocol_01.Data1[ index ];
        //CG_ComProtocol_01.N_L[ index ][ POS_CS ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->CS_Flag = YES;
        bldc_ctrl->N_H[ POS_CS ] = data1;
        bldc_ctrl->N_L[ POS_CS ] = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_FREE
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command FREE processing routine.
                       FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_FREE ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION ){

        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) |
                                      _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );
        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_FREE_BIT) );

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_SVON
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command SVON (Servo ON) processing routine.
                       FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_SVON ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION ){

        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_FREE_BIT) |
                                      _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_KEYSWITCH_BIT) );

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }

}

/*===========================================================================================
    Function Name    : com_CMD_SVOFF
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The Multi command SVOFF processing routine.
                       FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_SVOFF ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION ){

        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_KEYSWITCH_BIT) );

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_IMR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command IMR processing routine.
                       FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_IMR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING || bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ) &&
        bldc_ctrl->Current_Target_Speed_RPM_Abs != 0 ){
        //bldc_ctrl->Current_RPM_Abs != 0 ){

        //bldc_ctrl->IMR_SpeedInitInRPM_Abs =  bldc_ctrl->Current_RPM_Abs;
        bldc_ctrl->IMR_SpeedInitInRPM_Abs = bldc_ctrl->Current_Target_Speed_RPM_Abs;

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_IMR_BIT) );
        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_BIT) | _BIT( SRC_MULTI_DRIVE_STOP_MODE_BIT ) );

        //CG_ComProtocol_01.N_H[ index ][ POS_IMR ] = CG_ComProtocol_01.Data1[ index ];
        //CG_ComProtocol_01.N_L[ index ][ POS_IMR ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->N_H[ POS_IMR ] = data1;
        bldc_ctrl->N_L[ POS_IMR ] = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_MR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command MR processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_MR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ) &&
        bldc_ctrl->Current_RPM_Abs < CONST_LOW_SPEED &&
        bldc_ctrl->IMR_Flag == NO ){

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_MR_BIT) );
        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_BIT) | _BIT( SRC_MULTI_DRIVE_STOP_MODE_BIT ) );

        //CG_ComProtocol_01.N_H[ index ][ POS_MR ] = CG_ComProtocol_01.Data1[ index ];
        //CG_ComProtocol_01.N_L[ index ][ POS_MR ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->N_H[ POS_MR ] = data1;
        bldc_ctrl->N_L[ POS_MR ] = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }

}

/*===========================================================================================
    Function Name    : com_CMD_MA
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command MA processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_MA ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ) &&
        bldc_ctrl->Current_RPM_Abs < CONST_LOW_SPEED &&
        bldc_ctrl->IMR_Flag == NO ){

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_MA_BIT) );
        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_BIT) | _BIT( SRC_MULTI_DRIVE_STOP_MODE_BIT ) );

        //CG_ComProtocol_01.N_H[ index ][ POS_MA ] = CG_ComProtocol_01.Data1[ index ];
        //CG_ComProtocol_01.N_L[ index ][ POS_MA ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->N_H[ POS_MA ] = data1;
        bldc_ctrl->N_L[ POS_MA ] = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_CMA
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command MA processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_CMA ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING || bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ) &&
        bldc_ctrl->IMR_Flag == NO ){

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_CMA_BIT) );
        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_BIT) | _BIT( SRC_MULTI_DRIVE_STOP_MODE_BIT ) );

        //CG_ComProtocol_01.N_H[ index ][ POS_MA ] = CG_ComProtocol_01.Data1[ index ];
        //CG_ComProtocol_01.N_L[ index ][ POS_MA ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->N_H[ POS_MA ] = data1;
        bldc_ctrl->N_L[ POS_MA ] = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_CMR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command CMR processing routine.
                       Condition check, FUNC flags set, TPOS update.
//==========================================================================================*/
static uint8_t com_CMD_CMR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING || bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ) &&
        bldc_ctrl->IMR_Flag == NO ){

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_CMR_BIT) );
        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_BIT) | _BIT( SRC_MULTI_DRIVE_STOP_MODE_BIT ) );

        //CG_ComProtocol_01.N_H[ index ][ POS_MR ] = CG_ComProtocol_01.Data1[ index ];
        //CG_ComProtocol_01.N_L[ index ][ POS_MR ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->N_H[ POS_MR ] = data1;
        bldc_ctrl->N_L[ POS_MR ] = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_JG0
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JG0 processing routine.
                       Condition check, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JG0 ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING || bldc_ctrl->Motor_State == MOTOR_STATE_MOVE ) ){

        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) );
        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_STOP_BIT) );

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_JGF
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JGF processing routine.
                       Condition check, FUNC flags set, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JGF ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        bldc_ctrl->Motor_State != MOTOR_STATE_WAIT &&
        bldc_ctrl->Motor_State != MOTOR_STATE_STO &&
        bldc_ctrl->Motor_State != MOTOR_STATE_FAULT &&
        bldc_ctrl->Motor_State != MOTOR_STATE_FREEING &&
        bldc_ctrl->IMR_Flag == NO ){

        io_ValClr_DI_XN_BITF( io_src, ( _BIT(SRC_MULTI_DRIVE_CW_CCW_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_STOP_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) ) );

        io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
        //CG_ComProtocol_01.TSPD[ index ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->TSPD = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_JGR
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JGR processing routine.
                       Condition check, FUNC flags set, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JGR ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        bldc_ctrl->Motor_State != MOTOR_STATE_WAIT &&
        bldc_ctrl->Motor_State != MOTOR_STATE_STO &&
        bldc_ctrl->Motor_State != MOTOR_STATE_FAULT &&
        bldc_ctrl->Motor_State != MOTOR_STATE_FREEING &&
        bldc_ctrl->IMR_Flag == NO ){

        io_ValClr_DI_XN_BITF( io_src, ( _BIT(SRC_MULTI_DRIVE_STOP_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) ) );

        io_ValSet_DI_XN_BITF( io_src, (_BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_CW_CCW_BIT)) );
        //CG_ComProtocol_01.TSPD[ index ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->TSPD = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_JGS
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JGS processing routine.
                       Condition check, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JGS ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    //uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING ){

        //CG_ComProtocol_01.TSPD[ index ] = CG_ComProtocol_01.Data2[ index ];
        bldc_ctrl->TSPD = data2;

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_JG
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command JG processing routine.
                       Condition check, TSPD update.
//==========================================================================================*/
static uint8_t com_CMD_JG ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;
    int16_t spd;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        bldc_ctrl->Motor_State != MOTOR_STATE_WAIT &&
        bldc_ctrl->Motor_State != MOTOR_STATE_STO &&
        bldc_ctrl->Motor_State != MOTOR_STATE_FAULT &&
        bldc_ctrl->Motor_State != MOTOR_STATE_FREEING ){

        bldc_ctrl->IMR_Flag = NO;

        spd = (int16_t)data2;

        if( spd > 0 ){
            io_ValClr_DI_XN_BITF( io_src, ( _BIT(SRC_MULTI_DRIVE_CW_CCW_BIT) |
                                            _BIT(SRC_MULTI_DRIVE_STOP_BIT) |
                                            _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) |
                                            _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) ) );

            io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
            //CG_ComProtocol_01.TSPD[ index ] = spd;
            bldc_ctrl->TSPD = spd;




        }else if( spd < 0 ){
            io_ValClr_DI_XN_BITF( io_src, ( _BIT(SRC_MULTI_DRIVE_STOP_BIT) |
                                            _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) |
                                            _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) ) );

            io_ValSet_DI_XN_BITF( io_src, (_BIT(SRC_MULTI_DRIVE_START_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_CW_CCW_BIT)) );
            //CG_ComProtocol_01.TSPD[ index ] = -spd;
            bldc_ctrl->TSPD = -spd;
        }else{
            io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) |
                                          _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) |
                                          _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );

            io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_STOP_BIT) );
        }

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_STOP
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      : The Multi command STOP processing routine.
                       Condition check, FUNC flags set
//==========================================================================================*/
static uint8_t com_CMD_STOP ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t return_value = 0;
    uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION &&
        ( bldc_ctrl->Motor_State == MOTOR_STATE_RUNNING || bldc_ctrl->Motor_State == MOTOR_STATE_MOVE  ) ){

        io_ValClr_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
        io_ValSet_DI_XN_BITF( io_src, (_BIT(SRC_MULTI_DRIVE_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT)) );

        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : com_CMD_NetIO
    Input            : 1.bldc_ctrl
                       2.data1
                       3.data2
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw; Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
static uint8_t com_CMD_NetIO ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data1, int32_t data2 )
{
    //uint8_t io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->Control_Mode == CTRL_POSITION ){
        CG_ComProtocol_01.COM_IO_Xn_BITF = data2;
        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : mdCMD_Execute
    Input            : 1.bldc_ctrl
                       2.cmd
                       3.data1
                       4.data2
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
//==========================================================================================*/
uint8_t mdCMD_Execute ( Struct_BLDC_CTRL *bldc_ctrl, int32_t cmd, int32_t data1, int32_t data2 )
{
    uint8_t lc_IsCmdOk = 1;

    switch( cmd ){
        case MULTI_CMD_STOP:
            lc_IsCmdOk &= com_CMD_STOP( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_JGF:
            lc_IsCmdOk &= com_CMD_JGF( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_JGR:
            lc_IsCmdOk &= com_CMD_JGR( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_JGS:
            lc_IsCmdOk &= com_CMD_JGS( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_JG0:
            lc_IsCmdOk &= com_CMD_JG0( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_JG:
            lc_IsCmdOk &= com_CMD_JG( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_FREE:
            lc_IsCmdOk &= com_CMD_FREE( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_SVON:
            lc_IsCmdOk &= com_CMD_SVON( bldc_ctrl, data1, data2 );
            break;
        case MULTI_CMD_SVOFF:
            lc_IsCmdOk &= com_CMD_SVOFF( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_RST:
            lc_IsCmdOk &= com_CMD_RESET( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_BRAKE:
            lc_IsCmdOk &= com_CMD_BRAKE( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_IMR:
            lc_IsCmdOk &= com_CMD_IMR( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_MR:
            lc_IsCmdOk &= com_CMD_MR( bldc_ctrl, data1, data2 );
            break;

        case MULTI_CMD_MA:
            lc_IsCmdOk &= com_CMD_MA( bldc_ctrl, data1, data2 );
            break;
        case MULTI_CMD_CMR:
            lc_IsCmdOk &= com_CMD_CMR( bldc_ctrl, data1, data2 );
            break;
        case MULTI_CMD_CMA:
            lc_IsCmdOk &= com_CMD_CMA( bldc_ctrl, data1, data2 );
            break;
        case MULTI_CMD_CS:
            lc_IsCmdOk &= com_CMD_CS( bldc_ctrl, data1, data2 );
            break;
        case MULTI_CMD_NETIO:
            lc_IsCmdOk &= com_CMD_NetIO( bldc_ctrl, data1, data2 );
            break;
        //Do Nothing command. Unconditional pass.
        case MULTI_CMD_NULL:
            lc_IsCmdOk &= 1;
            break;

        // inValid command
        default:
            lc_IsCmdOk = 0;
            break;
    }

    return lc_IsCmdOk;

}





/************************** <END OF FILE> *****************************************/
