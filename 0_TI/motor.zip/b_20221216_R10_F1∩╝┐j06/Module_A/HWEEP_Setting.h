/*===========================================================================================
    File Name       : HWEEP_Setting.h
	Built Date      : 2014-07-29
    Version         : V1.00a 
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : 1. This file provides the functions of accessing HWEEP to the predefined ram.
	
	Module required:  - EEP_Setting: For EEP Data access.
					  - LPC11XX_I2C: Used by EEP_Setting for I2C BUS access.
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef HW_EEP_SETTING_H
#define HW_EEP_SETTING_H

/*===========================================================================================
   HWEEP Defines
//==========================================================================================*/
#define HWEEP_CODE_VER			86
#define HW_EEP_BLOCK_SIZE		32
#define HW_WATCH_DATA_NUM       32

#define HW_EEP_ADDRESS_BASE		7168

#define HW_EEP_B1_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*0	  // Block 1
#define HW_EEP_B2_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*1     // Block 2
#define HW_EEP_B3_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*2     // Block 3
#define HW_EEP_B4_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*3     // Block 4
#define HW_EEP_B5_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*4     // Block 5
#define HW_EEP_B6_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*5     // Block 6
#define HW_EEP_B7_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*6     // Block 7
#define HW_EEP_B8_ADDRESS	HW_EEP_ADDRESS_BASE + HW_EEP_BLOCK_SIZE*7     // Block 8
//#define HW_EEP_S1_ADDRESS	HW_EEP_BLOCK1_ADDRESS	// B1 + B2
//#define HW_EEP_S2_ADDRESS  	HW_EEP_BLOCK3_ADDRESS   	// B3 + B4
//#define HW_EEP_S3_ADDRESS  	HW_EEP_BLOCK5_ADDRESS   	// B5 ~ B8

#define HWEEP_HWE_CV_ADDRESS	0
#define HWEEP_PN_CV_ADDRESS		1
#define HWEEP_PN_ADDRESS		2

#define HWEEP_HWVER_ADDRESS		( HW_EEP_B2_ADDRESS + 16 )

#define ENG_PAGE_IBIKE_INDEX                7
#define ENG_PAGE_ENGINEER_INDEX			    8
#define ENG_PAGE_MPT_INDEX					9
#define ENG_PAGE_ADC_INDEX					10

#define HW_VER_LENGTH			1


enum{
	HW_VER_0	= 0,
	HW_VER_A	= 1,
	HW_VER_B	= 2,
	HW_VER_C	= 3,
	HW_VER_D	= 4,
	HW_VER_E	= 5,
	HW_VER_NUM	= 6
};


/*===========================================================================================
   HWEEP Info Defines
//==========================================================================================*/
enum {
	HWEEP_IDX_BUSV1         =  0,
	HWEEP_IDX_BUSV2         =  1,
	
	HWEEP_IDX_M0_SHUNT_I_U_OFFSET   = 2,
    HWEEP_IDX_M0_SHUNT_I_U_H        = 3,
    HWEEP_IDX_M0_SHUNT_I_V_OFFSET   = 4,
    HWEEP_IDX_M0_SHUNT_I_V_H        = 5,
    HWEEP_IDX_M0_SHUNT_I_W_OFFSET   = 6,
    HWEEP_IDX_M0_SHUNT_I_W_H        = 7,

	HWEEP_IDX_M1_SHUNT_I_U_OFFSET	= 8,
	HWEEP_IDX_M1_SHUNT_I_U_H		= 9,
	HWEEP_IDX_M1_SHUNT_I_V_OFFSET	= 10,
	HWEEP_IDX_M1_SHUNT_I_V_H		= 11,
	HWEEP_IDX_M1_SHUNT_I_W_OFFSET	= 12,
	HWEEP_IDX_M1_SHUNT_I_W_H		= 13,
	
	HWEEP_IDX_AD0_L0        = 16,
	HWEEP_IDX_AD0_H0        = 17,
	HWEEP_IDX_AD0_L1        = 18,
	HWEEP_IDX_AD0_H1        = 19,
	
	HWEEP_IDX_AD1_L0        = 22,
	HWEEP_IDX_AD1_H0        = 23,
	HWEEP_IDX_AD1_L1        = 24,
	HWEEP_IDX_AD1_H1        = 25,
	
	HWEEP_IDX_UVP 			= 48,
	HWEEP_IDX_UVPR 			= 49,
	HWEEP_IDX_OVP 			= 50,
	HWEEP_IDX_OVPR 			= 51,
	
	HWEEP_IDX_PWR_MAX		= 52,
	HWEEP_IDX_PWR_OB        = 53,
	HWEEP_IDX_PWR_RS        = 54,
	HWEEP_IDX_PWR_P_GAIN    = 55,
	
	HWEEP_IDX_I_MAX			= 56,
	HWEEP_IDX_FWP			= 56,
	HWEEP_IDX_I_OB        	= 57,
	HWEEP_IDX_I_RS        	= 58,
	
	HWEEP_IDX_TQ_MAX		= 59,
	HWEEP_IDX_TQ_OB        	= 60,
	HWEEP_IDX_TQ_RS        	= 61,

	HWEEP_IDX_HWP			= 63,
	HWEEP_IDX_TQ_RATE		= 62,
	HWEEP_IDX_DRIVE_TYPE	= 64,
	HWEEP_IDX_DEAD_TIME		= 65,
	HWEEP_IDX_PWM_FREQUENCE	= 66,
	HWEEP_IDX_MOSOT_TYPE	= 67,
	HWEEP_IDX_MOSOT_VALUE	= 68,
	HWEEP_IDX_MOSOT_REC		= 69,
	HWEEP_IDX_PGA_INDEX		= 70,
	HWEEP_IDX_CTRIP_PRESCALE = 71,
	HWEEP_IDX_NEG_HWP_EN	= 72,	// Negative HWOCP Enable
	HWEEP_IDX_HALL_FILTER	= 73,

	HWEEP_IDX_TOL			= 80
};

/*===========================================================================================
   HWEEP Negative HWOCP Enable / Disable
//==========================================================================================*/
enum{
	HWEEP_NEG_HWP_DIS		= 0,
	HWEEP_NEG_HWP_EN		= 1,
	HWEEP_NEG_HWP_NUM		= 2
};

typedef struct{
	
	uint8_t 	HW_Code_Ver[1];
	int32_t 	HW_Ver[ HW_VER_LENGTH ];	// Hardware Ver
	
//	int32_t		Attribute_2Bits_Field[2];	// 2bits as one attribute. tollay 16 attribute. see Geat's Note #6 P.118
											// To match with communication use 2 int.	
	// Numberic H.W. settings
//	int			_1_InputVoltage;			// Input Voltage 
//	int			_2_RatedPower;				// Power of the driver
//	int			_3_MaxMultiplier;			// Power Max multiplier of the driver
//	int			_4_IPM;						// IPM current
//	int			_5_CapValue;				// The value of capacitor
//	int			_6_CapVoltage;				// The allowable voltage of the capacitor
//	int			_7_CapNumber;				// The Number of capacitor
//	int			_8_Bridge_I;				// The rating current of the bridge
//	int			_9_Bridge_V;				// The allowable voltage of the bridge
//	int			_10_Shunt_R;				// The value of shunt resisotr
//	int			_11_Fuse_I;					// Break current of the fuse
	//int32_t		Read_HW_INFO[16];
	int32_t		HW_Info[ HWEEP_IDX_TOL ];
	int32_t 	WatchData[ HW_WATCH_DATA_NUM ];

}Struct_HWEEP;


/*===========================================================================================
    Function Name    : readTotalHWEEP
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : readTotalHWEEP
//==========================================================================================*/
void readTotalHWEEP( void );

/*===========================================================================================
    Function Name    : readHWEEP
    Input            : 1. *hweep_ver: hweep_ver ram
					   2. *pn_ver: part number ver
					   3. *pn: part number ram
					   4. pn_chars: number of chars of part number
					   5. *sn: SN ram
					   6. sn_chars: number of chars of SN
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Read data from HW EEP.
					   Include: HWEEP_CODE_VER, PART_NUM_CODE_VER, Part Number, S/N,
								1 byte Info, 2 byte Info
//==========================================================================================*/
void readHWEEP( uint8_t *hweep_ver, uint8_t *pn_ver, uint8_t *pn, const uint8_t pn_chars, uint8_t *sn, const uint8_t sn_chars );

/*===========================================================================================
    Function Name    : writeHWEEP_CV
    Input            : 1. data: data to write HWEEP.
					   2. addr: communication address to determine HWEEP_CV(1) or PN_CV(3)
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  HWEEP_CODE_VER, PART_NUM_CODE_VER
//==========================================================================================*/
uint8_t writeHWEEP_CV ( const uint8_t data, const uint8_t addr );

/*===========================================================================================
    Function Name    : writeHWEEP_PN
    Input            : 1. data: data to write HWEEP.
					   2. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  PN
//==========================================================================================*/
uint8_t writeHWEEP_PN ( const uint8_t *data, const uint8_t data_num );

/*===========================================================================================
    Function Name    : writeHWEEP_SN
    Input            : 1. data: data to write HWEEP.
					   2. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  SN
//==========================================================================================*/
uint8_t writeHWEEP_SN ( const uint8_t *data, const uint8_t data_num );

/*===========================================================================================
    Function Name    : writeHW_Ver
    Input            : 1. data: data to write HWEEP.
					   2. addr: communication address
					   3. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t writeHW_Ver ( const int32_t *data, const uint8_t addr, const uint8_t data_num );

/*===========================================================================================
    Function Name    : readHW_Ver
    Input            : 1. hweep
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void readHW_Ver ( Struct_HWEEP *hweep );

/*===========================================================================================
    Function Name    : writeHWEEP_Info
    Input            : 1. data: data to write HWEEP. (2 byte data)
					   2. addr: communication address
					   3. data_num: data quantity from communication.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Write data to HW EEP:  Info
//==========================================================================================*/
uint8_t writeHWEEP_Info ( const int32_t *data, const uint8_t addr, const uint8_t data_num );

/*===========================================================================================
    Function Name    : hweep_WatchUpdate
    Input            : 1. page_sel: page select
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update HWEEP Watch data
//==========================================================================================*/
void hweep_WatchUpdate ( const int32_t page_sel );

#endif

/************************** <END OF FILE> *****************************************/
