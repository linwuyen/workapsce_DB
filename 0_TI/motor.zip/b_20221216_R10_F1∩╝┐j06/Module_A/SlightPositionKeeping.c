/*===========================================================================================

    File Name       : SlightPositionKeeping.c

    Version         : V1_00_00_a

    Built Date      : 2016/08/31

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"


volatile Struct_SPK 									CG_SPK_M0;
//volatile Struct_SPK                                     CG_SPK_M1;
//extern volatile Struct_BLDC_CTRL 						CG_BLDC_CTRL;
//extern volatile Struct_BLDC_Drive 						CG_BLDC_Drive;
extern volatile Struct_BLDC_Drive                   CG_BLDC_Drive_M0;
//extern volatile Struct_BLDC_Drive                   CG_BLDC_Drive_M1;
//extern volatile Struct_Speed 							CG_Speed;
extern volatile Struct_HWEEP							CG_HWEEP;
extern volatile Struct_ADC 								CG_ADC;
extern volatile Struct_Parameter						CG_Parameter;
extern volatile Struct_Pretect 							CG_Protect;
//extern volatile Struct_PhaseAdv 						CG_PhaseAdv;
extern volatile Struct_MD                               CG_MD;                              // Main.c global variable data structure.


/*===========================================================================================
    Function Name    : setupInitial_SPK
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_SPK( void )
{
    variableInitial_SPK ( (Struct_SPK*)&CG_SPK_M0 );
    //variableInitial_SPK ( (Struct_SPK*)&CG_SPK_M1 );

    CG_SPK_M0.Start = &setupSPK_PWM_Start_M0;
    //CG_SPK_M1.Start = &setupSPK_PWM_Start_M1;

    CG_SPK_M0.Stop = &setupSPK_PWM_Stop_M0;
    //CG_SPK_M1.Stop = &setupSPK_PWM_Stop_M1;
}

/*===========================================================================================
    Function Name    : variableInitial_SPK
    Input            : spk
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_SPK ( Struct_SPK* spk )
{
    spk->Tq_Restraint_flag = NO;
}


/*===========================================================================================
    Function Name    : resetReg_SPK
    Input            : spk
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_SPK reset
//==========================================================================================*/
void resetReg_SPK ( Struct_SPK* spk )
{
    spk->Hall_Lock_pointer = HALL_LOCK_STARTING_POINT;
    spk->Current_Target_Tq = 0;
    spk->Lock_Timer = 0;
    spk->Hall_Lock_pointer_Abs = spk->Hall_Lock_pointer;
    spk->Hall_Lock_pointer_Abs_Old = spk->Hall_Lock_pointer_Abs;
    spk->Hall_Lock_pointer_Trend = HALL_LOCK_POINT_TREND_ACC;
    spk->Tq_AccDec_Rest = 0;
}

/*===========================================================================================
    Function Name    : calculateTargetCurrent_SPK
    Input            : spk
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current target torque when motor is in SPK.
//==========================================================================================*/
void calculateTargetCurrent_SPK ( Struct_SPK* spk )
{
    // target duty

    if( spk->Hall_Lock_pointer >= SPK_LIMIT_RANGE ){
        spk->Hall_Lock_pointer = SPK_LIMIT_RANGE;
    }else if( spk->Hall_Lock_pointer <= -SPK_LIMIT_RANGE ){
        spk->Hall_Lock_pointer = -SPK_LIMIT_RANGE;
    }


    if( spk->Hall_Lock_pointer == 0 ){

        spk->Hall_Lock_pointer_Abs = spk->Hall_Lock_pointer;
        spk->Hall_Lock_pointer_Effect = spk->Hall_Lock_pointer_Abs;
        if( spk->Moved_Flag == YES ){
            spk->Target_Tq = SHUNT_I_FWP * spk->Tq_Percentage_1 / SPK_100_PERCENT;
        }else{
            spk->Target_Tq = 0;
        }
    }else{
        spk->Target_Tq = SHUNT_I_FWP * spk->Tq_Percentage_2 / SPK_100_PERCENT;
        spk->Hall_Lock_pointer_Abs = spk->Hall_Lock_pointer;
        if( spk->Hall_Lock_pointer_Abs < 0 ){
            spk->Hall_Lock_pointer_Abs *= -1;
        }

        if( spk->Hall_Lock_pointer_Trend == HALL_LOCK_POINT_TREND_ACC ){
            spk->Hall_Lock_pointer_Effect = spk->Hall_Lock_pointer_Abs;
        }else{
            spk->Hall_Lock_pointer_Effect = spk->Hall_Lock_pointer_Abs + 1;
        }

        spk->Target_Tq = spk->Target_Tq * spk->Hall_Lock_pointer_Effect / SPK_LIMIT_RANGE;
    }

    if( spk->Hall_Lock_pointer_Abs > spk->Hall_Lock_pointer_Abs_Old ){
        spk->Hall_Lock_pointer_Trend = HALL_LOCK_POINT_TREND_ACC;
    }else if( spk->Hall_Lock_pointer_Abs < spk->Hall_Lock_pointer_Abs_Old ){
        spk->Hall_Lock_pointer_Trend = HALL_LOCK_POINT_TREND_DEC;
    }

    spk->Hall_Lock_pointer_Abs_Old = spk->Hall_Lock_pointer_Abs;

    if( spk->Target_Tq < 0 ){
        spk->Target_Tq *= -1;
    }

    // decide acc/dec
    spk->Tq_Acc = ( TORQUE_1A_CONST + spk->Tq_AccDec_Rest ) / spk->Tq_AccDec_Time;
    spk->Tq_Dec = ( TORQUE_1A_CONST + spk->Tq_AccDec_Rest ) / spk->Tq_AccDec_Time;

    if( spk->Current_Target_Tq + spk->Tq_Acc < spk->Target_Tq ){
        spk->Current_Target_Tq += spk->Tq_Acc;
        spk->Tq_AccDec_Rest = ( TORQUE_1A_CONST + spk->Tq_AccDec_Rest ) % spk->Tq_AccDec_Time;
    }else if( spk->Current_Target_Tq - spk->Tq_Dec > spk->Target_Tq ){
        spk->Current_Target_Tq -= spk->Tq_Dec;
        spk->Tq_AccDec_Rest = ( TORQUE_1A_CONST + spk->Tq_AccDec_Rest ) % spk->Tq_AccDec_Time;
    }else{
        spk->Current_Target_Tq = spk->Target_Tq;
        spk->Tq_AccDec_Rest = 0;
    }
}

/*===========================================================================================
    Function Name    : currentRestraint_SPK
    Input            : 1.spk
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Restraint current.
//==========================================================================================*/
void currentRestraint_SPK( Struct_SPK* spk, Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t restraint_step;
    int32_t restraint_step_limit = bldc_ctrl->Ctrl_Step_Limit_Pa * CTRL_FACTOR_1;
    int32_t dummy;
    Struct_Driver_Pretect   *protect;
    Struct_Motor_Analog     *adc;
    protect = bldc_ctrl->Protect_Ptr;
    adc = bldc_ctrl->ADC_Ptr;


    if( spk->Hall_Lock_pointer_Trend == HALL_LOCK_POINT_TREND_ACC && adc->Shunt_I < spk->Current_Target_Tq ){ // Just left zero point
        restraint_step = bldc_ctrl->Drive_Ptr->Period * SPK_STEP_DUTY_FAST / 5000;
    }else{
        restraint_step = bldc_ctrl->Drive_Ptr->Period * SPK_STEP_DUTY / 5000;
    }

    if( restraint_step < 1 ){
        restraint_step = 1;
    }

    //
    bldc_ctrl->Current_Restraint_Flag = NO;

    if( protect->OverPower_flag == YES ){
        if( adc->Power >= OVER_POWER_LIMIT ){
            bldc_ctrl->Current_Restraint_Flag = YES;
            restraint_step = ( adc->Power - OVER_POWER_LIMIT ) * OVER_POWER_P_GAIN;
        }else{
            restraint_step_limit = ( OVER_POWER_LIMIT - adc->Power ) * OVER_POWER_P_GAIN + bldc_ctrl->Current_Restraint_Step_Rest;
        }
    }

    bldc_ctrl->Torque_Limit = bldc_ctrl->OpMode_Ptr->Torque_Limit;

    if( protect->OverLoad_flag == YES ){

        if( adc->Shunt_I >= bldc_ctrl->Torque_Limit ){
            dummy = ( adc->Shunt_I - bldc_ctrl->Torque_Limit ) * bldc_ctrl->Tq_P_Const;
            if( ( bldc_ctrl->Current_Restraint_Flag == YES && dummy > restraint_step ) ||
                ( bldc_ctrl->Current_Restraint_Flag == NO ) ){
                restraint_step = dummy;
            }
            bldc_ctrl->Current_Restraint_Flag = YES;

        }else if( bldc_ctrl->Current_Restraint_Flag == NO ){
            dummy = ( bldc_ctrl->Torque_Limit - adc->Shunt_I ) * bldc_ctrl->Tq_P_Const;
            if( dummy < restraint_step_limit ){
                restraint_step_limit = dummy;
            }
        }
    }

    if( spk->Tq_Restraint_flag == YES ){
        if( adc->Shunt_I >= spk->Current_Target_Tq ){
            dummy = ( adc->Shunt_I -  spk->Current_Target_Tq ) * bldc_ctrl->Tq_P_Const;
            if( ( bldc_ctrl->Current_Restraint_Flag == YES && dummy > restraint_step ) ||
                ( bldc_ctrl->Current_Restraint_Flag == NO ) ){
                restraint_step = dummy;
            }
            bldc_ctrl->Current_Restraint_Flag = YES;
        }else if( bldc_ctrl->Current_Restraint_Flag == NO ){
            dummy = (  spk->Current_Target_Tq - adc->Shunt_I ) * bldc_ctrl->Tq_P_Const;
            if( dummy < restraint_step_limit ){
                restraint_step_limit = dummy;
            }
        }
    }

    if( protect->FWCR_flag == YES ){
        if( adc->Shunt_I >= OVER_CURRENT_LIMIT ){
            dummy = ( adc->Shunt_I - OVER_CURRENT_LIMIT ) * bldc_ctrl->Tq_P_Const;
            if( ( bldc_ctrl->Current_Restraint_Flag == YES && dummy > restraint_step ) ||
                ( bldc_ctrl->Current_Restraint_Flag == NO ) ){
                restraint_step = dummy;
            }
            bldc_ctrl->Current_Restraint_Flag = YES;

        }else if( bldc_ctrl->Current_Restraint_Flag == NO ){
            dummy = ( OVER_CURRENT_LIMIT - adc->Shunt_I ) * bldc_ctrl->Tq_P_Const;
            if( dummy < restraint_step_limit ){
                restraint_step_limit = dummy;
            }

        }

    }

    if( bldc_ctrl->Current_Restraint_Flag == YES ){
        dummy = restraint_step + bldc_ctrl->Current_Restraint_Step_Rest;
        bldc_ctrl->Current_Restraint_Step = dummy / CTRL_FACTOR_1;
    }else{
        if( protect->HWCR_Lock_Flag == HIGH ){
            dummy = 0;
        }else{
            dummy = restraint_step_limit + bldc_ctrl->Current_Restraint_Step_Rest;
        }
        bldc_ctrl->Current_Restraint_Step_Limit = dummy / CTRL_FACTOR_1;
    }

    bldc_ctrl->Current_Restraint_Step_Rest = dummy % CTRL_FACTOR_1;

}

/*===========================================================================================
    Function Name    : reduceDuty_SPK
    Input            : 1.target_duty: target duty
					   2.step_duty : One step reduced duty
    Return           : Null
    Programmer       : Andrew.an@trumman.com.tw
    Description      : reduce duty
//==========================================================================================*/
void reduceDuty_SPK( int32_t* target_duty, int32_t step_duty )
{
    if( *target_duty > 0 ){
        *target_duty -= step_duty;
    }else if( *target_duty < 0 ){
        *target_duty += step_duty;
    }
}

/*===========================================================================================
    Function Name    : dutyController_SPK
    Input            : 1.spk
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Andrew.An@trumman.com.tw
    Description      : SPK duty Controller
//==========================================================================================*/
void dutyController_SPK ( Struct_SPK* spk, Struct_BLDC_CTRL* bldc_ctrl )
{
    int32_t dummy;
    Struct_Motor_Analog     *adc;
    adc = bldc_ctrl->ADC_Ptr;

    if( spk->Hall_Lock_pointer_Trend == HALL_LOCK_POINT_TREND_ACC && adc->Shunt_I < spk->Current_Target_Tq ){ // Just left zero point
        dummy = bldc_ctrl->Drive_Ptr->Period * SPK_STEP_DUTY_FAST +  bldc_ctrl->AccDec_Rest;
    }else{
        dummy = bldc_ctrl->Drive_Ptr->Period * SPK_STEP_DUTY +  bldc_ctrl->AccDec_Rest;
    }

    spk->Step_duty_Max = dummy / SPK_STEP_CONST;
    bldc_ctrl->AccDec_Rest = dummy % SPK_STEP_CONST;

    if( spk->Step_duty_Max > bldc_ctrl->Current_Restraint_Step_Limit ){
        spk->Step_duty_Max = bldc_ctrl->Current_Restraint_Step_Limit;
    }

    if( spk->Step_duty_Max < 1 ){
        spk->Step_duty_Max = 1;
    }

    bldc_ctrl->Current_Duty_Abs += spk->Step_duty_Max;

    if( bldc_ctrl->Current_Duty_Abs >= bldc_ctrl->Drive_Ptr->Period ){
        bldc_ctrl->Current_Duty_Abs = bldc_ctrl->Drive_Ptr->Period - 1;
    }

}

/*===========================================================================================
    Function Name    : management_LockPointer
    Input            : 1.spk
                       2.direction
    Return           : Null
    Programmer       : Andrew.An@trumman.com.tw
    Description      : management_LockPointer
//==========================================================================================*/
void management_LockPointer( Struct_SPK* spk, int32_t direction )
{
	if( direction == DIR_CW ){
		spk->Hall_Lock_pointer++;
	}else if( direction == DIR_CCW ){
		spk->Hall_Lock_pointer--;
	}

}


/*===========================================================================================
    Function Name    : setSPK_Parameter
    Input            : 1.spk
                       2.acc_dec_time: acc and dec time ( unit: 1ms; 1A/xms )
    				   3.tq1: torque 1
    				   4.tq2: torque 2
    				   5.brake_time
    Return           : Null
    Programmer       : Andrew.An@trumman.com.tw
    Description      : setSPK_Torque
//==========================================================================================*/
void setSPK_Parameter( Struct_SPK* spk, int32_t acc_dec_time, int32_t tq1, int32_t tq2, int32_t brake_time )
{
    spk->Tq_AccDec_Time = acc_dec_time;
    if( spk->Tq_AccDec_Time < 1 ){
        spk->Tq_AccDec_Time = 1;
    }

    spk->Tq_Percentage_1 = tq1;
    spk->Tq_Percentage_2 = tq2;

    if( brake_time == 0 ){
        brake_time = SPK_LOCK_DELAY_CONST;
    }
    spk->BrakeLock_Time = brake_time;
}

/*===========================================================================================
    Function Name    : setupSPK_PWM_Start_M0
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
void setupSPK_PWM_Start_M0( void )
{
    EALLOW;  // This is needed to write to EALLOW protected registers

    GPIO_M0_UT_OFF;
    GPIO_M0_VT_OFF;
    GPIO_M0_WT_OFF;

    GPIO_M0_UB_OFF;
    GPIO_M0_VB_OFF;
    GPIO_M0_WB_OFF;

    PWM_M0_UT_OFF;
    PWM_M0_VT_OFF;
    PWM_M0_WT_OFF;
    PWM_M0_UB_OFF;
    PWM_M0_VB_OFF;
    PWM_M0_WB_OFF;

    bldcDrive_OutputDuty_M0( 0, 0, 0 );

    PWM_M0_UT_ON;
    PWM_M0_VT_ON;
    PWM_M0_WT_ON;
    PWM_M0_UB_ON;
    PWM_M0_VB_ON;
    PWM_M0_WB_ON;

    CG_SPK_M0.Tq_Restraint_flag = YES;
    CG_SPK_M0.Moved_Flag = NO;

    EDIS;    // This is needed to disable write to EALLOW protected registers
}

/*===========================================================================================
    Function Name    : setupSPK_PWM_Start_M1
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
#if(0)
void setupSPK_PWM_Start_M1( void )
{
    EALLOW;  // This is needed to write to EALLOW protected registers

    GPIO_M1_UT_OFF;
    GPIO_M1_VT_OFF;
    GPIO_M1_WT_OFF;

    GPIO_M1_UB_OFF;
    GPIO_M1_VB_OFF;
    GPIO_M1_WB_OFF;

    PWM_M1_UT_OFF;
    PWM_M1_VT_OFF;
    PWM_M1_WT_OFF;
    PWM_M1_UB_OFF;
    PWM_M1_VB_OFF;
    PWM_M1_WB_OFF;

    bldcDrive_OutputDuty_M1( 0, 0, 0 );

    PWM_M1_UT_ON;
    PWM_M1_VT_ON;
    PWM_M1_WT_ON;
    PWM_M1_UB_ON;
    PWM_M1_VB_ON;
    PWM_M1_WB_ON;

    CG_SPK_M1.Tq_Restraint_flag = YES;
    CG_SPK_M1.Moved_Flag = NO;

    EDIS;    // This is needed to disable write to EALLOW protected registers
}
#endif

/*===========================================================================================
    Function Name    : setupSPK_PWM_Stop_M0
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
void setupSPK_PWM_Stop_M0( void )
{
    EALLOW;  // This is needed to write to EALLOW protected registers
    GPIO_M0_UT_OFF;
    GPIO_M0_VT_OFF;
    GPIO_M0_WT_OFF;

    GPIO_M0_UB_OFF;
    GPIO_M0_VB_OFF;
    GPIO_M0_WB_OFF;

    PWM_M0_UT_OFF;
    PWM_M0_VT_OFF;
    PWM_M0_WT_OFF;
    PWM_M0_UB_OFF;
    PWM_M0_VB_OFF;
    PWM_M0_WB_OFF;

    bldcDrive_OutputDuty_M0( 0, 0, 0 );

    CG_SPK_M0.Tq_Restraint_flag = NO;

    EDIS;    // This is needed to disable write to EALLOW protected registers

}

/*===========================================================================================
    Function Name    : setupSPK_PWM_Stop_M1
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
#if(0)
void setupSPK_PWM_Stop_M1( void )
{
    EALLOW;  // This is needed to write to EALLOW protected registers
    GPIO_M1_UT_OFF;
    GPIO_M1_VT_OFF;
    GPIO_M1_WT_OFF;

    GPIO_M1_UB_OFF;
    GPIO_M1_VB_OFF;
    GPIO_M1_WB_OFF;

    PWM_M1_UT_OFF;
    PWM_M1_VT_OFF;
    PWM_M1_WT_OFF;
    PWM_M1_UB_OFF;
    PWM_M1_VB_OFF;
    PWM_M1_WB_OFF;

    bldcDrive_OutputDuty_M1( 0, 0, 0 );

    CG_SPK_M1.Tq_Restraint_flag = NO;

    EDIS;    // This is needed to disable write to EALLOW protected registers
}
#endif

/*===========================================================================================
    Function Name    : spkOutputDuty_ByADC
    Input            : 1.spk
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK output duty.
//==========================================================================================*/
void spkOutputDuty_ByADC( Struct_SPK* spk, Struct_BLDC_CTRL* bldc_ctrl )
{
    if ( bldc_ctrl->Ctrl_Updated == NO ){
         bldc_ctrl->Ctrl_Updated = YES;

        if( spk->Lock_Timer < 65535 ){
            spk->Lock_Timer++;
        }

        calculateTargetCurrent_SPK( spk );

        currentRestraint_SPK( spk, bldc_ctrl );

        if( bldc_ctrl->Current_Restraint_Flag == YES ){
            reduceDuty_SPK( ( int32_t* )&bldc_ctrl->Current_Duty_Abs, bldc_ctrl->Current_Restraint_Step );
        }else{
            dutyController_SPK( spk, bldc_ctrl );
        }
    }

    if( spk->Lock_Timer <= spk->BrakeLock_Time ){
        spk->Hall_Lock_pointer = 0;
    }


    //decide direction

    if( spk->Hall_Lock_pointer > 0 )  {

        spk->Moved_Flag = YES;
        bldc_ctrl->Target_Dir = DIR_CCW;
        bldc_ctrl->Current_Duty = -1 * bldc_ctrl->Current_Duty_Abs;
        bldc_ctrl->Commutation = ( bldc_ctrl->Drive_Ptr->Commutation_Table[ bldc_ctrl->Target_Dir ][ bldc_ctrl->Hall_Ptr->Current_State  ] + 4 ) % 6;

        spk->SVM_Point = 30;

        if( spk->Hall_Lock_pointer == 1 ){
            if( bldc_ctrl->Hall_Ptr->PA_Commutation_Type == COMMUTATION_TYPE_ACC ){
                spk->SVM_Point = 60;
            }else{
                spk->SVM_Point = 0;
            }
        }
    }else if ( spk->Hall_Lock_pointer < 0 ){
        spk->Moved_Flag = YES;
        bldc_ctrl->Target_Dir = DIR_CW;
        bldc_ctrl->Current_Duty = 1 * bldc_ctrl->Current_Duty_Abs;
        bldc_ctrl->Commutation = ( bldc_ctrl->Drive_Ptr->Commutation_Table[ bldc_ctrl->Target_Dir ][ bldc_ctrl->Hall_Ptr->Current_State  ] + 4 ) % 6;
        spk->SVM_Point = 30;

        if( spk->Hall_Lock_pointer == -1 ){
            if( bldc_ctrl->Hall_Ptr->PA_Commutation_Type == COMMUTATION_TYPE_ACC ){
                spk->SVM_Point = 0;
            }else{
                spk->SVM_Point = 60;
            }
        }
    }else{
        bldc_ctrl->Current_Duty = 1 * bldc_ctrl->Current_Duty_Abs;
        bldc_ctrl->Commutation = ( bldc_ctrl->Drive_Ptr->Commutation_Table[ DIR_CW ][ bldc_ctrl->Hall_Ptr->Current_State  ] + 4 ) % 6;
        if( bldc_ctrl->Hall_Ptr->PA_Commutation_Type == COMMUTATION_TYPE_ACC ){
            bldc_ctrl->Commutation = ( bldc_ctrl->Commutation + 5 ) % 6;
            spk->SVM_Point = 0;
        }else{
            bldc_ctrl->Commutation = ( bldc_ctrl->Commutation + 1 ) % 6;
            spk->SVM_Point = 60;
        }
    }

    spk->SVM_T1 = ( bldc_ctrl->Current_Duty_Abs * Const_Sine_Table[ 60 - spk->SVM_Point ] ) >> SINE_TABLE_BIT_NUM;
    spk->SVM_T2 = ( bldc_ctrl->Current_Duty_Abs * Const_Sine_Table[ spk->SVM_Point ] ) >> SINE_TABLE_BIT_NUM;
    spk->SVM_T0 = bldc_ctrl->Drive_Ptr->Period - spk->SVM_T1 - spk->SVM_T2;

    switch( bldc_ctrl->Commutation ){
    case 0:
        spk->SVM_Va = spk->SVM_T1 + spk->SVM_T2;
        spk->SVM_Vb = spk->SVM_T2;
        spk->SVM_Vc = 0;
        break;
    case 1:
        spk->SVM_Va = spk->SVM_T1;
        spk->SVM_Vb = spk->SVM_T1 + spk->SVM_T2;
        spk->SVM_Vc = 0;
        break;
    case 2:
        spk->SVM_Va = 0;
        spk->SVM_Vb = spk->SVM_T1 + spk->SVM_T2;
        spk->SVM_Vc = spk->SVM_T2;
        break;
    case 3:
        spk->SVM_Va = 0;
        spk->SVM_Vb = spk->SVM_T1;
        spk->SVM_Vc = spk->SVM_T1 + spk->SVM_T2;
        break;
    case 4:
        spk->SVM_Va = spk->SVM_T2;
        spk->SVM_Vb = 0;
        spk->SVM_Vc = spk->SVM_T1 + spk->SVM_T2;
        break;
    case 5:
        spk->SVM_Va = spk->SVM_T1 + spk->SVM_T2;
        spk->SVM_Vb = 0;
        spk->SVM_Vc = spk->SVM_T1;
        break;
    default:
        spk->SVM_Va = 0;
        spk->SVM_Vb = 0;
        spk->SVM_Vc = 0;
        break;
    }

    if( spk->Moved_Flag == YES ){

        spk->SVM_Duty_U = spk->SVM_Va + spk->SVM_T0 / 2;
        spk->SVM_Duty_V = spk->SVM_Vb + spk->SVM_T0 / 2;
        spk->SVM_Duty_W = spk->SVM_Vc + spk->SVM_T0 / 2;

    }else{

        spk->SVM_Duty_U = 0;
        spk->SVM_Duty_V = 0;
        spk->SVM_Duty_W = 0;

    }

    bldc_ctrl->Drive_Ptr->Duty_Out( spk->SVM_Duty_U,
                                    spk->SVM_Duty_V,
                                    spk->SVM_Duty_W );

}


/************************** <END OF FILE> *****************************************/
