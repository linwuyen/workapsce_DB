/*===========================================================================================
    File Name       : HallSensor.c
    Built Date      : 2020/06/24
    Version         : V1.00a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This file provides the functions for Hall sensor speed detect
    =========================================================================================
    History         : 
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"
//volatile 		Struct_Speed 					CG_Speed;
volatile Struct_HallSensor                      CG_Hall_M0;
//volatile Struct_HallSensor                      CG_Hall_M1;

//extern volatile Struct_BLDC_CTRL 				CG_BLDC_CTRL;
//extern volatile Struct_BLDC_Drive 				CG_BLDC_Drive;
extern volatile Struct_Parameter				CG_Parameter;
extern volatile Struct_MD 						CG_MD;
extern volatile Struct_Encoder 					CG_Encoder;
extern volatile Struct_Pretect 					CG_Protect;

#if(1)	// 120 degress Hall, Fault: 000, 111
	/*============= 	Hall CW : 1 -> 3 -> 2 -> 6-> 4 -> 5 ============*/
	const uint8_t Const_Hall_Next_State_TOP[2][8] = { 0, 3, 6, 2, 5, 1, 4, 0,		// For Hall A
													0, 5, 3, 1, 6, 4, 2, 0};

	const uint8_t Const_Hall_Next_State_BOTTOM[2][8] = 	{ 0, 5, 3, 1, 6, 4, 2, 0,		// For Hall B
														0, 3, 6, 2, 5, 1, 4, 0};
#else
	// 60 degress Hall, Fault: 010, 101
    /*============= 	Hall CW : 3 -> 7 -> 6 -> 4-> 0 -> 1 ============*/
	const uint8_t Const_Hall_Next_State_TOP[2][8] = { 1, 3, 5, 7, 0, 2, 4, 6,		// For Hall B
													4, 0, 5, 1, 6, 2, 7, 3};

	const uint8_t Const_Hall_Next_State_BOTTOM[2][8] = 	{ 4, 0, 5, 1, 6, 2, 7, 3,		// For Hall B
														1, 3, 5, 7, 0, 2, 4, 6};
#endif


/*===========================================================================================
    Function Name    : variableInitial_HallSensor
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_HallSensor ( Struct_HallSensor* hall )
{
    variableReset_HallSensor( hall );

    //
    hall->Current_Dir = 0;
    hall->Old_Dir = hall->Current_Dir;
    hall->Stall_Timer = 0;
    hall->Zero_Cnt = 0;
    hall->Reverse_Flag = NO;

	// Set all as top view for default.  2012_1210 added by Gear.
    hall->Sequence = 0;
    hall->Pole_Factor = 1;
    hall->Dir_Def = 0;
    hall->Next_State_Table 				= ( uint8_t(*)[8] )Const_Hall_Next_State_TOP;

    hall->Smooth_Spd_Threshold = 0;
    hall->Smooth_Speed_Old = 0;

    //
    hall->PA_Enabled = NO;
    hall->PA_Flag = NO;

    //hall->Current_State = 0;
    //hall->Next_State_If_CW  = hall->Next_State_Table[ DIR_CW  ][ hall->Current_State ];
    //hall->Next_State_If_CCW = hall->Next_State_Table[ DIR_CCW ][ hall->Current_State ];

}


/*===========================================================================================
    Function Name    : variableReset_HallSensor
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableReset_HallSensor ( Struct_HallSensor* hall )
{

	uint8_t i;

	for( i = 0 ; i < HALL_SEC_MAX; i ++ ){
	    hall->INT_Time_Period[i] = 0;
	    hall->INT_Time_Sum[i] = 0;
	}

	//hall->Current_Dir = 0;
	//hall->Old_Dir = hall->Current_Dir;

	hall->Pointer = 0;
	hall->Current_Pointer = 0;
	hall->INT_E_Last_Pointer = 0;
	hall->Last_Pointer = 0;

	hall->INT_E_Period = 0;

	hall->Current_ERPM_Abs = 0;
	hall->Current_ERPM = 0;
	hall->Current_RPM_Abs = 0;
	hall->Current_RPM = 0;

	hall->Smooth_RPM = 0;
	hall->Smooth_ERPM = 0;
	hall->Smooth_RPM_Abs = 0;
	hall->Smooth_ERPM_Abs = 0;

	hall->Ecycle_ERPM_Abs = 0;
	hall->Ecycle_ERPM = 0;
	hall->Ecycle_RPM_Abs = 0;
	hall->Ecycle_RPM = 0;

	hall->Rapid_RPM_Abs = 0;
	hall->Rapid_ERPM = 0;
	hall->Rapid_ERPM_Abs = 0;
	hall->Rapid_RPM = 0;

	//hall->Stall_Timer = 0;
	hall->INT_Times = 0;

	//hall->Zero_Cnt = 0;
	//hall->Reverse_Flag = NO;
    hall->Smooth_Flag = NO;
    hall->Smooth_Cnt = 0;

	hall->INT_TP_1 = CURRENT_TIMER_CNT;

}

/*===========================================================================================
    Function Name    : hall_ResetPosition
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Reset hall position count
//==========================================================================================*/
void hall_ResetPosition ( Struct_HallSensor* hall )
{
    hall->Position = 0;

}

/*===========================================================================================
    Function Name    : hall_Reset_Stall_Timer
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_Reset_Stall_Timer( Struct_HallSensor* hall )
{
    hall->Stall_Timer = 0;
}

/*===========================================================================================
    Function Name    : hall_PeriodCalculation
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 
//==========================================================================================*/
void hall_PeriodCalculation( Struct_HallSensor* hall )
{
#if(1)
    hall->Zero_Cnt = 0;
    hall->Stall_Timer = 0;

    if( hall->INT_Times < 65535 ){
        hall->INT_Times ++;
    }

    // direction
    if( hall->Current_State == hall->Next_State_If_CW ){
        hall->Current_Dir = DIR_CW;
        hall->Position++;
    }else if( hall->Current_State == hall->Next_State_If_CCW ){
        hall->Current_Dir = DIR_CCW;
        hall->Position--;
    }else{
        hall->Current_Dir = 65535;
    }

    if( hall->Old_Dir != hall->Current_Dir ){
        hall->Reverse_Flag = YES;
        variableReset_HallSensor ( hall );
        hall->INT_Times = 1;
    }else{
        hall->Reverse_Flag = NO;
    }
    hall->Old_Dir = hall->Current_Dir;

    // speed

    hall->INT_TP_2 = hall->INT_Time_New;

    if( hall->INT_Times >= 2 ){
#if( TIMER_TYPE== TIMER_TYPE_DECREASE)
        hall->INT_Time_Period[ hall->Pointer ] = hall->INT_TP_1 - hall->INT_TP_2;
#else
        hall->INT_Time_Period[ hall->Pointer ] = hall->INT_TP_2 - hall->INT_TP_1;
#endif

        //hall->Phase_Length = ( hall->Phase_Length * 3 + hall->INT_Time_Period[ hall->Pointer ] ) / 4;

        hall->Current_Pointer = hall->Pointer;                  // current pointer

        if( ++hall->Pointer >= ( hall->Pole_Factor ) * 6 + 1 ){     // move to next, ready to cover the old pointer
            hall->Pointer = 0;
        }

        hall->INT_Time_Sum[ hall->Current_Pointer ] = hall->INT_Time_Sum[ hall->Last_Pointer ] +
                                                      hall->INT_Time_Period[ hall->Current_Pointer ] -
                                                      hall->INT_Time_Period[ hall->Pointer ];

        if( hall->Current_Pointer >= 6 ){
            hall->INT_E_Last_Pointer = hall->Current_Pointer - 6;
        }else{
            hall->INT_E_Last_Pointer = hall->Pole_Factor * 6 + 1 + hall->Current_Pointer - 6;
        }
        hall->INT_E_Period = hall->INT_E_Period + hall->INT_Time_Period[ hall->Current_Pointer ] - hall->INT_Time_Period[ hall->INT_E_Last_Pointer ];
        hall->Last_Pointer = hall->Current_Pointer;

    }

    hall->INT_TP_1 = hall->INT_TP_2;

    hall->Next_State_If_CW = hall->Next_State_Table[ DIR_CW  ][ hall->Current_State ];
    hall->Next_State_If_CCW = hall->Next_State_Table[ DIR_CCW  ][ hall->Current_State ];

    //management_LockPointer( Struct_SPK* spk, hall->Current_Dir );

    hall->Updated_Flag = YES;

#endif
	
}

/*===========================================================================================
    Function Name    : hall_ZeroSpeed_Determine
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Determine if motor is zero speed.
//==========================================================================================*/
void hall_ZeroSpeed_Determine( Struct_HallSensor* hall )
{
#if(1)

    int32_t factor = hall->Pole_Factor;
    if( factor < 1 ){
        factor = 1;
    }
	
	if( hall->Zero_Cnt >= 10000 / ( HALL_ZERO_SPEED_CONST * factor ) ){
		DINT;
		variableReset_HallSensor ( hall );
		EINT;   // Enable Global interrupt INTM
	}


#endif
		
}

/*===========================================================================================
    Function Name    : hall_Speed_Calculations
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate motor's speed.
//==========================================================================================*/
void hall_Speed_Calculations( Struct_HallSensor* hall )
{
#if(1)
	int32_t dummy_spd;
	int32_t period_stamp;
	int32_t hall_int_stamp;
    uint32_t int_time_sum;
    uint32_t int_time_period;
	
	if( hall->INT_Flag == YES ){
	    hall->INT_Flag = NO;

#if(0)
        if( hall->INT_Time_Period[ hall->Current_Pointer ] != 0 ){
            hall->Rapid_ERPM_Abs =  ( (uint32_t)( 10 * CPU_FREQ ) ) / hall->INT_Time_Period[ hall->Current_Pointer ];
            hall->Rapid_RPM_Abs = hall->Rapid_ERPM_Abs / hall->Pole_Factor;
        }

        if( hall->INT_Time_Sum[ hall->Current_Pointer ] != 0 ){

            // hall->Smooth_RPM_Abs = ( (uint32_t)( 60 * CPU_FREQ ) ) / ( hall->INT_Time_Sum[ hall->Current_Pointer ] ); // 60 * CPU_FREQ will cause overflow
            hall->Smooth_RPM_Abs = ( (uint32_t)( 30 * CPU_FREQ ) ) / ( hall->INT_Time_Sum[ hall->Current_Pointer ] >> 1 );
            hall->Smooth_ERPM_Abs = hall->Smooth_RPM_Abs * hall->Pole_Factor;

        }
#else
        int_time_period = hall->INT_Time_Period[ hall->Current_Pointer ];
        if( int_time_period != 0 ){
            hall->Rapid_ERPM_Abs =  ( (uint32_t)( 10 * CPU_FREQ ) ) / int_time_period;
            hall->Rapid_RPM_Abs = hall->Rapid_ERPM_Abs / hall->Pole_Factor;
        }

        int_time_sum = ( hall->INT_Time_Sum[ hall->Current_Pointer ] >> 1 );
        if( int_time_sum != 0 ){
            // hall->Smooth_RPM_Abs = ( (uint32_t)( 60 * CPU_FREQ ) ) / ( hall->INT_Time_Sum[ hall->Current_Pointer ] ); // 60 * CPU_FREQ will cause overflow
            hall->Smooth_RPM_Abs = ( (uint32_t)( 30 * CPU_FREQ ) ) / int_time_sum;
            hall->Smooth_ERPM_Abs = hall->Smooth_RPM_Abs * hall->Pole_Factor;
        }
#endif


        if( hall->INT_E_Period != 0 ){
            // hall->Ecycle_ERPM_Abs = ( (uint32_t)( 60 * CPU_FREQ ) ) / hall->INT_Time_Period;	// 60 * CPU_FREQ will cause overflow
            // hall->Ecycle_ERPM_Abs = ( (uint32_t)( 30 * CPU_FREQ ) ) / ( hall->INT_Time_Period >> 1 );

            DINT;
            period_stamp = hall->INT_E_Period;
            hall_int_stamp = hall->INT_Times;
            EINT;

            hall_int_stamp--;

            if( hall_int_stamp < 1 ){		// To avoid zero
                hall_int_stamp = 1;
            }else if( hall_int_stamp > 6 ){	// 1 electric cycle of hall sensor = 6
                hall_int_stamp = 6;
            }

            if( period_stamp >= 2 ){
                dummy_spd = ( (uint32_t)( 30 * CPU_FREQ ) ) / ( period_stamp >> 1 );
            }else{
                dummy_spd = 0;
            }

            dummy_spd = dummy_spd * hall_int_stamp / 6;

            hall->Ecycle_ERPM_Abs = dummy_spd;
            hall->Ecycle_RPM_Abs = hall->Ecycle_ERPM_Abs / hall->Pole_Factor;

        }

        switch( hall->Current_Dir ){
            case DIR_CW:
                hall->Rapid_RPM = hall->Rapid_RPM_Abs;
                hall->Rapid_ERPM = hall->Rapid_ERPM_Abs;

                hall->Smooth_RPM = hall->Smooth_RPM_Abs;
                hall->Smooth_ERPM = hall->Smooth_ERPM_Abs;

                hall->Ecycle_ERPM = hall->Ecycle_ERPM_Abs;
                hall->Ecycle_RPM = hall->Ecycle_RPM_Abs;

                break;
            case DIR_CCW:
                hall->Rapid_RPM = -1 * hall->Rapid_RPM_Abs;
                hall->Rapid_ERPM = -1 * hall->Rapid_ERPM_Abs;

                hall->Smooth_RPM = -1 * hall->Smooth_RPM_Abs;
                hall->Smooth_ERPM = -1 * hall->Smooth_ERPM_Abs;

                hall->Ecycle_ERPM = -1 * hall->Ecycle_ERPM_Abs;
                hall->Ecycle_RPM = -1 * hall->Ecycle_RPM_Abs;

                break;
            default:
                hall->Rapid_RPM_Abs = 0;
                hall->Rapid_ERPM_Abs = 0;
                hall->Rapid_RPM = 0;
                hall->Rapid_ERPM = 0;

                hall->Smooth_ERPM_Abs = 0;
                hall->Smooth_RPM_Abs = 0;
                hall->Smooth_ERPM = 0;
                hall->Smooth_RPM = 0;

                hall->Ecycle_ERPM_Abs = 0;
                hall->Ecycle_RPM_Abs = 0;
                hall->Ecycle_ERPM = 0;
                hall->Ecycle_RPM = 0;

                break;
        }

        if( hall->INT_Times <= ( hall->Pole_Factor ) * 6 ){

            hall->Current_ERPM_Abs = hall->Ecycle_ERPM_Abs;
            hall->Current_ERPM = hall->Ecycle_ERPM;
            hall->Current_RPM_Abs = hall->Ecycle_RPM_Abs;
            hall->Current_RPM = hall->Ecycle_RPM;

        }else{
            hall->Current_ERPM_Abs = hall->Smooth_ERPM_Abs;
            hall->Current_ERPM = hall->Smooth_ERPM;
            hall->Current_RPM_Abs = hall->Smooth_RPM_Abs;
            hall->Current_RPM = hall->Smooth_RPM;
        }


        hall->Smooth_Spd_Threshold = hall->Smooth_ERPM_Abs / 10;
        if( hall->Smooth_Spd_Threshold < SMOOTH_RPM_THRESHOLD * hall->Pole_Factor ){
            hall->Smooth_Spd_Threshold = SMOOTH_RPM_THRESHOLD * hall->Pole_Factor;
        }

        //
        dummy_spd = hall->Ecycle_ERPM - hall->Smooth_Speed_Old;

        if( dummy_spd < hall->Smooth_Spd_Threshold &&
            dummy_spd > -hall->Smooth_Spd_Threshold ){

            if( hall->Smooth_Cnt < PA_OPEN_CNT ){
                hall->Smooth_Cnt++;
            }else{
                hall->Smooth_Flag = YES;
            }
        }else{
            hall->Smooth_Flag = NO;
            hall->Smooth_Cnt = 0;
        }
        hall->Smooth_Speed_Old = hall->Ecycle_ERPM;

        hall->Phase_Length = hall->INT_E_Period / 6;

        hall->PA_Time_Threshold = hall->Phase_Length * ( PHASE_ANDVACE_CONST - hall->PA_Angle ) / PHASE_ANDVACE_CONST;
        if( hall->PA_Time_Threshold > hall->PA_Ticks ){
            hall->PA_Time_Threshold -= hall->PA_Ticks;
        }else{
            hall->PA_Time_Threshold = 0;
        }

	}


#endif

	
}


/*===========================================================================================
    Function Name    : hall_1ms_Routine
    Input            : hall
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void hall_1ms_Routine( Struct_HallSensor* hall )
{

    if( hall->Zero_Cnt < 100000 ){
        hall->Zero_Cnt++;
    }

    hall_ZeroSpeed_Determine( hall );

    if( hall->Current_RPM_Abs == 0 ){
        if( hall->Stall_Timer < 1000000 ){
            hall->Stall_Timer++;
        }
    }
}

/************************** <END OF FILE> *****************************************/


