/*===========================================================================================

    File Name       : SlightPositionKeeping.h

    Version         : V1_00_00_a

    Built Date      : 2016/08/31

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */


#ifndef SLIGHT_POSITION_KEEPING_H
#define SLIGHT_POSITION_KEEPING_H

#include "IncludeFiles.h"
#include "SlightPositionKeeping_TypeDef.h"


//#define TORQUE_ACC_CONST			CG_SPK.Tq_AccDec_Time//100			//	100 => 0.1s from 0A to 1A
//#define TORQUE_DEC_CONST			CG_SPK.Tq_AccDec_Time//100			//	100 => 0.1s from 1A to 0A

#define SPK_LIMIT_RANGE				4			//	4 => 4 hall sensor phase length
#define SPK_100_PERCENT				1000

#define SPK_STEP_DUTY				100//5
#define SPK_STEP_DUTY_FAST			100
#define SPK_STEP_CONST				50000UL

#define HALL_LOCK_STARTING_POINT  	0

#define SPK_LOCK_TIME_CONST			CG_SPK.BrakeLock_Time//300UL
#define SPK_LOCK_DELAY_CONST		300UL

#define HALL_LOCK_POINT_TREND_ACC	0
#define HALL_LOCK_POINT_TREND_DEC	1

#define SPK_PHASE_POINT_NUM			60

/*===========================================================================================
    Function Name    : setupInitial_SPK
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void setupInitial_SPK( void );

/*===========================================================================================
    Function Name    : variableInitial_SPK
    Input            : spk
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_SPK ( Struct_SPK* spk );

/*===========================================================================================
    Function Name    : resetReg_SPK
    Input            : spk
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_SPK reset
//==========================================================================================*/
void resetReg_SPK ( Struct_SPK* spk );

/*===========================================================================================
    Function Name    : calculateTargetCurrent_SPK
    Input            : spk
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Calculate final and current target torque when motor is in SPK.
//==========================================================================================*/
void calculateTargetCurrent_SPK ( Struct_SPK* spk );

/*===========================================================================================
    Function Name    : currentRestraint_SPK
    Input            : 1.spk
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Restraint current.
//==========================================================================================*/
void currentRestraint_SPK( Struct_SPK* spk, Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : reduceDuty_SPK
    Input            : 1.target_duty: target duty
					   2.step_duty : One step reduced duty
    Return           : Null
    Programmer       : Andrew.an@trumman.com.tw
    Description      : reduce duty
//==========================================================================================*/
void reduceDuty_SPK( int32_t* target_duty, int32_t step_duty );

/*===========================================================================================
    Function Name    : dutyController_SPK
    Input            : 1.spk
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Andrew.An@trumman.com.tw
    Description      : SPK duty Controller
//==========================================================================================*/
void dutyController_SPK ( Struct_SPK* spk, Struct_BLDC_CTRL* bldc_ctrl );

/*===========================================================================================
    Function Name    : management_LockPointer
    Input            : 1.spk
                       2.direction
    Return           : Null
    Programmer       : Andrew.An@trumman.com.tw
    Description      : management_LockPointer
//==========================================================================================*/
void management_LockPointer( Struct_SPK* spk, int32_t direction );

/*===========================================================================================
    Function Name    : setSPK_Parameter
    Input            : 1.spk
                       2.acc_dec_time: acc and dec time ( unit: 1ms; 1A/xms )
                       3.tq1: torque 1
                       4.tq2: torque 2
                       5.brake_time
    Return           : Null
    Programmer       : Andrew.An@trumman.com.tw
    Description      : setSPK_Torque
//==========================================================================================*/
void setSPK_Parameter( Struct_SPK* spk, int32_t acc_dec_time, int32_t tq1, int32_t tq2, int32_t brake_time );

/*===========================================================================================
    Function Name    : setupSPK_PWM_Start_M0
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
void setupSPK_PWM_Start_M0( void );

/*===========================================================================================
    Function Name    : setupSPK_PWM_Start_M1
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
//void setupSPK_PWM_Start_M1( void );

/*===========================================================================================
    Function Name    : setupSPK_PWM_Stop_M0
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
void setupSPK_PWM_Stop_M0( void );

/*===========================================================================================
    Function Name    : setupSPK_PWM_Stop_M1
    Input            : NULL
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK uses SVPWM
//==========================================================================================*/
//void setupSPK_PWM_Stop_M1( void );

/*===========================================================================================
    Function Name    : spkOutputDuty_ByADC
    Input            : 1.spk
                       2.bldc_ctrl
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : SPK output duty.
//==========================================================================================*/
void spkOutputDuty_ByADC( Struct_SPK* spk, Struct_BLDC_CTRL* bldc_ctrl );


#endif /* MODULE_D_SLIGHTPOSITIONKEEPING_H_ */

/************************** <END OF FILE> *****************************************/


