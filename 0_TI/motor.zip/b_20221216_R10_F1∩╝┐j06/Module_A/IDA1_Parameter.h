/*===========================================================================================

    File Name       : IDA1_Parameter.h

    Version         : V1_00_00_a

    Built Date      : 2015/03/12

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw

    Description     : This file provides the functions for parameter acessing.
				
    =========================================================================================

    History         : 2015/03/12 Perlimary version.  ( by Chaim )
					  

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef PARAMETER_H
#define PARAMETER_H

#include "Type.h"

/*===========================================================================================
   Parameter.c setup and function macros
//==========================================================================================*/
#define PARAMETER_MAJOR_NUM    					9//PARAMETER_TOTALNUM
#define PARAMETER_MINOR_NUM    					32//14
#define PARAMETER_MONITOR_DATA_NUM    			32

#define PARAMETER_OFFSET                        16

#define PARAMETER_DATA_SIZE    					2                       		// each data = 2 bytes
#define PARAMETER_SECTOR_SIZE					1024//512                             // each sector of parameter type ( def, max, min, value )
#define PARAMETER_MULTI_ACCESS_SIZE				( PARAMETER_MINOR_NUM * PARAMETER_DATA_SIZE )   // minor in bytes per major
#define PARAMETER_SECTOR_DATA_SIZE				( PARAMETER_MAJOR_NUM * PARAMETER_MINOR_NUM )	// Flash data sector size.
//#define PARAMETER_EEP_ADDRESS( DataType )      ((DataType%10)*32 + 32) + ((DataType/10)*PARAMETER_SECTOR_SIZE)//( DataType * PARAMETER_MINOR_NUM * PARAMETER_DATA_SIZE )
//#define PARAMETER_EEP_ADDRESS( DataType )      ( MOD( DataType, 10 ) * 32 + 32) + ((DataType/10)*PARAMETER_SECTOR_SIZE)//( DataType * PARAMETER_MINOR_NUM * PARAMETER_DATA_SIZE )
#define PARAMETER_EEP_ADDRESS( DataType )      ( MOD( DataType, 10 ) * PARAMETER_MULTI_ACCESS_SIZE + PARAMETER_MULTI_ACCESS_SIZE ) + ((DataType/10)*PARAMETER_SECTOR_SIZE)//( DataType * PARAMETER_MINOR_NUM * PARAMETER_DATA_SIZE )

enum{
	PA_EEP_WR_AND_CHECK    	= 0,
	PA_EEP_WO				= 1	
};


/*===========================================================================================
   Parameter Major macros
//==========================================================================================*/
enum{

	PARAMETER_MOTOR			    = 0,    // motor and Engineer parameter
	PARAMETER_GENERAL	 		= 1,	// general
	PARAMETER_SPEED		 	    = 2,	// speed and VR output range
	PARAMETER_ACC_DEC	        = 3,	// acc/dec
	PARAMETER_PROTECT			= 4,	// protect
    PARAMETER_IO                = 5,	// IO
	PARAMETER_DIGITAL			= 6,    // Digital Torque and duty
	PARAMETER_ADVANCE_FUNC		= 7,    // Adcanve function
	PARAMETER_COM				= 8,    // Communication

    //PARAMETER_EXTENDER1         = 6,
    //PARAMETER_EXTENDER2         = 7,
    //PARAMETER_EXTENDER3         = 8,

	//PARAMETER_DIGITAL			= 6,
	PARAMETER_TOTALNUM	        = 9

};


/*===========================================================================================
	Motor ( major index = 0 )
	parameter ID
	Motor Region Parameters
//==========================================================================================*/
enum{
    // M0
	MOTOR_AND_SENSOR_TYPE				= 0,	// BIT Field; Bit 0,1 = Motor Type ( 0 = BLDC, 1 = BDC )
	                                            // Bit 2,3,4 = Sensor Type ( 0 = Depends on HWEEP, 1 = Hall Sensor, 2 = Encoder Type A, 3 = Encoder Type B and so on... )
	MOTOR_HALL_SEQUENCE 				= 1,	// Motor Hall signal sequence type. ( 0:B, 1:A )
	MOTOR_POLE_NUMBER					= 2,	// Motor pole number.
	MOTOR_FULL_SPEED	 				= 3,	// Motor free load max speed.
	MOTOR_FORWARD_DIR					= 4,	// Motor direction define.
	MOTOR_ENCODER_RESOLUTION       	    = 5,	// BLDC Motor encoder resolution
	MOTOR_ENCODER_OFFSET				= 6,	// For FOC, it needs a offset pos
    MOTOR_ENCODER_CHECKING_TIME         = 7,   // In this period, check encoder's "hall sensor state" ( uint : ms )
    MOTOR_ENCODER_SETTLING_TIME         = 8,   // In this period, encoder is used as a hall sensor ( uint : ms )

	MOTOR_SERVO_ON_MODE                 = 9,   // ServoOn Mode:    0 = Always servo on,
	MOTOR_CTRL_MODE				        = 10,	//  0 = Speed, 1 = duty control, 2 = position control
	MOTOR_OPERATION_MODE_SPD			= 11,	// Analag mode decides the analog source of speed/duty/acc/dec/torqe.
	MOTOR_OPERATION_MODE_POS            = 12,

	MOTOR_VR_MINVALUE_DEF               = 13,	// VR min value behavior, stop or keep running
	MOTOR_MOTOR_STOP_BEHAVIOR		    = 14,	// Brake or Free when motor stop ( 0 = Free, 1 = Brake )

	MOTOR_ENCODER_HALL_OFFSET           = 15

};

/*===========================================================================================
	General ( major index = 1 )
	parameter ID
	General Region Parameters
//==========================================================================================*/
enum{

    GENERAL_VR_SPD_MAX                  = 0,    // VR max speed cw sector 0
    GENERAL_VR_SPD_MIN                  = 1,
    GENERAL_VR_ACCDEC_MAX               = 2,
    GENERAL_VR_ACCDEC_MIN               = 3,

    GENERAL_VR_TQ_MAX                   = 4,
    GENERAL_VR_TQ_MIN                   = 5,
    GENERAL_VR_DUTY_MAX                 = 6,
    GENERAL_VR_DUTY_MIN                 = 7,

    GENERAL_AD_MODE                     = 8,    // AD in select 5V or 10V
    GENERAL_VR_GAIN                     = 9,    // analog input gain value rpm per 1V.
    GENERAL_VR_OFF_SET_VOLTAGE          = 10,   // analog input zero point voltage off set.
    GENERAL_VR_OFF_SET_SPD              = 11,   // analog input zero point speed.

    GENERAL_PATH_MODE                   = 12,   // 0 = relax, 1 = strict
    GENERAL_POSITION_DEF_MODE           = 13,

    GENERAL_ENCODER_UPDATE_RATE         = 14,

    //GENERAL_DRIVER_MODE                 = 16,   // 0 = drive 2 motors, 1 = drive 1 motor with 2 channels
    GENERAL_POWER_PERCENTAGE            = 17,    // HW/FW OCP restraint for low-power motor
    GENERAL_POWER_PWM_FREQ              = 18,

    GENERAL_IO_FILTER                   = 19,

    GENERAL_SPEED_SCALE_MAX             = 22,   // It's "VR max" of scale factor for speed/duty, 1000 = 100.0%
    GENERAL_SPEED_SCALE_MIN             = 23,   // It's "VR min" of scale factor for speed/duty,    0 =   0.0%
                                                // When VR2 is used as a scale factor input, it limits the VR1's output
                                                // ex: when VR2 = 50.0%, VR1 = VR1 * 50.0%

    GENERAL_THROTTLE_TYPE               = 24,
    GENERAL_THROTTLE_SIGNAL_MAX         = 25, // Throttle signal min = VR_OFF_SET_VOLTAGE
    GENERAL_THROTTLE_MAP                = 26,
    GENERAL_THROTTLE_DEAD_BAND          = 27,

    GENERAL_THROTTLE_PULSE_MAX          = 28,
    GENERAL_THROTTLE_PULSE_MIN          = 29,

    GENERAL_THROTTLE_RESTRAINT_MODE     = 30,

    GENERAL_IO_EXPANDER_ACT_BITF        = 31
};

/*===========================================================================================
	General ( major index = 2 )
	parameter ID
	Speed and VR range Region Parameters
//==========================================================================================*/
enum{	
    // M0
	SPD_DIGIT_SPD_0             = 0,
	SPD_DIGIT_SPD_1			    = 1,
	SPD_DIGIT_SPD_2			    = 2,
	SPD_DIGIT_SPD_3			    = 3,

	SPD_DIGIT_DUTY_0			= 4,	// Duty
	SPD_DIGIT_DUTY_1			= 5,
	SPD_DIGIT_DUTY_2			= 6,
	SPD_DIGIT_DUTY_3			= 7,

	SPD_DIGIT_TQ_0			    = 8,	// Tq
	SPD_DIGIT_TQ_1			    = 9,
	SPD_DIGIT_TQ_2			    = 10,
	SPD_DIGIT_TQ_3			    = 11,

	SPD_TQ_STALL_TIME           = 12,
	SPD_TQ_ACT_TIME             = 13,    // A specified time that allows torqe over the limit
	SPD_TQ_REC_TIME             = 14,    // It will clear the limit flag when its torqe is under the restraint over a specified time

    SPD_VR_MAX_CW_0                 = 16 + 0,    // VR max speed cw sector 0
    SPD_VR_MIN_CW_0                 = 16 + 1,
    SPD_VR_MAX_CCW_0                = 16 + 2,
    SPD_VR_MIN_CCW_0                = 16 + 3,

    SPD_VR_MAX_CW_1                 = 16 + 4,
    SPD_VR_MIN_CW_1                 = 16 + 5,
    SPD_VR_MAX_CCW_1                = 16 + 6,
    SPD_VR_MIN_CCW_1                = 16 + 7,

    DUTY_VR_MAX_CW_0                = 16 + 8,    // VR max duty cw sector 0
    DUTY_VR_MIN_CW_0                = 16 + 9,
    DUTY_VR_MAX_CCW_0               = 16 + 10,
    DUTY_VR_MIN_CCW_0               = 16 + 11,

    DUTY_VR_MAX_CW_1                = 16 + 12,
    DUTY_VR_MIN_CW_1                = 16 + 13,
    DUTY_VR_MAX_CCW_1               = 16 + 14,
    DUTY_VR_MIN_CCW_1               = 16 + 15

};

/*===========================================================================================
	ACC/DEC ( major index = 3 )
	parameter ID
	ACC/DEC Region Parameters
//==========================================================================================*/
enum{
	// M0
	ACC_DEC_DIGIT_ACC_0         = 0,	// Acc
	ACC_DEC_DIGIT_ACC_1			= 1,
	ACC_DEC_DIGIT_ACC_2			= 2,
	ACC_DEC_DIGIT_ACC_3			= 3,

	ACC_DEC_S_CURVE_ACC_0       = 4,
	ACC_DEC_S_CURVE_ACC_1       = 5,
	ACC_DEC_S_CURVE_ACC_2       = 6,
	ACC_DEC_S_CURVE_ACC_3       = 7,
	
	ACC_DEC_DIGIT_DEC_0		    = 8,	// Dec
	ACC_DEC_DIGIT_DEC_1			= 9,
	ACC_DEC_DIGIT_DEC_2			= 10,
	ACC_DEC_DIGIT_DEC_3			= 11,
	
	ACC_DEC_S_CURVE_DEC_0       = 12,
    ACC_DEC_S_CURVE_DEC_1       = 13,
    ACC_DEC_S_CURVE_DEC_2       = 14,
    ACC_DEC_S_CURVE_DEC_3       = 15

};

/*===========================================================================================
	Protection ( major index = 4 )
	parameter ID
	Protection Region Parameters
//==========================================================================================*/
enum{	

    PROTECT_MOTOROT_SENSOR_TYPE             = 0,    // Motor OT
    PROTECT_PWR_ON_RUN                      = 1,    // 0: diabled, 1: enabled
    PROTECT_FEEDBACK_SENSOR_PROTECT_ENABLE  = 2,    // For Hall sensor: 0 = disable hall sequence protect , 1 & 2 = enable...
                                                    // For Encoder: 0 & 1 = enable encoder overflow error, 2 = disable...
    PROTECT_OVERSPEED_RPM                   = 3,    // Over speed
    PROTECT_AUTORESET_TIME                  = 4,    // Auto reset
    PROTECT_RESETTABLE_ALARMS               = 5,    // Indicate what alarms can be autoreset

    PROTECT_ENCODER_ERROR_SENSITIVITY       = 6,

    PROTECT_ERROR_BEHAVIOR_HALL             = 7,   //
    PROTECT_ERROR_BEHAVIOR_OVP_UVP          = 8,    //

    PROTECT_OV_FAULT                        = 9,    // Over VBUS
    PROTECT_OV_RECOVER                      = 10,
    PROTECT_UV_FAULT                        = 11,   // Under VBUS
    PROTECT_UV_RECOVER                      = 12,

    PROTECT_LV_FAULT                        = 13,   // Low VBUS
    PROTECT_LV_RECOVER                      = 12,

    PROTECT_OC_FAULT_EN                     = 14,   // Over Current fault enable
    PROTECT_OP_FAULT_EN                     = 15,   // Over Power Fault enable

	PROTECT_485_TIME_OUT_TICKS		    = 16,	// in ms 0: no time out fault.
	PROTECT_485_COM_ALM_NUM					= 17,	// It alarms when com error meets this number.
	PROTECT_232_TIME_OUT_TICKS				= 18,	// in ms 0: no time out fault.
	PROTECT_232_COM_ALM_NUM					= 19,	// It alarms when com error meets this number.
	PROTECT_COMM_ERROR_BEHAVIOR				= 20,	// 0 = Only Alarm, 1 = Only Clear NET-IO, 2 = Alarm + Clear NET-IO

	PROTECT_RGN_ERROR                       = 21,

	PROTECT_CAN_TIME_OUT_TICKS              = 22,   // in ms 0: no time out fault.

	PROTECT_ALARM_MODE                      = 31

};


// DIO
enum{
    DIO_X0       		= 0,
    DIO_X1       		= 1,
    DIO_X2       	 	= 2,
    DIO_X3        		= 3,
    DIO_X4        		= 4,
    DIO_X5        		= 5,
    DIO_X6        		= 6,
    DIO_X7              = 7,

    DIO_X8              = 8,
    DIO_X9              = 9,
    DIO_X10             = 10,
    DIO_X11             = 11,
    DIO_X12             = 12,
    DIO_X13             = 13,
	DIO_SC_CC_MODE		= 14,	// SC Mode = start/stop, CC Mode = cw stop/ccw stop
	DIO_X_ACT_BITF      = 15,

    DIO_Y0        		= 16,
    DIO_Y1        		= 17,
    DIO_Y2       		= 18,
    DIO_Y3       		= 19,
    DIO_Y4       		= 20,
    DIO_Y5              = 21,

    DIO_Y6              = 22,   // BR1
    DIO_Y7              = 23,   // BR2
    DIO_Y8              = 24,   // BR All

    DIO_MBRAKE_TYPE     = 28,
	DIO_VA_VALUE		= 29,	// "VA" is from oriental, guess it is the initials of "velocity" and "arrive"
	DIO_EN_SPD			= 30,	// Enable out speed.
    DIO_Y_ACT_BITF   	= 31,
    DIO_TOTALNUM  		= 32
};



/*===========================================================================================
	Protection ( major index = 6 )
	parameter ID
	Digital Torque and Duty Region Parameters
//==========================================================================================*/
enum{

    DIGITAL_CTRL_ALGORITHM              = 0,
	DIGITAL_KP						    = 1,
	DIGITAL_CONST_1				        = 2,
	DIGITAL_CONST_2				        = 3,

	DIGITAL_TQ_PID_P				    = 4,
	DIGITAL_TQ_PID_I				    = 5,
	DIGITAL_IQ_PID_P                    = 4,
	DIGITAL_IQ_PID_I                    = 5,

	DIGITAL_ID_PID_P				    = 6,
	DIGITAL_ID_PID_I				    = 7,

	DIGITAL_STEP_DUTY_MAX			    = 8,	// Max feedback duty for single term.
	DIGITAL_DUTY_COMPENSATION           = 9,
	DIGITAL_ALLOWED_ERPM_ERROR_CONST    = 10,
	
	DIGITAL_SPECIAL_0                   = 11,
	DIGITAL_SPECIAL_1                   = 12,
	DIGITAL_SPECIAL_2                   = 13,

	DIGITAL_SPECIAL_3                   = 14,
	DIGITAL_SPECIAL_4                   = 15,

	DIGITAL_NUM                         = 16
};

/*===========================================================================================
	Protection ( major index = 7 )
	parameter ID
	Advanced function Region Parameters
//==========================================================================================*/
enum{

    ADVANCE_FUNC_REVERSE_MODE               = 0,	// REverse Mode, stop or no action
    ADVANCE_FUNC_BATTERY_GAUGE_1            = 1,
    ADVANCE_FUNC_BATTERY_GAUGE_2            = 2,

    ADVANCE_FUNC_SERVO_OFF_DELAY_TIME       = 3,
    ADVANCE_FUNC_STOP_DELAY_TIME			= 4,	// When InstStop works, a delay timer starts after duty meets target duty, leave motor state running after time up
	ADVANCE_FUNC_EMERGENCY_ACC		        = 5,	// Emergency acc rate
	ADVANCE_FUNC_EMERGENCY_DEC			    = 6,	// Emergency dec rate

	ADVANCE_FUNC_TQ_ACC_DEC_TIME		    = 7,	// Torque ACC and DEC time ( unit: ms >> 1A / xms )
	ADVANCE_FUNC_SPK_TQ_PERCENTAGE1		    = 8,	// The Slight-Position-Keeping torque percentage when position error = 0 	( unit: 0.1%, 100% = FWP )
	ADVANCE_FUNC_SPK_TQ_PERCENTAGE2		    = 9,	// The Slight-Position-Keeping torque percentage when lock_ponter != 0 ( unit: 0.1%, 100% = FWP )
	ADVANCE_FUNC_SPK_BRAKE_LOCK_TIME		= 10,	// SPK Lock Delay

	ADVANCE_FUNC_PHASE_ADVANCE_ENABLED      = 11,	// Phase Adv. enable flag.
	ADVANCE_FUNC_PHASE_ADVANCE_RATIO    	= 12,	// Phase Adv. angle ratio setting.
	ADVANCE_FUNC_PHASE_ADVANCE_TICK		    = 13,

	ADVANCE_FUNC_TQ_DEC_TIME                = 14,    // Torque ACC and DEC time ( unit: ms >> 1A / xms )
	ADVANCE_FUNC_ENCODER_DIVIDER            = 15

};

enum{
	BRAKE_MODE_ALWAYS_SHORT_BRAKE			= 0,
	BRAKE_MODE_SHORT_FREE_WHEN_CHANGE_PHASE	= 1,
	BRAKE_MODE_NUM							= 2

};

// Motor stop behavior
enum{
    MOTOR_STOP_BEHAVIOR_FREE                = 0,
    MOTOR_STOP_BEHAVIOR_BRAKE               = 1,
	MOTOR_STOP_BEHAVIOR_LOCK			    = 2,
    MOTOR_STOP_BEHAVIOR_NUM         		= 3
};

// Position definition mode
enum{
	POSITION_DEF_MODE_ENCODER               = 0,
	POSITION_DEF_MODE_COMBINATION           = 1,
	POSITION_DEF_MODE_NUM         			= 2
};

/*===========================================================================================
	Protection ( major index = 8 )
	parameter ID
	Communication Region Parameters
//==========================================================================================*/
enum{
	COM_PA_X1_FUNC							= 0,
	COM_PA_X2_FUNC							= 1,
	COM_PA_X3_FUNC							= 2,
	COM_PA_X4_FUNC							= 3,
	COM_PA_X5_FUNC							= 4,
	COM_PA_X6_FUNC							= 5,
	COM_PA_X7_FUNC							= 6,
	COM_PA_X8_FUNC							= 7,

	COM_PA_X9_FUNC                          = 8,
    COM_PA_X10_FUNC                         = 9,
    COM_PA_X11_FUNC                         = 10,
    COM_PA_X12_FUNC                         = 11,
    COM_PA_X13_FUNC                         = 12,
    COM_PA_X14_FUNC                         = 13,
    COM_PA_X15_FUNC                         = 14,
    COM_PA_X_ACT_BITF                       = 15,

	COM_PA_DATA_WATCH_SEL					= 16,	// Select DynamicData and HWEEP display items.
	COM_PA_485_SETTINGS				        = 17,	// Physical settings : Data bits, Stop bit and Parity

	COM_PA_485_CAN_ID					    = 18,
	COM_PA_485_BAUDRATE					    = 19,
	COM_PA_485_FRAME_LENGTH_LIMIT			= 20,	// 0 = 1.75ms, 1 = 1.50ms, 2 = 1.25ms, 3 = 1.00ms, 4 = 0.75ms, 5 = 0.50ms
	COM_PA_CAN_BAUDRATE                     = 21,

	COM_PA_CANOPEN_PDO_MAPPING_SELECT       = 25,
	COM_PA_CANOPEN_TPDO_TRIGGER_TYPE        = 26,
	COM_PA_CANOPEN_RPDO_TRIGGER_TYPE        = 27,
	COM_PA_CANOPEN_HEARTBEAT_TIME           = 28,
	COM_PA_CANOPEN_MODE                     = 29,
	COM_PA_CAN_MODE                         = 30,   // Currently no option
	COM_PA_RS485_CAN_SELECT                 = 31
};

enum{
    CANOPEN_PDO_MAPPING_SELECT_ENCODER      = 0,
    CANOPEN_PDO_MAPPING_SELECT_HALL         = 1,
    CANOPEN_PDO_MAPPING_SELECT_GPM          = 2,
    CANOPEN_PDO_MAPPING_SELECT_NUM          = 3
};

enum{
    CANOPEN_MODE_BIT_0_ID_LENGTH            = 0,
    CANOPEN_MODE_BIT_1_INIT_STATE           = 1,
    CANOPEN_MODE_BIT_NUM                    = 2
};

enum{
    RS485_CAN_SELECT_485    = 0,
    RS485_CAN_SELECT_CAN    = 1,
    RS485_CAN_SELECT_NUM    = 2
};


// UART TimeOut behavior
enum{
    UART_TIMEOUT_BEHAVIOR_ONLY_ALARM        			= 0,
	UART_TIMEOUT_BEHAVIOR_CLEAR_NET_IO     	 			= 1,
	UART_TIMEOUT_BEHAVIOR_CLEAR_NET_IO_AND_ALARM      	= 2,
	UART_TIMEOUT_BEHAVIOR_NUM      						= 3
};

/*===========================================================================================
   Parameter Major Start Address
//==========================================================================================*/
enum{
	PA_ALM_HIS_ADDS_INDEX		= 50
};

#define HALL_SEQUENCE	CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ MOTOR_HALL_SEQUENCE ]
#define CW_DIRECTION	CG_Parameter.RAM_data[ PARAMETER_MOTOR ][ MOTOR_FORWARD_DIR ]
#define VR_MIN_MODE		CG_Parameter.RAM_data[ PARAMETER_GENERAL ][ GENERAL_VR_MINVALUE_DEF ]

/*===========================================================================================
   Parameter Variable data structure
//==========================================================================================*/
typedef struct{

    int32_t dynamic_data			[ PARAMETER_MINOR_NUM ];
    int32_t RAM_data				[ PARAMETER_MAJOR_NUM ][ PARAMETER_MINOR_NUM ];	// PA RAM_USE
    int32_t EEP_data_max			[ PARAMETER_MAJOR_NUM ][ PARAMETER_MINOR_NUM ]; // PA_in RAM_USE + EEP
    int32_t EEP_data_min			[ PARAMETER_MAJOR_NUM ][ PARAMETER_MINOR_NUM ]; // PA_in RAM_USE + EEP
    int32_t EEP_data_default		[ PARAMETER_MAJOR_NUM ][ PARAMETER_MINOR_NUM ]; // PA_in RAM_USE + EEP
	int32_t EEP_data				[ PARAMETER_MAJOR_NUM ][ PARAMETER_MINOR_NUM ]; // PA RAM_EEP ( EEP reflection. )

	int32_t Monitor_data_M0         [ PARAMETER_MONITOR_DATA_NUM ];
	int32_t Monitor_data_M1         [ PARAMETER_MONITOR_DATA_NUM ];

	int32_t Monitor_data_Engineer	[ PARAMETER_MONITOR_DATA_NUM ];

}Struct_Parameter;


/*===========================================================================================
   Parameter Minor Macros by each Type Start >>>>
//==========================================================================================*/
// Hall Sequence defines
enum{
    HALL_SEQUENCE_B                 = 0,
    HALL_SEQUENCE_A                 = 1,
    HALL_SEQUENCE_NUM               = 2
};

// Foward Dir defines
enum{
    FORWARD_DIR_TOP                 = 0,
    FORWARD_DIR_BOTTOM              = 1,
    FORWARD_DIR_NUM                 = 2
};


// SC_CC mode defines
enum{
    SC_MODE                         = 0,
    CC_MODE                         = 1,
    SC_CC_MODE_NUM                  = 2
};

// VR min def defines
enum{
    VR_MINVALUE_DEF_STOP            = 0,
    VR_MINVALUE_DEF_RUN             = 1,
    VR_MINVALUE_DEF_NUM             = 2
};

// Phase Adv en defines
enum{
    PHASE_ADVANCE_DISABLED          = 0,
    PHASE_ADVANCE_ENABLED           = 1,
    PHASE_ADVANCE_SWITCH_NUM        = 2
};

enum{
	FEATRUE_NO_BRAKE				= 0,
	FEATRUE_BRAKE					= 1,
	FEATRUE_NUM						= 2
};

// AD def defines
enum{
    AD_MODE_0            			= 0,
    AD_MODE_1             			= 1,
    AD_MODE_NUM            			= 2
};


enum{
    PA_SENSOR_DEFAULT               = 0,
    PA_SENSOR_HALL,
    PA_SENSOR_ENCODER_TAMAGAWA,
    PA_SENSOR_ENCODER_PLUS_HALL,
    PA_SENSOR_ENCODER_ALLEGRO,
    PA_SENSOR_HALL_ENCODER_AB,
    PA_SENSOR_ENCODER_SIRUBA,
    PA_SENSOR_NUM
};

/*===========================================================================================
   <<<< Parameter Minor Macros by each Type End
//==========================================================================================*/

/*===========================================================================================
   Parameter Const Table Setup
//==========================================================================================*/
// Parameter max const table
#define EEP_PARAMETER_MAX	65535
#define EEP_PARAMETER_MIN	0

// Parameter real time updated allowed setting bit field (0: can only change when motor not running, 1: can change while motor is running)
extern const uint32_t CG_RealTime_Paramter_BITF[ PARAMETER_MAJOR_NUM ];

// Parameter write enable setting bit field ( 0: Read only, 1: write/read )
extern const uint32_t CG_WriteEn_Paramter_BITF[ PARAMETER_MAJOR_NUM ];

/*===========================================================================================
    Function Name    : variableInitial_Parameter
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_Parameter initial
//==========================================================================================*/
void variableInitial_Parameter( void );

/*===========================================================================================
    Function Name    : update_MonitorData
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : update monitor data
//==========================================================================================*/
void update_MonitorData( void );
	
/*===========================================================================================
    Function Name    : readFWEEP
    Input            : Null
    Return           : result : 1 = good, 0 = bad
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : readFWEEP
//==========================================================================================*/
uint32_t readFWEEP( void );

/*===========================================================================================
    Function Name    : readEEP
    Input            : 1. major_index: Data major index.
					   2. data_num: the number of data to load.
					   3. *dst: the destination array to put data.
    Return           : true or false, return flase if EEP error (out of flash range).
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Load EEP data to parameter 
//==========================================================================================*/
uint32_t readEEP ( const uint32_t major_index, const uint32_t data_num, int32_t* dst );

/*===========================================================================================
    Function Name    : readEEPParameter
    Input            : 1. major_index: Data major index
    Return           : true or false, return flase if EEP error (out of flash range).
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Load EEP data to parameter 
//==========================================================================================*/
uint32_t readEEPParameter( uint32_t major_index );

/*===========================================================================================
    Function Name    : saveEEPParameter
    Input            : 1. major_index: Data major index
					   2. minor_index: Data minor index
					   3. data:		   Data that will be saved.
					   4. eepWO: EEP write only flag. 1:eep write without check, 0: eep write and check.
    Return           : Result: when write and check return the check result: 1:eep ok, 0:eep bad(data not match).
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Save single parameter to EEP. (and update RAM)
//==========================================================================================*/
uint8_t saveEEPParameter_Single( const uint32_t major_index, const uint32_t minor_index, const int32_t data, const uint32_t eepWO );

/*===========================================================================================
    Function Name    : saveEEPParameter_Multiple
    Input            : 1. major_index : major address of the start address of pa.
					   2. minor_index : minor address of the start address of pa.
					   3. quant_of_reg : the data quantity to save.
					   4. *data : CG_Modbus_Slave.req_pdu_data[i]. the data value.
					   5. eepWO: EEP write only flag. 1:eep write only, 0: eep write and check.
    Return           : Result: when write and check return the check result: 1:eep ok, 0:eep bad(data not match).
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Save multiple parameter to EEP. (and update RAM)
					   Each data takes 2 bytes.
					   The max quantity of bytes can be saved to EEP is limited by the EEP (MAX_OP_BYTE_NUM).
					   If the bytes to be saved is more than this number. Then seperate the data
					   into groups for several times.
//==========================================================================================*/
uint8_t saveEEPParameter_Multiple( const uint32_t major_index, const uint8_t minor_index,
							    const int32_t quant_of_reg, const int32_t *data, const uint32_t eepWO );

/*===========================================================================================
    Function Name    : copy_Single_EEP_to_RAM_Pa
    Input            : 
					   1. major: Data major index
					   2. minor: Data minor index
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update speceil parameters.
//==========================================================================================*/
void copy_Single_EEP_to_RAM_Pa( uint8_t major, uint8_t minor );

/*===========================================================================================
    Function Name    : parameter_Range_Check
    Input            : 1. major: modbus address_h - 1 (mapping from com address to eep address)
					   2. minor: minor index of the parameter.
					   3. data: value to check.
    Return           : return_value: true or false, return flase if out of range.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : check parameter, def range with max, min.
					   check max, min with constant flash table
//==========================================================================================*/
uint8_t parameter_Range_Check ( int32_t major, int32_t minor, int32_t data );

/*===========================================================================================
    Function Name    : multi_parameter_Range_Check
    Input            : 1. major: modbus address_h - 1 (mapping from com address to eep address)
					   2. minor: minor index of the parameter.
					   3. quantity_of_data : the data number to check.
					   4. *data : the data value array pointer.
    Return           : return_value: true or false, return false if out of range.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : check multiple parameter range.
//==========================================================================================*/
uint8_t multi_parameter_Range_Check ( int32_t major, int32_t minor, int32_t quantity_of_data, int32_t *data,
									   int32_t *fault_major,  int32_t *fault_minor );

/*===========================================================================================
    Function Name    : parameter_multi_WriteEn_Check
    Input            : 1. major: major index of the parameter.
					   2. minor: minor index of the parameter.
					   3. data_num: the data number to check.
    Return           : return_value: true or false, return false if any of the value is not allowed to change.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : check multiple data write with the writeEN bit field.
					   Return false if any of the value is not allowed to change.
//==========================================================================================*/
uint8_t multi_parameter_WriteEn_Check ( uint8_t major, uint8_t minor, int32_t data_num );

/*===========================================================================================
    Function Name    : parameter_RealTime_Check
    Input            : 1. major: major index of the parameter.
                       2. minor: minor index of the parameter.
    Return           : return_value: true or false
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Return false if the value is not allowed to change while motor is running.
//==========================================================================================*/
uint8_t parameter_RealTime_Check ( uint8_t major, uint8_t minor );

/*===========================================================================================
    Function Name    : updateSpeceilParameter
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Update speceil parameters.
//==========================================================================================*/
void updateSpeceilParameter( void  );

#endif

/************************** <END OF FILE> *****************************************/


