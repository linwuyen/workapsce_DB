/*===========================================================================================

    File Name       : NTC06.h

    Version         : V1.00_a

    Built Date      : 2022/03/07

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     :

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */
#ifndef NTC06_H
#define NTC06_H
#include "Type.h"

#define NTC06_FULL_RANGE        100
#define NTC06_INDEX_0_TEMP      0
#define NTC06_INDEX_MAX_TEMP    99


#define NTC06_DIVIDER_RESISTOR  3300L//330 // Unit: 0.01K; ex: 330 = 3.3K


typedef struct{

    int16_t Temperature_Left;
    int16_t Temperature_Right;

    int16_t Temperature;

}Struct_NTC_Temperature;

/*===========================================================================================
    Function Name    : variableInitial_NTC_Temperature
    Input            : ntc
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_NTC_Temperature ( Struct_NTC_Temperature *ntc );

/*===========================================================================================
    Function Name    : calculate_NTCADC
    Input            : 1.temp
    Return           : ADC
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t calculate_NTCADC( uint32_t temp );

/*===========================================================================================
    Function Name    : calculate_NTCResistor
    Input            : 1.ntc
                       2.adc_value: ADC value
    Return           : Temperature ( Unit: 1 degree C )
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t calculate_NTCTemp( Struct_NTC_Temperature *ntc, uint32_t adc_value );

#endif

/************************** <END OF FILE> *****************************************/
