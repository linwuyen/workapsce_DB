/*===========================================================================================

    File Name       : MotorMove_TypeDef.h

    Version         : V1_00_10_a

    Built Date      : 2020/08/19

    Release Date    : Not Yet

    Programmer      : Chaim.Chen@trumman.com.tw

    Description     : 

    =========================================================================================

    History         :

===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef MOTOR_MOVE_TYPEDEF_H
#define MOTOR_MOVE_TYPEDEF_H

enum{
    POS_IMR         = 0,            // Data of Position IMR command
    POS_MR          = 1,            // Data of Position MR command
    POS_MA          = 2,            // Data of Position MA command
    POS_CS          = 3,            // Data of Position CS command
    POS_DATA_NUM    = 4
};


typedef struct{
	
	int16_t	Position_Mode;

	int32_t	Target_RPM_abs;				// from command
		
	int32_t	Path_Speed_RPM_Limit_abs;	
	int32_t	digital_target_rpm_abs;		// digital speed
	
	int32_t	Path_Speed_ERPM_Limit;
	int32_t	Path_Speed_ERPM;
	int32_t	Path_Speed_Const;
	
	int32_t Acc;
	int32_t Dec;

	int32_t PosError;

	int32_t	Offset_Index;
	int32_t	Offset_Pos;
	
	int32_t	Target_Index;
	int32_t	Target_Pos;
	
	int32_t	Current_Target_Index;
	int32_t	Current_Target_Pos;
	
	int32_t	Current_Index;
	int32_t	Current_Pos;
	
	int32_t	Capture_Index;
	int32_t	Capture_Pos;
	
	int32_t	Max_Error;
	
	int32_t JG_Step;
	uint32_t PI_cnt_old;
	uint32_t PI_cnt_delta;

	// ==
	int8_t  IMR_Flag;
	
	int32_t	IMR_SpeedInitInRPM;
	int32_t	IMR_SpeedInitInERPM;
	int32_t	IMR_SpeedInitInMs;
	int32_t	IMR_Dec_Const;
	int32_t	IMR_Dec;
	int32_t	IMR_Dec_Rest;
	
	int32_t Buffer_IMR_Limit;		// min buffer for IMR
	int32_t Buffer_IMR_CMD;			// CMD buffer for IMR
	int32_t Buffer_IMR;
	
	int32_t Buffer_IMR_GCD;
	int32_t Buffer_Norm_GCD;
	
	
	// ==
	
	int32_t	MR_Index;
	int32_t	MR_Pos;
	
	int32_t	MA_Index;
	int32_t	MA_Pos;
	
	// index when z was not detected yet
	int32_t	B4Z_Index;
	int32_t	B4Z_Last_Pos;
	int32_t Z_Processed_Flag;
	
	int32_t Z_Index;
	int32_t Z_Pos;

	// Motor state from run to move
	int8_t Run2Move_Flag;
	int8_t Lock2Move_Flag;
	
	int8_t  Move2Run_Flag; 
	int32_t Move2Run_Duty;

	int16_t	Stop_Enabled;
		
	// test
	int32_t Integrated_Error;
	int32_t fb_factor;
	
	int32_t duty_fb_old;
	int32_t duty_change;
	int32_t duty_change_record;
	
	
	int32_t record_Current_Index;
	int32_t record_Current_Pos;
	
	int32_t record_Current_Target_Index;
	int32_t record_Current_Target_Pos;
	
	int32_t record_Target_Index;
	int32_t record_Target_Pos;
	
	//

	int32_t Meat_Target_Flag;

	//

	int32_t Pulse_Stamp_1;
	int32_t Pulse_Stamp_2;
	int32_t Pulse_Delta;

	int32_t Inst_Speed_1;
	int32_t Inst_Speed_2;

	int32_t Inst_Acc;
	int32_t Inst_Speed_Acc_Const;

	int32_t Target_Erpm;

	int32_t Loop_1_Target;
	int32_t Loop_2_Target;
	int32_t Loop_3_Target;
	int32_t Loop_4_Target;

	int32_t Loop_1_Rest;
	int32_t Loop_2_Rest;
	int32_t Loop_3_Rest;
	int32_t Loop_4_Rest;

	int32_t Step_Pos;
	int32_t Step_Pos_Rest;

	int32_t Restraint_Flag;

	int32_t Kp_Factor;

	int32_t ChangeSpdFlag;

	int32_t Min_Speed;

}Struct_Move;


#endif

/************************** <END OF FILE> *****************************************/
