/*===========================================================================================
    File Name       : IncludeFiles.h
    Built Date      : 2015-02-02
    Version         : V1.00r
    Release Date    : Not Yet
    Programmer      : Chaim.Chen@trumman.com.tw
    Description     : This file includes all used head files.
					  The version release is for the over all structure of this file not the content.
    =========================================================================================
    History         : 2012-12-24 first released version
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef INCLUDE_FILE_H
#define INCLUDE_FILE_H


#include "F28x_Project.h"

//==
#include "Type.h"
#include "MD.h"

#include "I04_GPIO.h"
#include "C2000_Timer.h"
#include "C2000_UART232.h"
#include "C2000_UART485.h"
#include "F280XX_WDT.h"
#include "F280XX_I2C.h"
#include "C2000_ADC.h"
#include "C2000_BLDC_Drive.h"
#include "C2000_Encoder.h"
#include "F280XX_CAP.h"
#include "C2000_CAN.h"

//

#include "ModBus_Slave.h"
#include "ModBus_Slave_ASCII.h"
#include "ModBus_Slave_RTU.h"

#include "IO.h"
#include "IO_Func.h"
#include "HWEEP_Setting.h"
#include "IDA1_Parameter.h"
#include "IDA1_BLDC_CTRL.h"
#include "PIDControl.h"
#include "SpeedControl.h"
#include "PositionControl.h"
#include "Opearation_Mode.h"
#include "Protect_Setting.h"
#include "ModBus_Slave.h"
#include "ModBus_Slave_ASCII.h"
#include "COM_Protocol_01.h"
#include "misc_func_lib.h"
#include "ModBus_Slave_RTU.h"
#include "Multi_Drive_Lite.h"
//#include "C2000_PhaseAdv.h"
#include "HallSensor.h"
#include "MotorMove.h"
#include "SlightPositionKeeping.h"
//#include "IO_Expander.h"

//


/*













#include "Duty_Control.h"




*/

#endif

/************************** <END OF FILE> *****************************************/
