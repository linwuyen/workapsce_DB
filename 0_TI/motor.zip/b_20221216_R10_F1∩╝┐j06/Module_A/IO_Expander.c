/*
 * IO_Expander.c
 *
 *  Created on: 2020�~7��13��
 *      Author: Chaim.Chen
 */
#include "IncludeFiles.h"
#include "IO_Expander.h"

volatile Struct_IO_Expander      CG_IO_Expander;

extern volatile Struct_I2C       CG_I2C;
extern volatile Struct_MD        CG_MD;

/*===========================================================================================
    Function Name    : setupInitial_IO_Expander
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t setupInitial_IO_Expander()
{

    int32_t result = 1;
    uint8_t dummy_data[2];

    //CG_IO_Expander.XnNormState_BITF = 0;
    //CG_IO_Expander.YnActState_BITF = 0xffff;
    CG_IO_Expander.YnActState_BITF = IO_EXPANDER_ACT_BITF_INIT;

    if( CG_MD.HW_Ver == HW_VER_A ){
        CG_IO_Expander.XnNormState_BITF = 0;
        CG_IO_Expander.Configure = ( 1UL << IO_EXP_M1_ER ) | ( 1UL << IO_EXP_M2_ER );
    }else{
        CG_IO_Expander.XnNormState_BITF = ( 1UL << IO_EXP_COMM_ID_SW0 ) | ( 1UL << IO_EXP_COMM_ID_SW1 );
        CG_IO_Expander.Configure =  ( 1UL << IO_EXP_COMM_ID_SW0 ) | ( 1UL << IO_EXP_COMM_ID_SW1 ) |
                                    ( 1UL << IO_EXP_MBRAKE_SENSE_M1 ) | ( 1UL << IO_EXP_MBRAKE_SENSE_M2 ) |
                                    ( 1UL << IO_EXP_M1_ER ) | ( 1UL << IO_EXP_M2_ER );
    }

    dummy_data[0] = ( CG_IO_Expander.Configure >> 0 ) & 0xFF;
    dummy_data[1] = ( CG_IO_Expander.Configure >> 8 ) & 0xFF;

    result &= writeAndCheckDataEEP( IO_EXPANDER_ADDRESS, IO_EXPANDER_TYPE, IO_EXP_REG_CONFIG_0, dummy_data, 2 );
    //result &= writeAndCheckDataEEP( IO_EXPANDER_ADDRESS, IO_EXPANDER_TYPE, IO_EXP_REG_CONFIG_0, &dummy_data[0], 1 );
    //result &= writeAndCheckDataEEP( IO_EXPANDER_ADDRESS, IO_EXPANDER_TYPE, IO_EXP_REG_CONFIG_1, &dummy_data[1], 1 );

    CG_IO_Expander.Data_Flag = NO;

    return result;

}

/*===========================================================================================
    Function Name    : writeData_IOExp
    Input            :
                       1.slaveID: S2S1S0
                       2.address: EEP address
                       3.data   : data needs to write
                       4.num    : data length.
    Return           : Is_Write_Success
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
uint16_t writeData_IOExp( uint8_t slaveID, uint32_t address, uint8_t * data, uint8_t num )
{
#if(1)
    Uint16 i = 0;
    Uint16 datanum = 0;

    //while( CG_I2C.Busy_flag == 1 );    // Wait for I2C to be not busy
    if( CG_I2C.Busy_flag == 1 ){
        CG_I2C.State_BIFT |= ( 1UL << EEP_BUSY );
        return 0;
    }

    // Wait until the STP bit is cleared from any previous master communication.
    // Clearing of this bit by the module is delayed until after the SCD bit is
    // set. If this bit is not checked prior to initiating a new message, the
    // I2C could get confused.
    if( I2caRegs.I2CMDR.bit.STP == 1 ){
        CG_I2C.State_BIFT |= ( 1UL << STOP_MISSED );
        return 0;
    }

    // Setup slave address
    I2caRegs.I2CSAR.all = slaveID;

    // Check if bus busy
    if( I2caRegs.I2CSTR.bit.BB == 1 ){
        CG_I2C.State_BIFT |= ( 1UL << STUCK_IN_BUSY );
        return 0;
    }

   // Setup number of bytes to send
    CG_I2C.WriteLength = BASIC_WRITE_LENGTH_2KBIT  + num;   // address ( 1byte ) + num
    CG_I2C.T_Data[ datanum++ ] = address;

    I2caRegs.I2CCNT = CG_I2C.WriteLength;

    CG_I2C.WrIndex = 0;

    for( i = 0; i < num; i++ ){
        CG_I2C.T_Data[ datanum++ ] = data[ i ];
    }

    //CG_I2C.write_delay_counter = I2C_WRITE_DELAY_TIME - 2;
    CG_I2C.write_delay_counter = I2C_WRITE_DELAY_TIME - 1;
    CG_I2C.Busy_flag = 1;
    CG_I2C.MasterState      = I2C_WRITE_STARTED;
    // Send start as master transmitter
    CG_IO_Expander.Data_Flag = NO;

    I2caRegs.I2CMDR.all = 0x2E20;
#endif

    return 1;
}

/*===========================================================================================
    Function Name    : readData_IOExp
    Input            :
                       1.slaveID: S2S1S0
                       2.address: EEP address
                       3.num    : data length.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Read data from EEP
//==========================================================================================*/
uint16_t readData_IOExp( uint8_t slaveID, uint32_t address, uint8_t num )
{

    //Uint16 i = 0;

    //while( CG_I2C.Busy_flag == 1 );    // Wait for I2C to be not busy
    if( CG_I2C.Busy_flag == 1 ){
        CG_I2C.State_BIFT |= ( 1UL << EEP_BUSY );
        return 0;
    }

    // Wait until the STP bit is cleared from any previous master communication.
    // Clearing of this bit by the module is delayed until after the SCD bit is
    // set. If this bit is not checked prior to initiating a new message, the
    // I2C could get confused.
    if( I2caRegs.I2CMDR.bit.STP == 1 ){
        CG_I2C.State_BIFT |= ( 1UL << STOP_MISSED );
        return 0;
    }

    I2caRegs.I2CSAR.all = slaveID;

    // Check if bus busy
    if( I2caRegs.I2CSTR.bit.BB == 1 ){
        CG_I2C.State_BIFT |= ( 1UL << STUCK_IN_BUSY );
        return 0;
    }

    CG_I2C.WriteLength = BASIC_WRITE_LENGTH_2KBIT;  // address ( 1byte )
    CG_I2C.T_Data[ 0 ] = address;

    I2caRegs.I2CCNT = CG_I2C.WriteLength;

    CG_I2C.RdIndex = 0;
    CG_I2C.WrIndex = 0;
    CG_I2C.ReadLength = num;

    //CG_I2C.write_delay_counter = I2C_WRITE_DELAY_TIME - 2;
    CG_I2C.write_delay_counter = I2C_WRITE_DELAY_TIME - 1;
    CG_I2C.Busy_flag = 1;

    CG_I2C.MasterState      = I2C_READ_STARTED;

    I2caRegs.I2CMDR.all     = 0x2620;           // Send data to setup EEPROM address

    CG_I2C.error_counter = 0;

    CG_IO_Expander.Data_Flag = YES;

    /*
    while( CG_I2C.MasterState != I2C_READY );

    for( i = 0; i < num; i++ ){
        data[ i ] = CG_I2C.R_Data[ i ];
    }


    if( CG_I2C.State_BIFT == 0 ){
        return 1;
    }else{
        return 0;
    }*/

    return 1;

}


/*===========================================================================================
    Function Name    : ioExp_SetOutput
    Input            : 1.index
                       2.state
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void ioExp_SetOutput( int32_t index, int32_t state )
{
    int32_t act_state = ( CG_IO_Expander.YnActState_BITF >> index ) & 0x01;
    //  state,  act state, final
    //      1,          1, >> 1
    //      1,          0, >> 0
    //      0,          1, >> 0
    //      0,          0, >> 1
    state = 1 - ( act_state ^ state );

    if( state ){
        CG_IO_Expander.Yn_State_BITF |=  ( 1 << index );
    }else{
        CG_IO_Expander.Yn_State_BITF &= ~( 1 << index );
    }
}

/*===========================================================================================
    Function Name    : ioExp_ToggleOutput
    Input            : 1.index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void ioExp_ToggleOutput( int32_t index )
{
    if( ( CG_IO_Expander.Yn_State_BITF >> index ) & 0x01 ){
        CG_IO_Expander.Yn_State_BITF &= ~( 1 << index );
    }else{
        CG_IO_Expander.Yn_State_BITF |=  ( 1 << index );
    }
}

/*===========================================================================================
    Function Name    : ioExp_RoutineWork
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Put at 1ms event
//==========================================================================================*/
void ioExp_RoutineWork()
{
    static int16_t timer = 0;
    uint8_t dummy_data[2];

    timer++;

    if( timer == 5 ){ // Write

        if( CG_IO_Expander.Data_Flag ){
            CG_IO_Expander.Data_Flag = NO;
            CG_IO_Expander.Xn_State_BITF = ( ( CG_I2C.R_Data[1] << 8 ) | CG_I2C.R_Data[0] ) ^ CG_IO_Expander.XnNormState_BITF;
        }

        dummy_data[0] = ( CG_IO_Expander.Yn_State_BITF >> 0 ) & 0xFF;
        dummy_data[1] = ( CG_IO_Expander.Yn_State_BITF >> 8 ) & 0xFF;
        writeData_IOExp( IO_EXPANDER_ADDRESS, IO_EXP_REG_OUTPUT_0, dummy_data, 2 );

    }else if( timer == 10 ){  // Read
        timer = 0;
        //readData_IOExp( IO_EXPANDER_ADDRESS, IO_EXP_REG_INPUT_1, 1 );
        readData_IOExp( IO_EXPANDER_ADDRESS, IO_EXP_REG_INPUT_0, 2 );

    }

}



/************************** <END OF FILE> *****************************************/
