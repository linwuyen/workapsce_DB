/*===========================================================================================

    File Name       : ModBus_Slave_RTU_V1_00r.c

    Version         : V1.01a

    Built Date      : 2014/09/23

    Last Update    	: 2014/09/25

    Programmer      :  Eic.Tsai@trumman.com.tw

    Description     : 
			
    =========================================================================================

    History         : 2015-11-12 V1.01a (R8): Multi-driver control FC implement. PE02-74 bug fix.
									
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

extern volatile Struct_Modbus_Slave 	CG_Modbus_Slave;
extern volatile Struct_MD				CG_MD;
extern volatile Struct_Parameter		CG_Parameter;
extern volatile Struct_UART485          CG_UART485;

#if(PROTOCOL_MODE==1)
extern volatile Struct_ComProtocol_01 CG_ComProtocol_01;
#endif

extern volatile Struct_MDL                                 CG_MDL;

/*===========================================================================================
    Function Name    : data_fill_in_Converter_RTU
    Input            : 
					   1. src : address of src array
					   2. dst : address of dst array
					   3. data_byte_length : total byte length ( ex: move 2 int value = 2 * 2 = 4 bytes )
					   4. data_type : 1 = char, 2 = int, 4 = long
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : This is a array copy function, it will copy data from src to dst one by one.
					   Convert unchar into ascii if the data is int.
			           Notice that : It is not a general function, it is designed for modbus data return fuction at FC3 only
					   This Function only support char and int currently.
//==========================================================================================*/
void data_fill_in_Converter_RTU( unsigned char *src,
							 unsigned char *dst,
                             int data_byte_length,
                             int data_type )
{

	if( data_type == Data_Type_One_Byte  ){
			
		*(dst++) = src[ 0 ];
		*(dst++) = src[ 1 ];                                                 
		*(dst++) = src[ 2 ];
		*(dst++) = src[ 3 ];  
		
	}else{
	
		*(dst++) = src[ 1 ]; 
		*(dst++) = src[ 0 ];

	}

}

/*===========================================================================================
    Function Name    : mb_idle_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : mb idle routine to check the received data.
					   Set to mb_req_checking if uart received data is done. 
//==========================================================================================*/
void mb_idle_RTU ( 	uint8_t *ReceiveFlag,
				uint8_t *data,
				uint32_t data_num,
				uint8_t *T_data,
				uint8_t *T_data_Length,
				uint8_t *T_send_flag,
				uint8_t *T_data_ptr,
				Struct_Modbus_Slave *str_modbus
				)
{
	
	// Waiting for a request from Master.
	if ( *ReceiveFlag == UART_DONE ) {
	
		// Set uart state to busy.
		*ReceiveFlag = UART_BUSY;

		// Reset Exception Code.
		str_modbus->ExceptionCode = 0;
		//str_modbus->ExceptionCode_Secondary = 0;
		//str_modbus->SecondEcho_State = SECOND_ECHO_STATE_IDLE;
		
		// Set modbus_slave state into checking.
		str_modbus->State = MB_SLV_REQ_CHECKING;
		
	}
	
	// Com protocol time out check.
	#if(PROTOCOL_MODE==1)
		//modBus_TimeOut_Check( str_modbus, str_modbus->Time_Out_num );
	#else
		modBus_TimeOut_Check( str_modbus, 2000 );
	#endif

}


/*===========================================================================================
    Function Name    : mb_req_checking_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : mb request protocol data unit check.
					   Check frame and SlaveID.
					   Set to processing if all check passed.
					   Set to idle if frame check failed.
					   Set to error response if one of the function code, address or data check failed.
					   Set to broadcast ending if function code check failed in broadcast mode.
	LastUpData		 : 2014 0219 
//==========================================================================================*/
void mb_req_checking_RTU ( uint8_t *ReceiveFlag,
					   uint8_t *data,
					   uint32_t data_num,
					   uint8_t *T_data,
					   uint8_t *T_data_Length,
					   uint8_t *T_send_flag,
					   uint8_t *T_data_ptr, 
					   Struct_Modbus_Slave *str_modbus
)
{
	uint8_t is_frame_ok = NO;
	// Get function code and slaveID from the received buffer.
	str_modbus->req_pdu_slaveID				= data[0];
	str_modbus->req_pdu_function_code    	= data[1];
	
	// SlaveID ( Starting Address ) Check ( including broadcast check )
	str_modbus->FlagBITF &= ~(1 << MB_BROAD_CAST_BIT);						// Reset broadcast flag.

	switch ( str_modbus->req_pdu_function_code ) {
		// Normal FC
		case MB_FC3:		// Read
		case MB_FC6:		// Write single
		case MB_FC8:		// Diagnostics
		case MB_FC16:		// Write multiple
		default:
			is_frame_ok = mbRTU_General_FC_Check ( ReceiveFlag, (uint8_t*)data, data_num, str_modbus );
			break;
#ifdef MULTI_DRIVE_LITE
		case MB_FC65:
			is_frame_ok = mbRTU_FC65_Check ( ReceiveFlag, (uint8_t*)data, data_num, str_modbus );
			break;
		case MB_FC66:
		case MB_FC67:
			is_frame_ok = mbRTU_FC66_Check ( ReceiveFlag, (uint8_t*)data, data_num, str_modbus );
			break;
#endif
		case MB_FC101:		// Multi-driver request
			is_frame_ok = mbRTU_FC101_Check ( ReceiveFlag, (uint8_t*)data, data_num, str_modbus );
			break;

		case MB_FC102:		// Multi-driver reply
		case MB_FC103:		// Multi-driver reply
			is_frame_ok = mbRTU_FC102_Check ( ReceiveFlag, (uint8_t*)data, data_num, str_modbus );
			break;
		//default:

			//is_frame_ok = NO;
			//str_modbus->FlagBITF |= _BIT( MB_FRAME_COM_ALARM_BIT );
			//*ReceiveFlag 			= UART_READY;				// enable Uart recieve
			//str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

			//break;
	}


	// COM protocol error Fault, Alarm, WNG check.
	#if(PROTOCOL_MODE==1)
		com_Fault_handler ( str_modbus, is_frame_ok );
	#endif
}


/*===========================================================================================
    Function Name    : mb_req_processing_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : mb request protocol data unit processing.
					   Set to normal response if processing done without error.
					   Set to Error response if error ocurred while processing.
					   Set to broadcast end after processing regardless error in broadcast mode.
	LastUpData		 : 2014 0219 				   
//==========================================================================================*/
void mb_req_processing_RTU ( uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr, 
						 Struct_Modbus_Slave *str_modbus
)
{
	uint8_t lc_is_MultiDriver_ctrl = 0;		// 0 = normal FC, 1 = multi=driver FC

	switch ( str_modbus->req_pdu_function_code ) {
		// Read
		case MB_FC3:
			mB_Function_FC3_RTU ( str_modbus );
			break;
			
		// Write single
		case MB_FC6:
			mB_Function_FC6_RTU ( data_num, (uint8_t*)data, str_modbus );
			//mB_Function_FC6_Write_check_RTU ( str_modbus);
			break;
			
		// Diagnostics
		case MB_FC8:
			mB_Function_FC8_RTU ( data_num, (uint8_t*)data, str_modbus );	
			break;		
		
		// Write multiple
		case MB_FC16:
			mB_Function_FC16_RTU ( data_num, (uint8_t*)data, str_modbus );
			//mB_Function_FC16_Write_check_RTU ( (uint8_t*)data, str_modbus->req_pdu_data_quantity, str_modbus );
			break;
#ifdef MULTI_DRIVE_LITE
		case MB_FC65:
			//com_FC65_Processing ( (uint8_t*)data, MB_SLV_RTU, str_modbus );
			str_modbus->FlagBITF |= (1 << MB_FC_EXECUTE_REQ_BIT);
			lc_is_MultiDriver_ctrl = 2;			// Multi-Drive Lite
			break;
		case MB_FC66:
		case MB_FC67:
			com_FC66_Processing ( (uint8_t*)data, MB_SLV_RTU, str_modbus );
			str_modbus->FlagBITF &= ~(1 << MB_FC_EXECUTE_REQ_BIT);
			lc_is_MultiDriver_ctrl = 2;			// Multi-Drive Lite
			break;
#endif
		// Multi-driver ctrl request
		case MB_FC101:
			//com_FC101_Processing ( (uint8_t*)data, MB_SLV_RTU, str_modbus );
			str_modbus->FlagBITF |= (1 << MB_FC_EXECUTE_REQ_BIT);
			lc_is_MultiDriver_ctrl = 1;
			break;

		case MB_FC102:
		case MB_FC103:
			com_FC102_Processing ( (uint8_t*)data, MB_SLV_RTU, str_modbus );
			str_modbus->FlagBITF &= ~(1 << MB_FC_EXECUTE_REQ_BIT);
			lc_is_MultiDriver_ctrl = 1;
			break;
		
		// inValid function code
		default:
			break;
	}
	
	if ( lc_is_MultiDriver_ctrl == 1 ) {

			str_modbus->State = MB_SLV_SPECIAL_CAST;
#ifdef MULTI_DRIVE_LITE
	}else if( lc_is_MultiDriver_ctrl == 2 ){
		str_modbus->State = MB_SLV_MDL_CAST;
#endif
	} else {
		if ( str_modbus->ExceptionCode == 0 ) {
			// Set modbus slave state to normal reply.
			str_modbus->State = MB_SLV_UNICAST_PROCESSING;
			str_modbus->FlagBITF |= (1 << MB_FC_EXECUTE_REQ_BIT);
		} else {
			str_modbus->State = MB_SLV_ERROR_REPLY;
		}
	

		// BroadCast check. Response nothing regardless any situation in broadcast mode.
		if ( (str_modbus->FlagBITF & (1 << MB_BROAD_CAST_BIT)) != 0 ) {
			str_modbus->State = MB_SLV_BROADCAST_PROCESSING;
		}
	}

}


/*===========================================================================================
    Function Name    : mb_unicast_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : 
//==========================================================================================*/
void mb_unicast_RTU ( uint8_t *ReceiveFlag,
				  uint8_t *data,
				  uint32_t data_num,
				  uint8_t *T_data,
				  uint8_t *T_data_Length,
				  uint8_t *T_send_flag,
				  uint8_t *T_data_ptr, 
				  Struct_Modbus_Slave *str_modbus
)
{

	#if (PROTOCOL_MODE == 1)
		
	#else
		if ( (str_modbus->req_pdu_function_code == MB_FC6) || (str_modbus->req_pdu_function_code == MB_FC10) ) {
			str_modbus->FlagBITF |= (1 << MB_REG_UPDATE_REQ_BIT);
		}
		str_modbus->FlagBITF &= ~(1 << MB_FC_EXECUTE_REQ_BIT);
	#endif
	
	// Update holding register if required. (FC6, FC16)
	if ( (str_modbus->FlagBITF & (1 << MB_REG_UPDATE_REQ_BIT)) != 0 ) {
		mb_write_holdingRegister( str_modbus->req_pdu_address_h, str_modbus->req_pdu_address_l, str_modbus->req_pdu_data_quantity, str_modbus );
		str_modbus->FlagBITF &= ~(1 << MB_REG_UPDATE_REQ_BIT);
	}
	
	if ( (str_modbus->FlagBITF & (1 << MB_FC_EXECUTE_REQ_BIT)) == 0 ) {
		if ( str_modbus->ExceptionCode == 0 ) {
			str_modbus->State = MB_SLV_NORMAL_REPLY;
		} else {
			str_modbus->State = MB_SLV_ERROR_REPLY;
		}
	}
	
}


/*===========================================================================================
    Function Name    : mb_broadcast_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : 
//==========================================================================================*/
void mb_broadcast_RTU ( uint8_t *ReceiveFlag,
					uint8_t *data,
				    uint32_t data_num,
				    uint8_t *T_data,
				    uint8_t *T_data_Length,
				    uint8_t *T_send_flag,
				    uint8_t *T_data_ptr,
					Struct_Modbus_Slave *str_modbus
)
{
	#if (PROTOCOL_MODE == 1)
		com_Error_routine( str_modbus->ExceptionCode );
	#else
		if ( (str_modbus->req_pdu_function_code == MB_FC6) || (str_modbus->req_pdu_function_code == MB_FC10) ) {
			str_modbus->FlagBITF |= (1 << MB_REG_UPDATE_REQ_BIT);
		}
		str_modbus->FlagBITF &= ~(1 << MB_FC_EXECUTE_REQ_BIT);
	#endif
	
	// Update holding register if required. (FC6, FC16)
	if ( (str_modbus->FlagBITF & (1 << MB_REG_UPDATE_REQ_BIT)) != 0 ) {
		mb_write_holdingRegister( str_modbus->req_pdu_address_h, str_modbus->req_pdu_address_l, str_modbus->req_pdu_data_quantity, str_modbus );
		str_modbus->FlagBITF &= ~(1 << MB_REG_UPDATE_REQ_BIT);
	}

	if ( (str_modbus->FlagBITF & (1 << MB_FC_EXECUTE_REQ_BIT)) == 0 ) {
		*ReceiveFlag 		= UART_READY;			// enable Uart recieve
		str_modbus->State 	= MB_SLV_IDLE;          // Set modbus state back into idle.
	}
}


/*===========================================================================================
    Function Name    : mb_normal_reply_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Response the normal message and set back to idle state.
//==========================================================================================*/
void mb_normal_reply_RTU ( uint8_t *ReceiveFlag,
					   uint8_t *data,
				       uint32_t data_num,
				       uint8_t *T_data,
				       uint8_t *T_data_Length,
				       uint8_t *T_send_flag,
				       uint8_t *T_data_ptr,
					   Struct_Modbus_Slave *str_modbus
)
{

	mb_normal_response_RTU( str_modbus->req_pdu_slaveID,
						str_modbus->req_pdu_function_code,
						str_modbus->Response_data_number,
						(unsigned char*)( &str_modbus->Response_data),
						(uint8_t*)T_data,
						(uint8_t*)T_data_Length,
						(uint8_t*)T_send_flag,
						(uint8_t*)T_data_ptr);

	/*
	if( str_modbus->SecondEcho_State == SECOND_ECHO_STATE_IDLE ){
        *ReceiveFlag        = UART_READY;               // enable Uart recieve
        str_modbus->State   = MB_SLV_IDLE;
    }else{
        //str_modbus->SecondEcho_TP1 = CURRENT_TIMER_CNT;
        str_modbus->SecondEcho_StartFlag = YES;
        str_modbus->State   = MB_SLV_SECONDECHO;
    }*/

	*ReceiveFlag        = UART_READY;               // enable Uart recieve
    str_modbus->State   = MB_SLV_IDLE;

}

/*===========================================================================================
    Function Name    : mb_SecondEcho_reply_RTU
    Input            :
                       1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
                           1 = BUSY.
                           2 = DONE.
                       2. *data     : The data array from the Uart receive buffer.
                       3. data_num  : The received data number from the Uart buffer.
                       4. *T_data   : The Uart transmit buffer to put data to send.
                       5. *T_data_Length: The Uart transmit data length to send.
                       6. *T_send_flag  : The Uart transmit require flag.
                       7. *T_data_ptr   : The Uart transmit data pointer.
                       8. Struct_Modbus_Slave *str_modbus   : The struct of RS232 or RS485
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
#if(0)
void mb_SecondEcho_reply_RTU ( uint8_t *ReceiveFlag,
                       uint8_t *data,
                       uint32_t data_num,
                       uint8_t *T_data,
                       uint8_t *T_data_Length,
                       uint8_t *T_send_flag,
                       uint8_t *T_data_ptr,
                       Struct_Modbus_Slave *str_modbus
                    )
{
    uint32_t i = 0;
    int32_t *RegisterPtr;
    uint32_t data_cnt = 0;
    uint8_t lc_echo_driver = 1 - str_modbus->Echo_Driver;
    if( lc_echo_driver >= MULTI_DRIVE_DRIVE_INDEX_NUM ){
        lc_echo_driver = MULTI_DRIVE_DRIVE_INDEX_M0;
    }

    if( *T_send_flag == NO ){
        if( str_modbus->SecondEcho_StartFlag == YES ){
            str_modbus->SecondEcho_TP1 = CURRENT_TIMER_CNT;
            str_modbus->SecondEcho_StartFlag = NO;
        }
        str_modbus->SecondEcho_TP2 = CURRENT_TIMER_CNT;

        //if( str_modbus->SecondEcho_TP1 - str_modbus->SecondEcho_TP2 > MODBUS_FRAME_GAP_LIMIT ){
        if( str_modbus->SecondEcho_TP1 - str_modbus->SecondEcho_TP2 > CG_UART485.rtu_time_frame_length ){

            if( str_modbus->SecondEcho_State == SECOND_ECHO_STATE_MULTI_DRIVE ){

                // Set data quantity
                str_modbus->req_pdu_data_quantity = MB_FC_MUL_CMD_RESP_DATA_NUM;

                // Get Data
                RegisterPtr = ( int32_t* )&str_modbus->MD_STAMP_DATA[ lc_echo_driver ][ STAMP_CPOS_h ];

                for (i=0; i<str_modbus->req_pdu_data_quantity; i++) {
                    str_modbus->Response_data[ i * 2     ] = ( RegisterPtr[ i ] >> 8  ) & 0xff;
                    str_modbus->Response_data[ i * 2 + 1 ] = ( RegisterPtr[ i ] >> 0  ) & 0xff;
                }

                str_modbus->Response_data_number = MB_FC_MUL_CMD_RESP_DATA_NUM*2;   // Address 2, Quantity of reg 2

                str_modbus->req_pdu_slaveID = str_modbus->SubID[ str_modbus->SubID_Seq[ lc_echo_driver ] ];

                if( str_modbus->MultiCMD_Fail[ lc_echo_driver ] == YES ){
                    str_modbus->req_pdu_function_code = MB_FC103;   // multi-driver error reply
                }else{
                    str_modbus->req_pdu_function_code = MB_FC102;   // multi-driver normal reply
                }

            }else{

                // Set data quantity

                str_modbus->Response_data[ data_cnt++ ] = ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] >> 8 ) & 0xFF;
                str_modbus->Response_data[ data_cnt++ ] = ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] >> 0 ) & 0xFF;

                // Get Data
                RegisterPtr = ( int32_t* )&str_modbus->MDL_ECHO_DATA[ lc_echo_driver ][0];

                for ( i = 0; i < ECHO_BITF_NUM; i++ ) {
                    if( ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] & ( 1UL << i ) ) != 0 ){
                        str_modbus->Response_data[ data_cnt++ ] = ( RegisterPtr[ i ] >> 8  ) & 0xff;
                        str_modbus->Response_data[ data_cnt++ ] = ( RegisterPtr[ i ] >> 0  ) & 0xff;
                    }

                }

                str_modbus->Response_data_number = data_cnt;
                str_modbus->req_pdu_data_quantity = str_modbus->Response_data_number / 2;

                str_modbus->req_pdu_slaveID = str_modbus->SubID[ str_modbus->SubID_Seq[ lc_echo_driver ] ];

            }

            mb_normal_response_RTU( str_modbus->req_pdu_slaveID,
                                str_modbus->req_pdu_function_code,
                                str_modbus->Response_data_number,
                                (unsigned char*)( &str_modbus->Response_data),
                                (uint8_t*)T_data,
                                (uint8_t*)T_data_Length,
                                (uint8_t*)T_send_flag,
                                (uint8_t*)T_data_ptr);

            str_modbus->SecondEcho_State = SECOND_ECHO_STATE_IDLE;
            *ReceiveFlag        = UART_READY;               // enable Uart recieve
            str_modbus->State   = MB_SLV_IDLE;

        }

    }
}
#endif

/*===========================================================================================
    Function Name    : mb_error_reply_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Response the error message and set back to idle state.
//==========================================================================================*/
void mb_error_reply_RTU ( uint8_t *ReceiveFlag,
					  uint8_t *data,
				      uint32_t data_num,
				      uint8_t *T_data,
				      uint8_t *T_data_Length,
				      uint8_t *T_send_flag,
				      uint8_t *T_data_ptr,
					  Struct_Modbus_Slave *str_modbus
)
{
	
	mb_Error_response_RTU ( str_modbus->req_pdu_slaveID,
						str_modbus->req_pdu_function_code,
					    str_modbus->ExceptionCode,
						str_modbus->ExceptionMode,
						(uint8_t*)T_data,
						(uint8_t*)T_data_Length,
						(uint8_t*)T_send_flag,
						(uint8_t*)T_data_ptr);
	
	#if (PROTOCOL_MODE==1)
		com_Error_routine ( str_modbus->ExceptionCode );
    #endif

	*ReceiveFlag		= UART_READY;				// enable Uart recieve
	str_modbus->State	= MB_SLV_IDLE;

}



/*===========================================================================================
    Function Name    : mb_ADU_frame_check_is_ok_RTU
    Input            : 
					   1. *data: The data from the Modbus buffer. (Uart received data)
					   2. data_num: The received data number from the Uart buffer.
					   3. slaveID : The slave id from the received buffer. ( starting address )
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : return_value: 0 = frame_check failed.
									 1 = frame_check_passed.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the frame and slaveID of the received data from Uart buffer.
//==========================================================================================*/
uint8_t mb_ADU_frame_check_is_ok_RTU ( uint8_t *data, uint32_t data_num, uint8_t slaveID, Struct_Modbus_Slave *str_modbus  )
{
	uint8_t check_state  = 0;
	uint8_t return_value = NO;
	
	// Frame Check
	check_state = mb_Frame_Check_RTU( (uint8_t*)data, data_num, str_modbus );		// return 1 if passed.
	
	str_modbus->is_frame_ok = check_state;

	if ( check_state == 0 ) {
		str_modbus->FlagBITF |= _BIT( MB_FRAME_COM_ALARM_BIT );
	} else {
		str_modbus->FlagBITF &= ~_BIT( MB_FRAME_COM_ALARM_BIT );
		
		// Reset timeout
		str_modbus->time_out_cnt 	= 0;		// 2014 0313 Eric
		str_modbus->time_out_flag 	= NO;		// 2014 0313 Eric
	}
	
	// SlaveID ( Starting Address ) Check ( including broadcast check )
	str_modbus->FlagBITF &= ~(1 << MB_BROAD_CAST_BIT);						// Reset broadcast flag.
	
	if ( slaveID == BROAD_CAST_ADDRESS ) {              					// set broadcast bit if broadcast requested.
		str_modbus->FlagBITF |= (1 << MB_BROAD_CAST_BIT);
	} else if ( str_modbus->DeviceID != slaveID ) {						// check slave ID if not broadcasting.
		check_state = 0;
	}
		
	// Frame and slaveID result Check
	if ( check_state == 0 ) {
		// Frame Error
		// Original Modbus response nothing. Due to BUS type communication.	
		str_modbus->FlagBITF &= ~(1 << MB_REQ_PDU_RECEIVED_BIT);

	} else {
		// Frame Check ok, pdu handle request.
		str_modbus->FlagBITF |= (1 << MB_REQ_PDU_RECEIVED_BIT);
		return_value			  = YES;
	}
	
	return ( return_value );
}


/*===========================================================================================
    Function Name    : mb_PDU_Address_check_is_ok_RTU
    Input            : 
					   1. add_h : The data address high byte.
					   2. add_L : The data address low byte.
					   3. quantity : the quantity of the data received.
    Return           : return_value: 0 = address check failed.
									 1 = address check passed.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the address of PDU in modbus slave RTU.
					   Note: This function only support FC3, FC6 and FC16.
//==========================================================================================*/
uint8_t mb_PDU_Address_check_is_ok_RTU ( uint8_t add_h, uint8_t add_L, int32_t quantity )
{
	int32_t address_range = 0;
	uint8_t return_value   = YES;

	address_range = add_h*256 + add_L + quantity;
	
	// Address out of range.
	if ( address_range > ACCESSIBLE_HOLDING_ADDRESS) {
		return_value = NO;
	}
	
	return ( return_value );
}


/*===========================================================================================
    Function Name    : mb_PDU_Data_check_is_ok_RTU
    Input            : 
					   1. quantity : The quantity of the data received.
					   2. data_num : The received data number from the Uart buffer.
					   3. FC	   : The function code.
					   4. bytecount: The received byte count.
    Return           : return_value: 0 = data check failed.
									 1 = data check passed.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the data of PDU in modbus slave RTU.
					   Note: This function only support FC3, FC6 and FC16.
//==========================================================================================*/
uint8_t mb_PDU_Data_check_is_ok_RTU ( int32_t quantity, uint32_t data_num, uint8_t FC, int32_t bytecount )
{
	uint32_t data_cnt 		= 0;		// Recieved data quantity.
	uint32_t data_num_check = 0;		// data quantity calculated.
	uint8_t return_value   	= YES;
		
	return_value = mb_Function_FC16_Data_check_is_ok_RTU( quantity, FC, bytecount );
	
	// data number out of range.
	if ( (quantity > MAX_REG_QUANTITY) || 
		 (quantity == 0)
	) {
		return_value = NO;
	}
	
	data_cnt = data_num - 4;	// ID*1 + FC*1 + CRC*2 = 4 bytes
	
	if ( FC == 0x10 ) {
		data_num_check = 4 + 1 + quantity*2;	// Address 2, quantity 2, byteCnt 1, value 2*n
	} else {
		data_num_check = 4;						// Address 2, Data 2
	}
	
	if ( data_cnt != data_num_check ) {
		return_value = NO;	
	}	
	
	return ( return_value );
}

/*===========================================================================================
    Function Name    : mb_Function_FC16_Data_check_is_ok_RTU
    Input            : 
					   1. quantity : The quantity of the data received.
					   2. FC	   : The function code.
					   3. bytecount: The received byte count .
    Return           : return_value: 0 = data check failed.
									 1 = data check passed.
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : Check the data of ( Byte Count == Quantity of Registers x 2 )
					   Note: This function only support FC16.
//==========================================================================================*/
uint8_t mb_Function_FC16_Data_check_is_ok_RTU ( int32_t quantity,uint8_t FC, int32_t bytecount )
{
	uint8_t return_value   	= YES;
		
	if ( FC == 0x10 ){
		if( ( quantity * 2 ) != bytecount  ){
			return_value = NO;
		}
	}
	
	return ( return_value );
}

/*===========================================================================================
    Function Name    : mb_Frame_Check_RTU
    Input            : 
					   1. *data : Recieved data array to check.
					   2. data_num : data number to be check.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
					   
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the frame of recieved data of modbus (LCR) and return Good or Bad.
//==========================================================================================*/
unsigned char mb_Frame_Check_RTU( unsigned char *data, unsigned char data_num, Struct_Modbus_Slave *str_modbus  )
{
	unsigned int data_num2 = 0;

	data_num2 = data_num - 2;
	
	str_modbus->CRC = crcGenrator(data , data_num2 );
	str_modbus->D_CRC = ( ( ( data[ data_num - 2 ] << 8 ) & 0xFF00 ) |  ( data[ data_num - 1 ] & 0x00FF ) );

	if( str_modbus->CRC != str_modbus->D_CRC ) // Check LRC
        return 0;
    else
        return 1;
}

/*===========================================================================================
    Function Name    : mb_FC_Check_is_Ok_RTU
    Input            : 
					   1. FC : Recieved function code to be check.					   
					   2. address_h : The data address high byte.
					   3. address_l : The data address low byte.
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the if the function code is supported by the device. Return the result.
	LastUpData		 : 2014 0219
//==========================================================================================*/
unsigned char mb_FC_Check_is_Ok_RTU ( unsigned char FC, int32_t address_h, int32_t address_l )
{
	unsigned char return_value = NO;
	// Function Code check
	switch( FC ){
		// Read
		case 3:
			return_value = YES;
			break;
			
		// Write single
		case 6:
			return_value = YES;
			break;
			
		// Write multiple
		case 16:
			return_value = YES;
			break;

		// Diagnostics
		case 8:
//			return_value = mb_Function_FC8_ViceFunction_is_req_RTU( address_h, address_l );
			return_value = NO;		// 2014 1015 Eric
			break;
		
		// inValid function code
		default:
			return_value = NO;
			break;
	}
	return (return_value);
}


/*===========================================================================================
    Function Name    : MB_Function_FC3_RTU
    Input            : 
					   1.Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : FC3 command function to excute.
					   Send requested holding register value to Uart Tx buffer.
//==========================================================================================*/
void mB_Function_FC3_RTU ( Struct_Modbus_Slave *str_modbus )
{
	int i = 0;
	int32_t *RegisterPtr;

	// Insert byte count
	str_modbus->Response_data[0] = str_modbus->req_pdu_data_quantity*2;
	
	RegisterPtr = (str_modbus->HoldingRegister_ptr[str_modbus->req_pdu_address_h] + str_modbus->req_pdu_address_l);

	//! Insert Data of Holding register

	for ( i = 0; i<str_modbus->req_pdu_data_quantity; i++ ) {
		str_modbus->Response_data[1+i*2] = ( RegisterPtr[ i ] >> 8  ) & 0xff ;
		str_modbus->Response_data[2+i*2] = ( RegisterPtr[ i ] >> 0  ) & 0xff ;
	}

	
	// Reponse data number
	str_modbus->Response_data_number = str_modbus->req_pdu_data_quantity*2+1;
	str_modbus->ExceptionCode 		 = 0;	

}


/*===========================================================================================
    Function Name    : mB_Function_FC6
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : FC6 command function to excute.
					   Calculate the data to write and prepare the response data.
//==========================================================================================*/
void mB_Function_FC6_RTU ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus )
{

	int i = 0;
	str_modbus->req_pdu_data[0] = ( ( ( data[ 4 ] << 8 ) & 0xFF00 ) | ( data[ 5 ] & 0x00FF ) );


	//! Return last received data for FC6 return
	str_modbus->Response_data_number = data_num - 4;	// ID + FC + CRC*2 = 4 bytes
	// response data value = last received data for test
	for (i=0; i < str_modbus->Response_data_number; i ++ ) {
		str_modbus->Response_data[i] = data[i+2];
	}
	// ExceptionCode setup
	str_modbus->ExceptionCode = 0;	// 0 = no error
		
}


/*===========================================================================================
    Function Name    : mB_Function_FC16_RTU
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.				
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : FC16 command function to excute.
					   Calculate the data to write and prepare the response data.
//==========================================================================================*/
void mB_Function_FC16_RTU ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus )
{
    int i = 0;
	
	// Get Data
	for (i=0; i<str_modbus->req_pdu_data_quantity; i++) {
		str_modbus->req_pdu_data[i] = ( ( ( data[ i*2+7 ] << 8 ) & 0xFF00 ) | ( data[ i*2+8 ] & 0x00FF ) );
	}
	
	str_modbus->Response_data_number = 4;	// Address 2, Quantity of reg 2
    
	for (i=0; i < str_modbus->Response_data_number; i ++ ) {
		str_modbus->Response_data[i] = data[i+2];
	}
	
	// ExceptionCode setup
	str_modbus->ExceptionCode = 0;	// 0 = no error

}

/*===========================================================================================
    Function Name    : mB_Function_FC8_RTU
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : FC8 command function to excute.
					   Calculate the data to write and prepare the response data.
	LastUpData		 : 2014 0219
//==========================================================================================*/
void mB_Function_FC8_RTU ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus )
{

	int i = 0;
	str_modbus->req_pdu_data[0] = ( ( ( data[ 4 ] << 8 ) & 0xFF00 ) | ( data[ 5 ] & 0x00FF ) );
			
	//! Return last received data for FC8 return
	str_modbus->Response_data_number = data_num - 4;	// ID + FC + CRC*2 = 4 bytes
	// response data value = last received data for test
	for (i=0; i < str_modbus->Response_data_number; i ++ ) {
		str_modbus->Response_data[i] = data[i+2];
	}
	// ExceptionCode setup
	str_modbus->ExceptionCode = 0;	// 0 = no error
		
}

/*===========================================================================================
    Function Name    : crcGenrator
    Input            : 
					   1. *data: data array to be sent.
					   2. length: data array number.
    Return           : outCRC 	: CRC 
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : 
						
//==========================================================================================*/
unsigned int crcGenrator(unsigned char* data ,int length )
{
    unsigned int reg_crc=0xFFFF; //CRC
	unsigned int crcdata = 0;
	unsigned int outCRC;
	int i;
	int j;

	for(j=0;j<length;j++)		
    {
		crcdata = *data++;

        reg_crc ^= crcdata;

        for(i=0;i<8;i++)
        {
            if(reg_crc & 0x01)
                reg_crc=(reg_crc>>1) ^ 0xA001;
            else
                reg_crc=reg_crc >>1;
        }
    }

    outCRC=((reg_crc<<8)&0xFF00)|((reg_crc>>8)&0x00FF);

    return outCRC;
}

/*===========================================================================================
    Function Name    : mb_normal_response_RTU
    Input            : 
					   1. slaveID : slave ID of the device
					   2. FC : Function Code of the command
					   3. data_num : Requested data number      
			           4. *data : data array to be sent
					   5. *str_Uart : UART golobal data struct to be modified.
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : This function returns Modbus in ModBus_Slave_Response().
//==========================================================================================*/
void mb_normal_response_RTU ( unsigned char slaveID, unsigned char FC,
						  unsigned char data_num, unsigned char *data,
						  unsigned char *T_data, unsigned char *T_data_length,
						  unsigned char *send_data_flag, unsigned char *T_data_Ptr )
{	
	int i = 0;
	int sendpointer = 0;
	unsigned int CRC = 0;	
	
	// =>Slave ID
	T_data[sendpointer++] = slaveID;
	
	// =>Function code   		
	T_data[sendpointer++] = FC;              
	
	// =>Adress and Data	
	for (i=0; i < data_num; i++) {
		T_data[sendpointer+i] = data[i];
	}
	
	// => CRC
	sendpointer = sendpointer + data_num;
	CRC = crcGenrator(T_data , sendpointer );
	
	T_data[sendpointer++] = (CRC/256);
	//T_data[sendpointer++] = (CRC%256);
	T_data[sendpointer++] = MOD( CRC, 256 );	

    *T_data_length = sendpointer;
    *send_data_flag = 1;
    *T_data_Ptr = 0;	

}


/*===========================================================================================
    Function Name    : mb_Error_response_RTU
    Input            : 
					   1. slaveID : slave ID of the device
					   2. error_code : the requested function code
					   3. exception_code : 01 = ILLEGAL FUNCTION      
			                               02 = ILLEGAL DATA ADDRESS
						                   03 = ILLEGAL DATA VALUE
			                               04 = SLAVE DEVICE FAILURE
			           4. exception_mode : 00 = original setting ( have bug ), 01 = normal mode
					   5. *str_Uart : UART golobal data struct to be modified.
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : This function returns Modbus error code.
//==========================================================================================*/
void mb_Error_response_RTU ( 	unsigned char slaveID,
								unsigned char error_code,
								unsigned char exception_code,
								unsigned char exception_mode,
								unsigned char *T_data,
								unsigned char *T_data_length,
								unsigned char *send_data_flag,
								unsigned char *T_data_Ptr )
{

	unsigned int CRC = 0;

	T_data[0] = slaveID;	            

	error_code = error_code + 0x80;					// Convert function code into errorcode
	T_data[1] = error_code;              
    
	if( exception_mode == EXCEPTION_MODE_ORIGINAL ){
		T_data[2] = exception_code / 256 ;
		//T_data[3] = exception_code % 256 ;
		T_data[3] = MOD( exception_code, 256 );

		CRC = crcGenrator(T_data , 4 );

		T_data[4]  = CRC / 256; // =>CRC
		//T_data[5]  = CRC % 256; //
		T_data[5]  = MOD( CRC, 256 ); //

		*T_data_length = 6;

	}else{
		T_data[2] = exception_code;
		CRC = crcGenrator(T_data , 3 );
		T_data[3]  = CRC / 256;
		T_data[4]  = MOD( CRC, 256 ); //

		*T_data_length = 5;
		
	}

	*send_data_flag = 1;
	*T_data_Ptr = 0;

}

/*===========================================================================================
    Function Name    : mbRTU_General_FC_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check.
					   Check frame and SlaveID.
					   Set to processing if all check passed.
					   Set to idle if frame check failed.
					   Set to error response if one of the function code, address or data check failed.
					   Set to broadcast ending if function code check failed in broadcast mode.
//==========================================================================================*/
uint8_t mbRTU_General_FC_Check ( 	uint8_t *ReceiveFlag,
									uint8_t *data,
									uint32_t data_num,
									Struct_Modbus_Slave *str_modbus
						)
{
	uint8_t is_frame_ok = NO;

	// Frame check
	if ( mb_ADU_frame_check_is_ok_RTU( (uint8_t*)data, data_num, str_modbus->req_pdu_slaveID, str_modbus ) == YES ) {

		str_modbus->req_pdu_address_h = data[ 2 ] ;
		str_modbus->req_pdu_address_l = data[ 3 ] ;

		// FC check
		if ( mb_FC_Check_is_Ok_RTU( str_modbus->req_pdu_function_code, str_modbus->req_pdu_address_h, str_modbus->req_pdu_address_l ) == YES ) {
			// Get Data address and quantity if frame check and FC check passed.

			if ( str_modbus->req_pdu_function_code == 0x06 ) {
				str_modbus->req_pdu_data_quantity = 1;		// Quantity set to 1 if write single.
			}else if ( str_modbus->req_pdu_function_code == 0x08 ){
				str_modbus->req_pdu_data_quantity = 1;		// Quantity set to 1
			}else if ( str_modbus->req_pdu_function_code == 0x10 ){
				str_modbus->req_pdu_data_quantity = ( ( ( data[ 4 ] << 8 ) & 0xFF00 ) |  ( data[ 5 ] & 0x00FF ) );
				str_modbus->req_pdu_act_byteCnt	  = data[ 6 ];
			}else {
				str_modbus->req_pdu_data_quantity = ( ( ( data[ 4 ] << 8 ) & 0xFF00 ) |  ( data[ 5 ] & 0x00FF ) );
			}

			// Address Check
			if ( mb_PDU_Address_check_is_ok_RTU(  str_modbus->req_pdu_address_h,
											  str_modbus->req_pdu_address_l,
											  str_modbus->req_pdu_data_quantity ) == YES ) {

				// Data check
				if ( mb_PDU_Data_check_is_ok_RTU( str_modbus->req_pdu_data_quantity,
											  data_num,
											  str_modbus->req_pdu_function_code,
											  str_modbus->req_pdu_act_byteCnt ) == YES ) {

					// Set modbus slave state to processing if all pre check passed.
					str_modbus->State = MB_SLV_REQ_PROCESSING;

				} else {
					str_modbus->ExceptionCode = ILLEGAL_DATA_VALUE;
				}

			} else {
				str_modbus->ExceptionCode = ILLEGAL_DATA_ADDRESS;
			}

		} else {
			// Function not supported
			str_modbus->ExceptionCode = ILLEGAL_FUNCTION;
		}


		if ( str_modbus->ExceptionCode != 0 ) {
			// Set modbus slave state to error reply.
			str_modbus->State = MB_SLV_ERROR_REPLY;

			// BroadCast check. Response nothing regardless any situation in broadcast mode.
			if ( (str_modbus->FlagBITF & (1 << MB_BROAD_CAST_BIT)) != 0 ) {
				*ReceiveFlag 			= UART_READY;				// enable Uart recieve
				str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.
			}

		}

		is_frame_ok = YES;

	} else {

		*ReceiveFlag 		= UART_READY;				// enable Uart recieve
		str_modbus->State 	= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

	}

	return (is_frame_ok);

}

/*===========================================================================================
    Function Name    : mbRTU_FC101_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC101_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						)
{
	uint8_t is_frame_ok = NO;		// Flag to indicate if frame check passed or not. All error in this check will be treat as frame error. 1=ok, 1=bad.
	uint8_t is_msg_ok	= 1;		// Flag to indacate if message is ok. 0 = bad, 1 = ok

	// Frame check
	is_frame_ok = mb_Frame_Check_RTU( (uint8_t*)data, data_num, str_modbus );

	str_modbus->is_frame_ok = is_frame_ok;

	// Major ID check
	if ( str_modbus->req_pdu_slaveID == BROAD_CAST_ADDRESS ) {
		str_modbus->FlagBITF |= (1 << MB_BROAD_CAST_BIT);
	} else {
		is_msg_ok = 0;
	}

	// Check SubID, Command and echo
	if ( (is_frame_ok == YES) && (is_msg_ok == 1) ) {
		is_msg_ok &= com_FC101_Check_RTU ( (uint8_t*)data, data_num, str_modbus );

		// Reset timeout
		str_modbus->time_out_cnt 	= 0;
		str_modbus->time_out_flag 	= NO;

	} else {
		is_msg_ok = 0;
	}


	if ( is_msg_ok == 0 ) {
		// msg bad, back to modbus idle state
		*ReceiveFlag 			= UART_READY;				// enable Uart recieve
		str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

	} else {
		str_modbus->State = MB_SLV_REQ_PROCESSING;
	}

	return ( is_frame_ok );
}

/*===========================================================================================
    Function Name    : mbRTU_FC102_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC102_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						)
{
	uint8_t is_frame_ok = NO;		// Flag to indicate if frame check passed or not. All error in this check will be treat as frame error. 1=ok, 1=bad.
	uint8_t is_msg_ok	= 1;		// Flag to indacate if message is ok. 0 = bad, 1 = ok

	// Frame check
	is_frame_ok = mb_Frame_Check_RTU( (uint8_t*)data, data_num, str_modbus );

	str_modbus->is_frame_ok = is_frame_ok;


#if(0)
	// Major ID check
	if ( str_modbus->req_pdu_slaveID == BROAD_CAST_ADDRESS ) {
		str_modbus->FlagBITF |= (1 << MB_BROAD_CAST_BIT);
	} else {
		is_msg_ok = 0;
	}
#endif

	// Check SubID, Command and echo
	if ( (is_frame_ok == YES) && (is_msg_ok == 1) ) {
		is_msg_ok &= com_FC102_Check ( (uint8_t*)data, str_modbus );

		// Reset timeout
		str_modbus->time_out_cnt 	= 0;
		str_modbus->time_out_flag 	= NO;

	} else {
		is_msg_ok = 0;
	}


	if ( is_msg_ok == 0 ) {
		// msg bad, back to modbus idle state
		*ReceiveFlag 			= UART_READY;				// enable Uart recieve
		str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

	} else {
		str_modbus->State = MB_SLV_REQ_PROCESSING;
	}

	return ( is_frame_ok );
}

/*===========================================================================================
    Function Name    : mbRTU_SpecialCasting
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Multi-driver ctrl function casting. Repare response data.
//==========================================================================================*/
void mbRTU_SpecialCasting (	 uint8_t *ReceiveFlag,
							 uint8_t *data,
							 uint32_t data_num,
							 uint8_t *T_data,
							 uint8_t *T_data_Length,
							 uint8_t *T_send_flag,
							 uint8_t *T_data_ptr,
							 Struct_Modbus_Slave *str_modbus
						 )
{
	uint32_t i = 0;
	int32_t *RegisterPtr;
	uint8_t lc_echo_driver = str_modbus->Echo_Driver;
	//uint8_t another_driver;
	//uint8_t lc_echo_Seq = com_Export_Echo_Seq( CG_ComProtocol_01.Echo_Driver );
	uint8_t lc_received_FC = str_modbus->MultiCMD_FC_R;


	if( lc_echo_driver >= MULTI_DRIVE_DRIVE_INDEX_NUM ){
        lc_echo_driver = MULTI_DRIVE_DRIVE_INDEX_M0;
    }

	if ( (str_modbus->FlagBITF & (1 << MB_FC_EXECUTE_REQ_BIT)) == 0 ) {


	    if( ( lc_received_FC == MB_FC101 && str_modbus->Echo_Driver < MULTI_DRIVE_DRIVE_INDEX_NUM ) ||
            ( (lc_received_FC == MB_FC102) || (lc_received_FC == MB_FC103) )   ){

            // Set data quantity
            str_modbus->req_pdu_data_quantity = MB_FC_MUL_CMD_RESP_DATA_NUM;

            // Get Data
            RegisterPtr = ( int32_t* )&str_modbus->MD_STAMP_DATA[ lc_echo_driver ][ STAMP_CPOS_h ];

            for (i=0; i<str_modbus->req_pdu_data_quantity; i++) {
                str_modbus->Response_data[ i * 2     ] = ( RegisterPtr[ i ] >> 8  ) & 0xff;
                str_modbus->Response_data[ i * 2 + 1 ] = ( RegisterPtr[ i ] >> 0  ) & 0xff;
            }

            str_modbus->Response_data_number = MB_FC_MUL_CMD_RESP_DATA_NUM*2;   // Address 2, Quantity of reg 2

            str_modbus->req_pdu_slaveID = str_modbus->SubID[ str_modbus->SubID_Seq[ lc_echo_driver ] ];

            str_modbus->State = MB_SLV_NORMAL_REPLY;

            // current driver = lc_echo_driver  ( M0 or M1 )
            // another driver = 1 - current driver ( M1 or M0 )
            // If echo_seq[ another driver ] == echo_seq[ current driver ] + 1
            // Means it needs second echo
            /*
            another_driver = 1 - lc_echo_driver;
            if( str_modbus->Echo_Seq[ another_driver ] == str_modbus->Echo_Seq[ lc_echo_driver ] + 1 ){
                str_modbus->SecondEcho_State = SECOND_ECHO_STATE_MULTI_DRIVE;
            }*/
            //

        }else{
            *ReceiveFlag        = UART_READY;               // enable Uart recieve
            str_modbus->State   = MB_SLV_IDLE;
        }

	}
}

/************************** <END OF FILE> *****************************************/
