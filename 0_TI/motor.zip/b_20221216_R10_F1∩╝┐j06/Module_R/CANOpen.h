/*
 * CANOpen.h
 *
 *  Created on: 2020/11/30
 *      Author: chaim.chen
 */

#ifndef CAN_OPEN_H_
#define CAN_OPEN_H_

/*  Trunmman Technology Corporation. All rights reserved. */

//#include "IncludeFiles.h"
#include "CANOpen_TypeDef.h"

#define OD_INDEX_PARAMETER              0x30UL

#define OD_INIT_DATA_LENGTH_LIMIT       4
#define OD_SEGMENT_DATA_LENGTH_LIMIT    7

//#define CANOPEN_DISABLE_SUPPORT_RTR     1   // 1 = Disable, 0 = Enable ( Currently, This value must set to 1 )


/*===========================================================================================
    Function Name    : coSetupInitial
    Input            : 1.can
                       2.node_id
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coSetupInitial( Struct_CANOpen *co, uint32_t node_id );

/*===========================================================================================
    Function Name    : co_Call_1ms
    Input            : co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_Call_1ms( Struct_CANOpen *co );

/*===========================================================================================
    Function Name    : co_GetObject
    Input            : 1.co
                       2.index
                       3.sub_index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_GetObject( Struct_CANOpen *co, uint16_t index, uint8_t sub_index );

/*===========================================================================================
    Function Name    : co_Routine
    Input            : co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_Routine( Struct_CANOpen *co );




#endif /* C2000_CAN_H_ */


 /************************** <END OF FILE> *****************************************/



