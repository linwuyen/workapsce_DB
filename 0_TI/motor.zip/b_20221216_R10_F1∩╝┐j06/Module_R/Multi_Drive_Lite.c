/*
 * Multi_Drive_Lite.c
 *
 *  Created on: 2017/03/30
 *      Author: chaim.chen
 *     History:
 *
 */
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

volatile Struct_MDL									CG_MDL;
extern volatile Struct_GPIO 						CG_GPIO;
extern volatile Struct_ADC 							CG_ADC;
extern volatile Struct_Pretect 						CG_Protect;
//extern volatile Struct_Speed 						CG_Speed;
//extern volatile Struct_BLDC_CTRL 					CG_BLDC_CTRL;
extern volatile Struct_BLDC_CTRL                    CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL                    CG_BLDC_CTRL_M1;
extern volatile Struct_BLDC_Drive                   CG_BLDC_Drive_M0;
//extern volatile Struct_BLDC_Drive                   CG_BLDC_Drive_M1;
extern volatile Struct_IO							CG_IO;
extern volatile Struct_MD                           CG_MD;

#if(PROTOCOL_MODE==1)
extern volatile Struct_ComProtocol_01 CG_ComProtocol_01;
#endif

/*===========================================================================================
    Function Name    : variableInitial_MDL
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_MDL initial
//==========================================================================================*/
void variableInitial_MDL (void)
{
   CG_MDL.Enabled = NO;
}

/*===========================================================================================
    Function Name    : mdl_Enable
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mdl_Enable (void)
{
	CG_MDL.Enabled = YES;
}

/*===========================================================================================
    Function Name    : mdl_Disable
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mdl_Disable (void)
{
	CG_MDL.Enabled = NO;
}

/*===========================================================================================
    Function Name    : mbRTU_FC65_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC65_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						)
{
	uint8_t is_frame_ok = NO;		// Flag to indicate if frame check passed or not. All error in this check will be treat as frame error. 1=ok, 1=bad.
	uint8_t is_msg_ok	= 1;		// Flag to indacate if message is ok. 0 = bad, 1 = ok

	// Frame check
	is_frame_ok = mb_Frame_Check_RTU( (uint8_t*)data, data_num, str_modbus );

	str_modbus->is_frame_ok = is_frame_ok;

	// Major ID check
	if ( str_modbus->req_pdu_slaveID == BROAD_CAST_ADDRESS ) {
		str_modbus->FlagBITF |= (1 << MB_BROAD_CAST_BIT);
	} else {
		is_msg_ok = 0;
	}

	// Check SubID, Command and echo
	if ( (is_frame_ok == YES) && (is_msg_ok == 1) ) {
		is_msg_ok &= com_FC65_Check_RTU ( (uint8_t*)data, data_num, str_modbus );

		// Reset timeout
		str_modbus->time_out_cnt 	= 0;
		str_modbus->time_out_flag 	= NO;

	} else {
		is_msg_ok = 0;
	}


	if ( is_msg_ok == 0 ) {
		// msg bad, back to modbus idle state
		*ReceiveFlag 			= UART_READY;				// enable Uart recieve
		str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

	} else {
		str_modbus->State = MB_SLV_REQ_PROCESSING;
	}

	return ( is_frame_ok );
}

/*===========================================================================================
    Function Name    : mb_FC65_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mb_FC65_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						)
{
	uint8_t is_frame_ok = NO;		// Flag to indicate if frame check passed or not. All error in this check will be treat as frame error. 1=ok, 1=bad.
	uint8_t is_msg_ok	= 1;		// Flag to indacate if message is ok. 0 = bad, 1 = ok

	// Frame check
	is_frame_ok = mb_Frame_Check( (uint8_t*)data, data_num );

	str_modbus->is_frame_ok = is_frame_ok;

	// Major ID check
	if ( str_modbus->req_pdu_slaveID == BROAD_CAST_ADDRESS ) {
		str_modbus->FlagBITF |= (1 << MB_BROAD_CAST_BIT);
	} else {
		is_msg_ok = 0;
	}

	// Check SubID, Command and echo
	if ( (is_frame_ok == YES) && (is_msg_ok == 1) ) {
		is_msg_ok &= com_FC65_Check_ASCII ( (uint8_t*)data, data_num, str_modbus );

		// Reset timeout
		str_modbus->time_out_cnt 	= 0;
		str_modbus->time_out_flag 	= NO;

	} else {
		is_msg_ok = 0;
	}


	if ( is_msg_ok == 0 ) {
		// msg bad, back to modbus idle state
		*ReceiveFlag 			= UART_READY;				// enable Uart recieve
		str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

	} else {
		str_modbus->State = MB_SLV_REQ_PROCESSING;
	}

	return ( is_frame_ok );
}

/*===========================================================================================
    Function Name    : mbRTU_FC66_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC66_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						)
{
	uint8_t is_frame_ok = NO;		// Flag to indicate if frame check passed or not. All error in this check will be treat as frame error. 1=ok, 1=bad.
	uint8_t is_msg_ok	= 1;		// Flag to indacate if message is ok. 0 = bad, 1 = ok

	// Frame check
	is_frame_ok = mb_Frame_Check_RTU( (uint8_t*)data, data_num, str_modbus );

	str_modbus->is_frame_ok = is_frame_ok;


	// Check SubID, Command and echo
	if ( (is_frame_ok == YES) && (is_msg_ok == 1) ) {
		is_msg_ok &= com_FC66_Check ( (uint8_t*)data, str_modbus );

		// Reset timeout
		str_modbus->time_out_cnt 	= 0;
		str_modbus->time_out_flag 	= NO;

	} else {
		is_msg_ok = 0;
	}

	if ( is_msg_ok == 0 ) {
		// msg bad, back to modbus idle state
		*ReceiveFlag 			= UART_READY;				// enable Uart recieve
		str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

	} else {
		str_modbus->State = MB_SLV_REQ_PROCESSING;
	}

	return ( is_frame_ok );
}

/*===========================================================================================
    Function Name    : mb_FC66_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mb_FC66_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						)
{
	uint8_t is_frame_ok = NO;		// Flag to indicate if frame check passed or not. All error in this check will be treat as frame error. 1=ok, 1=bad.
	uint8_t is_msg_ok	= 1;		// Flag to indacate if message is ok. 0 = bad, 1 = ok

	// Frame check
	is_frame_ok = mb_Frame_Check( (uint8_t*)data, data_num );

	str_modbus->is_frame_ok = is_frame_ok;

	// Check SubID, Command and echo
	if ( (is_frame_ok == YES) && (is_msg_ok == 1) ) {
		is_msg_ok &= com_FC66_Check ( (uint8_t*)data, str_modbus );

		// Reset timeout
		str_modbus->time_out_cnt 	= 0;
		str_modbus->time_out_flag 	= NO;

	} else {
		is_msg_ok = 0;
	}


	if ( is_msg_ok == 0 ) {
		// msg bad, back to modbus idle state
		*ReceiveFlag 			= UART_READY;				// enable Uart recieve
		str_modbus->State 		= MB_SLV_IDLE;              // Set modbus state into idle if frame is wrong.

	} else {
		str_modbus->State = MB_SLV_REQ_PROCESSING;
	}

	return ( is_frame_ok );
}

/*===========================================================================================
    Function Name    : com_FC65_Check_RTU
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC65 check routine
//==========================================================================================*/
uint8_t com_FC65_Check_RTU ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus)
{
	uint8_t is_msg_ok = 1;			// Return value.
    uint8_t is_echo_m0      = 0;        // 0: no echo, 1: echo
    //uint8_t is_echo_m1     = 0;        // 0: no echo, 1: echo
	uint8_t i = 0;					// for loop counting index
	uint8_t k = 0;					// counting index
	uint32_t	echo;

	// Get Sub_ID quantity and check range
	str_modbus->SubID_Num =  data[ RTU_MDL_IDNUM ];
	if ( str_modbus->SubID_Num > SUB_ID_NUM ) {
		//str_modbus->ExceptionCode = ILLEGAL_DATA_ADDRESS;
		str_modbus->ExceptionCode = ILLEGAL_AGV_SUBID_NUM;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}else if( data_num != RTU_MDL_BASIC_LENGTH + str_modbus->SubID_Num * RTU_MDL_OFF_SET ){
		//str_modbus->ExceptionCode = ILLEGAL_DATA_VALUE;
		str_modbus->ExceptionCode = ILLEGAL_AGV_FORMAT;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}

	str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_NUM;

	//str_modbus->SecondEcho_State = SECOND_ECHO_STATE_IDLE;

	str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = MDL_CMD_NULL;
	//str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = MDL_CMD_NULL;
    str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = NO;
    //str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = NO;

	// If msg ok, check self sub ID and Echo
	if ( is_msg_ok == 1 ) {
		is_msg_ok = 0;

		for (i=0; i< str_modbus->SubID_Num; i++) {
			// Get Sub_ID
		    str_modbus->SubID[ i ] = data[ RTU_MDL_ID1 + ( i * RTU_MDL_OFF_SET ) ];
			echo =  data[ RTU_MDL_ECHO_BITF + ( i * RTU_MDL_OFF_SET ) + 0 ] * 256 +
					data[ RTU_MDL_ECHO_BITF + ( i * RTU_MDL_OFF_SET ) + 1 ];

			// Set SubID_Seq if ID matched
			if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = i;
				is_msg_ok = 1;

				// Get Command of self ID
				str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = data[ RTU_MDL_CMD1 + ( i * RTU_MDL_OFF_SET ) ];
				str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = (data[ RTU_MDL_DATA + ( i * RTU_MDL_OFF_SET ) + 0 ] * 256) +
				                                                         data[ RTU_MDL_DATA + ( i * RTU_MDL_OFF_SET ) + 1 ];

				str_modbus->MDL_Echo_BITF[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = echo;
				// Check if command supported
				if ( com_FC65_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] ) == NO ) {
					str_modbus->ExceptionCode = SLAVE_DEVICE_FAILURE;
					CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				}
			}/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = i;
                is_msg_ok = 1;

                // Get Command of self ID
                str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = data[ RTU_MDL_CMD1 + ( i * RTU_MDL_OFF_SET ) ];
                str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = (data[ RTU_MDL_DATA + ( i * RTU_MDL_OFF_SET ) + 0 ] * 256) +
                                                                         data[ RTU_MDL_DATA + ( i * RTU_MDL_OFF_SET ) + 1 ];
                str_modbus->MDL_Echo_BITF[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = echo;
                // Check if command supported
                if ( com_FC65_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] ) == NO ) {
                    str_modbus->ExceptionCode_Secondary = SLAVE_DEVICE_FAILURE;
                    CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
                }
            }*/

			// Check if command need echo. Set Echo ID and Echo_Seq.
			if ( echo != NO_ECHO ) {

			    str_modbus->EchoID[ k ] = str_modbus->SubID[ i ];

				// Set Echo_Seq if self ID matched the echo ID
                if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
                    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = k;
                    is_echo_m0 = 1;
                    if( k == 0 ){
                        str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M0;
                    }
                }/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
                    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = k;
                    is_echo_m1 = 1;
                    if( k == 0 ){
                        str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M1;
                    }
                }*/

				k++;
			}
		}
	}

	// Reset echo if no echo.
	if ( is_echo_m0 == 0 )  {
	    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = SUB_ID_NOECHO;
    }
	/*
    if ( is_echo_m1 == 0 )  {
        str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = SUB_ID_NOECHO;
    }*/

    str_modbus->MultiCMD_FC_R = str_modbus->req_pdu_function_code;	// get received function code.

	return ( is_msg_ok );
}

/*===========================================================================================
    Function Name    : com_FC65_Check_ASCII
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description      : FC65 check routine
//==========================================================================================*/
uint8_t com_FC65_Check_ASCII ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus)
{
	uint8_t is_msg_ok = 1;			// Return value.
    uint8_t is_echo_m0      = 0;        // 0: no echo, 1: echo
    //uint8_t is_echo_m1     = 0;        // 0: no echo, 1: echo
	uint8_t i = 0;					// for loop counting index
	uint8_t k = 0;					// counting index
	uint32_t	echo;

	// Get Sub_ID quantity and check range
	str_modbus->SubID_Num = aSCII_to_Unchar( data[ ASC_MDL_IDNUM_H ]  ,data[ ASC_MDL_IDNUM_L ] );
	if ( str_modbus->SubID_Num > SUB_ID_NUM ) {
		//str_modbus->ExceptionCode = ILLEGAL_DATA_ADDRESS;
		str_modbus->ExceptionCode = ILLEGAL_AGV_SUBID_NUM;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}else if( data_num != ASC_MDL_BASIC_LENGTH + str_modbus->SubID_Num * ASC_MDL_OFF_SET ){
		//str_modbus->ExceptionCode = ILLEGAL_DATA_VALUE;
		str_modbus->ExceptionCode = ILLEGAL_AGV_FORMAT;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}

	str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_NUM;

	//str_modbus->SecondEcho_State = SECOND_ECHO_STATE_IDLE;

	str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = MDL_CMD_NULL;
	//str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = MDL_CMD_NULL;
    str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = NO;
    //str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = NO;

	// If msg ok, check self sub ID and Echo
	if ( is_msg_ok == 1 ) {
		is_msg_ok = 0;

		for (i=0; i< str_modbus->SubID_Num; i++) {
			// Get Sub_ID
		    str_modbus->SubID[ i ] = aSCII_to_Unchar( data[ ASC_MDL_ID1_H + ( i * ASC_MDL_OFF_SET ) ]  ,data[ ASC_MDL_ID1_L + ( i * ASC_MDL_OFF_SET ) ] );

			echo =  aSCII_to_Unchar( data[ ASC_MDL_ECHO_BITF + ( i * ASC_MDL_OFF_SET ) + 0 ]  ,data[ ASC_MDL_ECHO_BITF + ( i * ASC_MDL_OFF_SET ) + 1 ] ) * 256 +
					aSCII_to_Unchar( data[ ASC_MDL_ECHO_BITF + ( i * ASC_MDL_OFF_SET ) + 2 ]  ,data[ ASC_MDL_ECHO_BITF + ( i * ASC_MDL_OFF_SET ) + 3 ] );

			// Set SubID_Seq if ID matched
			if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = i;
				is_msg_ok = 1;

				// Get Command of self ID
				str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = aSCII_to_Unchar( data[ ASC_MDL_CMD1_H + ( i * ASC_MDL_OFF_SET ) ]  ,data[ ASC_MDL_CMD1_L + ( i * ASC_MDL_OFF_SET ) ] );
				str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = aSCII_to_Unchar( data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 0 ],
                                                                                         data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 1 ]) * 256 +
                                                                        aSCII_to_Unchar( data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 2 ],
                                                                                         data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 3 ] );

				str_modbus->MDL_Echo_BITF[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = echo;

				// Check if command supported
				if ( com_FC65_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] ) == NO ) {
					str_modbus->ExceptionCode = SLAVE_DEVICE_FAILURE;
					CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				}

			}/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = i;
                is_msg_ok = 1;

                // Get Command of self ID
                str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = aSCII_to_Unchar( data[ ASC_MDL_CMD1_H + ( i * ASC_MDL_OFF_SET ) ]  ,data[ ASC_MDL_CMD1_L + ( i * ASC_MDL_OFF_SET ) ] );
                str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = aSCII_to_Unchar( data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 0 ],
                                                                                         data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 1 ]) * 256 +
                                                                        aSCII_to_Unchar( data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 2 ],
                                                                                         data[ ASC_MDL_DATA + ( i * ASC_MDL_OFF_SET ) + 3 ] );
                str_modbus->MDL_Echo_BITF[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = echo;

                // Check if command supported
                if ( com_FC65_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] ) == NO ) {
                    str_modbus->ExceptionCode_Secondary = SLAVE_DEVICE_FAILURE;
                    CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
                }

            }*/

			// Check if command need echo. Set Echo ID and Echo_Seq.
			if ( echo != NO_ECHO ) {

			    str_modbus->EchoID[ k ] = str_modbus->SubID[ i ];

				// Set Echo_Seq if self ID matched the echo ID
                if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
                    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = k;
                    is_echo_m0 = 1;
                    if( k == 0 ){
                        str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M0;
                    }
                }/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
                    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = k;
                    is_echo_m1 = 1;
                    if( k == 0 ){
                        str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M1;
                    }
                }*/

				k++;
			}
		}
	}

	// Reset echo if no echo.
    if ( is_echo_m0 == 0 )  {
        str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = SUB_ID_NOECHO;
    }
    /*
    if ( is_echo_m1 == 0 )  {
        str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = SUB_ID_NOECHO;
    }*/

    str_modbus->MultiCMD_FC_R = str_modbus->req_pdu_function_code;	// get received function code.

	return ( is_msg_ok );
}

/*===========================================================================================
    Function Name    : com_FC66_Check
    Input            :
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC66 check routine. Check to reply or not.
//==========================================================================================*/
uint8_t com_FC66_Check ( uint8_t *data, Struct_Modbus_Slave *str_modbus)
{
	uint8_t return_value = 0;
	uint8_t lc_LstSubID  = 0;
	uint8_t i;

	str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_NUM;
	for( i = MULTI_DRIVE_DRIVE_INDEX_M0; i < MULTI_DRIVE_DRIVE_INDEX_NUM; i++ ){
        // Check if Echo_Seq is the 1st ID or no Echo. Either of these need no echo.
        if ( ( str_modbus->Echo_Seq[i] != 0) && ( str_modbus->Echo_Seq[i] < SUB_ID_NOECHO) ) {
            lc_LstSubID = str_modbus->EchoID[ str_modbus->Echo_Seq[i] - 1 ];

            if ( str_modbus->req_pdu_slaveID == lc_LstSubID ) {
                /*To Response*/
                str_modbus->Echo_Driver = i;
                return_value = 1;
                break;
            }
        }

    }

	str_modbus->MultiCMD_FC_R = str_modbus->req_pdu_function_code;	// get received function code.

	return (return_value);
}

/*===========================================================================================
    Function Name    : com_FC65_CmdSupport_IsOk
    Input            : 1. lc_cmd: command to check
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check if the command of multi-drive lite command is supported by the device.
//==========================================================================================*/
uint8_t com_FC65_CmdSupport_IsOk ( const uint8_t lc_cmd )
{
	uint8_t return_value = 0;

	switch( lc_cmd ){
		case MDL_CMD_ISTOP:			// Multi-Drive-Lite command ISTOP
		case MDL_CMD_JG:			// Multi-Drive-Lite command JG
		case MDL_CMD_FREE:			// Multi-Drive-Lite command FREE
		case MDL_CMD_SVON:			// Multi-Drive-Lite command Servo ON
		case MDL_CMD_SVOFF:			// Multi-Drive-Lite command Servo OFF
		case MDL_CMD_RST:			// Multi-Drive-Lite command Alarm Reset
		case MDL_CMD_BRAKE:			// Multi-Drive-Lite command Motor Short Brake
		case MDL_CMD_NULL:			// Multi-Drive-Lite command Do Nothing
		case MDL_CMD_NETIO:
			return_value = 1;
			break;
		// inValid command
		default:
			return_value = 0;
			break;
	}
	return (return_value);
}

/*===========================================================================================
    Function Name    : com_FC65_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC65 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC65_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus)
{
    /*
	switch( CG_ComProtocol_01.CMD ){
		// Target speed commands
		case MDL_CMD_JG:
			mdl_Get_TSPD ( (uint8_t*)data, lc_MBscheme, str_modbus );
			break;
		default:
			break;
	}*/
}

/*===========================================================================================
    Function Name    : com_FC66_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC66 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC66_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus)
{
    /*
	if ( (CG_ComProtocol_01.FlagBITF & _BIT(COM_IS_FC65_FAILED)) != 0 ) {
		// last FC65 failed
		str_modbus->req_pdu_function_code = MB_FC67;
	} else {
		// last FC65 ok
		str_modbus->req_pdu_function_code = MB_FC66;
	}*/

    if( str_modbus->Echo_Driver < MULTI_DRIVE_DRIVE_INDEX_NUM ){
        if( str_modbus->MultiCMD_Fail[ str_modbus->Echo_Driver ] == YES ){
            str_modbus->req_pdu_function_code = MB_FC67;   // multi-driver error reply
        }else{
            str_modbus->req_pdu_function_code = MB_FC66;   // multi-driver normal reply
        }
    }
}

/*===========================================================================================
    Function Name    : mdl_Get_TSPD
    Input            : 1. *data: The data array from the Uart receive buffer.
					   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Get the value of TSPD from uart buffer to modbus buffer.
//==========================================================================================*/
void mdl_Get_TSPD ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus )
{
#if(0)
	if ( lc_MBscheme == MB_SLV_RTU ) {
		// RTU
		str_modbus->req_pdu_data[ 0 ] = (data[ RTU_MDL_DATA + ( CG_ComProtocol_01.SubID_Seq * RTU_MDL_OFF_SET ) + 0 ] * 256) +
										 data[ RTU_MDL_DATA + ( CG_ComProtocol_01.SubID_Seq * RTU_MDL_OFF_SET ) + 1 ];

	} else {
		// ASCII
		str_modbus->req_pdu_data[ 0 ] = aSCII_to_Unchar( data[ ASC_MDL_DATA + ( CG_ComProtocol_01.SubID_Seq * ASC_MDL_OFF_SET ) + 0 ],
														 data[ ASC_MDL_DATA + ( CG_ComProtocol_01.SubID_Seq * ASC_MDL_OFF_SET ) + 1 ]) * 256 +
										aSCII_to_Unchar( data[ ASC_MDL_DATA + ( CG_ComProtocol_01.SubID_Seq * ASC_MDL_OFF_SET ) + 2 ],
														 data[ ASC_MDL_DATA + ( CG_ComProtocol_01.SubID_Seq * ASC_MDL_OFF_SET ) + 3 ] );
	}
#endif

}

/*===========================================================================================
    Function Name    : mbRTU_MDLCasting
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Multi-drive-lite ctrl function casting. Repare response data.
//==========================================================================================*/
void mbRTU_MDLCasting (	 uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr,
						 Struct_Modbus_Slave *str_modbus
						 )
{
	uint32_t i = 0;
	uint32_t data_cnt = 0;
	int32_t *RegisterPtr;
	uint8_t lc_echo_driver = str_modbus->Echo_Driver;
    //uint8_t another_driver;
	//uint8_t lc_echo_Seq = com_Export_Echo_Seq( CG_ComProtocol_01.Echo_Driver );
	uint8_t lc_received_FC = str_modbus->MultiCMD_FC_R;

	if( lc_echo_driver >= MULTI_DRIVE_DRIVE_INDEX_NUM ){
        lc_echo_driver = MULTI_DRIVE_DRIVE_INDEX_M0;
    }

	if ( (str_modbus->FlagBITF & (1 << MB_FC_EXECUTE_REQ_BIT)) == 0 ) {

	    if( ( lc_received_FC == MB_FC65 && str_modbus->Echo_Driver < MULTI_DRIVE_DRIVE_INDEX_NUM ) ||
            ( (lc_received_FC == MB_FC66) || (lc_received_FC == MB_FC67) )   ){

	        // Set data quantity

            str_modbus->Response_data[ data_cnt++ ] = ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] >> 8 ) & 0xFF;
            str_modbus->Response_data[ data_cnt++ ] = ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] >> 0 ) & 0xFF;

            // Get Data
            RegisterPtr = ( int32_t* )&str_modbus->MDL_ECHO_DATA[ lc_echo_driver ][0];

            for ( i = 0; i < ECHO_BITF_NUM; i++ ) {
                if( ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] & ( 1UL << i ) ) != 0 ){
                    str_modbus->Response_data[ data_cnt++ ] = ( RegisterPtr[ i ] >> 8  ) & 0xff;
                    str_modbus->Response_data[ data_cnt++ ] = ( RegisterPtr[ i ] >> 0  ) & 0xff;
                }

            }

            str_modbus->Response_data_number = data_cnt;
            str_modbus->req_pdu_data_quantity = str_modbus->Response_data_number / 2;

            str_modbus->req_pdu_slaveID = str_modbus->SubID[ str_modbus->SubID_Seq[ lc_echo_driver ] ];

            str_modbus->State = MB_SLV_NORMAL_REPLY;

            // current driver = lc_echo_driver  ( M0 or M1 )
            // another driver = 1 - current driver ( M1 or M0 )
            // If echo_seq[ another driver ] == echo_seq[ current driver ] + 1
            // Means it needs second echo
            /*
            another_driver = 1 - lc_echo_driver;
            if( str_modbus->Echo_Seq[ another_driver ] == str_modbus->Echo_Seq[ lc_echo_driver ] + 1 ){
                str_modbus->SecondEcho_State = SECOND_ECHO_STATE_MULTI_DRIVE_LITE;
            }*/
            //
	    }else{
            *ReceiveFlag        = UART_READY;               // enable Uart recieve
            str_modbus->State   = MB_SLV_IDLE;
        }

	}
}

/*===========================================================================================
    Function Name    : mb_MDLCasting
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
void mb_MDLCasting ( uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr,
						 Struct_Modbus_Slave *str_modbus
						 )
{
	uint32_t i = 0;
	uint32_t data_cnt = 0;
	int32_t *RegisterPtr;
	uint8_t lc_echo_driver = str_modbus->Echo_Driver;
    //uint8_t another_driver;
    //uint8_t lc_echo_Seq = com_Export_Echo_Seq( CG_ComProtocol_01.Echo_Driver );
	uint8_t lc_received_FC = str_modbus->MultiCMD_FC_R;

	unsigned char temp_byte_data[2];

	if( lc_echo_driver >= MULTI_DRIVE_DRIVE_INDEX_NUM ){
        lc_echo_driver = MULTI_DRIVE_DRIVE_INDEX_M0;
    }

	if ( (str_modbus->FlagBITF & (1 << MB_FC_EXECUTE_REQ_BIT)) == 0 ) {

	    if( ( lc_received_FC == MB_FC65 && str_modbus->Echo_Driver < MULTI_DRIVE_DRIVE_INDEX_NUM ) ||
            ( (lc_received_FC == MB_FC66) || (lc_received_FC == MB_FC67) )   ){

	        // Set data quantity
            unchar_to_ASCII( ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] >> 8 ) & 0xFF, temp_byte_data );
            str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 0 ];
            str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 1 ];

            unchar_to_ASCII( ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] >> 0 ) & 0xFF, temp_byte_data );
            str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 0 ];
            str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 1 ];

            // Get Data
            RegisterPtr = ( int32_t* )&str_modbus->MDL_ECHO_DATA[ lc_echo_driver ][0];

            for ( i = 0; i < ECHO_BITF_NUM; i++ ) {

                if( ( str_modbus->MDL_Echo_BITF[ lc_echo_driver ] & ( 1UL << i ) ) != 0 ){

                    unchar_to_ASCII( ( RegisterPtr[ i ] >> 8  ) & 0xff, temp_byte_data );

                    str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 0 ];
                    str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 1 ];

                    unchar_to_ASCII( ( RegisterPtr[ i ] >> 0  ) & 0xff, temp_byte_data );

                    str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 0 ];
                    str_modbus->Response_data[ data_cnt++ ] = temp_byte_data[ 1 ];

                }

            }

            str_modbus->Response_data_number = data_cnt;
            str_modbus->req_pdu_data_quantity = str_modbus->Response_data_number / 4;

            str_modbus->req_pdu_slaveID = str_modbus->SubID[ str_modbus->SubID_Seq[ lc_echo_driver ] ];

            str_modbus->State = MB_SLV_NORMAL_REPLY;

            // current driver = lc_echo_driver  ( M0 or M1 )
            // another driver = 1 - current driver ( M1 or M0 )
            // If echo_seq[ another driver ] == echo_seq[ current driver ] + 1
            // Means it needs second echo
            /*
            another_driver = 1 - lc_echo_driver;
            if( str_modbus->Echo_Seq[ another_driver ] == str_modbus->Echo_Seq[ lc_echo_driver ] + 1 ){
                str_modbus->SecondEcho_State = SECOND_ECHO_STATE_MULTI_DRIVE_LITE;
            }*/
            //
        }else{
            *ReceiveFlag        = UART_READY;               // enable Uart recieve
            str_modbus->State   = MB_SLV_IDLE;
        }

	}
}

/*===========================================================================================
    Function Name    : com_FC65_Execute
    Input            :
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
					   Set CMD flags, Get stamp data for echo, Return ExceptionCode.
                       If an error occured, Stamp data then do nothing.
//==========================================================================================*/
uint8_t com_FC65_Execute ( Struct_Modbus_Slave *str_modbus )
{
    uint8_t return_value = 1;   // Return original ExceptionCode if an error occured already.
    uint8_t lc_IsCmdOk;                             // 1=ok. 0=SLAVE_DEVICE_FAILURE
    uint8_t lc_cmd; // mod for no echo command.
    int32_t exception[2];
    int8_t i;
    Struct_BLDC_CTRL *bldc_ctrl;

	/*Get Stamp Data*/

	DINT;
	str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_MOTOR_STATE ] = CG_BLDC_CTRL_M0.Motor_State & 65535;
	str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_SPD ] = CG_BLDC_CTRL_M0.Current_RPM & 65535;
	str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_ERROR_INDEX ] = CG_Protect.Motor_0.first_fault_user & 65535;
	str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_IO_STATE ] = ( ( CG_GPIO.Yn_State_BITF << 8 ) | ( CG_GPIO.Xn_State_BITF & 0xFF ) ) & 65535;
	str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_BUS_V ] = CG_ADC.BusV & 65535;
	str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_SHUNT_I ] = CG_ADC.Motor_0.Shunt_I_Avg & 65535;

	/*
	str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_MOTOR_STATE ] = CG_BLDC_CTRL_M1.Motor_State & 65535;

    str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_SPD ] = CG_BLDC_CTRL_M1.Current_RPM & 65535;
    str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_ERROR_INDEX ] = CG_Protect.Motor_1.first_fault_user & 65535;
    str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_IO_STATE ] = ( ( CG_GPIO.Yn_State_BITF << 8 ) | ( CG_GPIO.Xn_State_BITF & 0xFF ) ) & 65535;
    str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_BUS_V ] = CG_ADC.BusV & 65535;
    str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_SHUNT_I ] = CG_ADC.Motor_1.Shunt_I_Avg & 65535;
    */

    if( CG_BLDC_Drive_M0.Sensor_Type == SENSOR_TYPE_HALL ){
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_HALL_CNT_L ] = CG_BLDC_CTRL_M0.Hall_Ptr->Position & 65535;
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_HALL_CNT_H ] = ( CG_BLDC_CTRL_M0.Hall_Ptr->Position >> 16 ) & 65535;
    }else{
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_ENCODER_POS ] = mcGetCurrentPos( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ ECHO_BITF_ENCODER_INDEX ] = mcGetCurrentIndex( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
    }

    /*
    if( CG_BLDC_Drive_M1.Sensor_Type == SENSOR_TYPE_HALL ){
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_HALL_CNT_L ] = CG_BLDC_CTRL_M1.Hall_Ptr->Position & 65535;
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_HALL_CNT_H ] = ( CG_BLDC_CTRL_M1.Hall_Ptr->Position >> 16 ) & 65535;
    }else{
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_ENCODER_POS ] = mcGetCurrentPos( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
        str_modbus->MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ ECHO_BITF_ENCODER_INDEX ] = mcGetCurrentIndex( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
    }*/

	EINT;   // Enable Global interrupt INTM

	exception[0] = str_modbus->ExceptionCode;
    //exception[1] = str_modbus->ExceptionCode_Secondary;

    for( i = 0; i < MULTI_DRIVE_DRIVE_INDEX_NUM; i++ ){

        if( i == 0 ){
            bldc_ctrl = (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0;
        }/*else{
            bldc_ctrl = (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1;
        }*/

        lc_IsCmdOk = 1;
        lc_cmd = str_modbus->CMD[i];

        //Set Do Nothing if ExceptionCode is not 0. ( An error occured already )
        if ( exception[i] != 0 ) {
            lc_cmd = MULTI_CMD_NULL;
        }

        lc_IsCmdOk &= mdlCMD_Execute ( bldc_ctrl, lc_cmd, str_modbus->Data1[ i ] );

        if ( lc_IsCmdOk == 0 ) {
            exception[i] = SLAVE_DEVICE_FAILURE;
        }

        if( exception[i] != 0 ){
            str_modbus->MultiCMD_Fail[i] = YES;
        }
    }

    if( str_modbus->ExceptionCode == 0 ){
        str_modbus->ExceptionCode = exception[0];
    }
    /*
    if( str_modbus->ExceptionCode_Secondary == 0 ){
        str_modbus->ExceptionCode_Secondary = exception[1];
    }*/

    if( str_modbus->Echo_Driver < MULTI_DRIVE_DRIVE_INDEX_NUM ){
        if( str_modbus->MultiCMD_Fail[ str_modbus->Echo_Driver ] == YES ){
            str_modbus->req_pdu_function_code = MB_FC67;   // multi-driver error reply
        }else{
            str_modbus->req_pdu_function_code = MB_FC66;   // multi-driver normal reply
        }
    }

	return (return_value);

}

/*===========================================================================================
    Function Name    : mdlCMD_Execute
    Input            : 1.bldc_ctrl
                       2.cmd
                       3.data
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
//==========================================================================================*/
uint8_t mdlCMD_Execute ( Struct_BLDC_CTRL *bldc_ctrl, int32_t cmd, int32_t data )
{
    uint8_t lc_IsCmdOk = 1;

    switch( cmd ){
        case MDL_CMD_ISTOP:
            lc_IsCmdOk &= mdl_CMD_ISTOP( bldc_ctrl, data );
            break;
        case MDL_CMD_JG:
            lc_IsCmdOk &= mdl_CMD_JG( bldc_ctrl, data );
            break;
        case MDL_CMD_FREE:
            lc_IsCmdOk &= mdl_CMD_FREE( bldc_ctrl, data );
            break;
        case MDL_CMD_SVON:
            lc_IsCmdOk &= mdl_CMD_SVON( bldc_ctrl, data );
            break;
        case MDL_CMD_SVOFF:
            lc_IsCmdOk &= mdl_CMD_SVOFF( bldc_ctrl, data );
            break;
        case MDL_CMD_RST:
            lc_IsCmdOk &= mdl_CMD_RESET( bldc_ctrl, data );
            break;
        case MDL_CMD_BRAKE:
            lc_IsCmdOk &= mdl_CMD_BRAKE( bldc_ctrl, data );
            break;
        case MDL_CMD_NETIO:
            lc_IsCmdOk &= mdl_CMD_NetIO( bldc_ctrl, data );
            break;
        //Do Nothing command. Unconditional pass.
        case MDL_CMD_NULL:
            lc_IsCmdOk &= 1;
            break;

        // inValid command
        default:
            lc_IsCmdOk = 0;
            break;
    }

    return lc_IsCmdOk;

}




/*===========================================================================================
    Function Name    : mdl_CMD_ISTOP
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command STOP processing routine.
					   Condition check, FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_ISTOP ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    int8_t free_is_on = NO;
	int8_t brake_is_on = NO;
    uint8_t io_src;

    io_src = bldc_ctrl->MultiDrive_Src;

    if( ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_IO ] >> FUNC_FREE ) & 0x01 )  != 0 ||
        ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_UART ] >> FUNC_FREE ) & 0x01 ) != 0 ){
        free_is_on = YES;
    }
    if( ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_IO ] >> FUNC_EBRAKE ) & 0x01 ) != 0 ||
        ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_UART ] >> FUNC_EBRAKE ) & 0x01 ) != 0 ){
        brake_is_on = YES;
    }

	if ( bldc_ctrl->MDL_Enabled == YES &&
	     bldc_ctrl->Motor_State != MOTOR_STATE_WAIT &&
	     bldc_ctrl->Motor_State != MOTOR_STATE_STO &&
		 free_is_on == NO &&
		 brake_is_on == NO ) {


		io_ValClr_DI_XN_BITF( io_src, 	_BIT(SRC_MULTI_DRIVE_START_STOP_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_FREE_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );
		io_ValSet_DI_XN_BITF( io_src, (_BIT(SRC_MULTI_DRIVE_STOP_BIT) | _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT)) );
		return 1;
	}else{
	    CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
	    return 0;
	}

}

/*===========================================================================================
    Function Name    : mdl_CMD_JG
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command JGF processing routine.
					   Condition check, FUNC flags set, TSPD update.
//==========================================================================================*/
uint8_t mdl_CMD_JG ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    int16_t	target_speed;
    int8_t free_is_on = NO;
    int8_t brake_is_on = NO;
    uint8_t io_src;

    io_src = bldc_ctrl->MultiDrive_Src;

    if( ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_IO ] >> FUNC_FREE ) & 0x01 )  != 0 ||
        ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_UART ] >> FUNC_FREE ) & 0x01 ) != 0 ){
        free_is_on = YES;
    }
    if( ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_IO ] >> FUNC_EBRAKE ) & 0x01 ) != 0 ||
        ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_UART ] >> FUNC_EBRAKE ) & 0x01 ) != 0 ){
        brake_is_on = YES;
    }

	if ( bldc_ctrl->MDL_Enabled == YES &&
	     bldc_ctrl->Motor_State != MOTOR_STATE_WAIT &&
	     bldc_ctrl->Motor_State != MOTOR_STATE_STO &&
		 free_is_on == NO &&
		 brake_is_on == NO ) {

		io_ValClr_DI_XN_BITF( io_src, 	_BIT( SRC_MULTI_DRIVE_FREE_BIT ) |
                                        _BIT( SRC_MULTI_DRIVE_STOP_BIT ) |
                                        _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) |
                                        _BIT( SRC_MULTI_DRIVE_STOP_MODE_BIT )  );

		target_speed = (int16_t)data;

		if( target_speed > 0 ){
			//CG_ComProtocol_01.TSPD[ index ] = target_speed;
		    bldc_ctrl->TSPD = target_speed;
			io_ValClr_DI_XN_BITF( io_src, _BIT( SRC_MULTI_DRIVE_CW_CCW_BIT ) );
			io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) );
		}else if( target_speed < 0 ){
			//CG_ComProtocol_01.TSPD[ index ] = -1 * target_speed;
		    bldc_ctrl->TSPD = -1 * target_speed;
			io_ValSet_DI_XN_BITF( io_src, 	_BIT(SRC_MULTI_DRIVE_START_STOP_BIT) |
										    _BIT( SRC_MULTI_DRIVE_CW_CCW_BIT ) );
		}else{
			//CG_ComProtocol_01.TSPD[ index ] = 0;
		    bldc_ctrl->TSPD = 0;
			io_ValClr_DI_XN_BITF( io_src, 	_BIT( SRC_MULTI_DRIVE_START_STOP_BIT ) );
		}

		return 1;

	} else {
		CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
		return 0;
	}

}

/*===========================================================================================
    Function Name    : mdl_CMD_FREE
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command FREE processing routine.
					   FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_FREE ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    uint8_t io_src;

    io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->MDL_Enabled == YES ){
		io_ValClr_DI_XN_BITF( io_src, 	_BIT(SRC_MULTI_DRIVE_START_STOP_BIT) |
									    _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT));
		io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_FREE_BIT) );
		return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : mdl_CMD_SVON
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command SVON (Servo ON) processing routine.
					   FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_SVON ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    uint8_t io_src;
    io_src = bldc_ctrl->MultiDrive_Src;

    if( bldc_ctrl->MDL_Enabled == YES &&
        bldc_ctrl->Motor_State != MOTOR_STATE_STO ){
		io_ValClr_DI_XN_BITF( io_src, 	_BIT(SRC_MULTI_DRIVE_FREE_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_START_STOP_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_STOP_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_STOP_MODE_BIT) );

		io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_KEYSWITCH_BIT) );
		return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : mdl_CMD_SVOFF
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The Multi command SVOFF processing routine.
					   FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_SVOFF ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    uint8_t io_src;
    int8_t svo_is_on = NO;

    io_src = bldc_ctrl->MultiDrive_Src;

	if( bldc_ctrl->Driver_Enable_Mode == DRIVER_EN_MODE_0 ||
	    ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_IO ] >> FUNC_KEY_SWITCH ) & 0x01 ) != 0 ||
	    ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_UART ] >> FUNC_KEY_SWITCH ) & 0x01 ) != 0 ){
		svo_is_on = YES;
	}

    if( bldc_ctrl->MDL_Enabled == YES &&
    	svo_is_on == NO &&
    	bldc_ctrl->Motor_State != MOTOR_STATE_STO ){

		io_ValClr_DI_XN_BITF( io_src, 	_BIT(SRC_MULTI_DRIVE_START_STOP_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_KEYSWITCH_BIT) |
                                        _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );

		return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : mdl_CMD_BRAKE
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mdl_CMD_BRAKE ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    int8_t free_is_on = NO;
    uint8_t io_src;

    io_src = bldc_ctrl->MultiDrive_Src;

    if( ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_IO ] >> FUNC_FREE ) & 0x01 ) != 0 ||
        ( ( bldc_ctrl->IO_Func_Ptr->IOF_STAT_BITF[ SRC_UART ] >> FUNC_FREE ) & 0x01 ) != 0 ){
        free_is_on = YES;
    }

	if ( bldc_ctrl->MDL_Enabled == YES &&
	     bldc_ctrl->Motor_State != MOTOR_STATE_WAIT &&
	     bldc_ctrl->Motor_State != MOTOR_STATE_STO &&
		 free_is_on == NO ) {

		io_ValClr_DI_XN_BITF( io_src, 	_BIT(SRC_MULTI_DRIVE_FREE_BIT) |
									    _BIT(SRC_MULTI_DRIVE_START_STOP_BIT));

		io_ValSet_DI_XN_BITF( io_src, _BIT(SRC_MULTI_DRIVE_EBRAKE_BIT) );
		return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

/*===========================================================================================
    Function Name    : mdl_CMD_RESET
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mdl_CMD_RESET ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    uint32_t fault_bitf;

    fault_bitf = bldc_ctrl->Protect_Ptr->Fault_BITF;

    if( bldc_ctrl->MDL_Enabled == YES &&
        fault_bitf == 0 ){
    	//CG_ComProtocol_01.FlagBITF |= (1UL << COM_ALM_RESET_REQ_BIT);

        bldc_ctrl->Protect_Ptr->ToReset = YES;

		return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }

}

/*===========================================================================================
    Function Name    : mdl_CMD_NetIO
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mdl_CMD_NetIO ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data )
{
    if( bldc_ctrl->MDL_Enabled == YES ){
        CG_ComProtocol_01.COM_IO_Xn_BITF = data;
        return 1;
    }else{
        CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
        return 0;
    }
}

 /************************** <END OF FILE> *****************************************/


