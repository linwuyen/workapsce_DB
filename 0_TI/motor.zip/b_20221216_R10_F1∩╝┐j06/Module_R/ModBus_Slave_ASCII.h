/*===========================================================================================
    File Name       : ModBus_Slave_ASCII.h
    Built Date      : 2013-02-19
	Version         : V1.04a
    Programmer      : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description     : This is the head file of Modbus Slave ASCII driver
					  Note : For farther info please reference to the ModBus_Slave_ASCII.c			
    =========================================================================================
    History         : 2013-02-04 Perlimary version.
						- Based on ModBus_Slave_V1_00_01.c.
					    - Rebuilding the module as a basic modbus functions.
							- Support Target:
								1. FC3
								2. FC6
								3. FC10
							with basic modbus protocol.
					  2015-11-02 Modify for combine of 232 and 485. By Chaim

					  Note : For farther history please reference to the ModBus_Slave_V1_00_01.c										
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */
#ifndef MODBUS_SLAVE_ASCII_H_
#define MODBUS_SLAVE_ASCII_H_






/*===========================================================================================
    Function Name    : data_fill_in_Converter
    Input            : 
					   1. src : address of src array
					   2. dst : address of dst array
					   3. data_byte_length : total byte length ( ex: move 2 int value = 2 * 2 = 4 bytes )
					   4. data_type : 1 = char, 2 = int, 4 = long
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This is a array copy function, it will copy data from src to dst one by one.
					   Convert unchar into ascii if the data is int.
			           Notice that : It is not a general function, it is designed for modbus data return fuction at FC3 only
					   This Function only support char and int currently.
//==========================================================================================*/
void data_fill_in_Converter( unsigned char *src,
							 unsigned char *dst,
                             int data_byte_length,
                             int data_type );
							 
/*===========================================================================================
    Function Name    : mb_idle
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb idle routine to check the received data.
					   Set to mb_req_checking if uart received data is done. 
//==========================================================================================*/
void mb_idle ( 	uint8_t *ReceiveFlag,
				uint8_t *data,
				uint32_t data_num,
				uint8_t *T_data,
				uint8_t *T_data_Length,
				uint8_t *T_send_flag,
				uint8_t *T_data_ptr, 
				Struct_Modbus_Slave *str_modbus	);
				
/*===========================================================================================
    Function Name    : mb_req_checking
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check.
					   Check frame and SlaveID.
					   Set to processing if all check passed.
					   Set to idle if frame check failed.
					   Set to error response if one of the function code, address or data check failed.
					   Set to broadcast ending if function code check failed in broadcast mode.
//==========================================================================================*/
void mb_req_checking ( uint8_t *ReceiveFlag,
					   uint8_t *data,
					   uint32_t data_num,
					   uint8_t *T_data,
					   uint8_t *T_data_Length,
					   uint8_t *T_send_flag,
					   uint8_t *T_data_ptr,
					   Struct_Modbus_Slave *str_modbus	);

					   
/*===========================================================================================
    Function Name    : mb_req_processing
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit processing.
					   Set to normal response if processing done without error.
					   Set to Error response if error ocurred while processing.
					   Set to broadcast end after processing regardless error in broadcast mode.
//==========================================================================================*/
void mb_req_processing ( uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr, 
						 Struct_Modbus_Slave *str_modbus);

						 
/*===========================================================================================
    Function Name    : mb_unicast
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 
//==========================================================================================*/
void mb_unicast ( uint8_t *ReceiveFlag,
				  uint8_t *data,
				  uint32_t data_num,
				  uint8_t *T_data,
				  uint8_t *T_data_Length,
				  uint8_t *T_send_flag,
				  uint8_t *T_data_ptr, 
				  Struct_Modbus_Slave *str_modbus  );
				  
/*===========================================================================================
    Function Name    : mb_broadcast
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : 
//==========================================================================================*/
void mb_broadcast ( uint8_t *ReceiveFlag,
					uint8_t *data,
				    uint32_t data_num,
				    uint8_t *T_data,
				    uint8_t *T_data_Length,
				    uint8_t *T_send_flag,
				    uint8_t *T_data_ptr, 
					Struct_Modbus_Slave *str_modbus	);
						
/*===========================================================================================
    Function Name    : mb_normal_reply
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Response the normal message and set back to idle state.
//==========================================================================================*/
void mb_normal_reply ( uint8_t *ReceiveFlag,
					   uint8_t *data,
				       uint32_t data_num,
				       uint8_t *T_data,
				       uint8_t *T_data_Length,
				       uint8_t *T_send_flag,
				       uint8_t *T_data_ptr, 
					   Struct_Modbus_Slave *str_modbus   );

/*===========================================================================================
    Function Name    : mb_SecondEcho_reply
    Input            :
                       1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
                           1 = BUSY.
                           2 = DONE.
                       2. *data     : The data array from the Uart receive buffer.
                       3. data_num  : The received data number from the Uart buffer.
                       4. *T_data   : The Uart transmit buffer to put data to send.
                       5. *T_data_Length: The Uart transmit data length to send.
                       6. *T_send_flag  : The Uart transmit require flag.
                       7. *T_data_ptr   : The Uart transmit data pointer.
                       8. Struct_Modbus_Slave *str_modbus   : The struct of RS232 or RS485
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mb_SecondEcho_reply ( uint8_t *ReceiveFlag,
                       uint8_t *data,
                       uint32_t data_num,
                       uint8_t *T_data,
                       uint8_t *T_data_Length,
                       uint8_t *T_send_flag,
                       uint8_t *T_data_ptr,
                       Struct_Modbus_Slave *str_modbus
                    );
					   
/*===========================================================================================
    Function Name    : mb_error_reply
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Response the error message and set back to idle state.
//==========================================================================================*/
void mb_error_reply ( uint8_t *ReceiveFlag,
					  uint8_t *data,
				      uint32_t data_num,
				      uint8_t *T_data,
				      uint8_t *T_data_Length,
				      uint8_t *T_send_flag,
				      uint8_t *T_data_ptr, 
					  Struct_Modbus_Slave *str_modbus  );

				  
/*===========================================================================================
    Function Name    : mb_ADU_frame_check_is_ok
    Input            : 
					   1. *data: The data from the Modbus buffer. (Uart received data)
					   2. data_num: The received data number from the Uart buffer.
					   3. slaveID : The slave id from the received buffer. ( starting address )
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : return_value: 0 = frame_check failed.
									 1 = frame_check_passed.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the frame and slaveID of the received data from Uart buffer.
//==========================================================================================*/
uint8_t mb_ADU_frame_check_is_ok ( uint8_t *data, uint32_t data_num, uint8_t slaveID, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mb_PDU_Address_check_is_ok
    Input            : 
					   1. add_h : The data address high byte.
					   2. add_L : The data address low byte.
					   3. quantity : the quantity of the data received.
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : return_value: 0 = address check failed.
									 1 = address check passed.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the address of PDU in modbus slave ASCII.
					   Note: This function only support FC3, FC6 and FC16.
//==========================================================================================*/
uint8_t mb_PDU_Address_check_is_ok ( uint8_t add_h, uint8_t add_L, int32_t quantity );

/*===========================================================================================
    Function Name    : mb_PDU_Data_check_is_ok
    Input            : 
					   1. quantity : The quantity of the data received.
					   2. data_num : The received data number from the Uart buffer.
					   3. FC	   : The function code.
					   3. bytecount: The received byte count .
    Return           : return_value: 0 = data check failed.
									 1 = data check passed.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the data of PDU in modbus slave ASCII.
					   Note: This function only support FC3, FC6 and FC16.
//==========================================================================================*/
uint8_t mb_PDU_Data_check_is_ok ( int32_t quantity, uint32_t data_num, uint8_t FC, int32_t bytecount  );

/*===========================================================================================
    Function Name    : mb_Function_FC16_Data_check_is_ok
    Input            : 
					   1. quantity : The quantity of the data received.
					   2. FC	   : The function code.
					   3. bytecount: The received byte count .
    Return           : return_value: 0 = data check failed.
									 1 = data check passed.
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : Check the data of ( Byte Count == Quantity of Registers x 2 )
					   Note: This function only support FC16.
//==========================================================================================*/
uint8_t mb_Function_FC16_Data_check_is_ok ( int32_t quantity, uint8_t FC, int32_t bytecount );

/*===========================================================================================
    Function Name    : mb_Frame_Check
    Input            : 
					   1. *data : Recieved data array to check.
					   2. data_num : data number to be check.
					   
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the frame of recieved data of modbus (LCR) and return Good or Bad.
//==========================================================================================*/
unsigned char mb_Frame_Check( unsigned char *data, unsigned char data_num );

/*===========================================================================================
    Function Name    : mb_FC_Check_is_Ok
    Input            : 
					   1. FC : Recieved function code to be check.					   
					   2. address_h : The data address high byte.
					   3. address_l : The data address low byte.
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the if the function code is supported by the device. Return the result.
	LastUpData		 : 2014 0219
//==========================================================================================*/
unsigned char mb_FC_Check_is_Ok ( unsigned char FC, int32_t address_h, int32_t address_l );

/*===========================================================================================
    Function Name    : MB_Function_FC3
    Input            : 
					   1. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC3 command function to excute.
					   Send requested holding register value to Uart Tx buffer.
//==========================================================================================*/
void mB_Function_FC3 ( Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mB_Function_FC6
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC6 command function to excute.
					   Calculate the data to write and prepare the response data.
//==========================================================================================*/
void mB_Function_FC6 ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mB_Function_FC8
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : FC8 command function to excute.
					   Calculate the data to write and prepare the response data.
	LastUpData		 : 2014 0219
//==========================================================================================*/
void mB_Function_FC8 ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mB_Function_FC16
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.	
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC16 command function to excute.
					   Calculate the data to write and prepare the response data.
//==========================================================================================*/
void mB_Function_FC16 ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mb_normal_response
    Input            : 
					   1. slaveID : slave ID of the device
					   2. FC : Function Code of the command
					   3. data_num : Requested data number      
			           4. *data : data array to be sent
					   5. *str_Uart : UART golobal data struct to be modified.
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This function returns Modbus in ModBus_Slave_Response().
//==========================================================================================*/
void mb_normal_response ( unsigned char slaveID, unsigned char FC,
						  unsigned char data_num, unsigned char *data,
						  unsigned char *T_data, unsigned char *T_data_length,
						  unsigned char *send_data_flag, unsigned char *T_data_Ptr );
						  
/*===========================================================================================
    Function Name    : mb_Error_response
    Input            : 
					   1. slaveID : slave ID of the device
					   2. error_code : the requested function code
					   3. exception_code : 01 = ILLEGAL FUNCTION      
			                               02 = ILLEGAL DATA ADDRESS
						                   03 = ILLEGAL DATA VALUE
			                               04 = SLAVE DEVICE FAILURE
					   4. *str_Uart : UART golobal data struct to be modified.
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This function returns Modbus error code.
//==========================================================================================*/
void mb_Error_response ( int slaveID, int error_code, int exception_code,
					    unsigned char *T_data, unsigned char *T_data_length,
						unsigned char *send_data_flag, unsigned char *T_data_Ptr);


/*===========================================================================================
    Function Name    : mb_write_holdingRegister
    Input            : 1. address_h: high byte of the holding register to update.
					   2. address_l: low byte of the holding register to update.
					   3. data_num: data quantity to write.
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Nul.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update the holdingresiger from modbus_slave buffer.
//==========================================================================================*/
void mb_write_holdingRegister ( int address_h, int address_l, int data_num, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mb_General_FC_Check
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check.
					   Check frame and SlaveID.
					   Set to processing if all check passed.
					   Set to idle if frame check failed.
					   Set to error response if one of the function code, address or data check failed.
					   Set to broadcast ending if function code check failed in broadcast mode.
//==========================================================================================*/
uint8_t mb_General_FC_Check ( 	uint8_t *ReceiveFlag,
								uint8_t *data,
								uint32_t data_num,
								Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mb_FC101_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mb_FC101_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mb_FC102_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mb_FC102_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mb_SpecialCasting
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Multi-driver ctrl function casting. Repare response data.
//==========================================================================================*/
void mb_SpecialCasting ( uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr,
						 Struct_Modbus_Slave *str_modbus
						 );


#endif
/************************** <END OF FILE> *****************************************/
