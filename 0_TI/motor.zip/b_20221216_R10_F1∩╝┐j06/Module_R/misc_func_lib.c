/**************************************************************************//**
 * @file     misc_func_lib.c
 * @brief    library for Trumman custom misc mini functions.
 * @version  V0.01
 * @date     04. February 2013
 *
 * @note
 * Trunmman Technology Corporation. All rights reserved.
 * Programmer      : Gear.Feng@trumman.com.tw
 *
 * @par
 * Trumman custom library for misc mini functions.
 *
 ******************************************************************************/
//#include "Type.h"
#include "IncludeFiles.h"
 
/*===========================================================================================
    Function Name    : aSCII_to_Unchar
    Input            : 
					   1. char_buffer_0 : input high byte
					   2. char_buffer_1 : input low byte
    Return           : Converted value.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This function converts 2bytes ascii data into a unsigned char.
					   ex: input = "ff", then output = 255.
//==========================================================================================*/
unsigned char aSCII_to_Unchar(unsigned char char_buffer_0, unsigned char char_buffer_1)
{	
	unsigned char temp=0;
	unsigned char temp_0=0;
	unsigned char temp_1=0;
	if(char_buffer_0>64){
		temp_0 = ((char_buffer_0-0x41+10)*16);	//65 =>A
	}
	if(char_buffer_0<58){
		temp_0 = ((char_buffer_0-0x30)*16); 	//48 =>0
	}
	if(char_buffer_1>64){
		temp_1 = (char_buffer_1-0x41+10);		//65 =>A
	}
	if(char_buffer_1<58){
		temp_1 = (char_buffer_1-0x30); 			//48 =>0
	}
	temp = (temp_0 + temp_1);
	return (temp);
}


/*===========================================================================================
    Function Name    : unchar_to_ASCII
    Input            : 
					   1. char_buffer : input data
					   2. final_char : output 2bytes ascii data
					   				   final_char[0] = high byte, final_char[1] = low byte
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This function converts an unsigned char data to a 2-byte ascii array. 
		 			   ex: char_buffer = 255, then final_char will get "ff".
//==========================================================================================*/
void unchar_to_ASCII(unsigned char char_buffer,unsigned char *final_char)
{
    //char final_char[2];	
	char trans_buffer_1 = (char_buffer/16);
	char trans_buffer_0 = (char_buffer - trans_buffer_1*16);
	if(trans_buffer_1>9){
		trans_buffer_1 = ((trans_buffer_1-10) + 65);	//65 =>A
	}else{
		trans_buffer_1 = (trans_buffer_1 + 48);		//48 =>0
	}
	if(trans_buffer_0>9){
		trans_buffer_0 = ((trans_buffer_0-10) + 65);	//65 =>A
	}else{
		trans_buffer_0 = (trans_buffer_0 + 48);		//48 =>0
	}
	final_char[0]=trans_buffer_1;
	final_char[1]=trans_buffer_0;
}


/*===========================================================================================
    Function Name    : newtonSqrt
    Input            : x: x
    Return           : result = x^0.5
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t newtonSqrt( int32_t x )
{
    int32_t ans = x;
	int32_t temp;
	int32_t counter = 0;


    if( x < 1 ){
        return 0;
    }else{
        while( counter < 15 ){
            //temp = ( ans * ans + x ) / ( 2 * ans );

        	if( ans > 10000 ){
				temp = ( ans / 2 ) + ( x / ( 2 * ans ) ) ;
        	}else{
        		temp = ( ans * ans + x ) / ( 2 * ans );
        	}

        	if( ans - temp < 9 && ans - temp > -9 ){
        		counter = 15;
        	}

        	ans = temp;
			counter++;

        }
        return ans;
    }
}

/*===========================================================================================
    Function Name    : tmGCD
    Input            : a = x1, b = x2
    Return           : result GCD
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t tmGCD( int32_t a, int32_t b )
{
	int32_t gcd = 1;

    if( a == 0 || b == 0) {
        return gcd;
    }else{

		while( a > 0 && b > 0 ) {

			if( a > b ){
				a = a % b;
			}else{
				b = b % a;
			}
		}

		if( a == 0 ) {
			gcd = b;
		}else {
			gcd = a;
		}
		return gcd;
	}

}



	
	
	
/************************** <END OF FILE> *****************************************/	
