/*
 * CANOpen_TypeDef.h
 *
 *  Created on: 2020/11/30
 *      Author: chaim.chen
 */

#ifndef CAN_OPEN_TYPEDEF_H_
#define CAN_OPEN_TYPEDEF_H_

/*  Trunmman Technology Corporation. All rights reserved. */

//#include "IncludeFiles.h"

#define CAN_OPEN_DATA_NUM       8

#define CAN_OPEN_BROADCAST_ID   0

#define SDO_SUBINDEX_OFFSET     1

#define CANID_11BITS            0
#define CANID_29BITS            1

enum{
    CO_ERR_REG_BIT_0_GENERIC    = 0,
    CO_ERR_REG_BIT_1_CURRENT    = 1,
    CO_ERR_REG_BIT_2_VOLTAGE    = 2,
    CO_ERR_REG_BIT_3_TEMP       = 3,
    CO_ERR_REG_BIT_4_COMM       = 4,
    CO_ERR_REG_BIT_5_DEVICE     = 5,
    CO_ERR_REG_BIT_6_RES        = 6,
    CO_ERR_REG_BIT_7_MANU       = 7,
    CO_ERR_REG_BIT_NUM          = 8
};


/**
 * @defgroup CO_EM_errorCodes CANopen Error codes
 * @{
 *
 * Standard error codes according to CiA DS-301 and DS-401.
 */
#define CO_EMC_NO_ERROR                 0x0000U /**< 0x00xx, error Reset or No Error */
#define CO_EMC_GENERIC                  0x1000U /**< 0x10xx, Generic Error */
#define CO_EMC_CURRENT                  0x2000U /**< 0x20xx, Current */
#define CO_EMC_CURRENT_INPUT            0x2100U /**< 0x21xx, Current, device input side */
#define CO_EMC_CURRENT_INSIDE           0x2200U /**< 0x22xx, Current inside the device */
#define CO_EMC_CURRENT_OUTPUT           0x2300U /**< 0x23xx, Current, device output side */
#define CO_EMC_VOLTAGE                  0x3000U /**< 0x30xx, Voltage */
#define CO_EMC_VOLTAGE_MAINS            0x3100U /**< 0x31xx, Mains Voltage */
#define CO_EMC_VOLTAGE_INSIDE           0x3200U /**< 0x32xx, Voltage inside the device */
#define CO_EMC_VOLTAGE_OUTPUT           0x3300U /**< 0x33xx, Output Voltage */
#define CO_EMC_TEMPERATURE              0x4000U /**< 0x40xx, Temperature */
#define CO_EMC_TEMP_AMBIENT             0x4100U /**< 0x41xx, Ambient Temperature */
#define CO_EMC_TEMP_DEVICE              0x4200U /**< 0x42xx, Device Temperature */
#define CO_EMC_HARDWARE                 0x5000U /**< 0x50xx, Device Hardware */
#define CO_EMC_SOFTWARE_DEVICE          0x6000U /**< 0x60xx, Device Software */
#define CO_EMC_SOFTWARE_INTERNAL        0x6100U /**< 0x61xx, Internal Software */
#define CO_EMC_SOFTWARE_USER            0x6200U /**< 0x62xx, User Software */
#define CO_EMC_DATA_SET                 0x6300U /**< 0x63xx, Data Set */
#define CO_EMC_ADDITIONAL_MODUL         0x7000U /**< 0x70xx, Additional Modules */
#define CO_EMC_MONITORING               0x8000U /**< 0x80xx, Monitoring */
#define CO_EMC_COMMUNICATION            0x8100U /**< 0x81xx, Communication */
#define CO_EMC_CAN_OVERRUN              0x8110U /**< 0x8110, CAN Overrun (Objects lost) */
#define CO_EMC_CAN_PASSIVE              0x8120U /**< 0x8120, CAN in Error Passive Mode */
#define CO_EMC_HEARTBEAT                0x8130U /**< 0x8130, Life Guard Error or Heartbeat Error */
#define CO_EMC_BUS_OFF_RECOVERED        0x8140U /**< 0x8140, recovered from bus off */
#define CO_EMC_CAN_ID_COLLISION         0x8150U /**< 0x8150, CAN-ID collision */
#define CO_EMC_PROTOCOL_ERROR           0x8200U /**< 0x82xx, Protocol Error */
#define CO_EMC_PDO_LENGTH               0x8210U /**< 0x8210, PDO not processed due to length error */
#define CO_EMC_PDO_LENGTH_EXC           0x8220U /**< 0x8220, PDO length exceeded */
#define CO_EMC_DAM_MPDO                 0x8230U /**< 0x8230, DAM MPDO not processed, destination object not available */
#define CO_EMC_SYNC_DATA_LENGTH         0x8240U /**< 0x8240, Unexpected SYNC data length */
#define CO_EMC_RPDO_TIMEOUT             0x8250U /**< 0x8250, RPDO timeout */
#define CO_EMC_TIME_DATA_LENGTH         0x8260U /**< 0x8260, Unexpected TIME data length */
#define CO_EMC_EXTERNAL_ERROR           0x9000U /**< 0x90xx, External Error */
#define CO_EMC_ADDITIONAL_FUNC          0xF000U /**< 0xF0xx, Additional Functions */
#define CO_EMC_DEVICE_SPECIFIC          0xFF00U /**< 0xFFxx, Device specific */

#define CO_EMC401_OUT_CUR_HI            0x2310U /**< 0x2310, DS401, Current at outputs too high (overload) */
#define CO_EMC401_OUT_SHORTED           0x2320U /**< 0x2320, DS401, Short circuit at outputs */
#define CO_EMC401_OUT_LOAD_DUMP         0x2330U /**< 0x2330, DS401, Load dump at outputs */
#define CO_EMC401_IN_VOLT_HI            0x3110U /**< 0x3110, DS401, Input voltage too high */
#define CO_EMC401_IN_VOLT_LOW           0x3120U /**< 0x3120, DS401, Input voltage too low */
#define CO_EMC401_INTERN_VOLT_HI        0x3210U /**< 0x3210, DS401, Internal voltage too high */
#define CO_EMC401_INTERN_VOLT_LO        0x3220U /**< 0x3220, DS401, Internal voltage too low */
#define CO_EMC401_OUT_VOLT_HIGH         0x3310U /**< 0x3310, DS401, Output voltage too high */
#define CO_EMC401_OUT_VOLT_LOW          0x3320U /**< 0x3320, DS401, Output voltage too low */
/** @} */


/**
 * @defgroup CO_EM_errorCodes CANopen Error codes
 * @{
 *
 * Standard error codes according to CiA DS-301 and DS-401.
 */
#define CO_EMC_NO_ERROR                 0x0000U /**< 0x00xx, error Reset or No Error */
#define CO_EMC_GENERIC                  0x1000U /**< 0x10xx, Generic Error */
#define CO_EMC_CURRENT                  0x2000U /**< 0x20xx, Current */
#define CO_EMC_CURRENT_INPUT            0x2100U /**< 0x21xx, Current, device input side */
#define CO_EMC_CURRENT_INSIDE           0x2200U /**< 0x22xx, Current inside the device */
#define CO_EMC_CURRENT_OUTPUT           0x2300U /**< 0x23xx, Current, device output side */
#define CO_EMC_VOLTAGE                  0x3000U /**< 0x30xx, Voltage */
#define CO_EMC_VOLTAGE_MAINS            0x3100U /**< 0x31xx, Mains Voltage */
#define CO_EMC_VOLTAGE_INSIDE           0x3200U /**< 0x32xx, Voltage inside the device */
#define CO_EMC_VOLTAGE_OUTPUT           0x3300U /**< 0x33xx, Output Voltage */
#define CO_EMC_TEMPERATURE              0x4000U /**< 0x40xx, Temperature */
#define CO_EMC_TEMP_AMBIENT             0x4100U /**< 0x41xx, Ambient Temperature */
#define CO_EMC_TEMP_DEVICE              0x4200U /**< 0x42xx, Device Temperature */
#define CO_EMC_HARDWARE                 0x5000U /**< 0x50xx, Device Hardware */
#define CO_EMC_SOFTWARE_DEVICE          0x6000U /**< 0x60xx, Device Software */
#define CO_EMC_SOFTWARE_INTERNAL        0x6100U /**< 0x61xx, Internal Software */
#define CO_EMC_SOFTWARE_USER            0x6200U /**< 0x62xx, User Software */
#define CO_EMC_DATA_SET                 0x6300U /**< 0x63xx, Data Set */
#define CO_EMC_ADDITIONAL_MODUL         0x7000U /**< 0x70xx, Additional Modules */
#define CO_EMC_MONITORING               0x8000U /**< 0x80xx, Monitoring */
#define CO_EMC_COMMUNICATION            0x8100U /**< 0x81xx, Communication */
#define CO_EMC_CAN_OVERRUN              0x8110U /**< 0x8110, CAN Overrun (Objects lost) */
#define CO_EMC_CAN_PASSIVE              0x8120U /**< 0x8120, CAN in Error Passive Mode */
#define CO_EMC_HEARTBEAT                0x8130U /**< 0x8130, Life Guard Error or Heartbeat Error */
#define CO_EMC_BUS_OFF_RECOVERED        0x8140U /**< 0x8140, recovered from bus off */
#define CO_EMC_CAN_ID_COLLISION         0x8150U /**< 0x8150, CAN-ID collision */
#define CO_EMC_PROTOCOL_ERROR           0x8200U /**< 0x82xx, Protocol Error */
#define CO_EMC_PDO_LENGTH               0x8210U /**< 0x8210, PDO not processed due to length error */
#define CO_EMC_PDO_LENGTH_EXC           0x8220U /**< 0x8220, PDO length exceeded */
#define CO_EMC_DAM_MPDO                 0x8230U /**< 0x8230, DAM MPDO not processed, destination object not available */
#define CO_EMC_SYNC_DATA_LENGTH         0x8240U /**< 0x8240, Unexpected SYNC data length */
#define CO_EMC_RPDO_TIMEOUT             0x8250U /**< 0x8250, RPDO timeout */
#define CO_EMC_TIME_DATA_LENGTH         0x8260U /**< 0x8260, Unexpected TIME data length */
#define CO_EMC_EXTERNAL_ERROR           0x9000U /**< 0x90xx, External Error */
#define CO_EMC_ADDITIONAL_FUNC          0xF000U /**< 0xF0xx, Additional Functions */
#define CO_EMC_DEVICE_SPECIFIC          0xFF00U /**< 0xFFxx, Device specific */

#define CO_EMC401_OUT_CUR_HI            0x2310U /**< 0x2310, DS401, Current at outputs too high (overload) */
#define CO_EMC401_OUT_SHORTED           0x2320U /**< 0x2320, DS401, Short circuit at outputs */
#define CO_EMC401_OUT_LOAD_DUMP         0x2330U /**< 0x2330, DS401, Load dump at outputs */
#define CO_EMC401_IN_VOLT_HI            0x3110U /**< 0x3110, DS401, Input voltage too high */
#define CO_EMC401_IN_VOLT_LOW           0x3120U /**< 0x3120, DS401, Input voltage too low */
#define CO_EMC401_INTERN_VOLT_HI        0x3210U /**< 0x3210, DS401, Internal voltage too high */
#define CO_EMC401_INTERN_VOLT_LO        0x3220U /**< 0x3220, DS401, Internal voltage too low */
#define CO_EMC401_OUT_VOLT_HIGH         0x3310U /**< 0x3310, DS401, Output voltage too high */
#define CO_EMC401_OUT_VOLT_LOW          0x3320U /**< 0x3320, DS401, Output voltage too low */
/** @} */

/*===========================================================================================
    Mux control Macros
//==========================================================================================*/

enum{

    MAIL_BOX_INDEX_NMT          = 1,
    MAIL_BOX_INDEX_HEARTBEAT    = 2,

    MAIL_BOX_INDEX_SYNC         = 3,


    MAIL_BOX_INDEX_SDO_C2S      = 4,
    MAIL_BOX_INDEX_SDO_S2C      = 5,

    MAIL_BOX_INDEX_TPDO1        = 6,
    MAIL_BOX_INDEX_RPDO1        = 7,

    MAIL_BOX_INDEX_TPDO2        = 8,
    MAIL_BOX_INDEX_RPDO2        = 9,

    MAIL_BOX_INDEX_TPDO3        = 10,
    MAIL_BOX_INDEX_RPDO3        = 11,

    MAIL_BOX_INDEX_TPDO4        = 12,
    MAIL_BOX_INDEX_RPDO4        = 13,

    MAIL_BOX_INDEX_EMCY         = 14,

    MAIL_BOX_INDEX_NUM          = 15

};

enum{
    CANOPEN_ID_NMT              = 0,        // Network management
    CANOPEN_ID_GFC              = 1,        // Global fail safe command
    CANOPEN_ID_FLYING_MASTER    = 0x71,     // 0x71 ~ 0x76 = Flying master
    CANOPEN_ID_IAI              = 0x7F,     // Indicate active interface
    CANOPEN_ID_SYNC             = 0x80,     // Synchronous message
    CANOPEN_ID_EMERGENCY        = 0x80,     // 0x81 ~ 0xFF ( 0x80 + Node ID )
    CANOPEN_ID_TIME_STAMP       = 0x100,    // Time Stamp
    CANOPEN_ID_SRDO             = 0x101,    // 0x101 ~ 0x180 = Safety-relevant data object
    CANOPEN_ID_TPDO1            = 0x180,    // 0x181 ~ 0x1FF ( 0x180 + Node ID )
    CANOPEN_ID_RPDO1            = 0x200,    // 0x201 ~ 0x27F ( 0x200 + Node ID )
    CANOPEN_ID_TPDO2            = 0x280,    // 0x281 ~ 0x2FF ( 0x280 + Node ID )
    CANOPEN_ID_RPDO2            = 0x300,    // 0x301 ~ 0x37F ( 0x300 + Node ID )
    CANOPEN_ID_TPDO3            = 0x380,    // 0x381 ~ 0x3FF ( 0x380 + Node ID )
    CANOPEN_ID_RPDO3            = 0x400,    // 0x401 ~ 0x47F ( 0x400 + Node ID )
    CANOPEN_ID_TPDO4            = 0x480,    // 0x481 ~ 0x4FF ( 0x480 + Node ID )
    CANOPEN_ID_RPDO4            = 0x500,    // 0x501 ~ 0x57F ( 0x500 + Node ID )
    CANOPEN_ID_SDO_S2C          = 0x580,    // 0x581 ~ 0x5FF ( 0x580 + Node ID ) = SDO Server to Client
    CANOPEN_ID_SDO_C2S          = 0x600,    // 0x601 ~ 0x67F ( 0x600 + Node ID ) = SDO Client to Server

    CANOPEN_ID_DYNAMIC_SDO      = 0x6E0,    // Dynamic SDO Request
    CANOPEN_ID_NCP1             = 0x6E1,    // 0x6E1 ~ 0x6E3 = Node claiming procedure
    CANOPEN_ID_NCP2             = 0x6F0,    // 0x6F0 ~ 0x6FF = Node claiming procedure

    CANOPEN_ID_NMT_ERR_CTRL     = 0x700,    // 0x701 ~ 0x77F ( 0x700 + Node ID ) = NMT Error control

    CANOPEN_ID_LSS              = 0x7E4     // 0x7E4 ~ 0x7E5 = Layer setting service

};


/**
 * Internal network state of the CANopen node
 */
typedef enum{
    CO_NMT_UNKNOWN                  = -1,   /**< Device state is unknown (for heartbeat consumer) */
    CO_NMT_INITIALIZING             = 0,    /**< Device is initializing */
    CO_NMT_PRE_OPERATIONAL          = 127,  /**< Device is in pre-operational state */
    CO_NMT_OPERATIONAL              = 5,    /**< Device is in operational state */
    CO_NMT_STOPPED                  = 4     /**< Device is stopped */
}CO_NMT_internalState_t;


/**
 * Commands from NMT master.
 */
typedef enum{
    CO_NMT_ENTER_OPERATIONAL        = 1,    /**< Start device */
    CO_NMT_ENTER_STOPPED            = 2,    /**< Stop device */
    CO_NMT_ENTER_PRE_OPERATIONAL    = 128,  /**< Put device into pre-operational */
    CO_NMT_RESET_NODE               = 129,  /**< Reset device */
    CO_NMT_RESET_COMMUNICATION      = 130   /**< Reset CANopen communication on device */
}CO_NMT_command_t;

/**
 * Return code for CO_NMT_process() that tells application code what to
 * reset.
 */
typedef enum{
    CO_RESET_NOT  = 0,/**< Normal return, no action */
    CO_RESET_COMM = 1,/**< Application must provide communication reset. */
    CO_RESET_APP  = 2,/**< Application must provide complete device reset */
    CO_RESET_QUIT = 3 /**< Application must quit, no reset of microcontroller (command is not requested by the stack.) */
}CO_NMT_reset_cmd_t;


#define CO_HEART_BEAT_DEFAULT_MS        CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CANOPEN_HEARTBEAT_TIME ] // 0 //500


enum{
    OD_H0000_RES                  = 0x0000, // Reserved
    OD_H0001_DATA_TYPE            = 0x0001, // Data Type : 0x0001 ~ 0x025F
    OD_H0260_RES                  = 0x0260, // Reserved : 0x0260 ~ 0x0FFF
    OD_H1000_COM_PROFILE          = 0x1000, // Communication Profile Area : 0x1000 ~ 0x1FFF
    OD_H2000_MANUFACTURER         = 0x2000, // Manufacturer-Specific Profile Area : 0x2000 ~ 0x5FFF
    OD_H6000_STD_PROFILE          = 0x6000, // Standardized Profile Area : 0x6000 ~ 0x9FFF
    OD_HA000_NETWORK_VAR          = 0xA000, // Network variable : 0xA000 ~ 0xAFFF
    OD_HB000_SYSTEM_VAR           = 0xB000, // System variable :�@0xB000 ~ 0xBFFF
    OD_HC000_RES                  = 0xC000 // Reserved
};

/**
 * Common DS301 object dictionary entries.
 */
typedef enum{
    OD_H1000_DEV_TYPE             = 0x1000U,/**< Device type */
    OD_H1001_ERR_REG              = 0x1001U,/**< Error register */
    OD_H1002_MANUF_STATUS_REG     = 0x1002U,/**< Manufacturer status register */
    OD_H1003_PREDEF_ERR_FIELD     = 0x1003U,/**< Predefined error field */
    OD_H1004_RSV                  = 0x1004U,/**< Reserved */
    OD_H1005_COBID_SYNC           = 0x1005U,/**< Sync message cob-id */
    OD_H1006_COMM_CYCL_PERIOD     = 0x1006U,/**< Communication cycle period */
    OD_H1007_SYNC_WINDOW_LEN      = 0x1007U,/**< Sync windows length */
    OD_H1008_MANUF_DEV_NAME       = 0x1008U,/**< Manufacturer device name */
    OD_H1009_MANUF_HW_VERSION     = 0x1009U,/**< Manufacturer hardware version */
    OD_H100A_MANUF_SW_VERSION     = 0x100AU,/**< Manufacturer software version */
    OD_H100B_RSV                  = 0x100BU,/**< Reserved */
    OD_H100C_GUARD_TIME           = 0x100CU,/**< Guard time */
    OD_H100D_LIFETIME_FACTOR      = 0x100DU,/**< Life time factor */
    OD_H100E_RSV                  = 0x100EU,/**< Reserved */
    OD_H100F_RSV                  = 0x100FU,/**< Reserved */
    OD_H1010_STORE_PARAM_FUNC     = 0x1010U,/**< Store parameter in persistent memory function */
    OD_H1011_REST_PARAM_FUNC      = 0x1011U,/**< Restore default parameter function */
    OD_H1012_COBID_TIME           = 0x1012U,/**< Timestamp message cob-id */
    OD_H1013_HIGH_RES_TIMESTAMP   = 0x1013U,/**< High resolution timestamp */
    OD_H1014_COBID_EMERGENCY      = 0x1014U,/**< Emergency message cob-id */
    OD_H1015_INHIBIT_TIME_MSG     = 0x1015U,/**< Inhibit time message */
    OD_H1016_CONSUMER_HB_TIME     = 0x1016U,/**< Consumer heartbeat time */
    OD_H1017_PRODUCER_HB_TIME     = 0x1017U,/**< Producer heartbeat time */
    OD_H1018_IDENTITY_OBJECT      = 0x1018U,/**< Identity object */
    OD_H1019_SYNC_CNT_OVERFLOW    = 0x1019U,/**< Sync counter overflow value */
    OD_H1020_VERIFY_CONFIG        = 0x1020U,/**< Verify configuration */
    OD_H1021_STORE_EDS            = 0x1021U,/**< Store EDS */
    OD_H1022_STORE_FORMAT         = 0x1022U,/**< Store format */
    OD_H1023_OS_CMD               = 0x1023U,/**< OS command */
    OD_H1024_OS_CMD_MODE          = 0x1024U,/**< OS command mode */
    OD_H1025_OS_DBG_INTERFACE     = 0x1025U,/**< OS debug interface */
    OD_H1026_OS_PROMPT            = 0x1026U,/**< OS prompt */
    OD_H1027_MODULE_LIST          = 0x1027U,/**< Module list */
    OD_H1028_EMCY_CONSUMER        = 0x1028U,/**< Emergency consumer object */
    OD_H1029_ERR_BEHAVIOR         = 0x1029U,/**< Error behaviour */
    OD_H1200_SDO_SERVER_PARAM     = 0x1200U,/**< SDO server parameters */
    OD_H1280_SDO_CLIENT_PARAM     = 0x1280U,/**< SDO client parameters */
    OD_H1300_GFC_PARAM            = 0x1300U,/**< GFC parameter */
    OD_H1301_SRDO_1_PARAM         = 0x1301U,/**< SRDO communication parameters */
    OD_H1381_SRDO_1_MAPPING       = 0x1381U,/**< SRDO mapping parameters */
    OD_H13FE_SRDO_VALID           = 0x13FEU,/**< SRDO valid flag */
    OD_H13FF_SRDO_CHECKSUM        = 0x13FFU,/**< SRDO checksum */
    OD_H1400_RXPDO_1_PARAM        = 0x1400U,/**< RXPDO communication parameter */
    OD_H1401_RXPDO_2_PARAM        = 0x1401U,/**< RXPDO communication parameter */
    OD_H1402_RXPDO_3_PARAM        = 0x1402U,/**< RXPDO communication parameter */
    OD_H1403_RXPDO_4_PARAM        = 0x1403U,/**< RXPDO communication parameter */
    OD_H1600_RXPDO_1_MAPPING      = 0x1600U,/**< RXPDO mapping parameters */
    OD_H1601_RXPDO_2_MAPPING      = 0x1601U,/**< RXPDO mapping parameters */
    OD_H1602_RXPDO_3_MAPPING      = 0x1602U,/**< RXPDO mapping parameters */
    OD_H1603_RXPDO_4_MAPPING      = 0x1603U,/**< RXPDO mapping parameters */
    OD_H1800_TXPDO_1_PARAM        = 0x1800U,/**< TXPDO communication parameter */
    OD_H1801_TXPDO_2_PARAM        = 0x1801U,/**< TXPDO communication parameter */
    OD_H1802_TXPDO_3_PARAM        = 0x1802U,/**< TXPDO communication parameter */
    OD_H1803_TXPDO_4_PARAM        = 0x1803U,/**< TXPDO communication parameter */
    OD_H1A00_TXPDO_1_MAPPING      = 0x1A00U,/**< TXPDO mapping parameters */
    OD_H1A01_TXPDO_2_MAPPING      = 0x1A01U,/**< TXPDO mapping parameters */
    OD_H1A02_TXPDO_3_MAPPING      = 0x1A02U,/**< TXPDO mapping parameters */
    OD_H1A03_TXPDO_4_MAPPING      = 0x1A03U /**< TXPDO mapping parameters */
}CO_ObjDicId_t;

enum{
    EMCY_OD_BYTE0_ERROR_CODE_L      = 0,
    EMCY_OD_BYTE1_ERROR_CODE_H      = 1,
    EMCY_OD_BYTE2_ERROR_REG         = 2,
    // Byte 3 ~ 7 : Manufacturer-specific error code
    EMCY_OD_BYTE3_RES               = 3,
    EMCY_OD_BYTE4_RES               = 4,
    EMCY_OD_BYTE5_RES               = 5,
    EMCY_OD_BYTE6_ALARM_CODE_M0     = 6,
    EMCY_OD_BYTE7_ALARM_CODE_M1     = 7,
    EMCY_OD_BYTE_NUM                = 8
};

enum{
    SDO_STATE_IDLE = 0,
    SDO_STATE_UPLOADING,
    SDO_STATE_DOWNLOADING,
    SDO_STATE_ABORT,
    SDO_STATE_NUM
};


enum{
    SDO_BYTE0_CS = 0,           // CS = Command Specifier
    SDO_BYTE1 = 1,
    SDO_BYTE1_INDEX_L = 1,
    SDO_BYTE2_INDEX_H = 2,
    SDO_BYTE3_SUBINDEX = 3,
    SDO_BYTE4_DATA0 = 4,
    SDO_BYTE5_DATA1 = 5,
    SDO_BYTE6_DATA2 = 6,
    SDO_BYTE7_DATA3 = 7,
    SDO_BYTE_NUM = 8

};

enum{
    CCS_DOWNLOAD_SEGMENT = 0,           // 0 = DownLoad Segment
    CCS_INITIATE_DOWNLOAD = 1,          // 1 = Initiate DownLoad
    CCS_INITIATE_UPLOAD = 2,            // 2 = Initiate UpLoad
    CCS_UPLOAD_SEGMENT = 3,             // 3 = UpLoad Segment
    CCS_ABORT = 4,                      // 4 = Abort SDO Transfer
    CCS_NUM = 5
};


enum{
    SCS_UPLOAD_SEGMENT = 0,
    SCS_DOWNLOAD_SEGMENT = 1,
    SCS_INITIATE_UPLOAD = 2,
    SCS_INITIATE_DOWNLOAD = 3,
    SCS_ABORT = 4,                      // 4 = Abort SDO Transfer
    SCS_NUM = 5
};

enum{
    CCS_BIT0_S      = 0,
    CCS_BIT1_E      = 1,
    CCS_BIT23_N     = 2,
    //
    CCS_BIT4_T      = 4,
    CCS_BIT567_CCS  = 5,
    CCS_BIT_NUM     = 8
};

enum{
    //
    SCS_BIT0_S       = 0,
    SCS_BIT1_E       = 1,
    SCS_BIT23_N      = 2,
    //
    SCS_BIT0_SEG_C   = 0,
    SCS_BIT123_SEG_N = 1,
    //
    SCS_BIT4_T   = 4,
    SCS_BIT567_SCS = 5,
    SCS_BIT_NUM  = 8
};

/**
 * SDO abort codes.
 *
 * Send with Abort SDO transfer message.
 *
 * The abort codes not listed here are reserved.
 */
typedef enum{
    SDO_AB_NONE                  = 0x00000000UL, /**< 0x00000000, No abort */
    SDO_AB_TOGGLE_BIT            = 0x05030000UL, /**< 0x05030000, Toggle bit not altered */
    SDO_AB_TIMEOUT               = 0x05040000UL, /**< 0x05040000, SDO protocol timed out */
    SDO_AB_CMD                   = 0x05040001UL, /**< 0x05040001, Command specifier not valid or unknown */
    SDO_AB_BLOCK_SIZE            = 0x05040002UL, /**< 0x05040002, Invalid block size in block mode */
    SDO_AB_SEQ_NUM               = 0x05040003UL, /**< 0x05040003, Invalid sequence number in block mode */
    SDO_AB_CRC                   = 0x05040004UL, /**< 0x05040004, CRC error (block mode only) */
    SDO_AB_OUT_OF_MEM            = 0x05040005UL, /**< 0x05040005, Out of memory */
    SDO_AB_UNSUPPORTED_ACCESS    = 0x06010000UL, /**< 0x06010000, Unsupported access to an object */
    SDO_AB_WRITEONLY             = 0x06010001UL, /**< 0x06010001, Attempt to read a write only object */
    SDO_AB_READONLY              = 0x06010002UL, /**< 0x06010002, Attempt to write a read only object */
    SDO_AB_NOT_EXIST             = 0x06020000UL, /**< 0x06020000, Object does not exist in the object dictionary */
    SDO_AB_NO_MAP                = 0x06040041UL, /**< 0x06040041, Object cannot be mapped to the PDO */
    SDO_AB_MAP_LEN               = 0x06040042UL, /**< 0x06040042, Number and length of object to be mapped exceeds PDO length */
    SDO_AB_PRAM_INCOMPAT         = 0x06040043UL, /**< 0x06040043, General parameter incompatibility reasons */
    SDO_AB_DEVICE_INCOMPAT       = 0x06040047UL, /**< 0x06040047, General internal incompatibility in device */
    SDO_AB_HW                    = 0x06060000UL, /**< 0x06060000, Access failed due to hardware error */
    SDO_AB_TYPE_MISMATCH         = 0x06070010UL, /**< 0x06070010, Data type does not match, length of service parameter does not match */
    SDO_AB_DATA_LONG             = 0x06070012UL, /**< 0x06070012, Data type does not match, length of service parameter too high */
    SDO_AB_DATA_SHORT            = 0x06070013UL, /**< 0x06070013, Data type does not match, length of service parameter too short */
    SDO_AB_SUB_UNKNOWN           = 0x06090011UL, /**< 0x06090011, Sub index does not exist */
    SDO_AB_INVALID_VALUE         = 0x06090030UL, /**< 0x06090030, Invalid value for parameter (download only). */
    SDO_AB_VALUE_HIGH            = 0x06090031UL, /**< 0x06090031, Value range of parameter written too high */
    SDO_AB_VALUE_LOW             = 0x06090032UL, /**< 0x06090032, Value range of parameter written too low */
    SDO_AB_MAX_LESS_MIN          = 0x06090036UL, /**< 0x06090036, Maximum value is less than minimum value. */
    SDO_AB_NO_RESOURCE           = 0x060A0023UL, /**< 0x060A0023, Resource not available: SDO connection */
    SDO_AB_GENERAL               = 0x08000000UL, /**< 0x08000000, General error */
    SDO_AB_DATA_TRANSF           = 0x08000020UL, /**< 0x08000020, Data cannot be transferred or stored to application */
    SDO_AB_DATA_LOC_CTRL         = 0x08000021UL, /**< 0x08000021, Data cannot be transferred or stored to application because of local control */
    SDO_AB_DATA_DEV_STATE        = 0x08000022UL, /**< 0x08000022, Data cannot be transferred or stored to application because of present device state */
    SDO_AB_DATA_OD               = 0x08000023UL, /**< 0x08000023, Object dictionary not present or dynamic generation fails */
    SDO_AB_NO_DATA               = 0x08000024UL  /**< 0x08000024, No data available */
}CO_SDO_abortCode_t;


#define CO_PDO_NUMBER_OF_ENTRIES        6
#define CO_PDO_INHIBIT_TIME_INIT        10
#define CO_PDO_EVENT_TIME_INIT          10

enum{

    CO_PDO_TRANS_TYPE_00_SYN_ACYCLIC            = 0x00,   // Synchronous transmission ( acyclic )
    CO_PDO_TRANS_TYPE_01_SYN_CYCLIC             = 0x01,   // Synchronous transmission ( cyclic )

    CO_PDO_TRANS_TYPE_FC_RTR_SYN                = 0xFC,   // Remote Requested ( Synchronous )
    CO_PDO_TRANS_TYPE_FD_RTR_ASYN               = 0xFD,   // Remote Requested ( Asynchronous )

    CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER      = 0xFE,   // Asynchronous
    CO_PDO_TRANS_TYPE_FE_ASYN_DEVICE_PROFILE    = 0xFF    // Asynchronous

};


enum{
    CO_ERR_0_SDO_R_INDEX                 = 0,
    CO_ERR_0_SDO_R_INDEX_H               = 1,
    CO_ERR_0_SDO_R_INDEX_L               = 2,
    CO_ERR_0_SDO_R_SUBINDEX              = 3,

    CO_ERR_NUM = 1
};

typedef struct {
    /** The index of Object from 0x1000 to 0xFFFF */
    uint16_t            index;
    /** Number of (sub-objects - 1). If Object Type is variable, then
    maxSubIndex is 0, otherwise maxSubIndex is equal or greater than 1. */
    uint8_t             maxSubIndex;
    /** If Object Type is record, attribute is set to zero. Attribute for
    each member is then set in special array with members of type
    CO_OD_entryRecord_t. If Object Type is Array, attribute is common for
    all array members. See #CO_SDO_OD_attributes_t. */
    uint16_t            attribute;
    /** If Object Type is Variable, length is the length of variable in bytes.
    If Object Type is Array, length is the length of one array member.
    If Object Type is Record, length is zero. Length for each member is
    set in special array with members of type CO_OD_entryRecord_t.
    If Object Type is Domain, length is zero. Length is specified
    by application in @ref CO_SDO_OD_function. */
    uint16_t            length;
    /** If Object Type is Variable, pData is pointer to data.
    If Object Type is Array, pData is pointer to data. Data doesn't
    include Sub-Object 0.
    If object type is Record, pData is pointer to special array
    with members of type CO_OD_entryRecord_t.
    If object type is Domain, pData is null. */
    void               *pData;
}CO_OD_entry_t;


typedef struct{
    uint16_t    Index;
    uint8_t     SubIndex;

    uint32_t    SubIndex_Max;
    uint8_t     Type;
    uint8_t     DataSize;
    uint8_t     ReadWrite;
    uint16_t    Length;

    void        *pData;
    //
    uint32_t     Data_Max;
    uint32_t     Data_Min;

}Struct_CO_Object;

enum{
    CO_OBJECT_SIZE_UINT8_T      = 0,
    CO_OBJECT_SIZE_CHAR         = 1,
    CO_OBJECT_SIZE_UINT16_T     = 2,
    CO_OBJECT_SIZE_UINT32_T     = 3,
    CO_OBJECT_SIZE_UNKNOWN      = 4,
    CO_OBJECT_SIZE_NUM          = 5
};

enum{
    CO_OBJECT_TYPE_GENERAL      = 0,
    CO_OBJECT_TYPE_EEP          = 1,
    CO_OBJECT_TYPE_CMD          = 2,
    CO_OBJECT_TYPE_PDE          = 3,

    //
    CO_OBJECT_TYPE_UNKNOWN      = 4,
    CO_OBJECT_TYPE_NUM          = 5
};

enum{
    CO_RW_UNKNOWN               = 0,
    CO_RW_READ_WEITE            = 1,
    CO_RW_READ_ONLY             = 2,
    CO_RW_WRITE_ONLY            = 3,
    CO_RW_PROTECT               = 4, // Protect: Read Only when Master Level < 3; Read Write when Master Level = 3
    CO_RW_NUM                   = 5
};

enum{
    CO_SDO_ACTION_IDLE          = 0,
    CO_SDO_ACTION_CMD           = 1,
    CO_SDO_ACTION_EEP           = 2,
    CO_SDO_ACTION_CLEAR_PDE     = 3,

    CO_SDO_ACTION_NUM
};


typedef struct{

    uint8_t     NumberOfEntries;    /**< Equal to 6 */
    /** Communication object identifier for transmitting message. Meaning of the specific bits:
    - Bit  0-10: COB-ID for PDO, to change it bit 31 must be set.
    - Bit 11-29: set to 0 for 11 bit COB-ID.
    - Bit 30:    If true, rtr are NOT allowed for PDO.
    - Bit 31:    If true, node does NOT use the PDO. */
    uint32_t    COB_ID;
    /** Transmission type. Values:
    - 0:       Transmiting is synchronous, specification in device profile.
    - 1-240:   Transmiting is synchronous after every N-th SYNC object.
    - 241-251: Not used.
    - 252-253: Transmited only on reception of Remote Transmission Request.
    - 254:     Manufacturer specific.
    - 255:     Asinchronous, specification in device profile. */
    uint8_t     TransmissionType;
    /** Minimum time between transmissions of the PDO in 100micro seconds.
    Zero disables functionality. */
    uint16_t    InhibitTime_100us;
    /** Not used */
    uint8_t     Reserved_04;
    /** Time between periodic transmissions of the PDO in milliseconds.
    Zero disables functionality. */
    uint16_t    EventTime_1ms;
    /** Used with numbered SYNC messages. Values:
    - 0:       Counter of the SYNC message shall not be processed.
    - 1-240:   The SYNC message with the counter value equal to this value
               shall be regarded as the first received SYNC message. */
    uint8_t     SYNC_StartValue;

}Struct_CO_PDO_PA;

#define PDO_MAPPING_OBJECT_NUM_MAX      8

typedef struct{
    /** Actual number of mapped objects from 0 to 8. To change mapped object,
    this value must be 0. */
    uint8_t     IsUsePtrFlag;    // Yes or No, Yes : find data in Ptr; No : find data in Object
    uint8_t     MappingObject_Num;
    uint32_t    MappingObjec[ PDO_MAPPING_OBJECT_NUM_MAX ];
    uint32_t    *MappingPtr[ PDO_MAPPING_OBJECT_NUM_MAX ];

}Struct_CO_PDO_Mapping;


typedef struct{
    uint8_t                     IsGood_Flag;
    uint8_t                     ToUpdate_Flag;
    uint8_t                     ToTransmit_Flag;
    uint8_t                     ToWait4SYNC_Flag;

    Struct_CO_PDO_PA            Parameter;
    Struct_CO_PDO_Mapping       Mapping;
    uint16_t                    Data[ CAN_OPEN_DATA_NUM ];
    uint8_t                     Byte_Cnt;
    uint8_t                     DLC;
    //
    uint16_t                    EventTimer_1ms;
    uint16_t                    InhibitTimer_100us;
    uint16_t                    SYNC_Cnt;

    //
    uint32_t                    Trig_MailBox_ID;

    //
    uint32_t                    Test_Cnt;

}Struct_CO_PDO;

#define CO_PDE_ARRAY_SIZE          32


enum{   //StoreParameter
    CO_SP_BYTE0_NUMBER_OF_ENTRIES           = 0,
    CO_SP_BYTE1_SAVE_ALL_PARAMETER          = 1,
    CO_SP_BYTE2_SAVE_COMM_PARAMETER         = 2,
    CO_SP_BYTE3_SAVE_APP_PARAMETER          = 3,
    CO_SP_BYTE4_SAVE_MANU_PARAMETER         = 4,
    CO_SP_BYTE_NUM                          = 5
};

enum{   //ResetParameter
    CO_RP_BYTE0_NUMBER_OF_ENTRIES           = 0,
    CO_RP_BYTE1_RESET_ALL_PARAMETER         = 1,
    CO_RP_BYTE2_RESET_COMM_PARAMETER        = 2,
    CO_RP_BYTE3_RESET_APP_PARAMETER         = 3,
    CO_RP_BYTE4_RESET_MANU_PARAMETER        = 4,
    CO_RP_BYTE_NUM                          = 5
};

typedef struct{
    uint32_t DeviceType;
    uint32_t ErrorRegister;
    uint32_t ManufacturerStatusRegister;

    //
    uint32_t  PDE_Num;  // Pre-Defined Error
    uint32_t  PDE[ CO_PDE_ARRAY_SIZE ];
    //

    uint32_t  COBID_SYNC;
    uint32_t  CommunicationCyclePeriod;
    uint32_t  SyncWindowsLength;
    uint8_t*  ManufacturerDeviceName;

    uint8_t   ManufacturerHardwareVersion[ 2 ];

    uint8_t*  ManufacturerSoftwareVersion;


    uint16_t  GuardTime;
    uint8_t   LifrTimeFactor;

    uint32_t  StoreParameter[ CO_SP_BYTE_NUM ];
    uint32_t  RestoreDefaultParameters[ CO_RP_BYTE_NUM ];

    uint32_t  COBID_TimeStamp;
    uint32_t  HighResolutionTimeStamp;

    uint32_t  COBID_EMCY;

    uint32_t  InhibitTimeEMCY;
    uint32_t  ComsumerHeartbeatTime;
    uint16_t  ProducerHeartbeatTime;

    uint32_t  Identity_Object;

}Struct_CO_GCO;// GCO = General communication object

typedef struct{

    uint16_t Code;
    uint8_t Transmit_Flag;
    uint16_t Data[ CAN_OPEN_DATA_NUM ];

    //
    uint8_t Alarm_Old_M0;
    uint8_t Alarm_Old_M1;

}Struct_CO_EMCY;


typedef struct{

	uint8_t  Mode;
	uint8_t  Id_Mode;
	uint32_t NodeID;
	int16_t  NMT_State;
	int16_t  NMT_State_Old;
	int16_t  NMT_State_Init;

	//
	uint32_t MailBox_BITF;

	//
	uint8_t  Is_Reset_COM;
	uint8_t  Is_Init_Flag;
	uint8_t  TimeUp_1ms_Flag;

	//
	uint16_t HB_ID; // HeartBeat ID
	int32_t  HB_Period_Ms;
	int32_t  HB_Timer_Ms;

	//
	uint8_t  SYNC_Flag;
	uint16_t SYNC_Cnt;
	//

	uint16_t EMCY_State;
	Struct_CO_EMCY  EMCY;

	//
	Struct_CO_GCO   GCO;

	uint32_t SDO_S2C_ID;
	uint32_t SDO_C2S_ID;

	uint32_t TPDO1_ID;
	uint32_t TPDO2_ID;
	uint32_t TPDO3_ID;
	uint32_t TPDO4_ID;

	uint32_t RPDO1_ID;
    uint32_t RPDO2_ID;
    uint32_t RPDO3_ID;
    uint32_t RPDO4_ID;

    uint32_t Emergency_ID;
    uint32_t HeardBeat_ID;

    uint16_t R_Data[ CAN_OPEN_DATA_NUM ];
    uint16_t T_Data[ CAN_OPEN_DATA_NUM ];

    uint16_t DLC;

    //

    Struct_CO_PDO TPDO1;
    Struct_CO_PDO TPDO2;
    Struct_CO_PDO TPDO3;
    Struct_CO_PDO TPDO4;

    Struct_CO_PDO RPDO1;
    Struct_CO_PDO RPDO2;
    Struct_CO_PDO RPDO3;
    Struct_CO_PDO RPDO4;

    //

    int32_t  Access_Level;
    uint8_t  SDO_WriteEEP_Busy_Flag;
    uint8_t  SDO_RealTime_Req_Flag;

    uint8_t  SDO_State;
    uint8_t  SDO_CCS;   // Client Command Specified
    uint8_t  SDO_SCS;   // Server Command Specified
    uint16_t SDO_Index;
    uint8_t  SDO_SubIndex;
    uint32_t SDO_AbortCode;
    uint8_t  SDO_Toggle;

    uint16_t SDO_Segment_Counter;

    Struct_CO_Object Current_OBject;
    int32_t SDO_OBject_Null;
    uint32_t SDO_Action;
    uint32_t SDO_CMD;

    uint16_t Pa_Major;
    uint16_t Pa_Minor;
    uint32_t Pa_Value;

    //
    uint8_t  NewFrame_Flag;

    uint32_t Error_Code;

    //uint32_t Test_Cnt;

}Struct_CANOpen;



#endif /* C2000_CAN_H_ */


 /************************** <END OF FILE> *****************************************/



