/*===========================================================================================
    File Name       : COM_Protocol_01.c
    Built Date      : 2012-12-16
	Version         : V1.03a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file provides the functions of the protocol of communications.
					  Including parameter settings and command.

	Module required:  - UART: For Data transmit.
					  - ModBus_Slave_ASCII: For communication data access.
					  - Parameter: For parameter access.
					  - HWEEP_Setting: For HWEEP write access.
						
    =========================================================================================
    History         : 2012-12-03 Perlimary version.  ( by Gear )
					  2012-12-04 FC6 function routine added ( command not supported yet. )
					  2012-12-28 execute updatespecialpa in 1ms routine if the flag is set.
					  2013-02-01 v1.00r (R8)
						- FC16 protocol added. Can only execute when real time updated is allowed. ( Motor not running )
					  2013-12-16 v1.01r (R8)
						- Parameter Reset and I/O Reset command inplmenting.
						- com_EEP_to_RAM_Routine cross major bug fixed.
					  2014-07-30 v1.02a(R8): In Rev... 
					  2014-09-04 com_Protocol_routine() added eep save result return.
					  2014-09-26 com alm number check bug fix.
					  2014-12-03 Added COM_HWEEP_SAVE_ALLOWED_BIT to the bitfield for HWEEP write.
								 com_HWEEP_Write_allowed_check() added to is_FC16_ok(). Need consider Master level in the future.
								 HWEEP write routine and check added to com_Protocol_routine().
					  2014-12-23 COM_PA_LIMIT_CHECK_REQ_BIT flag for paramter limit check added.
						- FC6, FC16 and CMD.
					  2014-12-25 UartXn update bug fixed.
					  2015-11-12 V1.03a. Implement multi-driver ctrl.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"
#include "MultiDriveCMD.h"

volatile Struct_ComProtocol_01 CG_ComProtocol_01;

/************************** EXTERNAL VARIABLES ********************************/
extern volatile Struct_Parameter			CG_Parameter;
//extern volatile Struct_Modbus_Slave 		CG_Modbus_Slave;
extern volatile Struct_UART  				CG_UART;
/* Gear Test */
extern volatile Struct_MD 					CG_MD;								// Main.c global variable data structure. for test
//extern volatile Struct_BLDC_CTRL 			CG_BLDC_CTRL;
extern volatile Struct_BLDC_CTRL            CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL            CG_BLDC_CTRL_M1;

extern volatile Struct_Move 				CG_Move;
extern volatile Struct_Encoder 				CG_Encoder;
extern volatile Struct_Pretect              CG_Protect;

/*===========================================================================================
    Function Name    : variableInitial_COM_Protocol
    Input            : 1. *alm_history: ALM history array pointer.
					   2. *wng_history: WNG history array pointer.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Variable CG_ComProtocol_01 initial
//==========================================================================================*/
void variableInitial_COM_Protocol ( int32_t *alm_history, int32_t *wng_history )
{	
	int8_t i;
	for( i = 0; i < COM_HIST_ARRAY_SIZE; i++ ){
		CG_ComProtocol_01.ERROR_His_RAM[i] = 0;
	}
	CG_ComProtocol_01.FlagBITF = 0;

	CG_ComProtocol_01.Alm_His_ptr  = alm_history;
	CG_ComProtocol_01.Wng_His_ptr  = wng_history;
	// Parameter limit check flag set
	CG_ComProtocol_01.FlagBITF |= _BIT( COM_PA_LIMIT_CHECK_REQ_BIT );
	CG_ComProtocol_01.COM_IO_Xn_BITF = 0;
	CG_ComProtocol_01.COM_IO_NormState_BITF = 0;
	CG_ComProtocol_01.COM_IO_Yn_BITF[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = 0;
	//CG_ComProtocol_01.COM_IO_Yn_BITF[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = 0;

	CG_ComProtocol_01.MasterLevel = MASTER_LEVEL_0;
	CG_ComProtocol_01.Command = 0;

}

/*===========================================================================================
    Function Name    : com_Protocol_routine
    Input            : 1. *str_modbus : modbus golobal data struct.
					   2. *di_xn_BITF: Ext Xn bit field to update (UART Xn)
					   3. CMD_RUN: command of motor run operation.
					   4. *R_data: Data for one byte HWEEP.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : com protocol main routine.
					   Ext Xn update. (UART Xn)
//==========================================================================================*/
uint8_t com_Protocol_routine ( Struct_Modbus_Slave *str_modbus, uint32_t *di_xn_BITF, 
							   const uint8_t CMD_RUN, uint8_t *R_data )
{
	uint8_t result = 1;
	uint8_t Cmd_result = 0;
	int16_t data_offset;
	int16_t data_num;
	
	// If Modbus Function execute required.
	if ( (str_modbus->FlagBITF & (1 << MB_FC_EXECUTE_REQ_BIT)) != 0 ) {
		
		// Reset state and flags
		CG_ComProtocol_01.Error = 0;                                            // Reset CG_ComProtocol_01.Error
		CG_ComProtocol_01.FlagBITF &= ~(1UL << COM_PA_EEP_SAVE_ALLOWED_BIT);	// Clear EEP save allowed.
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_CMD_TYPE_BIT );                // Clear CMD type detemine flag.
		CG_ComProtocol_01.FlagBITF &= ~(1UL << COM_HWEEP_SAVE_ALLOWED_BIT);     // Clear HWEEP save allowed.
		if ( CMD_RUN == LOW ) {
			CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_ALM_RESET_FORBID_BIT );
		} else {
			CG_ComProtocol_01.FlagBITF |= _BIT( COM_ALM_RESET_FORBID_BIT );
		}				
		
		str_modbus->ExceptionCode = mB_Execute_routine( (Struct_Modbus_Slave*)str_modbus );

		// CMD execute routine
		Cmd_result = com_CMD_execute_routine();
		if (Cmd_result == 2) {
			result = 0;
		}
		
		// parameter update routine
		if ( (CG_ComProtocol_01.FlagBITF & (1UL << COM_PA_EEP_SAVE_ALLOWED_BIT)) != 0 ) {
			
			if ( str_modbus->req_pdu_data_quantity == 1 ) {
				result &= saveEEPParameter_Single( str_modbus->req_pdu_address_h - 1,
												   str_modbus->req_pdu_address_l,
												   str_modbus->req_pdu_data[0],
												   ((CG_ComProtocol_01.FlagBITF>>COM_PA_CHANGE_REALTIME_REQ_BIT)&0x01));
			} else {
				result &= saveEEPParameter_Multiple( str_modbus->req_pdu_address_h - 1,
													 str_modbus->req_pdu_address_l,
													 str_modbus->req_pdu_data_quantity,
													 (int32_t*)str_modbus->req_pdu_data,
													 PA_EEP_WR_AND_CHECK);
			}
			
			CG_ComProtocol_01.FlagBITF &= ~(1UL << COM_PA_EEP_SAVE_ALLOWED_BIT);
			
		}
		
		// HW eep update routine
		if ( (CG_ComProtocol_01.FlagBITF & (1UL << COM_HWEEP_SAVE_ALLOWED_BIT)) != 0 ) {
			
			if( str_modbus->modbus_mode == MB_SLV_ASCII ){
				data_offset = 15;
				data_num = str_modbus->req_pdu_data_quantity;
			}else{
				data_offset = 7;
				data_num = str_modbus->req_pdu_data_quantity / 2;
			}


			if( str_modbus->req_pdu_address_h == COM_DRIVER_VER_INDEX ){		// 99
				
				//result &= writeHWEEP_PN( (uint8_t*)&R_data[15], str_modbus->req_pdu_data_quantity );

				result &= writeHWEEP_PN( (uint8_t*)&R_data[data_offset], data_num );
				
			} else if ( str_modbus->req_pdu_address_h == COM_CODE_VER_INDEX ) {	//128
	
				result &= writeHWEEP_CV( str_modbus->req_pdu_data[ 0 ], str_modbus->req_pdu_address_l );

			} else if ( str_modbus->req_pdu_address_h == COM_HW_SN_0_INDEX ) {	//130
				
				//result &= writeHWEEP_SN( (uint8_t*)&R_data[15], str_modbus->req_pdu_data_quantity );
				result &= writeHWEEP_SN( (uint8_t*)&R_data[data_offset], data_num );
				
			} else if ( str_modbus->req_pdu_address_h == COM_HW_INFO_INDEX2 ) {	//131
				
				result &= writeHWEEP_Info( (int32_t*)str_modbus->req_pdu_data, str_modbus->req_pdu_address_l, str_modbus->req_pdu_data_quantity );

			} else if( str_modbus->req_pdu_address_h == COM_HW_VER_INDEX ){ // 97

				result &= writeHW_Ver ( (int32_t*)str_modbus->req_pdu_data, str_modbus->req_pdu_address_l, str_modbus->req_pdu_data_quantity );

			}
				
			CG_ComProtocol_01.FlagBITF &= ~(1UL << COM_HWEEP_SAVE_ALLOWED_BIT);
		}
		
		str_modbus->FlagBITF &= ~(1 << MB_FC_EXECUTE_REQ_BIT);
	}
	
	com_TimeOut_Alm_handler( str_modbus->time_out_flag );
	
	// UART xn uptdate
	//*di_xn_BITF = CG_ComProtocol_01.COM_IO_Xn_BITF;
	*di_xn_BITF = CG_ComProtocol_01.COM_IO_Xn_BITF ^ CG_ComProtocol_01.COM_IO_NormState_BITF;
	
	return (result);
}

/*===========================================================================================
    Function Name    : mB_Execute_routine
    Input            : 1. req_pdu_function_code: ModBus FC to determine the routine to run.
					   2. req_pdu_address_h: data address high byte of modbus.
					   3. req_pdu_address_l: data address low byte of modbus.
					   4. req_pdu_data_quantity: data number
					   5. Response_data: Response data to fill for one byte data.
    Return           : exception code of modbus
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : MB execute routine in broadcast or unicast state.
//==========================================================================================*/
uint8_t mB_Execute_routine ( Struct_Modbus_Slave *str_modbus )
{
    int i;
	int32_t *RegisterPtr;
	uint8_t return_value = 0;
	uint8_t data_offset = 1;
	
	switch ( str_modbus->req_pdu_function_code ) {
		// Read
		case MB_FC3:
			// If read data was one byte data, refill the response data as one byte format.
			if ( (str_modbus->req_pdu_address_h == COM_DRIVER_VER_INDEX) || 
				 (str_modbus->req_pdu_address_h == COM_HW_SN_0_INDEX ) ||
				 (str_modbus->req_pdu_address_h == COM_FW_VER_INDEX) ){
				
				if( str_modbus->modbus_mode == MB_SLV_ASCII ){
					data_offset = DATA_OFFSET_ASCII;
				}			 
					 
				RegisterPtr = (str_modbus->HoldingRegister_ptr[str_modbus->req_pdu_address_h] + str_modbus->req_pdu_address_l);
				for ( i=0; i<str_modbus->req_pdu_data_quantity; i++ ) {
					data_fill_in_Converter( (unsigned char*)( RegisterPtr ),
					//data_fill_in_Converter( (unsigned char*)( RegisterPtr[ i ] ),
											(unsigned char*)( &str_modbus->Response_data[ data_offset+i*4] ),
											4,
											Data_Type_One_Byte);
					*( RegisterPtr += 2);
				}
					 
			}
			
			break;
			
		// Write single
		case MB_FC6:
			
			if ( is_FC6_ok( (Struct_Modbus_Slave*)str_modbus ) == 1) {
				// If NOT command data, update the holding register.
				if ( (CG_ComProtocol_01.FlagBITF & _BIT(COM_CMD_TYPE_BIT)) == 0 ) {
					str_modbus->FlagBITF |= (1 << MB_REG_UPDATE_REQ_BIT);
				}
			} else {
				return_value = SLAVE_DEVICE_FAILURE;
			}
			
			break;
			
		// Write multiple
		case MB_FC16:
				
			if ( is_FC16_ok( (Struct_Modbus_Slave*)str_modbus ) == 1) {
				str_modbus->FlagBITF |= (1 << MB_REG_UPDATE_REQ_BIT);	
			} else {
				return_value = SLAVE_DEVICE_FAILURE;
			}
		
			break;
#ifdef MULTI_DRIVE_LITE
		case MB_FC65:
			return_value = com_FC65_Execute ( str_modbus );
			break;
#endif
		// Multi-driver ctrl request
		case MB_FC101:
			return_value = com_FC101_Execute ( str_modbus );


		// inValid function code
		default:
			break;
	}
	
	return ( return_value );
}

/*===========================================================================================
    Function Name    : is_FC6_ok
    Input            : 1. *str_modbus : modbus golobal data struct.					   
    Return           : return_value: 0=Function failed executed, 1=Function executed fine.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Determine the action of FC6 depends on the address_h.
//==========================================================================================*/
uint8_t is_FC6_ok ( Struct_Modbus_Slave *str_modbus )
{
	uint8_t return_value = 1;
	
	//CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_CMD_TYPE_BIT );
	
	// Determine the action depends on the address_h
	if ( str_modbus->req_pdu_address_h == COM_COMMAND_INDEX ) {

		// Common command flag setup
		return_value = command_flag_setup ( (Struct_Modbus_Slave*)str_modbus );		
		CG_ComProtocol_01.FlagBITF |= _BIT( COM_CMD_TYPE_BIT );
	
	} else if ( str_modbus->req_pdu_address_h == COM_UART_XIN_INDEX ) {

		// UART Xn
		return_value = 1;
		
	} else if ( str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_CMD_M0 ||
	            str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_CMD_M1 ) {

        // MultiDrive CMD
        if( str_modbus->req_pdu_address_l < MULTI_DRIVE_NUM ){
            return_value = 1;
        }else{
            return_value = 0;
            CG_ComProtocol_01.Error = COM_ERROR_OUT_RANGE;
        }

	} else if ( str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_LITE_CMD_M0 ||
	            str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_LITE_CMD_M1 ) {

        // MultiDrive-Lite CMD
	    if( str_modbus->req_pdu_address_l < MULTI_DRIVE_LITE_NUM ){
            return_value = 1;
        }else{
            return_value = 0;
            CG_ComProtocol_01.Error = COM_ERROR_OUT_RANGE;
        }

	} else if ( str_modbus->req_pdu_address_h == COM_UART_YOUT_INDEX ) {
		
		// NoteToGear : EXT Yn should be read only.
		return_value = 0;		
		CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;	// UART_YOUT should be read only.
		
	} else if ( (str_modbus->req_pdu_address_h >= COM_PA_EEP_INDEX) && (str_modbus->req_pdu_address_h < COM_PA_RAM_INDEX+9) ) {	// Parameter type data access
	
		// Parameter modify flag set
		return_value = pa_change_allowed_check ( str_modbus->req_pdu_address_h,
											     str_modbus->req_pdu_address_l,
											     str_modbus->req_pdu_data[0],
											     CG_ComProtocol_01.MasterLevel );
		
		// Parameter limit check flag set
		CG_ComProtocol_01.FlagBITF |= _BIT( COM_PA_LIMIT_CHECK_REQ_BIT );
		
	} else if ( str_modbus->req_pdu_address_h == COM_MASTER_LV_INDEX ) {
		
		// Master level password check and setup
		if ( str_modbus->req_pdu_address_l == MASTER_LEVEL_PASSWROD ) {
			CG_ComProtocol_01.MasterLevel = str_modbus->req_pdu_data[0];
			return_value = 1;
		} else {
			return_value = 0;
			CG_ComProtocol_01.Error =  COM_ERROR_OUT_RANGE;
		}
		CG_ComProtocol_01.FlagBITF |= _BIT( COM_CMD_TYPE_BIT );
		
	} else {
		
		// command not support
		return_value = 0;
	    CG_ComProtocol_01.Error =  COM_ERROR_OUT_RANGE;
		
	}		
	
	return (return_value);
}

/*===========================================================================================
    Function Name    : is_FC16_ok
    Input            : 1. *str_modbus : modbus golobal data struct.	
    Return           : return_value: 0=Function failed executed, 1=Function executed fine.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Determine the action of FC16 depends on the address_h.
//==========================================================================================*/
uint8_t is_FC16_ok ( Struct_Modbus_Slave *str_modbus )
{
	uint8_t return_value = 0;	
	// Action type determine
	if ( (str_modbus->req_pdu_address_h >= COM_PA_EEP_INDEX) && (str_modbus->req_pdu_address_h < COM_PA_RAM_INDEX+9) ) {
	
		// FC16 only support Pa  ( and RO_EEP in Eginner mode )
		if ( (str_modbus->req_pdu_address_h != COM_COMMAND_INDEX) &&
             (str_modbus->req_pdu_address_h != COM_UART_XIN_INDEX) &&
			 (str_modbus->req_pdu_address_h != COM_UART_YOUT_INDEX)
		) {

			return_value = pa_multi_change_allowed_check ( str_modbus->req_pdu_address_h,
														   str_modbus->req_pdu_address_l, 
														   (int32_t*)str_modbus->req_pdu_data,
														   str_modbus->req_pdu_data_quantity,
														   CG_ComProtocol_01.MasterLevel );
		}
		
		// Parameter limit check flag set
		CG_ComProtocol_01.FlagBITF |= _BIT( COM_PA_LIMIT_CHECK_REQ_BIT );

	}else if( str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_CMD_M0 ||
	          str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_CMD_M1 ){

	    if( str_modbus->req_pdu_address_l + str_modbus->req_pdu_data_quantity <= MULTI_DRIVE_NUM ){
	        return_value = 1;
	    }else{
	        return_value = 0;
	        CG_ComProtocol_01.Error = COM_ERROR_OUT_RANGE;
	    }

	}else if( str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_LITE_CMD_M0 ||
              str_modbus->req_pdu_address_h == COM_MULTI_DRIVE_LITE_CMD_M1 ){

        if( str_modbus->req_pdu_address_l + str_modbus->req_pdu_data_quantity <= MULTI_DRIVE_LITE_NUM ){
            return_value = 1;
        }else{
            return_value = 0;
            CG_ComProtocol_01.Error = COM_ERROR_OUT_RANGE;
        }
	
	} else if (	str_modbus->req_pdu_address_h == COM_HW_INFO_INDEX2 ||
				str_modbus->req_pdu_address_h == COM_DRIVER_VER_INDEX ||
				str_modbus->req_pdu_address_h == COM_CODE_VER_INDEX ||
				str_modbus->req_pdu_address_h == COM_HW_SN_0_INDEX ||
				str_modbus->req_pdu_address_h == COM_HW_VER_INDEX ){
		
		// FC16 for HWEEP write check
		return_value = com_HWEEP_Write_allowed_check( CG_ComProtocol_01.MasterLevel );
	}
	
	return (return_value);
}

/*===========================================================================================
    Function Name    : command_flag_setup
    Input            : 1. *str_modbus : modbus golobal data struct.
    Return           : return_value: 0=Function failed executed, 1=Function executed fine.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the related command flags.
//==========================================================================================*/
uint8_t command_flag_setup ( Struct_Modbus_Slave *str_modbus )
{
	int32_t return_value = 0;
	uint32_t set_bit	 = str_modbus->req_pdu_data[0];
	
	// Command type determine
	switch ( str_modbus->req_pdu_address_l ) {

		// Fault reset command
		case COM_CMD_ALARM_RESET:
			if ( (( CG_ComProtocol_01.FlagBITF & CMD_ALM_RESET_FORBID ) != 0) ||
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value = 0;
			} else {
				//CG_ComProtocol_01.FlagBITF |= (1UL << COM_ALM_RESET_REQ_BIT);
			    CG_Protect.Motor_0.ToReset = YES;
			    //CG_Protect.Motor_1.ToReset = YES;

				return_value = 1;	
			}
			break;

        // Config mode selection
		case COM_CMD_CONFIG:
			if ( (( CG_ComProtocol_01.FlagBITF & CMD_CONFIG_FORBID ) != 0) || 
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value 			 = 0;
			} else {
				CG_ComProtocol_01.FlagBITF |= (1UL << COM_CONFIG_ENTER_BIT);
				CG_ComProtocol_01.FlagBITF |= (1UL <<COM_UPDATE_SPECIAL_PA_REQ_BIT);
				return_value = 1;	
			}	
			break;
			  
		case COM_CMD_ERROR_HISTORY_RESET:	// Alarm history reset.
			if ( (( CG_ComProtocol_01.FlagBITF & CMD_ALM_HIS_RESET_FORBID ) != 0) ||
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value 			 = 0;
			} else {
				CG_ComProtocol_01.FlagBITF |= (1UL << COM_ALARM_HIS_RESET_REQ_BIT);
				return_value = 1;	
			}		
			break;
		     
		case COM_CMD_WARN_HISTORY_RESET:		// Warning history reset.
			if ( (( CG_ComProtocol_01.FlagBITF & CMD_WNG_HIS_RESET_FORBID ) != 0) || 
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value 			 = 0;
			} else {
				CG_ComProtocol_01.FlagBITF |= (1UL << COM_WARN_HIS_RESET_REQ_BIT);
				return_value = 1;	
			}
			break;
			
		case COM_CMD_COM_HISTORY_RESET:		// COM Error history reset.
			if ( (( CG_ComProtocol_01.FlagBITF & CMD_COM_ERROR_HIS_RESET_FORBID ) != 0) ||
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value 			 = 0;
			} else {
				CG_ComProtocol_01.FlagBITF |= (1UL << COM_COM_ERROR_HIS_RESET_REQ_BIT);
				return_value = 1;	
			}
			break;

		case COM_CMD_LOAD_ALL_PA_START:
			return_value = 1;
			break;
			
		case COM_CMD_LOAD_ALL_PA_DONE:
		    return_value = 1;
			break;
			
		case COM_CMD_IO_RESET:
			CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
			return_value 			 = 0;

			break;
			
		case COM_CMD_PA_RESET:
			if ( (( CG_ComProtocol_01.FlagBITF & CMD_PA_RESET_FORBID ) != 0) ||
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value 			 = 0;
			} else {
				CG_ComProtocol_01.FlagBITF |= (1UL << COM_PA_SETUP_RESET_REQ_BIT);
				return_value = 1;
			}
			break;	
		case COM_CMD_RELOAD_FWEEP:	// To reload FWEEP

			if ( (( CG_ComProtocol_01.FlagBITF & CMD_RELOAD_FWEEP_FORBID ) != 0) ||
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value 			 = 0;
			} else {
				CG_ComProtocol_01.FlagBITF |= (1UL << COM_RELOAD_FWEEP_BIT);
				return_value = 1;
			}
			
			break;
		case COM_CMD_RELOAD_HWEEP: // To reload HWEEP

			if ( (( CG_ComProtocol_01.FlagBITF & CMD_RELOAD_HWEEP_FORBID ) != 0) ||
				 ( set_bit != 1 )
			) {
				 CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				 return_value 			 = 0;
			} else {
				CG_ComProtocol_01.FlagBITF |= (1UL << COM_RELOAD_HWEEP_BIT);
				return_value = 1;
			}

			break;
		// command not support yet.
		default:
			return_value = 0;
			CG_ComProtocol_01.Error =  COM_ERROR_OUT_RANGE;
			break;
	}
	return (return_value);

}

/*===========================================================================================
    Function Name    : pa_change_allowed_check
    Input            : 1. mb_adds_h: modbus data address high byte
					   2. mb_adds_l: modbus data address low byte
					   3. mb_data: modbus data value
					   4. Masterlevel: master device level
    Return           : return_value: 0 = Set parameter update req flag to YES
									 1 = Set parameter update req flag to NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to check if parameter can update or not.
					   Check register Address
					   Check Real Time Update
					   Check Read Only					   
					   Check Range
					   Check eep write
//==========================================================================================*/
uint8_t pa_change_allowed_check ( const uint8_t mb_adds_h, const uint8_t mb_adds_l, 
								  const int32_t mb_data, const int32_t MasterLevel )
{
	uint8_t return_value 		= 1;
	//uint8_t pa_major_num		= mb_adds_h%10;		// major address of the parameter
	uint8_t pa_major_num		= MOD( mb_adds_h, 10 );		// major address of the parameter
	uint8_t pa_major			= 0;                // major of the parameter
	uint8_t pa_minor            = mb_adds_l;		// minor of the parameter
	uint8_t pa_type			 	= mb_adds_h/10;     // Data type by address: Pa_EEP, Def, Max, Min, MaxMin, RO_EEP, Pa_RAM
	//uint8_t RO_Index			= Const_RO_SECT [ pa_type ]%RO_SEC_MAX; 	// Determine if the data is read only and eep write req?
	uint8_t RO_Index			= MOD( Const_RO_SECT [ pa_type ], RO_SEC_MAX ); 	// Determine if the data is read only and eep write req?
	
	//CG_ComProtocol_01.FlagBITF &= ~(1UL << COM_PA_EEP_SAVE_ALLOWED_BIT);	// Clear EEP save allowed.
	
	// Address check
	#if(0)
	if ( (pa_major_num > PARAMETER_MAJOR_NUM) ||
	     (pa_minor > PARAMETER_MINOR_NUM) ) {
		 
		 return_value = 0;
		 CG_ComProtocol_01.Error =  COM_ERROR_OUT_RANGE;
		 
	#else
	if ( ( mb_adds_h >= COM_DEFAULT_EEP_INDEX + PARAMETER_MAJOR_NUM && mb_adds_h < COM_PA_RAM_INDEX ) ||
		 mb_adds_h >= COM_PA_RAM_INDEX + PARAMETER_MAJOR_NUM  ||
		 pa_minor > PARAMETER_MINOR_NUM  ) {

		 return_value = 0;
		 CG_ComProtocol_01.Error =  COM_ERROR_OUT_RANGE;

		 // Range check
		if ( parameter_Range_Check ( mb_adds_h, pa_minor, mb_data ) == 0 ) {

			CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MAJOR ] = pa_major + 1;	// mapping to display address
			CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MINOR ] = pa_minor + 1;  // mapping to display address
		}

	#endif

	} else {
		
		pa_major = pa_major_num - 1;	// mapping com address to parameter eep address.
		
		// Read only check
		if ( RO_Index == 0 ) {
			return_value = 0;
		} else if ( RO_Index == 1 ) {
			return_value &= 1;
		} else if ( (RO_Index == 2) || (RO_Index == 3) ) {
			return_value  &= ((CG_WriteEn_Paramter_BITF[ pa_major ] >> pa_minor) & 0x01);
		}
		// Real Time update check
		if ((CG_ComProtocol_01.FlagBITF & (1UL << COM_PA_CHANGE_REALTIME_REQ_BIT)) !=0) {
			return_value  &= ((CG_RealTime_Paramter_BITF[ pa_major ] >> pa_minor) & 0x01);
		} else {
			return_value &= 1;	
		}
		
		if ( return_value == 1 ) {
			// Range check
			if ( parameter_Range_Check ( mb_adds_h, pa_minor, mb_data ) == 0 ) {
				return_value = 0;
				CG_ComProtocol_01.Error = COM_ERROR_OUT_RANGE;
				CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MAJOR ] = pa_major + 1;	// mapping to display address
				CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MINOR ] = pa_minor + 1;  // mapping to display address
			}
		} else {
			CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
		}
				
	}
	

	// Enginner mode (only check if write eep, bypass other checks)
	if ( MasterLevel == MASTER_LEVEL_3 ) {
		CG_ComProtocol_01.Error =  0;
		return_value = 1;
	}
	
	// EEP write check.
	if ( ((RO_Index == 1) || (RO_Index == 2)) &&
		 (return_value == 1)
	) {
		CG_ComProtocol_01.FlagBITF |= (1UL << COM_PA_EEP_SAVE_ALLOWED_BIT);
	}


	return (return_value);
}

/*===========================================================================================
    Function Name    : pa_multi_change_allowed_check
    Input            : 1. mb_adds_h: modbus data address high byte
					   2. mb_adds_l: modbus data address low byte
					   3. *mb_data: modbus data array pointer
					   4. data_num: modbus data quantity
					   5. Masterlevel: master device level
    Return           : return_value: 0 = Set parameter update req flag to YES
									 1 = Set parameter update req flag to NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to check if multiple parameter can update or not.
					   Only support parameters and only allowed when motor is not running.
					   Real Time Check (motor state check)
//==========================================================================================*/
uint8_t pa_multi_change_allowed_check ( const uint8_t mb_adds_h,const uint8_t mb_adds_l, 
										int32_t *mb_data, const int32_t data_num, const int32_t MasterLevel )
{
	uint8_t return_value 		= 1;
	//uint8_t pa_major_num		= mb_adds_h%10;		// major address of the parameter
	uint8_t pa_major_num		= MOD( mb_adds_h, 10 );		// major address of the parameter
	uint8_t pa_major			= 0;                // major of the parameter
	uint8_t pa_minor            = mb_adds_l;		// minor of the parameter
	uint8_t pa_type			 	= mb_adds_h/10;     					// Data type by address: Pa_EEP, Def, Max, Min, MaxMin, RO_EEP, Pa_RAM
	//uint8_t RO_Index			= Const_RO_SECT [ pa_type ]%RO_SEC_MAX;	// Determine if the data is read only and eep write req?
	uint8_t RO_Index			= MOD( Const_RO_SECT [ pa_type ], RO_SEC_MAX );	// Determine if the data is read only and eep write req?
	uint8_t realtime_First, realtime_Last;

	realtime_First = ( CG_RealTime_Paramter_BITF[ pa_major_num - 1 ] >> pa_minor ) & 0x01;
	realtime_Last  = ( CG_RealTime_Paramter_BITF[ pa_major_num - 1 ] >> ( pa_minor + data_num ) ) & 0x01;
	
	// Real time update check to see if the motor is running or not
    if ( (CG_ComProtocol_01.FlagBITF & (1UL << COM_PA_CHANGE_REALTIME_REQ_BIT)) != 0 &&
    	 ( realtime_First == 0 || realtime_Last == 0 )) {
		return_value = 0;
		CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;	
	} else {
		pa_major = pa_major_num - 1;	// mapping com address to parameter eep address.
		// Read only check
		if ( RO_Index == 0 ) {
			return_value = 0;
		} else if ( RO_Index == 1 ) {
			return_value &= 1;
		} else if ( (RO_Index == 2) || (RO_Index == 3) ) {
            return_value &= multi_parameter_WriteEn_Check ( pa_major, pa_minor, data_num );
		}
		
		if ( return_value == 1 ) {

			#if(0)
			// Range check
			if ( multi_parameter_Range_Check ( mb_adds_h, pa_minor, data_num, mb_data,
											  (int32_t*)&CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MAJOR ],
											  (int32_t*)&CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MINOR ]
											 ) == 0 ) {
				return_value = 0;
				CG_ComProtocol_01.Error = COM_ERROR_OUT_RANGE;
			}
			#else

			if ( multi_parameter_Range_Check ( mb_adds_h, pa_minor, data_num, mb_data,
				 							   (int32_t*)&CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MAJOR ],
				 							   (int32_t*)&CG_ComProtocol_01.ERROR_His_RAM[ FAULT_MINOR ] ) == 0 ||
				 ( mb_adds_h >= COM_DEFAULT_EEP_INDEX + PARAMETER_MAJOR_NUM && mb_adds_h < COM_PA_RAM_INDEX ) ||
				 mb_adds_h >= COM_PA_RAM_INDEX + PARAMETER_MAJOR_NUM ){

				return_value = 0;
				CG_ComProtocol_01.Error = COM_ERROR_OUT_RANGE;
			}

			#endif
			
		} else {
			CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;
		}
		
		// Enginner mode
		if ( MasterLevel == MASTER_LEVEL_3 ) {
			CG_ComProtocol_01.Error =  0;
			return_value = 1;
		}
		
		// EEP write check.
		if ( ((RO_Index == 1) || (RO_Index == 2)) &&
			 (return_value == 1)
		) {
			CG_ComProtocol_01.FlagBITF |= (1UL << COM_PA_EEP_SAVE_ALLOWED_BIT);
		}
	}
	
	return (return_value);
}

/*===========================================================================================
    Function Name    : pa_BackToDefault
    Input            : 1. major_index: major number of the parameter to reset
    Return           : result: 1=eep ok, 0=eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Function to set the parameters of a major back to default eep value.
					   Only support parameters and only allowed when motor is not running.
//==========================================================================================*/
uint8_t pa_BackToDefault ( const uint32_t major_index )
{
    uint8_t result = 1;
	result &= saveEEPParameter_Multiple( major_index,
										 0,
										 PARAMETER_MINOR_NUM,
										 (int32_t*)&CG_Parameter.EEP_data_default[major_index],
										 PA_EEP_WR_AND_CHECK );
    return (result);
}

/*===========================================================================================
    Function Name    : com_CMD_execute_routine
    Input            : NULL
    Return           : return_value: 0=Function failed executed, 1=Function executed fine. 2=eep error.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to execute the command.
//==========================================================================================*/
uint8_t com_CMD_execute_routine ( void )
{
	uint8_t return_value 		= 1;
	uint8_t eep_ok				= 1;
	
	// Special pa update
	if ( (CG_ComProtocol_01.FlagBITF & (1UL <<COM_UPDATE_SPECIAL_PA_REQ_BIT)) != 0 ) {
		updateSpeceilParameter ();
		hweep_WatchUpdate ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] );
		CG_ComProtocol_01.FlagBITF &= ~(1UL <<COM_UPDATE_SPECIAL_PA_REQ_BIT);
		CG_ComProtocol_01.FlagBITF &= ~(1UL << COM_CONFIG_ENTER_BIT);
	}
	
	// Reload FWEEP
	if( ( CG_ComProtocol_01.FlagBITF & ( 1UL << COM_RELOAD_FWEEP_BIT ) ) != 0 ){
		eep_ok &= readFWEEP();
		CG_ComProtocol_01.FlagBITF &= ~( 1UL << COM_RELOAD_FWEEP_BIT );
	}

	// Reload HWEEP
	if( ( CG_ComProtocol_01.FlagBITF & ( 1UL <<COM_RELOAD_HWEEP_BIT ) ) != 0 ){
		readTotalHWEEP();
		CG_ComProtocol_01.FlagBITF &= ~( 1UL << COM_RELOAD_HWEEP_BIT );
	}

	// Com error history clear
	if ( (CG_ComProtocol_01.FlagBITF & _BIT( COM_COM_ERROR_HIS_RESET_REQ_BIT )) != 0 ) {
		com_HistoryArray_Clear( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_HIST_ARRAY_SIZE );
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_COM_ERROR_HIS_RESET_REQ_BIT );
	}
	
	// WNG history clear
	if ( (CG_ComProtocol_01.FlagBITF & _BIT( COM_WARN_HIS_RESET_REQ_BIT )) != 0 ) {
        com_HistoryArray_Clear( (uint32_t*)CG_ComProtocol_01.Wng_His_ptr, HIST_SIZE );
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_WARN_HIS_RESET_REQ_BIT );
	}
	
	// ALM history clear
	if ( (CG_ComProtocol_01.FlagBITF & _BIT( COM_ALARM_HIS_RESET_REQ_BIT )) != 0 ) {
		com_HistoryArray_Clear( (uint32_t*)CG_ComProtocol_01.Alm_His_ptr, HIST_SIZE );
		eep_ok &= saveEEPParameter_Multiple( COM_RO_EEP_INDEX-1,
											 0,
											 HIST_SIZE,
											 (int32_t*)CG_ComProtocol_01.Alm_His_ptr,
											 PA_EEP_WR_AND_CHECK );
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_ALARM_HIS_RESET_REQ_BIT );
	}
	
	// IO back to default
	if ( (CG_ComProtocol_01.FlagBITF & _BIT( COM_IO_SETUP_RESET_REQ_BIT )) != 0 ) {
		eep_ok &= pa_BackToDefault( PARAMETER_IO );
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_IO_SETUP_RESET_REQ_BIT );
	}
	
	// Parameter back to default
	if ( (CG_ComProtocol_01.FlagBITF & _BIT( COM_PA_SETUP_RESET_REQ_BIT )) != 0 ) {
		eep_ok &= pa_BackToDefault( 0 );
		eep_ok &= pa_BackToDefault( 1 );
		eep_ok &= pa_BackToDefault( 2 );
		eep_ok &= pa_BackToDefault( 3 );
		eep_ok &= pa_BackToDefault( 4 );
		eep_ok &= pa_BackToDefault( 5 );
		eep_ok &= pa_BackToDefault( 6 );
		eep_ok &= pa_BackToDefault( 7 );
		eep_ok &= pa_BackToDefault( 8 );
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_PA_SETUP_RESET_REQ_BIT );
	}
	
	if (eep_ok == 0) {
		return_value = 2;
	}
	
	// Parameter limit check flag set
	CG_ComProtocol_01.FlagBITF |= _BIT( COM_PA_LIMIT_CHECK_REQ_BIT );
	
	return (return_value);
}

/*===========================================================================================
    Function Name    : com_Error_routine
    Input            : 1. ExceptionCode : The exception code of modbus.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update and check the com error.
					   In Modbus error reply and broadcast.
//==========================================================================================*/
void com_Error_routine ( const uint8_t ExceptionCode )
{
	switch ( ExceptionCode ) {
		case ILLEGAL_FUNCTION:
			com_HistoryArray_update( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_ALM_HIS_NUM, COM_ERROR_CMD_NDF );
			break;
		
		case ILLEGAL_DATA_ADDRESS:
			com_HistoryArray_update( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_ALM_HIS_NUM, COM_ERROR_CMD_NDF );
			break;
			
		case ILLEGAL_DATA_VALUE:
			com_HistoryArray_update( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_ALM_HIS_NUM, COM_ERROR_OUT_RANGE );
			break;
			
		case SLAVE_DEVICE_FAILURE:
			com_HistoryArray_update( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_ALM_HIS_NUM, CG_ComProtocol_01.Error );
			break;
		
		case 0: // NOrmal
			break;

	}

}

/*===========================================================================================
    Function Name    : com_Error_His_update
    Input            : 1. *data: pointer of the data array to update
					   2. data_num: the data quantity of the arrary
					   3. ComErrorNum : The Error number of the COM error.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update the the history array.
//==========================================================================================*/
void com_HistoryArray_update ( uint32_t *data, const uint32_t data_num, const uint32_t ComErrorNum )
{
	int i=0;
	
	data = data + data_num - 1;		// Set the array pointer to the last (oldest) data
	
	for (i=data_num-1; i>0; i--) {	// Move all data to it's next address
		(*data) = *(data-1);
		data--;
	}
	(*data) = ComErrorNum;			// update the current data

}

/*===========================================================================================
    Function Name    : com_HistoryArray_Clear
    Input            : 1. *data: pointer of the data array to clear
					   2. data_num: the data quantity of the arrary
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : A routine to clear array (set all value to 0). (WNG, ALM ...etc)
//==========================================================================================*/
void com_HistoryArray_Clear ( uint32_t *data, const uint32_t data_num )
{
	int i;
	
	for (i=0; i<data_num; i++) {	        
		*(data++) = 0;
	}

}

/*===========================================================================================
    Function Name    : com_Init_waiting_Check
    Input            : 1. check_tick : The tick before com protocol timeout to enable.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : waiting for initialize before timeout check.
					   Called in 1 sec or 100ms routine.
//==========================================================================================*/
void com_Init_waiting_Check ( uint8_t check_tick )
{
	static uint8_t cnt_ticks = 0;
	
    if ( cnt_ticks < check_tick ) {
		cnt_ticks ++;
	} else {
		CG_ComProtocol_01.FlagBITF |= (1UL << COM_INIT_FINISH_BIT);
	}

}

/*===========================================================================================
    Function Name    : com_TimeOut_Alm_handler
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Communication Time Out handler. With system initial finished check.			   				   
//==========================================================================================*/
void com_TimeOut_Alm_handler ( uint8_t timeout_flag )
{
	if (( timeout_flag == YES) && ((CG_ComProtocol_01.FlagBITF & (1UL << COM_INIT_FINISH_BIT)) != 0) ) {
		CG_ComProtocol_01.FlagBITF |= _BIT( COM_TIME_OUT_BIT );
		//CG_ComProtocol_01.FlagBITF |= _BIT( COM_COM_ALM_REQ_BIT );
		CG_Protect.Motor_0.ComAlarm_Req_Flag = YES;
		//CG_Protect.Motor_1.ComAlarm_Req_Flag = YES;

		//CG_ComProtocol_01.MasterLevel = MASTER_LEVEL_0;
		if ( (CG_ComProtocol_01.FlagBITF & _BIT( COM_TIMEOUT_ALM_SAVED_BIT )) == 0 ) {
			com_HistoryArray_update( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_ALM_HIS_NUM, COM_ERROR_TIME_OUT );
			CG_ComProtocol_01.FlagBITF |= _BIT( COM_TIMEOUT_ALM_SAVED_BIT );
		}
	} else {
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_TIME_OUT_BIT );
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_TIMEOUT_ALM_SAVED_BIT );
	}

}

/*===========================================================================================
    Function Name    : com_Fault_handler
    Input            : 1. str_modbus : The struct of RS232 or RS485
					   2. receive_flag: the receive state of the modbus data
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Communication fault determine routine. (error that may cause alarm)
					   Set fault flag and clear the counter if the number matched.
					   Called in mb_req_checking()
//==========================================================================================*/
void com_Fault_handler (  Struct_Modbus_Slave *str_modbus, const uint8_t receive_flag )
{
    
	if ( ( str_modbus->FlagBITF & _BIT(MB_FRAME_COM_ALARM_BIT)) != 0 ) {
		
		if ( ( str_modbus->COM_Alm_num ) != 0 ) {
			if ( ++str_modbus->COM_Alm_cnt >= str_modbus->COM_Alm_num ) {
		
				str_modbus->COM_Alm_cnt = 0;
				
				// Set com error fault flag.
				//CG_ComProtocol_01.FlagBITF |= _BIT( COM_COM_ALM_REQ_BIT );
				CG_Protect.Motor_0.ComAlarm_Req_Flag = YES;
                //CG_Protect.Motor_1.ComAlarm_Req_Flag = YES;
			}
		} else {
			str_modbus->COM_Alm_cnt = 0;
		}
		
		// Com error history update for error, set WNG
		com_HistoryArray_update( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_ALM_HIS_NUM, COM_ERROR_COM_ALARM );
		CG_ComProtocol_01.FlagBITF |= _BIT( COM_ERROR_WNG_BIT );
		
	}
	
	// Clear COM error WNG if receive is fine
	if ( receive_flag == YES ) {
		CG_ComProtocol_01.FlagBITF &= ~_BIT( COM_ERROR_WNG_BIT );
	} 	
}

/*===========================================================================================
    Function Name    : com_HWEEP_Write_allowed_check
    Input            : 1. Masterlevel: master device level
    Return           : return_value: 0 = Set HWEEP update req flag to YES
									 1 = Set HWEEP update req flag to NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to check if HWEEP can update or not.
					   Only allowed when motor is not running. (Real Time Check)
					   Called in is_FC16_ok()
					   2014-12-03 Gear Note: consider only update in Master Level 3 in the future
//==========================================================================================*/
uint8_t com_HWEEP_Write_allowed_check ( const int32_t MasterLevel )
{
	uint8_t return_value 		= 1;
	
	// Real time update check to see if the motor is running or not
    if ( (CG_ComProtocol_01.FlagBITF & (1UL << COM_PA_CHANGE_REALTIME_REQ_BIT)) != 0 ) {
		return_value = 0;
		CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;	
	}
	
	// Check if Engineering mode
	#if(1)
	///*
	if ( MasterLevel != MASTER_LEVEL_3 ) {
		return_value = 0;
		CG_ComProtocol_01.Error =  COM_ERROR_CMD_DENY;	
	}
	//*/
	#endif
	
	if ( return_value == 1 ) {
		CG_ComProtocol_01.FlagBITF |= (1UL << COM_HWEEP_SAVE_ALLOWED_BIT);
	}
	
	return (return_value);
}

/*===========================================================================================
    Function Name    : com_FC101_Check_ASCII
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description      : FC101 check routine
//==========================================================================================*/
uint8_t com_FC101_Check_ASCII ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus)
{
	uint8_t is_msg_ok = 1;			// Return value.
	uint8_t is_echo_m0		= 0;		// 0: no echo, 1: echo
	//uint8_t is_echo_m1      = 0;        // 0: no echo, 1: echo
	uint8_t i = 0;					// for loop counting index
	uint8_t k = 0;					// counting index


	#if(0)
	// Get Sub_ID quantity and check range
	CG_ComProtocol_01.SubID_Num = aSCII_to_Unchar( data[ ASC_IDNUM_H ]  ,data[ ASC_IDNUM_L ] );
	if ( CG_ComProtocol_01.SubID_Num > SUB_ID_NUM ) {
		str_modbus->ExceptionCode = ILLEGAL_DATA_ADDRESS;
		is_msg_ok = 0;
	}
	#else

	// Get Sub_ID quantity and check range
	str_modbus->SubID_Num = aSCII_to_Unchar( data[ ASC_IDNUM_H ]  ,data[ ASC_IDNUM_L ] );
	if ( str_modbus->SubID_Num > SUB_ID_NUM ) {
		//str_modbus->ExceptionCode = ILLEGAL_DATA_ADDRESS;
		str_modbus->ExceptionCode = ILLEGAL_AGV_SUBID_NUM;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}else if( data_num != ASC_BASIC_LENGTH + str_modbus->SubID_Num * ASC_OFF_SET ){
		//str_modbus->ExceptionCode = ILLEGAL_DATA_VALUE;
		str_modbus->ExceptionCode = ILLEGAL_AGV_FORMAT;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}

	#endif

	str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_NUM;

	//str_modbus->SecondEcho_State = SECOND_ECHO_STATE_IDLE;

	str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = MULTI_CMD_NULL;
	//str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = MULTI_CMD_NULL;
	str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = NO;
	//str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = NO;

	// If msg ok, check self sub ID and Echo
	if ( is_msg_ok == 1 ) {
		is_msg_ok = 0;

		for (i=0; i< str_modbus->SubID_Num; i++) {
			// Get Sub_ID
		    str_modbus->SubID[ i ] = aSCII_to_Unchar( data[ ASC_ID1_H + (i*ASC_OFF_SET) ]  ,data[ ASC_ID1_L + (i*ASC_OFF_SET) ] );

			// Set SubID_Seq if ID matched
			if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = i;
				is_msg_ok = 1;

				// Get Command of self ID
				str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = aSCII_to_Unchar( data[ ASC_CMD1_H + (i * ASC_OFF_SET) ]  ,data[ ASC_CMD1_L + (i * ASC_OFF_SET) ] );

				str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M0 ] =   aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 1 ]) * 256 +
                                                                    aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 2 ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 3 ] );

				str_modbus->Data2[ MULTI_DRIVE_DRIVE_INDEX_M0 ] =   aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 4 ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 5 ]) * 256 +
                                                                    aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 6 ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 7 ] );

				// Check if command supported
				if ( com_FC101_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] ) == NO ) {
					str_modbus->ExceptionCode = SLAVE_DEVICE_FAILURE;
					CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				}

			}/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = i;
                is_msg_ok = 1;

                // Get Command of self ID
                str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = aSCII_to_Unchar( data[ ASC_CMD1_H + (i * ASC_OFF_SET) ]  ,data[ ASC_CMD1_L + (i * ASC_OFF_SET) ] );

                str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M1 ] =   aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 1 ]) * 256 +
                                                                    aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 2 ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 3 ] );

                str_modbus->Data2[ MULTI_DRIVE_DRIVE_INDEX_M1 ] =   aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 4 ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 5 ]) * 256 +
                                                                    aSCII_to_Unchar( data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 6 ],
                                                                                     data[ ASC_POS_DATA + ( i * ASC_OFF_SET) + 7 ] );


                // Check if command supported
                if ( com_FC101_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] ) == NO ) {
                    str_modbus->ExceptionCode_Secondary = SLAVE_DEVICE_FAILURE;
                    CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
                }

            }*/

			// Check if command need echo. Set Echo ID and Echo_Seq.
			if ( aSCII_to_Unchar( data[ ASC_CMD1_H + (i * ASC_OFF_SET) ]  ,data[ ASC_CMD1_L + (i * ASC_OFF_SET) ] ) < MULTI_CMD_NOECHO ) {
			    str_modbus->EchoID[ k ] = str_modbus->SubID[ i ];

				// Set Echo_Seq if self ID matched the echo ID
				if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
				    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = k;
					is_echo_m0 = 1;
					if( k == 0 ){
					    str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M0;
					}
				}/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
				    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = k;
                    is_echo_m1 = 1;
                    if( k == 0 ){
                        str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M1;
                    }
                }*/

				k++;
			}
		}
	}

	// Reset echo if no echo.
	if ( is_echo_m0 == 0 )  {
	    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = SUB_ID_NOECHO;
	}

	/*
	if ( is_echo_m1 == 0 )  {
	    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = SUB_ID_NOECHO;
    }*/

	str_modbus->MultiCMD_FC_R = str_modbus->req_pdu_function_code;	// get received function code.

	return ( is_msg_ok );
}

/*===========================================================================================
    Function Name    : com_FC101_Check_RTU
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC101 check routine
//==========================================================================================*/
uint8_t com_FC101_Check_RTU ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus)
{
	uint8_t is_msg_ok = 1;			// Return value.
	uint8_t is_echo_m0		= 0;		// 0: no echo, 1: echo
	//uint8_t is_echo_m1     = 0;        // 0: no echo, 1: echo
	uint8_t i = 0;					// for loop counting index
	uint8_t k = 0;					// counting index

	#if(0)
	// Get Sub_ID quantity and check range
	CG_ComProtocol_01.SubID_Num =  data[ RTU_IDNUM ];
	if ( CG_ComProtocol_01.SubID_Num > SUB_ID_NUM ) {
		str_modbus->ExceptionCode = ILLEGAL_DATA_ADDRESS;
		is_msg_ok = 0;
	}
	#else
	// Get Sub_ID quantity and check range
	str_modbus->SubID_Num =  data[ RTU_IDNUM ];
	if ( str_modbus->SubID_Num > SUB_ID_NUM ) {
		//str_modbus->ExceptionCode = ILLEGAL_DATA_ADDRESS;
		str_modbus->ExceptionCode = ILLEGAL_AGV_SUBID_NUM;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}else if( data_num != RTU_BASIC_LENGTH + str_modbus->SubID_Num * RTU_OFF_SET ){
		//str_modbus->ExceptionCode = ILLEGAL_DATA_VALUE;
		str_modbus->ExceptionCode = ILLEGAL_AGV_FORMAT;
		is_msg_ok = 0;
		com_Error_routine( str_modbus->ExceptionCode );
	}


	#endif

	str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_NUM;

	//str_modbus->SecondEcho_State = SECOND_ECHO_STATE_IDLE;

	str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = MULTI_CMD_NULL;
	//str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = MULTI_CMD_NULL;
    str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = NO;
    //str_modbus->MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = NO;

	// If msg ok, check self sub ID and Echo
	if ( is_msg_ok == 1 ) {
		is_msg_ok = 0;

		for (i=0; i< str_modbus->SubID_Num; i++) {
			// Get Sub_ID
		    str_modbus->SubID[ i ] = data[ RTU_ID1 + (i*RTU_OFF_SET) ];

			// Set SubID_Seq if ID matched
			if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = i;
				is_msg_ok = 1;

				// Get Command of self ID
				str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = data[ RTU_CMD1 + (i * RTU_OFF_SET) ];


				str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = ( data[ RTU_POS_DATA + ( i * RTU_OFF_SET) ] * 256) +
                                                                    data[ RTU_POS_DATA + ( i * RTU_OFF_SET) + 1 ];
				str_modbus->Data2[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = ( data[ RTU_POS_DATA + ( i * RTU_OFF_SET) + 2 ] * 256) +
				                                                    data[ RTU_POS_DATA + ( i * RTU_OFF_SET) + 3 ];

				// Check if command supported
				if ( com_FC101_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M0 ] ) == NO ) {
					str_modbus->ExceptionCode = SLAVE_DEVICE_FAILURE;
					CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
				}

			}/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
			    str_modbus->SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = i;
                is_msg_ok = 1;

                // Get Command of self ID
                str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = data[ RTU_CMD1 + (i * RTU_OFF_SET) ];

                str_modbus->Data1[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = ( data[ RTU_POS_DATA + ( i * RTU_OFF_SET) ] * 256) +
                                                                    data[ RTU_POS_DATA + ( i * RTU_OFF_SET) + 1 ];
                str_modbus->Data2[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = ( data[ RTU_POS_DATA + ( i * RTU_OFF_SET) + 2 ] * 256) +
                                                                    data[ RTU_POS_DATA + ( i * RTU_OFF_SET) + 3 ];

                // Check if command supported
                if ( com_FC101_CmdSupport_IsOk ( str_modbus->CMD[ MULTI_DRIVE_DRIVE_INDEX_M1 ] ) == NO ) {
                    str_modbus->ExceptionCode_Secondary = SLAVE_DEVICE_FAILURE;
                    CG_ComProtocol_01.Error = COM_ERROR_CMD_DENY;
                }

            }*/

			// Check if command need echo. Set Echo ID and Echo_Seq.
			if ( data[ RTU_CMD1 + (i * RTU_OFF_SET) ] < MULTI_CMD_NOECHO ) {
			    str_modbus->EchoID[ k ] = str_modbus->SubID[ i ];

				// Set Echo_Seq if self ID matched the echo ID
				if ( str_modbus->SubID[ i ] == str_modbus->DeviceID ) {
				    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = k;
					is_echo_m0 = 1;
					if( k == 0 ){
					    str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M0;
                    }
				}/*else if ( str_modbus->SubID[ i ] == str_modbus->DeviceID_Secondary ) {
				    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = k;
                    is_echo_m1 = 1;
                    if( k == 0 ){
                        str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M1;
                    }
                }*/

				k++;
			}
		}
	}

	// Reset echo if no echo.
	if ( is_echo_m0 == 0 )  {
	    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M0 ] = SUB_ID_NOECHO;
	}
	/*
	if ( is_echo_m1 == 0 )  {
	    str_modbus->Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_M1 ] = SUB_ID_NOECHO;
    }*/

	str_modbus->MultiCMD_FC_R = str_modbus->req_pdu_function_code;	// get received function code.

	return ( is_msg_ok );
}

/*===========================================================================================
    Function Name    : com_FC101_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC101 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC101_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus)
{
    /*
	// Get command
	uint8_t lc_cmd;
	uint8_t i;

	for( i = MULTI_DRIVE_DRIVE_INDEX_M0; i < MULTI_DRIVE_DRIVE_INDEX_NUM; i++ ){
	    lc_cmd = MOD( CG_ComProtocol_01.CMD[i] , MULTI_CMD_NOECHO );	// mod for no echo command.

        switch( lc_cmd ){
            // Target speed commands
            case MULTI_CMD_JGF:
            case MULTI_CMD_JGR:
            case MULTI_CMD_JGS:
            case MULTI_CMD_JG:
                com_Get_TSPD ( (uint8_t*)data, lc_MBscheme, str_modbus );
                break;

            // Target Position commands
            case MULTI_CMD_CS:
            case MULTI_CMD_IMR:
            case MULTI_CMD_MR:
            case MULTI_CMD_MA:
            case MULTI_CMD_CMR:
            case MULTI_CMD_CMA:
                com_Get_TPOS ( (uint8_t*)data, lc_MBscheme, str_modbus );
                break;

            // No Target commands
            case MULTI_CMD_STOP:
            case MULTI_CMD_JG0:
            case MULTI_CMD_FREE:
            case MULTI_CMD_SVON:
            case MULTI_CMD_SVOFF:
            case MULTI_CMD_NULL:
            // inValid command
            default:
                break;
        }
	}*/
}

/*===========================================================================================
    Function Name    : com_FC102_Check
    Input            :
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC102 check routine. Check to reply or not.
//==========================================================================================*/
uint8_t com_FC102_Check ( uint8_t *data, Struct_Modbus_Slave *str_modbus)
{
	uint8_t return_value = 0;
	uint8_t lc_LstSubID  = 0;
	uint8_t i;

	str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_NUM;

	for( i = MULTI_DRIVE_DRIVE_INDEX_M0; i < MULTI_DRIVE_DRIVE_INDEX_NUM; i++ ){
        // Check if Echo_Seq is the 1st ID or no Echo. Either of these need no echo.
        if ( ( str_modbus->Echo_Seq[i] != 0) && ( str_modbus->Echo_Seq[i] < SUB_ID_NOECHO) ) {
            lc_LstSubID = str_modbus->EchoID[ str_modbus->Echo_Seq[i] - 1 ];

            if ( str_modbus->req_pdu_slaveID == lc_LstSubID ) {
                /*To Response*/
                str_modbus->Echo_Driver = i;
                return_value = 1;
                break;
            }
        }

	}

	str_modbus->MultiCMD_FC_R = str_modbus->req_pdu_function_code;	// get received function code.

	return (return_value);
}

/*===========================================================================================
    Function Name    : com_FC102_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC101 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC102_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus)
{
    /*
	if ( (CG_ComProtocol_01.FlagBITF & _BIT(COM_IS_FC101_FAILED)) != 0 ) {
		// last FC101 failed
		str_modbus->req_pdu_function_code = MB_FC103;
	} else {
		// last FC101 ok
		str_modbus->req_pdu_function_code = MB_FC102;
	}*/
    if( str_modbus->Echo_Driver < MULTI_DRIVE_DRIVE_INDEX_NUM ){

        if( str_modbus->MultiCMD_Fail[ str_modbus->Echo_Driver ] == YES ){
            str_modbus->req_pdu_function_code = MB_FC103;   // multi-driver error reply
        }else{
            str_modbus->req_pdu_function_code = MB_FC102;   // multi-driver normal reply
        }
    }

}

/*===========================================================================================
    Function Name    : com_Get_TSPD
    Input            : 1. *data: The data array from the Uart receive buffer.
					   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Get the value of TSPD from uart buffer to modbus buffer.
//==========================================================================================*/
#if(0)
static void com_Get_TSPD ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus )
{
    /*
	if ( lc_MBscheme == MB_SLV_RTU ) {
		// RTU
		str_modbus->req_pdu_data[ 0 ] = (data[ RTU_SPD_DATA + (CG_ComProtocol_01.SubID_Seq * RTU_OFF_SET) ] * 256) +
										 data[ RTU_SPD_DATA + (CG_ComProtocol_01.SubID_Seq * RTU_OFF_SET) + 1 ];

	} else {
		// ASCII
		str_modbus->req_pdu_data[ 0 ] = aSCII_to_Unchar( data[ ASC_SPD_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) ],
														 data[ ASC_SPD_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 1 ]) * 256 +
										aSCII_to_Unchar( data[ ASC_SPD_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 2 ],
														 data[ ASC_SPD_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 3 ] );
	}*/

}
#endif

/*===========================================================================================
    Function Name    : com_Get_TPOS
    Input            : 1. *data: The data array from the Uart receive buffer.
					   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Get the value of TPOS. From uart buffer to modbus buffer.
					   High byte use 16 bits data. The first 16 bits reserved. Uart data handle depends on Modbus mode.
//==========================================================================================*/
#if(0)
static void com_Get_TPOS ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus )
{

    /*
	if ( lc_MBscheme == MB_SLV_RTU ) {
		// RTU
		// high byte
		str_modbus->req_pdu_data[ 0 ] 		= (data[ RTU_POS_DATA + (CG_ComProtocol_01.SubID_Seq * RTU_OFF_SET) ] * 256) +
											   data[ RTU_POS_DATA + (CG_ComProtocol_01.SubID_Seq * RTU_OFF_SET) + 1 ];
		// low byte
		str_modbus->req_pdu_data[ 1 ]		= (data[ RTU_POS_DATA + (CG_ComProtocol_01.SubID_Seq * RTU_OFF_SET) + 2 ] * 256) +
											   data[ RTU_POS_DATA + (CG_ComProtocol_01.SubID_Seq * RTU_OFF_SET) + 3 ];

	} else {
		//ASCII
		// high byte
		str_modbus->req_pdu_data[ 0 ]		 = aSCII_to_Unchar( data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) ],
															   data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 1 ]) * 256 +
											  aSCII_to_Unchar( data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 2 ],
															   data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 3 ] );
		// low byte
		str_modbus->req_pdu_data[ 1 ]		 = aSCII_to_Unchar( data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 4 ],
															   data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 5 ]) * 256 +
											  aSCII_to_Unchar( data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 6 ],
															   data[ ASC_POS_DATA + (CG_ComProtocol_01.SubID_Seq * ASC_OFF_SET) + 7 ] );
	}*/

}
#endif

/*===========================================================================================
    Function Name    : com_FC101_CmdSupport_IsOk
    Input            : 1. lc_cmd: command to check
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the if the command of multi command FC is supported by the device.
//==========================================================================================*/
static uint8_t com_FC101_CmdSupport_IsOk ( const uint8_t lc_cmd )
{
	uint8_t return_value = 0;
	uint8_t lc_cmd_modified = MOD( lc_cmd, MULTI_CMD_NOECHO );  // mod for no echo command.

	switch( lc_cmd_modified ){
		case MULTI_CMD_STOP:
			return_value = 1;
			break;

		case MULTI_CMD_JGF:
			return_value = 1;
			break;

		case MULTI_CMD_JGR:
			return_value = 1;
			break;

		case MULTI_CMD_JGS:
			return_value = 1;
			break;

		case MULTI_CMD_JG0:
			return_value = 1;
			break;

		case MULTI_CMD_JG:
			return_value = 1;
			break;

		case MULTI_CMD_FREE:
			return_value = 1;
			break;

		case MULTI_CMD_SVON:
		case MULTI_CMD_SVOFF:
			return_value = 1;
			break;

		case MULTI_CMD_IMR:
		case MULTI_CMD_CMR:
		case MULTI_CMD_CMA:
			return_value = 1;
			break;

		case MULTI_CMD_MA:
			return_value = 1;
			break;

		case MULTI_CMD_MR:
			return_value = 1;
			break;

		case MULTI_CMD_CS:
			return_value = 1;
			break;

		case MULTI_CMD_NETIO:
		    return_value = 1;
		    break;
		case MULTI_CMD_NULL:
			return_value = 1;
			break;

		// inValid command
		default:
			return_value = 0;
			break;
	}
	return (return_value);
}

/*===========================================================================================
    Function Name    : com_FC101_Execute
    Input            :
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
					   Set CMD flags, Get stamp data for echo, Return ExceptionCode.
                       If an error occured, Stamp data then do nothing.
//==========================================================================================*/
static uint8_t com_FC101_Execute ( Struct_Modbus_Slave *str_modbus )
{
	uint8_t return_value = 1;	// Return original ExceptionCode if an error occured already.
	uint8_t lc_IsCmdOk;								// 1=ok. 0=SLAVE_DEVICE_FAILURE
	uint8_t lc_cmd;	// mod for no echo command.
	int32_t exception[2];
	int8_t i;
	Struct_BLDC_CTRL *bldc_ctrl;

	/*Get Stamp Data*/

	DINT;
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ STAMP_CPOS_h ] = mcGetCurrentIndex( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ STAMP_CPOS_L ] = mcGetCurrentPos( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ STAMP_DIR ] 	= mcGetCurrentDirection( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M0 ][ STAMP_SPD ] 	= mcGetCurrentSpeed( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0 ) & 65535;

	/*
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ STAMP_CPOS_h ] = mcGetCurrentIndex( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ STAMP_CPOS_L ] = mcGetCurrentPos( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ STAMP_DIR ]     = mcGetCurrentDirection( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
	str_modbus->MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_M1 ][ STAMP_SPD ]     = mcGetCurrentSpeed( ( Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1 ) & 65535;
	*/

	EINT;   // Enable Global interrupt INTM


	exception[0] = str_modbus->ExceptionCode;
	//exception[1] = str_modbus->ExceptionCode_Secondary;

	for( i = 0; i < MULTI_DRIVE_DRIVE_INDEX_NUM; i++ ){

	    if( i == 0 ){
	        bldc_ctrl = (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M0;
	    }/*else{
	        bldc_ctrl = (Struct_BLDC_CTRL*)&CG_BLDC_CTRL_M1;
	    }*/

	    lc_IsCmdOk = 1;
	    lc_cmd = MOD( str_modbus->CMD[i] , MULTI_CMD_NOECHO );    // mod for no echo command.

	    //Set Do Nothing if ExceptionCode is not 0. ( An error occured already )
        if ( exception[i] != 0 ) {
            lc_cmd = MULTI_CMD_NULL;
        }

        lc_IsCmdOk &= mdCMD_Execute ( bldc_ctrl, lc_cmd, str_modbus->Data1[ i ], str_modbus->Data2[ i ] );

        if ( lc_IsCmdOk == 0 ) {
            exception[i] = SLAVE_DEVICE_FAILURE;
        }

        if( exception[i] != 0 ){
            str_modbus->MultiCMD_Fail[i] = YES;
        }

	}

	if( str_modbus->ExceptionCode == 0 ){
	    str_modbus->ExceptionCode = exception[0];
	}
	/*
	if( str_modbus->ExceptionCode_Secondary == 0 ){
	    str_modbus->ExceptionCode_Secondary = exception[1];
	}*/

	if( str_modbus->Echo_Driver < MULTI_DRIVE_DRIVE_INDEX_NUM ){
	    if( str_modbus->MultiCMD_Fail[ str_modbus->Echo_Driver ] == YES ){
	        str_modbus->req_pdu_function_code = MB_FC103;   // multi-driver error reply
        }else{
            str_modbus->req_pdu_function_code = MB_FC102;   // multi-driver normal reply
        }
	}

	/*
	if ( lc_IsCmdOk == 0 ) {
		return_value = SLAVE_DEVICE_FAILURE;
	}

	if ( return_value == 0 ) {
		str_modbus->req_pdu_function_code = MB_FC102;	// multi-driver normal reply
		CG_ComProtocol_01.FlagBITF &= ~_BIT(COM_IS_FC101_FAILED);
	} else {
		str_modbus->req_pdu_function_code = MB_FC103;	// multi-driver error reply
		CG_ComProtocol_01.FlagBITF |= _BIT(COM_IS_FC101_FAILED);
	}
	*/

	return (return_value);
}


