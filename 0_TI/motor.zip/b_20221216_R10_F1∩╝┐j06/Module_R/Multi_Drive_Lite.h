/*
 * Multi_Drive_Lite.h
 *
 *  Created on: 2017/03/30
 *      Author: chaim.chen
 *     History:
 *
 */
/*  Trunmman Technology Corporation. All rights reserved. */
#ifndef MULTI_DRIVE_LITE_H_
#define MULTI_DRIVE_LITE_H_
#include "ModBus_Slave.h"

#define MULTI_DRIVE_LITE

#define LIMIT_SPEED_RPM		60

// Modbus based multi-drive-lite function define
enum{
	MB_FC65	= 0X41,
	MB_FC66	= 0X42,
	MB_FC67	= 0X43
};

// ASCII Uart data index
enum{
	ASC_MDL_IDNUM_H				= 5,			// Modbus ASCII UART data index of ID number H
	ASC_MDL_IDNUM_L				= 6,            // Modbus ASCII UART data index of ID number L
	ASC_MDL_ID1_H				= 7,			// Modbus ASCII UART data index of ID1_H
	ASC_MDL_ID1_L				= 8,            // Modbus ASCII UART data index of ID1_L
	ASC_MDL_CMD1_H				= 9,            // Modbus ASCII UART data index of CMD1_H
	ASC_MDL_CMD1_L      		= 10,           // Modbus ASCII UART data index of CMD1_L
	ASC_MDL_DATA				= 11,           // Modbus ASCII UART data starting index of Data
	ASC_MDL_ECHO_BITF			= 15,
	ASC_MDL_OFF_SET				= 12,			// Modbus ASCII UART data index offset of each ID
	ASC_MDL_BASIC_LENGTH		= 11			// Modbus ASCII UART data basic length
};

// RTU Uart data index
enum{
	RTU_MDL_IDNUM				= 2,			// Modbus RTU Multi-Drive-Lite UART data index of ID number
	RTU_MDL_ID1					= 3,			// Modbus RTU Multi-Drive-Lite UART data index of ID1
	RTU_MDL_CMD1				= 4,            // Modbus RTU Multi-Drive-Lite UART data index of CMD1
	RTU_MDL_DATA				= 5,            // Modbus RTU Multi-Drive-Lite UART data index of Data
	RTU_MDL_ECHO_BITF			= 7,			// Modbus RTU Multi-Drive-Lite UART data index of Echo_BITF
	RTU_MDL_OFF_SET				= 6,				// Modbus RTU Multi-Drive-Lite UART data index offset of each ID
	RTU_MDL_BASIC_LENGTH		= 5				// Modbus RTU UART data basic length
};

enum{

	MDL_CMD_ISTOP		= 0,			// Multi-Drive-Lite command ISTOP
	MDL_CMD_JG			= 1,			// Multi-Drive-Lite command JG

	MDL_CMD_FREE		= 5,			// Multi-Drive-Lite command FREE
	MDL_CMD_SVON		= 6,			// Multi-Drive-Lite command Servo ON
	MDL_CMD_SVOFF		= 7,			// Multi-Drive-Lite command Servo OFF
	MDL_CMD_RST			= 8,			// Multi-Drive-Lite command Alarm Reset
	MDL_CMD_BRAKE		= 9,			// Multi-Drive-Lite command Motor Short Brake

	MDL_CMD_NETIO       = 20,

	MDL_CMD_NULL		= 99			// Multi-Drive-Lite command Do Nothing

};

typedef struct{

	uint8_t		Enabled;

}Struct_MDL;

/*===========================================================================================
    Function Name    : variableInitial_MDL
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Variable CG_MDL initial
//==========================================================================================*/
void variableInitial_MDL (void);

/*===========================================================================================
    Function Name    : mdl_Enable
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mdl_Enable (void);

/*===========================================================================================
    Function Name    : mdl_Disable
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mdl_Disable (void);

/*===========================================================================================
    Function Name    : mbRTU_FC65_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC65_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mb_FC65_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mb_FC65_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mbRTU_FC66_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC66_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mb_FC66_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mb_FC66_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : com_FC65_Check_RTU
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC65 check routine
//==========================================================================================*/
uint8_t com_FC65_Check_RTU ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC65_Check_ASCII
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description      : FC65 check routine
//==========================================================================================*/
uint8_t com_FC65_Check_ASCII ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC66_Check
    Input            :
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC66 check routine. Check to reply or not.
//==========================================================================================*/
uint8_t com_FC66_Check ( uint8_t *data, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC65_CmdSupport_IsOk
    Input            : 1. lc_cmd: command to check
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check if the command of multi-drive lite command is supported by the device.
//==========================================================================================*/
uint8_t com_FC65_CmdSupport_IsOk ( const uint8_t lc_cmd );

/*===========================================================================================
    Function Name    : com_FC65_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC65 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC65_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC66_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC66 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC66_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : mdl_Get_TSPD
    Input            : 1. *data: The data array from the Uart receive buffer.
					   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Get the value of TSPD from uart buffer to modbus buffer.
//==========================================================================================*/
void mdl_Get_TSPD ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mbRTU_MDLCasting
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Multi-drive-lite ctrl function casting. Repare response data.
//==========================================================================================*/
void mbRTU_MDLCasting (	 uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr,
						 Struct_Modbus_Slave *str_modbus
						 );

/*===========================================================================================
    Function Name    : mb_MDLCasting
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
void mb_MDLCasting ( uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr,
						 Struct_Modbus_Slave *str_modbus
						 );

/*===========================================================================================
    Function Name    : com_FC65_Execute
    Input            :
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
					   Set CMD flags, Get stamp data for echo, Return ExceptionCode.
                       If an error occured, Stamp data then do nothing.
//==========================================================================================*/
uint8_t com_FC65_Execute ( Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mdlCMD_Execute
    Input            : 1.bldc_ctrl
                       2.cmd
                       3.data
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
//==========================================================================================*/
uint8_t mdlCMD_Execute ( Struct_BLDC_CTRL *bldc_ctrl, int32_t cmd, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_ISTOP
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command STOP processing routine.
                       Condition check, FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_ISTOP ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_JG
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command JGF processing routine.
                       Condition check, FUNC flags set, TSPD update.
//==========================================================================================*/
uint8_t mdl_CMD_JG ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_FREE
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command FREE processing routine.
                       FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_FREE ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_SVON
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : The Multi command SVON (Servo ON) processing routine.
                       FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_SVON ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_SVOFF
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : The Multi command SVOFF processing routine.
                       FUNC flags set
//==========================================================================================*/
uint8_t mdl_CMD_SVOFF ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_BRAKE
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mdl_CMD_BRAKE ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_RESET
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mdl_CMD_RESET ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );

/*===========================================================================================
    Function Name    : mdl_CMD_NetIO
    Input            : 1.bldc_ctrl
                       2.data
    Return           : 0=Function failed executed, 1=Function executed fine
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t mdl_CMD_NetIO ( Struct_BLDC_CTRL *bldc_ctrl, int32_t data );


#endif /* MODULE_R_MULTI_DRIVE_LITE_H_ */
 /************************** <END OF FILE> *****************************************/

