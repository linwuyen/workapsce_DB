/*===========================================================================================
    File Name       : COM_Protocol_01.h
    Built Date      : 2012-12-16
	Version         : V1.03a
    Release Date    : Not Yet
    Programmer      : Gear.Feng@trumman.com.tw
    Description     : This file provides the functions of the protocol of communications.
					  Including parameter settings and command.

	Module required:  - UART: For Data transmit.
					  - ModBus_Slave_ASCII: For communication data access.
					  - Parameter: For parameter access.
						
    =========================================================================================
    History         : Reference to the source file.
===========================================================================================*/
/*  Trunmman Technology Corporation. All rights reserved. */
#ifndef COM_PROTOCOL_01_H
#define COM_PROTOCOL_01_H

#include "ModBus_Slave.h"


/*===========================================================================================
   COM_Protocol_01.c setup and function macros
//==========================================================================================*/
#define		HIST_SIZE			32//16                      // Should be setup dedpends on the array.
#define 	COM_ALM_HIS_NUM	 	30//14                      // communication erro history number (last 2 is for the fault major and minor)
#define 	COM_HIST_ARRAY_SIZE	32//16						// Communication error history array size
#define		FAULT_MAJOR			30//14						// ERROR_His_RAM 14 is for Fault_Major.
#define		FAULT_MINOR         31//15                      // ERROR_His_RAM 15 is for Fault_Minor.

/*===========================================================================================
    Read only sector const array
	0 = read only
	1 = W/R (can write to eep)
	2 = by setup (can write to eep)
	3 = by setup (ram only)
//==========================================================================================*/
#define RO_SEC_MAX	7
static const uint8_t Const_RO_SECT[ RO_SEC_MAX ]= { 2, 1, 1, 1, 0, 0, 3 }; // Pa_EEP, Def, Max, Min, MaxMin, RO_EEP, Pa_RAM 

// COM_Error code defines.
enum {
	COM_ERROR_COM_ALARM				= 0x84,			// Basic communication frame or LRC error.
	COM_ERROR_TIME_OUT				= 0x85,			// Communication time out.
	COM_ERROR_CMD_NDF               = 0x88,         // Command incorrect or not support.
	COM_ERROR_BSY_0					= 0x89,			// Driver busy.	( Res )
	COM_ERROR_BSY_1					= 0x8A,			// Driver busy. ( EEP busy )
	COM_ERROR_OUT_RANGE				= 0x8C,			// Data out of range.
	COM_ERROR_CMD_DENY				= 0x8D,			// Command can't execute. ( wrong motor state )
	COM_ERROR_IN_TEST				= 0x8E			// Not support yet, in testing.
};

// Command defines.
enum {
	COM_CMD_ALARM_RESET				= 0,
	
	COM_CMD_PA_RESET				= 32,	// 32 +0
	COM_CMD_IO_RESET				= 33,   // 32 +1
	COM_CMD_ERROR_HISTORY_RESET		= 34,   // 32 +2
	
	COM_CMD_LOAD_ALL_PA_START       = 35,	// 32 +3	// Reserved.
	COM_CMD_LOAD_ALL_PA_DONE		= 36,	// 32 +4    // Reserved.
	
	COM_CMD_WARN_HISTORY_RESET		= 37,	// 32 +5
	COM_CMD_COM_HISTORY_RESET		= 38,	// 32 +6
	COM_CMD_CONFIG					= 39,   // 32 +7
	COM_CMD_ALL_EEP_TO_RAM			= 40,   // 32 +8
	COM_CMD_ALL_RAM_TO_EEP			= 41,   // 32 +9

	COM_CMD_RELOAD_FWEEP			= 42,   // 32 +10
	COM_CMD_RELOAD_HWEEP			= 43    // 32 +11
};

// MasterLevel defines
enum{
	MASTER_LEVEL_0			= 0,
	MASTER_LEVEL_1			= 1,
	MASTER_LEVEL_2		   	= 2,
	MASTER_LEVEL_3			= 3,
	MASTER_LEVEL_PASSWROD	= 123
};

// ComProtocol_01 Flag bit field defines. FlagBITF
enum {
	COM_PA_CHANGE_REALTIME_REQ_BIT 	= 0,

	COM_PA_CHANGE_ALLOWED_BIT 		= 1,	// Parameter flash update avaliable bit
	COM_PA_EEP_SAVE_ALLOWED_BIT 	= 2,	// Parameter eep update avaliable bit
	
	COM_ALM_RESET_REQ_BIT			= 3,	// Alarm reset required bit by communication.
	
	COM_UPDATE_SPECIAL_PA_REQ_BIT	= 4,	// flag indicate to update special parameter.
	
	COM_CONFIG_ENTER_BIT			= 5,    // flag to enter config mode.
	COM_CONFIG_ON_BIT				= 6,	// flag indicate the configuration mode.
	
	COM_CMD_TYPE_BIT				= 7,	// flag indicate the Commmand type write. No memory change.
	
	COM_ALARM_HIS_RESET_REQ_BIT		= 8,	// flag indicate to clear the alarm history.
	COM_WARN_HIS_RESET_REQ_BIT		= 9,	// flag indicate to clear the warning history.
	COM_COM_ERROR_HIS_RESET_REQ_BIT = 10,	// flag indicate to clear the COM_Error history.
	COM_IO_SETUP_RESET_REQ_BIT		= 11,	// flag indicate to set the IO setup parameter to the defauly value. (EEP and RAM)
	COM_PA_SETUP_RESET_REQ_BIT		= 12,   // flag indicate to set the PA setup parameter to the defauly value. (EEP and RAM)
	COM_ALL_SETUP_RESET_REQ_BIT		= 13,   // flag indicate to set the IO and PA setup parameter to the defauly value. (EEP and RAM)
	
	COM_TIME_OUT_BIT				= 15,	// flag indicate com time out ocurred.
	COM_COM_ALM_REQ_BIT				= 16,	// flag indicate com error to cus fault.
	COM_INIT_FINISH_BIT				= 17,	// flag indicate the initializing is finished for time out check.
	
	COM_ALM_RESET_FORBID_BIT		= 18,	// If the motor_state is not fault alarm reset command is not allowed (forbid).
	COM_TIMEOUT_ALM_SAVED_BIT		= 19,   // Save alarm history of timeout save request.
	COM_ERROR_WNG_BIT				= 20,	// Com fault error.
		
	COM_HWEEP_SAVE_ALLOWED_BIT		= 21,	// HW eep update avaliable bit

	COM_PA_LIMIT_CHECK_REQ_BIT		= 22,	// flag indicate that parameter has changed. Value limit check from HWEEP required.

	/*For multi-driver ctrl special FC*/
	//COM_IS_ZERO_SPD_BIT				= 23,	// Is zero speed flag for condition check. 0=speed is not zero, 1=speed is zero.
	COM_REQ_STAMP_SPD_BIT           = 24,   // Current speed stamp request.
	COM_REQ_STAMP_POS_BIT           = 25,   // Current postion stamp request.
	//COM_REQ_CS_BIT	                = 26,   // Position calibration request.

	//COM_IS_MOTOR_STATE_RUNNING		= 27,	// Is motor state running flag for condition check. 0=motor state is not running, 1=motor state is running.
	//COM_IS_MOTOR_STATE_MOVE			= 28,	// Is motor state move flag for condition check. 0=motor state is not move, 1=motor state is move.

	COM_IS_FC101_FAILED				= 29,	// 0=FC101 command normaly executed, 1=FC101 failed to execute.
	COM_IS_FC65_FAILED				= 29,	// 0=FC65 command normaly executed, 1=FC65 failed to execute.

	COM_RELOAD_FWEEP_BIT			= 30,	// flag to reload FWEEP
	COM_RELOAD_HWEEP_BIT			= 31	// flag to reload HWEEP

};
// execute forbid check for each command 
#define CMD_ALM_RESET_FORBID			(_BIT(COM_ALM_RESET_REQ_BIT) | _BIT(COM_ALM_RESET_FORBID_BIT))
#define CMD_CONFIG_FORBID				(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_CONFIG_ENTER_BIT))
#define CMD_ALM_HIS_RESET_FORBID		(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_ALARM_HIS_RESET_REQ_BIT))
#define CMD_WNG_HIS_RESET_FORBID		(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_WARN_HIS_RESET_REQ_BIT))
#define CMD_COM_ERROR_HIS_RESET_FORBID	(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_COM_ERROR_HIS_RESET_REQ_BIT))
#define CMD_IO_RESET_FORBID				(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_IO_SETUP_RESET_REQ_BIT))
#define CMD_PA_RESET_FORBID				(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_PA_SETUP_RESET_REQ_BIT))
#define CMD_RELOAD_FWEEP_FORBID			(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_RELOAD_FWEEP_BIT))
#define CMD_RELOAD_HWEEP_FORBID			(_BIT(COM_PA_CHANGE_REALTIME_REQ_BIT) | _BIT(COM_RELOAD_HWEEP_BIT))
/*===========================================================================================
    Multi-Driver Control Special FC Macros
//==========================================================================================*/

// ASCII Uart data index
enum{
	ASC_IDNUM_H		= 5,			// Modbus ASCII UART data index of ID number H
	ASC_IDNUM_L		= 6,            // Modbus ASCII UART data index of ID number L
	ASC_ID1_H		= 7,			// Modbus ASCII UART data index of ID1_H
	ASC_ID1_L		= 8,            // Modbus ASCII UART data index of ID1_L
	ASC_CMD1_H		= 9,            // Modbus ASCII UART data index of CMD1_H
	ASC_CMD1_L      = 10,           // Modbus ASCII UART data index of CMD1_L
	ASC_DATA		= 11,           // Modbus ASCII UART data starting index of Data

	ASC_POS_DATA	= 11,			// Modbus ASCII UART postion data starting index
	ASC_SPD_DATA	= 15,			// Modbus ASCII UART speed data starting index ( higher bytes are reserved )

	ASC_OFF_SET		= 12,			// Modbus ASCII UART data index offset of each ID
	ASC_BASIC_LENGTH	= 11		// Modbus ASCII UART data basic length
};

// RTU Uart data index
enum{
	RTU_IDNUM		= 2,			// Modbus RTU UART data index of ID number
	RTU_ID1			= 3,			// Modbus RTU UART data index of ID1
	RTU_CMD1		= 4,            // Modbus RTU UART data index of CMD1
	RTU_DATA		= 5,            // Modbus RTU UART data starting index of Data

	RTU_POS_DATA	= 5,			// Modbus RTU UART postion data starting index
	RTU_SPD_DATA	= 7,			// Modbus RTU UART speed data starting index ( higher bytes are reserved )

	RTU_OFF_SET		= 6,			// Modbus RTU UART data index offset of each ID
	RTU_BASIC_LENGTH	= 5		// Modbus RTU UART data basic length
};

enum{
	MULTI_CMD_STOP		= 0,			// Multi command STOP
	MULTI_CMD_JGF		= 1,			// Multi command JGF
	MULTI_CMD_JGR		= 2,            // Multi command JGR
	MULTI_CMD_JGS		= 3,			// Multi command JGS
	MULTI_CMD_JG0		= 4,            // Multi command JG0
	MULTI_CMD_FREE		= 5,			// Multi command FREE
	MULTI_CMD_SVON		= 6,			// Multi command Servo ON
	MULTI_CMD_SVOFF		= 7,			// Multi command Servo OFF

	MULTI_CMD_RST       = 8,            // Multi-Drive-Lite command Alarm Reset
	MULTI_CMD_BRAKE     = 9,            // Multi-Drive-Lite command Motor Short Brake

	MULTI_CMD_JG		= 10,			// Multi command JG
	MULTI_CMD_IMR		= 11,			// Multi command IMR
	MULTI_CMD_MR   		= 12,        	// Multi command MR
	MULTI_CMD_MA		= 13,         	// Multi command MA
	MULTI_CMD_CS		= 14,        	// Multi command CS
	MULTI_CMD_CMR   	= 15,        	// Multi command CMR
	MULTI_CMD_CMA		= 16,         	// Multi command CMA

	MULTI_CMD_NETIO     = 20,

	MULTI_CMD_NULL		= 99,			// Multi command Do Nothing

	MULTI_CMD_NOECHO	= 100,			// Multi command without response

	MULTI_CMD_NULL_AND_NOECHO   = 199

};

enum{
    SECOND_ECHO_STATE_IDLE                  = 0,
    SECOND_ECHO_STATE_MULTI_DRIVE           = 1,
    SECOND_ECHO_STATE_MULTI_DRIVE_LITE      = 2,
    SECOND_ECHO_STATE_NUM                   = 3
};


typedef struct{
	
	uint32_t	FlagBITF;			// Bit field of communication protocol 01.
	uint32_t	WriteEn_BITF;		// Write Enable Bit field.
	int32_t		MasterLevel;		// Master level detected.

	int32_t		*Alm_His_ptr;			// ALM history array pointer
	int32_t		*Wng_His_ptr;           // WNG history array pointer
	int32_t		ERROR_His_RAM 	[ COM_HIST_ARRAY_SIZE ];	// Communication error history. NoteToGear : Data type temp as int32_t for com.
	int32_t		Error;
	
	int32_t		COM_IO_Xn_BITF;
    uint32_t    COM_IO_NormState_BITF;                               // I/O active state.

	int32_t		COM_IO_Yn_BITF[ MULTI_DRIVE_DRIVE_INDEX_NUM ];

	//
	int32_t     Command;

}Struct_ComProtocol_01;


/*===========================================================================================
    Function Name    : variableInitial_COM_Protocol
    Input            : 1. *alm_history: ALM history array pointer.
					   2. *wng_history: WNG history array pointer.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Variable CG_ComProtocol_01 initial
//==========================================================================================*/
void variableInitial_COM_Protocol ( int32_t *alm_history, int32_t *wng_history );

/*===========================================================================================
    Function Name    : com_Protocol_routine
    Input            : 1. *str_modbus : modbus golobal data struct.
					   2. *di_xn_BITF: Ext Xn bit field to update (UART Xn)
					   3. CMD_RUN: command of motor run operation.
					   4. *R_data: Data for one byte HWEEP.
    Return           : result: eep save result. 1:eep ok, 0:eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : com protocol main routine.
					   Ext Xn update. (UART Xn)
//==========================================================================================*/
uint8_t com_Protocol_routine ( Struct_Modbus_Slave *str_modbus, uint32_t *di_xn_BITF, 
							   const uint8_t CMD_RUN, uint8_t *R_data );

/*===========================================================================================
    Function Name    : mB_Execute_routine
    Input            : 1. req_pdu_function_code: ModBus FC to determine the routine to run.
					   2. req_pdu_address_h: data address high byte of modbus.
					   3. req_pdu_address_l: data address low byte of modbus.
					   4. req_pdu_data_quantity: data number
					   5. Response_data: Response data to fill for one byte data.
    Return           : exception code of modbus
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : MB execute routine in broadcast or unicast state.
//==========================================================================================*/
uint8_t mB_Execute_routine ( Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : is_FC6_ok
    Input            : 
					   1. *str_modbus : modbus golobal data struct.					   
    Return           : 
					   return_value: 0=Function failed executed, 1=Function executed fine.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication of FC6
//==========================================================================================*/
uint8_t is_FC6_ok ( Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : is_FC16_ok
    Input            : 1. *str_modbus : modbus golobal data struct.	
    Return           : return_value: 0=Function failed executed, 1=Function executed fine.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Determine the action of FC16 depends on the address_h.
//==========================================================================================*/
uint8_t is_FC16_ok ( Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : command_flag_setup
    Input            : 1. *str_modbus : modbus golobal data struct.
    Return           : return_value: 0=Function failed executed, 1=Function executed fine.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Set the related command flags.
//==========================================================================================*/
uint8_t command_flag_setup ( Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : pa_change_allowed_check
    Input            : 1. mb_adds_h: modbus data address high byte
					   2. mb_adds_l: modbus data address low byte
					   3. mb_data: modbus data value
					   4. Masterlevel: master device level
    Return           : return_value: 0 = Set parameter update req flag to YES
									 1 = Set parameter update req flag to NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to check if parameter can update or not.
					   Check register Address
					   Check Real Time Update
					   Check Read Only					   
					   Check Range
					   Check eep write
//==========================================================================================*/
uint8_t pa_change_allowed_check ( const uint8_t mb_adds_h, const uint8_t mb_adds_l, 
								  const int32_t mb_data, const int32_t MasterLevel );
								  
/*===========================================================================================
    Function Name    : pa_multi_change_allowed_check
    Input            : 1. mb_adds_h: modbus data address high byte
					   2. mb_adds_l: modbus data address low byte
					   3. *mb_data: modbus data array pointer
					   4. data_num: modbus data quantity
					   5. Masterlevel: master device level
    Return           : return_value: 0 = Set parameter update req flag to YES
									 1 = Set parameter update req flag to NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to check if multiple parameter can update or not.
					   Only support parameters and only allowed when motor is not running.
					   Real Time Check (motor state check)
//==========================================================================================*/
uint8_t pa_multi_change_allowed_check ( const uint8_t mb_adds_h,const uint8_t mb_adds_l, 
										int32_t *mb_data, const int32_t data_num, const int32_t MasterLevel );
										
/*===========================================================================================
    Function Name    : pa_BackToDefault
    Input            : 1. major_index: major number of the parameter to reset
    Return           : result: 1=eep ok, 0=eep bad
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Function to set the parameters of a major back to default eep value.
					   Only support parameters and only allowed when motor is not running.
//==========================================================================================*/
uint8_t pa_BackToDefault ( const uint32_t major_index );
										
/*===========================================================================================
    Function Name    : com_CMD_execute_routine
    Input            : NULL
    Return           : return_value: 0=Function failed executed, 1=Function executed fine. 2=eep error.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to execute the command.
//==========================================================================================*/
uint8_t com_CMD_execute_routine ( void );
										
/*===========================================================================================
    Function Name    : com_Error_routine
    Input            : 1. ExceptionCode : The exception code of modbus.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update and check the com error.
//==========================================================================================*/
void com_Error_routine ( const uint8_t ExceptionCode );

/*===========================================================================================
    Function Name    : com_Error_His_update
    Input            : 1. *data: pointer of the data array to update
					   2. data_num: the data quantity of the arrary
					   3. ComErrorNum : The Error number of the COM error.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Update the the history array.
//==========================================================================================*/
void com_HistoryArray_update ( uint32_t *data, const uint32_t data_num, const uint32_t ComErrorNum );

/*===========================================================================================
    Function Name    : com_HistoryArray_Clear
    Input            : 1. *data: pointer of the data array to clear
					   2. data_num: the data quantity of the arrary
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : A routine to clear array (set all value to 0). (WNG, ALM ...etc)
//==========================================================================================*/
void com_HistoryArray_Clear ( uint32_t *data, const uint32_t data_num );

/*===========================================================================================
    Function Name    : com_Init_waiting_Check
    Input            : 1. check_tick : The tick before com protocol timeout to enable.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : waiting for initialize before timeout check.
					   Called in 1 sec or 100ms routine.
//==========================================================================================*/
void com_Init_waiting_Check ( uint8_t check_tick );

/*===========================================================================================
    Function Name    : com_TimeOut_Alm_handler
    Input            : Null
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Communication Time Out handler			   				   
//==========================================================================================*/
void com_TimeOut_Alm_handler ( uint8_t timeout_flag );

/*===========================================================================================
    Function Name    : com_Fault_handler
    Input            : 1. str_modbus : The struct of RS232 or RS485
					   2. receive_flag: the receive state of the modbus data
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Communication fault determine routine. (error that may cause alarm)
					   Set fault flag and clear the counter if the number matched.
					   Called in mb_req_checking()
//==========================================================================================*/
void com_Fault_handler (  Struct_Modbus_Slave *str_modbus, const uint8_t receive_flag );

/*===========================================================================================
    Function Name    : com_HWEEP_Write_allowed_check
    Input            : 1. Masterlevel: master device level
    Return           : return_value: 0 = Set HWEEP update req flag to YES
									 1 = Set HWEEP update req flag to NO
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Protocol routine for the communication to check if HWEEP can update or not.
					   Only allowed when motor is not running. (Real Time Check)
					   Called in is_FC16_ok()
					   2014-12-03 Gear Note: consider only update in Master Level 3 in the future
//==========================================================================================*/
uint8_t com_HWEEP_Write_allowed_check ( const int32_t MasterLevel );

/*===========================================================================================
    Function Name    : com_FC101_Check_ASCII
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw, Chaim.Chen@trumman.com.tw
    Description      : FC101 check routine
//==========================================================================================*/
uint8_t com_FC101_Check_ASCII ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC101_Check_RTU
    Input            : 1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC101 check routine
//==========================================================================================*/
uint8_t com_FC101_Check_RTU ( uint8_t *data, uint32_t data_num, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC101_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC101 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC101_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC102_Check
    Input            :
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC102 check routine
//==========================================================================================*/
uint8_t com_FC102_Check ( uint8_t *data, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_FC102_Processing
    Input            : 1. *data: The data array from the Uart receive buffer.
    				   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : is_frame_ok:  0 = frame error
									 1 = frame ok
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : FC101 processing routine. Get operation data target from uart to modbus buffer.
//==========================================================================================*/
void com_FC102_Processing ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : com_Get_TSPD
    Input            : 1. *data: The data array from the Uart receive buffer.
					   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Get the value of TSPD from uart buffer to modbus buffer.
//==========================================================================================*/
static void com_Get_TSPD ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : com_Get_TPOS
    Input            : 1. *data: The data array from the Uart receive buffer.
					   2. lc_MBscheme: Scheme of Modbus: 0=ASCI, 1=RTU. Set to ASCII as default.
					   3. Modbus buffer to put TSPD.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Get the value of TPOS. From uart buffer to modbus buffer.
					   High byte use 16 bits data. The first 16 bits reserved. Uart data handle depends on Modbus mode.
//==========================================================================================*/
static void com_Get_TPOS ( uint8_t *data, const uint8_t lc_MBscheme, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : com_FC101_CmdSupport_IsOk
    Input            : 1. lc_cmd: command to check
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Check the if the command of multi command FC is supported by the device.
//==========================================================================================*/
static uint8_t com_FC101_CmdSupport_IsOk ( const uint8_t lc_cmd );

/*===========================================================================================
    Function Name    : com_FC101_Execute
    Input            :
    Return           : ExceptionCode. 0=Ok, if BAD return the exception code as SLAVE_DEVICE_FAILURE.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Process multi command depends on the command.
					   Set CMD flags, Get stamp data for echo, Return ExceptionCode.
                       If an error occured, Stamp data then do nothing.
//==========================================================================================*/
static uint8_t com_FC101_Execute ( Struct_Modbus_Slave *str_modbus );


#endif
/************************** <END OF FILE> *****************************************/
