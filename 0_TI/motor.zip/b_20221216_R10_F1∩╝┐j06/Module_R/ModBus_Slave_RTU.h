/*===========================================================================================

    File Name       : ModBus_Slave_RTU.h

    Version         : V1.01a

    Built Date      : 2014/09/23

    Programmer      : Eric.Tsai@trumman.com.tw

    Description     : 
			
    =========================================================================================

    History         : Note : For farther history please reference to source code.
									
===========================================================================================*/

/*  Trunmman Technology Corporation. All rights reserved. */
#ifndef MODBUS_SLAVE_RTU_H_
#define MODBUS_SLAVE_RTU_H_

#include "ModBus_Slave_ASCII.h"


#define MODBUS_FRAME_GAP_LIMIT		( ( CPU_FREQ / 1000000 ) * 1750 )//( ( CPU_FREQ / 1000000 ) * 1750 ) // 1.75ms


enum{
	FRAME_LENGTH_1750US				 = 0,
	FRAME_LENGTH_1500US,
	FRAME_LENGTH_1250US,
	FRAME_LENGTH_1000US,
	FRAME_LENGTH_750US,
	FRAME_LENGTH_500US,
	FRAME_LENGTH_NUM
};

static const uint32_t const_ModbusRTU_FrameLength_Limit[ FRAME_LENGTH_NUM ]= {
		( CPU_FREQ / 1000000 ) * 1750,
		( CPU_FREQ / 1000000 ) * 1500,
		( CPU_FREQ / 1000000 ) * 1250,
		( CPU_FREQ / 1000000 ) * 1000,
		( CPU_FREQ / 1000000 ) * 750,
		( CPU_FREQ / 1000000 ) * 500
};



/*===========================================================================================
    Function Name    : modBus_RegAllocate_485
    Input            :
					   1. HoldingRegMajor : the major arrary of holding register ptr to allocate.
					   2. *holdReg_ptr_target : memory allocate target for holding register.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Map ModBus register to memory address
//==========================================================================================*/
void modBus_RegAllocate_485 ( uint32_t HoldingRegMajor, int32_t *holdReg_ptr_target );

/*===========================================================================================
    Function Name    : variableInitial_ModBus_Slave_485
    Input            :
					   1. slaveID : slave id for the device ( Starting Address )
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Variable CG_Modbus_Slave_485 initial.
					   Salve id setup.
//==========================================================================================*/
void variableInitial_ModBus_Slave_485 (unsigned char slaveID );

/*===========================================================================================
    Function Name    : modBus_TimeOut_Check_485
    Input            : 
					   1. TimeOut_Ticks_Setpoint : the value of ticks to determine modbus timeout.					   
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : This function check if the modbus is timeout in one of the systick routine.
//==========================================================================================*/
void modBus_TimeOut_Check_485 ( int32_t TimeOut_Ticks_Setpoint );

/*===========================================================================================
    Function Name    : data_fill_in_Converter_RTU
    Input            : 
					   1. src : address of src array
					   2. dst : address of dst array
					   3. data_byte_length : total byte length ( ex: move 2 int value = 2 * 2 = 4 bytes )
					   4. data_type : 1 = char, 2 = int, 4 = long
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This is a array copy function, it will copy data from src to dst one by one.
					   Convert unchar into ascii if the data is int.
			           Notice that : It is not a general function, it is designed for modbus data return fuction at FC3 only
					   This Function only support char and int currently.
//==========================================================================================*/
void data_fill_in_Converter_RTU( unsigned char *src,
							 unsigned char *dst,
                             int data_byte_length,
                             int data_type );

/*===========================================================================================
    Function Name    : mb_idle_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : mb idle routine to check the received data.
					   Set to mb_req_checking if uart received data is done. 
//==========================================================================================*/
void mb_idle_RTU ( 	uint8_t *ReceiveFlag,
				uint8_t *data,
				uint32_t data_num,
				uint8_t *T_data,
				uint8_t *T_data_Length,
				uint8_t *T_send_flag,
				uint8_t *T_data_ptr,
				Struct_Modbus_Slave *str_modbus	);

/*===========================================================================================
    Function Name    : mb_req_checking_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : mb request protocol data unit check.
					   Check frame and SlaveID.
					   Set to processing if all check passed.
					   Set to idle if frame check failed.
					   Set to error response if one of the function code, address or data check failed.
					   Set to broadcast ending if function code check failed in broadcast mode.
	LastUpData		 : 2014 0219 
//==========================================================================================*/
void mb_req_checking_RTU ( uint8_t *ReceiveFlag,
					   uint8_t *data,
					   uint32_t data_num,
					   uint8_t *T_data,
					   uint8_t *T_data_Length,
					   uint8_t *T_send_flag,
					   uint8_t *T_data_ptr, 
					   Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : mb_req_processing_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : mb request protocol data unit processing.
					   Set to normal response if processing done without error.
					   Set to Error response if error ocurred while processing.
					   Set to broadcast end after processing regardless error in broadcast mode.
	LastUpData		 : 2014 0219 				   
//==========================================================================================*/
void mb_req_processing_RTU ( uint8_t *ReceiveFlag,
						 uint8_t *data,
						 uint32_t data_num,
						 uint8_t *T_data,
						 uint8_t *T_data_Length,
						 uint8_t *T_send_flag,
						 uint8_t *T_data_ptr, 
						 Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : mb_unicast_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : 
//==========================================================================================*/
void mb_unicast_RTU ( uint8_t *ReceiveFlag,
				  uint8_t *data,
				  uint32_t data_num,
				  uint8_t *T_data,
				  uint8_t *T_data_Length,
				  uint8_t *T_send_flag,
				  uint8_t *T_data_ptr, 
				  Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : mb_broadcast_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : 
//==========================================================================================*/
void mb_broadcast_RTU ( uint8_t *ReceiveFlag,
					uint8_t *data,
				    uint32_t data_num,
				    uint8_t *T_data,
				    uint8_t *T_data_Length,
				    uint8_t *T_send_flag,
				    uint8_t *T_data_ptr,
					Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : mb_normal_reply_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Response the normal message and set back to idle state.
//==========================================================================================*/
void mb_normal_reply_RTU ( uint8_t *ReceiveFlag,
					   uint8_t *data,
				       uint32_t data_num,
				       uint8_t *T_data,
				       uint8_t *T_data_Length,
				       uint8_t *T_send_flag,
				       uint8_t *T_data_ptr,
					   Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : mb_SecondEcho_reply_RTU
    Input            :
                       1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
                           1 = BUSY.
                           2 = DONE.
                       2. *data     : The data array from the Uart receive buffer.
                       3. data_num  : The received data number from the Uart buffer.
                       4. *T_data   : The Uart transmit buffer to put data to send.
                       5. *T_data_Length: The Uart transmit data length to send.
                       6. *T_send_flag  : The Uart transmit require flag.
                       7. *T_data_ptr   : The Uart transmit data pointer.
                       8. Struct_Modbus_Slave *str_modbus   : The struct of RS232 or RS485
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void mb_SecondEcho_reply_RTU ( uint8_t *ReceiveFlag,
                       uint8_t *data,
                       uint32_t data_num,
                       uint8_t *T_data,
                       uint8_t *T_data_Length,
                       uint8_t *T_send_flag,
                       uint8_t *T_data_ptr,
                       Struct_Modbus_Slave *str_modbus
                    );

/*===========================================================================================
    Function Name    : mb_error_reply_RTU
    Input            : 
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Response the error message and set back to idle state.
//==========================================================================================*/
void mb_error_reply_RTU ( uint8_t *ReceiveFlag,
					  uint8_t *data,
				      uint32_t data_num,
				      uint8_t *T_data,
				      uint8_t *T_data_Length,
				      uint8_t *T_send_flag,
				      uint8_t *T_data_ptr,
					  Struct_Modbus_Slave *str_modbus);

/*===========================================================================================
    Function Name    : mb_ADU_frame_check_is_ok_RTU
    Input            : 
					   1. *data: The data from the Modbus buffer. (Uart received data)
					   2. data_num: The received data number from the Uart buffer.
					   3. slaveID : The slave id from the received buffer. ( starting address )
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : return_value: 0 = frame_check failed.
									 1 = frame_check_passed.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the frame and slaveID of the received data from Uart buffer.
//==========================================================================================*/
uint8_t mb_ADU_frame_check_is_ok_RTU ( uint8_t *data, uint32_t data_num, uint8_t slaveID, Struct_Modbus_Slave *str_modbus  );

/*===========================================================================================
    Function Name    : mb_PDU_Address_check_is_ok_RTU
    Input            : 
					   1. add_h : The data address high byte.
					   2. add_L : The data address low byte.
					   3. quantity : the quantity of the data received.
    Return           : return_value: 0 = address check failed.
									 1 = address check passed.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the address of PDU in modbus slave RTU.
					   Note: This function only support FC3, FC6 and FC16.
//==========================================================================================*/
uint8_t mb_PDU_Address_check_is_ok_RTU ( uint8_t add_h, uint8_t add_L, int32_t quantity );

/*===========================================================================================
    Function Name    : mb_PDU_Data_check_is_ok_RTU
    Input            : 
					   1. quantity : The quantity of the data received.
					   2. data_num : The received data number from the Uart buffer.
					   3. FC	   : The function code.
					   4. bytecount: The received byte count.
    Return           : return_value: 0 = data check failed.
									 1 = data check passed.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the data of PDU in modbus slave RTU.
					   Note: This function only support FC3, FC6 and FC16.
//==========================================================================================*/
uint8_t mb_PDU_Data_check_is_ok_RTU ( int32_t quantity, uint32_t data_num, uint8_t FC, int32_t bytecount );

/*===========================================================================================
    Function Name    : mb_Function_FC16_Data_check_is_ok_RTU
    Input            : 
					   1. quantity : The quantity of the data received.
					   2. FC	   : The function code.
					   3. bytecount: The received byte count .
    Return           : return_value: 0 = data check failed.
									 1 = data check passed.
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : Check the data of ( Byte Count == Quantity of Registers x 2 )
					   Note: This function only support FC16.
//==========================================================================================*/
uint8_t mb_Function_FC16_Data_check_is_ok_RTU ( int32_t quantity, uint8_t FC, int32_t bytecount );

/*===========================================================================================
    Function Name    : mb_Frame_Check_RTU
    Input            : 
					   1. *data : Recieved data array to check.
					   2. data_num : data number to be check.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
					   
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the frame of recieved data of modbus (LCR) and return Good or Bad.
//==========================================================================================*/
unsigned char mb_Frame_Check_RTU( unsigned char *data, unsigned char data_num, Struct_Modbus_Slave *str_modbus  );

/*===========================================================================================
    Function Name    : mb_FC_Check_is_Ok_RTU
    Input            : 
					   1. FC : Recieved function code to be check.					   
					   2. address_h : The data address high byte.
					   3. address_l : The data address low byte.
    Return           : 1 = OK, 0 = BAD
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : Check the if the function code is supported by the device. Return the result.
	LastUpData		 : 2014 0219
//==========================================================================================*/
unsigned char mb_FC_Check_is_Ok_RTU ( unsigned char FC, int32_t address_h, int32_t address_l );

/*===========================================================================================
    Function Name    : MB_Function_FC3_RTU
    Input            : 
					   1.Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : FC3 command function to excute.
					   Send requested holding register value to Uart Tx buffer.
//==========================================================================================*/
void mB_Function_FC3_RTU ( Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mB_Function_FC6
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : FC6 command function to excute.
					   Calculate the data to write and prepare the response data.
//==========================================================================================*/
void mB_Function_FC6_RTU ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mB_Function_FC16_RTU
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.				
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : FC16 command function to excute.
					   Calculate the data to write and prepare the response data.
//==========================================================================================*/
void mB_Function_FC16_RTU ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : mB_Function_FC8_RTU
    Input            : 
					   1. data_num 	: The received data number from the Uart buffer.
					   2. *data		: The UART received data buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485			   
    Return           : Null.
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : FC8 command function to excute.
					   Calculate the data to write and prepare the response data.
	LastUpData		 : 2014 0219
//==========================================================================================*/
void mB_Function_FC8_RTU ( uint32_t data_num, uint8_t *data, Struct_Modbus_Slave *str_modbus );

/*===========================================================================================
    Function Name    : crcGenrator
    Input            : 
					   1. *data: data array to be sent.
					   2. length: data array number.
    Return           : outCRC 	: CRC 
    Programmer       : Eric.Tsai@trumman.com.tw
    Description      : 
						
//==========================================================================================*/
unsigned int crcGenrator(unsigned char* data ,int length );

/*===========================================================================================
    Function Name    : mb_normal_response_RTU
    Input            : 
					   1. slaveID : slave ID of the device
					   2. FC : Function Code of the command
					   3. data_num : Requested data number      
			           4. *data : data array to be sent
					   5. *str_Uart : UART golobal data struct to be modified.
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : This function returns Modbus in ModBus_Slave_Response().
//==========================================================================================*/
void mb_normal_response_RTU ( unsigned char slaveID, unsigned char FC,
						  unsigned char data_num, unsigned char *data,
						  unsigned char *T_data, unsigned char *T_data_length,
						  unsigned char *send_data_flag, unsigned char *T_data_Ptr );

/*===========================================================================================
    Function Name    : mb_Error_response_RTU
    Input            : 
					   1. slaveID : slave ID of the device
					   2. error_code : the requested function code
					   3. exception_code : 01 = ILLEGAL FUNCTION      
			                               02 = ILLEGAL DATA ADDRESS
						                   03 = ILLEGAL DATA VALUE
			                               04 = SLAVE DEVICE FAILURE
			           4. exception_mode : 00 = original setting ( have bug ), 01 = normal mode
					   5. *str_Uart : UART golobal data struct to be modified.
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : This function returns Modbus error code.
//==========================================================================================*/
void mb_Error_response_RTU ( 	unsigned char slaveID,
								unsigned char error_code,
								unsigned char exception_code,
								unsigned char exception_mode,
								unsigned char *T_data,
								unsigned char *T_data_length,
								unsigned char *send_data_flag,
								unsigned char *T_data_Ptr );

/*===========================================================================================
    Function Name    : mbRTU_General_FC_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check.
					   Check frame and SlaveID.
					   Set to processing if all check passed.
					   Set to idle if frame check failed.
					   Set to error response if one of the function code, address or data check failed.
					   Set to broadcast ending if function code check failed in broadcast mode.
//==========================================================================================*/
uint8_t mbRTU_General_FC_Check ( 	uint8_t *ReceiveFlag,
									uint8_t *data,
									uint32_t data_num,
									Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mbRTU_FC101_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC101_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mbRTU_FC102_Check
    Input            : 1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
    				   1. *data		: The data array from the Uart receive buffer.
					   2. data_num	: The received data number from the Uart buffer.
					   3. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : mb request protocol data unit check for multi-driver control.
//==========================================================================================*/
uint8_t mbRTU_FC102_Check (	uint8_t *ReceiveFlag,
							uint8_t *data,
							uint32_t data_num,
							Struct_Modbus_Slave *str_modbus
						);

/*===========================================================================================
    Function Name    : mbRTU_SpecialCasting
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Multi-driver ctrl function casting. Repare response data.
//==========================================================================================*/
void mbRTU_SpecialCasting (	 uint8_t *ReceiveFlag,
							 uint8_t *data,
							 uint32_t data_num,
							 uint8_t *T_data,
							 uint8_t *T_data_Length,
							 uint8_t *T_send_flag,
							 uint8_t *T_data_ptr,
							 Struct_Modbus_Slave *str_modbus
						 );

#endif 
/************************** <END OF FILE> *****************************************/
