/*
 * ModBus_Slave.h
 *
 *  Created on: 2015/11/03
 *      Author: chaim.chen
 */
/*  Trunmman Technology Corporation. All rights reserved. */

#ifndef MODBUS_SLAVE_H_
#define MODBUS_SLAVE_H_


#define VICEFUNCTION_ADDRESS_H		0
#define VICEFUNCTION_ADDRESS_L		0

#define COM_CODE_VER		86

#define PROTOCOL_MODE		1	// 0: modbus only, 1: with COM_Protocol_01 module

#define	DATA_OFFSET_RTU		1
#define	DATA_OFFSET_ASCII	2

/*===========================================================================================
    ModBus Basic setup
//==========================================================================================*/
#define MAX_HODLING_REG_MAJOR		132//256 //7
#define MAX_HOLDING_REG_MINOR		32
#define MAX_REG_QUANTITY			MAX_HOLDING_REG_MINOR 	//14
#define ACCESSIBLE_HOLDING_MAJOR	150						// The setting of max major holding in use.
#define ACCESSIBLE_HOLDING_ADDRESS	( ( uint32_t )ACCESSIBLE_HOLDING_MAJOR*256) + MAX_REG_QUANTITY	// The setting of max holding register address in use.

#define BROAD_CAST_ADDRESS			0

#define SLAVE_RETURN_ERROR			1
#define DATA_LOST					2
#define DATA_NORMAL					0

#ifndef NO
#define NO 0
#endif

#ifndef YES
#define YES !NO
#endif

enum{
    MULTI_DRIVE_DRIVE_INDEX_M0  = 0,
    //MULTI_DRIVE_DRIVE_INDEX_M1  = 1,
    //MULTI_DRIVE_DRIVE_INDEX_NUM = 2
    MULTI_DRIVE_DRIVE_INDEX_NUM = 1
};

// Modbus function define
enum{
	MB_FC3		= 0x03,
	MB_FC6		= 0x06,
	MB_FC8      = 0x08,
	MB_FC16		= 0x10,
	MB_FC101	= 0X65,
	MB_FC102	= 0X66,
	MB_FC103	= 0X67,
};

// Modbus related flag bit field "FlagBITF" defines
enum{
	MB_NO_RES_ERROR_BIT			= 0,	// Error without response flag
	MB_BROAD_CAST_BIT			= 1,    // Broad cast mode flag.
	MB_REQ_PDU_RECEIVED_BIT		= 2,    // mb_req_pdu received flag.
	MB_RESPONSE_REQ_BIT			= 3,	// Response required flag
	MB_FC_EXECUTE_REQ_BIT		= 4,	// Modbus command function execute required
	MB_REG_UPDATE_REQ_BIT		= 5,	// Register update required flag.
	MB_FRAME_COM_ALARM_BIT		= 6	// Frame check wrong bit.
};

// Communication Index Constant
enum{
	COM_HW_INFO_INDEX2				= 131,	// HW Info region.
	COM_HW_SN_0_INDEX				= 130,
	COM_HW_INFO_INDEX				= 129,
	COM_CODE_VER_INDEX				= 128,
	COM_MASTER_LV_INDEX				= 100,
	COM_DRIVER_VER_INDEX			= 99,
	COM_FW_VER_INDEX				= 98,
	COM_HW_VER_INDEX				= 97,
	//COM_MAXMIN_REQ_INDEX 			= 40,

	COM_DYNAMIC_DATA_INDEX			= 0,
	COM_PA_EEP_INDEX				= 1,	// from 1 to 9, 0 is reserved for dynamic data for old protocol.
	COM_DEFAULT_EEP_INDEX 			= 11,	// from 11 to 19, 10 is reserved for command type for old protocol.
    COM_MAX_EEP_INDEX 				= 21,	// from 21 to 29
    COM_MIN_EEP_INDEX 				= 31,	// from 31 to 39
	COM_MAXMIN_EEP_INDEX			= 41,	// from 41 to 49 special request reserved.
	COM_RO_EEP_INDEX				= 51,	// from 51 to 59 is Read only EEP region.

	// RAM only
	COM_PA_RAM_INDEX				= 61,	// from 61 to 69 parameter RAM_EEP region.
	COM_MONITOR_DATA_M0_INDEX		= 70,	// Monitor data for user
	COM_RO_RAM_INDEX				= 71,	// from 71 to 79 Read Only RAM region.
	COM_MONITOR_DATA_ENG_INDEX		= 73,	// Monitor data for engineer.
	COM_MONITOR_DATA_M1_INDEX       = 74,   // Monitor data for user

	COM_COMMAND_INDEX				= 10,	// Command type region.
	COM_UART_XIN_INDEX				= 20,   // Uart Input Xn region.
	COM_UART_YOUT_INDEX				= 30,   // Uart Output Yx region.

	COM_MULTI_DRIVE_CMD_M0          = 81,
	COM_MULTI_DRIVE_CMD_M1          = 82,

	COM_MULTI_DRIVE_LITE_CMD_M0     = 91,
    COM_MULTI_DRIVE_LITE_CMD_M1     = 92

};

// Communication for general
#define SHADOW_BUFFER_ADDRESS_L		COM_PA_EEP_INDEX
#define SHADOW_BUFFER_ADDRESS_H		(COM_MIN_EEP_INDEX + MAX_HOLDING_REG_MINOR)

enum{
	Data_Type_One_Byte  = 1,
    Data_Type_Two_Byte  = 2,
    Data_Type_Four_Byte = 4
};

enum{
    ILLEGAL_FUNCTION            = 0x01,
    ILLEGAL_DATA_ADDRESS        = 0x02,
    ILLEGAL_DATA_VALUE          = 0x03,

	ILLEGAL_AGV_SUBID_NUM       = 0x03,
	ILLEGAL_AGV_FORMAT      	= 0x02,

    SLAVE_DEVICE_FAILURE        = 0x04,

    SLAVE_DEVICE_BUSY           = 0x06,

    FORMAT_ERROR                = 0x09
};


enum{
    Modbus_ERROR        = 0x80,

    Modbus_ERROR_FC3    = 0x83,
    Modbus_ERROR_FC6    = 0x86,
    Modbus_ERROR_FC10   = 0x90
};

/*===========================================================================================
    ModBus Slave State Defines
//==========================================================================================*/
enum{
	MB_SLV_IDLE					= 0,
	MB_SLV_REQ_CHECKING			= 1,
	MB_SLV_REQ_PROCESSING       = 2,
	MB_SLV_UNICAST_PROCESSING	= 3,
	MB_SLV_BROADCAST_PROCESSING	= 4,
	MB_SLV_NORMAL_REPLY			= 5,
	MB_SLV_ERROR_REPLY			= 6,
	MB_SLV_SPECIAL_CAST			= 7,	// For multi-driver control
	MB_SLV_MDL_CAST				= 8,	// For multi-drive-lite control

	//MB_SLV_SECONDECHO           = 9,

	//MB_SLV_STATE_NUM			= 10
	MB_SLV_STATE_NUM            = 9
};

/*===========================================================================================
    ModBus Slave serial Transmission Modes select
//==========================================================================================*/
enum{
	MB_SLV_ASCII				= 0,
	MB_SLV_RTU					= 1,
	MB_SLV_TRANS_MODE_NUM       = 2
};

enum{
    //SUB_ID_NUM        = 4,                // Quantity of sub ID
    SUB_ID_NUM      = 15,               // Quantity of sub ID
    SUB_ID_NOECHO   = (SUB_ID_NUM+1),   // Set Echo_Seq to this value if no echo.
};

enum{
    STAMP_RES       = 0,            // Stamp data current position reserve
    STAMP_CPOS_h    = 1,            // Stamp data current position high byte
    STAMP_CPOS_L    = 2,            // Stamp data current position low byte
    STAMP_DIR       = 3,            // Stamp data current direction
    STAMP_SPD       = 4,            // Stamp data current speed
    STAMP_NUM       = 5,            // Stamp data number
};

enum{
    NO_ECHO                     = 0,
    ECHO_BITF_MOTOR_STATE       = 0,
    ECHO_BITF_HALL_CNT_L        = 1,
    ECHO_BITF_ENCODER_POS       = 1,

    ECHO_BITF_SPD               = 2,
    ECHO_BITF_ERROR_INDEX       = 3,
    ECHO_BITF_IO_STATE          = 4,
    ECHO_BITF_BUS_V             = 5,
    ECHO_BITF_SHUNT_I           = 6,

    ECHO_BITF_HALL_CNT_H        = 7,
    ECHO_BITF_ENCODER_INDEX     = 7,

    ECHO_BITF_NUM               = 16
};

/*===========================================================================================
    ModBus Slave Special FC macros
//==========================================================================================*/
#define MB_FC_MUL_CMD_RESP_DATA_NUM		2

#define RESPONSE_DATA_SIZE	200

typedef struct{

    // DeviceID is our major ID
    // When using standard Modbus protocol, it is the Device ID
    // While in multi-drive application
    // Device ID corresponding to Motor 0 's ID
    // And DeviceID_Secondary corresponding to Motor 1 's ID
	uint8_t 	DeviceID;			// Slave ID of the slave device (1~124)
	//uint8_t     DeviceID_Secondary; // M1 device ID in Multi-Drive

	uint8_t 	ExceptionCode;		// Error return exception code
	//uint8_t     ExceptionCode_Secondary;

    //uint32_t    SecondEcho_TP1;
    //uint32_t    SecondEcho_TP2;
    //uint32_t    SecondEcho_StartFlag;

	uint8_t 	ExceptionMode;		// Exception Mode: 0 = original, 1 = normal

	uint8_t 	FlagBITF;			// Modbus related flag bit field
	uint16_t	is_frame_ok;
	uint8_t 	modbus_mode;
	uint8_t 	State;                       				// Modbus slave state

	uint8_t 	Response_data_number;						// Data number in return for response
	uint8_t 	Response_data [ RESPONSE_DATA_SIZE ];		// Data values in return for response

	// Holding register pointer array
	int32_t 	*HoldingRegister_ptr[ MAX_HODLING_REG_MAJOR ];

	// mb_req_pdu
	uint8_t		req_pdu_slaveID;							// SaveID ( starting address ) from the recive buffer.
	uint8_t 	req_pdu_function_code;						// function code from the recieve buffer.
	uint8_t 	req_pdu_address_h;                 		 	// data start address high byte.
	uint8_t 	req_pdu_address_l;                  		// dara start address low byte.
	//uint8_t 	req_pdu_data_buffer[ UART_BUFFER_SIZE ];	// data buffer of modbus.
	int32_t 	req_pdu_data[ MAX_REG_QUANTITY ];			// data value from the recieve buffer.
	int32_t 	req_pdu_data_quantity;						// data quantity from the recieve buffer.
	int32_t 	req_pdu_act_byteCnt;						// the actual byte count of ascii.


	uint8_t		COM_Alm_cnt;		// Com alm counter.
	int32_t		COM_Alm_num;		// Com alm allowed times before com fault.
	int32_t		Time_Out_num;		// number of ticks for time out. 0 = never time out.
	uint32_t 	time_out_cnt;		// timeout counter
	uint8_t 	time_out_flag;		// timeout indicator

	// RTU

	uint16_t 	CRC;
	uint16_t 	D_CRC;

	// Multi CMD
	uint8_t Echo_Driver;
	//uint8_t SecondEcho_State;

	uint8_t SubID_Num;                                  // Sub slave ID quantity
	uint8_t SubID[ SUB_ID_NUM ];                        // All Sub slave ID from the message.
	uint8_t EchoID[ SUB_ID_NUM ];                       // Sub ID that need to response from the message.

    uint8_t MultiCMD_Fail[ MULTI_DRIVE_DRIVE_INDEX_NUM ];

    uint8_t CMD[ MULTI_DRIVE_DRIVE_INDEX_NUM ];          // Command of special FC
    int32_t Data1[ MULTI_DRIVE_DRIVE_INDEX_NUM ];
    int32_t Data2[ MULTI_DRIVE_DRIVE_INDEX_NUM ];
    uint8_t SubID_Seq[ MULTI_DRIVE_DRIVE_INDEX_NUM ];                                   // The sequence of slef sub ID
    uint8_t Echo_Seq[ MULTI_DRIVE_DRIVE_INDEX_NUM ];                                    // The sequence to response. Set to SUB_ID_NUM if no response.

    int32_t MD_STAMP_DATA[ MULTI_DRIVE_DRIVE_INDEX_NUM ][ STAMP_NUM ];                    // Multi-Drive Stamp data
    int32_t MDL_ECHO_DATA[ MULTI_DRIVE_DRIVE_INDEX_NUM ][ ECHO_BITF_NUM ];                // Multi-Drive Lite Stamp data
    int32_t MDL_Echo_BITF[ MULTI_DRIVE_DRIVE_INDEX_NUM ];

	uint8_t MultiCMD_FC_R;                                // Received function code for reply check.

}Struct_Modbus_Slave;


/*===========================================================================================
    Function Name    : modBus_RegAllocate
    Input            : 1. str_modbus : The struct of RS232 or RS485
					   2. HoldingRegMajor : the major arrary of holding register ptr to allocate.
					   3. *holdReg_ptr_target : memory allocate target for holding register.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Map ModBus register to memory address
//==========================================================================================*/
void modBus_RegAllocate ( Struct_Modbus_Slave *str_modbus, uint32_t HoldingRegMajor, int32_t *holdReg_ptr_target );

/*===========================================================================================
    Function Name    : variableInitial_ModBus_Slave
    Input            : 1. str_modbus : The struct of RS232 or RS485
					   2. slaveID : slave id for the device ( Starting Address )
					   3. modbus_protocol : ASCII or RTU
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Variable CG_Modbus_Slave initial.
					   Salve id setup.
//==========================================================================================*/
void variableInitial_ModBus_Slave ( Struct_Modbus_Slave *str_modbus, unsigned char slaveID, uint8_t modbus_protocol );

/*===========================================================================================
    Function Name    : modBus_TimeOut_Check
    Input            : 1. str_modbus : The struct of RS232 or RS485
    				   2. TimeOut_Ticks_Setpoint : the value of ticks to determine modbus timeout.
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : This function check if the modbus is timeout.
//==========================================================================================*/
void modBus_TimeOut_Check ( Struct_Modbus_Slave *str_modbus, uint32_t TimeOut_Ticks_Setpoint );


#endif /* MODULE_D_MODBUS_SLAVE_H_ */



 /************************** <END OF FILE> *****************************************/



