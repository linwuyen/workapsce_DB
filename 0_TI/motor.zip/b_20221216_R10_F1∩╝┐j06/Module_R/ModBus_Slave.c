/*
 * ModBus_Slave.c
 *
 *  Created on: 2015/11/03
 *      Author: chaim.chen
 *     History: 2015-11-09 Gear.Feng
 *					Add FC 101, 102, 103 for multi-driver ctrl.
 */
/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"

/* Gear Test */
//#include "MD.h"
volatile Struct_Modbus_Slave						CG_Modbus_Slave;
volatile Struct_Modbus_Slave						CG_Modbus_Slave_485;

extern volatile Struct_HWEEP						CG_HWEEP;
extern volatile Struct_MD							CG_MD;
extern volatile Struct_Parameter					CG_Parameter;
extern volatile Struct_Pretect 						CG_Protect;
extern volatile Struct_BLDC_CTRL                        CG_BLDC_CTRL_M0;
extern volatile Struct_BLDC_CTRL                        CG_BLDC_CTRL_M1;

#if(PROTOCOL_MODE==1)
extern volatile Struct_ComProtocol_01 CG_ComProtocol_01;
#endif



/*===========================================================================================
    Function Name    : ModBus Slave State machine
    Input            :
					   1. *ReceveFlag: The Uart data status flag to indicate the state of communication.
                           0 = READY.
						   1 = BUSY.
						   2 = DONE.
					   2. *data		: The data array from the Uart receive buffer.
					   3. data_num	: The received data number from the Uart buffer.
					   4. *T_data	: The Uart transmit buffer to put data to send.
					   5. *T_data_Length: The Uart transmit data length to send.
					   6. *T_send_flag	: The Uart transmit require flag.
					   7. *T_data_ptr	: The Uart transmit data pointer.
					   8. Struct_Modbus_Slave *str_modbus	: The struct of RS232 or RS485
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw, Eric.Tsai@trumman.com.tw
    Description      : The modbus slave state machine to handle modbus routines.
//==========================================================================================*/
void ( *const modbus_slave_Handler[MB_SLV_TRANS_MODE_NUM][ MB_SLV_STATE_NUM ] )
														(	uint8_t *ReceiveFlag,	// UART receive flag.
															uint8_t *data,          // UART receive data buffer.
															uint32_t data_num,      // UART receive data number.
															uint8_t *T_data,        // UART transmit data buffer.
															uint8_t *T_data_Length, // UART transmit data length.
															uint8_t *T_send_flag,   // UART data send flag.
															uint8_t *T_data_ptr,    // UART sata send pointer.
															Struct_Modbus_Slave *str_modbus
														 ) =
{
	{ mb_idle,			mb_req_checking,	mb_req_processing,		mb_unicast,
	  mb_broadcast,		mb_normal_reply,	mb_error_reply,
#ifndef MULTI_DRIVE_LITE
	  mb_SpecialCasting, mb_SecondEcho_reply
#else
	  mb_SpecialCasting, mb_MDLCasting//, mb_SecondEcho_reply
#endif
	},
	{ mb_idle_RTU,			mb_req_checking_RTU,	mb_req_processing_RTU,		mb_unicast_RTU,
	  mb_broadcast_RTU,		mb_normal_reply_RTU,	mb_error_reply_RTU,
#ifndef MULTI_DRIVE_LITE
	  mbRTU_SpecialCasting, mb_SecondEcho_reply_RTU
#else
	  mbRTU_SpecialCasting, mbRTU_MDLCasting//,  mb_SecondEcho_reply_RTU
#endif

	}
};


/*===========================================================================================
    Function Name    : modBus_RegAllocate
    Input            : 1. str_modbus : The struct of RS232 or RS485
					   2. HoldingRegMajor : the major arrary of holding register ptr to allocate.
					   3. *holdReg_ptr_target : memory allocate target for holding register.
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Map ModBus register to memory address
//==========================================================================================*/
void modBus_RegAllocate ( Struct_Modbus_Slave *str_modbus, uint32_t HoldingRegMajor, int32_t *holdReg_ptr_target )
{
	str_modbus->HoldingRegister_ptr[HoldingRegMajor] = (int32_t*) ( holdReg_ptr_target );
}


/*===========================================================================================
    Function Name    : variableInitial_ModBus_Slave
    Input            : 1. str_modbus : The struct of RS232 or RS485
					   2. slaveID : slave id for the device ( Starting Address )
					   3. modbus_protocol : ASCII or RTU
    Return           : Null
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : Variable CG_Modbus_Slave initial.
					   Salve id setup.
//==========================================================================================*/
void variableInitial_ModBus_Slave ( Struct_Modbus_Slave *str_modbus, unsigned char slaveID, uint8_t modbus_protocol )
{
	int32_t i = 0;
	int32_t j;

	// Setup device ID
	str_modbus->DeviceID = slaveID;
	//str_modbus->DeviceID_Secondary = slaveID + 1;

	str_modbus->modbus_mode = modbus_protocol;
	str_modbus->State = MB_SLV_IDLE;

	// Added by chaim to give initial values
	str_modbus->FlagBITF = 0;
	str_modbus->time_out_flag = 0;
	str_modbus->time_out_cnt = 0;
	str_modbus->ExceptionCode = 0;
	//str_modbus->ExceptionCode_Secondary = 0;

	str_modbus->Time_Out_num = 0;
	str_modbus->COM_Alm_num  = 0;
	str_modbus->COM_Alm_cnt = 0;
	str_modbus->is_frame_ok = NO;

	//str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_M0;
	str_modbus->Echo_Driver = MULTI_DRIVE_DRIVE_INDEX_NUM;
	//str_modbus->SecondEcho_State = SECOND_ECHO_STATE_IDLE;

	for( i = 0; i < MULTI_DRIVE_DRIVE_INDEX_NUM; i++ ){
	    str_modbus->MultiCMD_Fail[i] = NO;
	    str_modbus->CMD[i] = MULTI_CMD_NULL;
	    str_modbus->Data1[i] = 0;
	    str_modbus->Data2[i] = 0;
	    str_modbus->SubID_Seq[i] = 0;
	    str_modbus->Echo_Seq[i] = SUB_ID_NOECHO;

	    for( j = 0; j < ECHO_BITF_NUM; j++ ){
	        str_modbus->MDL_ECHO_DATA[i][j] = 0;
	    }
	}

	modBus_RegAllocate ( str_modbus, COM_DRIVER_VER_INDEX, (int32_t*)&CG_MD.PN[0] );			// Allocate holding register 99 for HW Part Number
	modBus_RegAllocate ( str_modbus, COM_FW_VER_INDEX, (int32_t*)&CG_MD.FW_Ver[0] );            // Allocate holding register 98 for FW Ver
	modBus_RegAllocate ( str_modbus, COM_HW_VER_INDEX, (int32_t*)&CG_HWEEP.HW_Ver[0] );
	modBus_RegAllocate ( str_modbus, COM_HW_SN_0_INDEX, (int32_t*)&CG_MD.HW_SN[0] );			// Allocate holding register 130 ( Old code SN check command )
	modBus_RegAllocate ( str_modbus, COM_CODE_VER_INDEX, (int32_t*)&CG_MD.Code_Ver[0] );        // Allocate holding register 128 ( Old code ver command )
	modBus_RegAllocate ( str_modbus, COM_HW_INFO_INDEX2, (int32_t*)&CG_HWEEP.HW_Info[0] );
	modBus_RegAllocate ( str_modbus, COM_HW_INFO_INDEX, (int32_t*)&CG_HWEEP.WatchData[0]);

	modBus_RegAllocate ( str_modbus, COM_DYNAMIC_DATA_INDEX, (int32_t*)&CG_Parameter.dynamic_data[0] );

	modBus_RegAllocate ( str_modbus, COM_MONITOR_DATA_M0_INDEX, (int32_t*)&CG_Parameter.Monitor_data_M0[0] );
	//modBus_RegAllocate ( str_modbus, COM_MONITOR_DATA_M1_INDEX, (int32_t*)&CG_Parameter.Monitor_data_M1[0] );

	modBus_RegAllocate ( str_modbus, COM_MONITOR_DATA_ENG_INDEX, (int32_t*)&CG_Parameter.Monitor_data_Engineer[0] );

	//
	modBus_RegAllocate ( str_modbus, COM_COMMAND_INDEX, (int32_t*)&CG_ComProtocol_01.Command );
	//modBus_RegAllocate ( str_modbus, COM_MASTER_LV_INDEX, (int32_t*)&CG_ComProtocol_01.MasterLevel );
	//

	for (i=0; i<PARAMETER_MAJOR_NUM; i++) {	// 1~7, 11~27 ...
		modBus_RegAllocate ( str_modbus, i+COM_PA_EEP_INDEX, 		(int32_t*)&CG_Parameter.EEP_data[i][0] );			// Current value
		modBus_RegAllocate ( str_modbus, i+COM_DEFAULT_EEP_INDEX, 	(int32_t*)&CG_Parameter.EEP_data_default[i][0] ); 	// default value
		modBus_RegAllocate ( str_modbus, i+COM_MAX_EEP_INDEX, 		(int32_t*)&CG_Parameter.EEP_data_max[i][0] );     	// max value
		modBus_RegAllocate ( str_modbus, i+COM_MIN_EEP_INDEX, 		(int32_t*)&CG_Parameter.EEP_data_min[i][0] );     	// min value

		modBus_RegAllocate ( str_modbus, i+COM_PA_RAM_INDEX,		(int32_t*)&CG_Parameter.RAM_data[i][0]);            // Current value ram
	}
	modBus_RegAllocate ( str_modbus, COM_RO_EEP_INDEX,				(int32_t*)&CG_Protect.Alarm_His_EEP[0] );			// Read Only EEP
	modBus_RegAllocate ( str_modbus, COM_RO_RAM_INDEX,				(int32_t*)&CG_Protect.Warning_His_RAM[0] );			// Read Only Ram
	modBus_RegAllocate ( str_modbus, COM_RO_RAM_INDEX+1,			(int32_t*)&CG_ComProtocol_01.ERROR_His_RAM[0] );    // Read Only Ram
	modBus_RegAllocate ( str_modbus, COM_UART_XIN_INDEX,			(int32_t*)&CG_ComProtocol_01.COM_IO_Xn_BITF );      // EXT IO
	modBus_RegAllocate ( str_modbus, COM_UART_YOUT_INDEX,			(int32_t*)&CG_ComProtocol_01.COM_IO_Yn_BITF[MULTI_DRIVE_DRIVE_INDEX_M0] );      // EXT IO Net-IO output


	modBus_RegAllocate ( str_modbus, COM_MULTI_DRIVE_CMD_M0,        (int32_t*)&CG_BLDC_CTRL_M0.MultiDrive_CMD[0] );      // MultiDrive CMD M0
	//modBus_RegAllocate ( str_modbus, COM_MULTI_DRIVE_CMD_M1,        (int32_t*)&CG_BLDC_CTRL_M1.MultiDrive_CMD[0] );      // MultiDrive CMD M1

	modBus_RegAllocate ( str_modbus, COM_MULTI_DRIVE_LITE_CMD_M0,        (int32_t*)&CG_BLDC_CTRL_M0.MultiDriveLite_CMD[0] );      // MultiDrive-Lite CMD M0
    //modBus_RegAllocate ( str_modbus, COM_MULTI_DRIVE_LITE_CMD_M1,        (int32_t*)&CG_BLDC_CTRL_M1.MultiDriveLite_CMD[0] );      // MultiDrive-Lite CMD M1

}

/*===========================================================================================
    Function Name    : modBus_TimeOut_Check
    Input            : 1. str_modbus : The struct of RS232 or RS485
    				   2. TimeOut_Ticks_Setpoint : the value of ticks to determine modbus timeout.
    Return           : Null.
    Programmer       : Gear.Feng@trumman.com.tw
    Description      : This function check if the modbus is timeout.
//==========================================================================================*/
void modBus_TimeOut_Check ( Struct_Modbus_Slave *str_modbus, uint32_t TimeOut_Ticks_Setpoint )
{
	if( str_modbus->State == MB_SLV_IDLE ){
		#if(0)
		if (TimeOut_Ticks_Setpoint != 0) {
			if ( str_modbus->time_out_cnt < TimeOut_Ticks_Setpoint ) {
				str_modbus->time_out_cnt ++;
			} else {
				str_modbus->time_out_flag = YES;
			}
		} else {
			str_modbus->time_out_flag = NO;
		}
		#else

		str_modbus->time_out_cnt += 1;

		if( str_modbus->time_out_cnt > 65535  ){
			str_modbus->time_out_cnt = 65535;
		}

		if (TimeOut_Ticks_Setpoint != 0) {
			if ( str_modbus->time_out_cnt >= TimeOut_Ticks_Setpoint ) {
				str_modbus->time_out_flag = YES;
			}
		} else {
			str_modbus->time_out_flag = NO;
		}


		#endif
	}
}



 /************************** <END OF FILE> *****************************************/


