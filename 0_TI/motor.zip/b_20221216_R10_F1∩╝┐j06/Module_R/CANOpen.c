/*
 * CANOpen.c
 *
 *  Created on: 2020/11/30
 *      Author: chaim.chen
 */

/*  Trunmman Technology Corporation. All rights reserved. */

#include "IncludeFiles.h"
#include "driverlib.h"
#include "device.h"
#include "CANOpen.h"


//extern volatile Struct_UART485  CG_UART485;
extern volatile Struct_Parameter						CG_Parameter;
//extern volatile Struct_Modbus_Slave			        CG_Modbus_Slave_485;
//extern volatile Struct_HWEEP							CG_HWEEP;
extern volatile Struct_MD                               CG_MD;
extern volatile Struct_Modbus_Slave                     CG_Modbus_Slave;
extern volatile Struct_ComProtocol_01                   CG_ComProtocol_01;
extern volatile Struct_Pretect                          CG_Protect;
extern volatile Struct_I2C                              CG_I2C;
extern volatile Struct_BLDC_CTRL                        CG_BLDC_CTRL_M0;
//extern volatile Struct_BLDC_CTRL                        CG_BLDC_CTRL_M1;

const uint32_t Const_CO_ErrorRegister_Mapping[ FAULT_STATE_TOTALNUM ] = {
    0,                              // FAULT_STATE_NO_FAULT        = 0,            // No fault.
    CO_ERR_REG_BIT_1_CURRENT,       // FAULT_STATE_IPM_FAULT       = 1,            // IPM over current fault.                              (Do free)
    CO_ERR_REG_BIT_1_CURRENT,       // FAULT_STATE_LOAD_OVER       = 2,            // Motor running over load.
    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_HALL_FAULT      = 3,            // Hall fault of sensed exceptions.                     (Do free)
    CO_ERR_REG_BIT_2_VOLTAGE,       // FAULT_STATE_BUSV_OVER       = 4,            // Vbus over voltage.                                   (Do free)
    CO_ERR_REG_BIT_2_VOLTAGE,       // FAULT_STATE_BUSV_UNDER      = 5,            // Vbus under voltage.                                  (Do free)
    CO_ERR_REG_BIT_3_TEMP,          // FAULT_STATE_OT_MOS          = 6,

    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_RESTART_FAULT   = 7,            // Failed restart.
    CO_ERR_REG_BIT_7_MANU,          // FAULT_STATE_EEP_ERROR       = 8,
    CO_ERR_REG_BIT_3_TEMP,          // FAULT_STATE_OT_RGN          = 9,
    CO_ERR_REG_BIT_3_TEMP,          // FAULT_STATE_OT_MOTOR        = 10,
    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_MOTOR_COIL      = 11,


    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_SPEED_OVER      = 12,
    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_ENCODER_FAULT   = 13,
    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_PWR_ON_RUN      = 14,
    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_EXT_ERROR       = 15,

    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_PWR_ERROR       = 16,           // Power loss fault.
    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_INIT_SENSOR     = 17,

    CO_ERR_REG_BIT_2_VOLTAGE,       // FAULT_STATE_BUSV_LOW        = 18,           // Vbus low voltage


    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_OVER_TORQUE     = 19,           // Motor running over torque.
    CO_ERR_REG_BIT_0_GENERIC,       // FAULT_STATE_PHASE_FAULT     = 20,           // Hall sensor phase error.

    CO_ERR_REG_BIT_4_COMM,          // FAULT_STATE_COMM_ERROR      = 21,
    CO_ERR_REG_BIT_5_DEVICE         // FAULT_STATE_PARAMETER_ERROR = 22,
};

const uint32_t Const_CO_ErrorCode_Mapping[ FAULT_STATE_TOTALNUM ] = {
    CO_EMC_NO_ERROR,        // FAULT_STATE_NO_FAULT        = 0,            // No fault.
    CO_EMC_CURRENT,         // FAULT_STATE_IPM_FAULT       = 1,            // IPM over current fault.                              (Do free)
    CO_EMC_CURRENT,         // FAULT_STATE_LOAD_OVER       = 2,            // Motor running over load.
    CO_EMC_EXTERNAL_ERROR,  // FAULT_STATE_HALL_FAULT      = 3,            // Hall fault of sensed exceptions.                     (Do free)
    CO_EMC_VOLTAGE,         // FAULT_STATE_BUSV_OVER       = 4,            // Vbus over voltage.                                   (Do free)
    CO_EMC_VOLTAGE,         // FAULT_STATE_BUSV_UNDER      = 5,            // Vbus under voltage.                                  (Do free)
    CO_EMC_TEMPERATURE,     // FAULT_STATE_OT_MOS          = 6,

    CO_EMC_GENERIC,         // FAULT_STATE_RESTART_FAULT   = 7,            // Failed restart.
    CO_EMC_GENERIC,         // FAULT_STATE_EEP_ERROR       = 8,
    CO_EMC_TEMPERATURE,     // FAULT_STATE_OT_RGN          = 9,
    CO_EMC_TEMPERATURE,     // FAULT_STATE_OT_MOTOR        = 10,
    CO_EMC_GENERIC,         // FAULT_STATE_MOTOR_COIL      = 11,


    CO_EMC_GENERIC,         // FAULT_STATE_SPEED_OVER      = 12,
    CO_EMC_EXTERNAL_ERROR,  // FAULT_STATE_ENCODER_FAULT   = 13,
    CO_EMC_GENERIC,         // FAULT_STATE_PWR_ON_RUN      = 14,
    CO_EMC_EXTERNAL_ERROR,  // FAULT_STATE_EXT_ERROR       = 15,

    CO_EMC_GENERIC,         // FAULT_STATE_PWR_ERROR       = 16,           // Power loss fault.
    CO_EMC_EXTERNAL_ERROR,  // FAULT_STATE_INIT_SENSOR     = 17,

    CO_EMC_VOLTAGE,         // FAULT_STATE_BUSV_LOW        = 18,           // Vbus low voltage


    CO_EMC_GENERIC,         // FAULT_STATE_OVER_TORQUE     = 19,           // Motor running over torque.
    CO_EMC_GENERIC,         // FAULT_STATE_PHASE_FAULT     = 20,           // Hall sensor phase error.

    CO_EMC_COMMUNICATION,   // FAULT_STATE_COMM_ERROR      = 21,
    CO_EMC_DATA_SET         // FAULT_STATE_PARAMETER_ERROR = 22,
};

/*===========================================================================================
    Function Name    : coSetupInitial_GCO
    Input            : 1.co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coSetupInitial_GCO( Struct_CANOpen *co )
{
    uint16_t i;
    Struct_CO_GCO   *gco = &co->GCO;

    //gco->DeviceType = ( 0xFFFFUL << 16 ) | ( 0 );
    gco->DeviceType = ( 0UL << 16 ) | ( 0 );
    gco->ErrorRegister = 0;
    gco->ManufacturerStatusRegister = 0;

    //
    gco->PDE_Num = 0;
    for( i = 0; i < CO_PDE_ARRAY_SIZE; i++ ){
        gco->PDE[ i ] = 0;
    }
    //

    gco->COBID_SYNC = CANOPEN_ID_SYNC;
    if( co->Id_Mode == CANID_29BITS ){
        gco->COBID_SYNC |= ( 1UL << 29 );
    }

    gco->CommunicationCyclePeriod = 0;
    gco->SyncWindowsLength = 0;

    gco->ManufacturerDeviceName = (uint8_t*)&CG_MD.PN[0];

    unchar_to_ASCII( CG_MD.HW_Ver, &gco->ManufacturerHardwareVersion[0] );

    gco->ManufacturerSoftwareVersion = (uint8_t*)&CG_MD.FW_Ver[0];

    gco->GuardTime = 0;
    gco->LifrTimeFactor = 0;

    //gco->StoreParameter = 0;
    gco->StoreParameter[ CO_SP_BYTE0_NUMBER_OF_ENTRIES ] = CO_SP_BYTE_NUM - 1;
    gco->StoreParameter[ CO_SP_BYTE1_SAVE_ALL_PARAMETER ] = 0;
    gco->StoreParameter[ CO_SP_BYTE2_SAVE_COMM_PARAMETER ] = 0;
    gco->StoreParameter[ CO_SP_BYTE3_SAVE_APP_PARAMETER ] = 0;
    gco->StoreParameter[ CO_SP_BYTE4_SAVE_MANU_PARAMETER ] = 0;

    //gco->RestoreDefaultParameters = 0;
    gco->RestoreDefaultParameters[ CO_RP_BYTE0_NUMBER_OF_ENTRIES ] = CO_RP_BYTE_NUM - 1;
    gco->RestoreDefaultParameters[ CO_RP_BYTE1_RESET_ALL_PARAMETER ] = 0;
    gco->RestoreDefaultParameters[ CO_RP_BYTE2_RESET_COMM_PARAMETER ] = 0;
    gco->RestoreDefaultParameters[ CO_RP_BYTE3_RESET_APP_PARAMETER ] = 0;
    gco->RestoreDefaultParameters[ CO_RP_BYTE4_RESET_MANU_PARAMETER ] = 0;

    gco->COBID_TimeStamp = 0;
    gco->HighResolutionTimeStamp = 0;
    gco->COBID_EMCY = CANOPEN_ID_EMERGENCY + co->NodeID;
    if( co->Id_Mode == CANID_29BITS ){
        gco->COBID_EMCY |= ( 1UL << 29 );
    }

    gco->InhibitTimeEMCY = 0;
    gco->ComsumerHeartbeatTime = 0;
    gco->ProducerHeartbeatTime = 0;
    gco->Identity_Object = 0;


}

/*===========================================================================================
    Function Name    : coUpdate_ManufacturerStatusRegister
    Input            : 1.co
                       2.status_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coUpdate_ManufacturerStatusRegister( Struct_CANOpen *co, uint32_t alarm_m0 )
{
    Struct_CO_GCO *gco = &co->GCO;
    gco->ManufacturerStatusRegister = ( alarm_m0 );
}


/*===========================================================================================
    Function Name    : coUpdate_PreDefinedErrrorField
    Input            : 1.co
                        2.error
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coUpdate_PreDefinedErrrorField( Struct_CANOpen *co, uint32_t error )
{
    uint8_t i;
    uint32_t  *pde = &co->GCO.PDE[ 0 ];
    for( i = CO_PDE_ARRAY_SIZE - 1; i > 0; i-- ){
        pde[ i ] = pde[ i - 1 ];
    }
    pde[0] = error;
    if( ++co->GCO.PDE_Num > CO_PDE_ARRAY_SIZE ){
        co->GCO.PDE_Num = CO_PDE_ARRAY_SIZE;
    }
}

/*===========================================================================================
    Function Name    : coClear_PreDefinedErrrorField
    Input            : 1.co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coClear_PreDefinedErrrorField( Struct_CANOpen *co )
{
    uint8_t i;
    uint32_t  *pde = &co->GCO.PDE[ 0 ];
    for( i = 0; i < CO_PDE_ARRAY_SIZE; i++ ){
        pde[ i ] = 0;
    }

    co->GCO.PDE_Num = 0;
}

/*===========================================================================================
    Function Name    : coUpdate_ErrorRegister
    Input            : 1.co
                       2.alarm_m0
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coUpdate_ErrorRegister( Struct_CANOpen *co, uint32_t alarm_m0 )
{
    uint32_t error_reg_m0;
    //uint32_t error_reg_m1;
    uint32_t error_code_m0;
    //uint32_t error_code_m1;
    Struct_CO_GCO *gco = &co->GCO;
    Struct_CO_EMCY  *emcy = &co->EMCY;

    if( alarm_m0 == FAULT_STATE_NO_FAULT ){
        error_reg_m0 = 0;
        error_code_m0 = CO_EMC_NO_ERROR;
    }else if( alarm_m0 >= FAULT_STATE_TOTALNUM ){
        error_reg_m0 = ( 1UL << CO_ERR_REG_BIT_0_GENERIC );
        error_code_m0 = CO_EMC_GENERIC;
    }else{
        error_reg_m0 = ( 1UL << Const_CO_ErrorRegister_Mapping[ alarm_m0 ] );
        error_code_m0 = Const_CO_ErrorCode_Mapping[ alarm_m0 ];
    }

    /*
    if( alarm_m1 == FAULT_STATE_NO_FAULT ){
        error_reg_m1 = 0;
        error_code_m1 = CO_EMC_NO_ERROR;
    }else if( alarm_m1 >= FAULT_STATE_TOTALNUM ){
        error_reg_m1 = ( 1UL << CO_ERR_REG_BIT_0_GENERIC );
        error_code_m1 = CO_EMC_GENERIC;
    }else{
        error_reg_m1 = ( 1UL << Const_CO_ErrorRegister_Mapping[ alarm_m1 ] );
        error_code_m1 = Const_CO_ErrorCode_Mapping[ alarm_m1 ];
    }*/

    //gco->ErrorRegister = error_reg_m0 | error_reg_m1;
    gco->ErrorRegister = error_reg_m0;

    //
    if( emcy->Alarm_Old_M0 != alarm_m0 ){
        emcy->Data[ EMCY_OD_BYTE0_ERROR_CODE_L ] = ( error_code_m0 >> 0 ) & 0xFF;
        emcy->Data[ EMCY_OD_BYTE1_ERROR_CODE_H ] = ( error_code_m0 >> 8 ) & 0xFF;
        emcy->Data[ EMCY_OD_BYTE2_ERROR_REG ] = gco->ErrorRegister & 0xFF;

        emcy->Data[ EMCY_OD_BYTE6_ALARM_CODE_M0 ] = alarm_m0;
        emcy->Data[ EMCY_OD_BYTE7_ALARM_CODE_M1 ] = 0;//alarm_m1;

        emcy->Transmit_Flag = YES;
        emcy->Alarm_Old_M0 = alarm_m0;

        //coUpdate_PreDefinedErrrorField( co, ( alarm_m1 << 24 ) | ( alarm_m0 << 16 ) | error_code_m0 );
        coUpdate_PreDefinedErrrorField( co, ( alarm_m0 << 16 ) | error_code_m0 );

    }/*else if( emcy->Alarm_Old_M1 != alarm_m1 ){
        emcy->Data[ EMCY_OD_BYTE0_ERROR_CODE_L ] = ( error_code_m1 >> 0 ) & 0xFF;
        emcy->Data[ EMCY_OD_BYTE1_ERROR_CODE_H ] = ( error_code_m1 >> 8 ) & 0xFF;
        emcy->Data[ EMCY_OD_BYTE2_ERROR_REG ] = gco->ErrorRegister & 0xFF;

        emcy->Data[ EMCY_OD_BYTE6_ALARM_CODE_M0 ] = alarm_m0;
        emcy->Data[ EMCY_OD_BYTE7_ALARM_CODE_M1 ] = alarm_m1;

        emcy->Transmit_Flag = YES;
        emcy->Alarm_Old_M1 = alarm_m1;

        coUpdate_PreDefinedErrrorField( co, ( alarm_m1 << 24 ) | ( alarm_m0 << 16 ) | error_code_m1 );
    }*/

}

/*===========================================================================================
    Function Name    : coSetupInitial_EMCY
    Input            : 1.co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coSetupInitial_EMCY( Struct_CANOpen *co )
{
    uint8_t i;
    Struct_CO_EMCY  *emcy = &co->EMCY;

    emcy->Code = CO_EMC_NO_ERROR;
    emcy->Transmit_Flag = NO;
    for( i = 0; i < CAN_OPEN_DATA_NUM; i++ ){
        emcy->Data[i] = 0;
    }

    emcy->Alarm_Old_M0 = FAULT_STATE_NO_FAULT;
    emcy->Alarm_Old_M1 = FAULT_STATE_NO_FAULT;
}


/*===========================================================================================
    Function Name    : coSetupInitial_PDO_Parameter
    Input            : 1.pdo
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coSetupInitial_PDO_Parameter( Struct_CO_PDO *pdo )
{
    pdo->IsGood_Flag = YES;
    pdo->ToUpdate_Flag = NO;
    pdo->ToTransmit_Flag = NO;
    pdo->ToWait4SYNC_Flag = NO;
    // Parameter
    pdo->Parameter.NumberOfEntries = CO_PDO_NUMBER_OF_ENTRIES;
    pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_01_SYN_CYCLIC;
    pdo->Parameter.InhibitTime_100us = CO_PDO_INHIBIT_TIME_INIT;
    pdo->Parameter.Reserved_04 = 0;
    pdo->Parameter.EventTime_1ms = CO_PDO_EVENT_TIME_INIT;
    pdo->Parameter.SYNC_StartValue = 0;

    // Mapping
    pdo->Mapping.IsUsePtrFlag = NO;
    pdo->Mapping.MappingObject_Num = 0;

    //
    pdo->Byte_Cnt = 0;
    pdo->DLC = 0;
    pdo->EventTimer_1ms = 0;
    pdo->InhibitTimer_100us = 0;
    pdo->SYNC_Cnt = 0;

    pdo->Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO1;

    pdo->Test_Cnt = 0;

}

/*===========================================================================================
    Function Name    : coPDO_CalculateRPDO_ByteCnt
    Input            : 1.co
                       2.pdo
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coPDO_CalculateRPDO_ByteCnt( Struct_CANOpen *co, Struct_CO_PDO *pdo )
{
    uint8_t i;
    uint8_t byte_cnt = 0;
    uint8_t num = pdo->Mapping.MappingObject_Num;
    uint32_t bit_cnt;

    for( i = 0; i < num; i++ ){
        bit_cnt = pdo->Mapping.MappingObjec[ i ] & 0xFF;
        if( bit_cnt <= 8 ){
            byte_cnt += 1;
        }else{
            byte_cnt += 2;
        }
    }

    if( byte_cnt <= CAN_OPEN_DATA_NUM ){
        pdo->Byte_Cnt = byte_cnt;
    }else{
        pdo->Byte_Cnt = CAN_OPEN_DATA_NUM;
        // Error
        co->EMCY_State = CO_EMC_PDO_LENGTH_EXC;
        //co->EMCY.Code = CO_EMC_PDO_LENGTH_EXC;
    }
}

/*===========================================================================================
    Function Name    : coPDO_SetTrigTypeFromPa_RPDO
    Input            : pa
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coPDO_SetTrigTypeFromPa_RPDO( Struct_CO_PDO *pdo, uint8_t pa )
{
    switch( pa ){
    case 0:
    default:
        pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        break;
    case 1:
    case 2:
    case 3:
    case 4:
        pdo->Parameter.TransmissionType = pa;
        break;
    }
}

/*===========================================================================================
    Function Name    : coPDO_GetTrigTypeFromPa_TPDO
    Input            : pa
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coPDO_SetTrigTypeFromPa_TPDO( Struct_CO_PDO *pdo, uint8_t pa )
{
    const uint16_t const_time_ms[ 16 ] = { 0,   0,   0,   0,
                                           0,   0,   0,   0,
                                           0,  10,  25,  50,
                                         100, 250, 500, 1000 };

    switch( pa ){
    case 0:
    case 5:
        pdo->Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO1;
        pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        break;
    case 6:
        pdo->Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO2;
        pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        break;
    case 7:
        pdo->Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO3;
        pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        break;
    case 8:
        pdo->Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO4;
        pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        break;
    case 1:
    case 2:
    case 3:
    case 4:
        pdo->Parameter.TransmissionType = pa;
        break;
    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
        pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_DEVICE_PROFILE;
        pdo->Parameter.EventTime_1ms = const_time_ms[ pa ];
        break;
    default:
        pdo->Parameter.TransmissionType = CO_PDO_TRANS_TYPE_01_SYN_CYCLIC;
        break;

    }
}

/*===========================================================================================
    Function Name    : coSetupInitial_PDO
    Input            : 1.co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coSetupInitial_PDO( Struct_CANOpen *co )
{
    uint32_t data_cnt = 0;

    uint16_t trigger_type_rpdo = CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CANOPEN_RPDO_TRIGGER_TYPE ];
    uint16_t trigger_type_tpdo = CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CANOPEN_TPDO_TRIGGER_TYPE ];
    uint16_t trigger_type_rpdo1;
    uint16_t trigger_type_rpdo2;
    uint16_t trigger_type_rpdo3;
    uint16_t trigger_type_rpdo4;

    uint16_t trigger_type_tpdo1;
    uint16_t trigger_type_tpdo2;
    uint16_t trigger_type_tpdo3;
    uint16_t trigger_type_tpdo4;

    co->TPDO1_ID = CANOPEN_ID_TPDO1 + co->NodeID;
    co->TPDO1.Parameter.COB_ID = co->TPDO1_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->TPDO1.Parameter.COB_ID |= ( 1UL << 29 );
    }

    //
    co->TPDO2_ID = CANOPEN_ID_TPDO2 + co->NodeID;
    co->TPDO2.Parameter.COB_ID = co->TPDO2_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->TPDO2.Parameter.COB_ID |= ( 1UL << 29 );
    }
    //
    co->TPDO3_ID = CANOPEN_ID_TPDO3 + co->NodeID;
    co->TPDO3.Parameter.COB_ID = co->TPDO3_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->TPDO3.Parameter.COB_ID |= ( 1UL << 29 );
    }
    //
    co->TPDO4_ID = CANOPEN_ID_TPDO4 + co->NodeID;
    co->TPDO4.Parameter.COB_ID = co->TPDO4_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->TPDO4.Parameter.COB_ID |= ( 1UL << 29 );
    }

    //
    co->RPDO1_ID = CANOPEN_ID_RPDO1 + co->NodeID;
    co->RPDO1.Parameter.COB_ID = co->RPDO1_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->RPDO1.Parameter.COB_ID |= ( 1UL << 29 );
    }
    //
    co->RPDO2_ID = CANOPEN_ID_RPDO2 + co->NodeID;
    co->RPDO2.Parameter.COB_ID = co->RPDO2_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->RPDO2.Parameter.COB_ID |= ( 1UL << 29 );
    }
    //
    co->RPDO3_ID = CANOPEN_ID_RPDO3 + co->NodeID;
    co->RPDO3.Parameter.COB_ID = co->RPDO3_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->RPDO3.Parameter.COB_ID |= ( 1UL << 29 );
    }
    //
    co->RPDO4_ID = CANOPEN_ID_RPDO4 + co->NodeID;
    co->RPDO4.Parameter.COB_ID = co->RPDO4_ID;
    if( co->Id_Mode == CANID_29BITS ){
        co->RPDO4.Parameter.COB_ID |= ( 1UL << 29 );
    }

#if( CANOPEN_DISABLE_SUPPORT_RTR )
    co->TPDO1.Parameter.COB_ID |= ( 1UL << 30 ); // 0 : RTR allowed on this PDO; 1 : no RTR allowed on this PDO
    co->TPDO2.Parameter.COB_ID |= ( 1UL << 30 );
    co->TPDO3.Parameter.COB_ID |= ( 1UL << 30 );
    co->TPDO4.Parameter.COB_ID |= ( 1UL << 30 );

    co->RPDO1.Parameter.COB_ID |= ( 1UL << 30 ); // 0 : RTR allowed on this PDO; 1 : no RTR allowed on this PDO
    co->RPDO2.Parameter.COB_ID |= ( 1UL << 30 );
    co->RPDO3.Parameter.COB_ID |= ( 1UL << 30 );
    co->RPDO4.Parameter.COB_ID |= ( 1UL << 30 );
#endif


    coSetupInitial_PDO_Parameter( &co->TPDO1 );
    coSetupInitial_PDO_Parameter( &co->TPDO2 );
    coSetupInitial_PDO_Parameter( &co->TPDO3 );
    coSetupInitial_PDO_Parameter( &co->TPDO4 );

    coSetupInitial_PDO_Parameter( &co->RPDO1 );
    coSetupInitial_PDO_Parameter( &co->RPDO2 );
    coSetupInitial_PDO_Parameter( &co->RPDO3 );
    coSetupInitial_PDO_Parameter( &co->RPDO4 );

    trigger_type_rpdo1 = ( trigger_type_rpdo >> 0 ) & 0x0F;
    trigger_type_rpdo2 = ( trigger_type_rpdo >> 4 ) & 0x0F;
    trigger_type_rpdo3 = ( trigger_type_rpdo >> 8 ) & 0x0F;
    trigger_type_rpdo4 = ( trigger_type_rpdo >> 12 ) & 0x0F;

    trigger_type_tpdo1 = ( trigger_type_tpdo >> 0 ) & 0x0F;
    trigger_type_tpdo2 = ( trigger_type_tpdo >> 4 ) & 0x0F;
    trigger_type_tpdo3 = ( trigger_type_tpdo >> 8 ) & 0x0F;
    trigger_type_tpdo4 = ( trigger_type_tpdo >> 12 ) & 0x0F;


    coPDO_SetTrigTypeFromPa_TPDO( &co->TPDO1, trigger_type_tpdo1 );
    coPDO_SetTrigTypeFromPa_TPDO( &co->TPDO2, trigger_type_tpdo2 );
    coPDO_SetTrigTypeFromPa_TPDO( &co->TPDO3, trigger_type_tpdo3 );
    coPDO_SetTrigTypeFromPa_TPDO( &co->TPDO4, trigger_type_tpdo4 );

    coPDO_SetTrigTypeFromPa_RPDO( &co->RPDO1, trigger_type_rpdo1 );
    coPDO_SetTrigTypeFromPa_RPDO( &co->RPDO2, trigger_type_rpdo2 );
    coPDO_SetTrigTypeFromPa_RPDO( &co->RPDO3, trigger_type_rpdo3 );
    coPDO_SetTrigTypeFromPa_RPDO( &co->RPDO4, trigger_type_rpdo4 );

    if( trigger_type_tpdo1 == 0 ){
        co->TPDO1.Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO1;
    }
    if( trigger_type_tpdo2 == 0 ){
        co->TPDO2.Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO2;
    }
    if( trigger_type_tpdo3 == 0 ){
        co->TPDO3.Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO3;
    }
    if( trigger_type_tpdo4 == 0 ){
        co->TPDO4.Trig_MailBox_ID = MAIL_BOX_INDEX_RPDO4;
    }

#define SDO_SUBINDEX_OFFSET     1

    switch( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CANOPEN_PDO_MAPPING_SELECT ] ){

    case CANOPEN_PDO_MAPPING_SELECT_ENCODER:
    default:
        // Size in bytes:    1      /     1      /        2      /       2       /     2
        // Set TPDO1 :  M0: Motor State / Alarm Code / Current Speed / Encoder Index / Encoder Pos
        data_cnt = 0;
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 0 << 8 ) = M0: Motor State
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (1+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 1 << 8 ) = M0: Alarm Code
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (4+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 4 << 8 ) = M0: Current Speed
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (21+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M0: Encoder Index
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (22+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 22 << 8 ) = M0: Encoder Pos
        co->TPDO1.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes:    1      /     1      /        2      /       2       /     2
        // Set TPDO2 :  M1: Motor State / Alarm Code / Current Speed / Encoder Index / Encoder Pos
        data_cnt = 0;
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 0 << 8 ) = M1: Motor State
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (1+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 1 << 8 ) = M1: Alarm Code
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (4+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 4 << 8 ) = M1: Current Speed
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (21+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M1: Encoder Index
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (22+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 22 << 8 ) = M1: Encoder Pos
        co->TPDO2.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes:   2    /     2   /    2     /    2
        // Set TPDO3 :  M0: Duty / Shunt I / M1: Duty / Shunt I
        data_cnt = 0;
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (8+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 8 << 8 ) = M0: Duty
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M0: Current
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (8+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 8 << 8 ) = M1: Duty
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M1: Current
        co->TPDO3.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes: 2   /        1       /        1        /      2 x n
        // Set TPDO1 :  Bus V / IO Input State / IO Output State / Analog Inputs ( AxIN )
        data_cnt = 0;
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (7+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 7 << 8 ) = BusV
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (5+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 5 << 8 ) = IO IN
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (17+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 17 << 8 ) = IO Out
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (13+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 13 << 8 ) = A1X
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (14+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 14 << 8 ) = A2X
        co->TPDO4.Mapping.MappingObject_Num = data_cnt;


        // RPDO
        // Size in bytes:          1        /            2          /           2
        // Set RPDO1 :   M0: MultiDrive CMD / M0: MultiDrive Data 1 / M0: MultiDrive Data 2
        data_cnt = 0;
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 81UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 81, 0 ) = M0: MultiDrive CMD
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 81UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 81, 1 ) = M0: MultiDrive Data 1
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 81UL << 16 ) | ( 3 << 8 ) | ( 16 ); // ( 81, 2 ) = M0: MultiDrive Data 2
        co->RPDO1.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO1.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO1 );

        // Size in bytes:          1        /            2          /           2
        // Set RPDO1 :   M1: MultiDrive CMD / M1: MultiDrive Data 1 / M1: MultiDrive Data 2
        data_cnt = 0;
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 82UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 82, 0 ) = M1: MultiDrive CMD
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 82UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 82, 1 ) = M1: MultiDrive Data 1
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 82UL << 16 ) | ( 3 << 8 ) | ( 16 ); // ( 82, 2 ) = M1: MultiDrive Data 2
        co->RPDO2.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO2.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO2 );

        // Size in bytes:   2   /         2         /          2        /
        // Set RPDO3 :   Net-IO / M0: Digit Speed 0 / M1: Digit Speed 0 /
        data_cnt = 0;
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 20UL << 16 ) | ( 0 << 8 ) | ( 16 ); // ( 20, 0 ) = Net-IO
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 63UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 63, 0 ) = M0: Digit Speed 0
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 63UL << 16 ) | ( (16+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 63, 16 ) = M1: Digit Speed 0
        co->RPDO3.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO3.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO3 );

        // Size in bytes:           1           /            2            /            1          /             2
        // Set RPDO4 :   M0: MultiDrive-Lie CMD / M0: MultiDrive-Lie Data / M1: MultiDrive-Lie CMD / M1: MultiDrive-Lie Data
        data_cnt = 0;
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 91, 0 ) = M0: MultiDrive-Lite CMD
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 91, 1 ) = M0: MultiDrive-Lite Data
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 92, 0 ) = M1: MultiDrive-Lite CMD
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 92, 1 ) = M1: MultiDrive-Lite Data
        co->RPDO4.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO4.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO4 );

        break;

    case CANOPEN_PDO_MAPPING_SELECT_HALL:

        // Size in bytes:        1      /     1      /        2      /    2    /    2
        // Set TPDO1 :  M0: Motor State / Alarm Code / Current Speed / Current / Hall Cnt
        data_cnt = 0;
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 0 << 8 ) = M0: Motor State
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (1+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 1 << 8 ) = M0: Alarm Code
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (4+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 4 << 8 ) = M0: Current Speed
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M0: Current
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (18+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 18 << 8 ) = M0: Hall Cnt
        co->TPDO1.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes:        1      /     1      /        2      /    2    /    2
        // Set TPDO2 :  M1: Motor State / Alarm Code / Current Speed / Current / Hall Cnt
        data_cnt = 0;
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 0 << 8 ) = M1: Motor State
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (1+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 1 << 8 ) = M1: Alarm Code
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (4+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 4 << 8 ) = M1: Current Speed
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M1: Current
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (18+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 22 << 8 ) = M1: Hall Cnt
        co->TPDO2.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes:   2    /     2   /    2     /    2
        // Set TPDO3 :  M0: Duty / Shunt I / M1: Duty / Shunt I
        data_cnt = 0;
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (8+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 8 << 8 ) = M0: Duty
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M0: Current
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (8+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 8 << 8 ) = M1: Duty
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M1: Current
        co->TPDO3.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes: 2   /        1       /        1        /      2 x n
        // Set TPDO1 :  Bus V / IO Input State / IO Output State / Analog Inputs ( AxIN )
        data_cnt = 0;
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (7+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 7 << 8 ) = BusV
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (5+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 5 << 8 ) = IO IN
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (17+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 17 << 8 ) = IO Out
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (13+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 13 << 8 ) = A1X
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (14+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 14 << 8 ) = A2X
        co->TPDO4.Mapping.MappingObject_Num = data_cnt;


        // RPDO
        // Size in bytes:            1           /             2
        // Set RPDO1 :   M0: MultiDrive-Lite CMD / M0: MultiDrive-Lite Data
        data_cnt = 0;
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 91, 0 ) = M0: MultiDrive-Lite CMD
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 91, 1 ) = M0: MultiDrive-Lite Data
        co->RPDO1.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO1.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO1 );

        // Size in bytes:            1           /             2
        // Set RPDO1 :   M0: MultiDrive-Lite CMD / M0: MultiDrive-Lite Data
        data_cnt = 0;
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 92, 0 ) = M1: MultiDrive-Lite CMD
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 92, 1 ) = M1: MultiDrive-Lite Data
        co->RPDO2.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO2.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO2 );

        // Size in bytes:   2   /         2         /          2        /
        // Set RPDO3 :   Net-IO / M0: Digit Speed 0 / M1: Digit Speed 0 /
        data_cnt = 0;
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 20UL << 16 ) | ( 0 << 8 ) | ( 16 ); // ( 20, 0 ) = Net-IO
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 63UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 63, 0 ) = M0: Digit Speed 0
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 63UL << 16 ) | ( (16+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 63, 16 ) = M1: Digit Speed 0
        co->RPDO3.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO3.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO3 );

        // Size in bytes:           1           /            2            /            1          /             2
        // Set RPDO4 :   M0: MultiDrive-Lie CMD / M0: MultiDrive-Lie Data / M1: MultiDrive-Lie CMD / M1: MultiDrive-Lie Data
        data_cnt = 0;
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 91, 0 ) = M0: MultiDrive-Lite CMD
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 91, 1 ) = M0: MultiDrive-Lite Data
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 92, 0 ) = M1: MultiDrive-Lite CMD
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 92, 1 ) = M1: MultiDrive-Lite Data
        co->RPDO4.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO4.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO4 );

        break;

    case CANOPEN_PDO_MAPPING_SELECT_GPM:

        // Size in bytes:        1      /     1      /        2      /    2    /   2
        // Set TPDO1 :  M0: Motor State / Alarm Code / Current Speed /  Bus V  / Shunt I
        data_cnt = 0;
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 0 << 8 ) = M0: Motor State
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (1+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 1 << 8 ) = M0: Alarm Code
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (4+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 4 << 8 ) = M0: Current Speed
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (7+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 7 << 8 ) = BusV
        co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M0: Current

        //co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (21+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M0: Encoder Index
        //co->TPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (22+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 22 << 8 ) = M0: Encoder Pos
        co->TPDO1.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes:        1      /     1      /        2      /    2    /   2
        // Set TPDO2 :  M1: Motor State / Alarm Code / Current Speed /  Bus V  / Shunt I
        data_cnt = 0;
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 0 << 8 ) = M1: Motor State
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (1+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 1 << 8 ) = M1: Alarm Code
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (4+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 4 << 8 ) = M1: Current Speed
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (7+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 7 << 8 ) = BusV
        co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M1: Current

        //co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (21+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M1: Encoder Index
        //co->TPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (22+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 22 << 8 ) = M1: Encoder Pos
        co->TPDO2.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes:   2    /   2   /    2     /   2
        // Set TPDO3 : M0: Index /  Pos / M1: Index /  Pos
        data_cnt = 0;
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (21+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M0: Encoder Index
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (22+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 22 << 8 ) = M0: Encoder Pos
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (21+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 21 << 8 ) = M1: Encoder Index
        co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (22+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 22 << 8 ) = M1: Encoder Pos
        //co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (8+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 8 << 8 ) = M0: Duty
        //co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M0: Current
        //co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (8+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 8 << 8 ) = M1: Duty
        //co->TPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 74UL << 16 ) | ( (9+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 9 << 8 ) = M1: Current
        co->TPDO3.Mapping.MappingObject_Num = data_cnt;

        // Size in bytes: 2   /        1       /        1        /      2 x n
        // Set TPDO1 :  Bus V / IO Input State / IO Output State / Analog Inputs ( AxIN )
        data_cnt = 0;
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (7+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 7 << 8 ) = BusV
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (5+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 5 << 8 ) = IO IN
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (17+SDO_SUBINDEX_OFFSET) << 8 ) | ( 8 ); // ( 17 << 8 ) = IO Out
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (13+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 13 << 8 ) = A1X
        co->TPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 70UL << 16 ) | ( (14+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 14 << 8 ) = A2X
        co->TPDO4.Mapping.MappingObject_Num = data_cnt;


        // RPDO
        // Size in bytes:          1        /            2          /           2
        // Set RPDO1 :   M0: MultiDrive CMD / M0: MultiDrive Data 1 / M0: MultiDrive Data 2
        data_cnt = 0;
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 81UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 81, 0 ) = M0: MultiDrive CMD
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 81UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 81, 1 ) = M0: MultiDrive Data 1
        co->RPDO1.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 81UL << 16 ) | ( 3 << 8 ) | ( 16 ); // ( 81, 2 ) = M0: MultiDrive Data 2
        co->RPDO1.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO1.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO1 );

        // Size in bytes:          1        /            2          /           2
        // Set RPDO1 :   M1: MultiDrive CMD / M1: MultiDrive Data 1 / M1: MultiDrive Data 2
        data_cnt = 0;
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 82UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 82, 0 ) = M1: MultiDrive CMD
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 82UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 82, 1 ) = M1: MultiDrive Data 1
        co->RPDO2.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 82UL << 16 ) | ( 3 << 8 ) | ( 16 ); // ( 82, 2 ) = M1: MultiDrive Data 2
        co->RPDO2.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO2.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO2 );

        // Size in bytes:   2   /         2         /          2        /
        // Set RPDO3 :   Net-IO / M0: Digit Speed 0 / M1: Digit Speed 0 /
        data_cnt = 0;
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 20UL << 16 ) | ( 0 << 8 ) | ( 16 ); // ( 20, 0 ) = Net-IO
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 63UL << 16 ) | ( (0+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 63, 0 ) = M0: Digit Speed 0
        co->RPDO3.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 63UL << 16 ) | ( (16+SDO_SUBINDEX_OFFSET) << 8 ) | ( 16 ); // ( 63, 16 ) = M1: Digit Speed 0
        co->RPDO3.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO3.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO3 );

        // Size in bytes:           1           /            2            /            1          /             2
        // Set RPDO4 :   M0: MultiDrive-Lie CMD / M0: MultiDrive-Lie Data / M1: MultiDrive-Lie CMD / M1: MultiDrive-Lie Data
        data_cnt = 0;
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 91, 0 ) = M0: MultiDrive-Lite CMD
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 91UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 91, 1 ) = M0: MultiDrive-Lite Data
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 1 << 8 ) | ( 8 ); // ( 92, 0 ) = M1: MultiDrive-Lite CMD
        co->RPDO4.Mapping.MappingObjec[data_cnt++] = ( OD_INDEX_PARAMETER << 24 ) | ( 92UL << 16 ) | ( 2 << 8 ) | ( 16 ); // ( 92, 1 ) = M1: MultiDrive-Lite Data
        co->RPDO4.Mapping.MappingObject_Num = data_cnt;
        //co->RPDO4.Parameter.TransmissionType = CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER;
        coPDO_CalculateRPDO_ByteCnt( co, &co->RPDO4 );

        break;
    }

}


/*===========================================================================================
    Function Name    : coPDO_UpdateTPDO
    Input            : 1.co
                       2.pdo
                       3.data
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coPDO_UpdateTPDO( Struct_CANOpen *co, Struct_CO_PDO *pdo, uint16_t *data )
{
    uint8_t i;
    uint8_t num = pdo->Mapping.MappingObject_Num;
    uint8_t size = 8;
    uint32_t value = 0;
    uint16_t index;
    uint8_t sub_index;
    uint32_t object;
    uint8_t byte_cnt = 0;
    uint32_t* mapping_data;

    for( i = 0; i < num; i++ ){

        object = pdo->Mapping.MappingObjec[i];

        size = ( object >> 0 ) & 0xFF;

        if( pdo->Mapping.IsUsePtrFlag ){
            mapping_data = pdo->Mapping.MappingPtr[i];
        }else{
            index = ( object >> 16 ) & 0xFFFF;
            sub_index = ( object >> 8 ) & 0xFF;
            co_GetObject( co, index, sub_index );
            if( co->Current_OBject.ReadWrite != CO_RW_WRITE_ONLY ){
                mapping_data = (uint32_t*)co->Current_OBject.pData;
                pdo->Mapping.MappingPtr[i] = mapping_data;
            }else{
                pdo->Mapping.MappingPtr[i] = (uint32_t*)&co->SDO_OBject_Null;
                pdo->IsGood_Flag = NO;
            }
        }

        if( size <= 8 ){
            value = ( *mapping_data ) & 0xFF;
            data[ byte_cnt++ ] = value;
            //pdo->Byte_Cnt = byte_cnt;
            if( byte_cnt >= CAN_OPEN_DATA_NUM ){
                return;
            }
        }else{
            value = ( *mapping_data ) & 0xFFFF;
            data[ byte_cnt++ ] = value & 0xFF;
            //pdo->Byte_Cnt = byte_cnt;
            if( byte_cnt >= CAN_OPEN_DATA_NUM ){
                return;
            }
            data[ byte_cnt++ ] = ( value >> 8 ) & 0xFF;
            //pdo->Byte_Cnt = byte_cnt;
            if( byte_cnt >= CAN_OPEN_DATA_NUM ){
                return;
            }
        }

    }

    for( i = byte_cnt; i < CAN_OPEN_DATA_NUM; i++ ){
        data[ i ] = 0;
    }

}

/*===========================================================================================
    Function Name    : coPDO_TPDO_Excute
    Input            : 1.mail_box_id
                       2.co
                       3.pdo
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coPDO_TPDO_Excute( uint32_t mail_box_id, Struct_CANOpen *co, Struct_CO_PDO *pdo )
{
    uint8_t is_event_timer_work = NO;
    uint8_t is_pdo_valid = NO;
    uint8_t is_asyn_falg = NO;

    if( pdo->Mapping.MappingObject_Num != 0 ){

        if( pdo->IsGood_Flag ){

            if( pdo->Parameter.TransmissionType == CO_PDO_TRANS_TYPE_00_SYN_ACYCLIC ){
                is_event_timer_work = YES;
                if( co->SYNC_Flag ){
                    pdo->ToTransmit_Flag = YES;
                }
            }else if( pdo->Parameter.TransmissionType >= CO_PDO_TRANS_TYPE_01_SYN_CYCLIC && // 1 ~ 240
                      pdo->Parameter.TransmissionType <  CO_PDO_TRANS_TYPE_01_SYN_CYCLIC + 240 ){
                if( co->SYNC_Flag ){

                    if( co->SYNC_Cnt != 0 ){
                        if( co->SYNC_Cnt == pdo->Parameter.SYNC_StartValue ){
                            pdo->SYNC_Cnt = 0;
                        }
                    }

                    if( ++pdo->SYNC_Cnt >= pdo->Parameter.TransmissionType ){
                        pdo->SYNC_Cnt = 0;
                        pdo->ToUpdate_Flag = YES;
                        pdo->ToTransmit_Flag = YES;
                    }
                }
            }else if( pdo->Parameter.TransmissionType == CO_PDO_TRANS_TYPE_FE_ASYN_MANUFACTURER ){
                is_asyn_falg = YES;
                if( ( co->MailBox_BITF >> ( pdo->Trig_MailBox_ID ) ) & 0x01 ){
                    pdo->ToUpdate_Flag = YES;
                }
            }else if( pdo->Parameter.TransmissionType == CO_PDO_TRANS_TYPE_FE_ASYN_DEVICE_PROFILE ){
                is_event_timer_work = YES;
                is_asyn_falg = YES;
            }else{
                // Not Support
                co->EMCY_State = CO_EMC_GENERIC;
            }

            if( is_event_timer_work ){
                if( pdo->Parameter.EventTime_1ms != 0 ){
                    if( co->TimeUp_1ms_Flag ){
                        if( ++pdo->EventTimer_1ms >= pdo->Parameter.EventTime_1ms ){
                            pdo->ToUpdate_Flag = YES;
                            pdo->EventTimer_1ms = 0;
                        }
                    }
                }else{
                    pdo->ToUpdate_Flag = YES;
                }
            }

            if( pdo->Parameter.InhibitTime_100us != 0 ){
                if( co->TimeUp_1ms_Flag ){

                    //pdo->InhibitTimer_100us += 10; // 10 * 100us = 1ms
                    if( pdo->InhibitTimer_100us < 65525 ){
                        pdo->InhibitTimer_100us += 10; // 10 * 100us = 1ms
                    }else{
                        pdo->InhibitTimer_100us = 0xFFFF;
                    }
                }

                if( pdo->InhibitTimer_100us < pdo->Parameter.InhibitTime_100us ){
                    is_pdo_valid = NO;
                }else{
                    is_pdo_valid = YES;
                }

            }else{
                is_pdo_valid = YES;
            }

            if( pdo->ToUpdate_Flag ){
                pdo->ToUpdate_Flag = NO;
                coPDO_UpdateTPDO( co, pdo, pdo->Data );
                pdo->Mapping.IsUsePtrFlag = YES;
                if( is_asyn_falg ){
                    pdo->ToTransmit_Flag = YES;
                }
            }

            if( pdo->ToTransmit_Flag && is_pdo_valid ){
                pdo->ToTransmit_Flag = NO;
                pdo->InhibitTimer_100us = 0;
                CAN_sendMessage( C2000_CAN_BASE, mail_box_id, CAN_OPEN_DATA_NUM, pdo->Data );
            }
        }else{ // pdo->IsGood_Flag
            co->EMCY_State = CO_EMC_DAM_MPDO;
        }
    } // pdo->Mapping.MappingObject_Num != 0

}

/*===========================================================================================
    Function Name    : coPDO_UpdateRPDO
    Input            : 1.co
                       2.pdo
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coPDO_UpdateRPDO( Struct_CANOpen *co, Struct_CO_PDO *pdo )
{
    uint8_t i;
    uint8_t num = pdo->Mapping.MappingObject_Num;
    uint8_t size = 8;
    uint32_t value = 0;
    uint16_t index;
    uint8_t sub_index;
    uint32_t object;
    uint8_t byte_cnt = 0;
    uint32_t* mapping_data;

    for( i = 0; i < num; i++ ){
        object = pdo->Mapping.MappingObjec[i];
        size = ( object >> 0 ) & 0xFF;
        if( pdo->Mapping.IsUsePtrFlag ){
            mapping_data = pdo->Mapping.MappingPtr[i];
        }else{
            index = ( object >> 16 ) & 0xFFFF;
            sub_index = ( object >> 8 ) & 0xFF;
            co_GetObject( co, index, sub_index );
            if( co->Current_OBject.ReadWrite == CO_RW_WRITE_ONLY ||
                co->Current_OBject.ReadWrite == CO_RW_READ_WEITE ){
                mapping_data = (uint32_t*)co->Current_OBject.pData;
                pdo->Mapping.MappingPtr[i] = mapping_data;
            }else{
                pdo->Mapping.MappingPtr[i] = (uint32_t*)&co->SDO_OBject_Null;
                pdo->IsGood_Flag = NO;
            }

        }

        if( size <= 8 ){
            value = pdo->Data[ byte_cnt++ ];
        }else{
            value = pdo->Data[ byte_cnt++ ];
            value |= ( pdo->Data[ byte_cnt++ ] << 8 );
        }

        *mapping_data = value;
    }

}

/*===========================================================================================
    Function Name    : coPDO_RPDO_Excute
    Input            : 1.mail_box_id
                       2.co
                       3.pdo
                       4.is_pdo_work
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coPDO_RPDO_Excute( uint32_t mail_box_id, Struct_CANOpen *co, Struct_CO_PDO *pdo, uint8_t is_pdo_work )
{
    uint8_t is_newdata_flag = NO;

    if( CAN_readMessage( C2000_CAN_BASE, mail_box_id, pdo->Data ) ){
        co->MailBox_BITF |= ( 1UL << mail_box_id );
        pdo->DLC = HWREGH( C2000_CAN_BASE + CAN_O_IF2MCTL) & 0x0F;
        is_newdata_flag = YES;
    }// readMessage

    if( pdo->Mapping.MappingObject_Num != 0  ){
        if( is_pdo_work ){
            if( pdo->IsGood_Flag ){
                if( is_newdata_flag ){
                    if( pdo->DLC < pdo->Byte_Cnt ){
                        // Error State
                        // Needs to work
                        co->EMCY_State = CO_EMC_PDO_LENGTH;
                    }else{
                        //co->MailBox_BITF |= ( 1UL << mail_box_id );
                        if( pdo->Parameter.TransmissionType < CO_PDO_TRANS_TYPE_01_SYN_CYCLIC + 240 ){
                            pdo->ToWait4SYNC_Flag = YES;
                        }else{
                            pdo->ToUpdate_Flag = YES;
                        }
                    } // DLC < pdo->Byte_Cnt
                }

                if( co->SYNC_Flag && pdo->ToWait4SYNC_Flag ){
                    if( co->SYNC_Cnt != 0 ){
                        if( co->SYNC_Cnt == pdo->Parameter.SYNC_StartValue ){
                            pdo->SYNC_Cnt = 0;
                        }
                    }
                    if( ++pdo->SYNC_Cnt >= pdo->Parameter.TransmissionType ){
                        pdo->SYNC_Cnt = 0;
                        pdo->ToUpdate_Flag = YES;
                    }
                }

                if( pdo->ToUpdate_Flag ){
                    pdo->ToUpdate_Flag = NO;
                    pdo->Test_Cnt++;
                    // Needs to work
                    coPDO_UpdateRPDO( co, pdo );
                }
            }else{ // pdo->IsGood_Flag
                co->EMCY_State = CO_EMC_DAM_MPDO;
            }
        } // is_pdo_work
    } // MappingObject_Num != 0

}


/*===========================================================================================
    Function Name    : coSetupInitial
    Input            : 1.can
					   2.node_id
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void coSetupInitial( Struct_CANOpen *co, uint32_t node_id )
{
    CAN_MsgFrameType frame_type;

    co->NodeID = node_id;
    if( co->NodeID == 0 ){
        co->NodeID = 1;
    }

    //
    co->NMT_State = CO_NMT_INITIALIZING;
    co->NMT_State_Old = CO_NMT_INITIALIZING;

    if( ( ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CANOPEN_MODE ] >> CANOPEN_MODE_BIT_0_ID_LENGTH ) & 0x01 ) == 0 ){
        co->Id_Mode = CANID_11BITS;
        frame_type = CAN_MSG_FRAME_STD;
    }else{
        co->Id_Mode = CANID_29BITS;
        frame_type = CAN_MSG_FRAME_EXT;
    }

    if( ( ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_CANOPEN_MODE ] >> CANOPEN_MODE_BIT_1_INIT_STATE ) & 0x01 ) == 0 ){
        co->NMT_State_Init = CO_NMT_OPERATIONAL;
    }else{
        co->NMT_State_Init = CO_NMT_PRE_OPERATIONAL;
    }

    co->Is_Reset_COM = NO;
    co->Is_Init_Flag = YES;
    co->TimeUp_1ms_Flag = NO;

    co->HB_ID = CANOPEN_ID_NMT_ERR_CTRL + co->NodeID;
    co->HB_Period_Ms = CO_HEART_BEAT_DEFAULT_MS;
    co->HB_Timer_Ms = co->HB_Period_Ms;

    //
    co->SYNC_Flag = NO;
    co->SYNC_Cnt = 0;
    //
    //co->EMCY_State = CO_EMC_NO_ERROR;
    co->Emergency_ID = CANOPEN_ID_EMERGENCY + co->NodeID;
    coSetupInitial_EMCY( co );

    //
    coSetupInitial_PDO( co );

    //
    co->SDO_C2S_ID = CANOPEN_ID_SDO_C2S + co->NodeID;
    co->SDO_S2C_ID = CANOPEN_ID_SDO_S2C + co->NodeID;

    co->SDO_State = SDO_STATE_IDLE;
    co->SDO_AbortCode = SDO_AB_NONE;

    co->SDO_WriteEEP_Busy_Flag = NO;
    co->SDO_RealTime_Req_Flag = NO;

    co->SDO_OBject_Null = 0;
    co->SDO_Action = CO_SDO_ACTION_IDLE;
    co->SDO_CMD = 0;

    //
    co->Access_Level = 0;
    co->Error_Code = 0;
    //co->Test_Cnt = 0;

    co->NewFrame_Flag = NO;

    //

    coSetupInitial_GCO( co );

    // NMT
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_NMT, CANOPEN_ID_NMT, frame_type,
                            CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 2 );

    // HearrBeat
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_HEARTBEAT, co->HB_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 1 );

    // SYNC
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_SYNC, CANOPEN_ID_SYNC, frame_type,
                                CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 1 );

    // SDO
#if(TEST_CAN_MASTER)
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_C2S, co->SDO_C2S_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_S2C, co->SDO_S2C_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );
#else
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_C2S, co->SDO_C2S_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_S2C, co->SDO_S2C_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );
#endif

    // PDO
    // TPDO
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_TPDO1, co->TPDO1_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_TPDO2, co->TPDO2_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_TPDO3, co->TPDO3_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_TPDO4, co->TPDO4_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    // RPDO
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_RPDO1, co->RPDO1_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_RPDO2, co->RPDO2_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_RPDO3, co->RPDO3_ID, frame_type,
                                CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_RPDO4, co->RPDO4_ID, frame_type,
                                CAN_MSG_OBJ_TYPE_RX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );


    // EMCY
    CAN_setupMessageObject( C2000_CAN_BASE, MAIL_BOX_INDEX_EMCY, co->Emergency_ID, frame_type,
                            CAN_MSG_OBJ_TYPE_TX, 0, CAN_MSG_OBJ_NO_FLAGS, 8 );

}

/*===========================================================================================
    Function Name    : co_Check_PaRealTime
    Input            : 1.co
                       2.major: 0 = motor, 1 = general...
                       3.minor: 0 ~ 15 or 0 ~ 31
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t co_Check_PaRealTime( Struct_CANOpen *co, uint8_t major, uint8_t minor )
{
    if( co->Access_Level == MASTER_LEVEL_3 ){
        return 1;
    }else if( ( ~( CG_ComProtocol_01.FlagBITF >> COM_PA_CHANGE_REALTIME_REQ_BIT ) ) & 0x01 ){
        return 1;
    }else{
        return parameter_RealTime_Check( major, minor );
    }
}

/*===========================================================================================
    Function Name    : co_SDO_Execute
    Input            : co
    Return           : eep_ok : 0 = Bad, 1 = Ok
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
uint8_t co_SDO_Execute( Struct_CANOpen *co )
{
    uint8_t eep_ok              = 1;

    if( co->SDO_Action ){
        if( co->SDO_Action == CO_SDO_ACTION_CMD ){

            switch( co->SDO_CMD ){
            case COM_CMD_ALARM_RESET:
                CG_Protect.Motor_0.ToReset = YES;
                //CG_Protect.Motor_1.ToReset = YES;
                break;
            case COM_CMD_CONFIG:
                updateSpeceilParameter ();
                hweep_WatchUpdate ( CG_Parameter.RAM_data[ PARAMETER_COM ][ COM_PA_DATA_WATCH_SEL ] );
                break;
            case COM_CMD_PA_RESET:
                co->SDO_WriteEEP_Busy_Flag = YES;
                eep_ok &= pa_BackToDefault( 0 );
                eep_ok &= pa_BackToDefault( 1 );
                eep_ok &= pa_BackToDefault( 2 );
                eep_ok &= pa_BackToDefault( 3 );
                eep_ok &= pa_BackToDefault( 4 );
                eep_ok &= pa_BackToDefault( 5 );
                eep_ok &= pa_BackToDefault( 6 );
                eep_ok &= pa_BackToDefault( 7 );
                eep_ok &= pa_BackToDefault( 8 );
                break;
            case COM_CMD_ERROR_HISTORY_RESET:
                co->SDO_WriteEEP_Busy_Flag = YES;
                com_HistoryArray_Clear( (uint32_t*)CG_ComProtocol_01.Alm_His_ptr, HIST_SIZE );
                eep_ok &= saveEEPParameter_Multiple( COM_RO_EEP_INDEX-1,
                                                     0,
                                                     HIST_SIZE,
                                                     (int32_t*)CG_ComProtocol_01.Alm_His_ptr,
                                                     PA_EEP_WR_AND_CHECK );
                break;
            case COM_CMD_WARN_HISTORY_RESET:
                com_HistoryArray_Clear( (uint32_t*)CG_ComProtocol_01.Wng_His_ptr, HIST_SIZE );
                break;
            case COM_CMD_COM_HISTORY_RESET:
                com_HistoryArray_Clear( (uint32_t*)&CG_ComProtocol_01.ERROR_His_RAM, COM_HIST_ARRAY_SIZE );
                break;
            default:
                // Reserved
                break;
            }

        }else if( co->SDO_Action == CO_SDO_ACTION_EEP ){
            co->SDO_WriteEEP_Busy_Flag = YES;
            eep_ok &= saveEEPParameter_Single( co->Pa_Major,
                                               co->Pa_Minor,
                                               co->Pa_Value,
                                               ((CG_ComProtocol_01.FlagBITF>>COM_PA_CHANGE_REALTIME_REQ_BIT)&0x01));

        }else if( co->SDO_Action == CO_SDO_ACTION_CLEAR_PDE ){
            coClear_PreDefinedErrrorField( co );
        }else{
            // Reserved
        }
        co->SDO_Action = CO_SDO_ACTION_IDLE;
    }

    return eep_ok;
}


/*===========================================================================================
    Function Name    : co_GetObject_Parameter
    Input            : 1.co
                       2.index
                       3.sub_index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_GetObject_Parameter( Struct_CANOpen *co, uint16_t index, uint8_t sub_index )
{
    //uint16_t index_h = ( index >> 8 ) & 0xFF;
    uint16_t index_l = ( index ) & 0xFF;
    int32_t *holding_register_ptr;
    Struct_CO_Object *current_object = &co->Current_OBject;
    uint16_t major;
    uint16_t minor;

    if( index_l < MAX_HODLING_REG_MAJOR ){
        holding_register_ptr = CG_Modbus_Slave.HoldingRegister_ptr[ index_l ];
    }else{
        co->SDO_AbortCode = SDO_AB_NOT_EXIST;
        co->Error_Code = CO_ERR_0_SDO_R_INDEX_L;
        return;
    }

    if( index_l < COM_MIN_EEP_INDEX + PARAMETER_MAJOR_NUM  ){  // Parameter EEP, Default, Max and Min

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;

        current_object->SubIndex_Max = PARAMETER_MINOR_NUM;

        if( index_l == COM_DYNAMIC_DATA_INDEX ){ // Dynamic data
            if( sub_index == 0 ){
                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &current_object->SubIndex_Max;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else if( sub_index <= PARAMETER_MINOR_NUM ){
                current_object->pData = &holding_register_ptr[ sub_index - 1 ];
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }
        }else if( index_l < COM_PA_EEP_INDEX + PARAMETER_MAJOR_NUM ){ // EEP
            if( sub_index == 0 ){
                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &current_object->SubIndex_Max;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else if( sub_index <= PARAMETER_MINOR_NUM ){
                current_object->pData = &holding_register_ptr[ sub_index - 1 ];
                current_object->Type = CO_OBJECT_TYPE_EEP;

                major = MOD( index_l, 10 ) - 1;
                minor = sub_index - 1;
                co->Pa_Major = major;
                co->Pa_Minor = minor;

                current_object->ReadWrite = CO_RW_READ_WEITE;
                if( co->Access_Level == MASTER_LEVEL_3 ){
                    current_object->Data_Max = 0xFFFFFFFF;
                    current_object->Data_Min = 0;
                }else{
                    current_object->Data_Max = CG_Parameter.EEP_data_max[ major ][ minor ];
                    current_object->Data_Min = CG_Parameter.EEP_data_min[ major ][ minor ];
                }

                co->SDO_RealTime_Req_Flag = co_Check_PaRealTime( co, major, minor );

            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }
        }else if( index_l == COM_COMMAND_INDEX ){ // Command
            current_object->SubIndex_Max = 0;
            if( sub_index == 0 ){
                current_object->pData = (int32_t*)&co->SDO_OBject_Null;
                current_object->Type = CO_OBJECT_TYPE_CMD;
                current_object->ReadWrite = CO_RW_WRITE_ONLY;

                current_object->Data_Max = 0xFFFFFFFF;
                current_object->Data_Min = 0;

                co->SDO_RealTime_Req_Flag = ( ~( CG_ComProtocol_01.FlagBITF >> COM_PA_CHANGE_REALTIME_REQ_BIT ) ) & 0x01;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

        }else if( index_l < COM_DEFAULT_EEP_INDEX + PARAMETER_MAJOR_NUM ){ // Default
            if( sub_index == 0 ){
                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &current_object->SubIndex_Max;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else if( sub_index <= PARAMETER_MINOR_NUM ){
                current_object->pData = &holding_register_ptr[ sub_index -1 ];
                current_object->ReadWrite = CO_RW_PROTECT;
                current_object->Data_Max = 0xFFFFFFFF;
                current_object->Data_Min = 0;
                co->SDO_RealTime_Req_Flag = YES;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }
        }else if( index_l == COM_UART_XIN_INDEX ){ // Net-IO
            current_object->SubIndex_Max = 0;
            if( sub_index == 0 ){
                current_object->pData = &holding_register_ptr[ sub_index ];
                current_object->ReadWrite = CO_RW_READ_WEITE;
                current_object->Data_Max = 0xFFFFFFFF;
                current_object->Data_Min = 0;
                co->SDO_RealTime_Req_Flag = YES;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

        }else if( index_l < COM_MAX_EEP_INDEX + PARAMETER_MAJOR_NUM ){ // Max
            if( sub_index == 0 ){
                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &current_object->SubIndex_Max;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else if( sub_index <= PARAMETER_MINOR_NUM ){
                current_object->pData = &holding_register_ptr[ sub_index - 1 ];
                current_object->ReadWrite = CO_RW_PROTECT;
                current_object->Data_Max = 0xFFFFFFFF;
                current_object->Data_Min = 0;
                co->SDO_RealTime_Req_Flag = YES;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }
        }else if( index_l == COM_UART_YOUT_INDEX ){ // Y-Out
            current_object->SubIndex_Max = 0;
            if( sub_index == 0 ){
                current_object->pData = &holding_register_ptr[ sub_index ];
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }
        }else{ // Min
            if( sub_index == 0 ){
                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &current_object->SubIndex_Max;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else if( sub_index <= PARAMETER_MINOR_NUM ){
                current_object->pData = &holding_register_ptr[ sub_index - 1 ];
                current_object->ReadWrite = CO_RW_PROTECT;
                current_object->Data_Max = 0xFFFFFFFF;
                current_object->Data_Min = 0;
                co->SDO_RealTime_Req_Flag = YES;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }
        }

    }else if( index_l >= COM_PA_RAM_INDEX && index_l < COM_PA_RAM_INDEX + PARAMETER_MAJOR_NUM ){ // Parameter Ram

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;
        current_object->SubIndex_Max = PARAMETER_MINOR_NUM;

        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= PARAMETER_MINOR_NUM ){
            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->ReadWrite = CO_RW_READ_WEITE;

            major = MOD( index_l, 10 ) - 1;
            minor = sub_index - 1;

            if( co->Access_Level == MASTER_LEVEL_3 ){
                current_object->Data_Max = 0xFFFFFFFF;
                current_object->Data_Min = 0;
            }else{
                current_object->Data_Max = CG_Parameter.EEP_data_max[ major ][ minor ];
                current_object->Data_Min = CG_Parameter.EEP_data_min[ major ][ minor ];
            }

            co->SDO_RealTime_Req_Flag = co_Check_PaRealTime( co, major, minor );

        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_MONITOR_DATA_M0_INDEX || // Monitor Data
              index_l == COM_MONITOR_DATA_M1_INDEX ||
              index_l == COM_MONITOR_DATA_ENG_INDEX ){

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;
        current_object->SubIndex_Max = PARAMETER_MONITOR_DATA_NUM;

        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= PARAMETER_MONITOR_DATA_NUM ){
            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_RO_EEP_INDEX ||        // Alarm History
              index_l == COM_RO_RAM_INDEX ||        // Warning
              index_l == COM_RO_RAM_INDEX + 1 ){    // Com Error

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;
        current_object->SubIndex_Max = HIST_ARRAY_SIZE;

        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= HIST_ARRAY_SIZE ){
            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_MULTI_DRIVE_CMD_M0 ||
              index_l == COM_MULTI_DRIVE_CMD_M1 ){

        current_object->SubIndex_Max = MULTI_DRIVE_NUM;
        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;

            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= current_object->SubIndex_Max ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;

            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->Type = CO_OBJECT_TYPE_GENERAL;

            current_object->ReadWrite = CO_RW_WRITE_ONLY;
            current_object->Data_Max = 0xFFFFFFFF;
            current_object->Data_Min = 0;
            co->SDO_RealTime_Req_Flag = YES;

        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }
    }else if( index_l == COM_MULTI_DRIVE_LITE_CMD_M0 ||
              index_l == COM_MULTI_DRIVE_LITE_CMD_M1 ){

        current_object->SubIndex_Max = MULTI_DRIVE_LITE_NUM;
        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;

            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= current_object->SubIndex_Max ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;

            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->Type = CO_OBJECT_TYPE_GENERAL;

            current_object->ReadWrite = CO_RW_WRITE_ONLY;
            current_object->Data_Max = 0xFFFFFFFF;
            current_object->Data_Min = 0;
            co->SDO_RealTime_Req_Flag = YES;

        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_HW_INFO_INDEX ){ // HW infor : Watch Data

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;
        current_object->SubIndex_Max = HW_WATCH_DATA_NUM;

        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= HW_WATCH_DATA_NUM ){
            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_HW_INFO_INDEX2 ){ // HW infor2

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;
        current_object->SubIndex_Max = HWEEP_IDX_TOL;

        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= HWEEP_IDX_TOL ){
            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_HW_VER_INDEX ){ // HW Version

        current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
        current_object->Length = 1;
        current_object->SubIndex_Max = 0;

        if( sub_index == 0 ){
            current_object->pData = &holding_register_ptr[ sub_index ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_FW_VER_INDEX ){ // FW Version

        current_object->DataSize = CO_OBJECT_SIZE_CHAR;
        current_object->Length = FW_VER_CHARS;
        current_object->SubIndex_Max = 0;

        if( sub_index == 0 ){
            current_object->pData = &holding_register_ptr[ sub_index ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_DRIVER_VER_INDEX ){ // Part Number

        current_object->DataSize = CO_OBJECT_SIZE_CHAR;
        current_object->Length = PART_NUM_CHARS;
        current_object->SubIndex_Max = 0;

        if( sub_index == 0 ){
            current_object->pData = &holding_register_ptr[ sub_index ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_HW_SN_0_INDEX ){ // Serial Number

        current_object->DataSize = CO_OBJECT_SIZE_CHAR;
        current_object->Length = SN_CHARS;
        current_object->SubIndex_Max = 0;

        if( sub_index == 0 ){
            current_object->pData = &holding_register_ptr[ sub_index ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_CODE_VER_INDEX ){ // Code Version

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;
        current_object->SubIndex_Max = 5;

        if( sub_index == 0 ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else if( sub_index <= 5 ){
            current_object->pData = &holding_register_ptr[ sub_index - 1 ];
            current_object->ReadWrite = CO_RW_READ_ONLY;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else if( index_l == COM_MASTER_LV_INDEX ){ // Master Level

        current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
        current_object->Length = PARAMETER_DATA_SIZE;
        current_object->SubIndex_Max = 0; // Not sure what value should be set here

        if( sub_index == MASTER_LEVEL_PASSWROD ){
            current_object->pData = (int32_t*)&co->Access_Level;
            current_object->ReadWrite = CO_RW_WRITE_ONLY;
            current_object->Data_Max = 0xFFFFFFFF;
            current_object->Data_Min = 0;
            co->SDO_RealTime_Req_Flag = YES;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

    }else{
        co->SDO_AbortCode = SDO_AB_NOT_EXIST;
        co->Error_Code = CO_ERR_0_SDO_R_INDEX_L;
    }


}

/*===========================================================================================
    Function Name    : co_GetObject_GeneralCommunication
    Input            : 1.co
                       2.index
                       3.sub_index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_GetObject_GeneralCommunication( Struct_CANOpen *co, uint16_t index, uint8_t sub_index )
{
    //int32_t *holding_register_ptr;
    Struct_CO_Object *current_object = &co->Current_OBject;

    if( index < OD_H1010_STORE_PARAM_FUNC ){

        co->SDO_RealTime_Req_Flag = YES;
        current_object->Type = CO_OBJECT_TYPE_GENERAL;

        switch( index ){
        case OD_H1000_DEV_TYPE:

            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.DeviceType;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1001_ERR_REG:

            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.ErrorRegister;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1002_MANUF_STATUS_REG:
            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.ManufacturerStatusRegister;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1003_PREDEF_ERR_FIELD:

            current_object->SubIndex_Max = CO_PDE_ARRAY_SIZE;

            if( sub_index == 0 ){
                current_object->Type = CO_OBJECT_TYPE_PDE;
                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &co->GCO.PDE_Num;
                current_object->ReadWrite = CO_RW_READ_WEITE;
                current_object->Data_Max = 0;
                current_object->Data_Min = 0;

            }else if( sub_index <= current_object->SubIndex_Max ){

                current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
                current_object->Length = 4;
                current_object->pData = &co->GCO.PDE[ sub_index - 1 ];
                current_object->ReadWrite = CO_RW_READ_ONLY;

            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1005_COBID_SYNC:
            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.COBID_SYNC;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1006_COMM_CYCL_PERIOD:
            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.CommunicationCyclePeriod;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1007_SYNC_WINDOW_LEN:
            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.SyncWindowsLength;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1008_MANUF_DEV_NAME:

            current_object->DataSize = CO_OBJECT_SIZE_CHAR;
            current_object->Length = PART_NUM_CHARS;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = co->GCO.ManufacturerDeviceName;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1009_MANUF_HW_VERSION:

            current_object->DataSize = CO_OBJECT_SIZE_CHAR;
            current_object->Length = 2;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.ManufacturerHardwareVersion[0];
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H100A_MANUF_SW_VERSION:

            current_object->DataSize = CO_OBJECT_SIZE_CHAR;
            current_object->Length = FW_VER_CHARS;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = co->GCO.ManufacturerSoftwareVersion;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;

        case OD_H100C_GUARD_TIME:

            current_object->DataSize = CO_OBJECT_SIZE_UINT16_T;
            current_object->Length = 2;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.GuardTime;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H100D_LIFETIME_FACTOR:

            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.LifrTimeFactor;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        default:
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_INDEX_L;
            break;
        }

    }else{

        co->SDO_RealTime_Req_Flag = YES;
        current_object->Type = CO_OBJECT_TYPE_GENERAL;

        switch( index ){
        case OD_H1010_STORE_PARAM_FUNC:

            current_object->SubIndex_Max = CO_SP_BYTE_NUM - 1;

            if( sub_index == 0 ){

                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &co->GCO.StoreParameter[0];
                current_object->ReadWrite = CO_RW_READ_ONLY;

            }else if( sub_index <= current_object->SubIndex_Max ){

                current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
                current_object->Length = 4;
                current_object->pData = &co->GCO.StoreParameter[ sub_index ];
                current_object->ReadWrite = CO_RW_READ_ONLY;

            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1011_REST_PARAM_FUNC:

            current_object->SubIndex_Max = CO_RP_BYTE_NUM - 1;

            if( sub_index == 0 ){

                current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
                current_object->Length = 1;
                current_object->pData = &co->GCO.RestoreDefaultParameters[0];
                current_object->ReadWrite = CO_RW_READ_ONLY;

            }else if( sub_index <= current_object->SubIndex_Max ){

                current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
                current_object->Length = 4;
                current_object->pData = &co->GCO.RestoreDefaultParameters[ sub_index ];
                current_object->ReadWrite = CO_RW_READ_ONLY;

            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }


            break;
        case OD_H1014_COBID_EMERGENCY:

            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->GCO.COBID_EMCY;
                current_object->ReadWrite = CO_RW_READ_ONLY;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;

        case OD_H1017_PRODUCER_HB_TIME:

            current_object->DataSize = CO_OBJECT_SIZE_UINT16_T;
            current_object->Length = 2;
            current_object->SubIndex_Max = 0;

            if( sub_index == 0 ){
                current_object->pData = &co->HB_Period_Ms;
                current_object->ReadWrite = CO_RW_READ_WEITE;
                current_object->Data_Max = 0xFFFF;
                current_object->Data_Min = 0;
            }else{
                co->SDO_AbortCode = SDO_AB_NOT_EXIST;
                co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
            }

            break;
        case OD_H1012_COBID_TIME:
        case OD_H1013_HIGH_RES_TIMESTAMP:
        case OD_H1015_INHIBIT_TIME_MSG:
        case OD_H1016_CONSUMER_HB_TIME:
        case OD_H1018_IDENTITY_OBJECT:
            default:

            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_INDEX_L;
            break;
        }

    }

}


/*===========================================================================================
    Function Name    : co_GetObject_PDO
    Input            : 1.co
                       2.index
                       3.sub_index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_GetObject_PDO( Struct_CANOpen *co, uint16_t index, uint8_t sub_index )
{
    //int32_t *holding_register_ptr;
    Struct_CO_Object *current_object = &co->Current_OBject;
    Struct_CO_PDO *pdo;

    if( index == OD_H1400_RXPDO_1_PARAM || index == OD_H1600_RXPDO_1_MAPPING ){
        pdo = &co->RPDO1;
    }else if( index == OD_H1401_RXPDO_2_PARAM || index == OD_H1601_RXPDO_2_MAPPING ){
        pdo = &co->RPDO2;
    }else if( index == OD_H1402_RXPDO_3_PARAM || index == OD_H1602_RXPDO_3_MAPPING ){
        pdo = &co->RPDO3;
    }else if( index == OD_H1403_RXPDO_4_PARAM || index == OD_H1603_RXPDO_4_MAPPING ){
        pdo = &co->RPDO4;
    }else if( index == OD_H1800_TXPDO_1_PARAM || index == OD_H1A00_TXPDO_1_MAPPING ){
        pdo = &co->TPDO1;
    }else if( index == OD_H1801_TXPDO_2_PARAM || index == OD_H1A01_TXPDO_2_MAPPING ){
        pdo = &co->TPDO2;
    }else if( index == OD_H1802_TXPDO_3_PARAM || index == OD_H1A02_TXPDO_3_MAPPING){
        pdo = &co->TPDO3;
    }else if( index == OD_H1803_TXPDO_4_PARAM || index == OD_H1A03_TXPDO_4_MAPPING ){
        pdo = &co->TPDO4;
    }

    co->SDO_RealTime_Req_Flag = YES;

    switch( index ){
    case OD_H1400_RXPDO_1_PARAM:
    case OD_H1401_RXPDO_2_PARAM:
    case OD_H1402_RXPDO_3_PARAM:
    case OD_H1403_RXPDO_4_PARAM:
    case OD_H1800_TXPDO_1_PARAM:
    case OD_H1801_TXPDO_2_PARAM:
    case OD_H1802_TXPDO_3_PARAM:
    case OD_H1803_TXPDO_4_PARAM:

        current_object->SubIndex_Max = 0x06;
        current_object->Type = CO_OBJECT_TYPE_GENERAL;

        if( sub_index == 0 ){     // NumberOfEntries
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &current_object->SubIndex_Max;
            current_object->ReadWrite = CO_RW_READ_ONLY;

        }else if( sub_index == 1 ){ // COB_ID

            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->pData = &pdo->Parameter.COB_ID;
            current_object->ReadWrite = CO_RW_READ_ONLY;

        }else if( sub_index == 2 ){ // TransmissionType

            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &pdo->Parameter.TransmissionType;
            current_object->ReadWrite = CO_RW_READ_WEITE;

            current_object->Data_Max = 0xFF;
            current_object->Data_Min = 0;

        }else if( sub_index == 3 ){ // InhibitTime_100us

            current_object->DataSize = CO_OBJECT_SIZE_UINT16_T;
            current_object->Length = 2;
            current_object->pData = &pdo->Parameter.InhibitTime_100us;
            current_object->ReadWrite = CO_RW_READ_WEITE;

            current_object->Data_Max = 0xFFFF;
            current_object->Data_Min = 0;

        }else if( sub_index == 4 ){ // Reserved_04

            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &pdo->Parameter.Reserved_04;
            current_object->ReadWrite = CO_RW_READ_ONLY;

        }else if( sub_index == 5 ){ // EventTime_1ms

            current_object->DataSize = CO_OBJECT_SIZE_UINT16_T;
            current_object->Length = 2;
            current_object->pData = &pdo->Parameter.EventTime_1ms;
            current_object->ReadWrite = CO_RW_READ_WEITE;

            current_object->Data_Max = 0xFFFF;
            current_object->Data_Min = 0;

        }else if( sub_index == 6 ){ // SYNC_StartValue

            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &pdo->Parameter.SYNC_StartValue;
            current_object->ReadWrite = CO_RW_READ_WEITE;

            current_object->Data_Max = 0xFF;
            current_object->Data_Min = 0;

        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }


        break;
    case OD_H1600_RXPDO_1_MAPPING:
    case OD_H1601_RXPDO_2_MAPPING:
    case OD_H1602_RXPDO_3_MAPPING:
    case OD_H1603_RXPDO_4_MAPPING:
    case OD_H1A00_TXPDO_1_MAPPING:
    case OD_H1A01_TXPDO_2_MAPPING:
    case OD_H1A02_TXPDO_3_MAPPING:
    case OD_H1A03_TXPDO_4_MAPPING:

        current_object->SubIndex_Max = PDO_MAPPING_OBJECT_NUM_MAX;
        current_object->Type = CO_OBJECT_TYPE_GENERAL;

        if( sub_index == 0 ){     // NumberOfEntries
            current_object->DataSize = CO_OBJECT_SIZE_UINT8_T;
            current_object->Length = 1;
            current_object->pData = &pdo->Mapping.MappingObject_Num;
            current_object->ReadWrite = CO_RW_READ_WEITE;
            current_object->Data_Max = current_object->SubIndex_Max;
            current_object->Data_Min = 0;
        }else if( sub_index <= current_object->SubIndex_Max ){
            current_object->DataSize = CO_OBJECT_SIZE_UINT32_T;
            current_object->Length = 4;
            current_object->pData = &pdo->Mapping.MappingObjec[ sub_index - 1 ];
            current_object->ReadWrite = CO_RW_READ_WEITE;
            current_object->Data_Max = 0xFFFFFFFF;
            current_object->Data_Min = 0;
        }else{
            co->SDO_AbortCode = SDO_AB_NOT_EXIST;
            co->Error_Code = CO_ERR_0_SDO_R_SUBINDEX;
        }

        break;
    default:
        co->SDO_AbortCode = SDO_AB_NOT_EXIST;
        co->Error_Code =  CO_ERR_0_SDO_R_INDEX;
        break;
    }

}


/*===========================================================================================
    Function Name    : co_GetObject
    Input            : 1.co
                       2.index
                       3.sub_index
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_GetObject( Struct_CANOpen *co, uint16_t index, uint8_t sub_index )
{
    uint16_t index_h = ( index >> 8 ) & 0xFF;
    Struct_CO_Object *current_object = &co->Current_OBject;

    current_object->Index = index;
    current_object->SubIndex = sub_index;

    current_object->Type = CO_OBJECT_TYPE_UNKNOWN;
    current_object->DataSize = CO_OBJECT_SIZE_UNKNOWN;
    current_object->ReadWrite = CO_RW_UNKNOWN;

    current_object->pData = (int32_t*)&co->SDO_OBject_Null;

    if( index_h == OD_INDEX_PARAMETER ){
        co_GetObject_Parameter( co, index, sub_index );

    }else if( index <= OD_H1029_ERR_BEHAVIOR ){

        co_GetObject_GeneralCommunication( co, index, sub_index );

    }else if( index >= OD_H1400_RXPDO_1_PARAM && index <= OD_H1A03_TXPDO_4_MAPPING ){   // PDO Parameters

        co_GetObject_PDO( co, index, sub_index );

    }else{
        co->SDO_AbortCode = SDO_AB_NOT_EXIST;
        co->Error_Code = CO_ERR_0_SDO_R_INDEX_H;
    }

}

/*===========================================================================================
    Function Name    : co_SDO_Routine
    Input            : co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_SDO_Routine( Struct_CANOpen *co )
{
    uint8_t ccs;
    uint8_t t;
    uint8_t n;
    uint8_t data_cnt;
    uint8_t e;
    uint8_t s;
    uint8_t c;
    int8_t i;
    int32_t start_byte;
    uint32_t dummy_data = 0;

    Struct_CO_Object *obj_ptr = &co->Current_OBject;
    //
    co->SDO_AbortCode = SDO_AB_NONE;
    co->SDO_CCS = co->R_Data[ SDO_BYTE0_CS ];
    ccs = ( co->SDO_CCS >> CCS_BIT567_CCS ) & 0x07;
    switch( ccs ){
    case CCS_INITIATE_DOWNLOAD:  // 1 = Initiate DownLoad
        // Try to find out Object Dictionary
        co->SDO_Index = ( co->R_Data[ SDO_BYTE2_INDEX_H ] << 8 ) | ( co->R_Data[ SDO_BYTE1_INDEX_L ] );
        co->SDO_SubIndex = co->R_Data[ SDO_BYTE3_SUBINDEX ];

        // Get object from index
        co_GetObject( co, co->SDO_Index, co->SDO_SubIndex );

        co->T_Data[ SDO_BYTE1_INDEX_L ] = co->R_Data[ SDO_BYTE1_INDEX_L ];
        co->T_Data[ SDO_BYTE2_INDEX_H ] = co->R_Data[ SDO_BYTE2_INDEX_H ];
        co->T_Data[ SDO_BYTE3_SUBINDEX ] = co->R_Data[ SDO_BYTE3_SUBINDEX ];

        if( co->SDO_AbortCode == SDO_AB_NONE  ){

            if( co->Current_OBject.ReadWrite == CO_RW_WRITE_ONLY ||
                co->Current_OBject.ReadWrite == CO_RW_READ_WEITE ||
                ( co->Current_OBject.ReadWrite == CO_RW_PROTECT && co->Access_Level == MASTER_LEVEL_3 ) ){

                if( co->SDO_RealTime_Req_Flag ){
                    if( !co->SDO_WriteEEP_Busy_Flag ){
                        e = ( co->SDO_CCS >> CCS_BIT1_E ) & 0x01;
                        s = ( co->SDO_CCS >> CCS_BIT0_S ) & 0x01;

                        if( e == 1 && s == 1 ){
                            n = ( co->SDO_CCS >> CCS_BIT23_N ) & 0x03;

                            co->SDO_SCS = ( SCS_INITIATE_DOWNLOAD << SCS_BIT567_SCS );
                            co->T_Data[ SDO_BYTE0_CS ] = co->SDO_SCS;
                            co->T_Data[ SDO_BYTE4_DATA0 ] = 0;
                            co->T_Data[ SDO_BYTE5_DATA1 ] = 0;
                            co->T_Data[ SDO_BYTE6_DATA2 ] = 0;
                            co->T_Data[ SDO_BYTE7_DATA3 ] = 0;

                            data_cnt = OD_INIT_DATA_LENGTH_LIMIT - n;
                            if( data_cnt > obj_ptr->Length ){
                                data_cnt = obj_ptr->Length;
                            }

                            for( i = 0; i < data_cnt; i++ ){
                                dummy_data |= ( ( uint32_t )co->R_Data[ SDO_BYTE4_DATA0 + i ] ) << ( 8 * i );
                            }

                            if( dummy_data >= obj_ptr->Data_Min &&
                                dummy_data <= obj_ptr->Data_Max ){

                                if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT32_T ){
                                    *( ( uint32_t* )obj_ptr->pData ) = dummy_data;
                                }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT16_T ){
                                    *( ( uint16_t* )obj_ptr->pData ) = dummy_data;
                                }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT8_T ){
                                    *( ( uint8_t* )obj_ptr->pData ) = dummy_data;
                                }else{
                                    co->SDO_AbortCode = SDO_AB_TYPE_MISMATCH;
                                }

                                if( co->SDO_AbortCode == SDO_AB_NONE ){
                                    //
                                    if( co->Current_OBject.Type == CO_OBJECT_TYPE_CMD ){
                                        co->SDO_CMD = dummy_data;
                                        co->SDO_Action = CO_SDO_ACTION_CMD;
                                    }else if( co->Current_OBject.Type == CO_OBJECT_TYPE_EEP ){
                                        co->Pa_Value = dummy_data;
                                        co->SDO_Action = CO_SDO_ACTION_EEP;
                                    }else if( co->Current_OBject.Type ==CO_OBJECT_TYPE_PDE ){
                                        co->SDO_Action = CO_SDO_ACTION_CLEAR_PDE;
                                    }
                                    //
                                }


                            }else{
                                co->SDO_AbortCode = SDO_AB_INVALID_VALUE;
                            }

                        }else if( e == 0 && s == 1 ){ // Reserved
                            co->SDO_AbortCode = SDO_AB_CMD;
                        }else{ // Not Support
                            co->SDO_AbortCode = SDO_AB_CMD;
                        }
                    }else{ // EEP is busy, needs to wait about 20ms
                        co->SDO_AbortCode = SDO_AB_DATA_TRANSF;
                    }
                }else{ // Can not write when motor is running
                    co->SDO_AbortCode = SDO_AB_DATA_DEV_STATE;
                }

            }else{ // Read Only
                co->SDO_AbortCode = SDO_AB_READONLY;
            }
        }

        break;
    case CCS_DOWNLOAD_SEGMENT:  // 0 = DownLoad Segment
        co->SDO_AbortCode = SDO_AB_GENERAL; // Reserved
        break;
    case CCS_INITIATE_UPLOAD:  // 2 = Initiate UpLoad
        // Try to find out Object Dictionary
        co->SDO_Index = ( co->R_Data[ SDO_BYTE2_INDEX_H ] << 8 ) | ( co->R_Data[ SDO_BYTE1_INDEX_L ] );
        co->SDO_SubIndex = co->R_Data[ SDO_BYTE3_SUBINDEX ];

        // Get object from index
        co_GetObject( co, co->SDO_Index, co->SDO_SubIndex );

        co->T_Data[ SDO_BYTE1_INDEX_L ] = co->R_Data[ SDO_BYTE1_INDEX_L ];
        co->T_Data[ SDO_BYTE2_INDEX_H ] = co->R_Data[ SDO_BYTE2_INDEX_H ];
        co->T_Data[ SDO_BYTE3_SUBINDEX ] = co->R_Data[ SDO_BYTE3_SUBINDEX ];

        if( co->SDO_AbortCode == SDO_AB_NONE  ){

            if( co->Current_OBject.ReadWrite != CO_RW_WRITE_ONLY ){

                if( obj_ptr->Length <= OD_INIT_DATA_LENGTH_LIMIT ){
                    n = OD_INIT_DATA_LENGTH_LIMIT - obj_ptr->Length;
                    e = 1;
                    s = 1;
                    co->SDO_SCS = ( SCS_INITIATE_UPLOAD << SCS_BIT567_SCS ) |
                                  ( n << SCS_BIT23_N ) |
                                  ( e << SCS_BIT1_E ) |
                                  ( s << SCS_BIT0_S );

                    co->T_Data[ SDO_BYTE0_CS ] = co->SDO_SCS;


                    if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT32_T ){
                        for( i = 0; i < obj_ptr->Length; i++ ){
                            co->T_Data[ SDO_BYTE4_DATA0 + i ] = ( ( *( ( uint32_t* )obj_ptr->pData ) ) >> ( 8 * i ) ) & 0xFF;
                        }
                    }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT16_T ){
                        for( i = 0; i < obj_ptr->Length; i++ ){
                            co->T_Data[ SDO_BYTE4_DATA0 + i ] = ( ( *( ( uint16_t* )obj_ptr->pData ) ) >> ( 8 * i ) ) & 0xFF;
                        }
                    }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT8_T ){
                        for( i = 0; i < obj_ptr->Length; i++ ){
                            co->T_Data[ SDO_BYTE4_DATA0 + i ] = ( ( *( ( uint8_t* )obj_ptr->pData ) ) >> ( 8 * i ) ) & 0xFF;
                        }
                    }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_CHAR ){
                        for( i = 0; i < obj_ptr->Length; i++ ){
                            co->T_Data[ SDO_BYTE4_DATA0 + i ] = ( ( (char*)obj_ptr->pData )[i] ) & 0xFF;
                        }
                    }else{
                        co->SDO_AbortCode = SDO_AB_TYPE_MISMATCH;
                    }

                    // Fill 0 on undefined data
                    for( i = obj_ptr->Length; i < OD_INIT_DATA_LENGTH_LIMIT; i++ ){
                        co->T_Data[ SDO_BYTE4_DATA0 + i ] = 0;
                    }

                }else{ // Data Length > 4; Needs to use segment upload

                    n = 0;
                    e = 0;  // e = 0 and s = 1, means data 0 ~ 3 contains data length, instead of data itself.
                    s = 1;
                    co->SDO_SCS = ( SCS_INITIATE_UPLOAD << SCS_BIT567_SCS ) |
                                  ( n << SCS_BIT23_N ) |
                                  ( e << SCS_BIT1_E ) |
                                  ( s << SCS_BIT0_S );

                    co->T_Data[ SDO_BYTE0_CS ] = co->SDO_SCS;

                    co->T_Data[ SDO_BYTE4_DATA0 ] = ( obj_ptr->Length >> 0 ) & 0xFF;
                    co->T_Data[ SDO_BYTE5_DATA1 ] = ( obj_ptr->Length >> 8 ) & 0xFF;
                    co->T_Data[ SDO_BYTE6_DATA2 ] = 0;
                    co->T_Data[ SDO_BYTE7_DATA3 ] = 0;

                    co->SDO_Toggle = 0;
                    co->SDO_Segment_Counter = 0;
                    co->SDO_State = SDO_STATE_UPLOADING;

                }
            }else{ // CO_RW_WRITE_ONLY
                co->SDO_AbortCode = SDO_AB_WRITEONLY;
            }
        }
        break;
    case CCS_UPLOAD_SEGMENT:  // 3 = UpLoad Segment
        if( co->SDO_State == SDO_STATE_UPLOADING ){
            t = ( co->SDO_CCS >> CCS_BIT4_T ) & 0x01;
            if( t == co->SDO_Toggle ){
                //   |                     Segment Data Length Limit          |
                // --|-----------Counter--|-------------------------|---------|-----
                //   |--------------------  Data Length  ---------------------|
                start_byte = co->SDO_Segment_Counter;
                if( co->SDO_Segment_Counter + OD_SEGMENT_DATA_LENGTH_LIMIT >= obj_ptr->Length ){
                    c = 1;  // n = 1 means no more data needs to be transmit
                    n = co->SDO_Segment_Counter + OD_SEGMENT_DATA_LENGTH_LIMIT - obj_ptr->Length;
                    co->SDO_State = SDO_STATE_IDLE;
                }else{
                    c = 0;
                    n = 0;
                    co->SDO_Segment_Counter += OD_SEGMENT_DATA_LENGTH_LIMIT;
                }
                co->SDO_Toggle ^= 1;    // Toogle;

                co->SDO_SCS = ( SCS_UPLOAD_SEGMENT << SCS_BIT567_SCS ) |
                              ( t << SCS_BIT4_T ) |
                              ( n << SCS_BIT123_SEG_N ) |
                              ( c << SCS_BIT0_SEG_C );

                co->T_Data[ SDO_BYTE0_CS ] = co->SDO_SCS;

                data_cnt = OD_SEGMENT_DATA_LENGTH_LIMIT - n;

                if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT32_T ){
                    for( i = 0; i < data_cnt; i++ ){
                        co->T_Data[ SDO_BYTE1 + i ] = ( ( *( ( uint32_t* )obj_ptr->pData ) ) >> ( 8 * i ) ) & 0xFF;
                    }
                }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT16_T ){
                    for( i = 0; i < data_cnt; i++ ){
                        co->T_Data[ SDO_BYTE1 + i ] = ( ( *( ( uint16_t* )obj_ptr->pData ) ) >> ( 8 * i ) ) & 0xFF;
                    }
                }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_UINT8_T ){
                    for( i = 0; i < data_cnt; i++ ){
                        co->T_Data[ SDO_BYTE1 + i ] = ( ( *( ( uint8_t* )obj_ptr->pData ) ) >> ( 8 * i ) ) & 0xFF;
                    }
                }else if( obj_ptr->DataSize == CO_OBJECT_SIZE_CHAR ){
                    for( i = 0; i < data_cnt; i++ ){
                        co->T_Data[ SDO_BYTE1 + i ] = ( ( (char*)obj_ptr->pData )[ start_byte + i] ) & 0xFF;
                    }
                }else{
                    co->SDO_AbortCode = SDO_AB_TYPE_MISMATCH;
                }

                // Fill 0 on undefined data
                for( i = data_cnt; i < OD_SEGMENT_DATA_LENGTH_LIMIT; i++ ){
                    co->T_Data[ SDO_BYTE1 + i ] = 0;
                }

            }else{
                co->SDO_AbortCode = SDO_AB_TOGGLE_BIT;
            }
        }else{
            co->SDO_AbortCode = SDO_AB_GENERAL;
        }
        break;
    case CCS_ABORT:  // 4 = Abort SDO Transfer
        co->SDO_State = SDO_STATE_ABORT;
        break;
    default:
        co->SDO_AbortCode = SDO_AB_CMD;
        break;
    }

    if( co->SDO_State != SDO_STATE_ABORT &&
        co->SDO_AbortCode != SDO_AB_NONE ){

        co->SDO_State = SDO_STATE_IDLE;
        co->SDO_SCS = ( SCS_ABORT << SCS_BIT567_SCS );
        co->T_Data[ SDO_BYTE0_CS ] = co->SDO_SCS;
        co->T_Data[ SDO_BYTE1_INDEX_L ] = co->R_Data[ SDO_BYTE1_INDEX_L ];
        co->T_Data[ SDO_BYTE2_INDEX_H ] = co->R_Data[ SDO_BYTE2_INDEX_H ];
        co->T_Data[ SDO_BYTE3_SUBINDEX ] = co->R_Data[ SDO_BYTE3_SUBINDEX ];

        co->T_Data[ SDO_BYTE4_DATA0 ] = ( co->SDO_AbortCode >> 0 ) & 0xFF;
        co->T_Data[ SDO_BYTE5_DATA1 ] = ( co->SDO_AbortCode >> 8 ) & 0xFF;
        co->T_Data[ SDO_BYTE6_DATA2 ] = ( co->SDO_AbortCode >> 16 ) & 0xFF;
        co->T_Data[ SDO_BYTE7_DATA3 ] = ( co->SDO_AbortCode >> 24 ) & 0xFF;
    }


}

/*===========================================================================================
    Function Name    : co_Call_1ms
    Input            : co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_Call_1ms( Struct_CANOpen *co )
{
    co->TimeUp_1ms_Flag = YES;
    if( co->HB_Timer_Ms < 0xFFFF ){
        co->HB_Timer_Ms++;
    }

    //coUpdate_ManufacturerStatusRegister( co, CG_BLDC_CTRL_M0.Motor_State, CG_BLDC_CTRL_M1.Motor_State );
    coUpdate_ManufacturerStatusRegister( co, CG_BLDC_CTRL_M0.Motor_State );
    //coUpdate_ErrorRegister( co, CG_BLDC_CTRL_M0.Protect_Ptr->first_fault_user, CG_BLDC_CTRL_M1.Protect_Ptr->first_fault_user );
    coUpdate_ErrorRegister( co, CG_BLDC_CTRL_M0.Protect_Ptr->first_fault_user );
}

/*===========================================================================================
    Function Name    : co_Routine
    Input            : co
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void co_Routine( Struct_CANOpen *co )
{
#if(TEST_CAN_MASTER)
    static uint32_t timer = 0;
    if( co->TimeUp_1ms_Flag ){
        timer++;
    }

    if( timer == 100 ){
        co->T_Data[0] = 0x40;
        co->T_Data[1] = 0x00;
        co->T_Data[2] = 0x30;
        co->T_Data[3] = 0x00;

        co->T_Data[4] = 0x00;
        co->T_Data[5] = 0x00;
        co->T_Data[6] = 0x00;
        co->T_Data[7] = 0x00;
        CAN_sendMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_C2S, CAN_OPEN_DATA_NUM, co->T_Data );
    }


    if( CAN_readMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_S2C, co->R_Data ) ){
        if( co->R_Data[0] == 0x4B &&
            co->R_Data[1] == 0x00 &&
            co->R_Data[2] == 0x30 &&
            co->R_Data[3] == 0x00 &&
            co->R_Data[4] == 0x20){

            // Good response
            ioExp_SetOutput( IO_EXP_STA_LED, HIGH );
            timer = 0;
        }
    }

    if( timer > 500 ){
        timer = 0;
        // Time out
        ioExp_SetOutput( IO_EXP_STA_LED, LOW );
    }


    co->TimeUp_1ms_Flag = NO;
#else
    uint8_t is_sdo_work = NO;
    uint8_t is_pdo_work = NO;
    uint8_t is_sync_work = NO;
    uint8_t is_emcy_work = NO;
    uint16_t state_cmd;
    uint16_t node_id;

    // NMT
    if( CAN_readMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_NMT, co->R_Data ) ){
        co->MailBox_BITF |= ( 1UL << MAIL_BOX_INDEX_NMT );
        //co->Test_Cnt++;
        state_cmd = co->R_Data[0];
        node_id = co->R_Data[1];
        if( node_id == CAN_OPEN_BROADCAST_ID || node_id == co->NodeID ){
            switch( state_cmd ){
            case CO_NMT_ENTER_OPERATIONAL:
                co->NMT_State = CO_NMT_OPERATIONAL;
                break;
            case CO_NMT_ENTER_STOPPED:
                co->NMT_State = CO_NMT_STOPPED;
                break;
            case CO_NMT_ENTER_PRE_OPERATIONAL:
                co->NMT_State = CO_NMT_PRE_OPERATIONAL;
                break;
            case CO_NMT_RESET_NODE: /**< Reset device */
                // Reset MCU By Watch Dog
                EALLOW;
                // Bit 3 ~ 5 = Watchdog Check Bits
                // The user must ALWAYS write 1,0,1 to these bits whenever a write to this register is performed.
                // Writing any other value will cause an immediate reset to the core (if WD enabled)
                WdRegs.WDCR.all = ( 0 << 3 );
                EDIS;
                break;
            case CO_NMT_RESET_COMMUNICATION: /**< Reset CANopen communication on device */
                co->Is_Reset_COM = YES;
                break;
            default:
                // Not Support
                break;
            }
        }
    }

    //int32_t index;
    switch( co->NMT_State ){
    case CO_NMT_INITIALIZING:
        //co->NMT_State = CO_NMT_PRE_OPERATIONAL;
        co->NMT_State = co->NMT_State_Init;
        break;
    case CO_NMT_PRE_OPERATIONAL:
        is_sdo_work = YES;

        is_sync_work = YES;
        is_emcy_work = YES;
        break;
    case CO_NMT_OPERATIONAL:
        is_sdo_work = YES;
        is_pdo_work = YES;

        is_sync_work = YES;
        is_emcy_work = YES;
        break;
    case CO_NMT_STOPPED:
        break;
    default:
        // Reserved
        break;
    }

    // HeartBeat
    /*
    if( co->HB_Timer_Ms >= co->HB_Period_Ms &&
        co->HB_Period_Ms != 0 ){

        co->HB_Timer_Ms = 0;
        if( co->Is_Init_Flag ){
            co->Is_Init_Flag = NO;
            co->T_Data[0] = 0;
        }else{
            co->T_Data[0] = co->NMT_State;
        }
        CAN_sendMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_HEARTBEAT, 1, co->T_Data );
    }*/

    if( co->Is_Init_Flag ){
        co->Is_Init_Flag = NO;
        co->T_Data[0] = 0;
        CAN_sendMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_HEARTBEAT, 1, co->T_Data );
    }else if( co->HB_Timer_Ms >= co->HB_Period_Ms && co->HB_Period_Ms != 0 ){
        co->HB_Timer_Ms = 0;
        co->T_Data[0] = co->NMT_State;
        CAN_sendMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_HEARTBEAT, 1, co->T_Data );
    }

    // SDO
    if( CAN_readMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_C2S, co->R_Data ) ){
        co->MailBox_BITF |= ( 1UL << MAIL_BOX_INDEX_SDO_C2S );
        if( is_sdo_work ){
            co_SDO_Routine( co );
            CG_I2C.is_OK_Flag &= co_SDO_Execute( co );
            if( co->SDO_State != SDO_STATE_ABORT ){
                CAN_sendMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_SDO_S2C, CAN_OPEN_DATA_NUM, co->T_Data );
            }
        }
    }

    // SYNC
    co->R_Data[0] = 0;
    if( CAN_readMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_SYNC, co->R_Data ) ){
        co->MailBox_BITF |= ( 1UL << MAIL_BOX_INDEX_SYNC );
        co->DLC = HWREGH( C2000_CAN_BASE + CAN_O_IF2MCTL) & 0x0F;
        if( is_sync_work ){
            // Needs to work
            if( co->DLC <= 1 ){
                co->SYNC_Cnt = co->R_Data[0];
                co->SYNC_Flag = YES;
            }else{
                co->EMCY_State = CO_EMC_SYNC_DATA_LENGTH;
            }
        }
    }

    // PDO
    coPDO_RPDO_Excute( MAIL_BOX_INDEX_RPDO1, co, &co->RPDO1, is_pdo_work );
    coPDO_RPDO_Excute( MAIL_BOX_INDEX_RPDO2, co, &co->RPDO2, is_pdo_work );
    coPDO_RPDO_Excute( MAIL_BOX_INDEX_RPDO3, co, &co->RPDO3, is_pdo_work );
    coPDO_RPDO_Excute( MAIL_BOX_INDEX_RPDO4, co, &co->RPDO4, is_pdo_work );

    if( is_pdo_work ){
        coPDO_TPDO_Excute( MAIL_BOX_INDEX_TPDO1, co, &co->TPDO1 );
        coPDO_TPDO_Excute( MAIL_BOX_INDEX_TPDO2, co, &co->TPDO2 );
        coPDO_TPDO_Excute( MAIL_BOX_INDEX_TPDO3, co, &co->TPDO3 );
        coPDO_TPDO_Excute( MAIL_BOX_INDEX_TPDO4, co, &co->TPDO4 );
    }

    // EMCY
    if( is_emcy_work ){
        /*
        if( co->EMCY_State ){
            co->T_Data[ EMCY_OD_BYTE0_ERROR_CODE_L ] = ( co->EMCY_State >> 0 ) & 0xFF;
            co->T_Data[ EMCY_OD_BYTE1_ERROR_CODE_H ] = ( co->EMCY_State >> 8 ) & 0xFF;
            co->T_Data[ EMCY_OD_BYTE2_ERROR_REG ] = co->GCO.ErrorRegister & 0xFF;
            //
            co->T_Data[ EMCY_OD_BYTE3_RES ] = 0;
            co->T_Data[ EMCY_OD_BYTE4_RES ] = 0;
            co->T_Data[ EMCY_OD_BYTE5_RES ] = 0;
            //
            co->T_Data[ EMCY_OD_BYTE6_ALARM_CODE_M0 ] = CG_BLDC_CTRL_M0.Protect_Ptr->first_fault_user;
            co->T_Data[ EMCY_OD_BYTE7_ALARM_CODE_M1 ] = CG_BLDC_CTRL_M1.Protect_Ptr->first_fault_user;

            co->EMCY_State = CO_EMC_NO_ERROR;
            CAN_sendMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_EMCY, CAN_OPEN_DATA_NUM, co->T_Data );
        }*/

        if( co->EMCY.Transmit_Flag ){
            co->EMCY.Transmit_Flag = NO;
            CAN_sendMessage( C2000_CAN_BASE, MAIL_BOX_INDEX_EMCY, CAN_OPEN_DATA_NUM, co->EMCY.Data );
        }
    }


    if( co->MailBox_BITF ){
        co->NewFrame_Flag = YES;
    }

    //
    co->SYNC_Flag = NO;
    co->TimeUp_1ms_Flag = NO;
    co->MailBox_BITF = 0;

    if( !CG_I2C.Busy_flag ){
        co->SDO_WriteEEP_Busy_Flag = NO;
    }
#endif

}



 /************************** <END OF FILE> *****************************************/



