/**************************************************************************//**
 * @file     misc_func_lib.h
 * @brief    library for Trumman custom misc mini functions.
 * @version  V0.01
 * @date     04. February 2013
 *
 * @note
 * Trunmman Technology Corporation. All rights reserved.
 * Programmer      : Gear.Feng@trumman.com.tw
 *
 * @par
 * Trumman custom library for misc mini functions.
 *
 ******************************************************************************/
#ifndef misc_func_H
#define misc_func_H

#include "Type.h"
 
/*===========================================================================================
    Function Name    : aSCII_to_Unchar
    Input            : 
					   1. char_buffer_0 : input high byte
					   2. char_buffer_1 : input low byte
    Return           : Converted value.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This function converts 2bytes ascii data into a unsigned char.
					   ex: input = "ff", then output = 255.
//==========================================================================================*/
unsigned char aSCII_to_Unchar(unsigned char char_buffer_0, unsigned char char_buffer_1);

/*===========================================================================================
    Function Name    : unchar_to_ASCII
    Input            : 
					   1. char_buffer : input data
					   2. final_char : output 2bytes ascii data
					   				   final_char[0] = high byte, final_char[1] = low byte
    Return           : Null.
    Programmer       : Chaim.Chen@trumman.com.tw, Gear.Feng@trumman.com.tw
    Description      : This function converts an unsigned char data to a 2-byte ascii array. 
		 			   ex: char_buffer = 255, then final_char will get "ff".
//==========================================================================================*/
void unchar_to_ASCII(unsigned char char_buffer,unsigned char *final_char);


/*===========================================================================================
    Function Name    : newtonSqrt
    Input            : x: x
    Return           : result = x^0.5
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t newtonSqrt( int32_t x );

/*===========================================================================================
    Function Name    : tmGCD
    Input            : a = x1, b = x2
    Return           : result GCD
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
int32_t tmGCD( int32_t a, int32_t b );


	
	
#endif	
/************************** <END OF FILE> *****************************************/
