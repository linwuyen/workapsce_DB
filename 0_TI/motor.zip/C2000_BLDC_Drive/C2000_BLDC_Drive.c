/*
 * C2000_BLDC_Drive.c
 *
 *  Created on: 2015/7/20
 *      Author: Chaim.Chen
 */
/*  Trunmman Technology Corporation. All rights reserved. */
#include "IncludeFiles.h"


volatile Struct_BLDC_Drive						CG_BLDC_Drive_M0;

//extern volatile Struct_BLDC_CTRL 				CG_BLDC_CTRL;
//extern volatile Struct_ADC 						CG_ADC;
//extern volatile Struct_Parameter				CG_Parameter;
//extern volatile Struct_Encoder 					CG_Encoder;
extern volatile Struct_MD 						CG_MD;
//extern volatile Struct_Speed 					CG_Speed;
//extern volatile Struct_HWEEP					CG_HWEEP;
//extern volatile Struct_Move 					CG_Move;
//extern volatile Struct_UART485  				CG_UART485;
//extern volatile Struct_IO						CG_IO;
//extern volatile Struct_IO_FUNC					CG_IO_Func;


/*===========================================================================================
    Hall State to UVW output table.
//==========================================================================================*/
#if(1)	// 120 degress Hall
	#if(1)
	const uint8_t Const_Hall_TableA[2][8] = { 6, 5, 1, 0, 3, 4, 2, 6,	// 0:CW, 1:CCW from wired side. HALL A
											6, 2, 4, 3, 0, 1, 5, 6 };  // 6 = unexpected (000,111)
	#else
	// Test ( Another Type of Hall vs Commutation type )
	const uint8_t Const_Hall_TableA[2][8] = { 6, 4, 0, 5, 2, 3, 1, 6,	// 0:CW, 1:CCW from wired side. HALL A
											6, 1, 3, 2, 5, 0, 4, 6 };  // 6 = unexpected (000,111)
	#endif


	const uint8_t Const_Hall_TableB[2][8] = { 6, 2, 4, 3, 0, 1, 5, 6,	// 0:CW, 1:CCW from wired side. HALL B
											6, 5, 1, 0, 3, 4, 2, 6};   // 6 = unexpected (000,111)
#else
	// 60 degress Hall
	const uint8_t Const_Hall_TableA[2][8] = { 3, 4, 6, 5, 2, 6, 1, 0,	// 0:CW, 1:CCW from wired side. HALL A
											0, 1, 6, 2, 5, 6, 4, 3 };  // 6 = unexpected (2,5)

	const uint8_t Const_Hall_TableB[2][8] = { 0, 1, 6, 2, 5, 6, 4, 3,	// 0:CW, 1:CCW from wired side. HALL B												 3, 4, 6, 5, 2, 6, 1, 0};   // 6 = unexpected (2,5)
                                            3, 4, 6, 5, 2, 6, 1, 0};   // 6 = unexpected (2,5)

#endif


const uint8_t Const_Hall_TableA_I01B[2][8] = { 6, 2, 0, 1, 4, 3, 5, 6,   // 0:CW, 1:CCW from wired side. HALL A
                                               6, 5, 3, 4, 1, 0, 2, 6 };  // 6 = unexpected (000,111)

const uint8_t Const_Hall_TableB_I01B[2][8] = { 6, 5, 3, 4, 1, 0, 2, 6,   // 0:CW, 1:CCW from wired side. HALL B
                                               6, 2, 0, 1, 4, 3, 5, 6};   // 6 = unexpected (000,111)


const uint8_t Const_Commutation_UW_Switch_Table[6] = { 1, 0, 5, 4, 3, 2 };


const uint8_t Const_ShuntI_Bottom[ 6 ] = { Shunt_Index_V, Shunt_Index_V, Shunt_Index_W, Shunt_Index_W, Shunt_Index_U, Shunt_Index_U };

const uint32_t Const_Frequence[ DRIVE_FREQUENCE_NUM ] = { 20000, 16000, 12000, 8000, 40000 };

#if(0)
const int32_t Const_Shunt_I_Type[ BLDCDRIVE_NUM ] =
{
	SHUNT_I_TYPE_SAMPLE_ON_SINGLE, SHUNT_I_TYPE_SAMPLE_ON_SINGLE, SHUNT_I_TYPE_SAMPLE_ON_SINGLE, SHUNT_I_TYPE_SAMPLE_ON_SINGLE,	SHUNT_I_TYPE_SAMPLE_FOC,
	SHUNT_I_TYPE_SAMPLE_ON_SINGLE, SHUNT_I_TYPE_SAMPLE_ON_SINGLE
};
#endif

/*
void ( *const commutation_output_M0[ BLDCDRIVE_NUM ] ) ( uint8_t commutation ) =
{
	commutation_6Step_sabs_voltage_M0, commutation_6Step_sabs_voltage_M0, commutation_6Step_sabs_voltage_M0, commutation_6Step_sabs_voltage_M0, commutation_6Step_sabs_voltage_M0,
	commutation_6Step_sabs_voltage_M0, commutation_6Step_sabs_voltage_M0
};

void ( *const commutation_output_M1[ BLDCDRIVE_NUM ] ) ( uint8_t commutation ) =
{
    commutation_6Step_sabs_voltage_M1, commutation_6Step_sabs_voltage_M1, commutation_6Step_sabs_voltage_M1, commutation_6Step_sabs_voltage_M1, commutation_6Step_sabs_voltage_M1,
    commutation_6Step_sabs_voltage_M1, commutation_6Step_sabs_voltage_M1
};
*/

/*===========================================================================================
    Function Name    : variableInitial_BLDCDrive
    Input            : 1.bldc_drive
                       2.mode
                       3.freq
                       4.deadtime
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void variableInitial_BLDCDrive ( Struct_BLDC_Drive *bldc_drive, uint8_t mode, uint32_t freq, uint32_t deadtime )
{
    int32_t pid_output_max;
    //
    //bldc_drive->Motor_Type = MOTOR_BLDC;
    if( bldc_drive->Motor_Type == MOTOR_BDC ){
        bldc_drive->Mode = BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE;
    }else{
        bldc_drive->Mode = mode;
    }

    if( bldc_drive->Mode >= BLDCDRIVE_NUM ){
        bldc_drive->Mode = BLDCDRIVE_6STEP_COMMUTATION_SLOW_DECAY;
    }

    //
    if( freq >= DRIVE_FREQUENCE_NUM ){
        freq = DRIVE_FREQUENCE_8KHz;
    }
    bldc_drive->Frequency = Const_Frequence[ freq ];

    bldc_drive->Period = SYSTEM_FREQUENCE / bldc_drive->Frequency / 2;   // Up down counting

    bldc_drive->Duty_Min_Abs = 0;
    bldc_drive->Duty_Max_Abs = bldc_drive->Period;
    bldc_drive->Duty_Resolution = bldc_drive->Duty_Max_Abs - bldc_drive->Duty_Min_Abs;
    bldc_drive->Duty_Apply_Abs = 0;

    //setADC_UpdateDutyConst( CG_BLDC_Drive.Frequency );

    //
    bldc_drive->DeadTime = deadtime;
    if( bldc_drive->DeadTime < 1 ){
        bldc_drive->DeadTime = 1;
    }
    //

    bldc_drive->Period_Limit = ( bldc_drive->Period * PWM_PERIOD_LIMIT / PERCENTAGE_100 ) - 1;
    bldc_drive->Period_Limit_Brake = 0;//bldc_drive->Period * PWM_PERIOD_LIMIT_BRAKE / PERCENTAGE_100;

    bldc_drive->Commutation_Enable = YES;
    bldc_drive->Commutation = 'C';
    bldc_drive->FOC_Start_Flag = NO;
    bldc_drive->EBrake_Flag = NO;
    bldc_drive->HWOCP_Flag = NO;

    bldc_drive->FOC.Vd = 0;
    bldc_drive->FOC.Vq = 0;

    setupInitial_PID ( ( Struct_PID* ) &bldc_drive->FOC.Id_Controller );
    setupInitial_PID ( ( Struct_PID* ) &bldc_drive->FOC.Iq_Controller );

    il_PID_Set_Input ( ( Struct_PID* ) &bldc_drive->FOC.Id_Controller, 0 );
    il_PID_Set_Input ( ( Struct_PID* ) &bldc_drive->FOC.Iq_Controller, 0 );

    il_PID_Set_KpKiKd ( ( Struct_PID* ) &bldc_drive->FOC.Id_Controller,
                        10,
                        100,
                        0 );
    il_PID_Set_KpKiKd ( ( Struct_PID* ) &bldc_drive->FOC.Iq_Controller,
                        1024,
                        1,
                        0 );

    pid_output_max = ( bldc_drive->Period_Limit * CONST_SQRT3_OVER_3 ) >> CONST_1_BIT_NUM;
    il_PID_Set_MaxMin ( ( Struct_PID* ) &bldc_drive->FOC.Id_Controller,
                        pid_output_max,
                        -pid_output_max );
    il_PID_Set_MaxMin ( ( Struct_PID* ) &bldc_drive->FOC.Iq_Controller,
                        pid_output_max,
                        -pid_output_max );

    //il_FOC_Set_SVM_T_Max ( ( Struct_FOC* ) &bldc_drive->FOC,
    //                      bldc_drive->Period_Limit );
    il_FOC_Set_SVM_T_Max ( ( Struct_FOC* ) &bldc_drive->FOC,
                           bldc_drive->Period - 1 );


}


/*===========================================================================================
    Function Name    : il_SetUp_PWMPin
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up PWM Pin
//==========================================================================================*/
__inline void il_SetUp_PWMPin( void )
{
	EALLOW;

	// Motor 0

	// UT
	PWM_M0_UT_OFF;
	SET_AS_OUTPUT_M0_UT;
	GPIO_M0_UT_OFF;
	//PULL_LOW_UT;
	// UB
	PWM_M0_UB_OFF;
	SET_AS_OUTPUT_M0_UB;
	GPIO_M0_UB_OFF;
	//PULL_LOW_UB;

	// VT
	PWM_M0_VT_OFF;
	SET_AS_OUTPUT_M0_VT;
	GPIO_M0_VT_OFF;
	//PULL_LOW_VT;

	// VB
	PWM_M0_VB_OFF;
	SET_AS_OUTPUT_M0_VB;
	GPIO_M0_VB_OFF;
	//PULL_LOW_VB;

	// WT
	PWM_M0_WT_OFF;
	SET_AS_OUTPUT_M0_WT;
	GPIO_M0_WT_OFF;
	//PULL_LOW_WT;

	// WB
	PWM_M0_WB_OFF;
	SET_AS_OUTPUT_M0_WB;
	GPIO_M0_WB_OFF;

	EDIS;

}

/*===========================================================================================
    Function Name    : il_PWM_Synchronize
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Synchronize PWM
//==========================================================================================*/
__inline void il_PWM_Synchronize( void )
{
    // Time-base registers
    EALLOW;  // This is needed to write to EALLOW protected registers

    //SyncSocRegs.SYNCSELECT.bit.EPWM4SYNCIN = 0;

    PWM_M0_U.TBPRD = CG_BLDC_Drive_M0.Period;                  // Set timer period, PWM frequency = 1 / period
    PWM_M0_U.TBPHS.all = 0;                               // Time-Base Phase Register
    PWM_M0_U.TBCTR = 0;                                   // Time-Base Counter Register
    PWM_M0_U.TBCTL.bit.PRDLD = TB_IMMEDIATE;                  // Set Immediate load
    PWM_M0_U.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;             // Count-updown mode: used for symmetric PWM
    PWM_M0_U.TBCTL.bit.PHSEN = TB_DISABLE;                    // Disable phase loading
    //PWM_M0_U.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;
    PWM_M0_U.EPWMSYNCOUTEN.bit.ZEROEN = 1;

    PWM_M0_U.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    PWM_M0_U.TBCTL.bit.CLKDIV = TB_DIV1;

    PWM_M0_V.TBPRD = CG_BLDC_Drive_M0.Period;                  // Set timer period, PWM frequency = 1 / period
    PWM_M0_V.TBPHS.all = 0;                               // Time-Base Phase Register
    PWM_M0_V.TBCTR = 0;                                   // Time-Base Counter Register
    PWM_M0_V.TBCTL.bit.PRDLD = TB_IMMEDIATE;                  // Set Immediate load
    PWM_M0_V.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;             // Count-updown mode: used for symmetric PWM
    PWM_M0_V.TBCTL.bit.PHSEN = TB_ENABLE;                 // Disable phase loading
    PWM_M0_V.TBCTL.bit.PHSDIR = 1;
    PWM_M0_V.TBPHS.bit.TBPHS = 2;                         // Testing value
    //PWM_M0_V.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
    PWM_M0_V.EPWMSYNCINSEL.bit.SEL = 2;

    PWM_M0_V.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    PWM_M0_V.TBCTL.bit.CLKDIV = TB_DIV1;

    PWM_M0_W.TBPRD = CG_BLDC_Drive_M0.Period;                  // Set timer period, PWM frequency = 1 / period
    PWM_M0_W.TBPHS.all = 0;                               // Time-Base Phase Register
    PWM_M0_W.TBCTR = 0;                                   // Time-Base Counter Register
    PWM_M0_W.TBCTL.bit.PRDLD = TB_IMMEDIATE;                  // Set Immediate load
    PWM_M0_W.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;             // Count-updown mode: used for symmetric PWM
    PWM_M0_W.TBCTL.bit.PHSEN = TB_ENABLE;                 // Disable phase loading
    PWM_M0_W.TBCTL.bit.PHSDIR = 1;
    PWM_M0_W.TBPHS.bit.TBPHS = 2;                         // Testing value
    //PWM_M0_W.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
    PWM_M0_W.EPWMSYNCINSEL.bit.SEL = 2;
    PWM_M0_W.TBCTL.bit.HSPCLKDIV = TB_DIV1;
    PWM_M0_W.TBCTL.bit.CLKDIV = TB_DIV1;

    // disable sync

    il_Delay( CG_BLDC_Drive_M0.Period * 4 );             // make sure sync occured
    while( 1 ){
        if( PWM_M0_U.TBCTR >= CG_BLDC_Drive_M0.Period - 10 ){
            //PWM_M0_U.TBCTL.bit.SYNCOSEL = TB_SYNC_DISABLE;
            PWM_M0_U.EPWMSYNCOUTEN.bit.ZEROEN = 0;
            break;
        }
    }

    EDIS;    // This is needed to disable write to EALLOW protected registers

}

/*===========================================================================================
    Function Name    : il_SetUp_PWMReg
    Input            : 1.bldc_drive
                       2.pwm_u
                       3.pwm_v
                       4.pwm_w
                       5.mode
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up PWM register
//==========================================================================================*/
__inline void il_SetUp_PWMReg( Struct_BLDC_Drive *bldc_drive,
                               struct EPWM_REGS* pwm_u,
                               struct EPWM_REGS* pwm_v,
                               struct EPWM_REGS* pwm_w,
                               uint8_t mode )
{
	EALLOW;  // This is needed to write to EALLOW protected registers

	// Setup shadow register load on ZERO

	pwm_u->CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	pwm_u->CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	pwm_u->CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;	// load on CTR=Zero
	pwm_u->CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;	// load on CTR=Zero

	pwm_v->CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	pwm_v->CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	pwm_v->CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;	// load on CTR=Zero
	pwm_v->CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;	// load on CTR=Zero

	pwm_w->CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	pwm_w->CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	pwm_w->CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;	// load on CTR=Zero
	pwm_w->CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;	// load on CTR=Zero

	// Set Compare values
	bldc_drive->Duty_U = 0;
	pwm_u->CMPA.bit.CMPA = bldc_drive->Period - bldc_drive->Duty_U;

	bldc_drive->Duty_V = 0;
	pwm_v->CMPA.bit.CMPA = bldc_drive->Period - bldc_drive->Duty_V;

	bldc_drive->Duty_W = 0;
	pwm_w->CMPA.bit.CMPA = bldc_drive->Period - bldc_drive->Duty_W;

	// Set actions

	switch( mode ){
	case BLDCDRIVE_6STEP_COMMUTATION_SABS_VOLTAGE:
	case BLDCDRIVE_FOC:
	default:

		// Set actions
	    pwm_u->AQCTLA.bit.CAU = AQ_SET;				// Set PWM2A on event A, up count
	    pwm_u->AQCTLA.bit.CAD = AQ_CLEAR;			// Clear PWM2A on event A, down count

	    //pwm_u->AQCTLB.bit.CAU = AQ_CLEAR;			// Set PWM2B on event B, up count
	    //pwm_u->AQCTLB.bit.CAD = AQ_SET;				// Clear PWM2B on event B, down count

	    pwm_v->AQCTLA.bit.CAU = AQ_SET;
	    pwm_v->AQCTLA.bit.CAD = AQ_CLEAR;

	    //pwm_v->AQCTLB.bit.CAU = AQ_CLEAR;
	    //pwm_v->AQCTLB.bit.CAD = AQ_SET;

	    pwm_w->AQCTLA.bit.CAU = AQ_SET;
	    pwm_w->AQCTLA.bit.CAD = AQ_CLEAR;

	    //pwm_w->AQCTLB.bit.CAU = AQ_CLEAR;
	    //pwm_w->AQCTLB.bit.CAD = AQ_SET;

	    if( CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ||
	        CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_LOWSIDE_REVERSE ){

	        pwm_u->AQCTLB.bit.CAU = AQ_CLEAR;            // Set PWM2B on event B, up count
	        pwm_u->AQCTLB.bit.CAD = AQ_SET;              // Clear PWM2B on event B, down count

	        pwm_v->AQCTLB.bit.CAU = AQ_CLEAR;
	        pwm_v->AQCTLB.bit.CAD = AQ_SET;

	        pwm_w->AQCTLB.bit.CAU = AQ_CLEAR;
	        pwm_w->AQCTLB.bit.CAD = AQ_SET;

        }else{

            pwm_u->AQCTLB.all = AQ_CLEAR;
            pwm_v->AQCTLB.all = AQ_CLEAR;
            pwm_w->AQCTLB.all = AQ_CLEAR;

        }

		// Set dead time
		pwm_u->DBCTL.bit.HALFCYCLE = 0;
		//pwm_u->DBCTL.bit.POLSEL = DB_ACTV_HIC;
		//pwm_u->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
		pwm_u->DBCTL.bit.IN_MODE = DBA_ALL;
		pwm_u->DBRED.bit.DBRED = bldc_drive->DeadTime;
		pwm_u->DBFED.bit.DBFED = bldc_drive->DeadTime;

		pwm_v->DBCTL.bit.HALFCYCLE = 0;
		//pwm_v->DBCTL.bit.POLSEL = DB_ACTV_HIC;
		//pwm_v->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
		pwm_v->DBCTL.bit.IN_MODE = DBA_ALL;
		pwm_v->DBRED.bit.DBRED = bldc_drive->DeadTime;
		pwm_v->DBFED.bit.DBFED = bldc_drive->DeadTime;

		pwm_w->DBCTL.bit.HALFCYCLE = 0;
		//pwm_w->DBCTL.bit.POLSEL = DB_ACTV_HIC;
		//pwm_w->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
		pwm_w->DBCTL.bit.IN_MODE = DBA_ALL;
		pwm_w->DBRED.bit.DBRED = bldc_drive->DeadTime;
		pwm_w->DBFED.bit.DBFED = bldc_drive->DeadTime;

		if( CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_NORMAL ){
		    pwm_u->DBCTL.bit.POLSEL = DB_ACTV_HIC;
		    pwm_v->DBCTL.bit.POLSEL = DB_ACTV_HIC;
		    pwm_w->DBCTL.bit.POLSEL = DB_ACTV_HIC;

            pwm_u->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
            pwm_v->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
            pwm_w->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;

        }else if( CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_LOWSIDE_REVERSE ){
            pwm_u->DBCTL.bit.POLSEL = DB_ACTV_HI;
            pwm_v->DBCTL.bit.POLSEL = DB_ACTV_HI;
            pwm_w->DBCTL.bit.POLSEL = DB_ACTV_HI;

            pwm_u->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
            pwm_v->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
            pwm_w->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;

        }else{  // GATEDRIVER_TYPE_PWM_FREE
            pwm_u->DBCTL.bit.POLSEL = DB_ACTV_HI;
            pwm_v->DBCTL.bit.POLSEL = DB_ACTV_HI;
            pwm_w->DBCTL.bit.POLSEL = DB_ACTV_HI;

            pwm_u->DBCTL.bit.OUT_MODE = DBA_ENABLE;
            pwm_v->DBCTL.bit.OUT_MODE = DBA_ENABLE;
            pwm_w->DBCTL.bit.OUT_MODE = DBA_ENABLE;

        }

		break;
	}

#if(1)
	// Force to low state when TZ is set

	pwm_u->TZSEL.bit.DCAEVT2 = 1;
	pwm_u->TZSEL.bit.DCBEVT2 = 1;

	pwm_v->TZSEL.bit.DCAEVT2 = 1;
	pwm_v->TZSEL.bit.DCBEVT2 = 1;

	pwm_w->TZSEL.bit.DCAEVT2 = 1;
	pwm_w->TZSEL.bit.DCBEVT2 = 1;

	pwm_u->TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;
	//pwm_u->TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;

	pwm_u->TZCTL.bit.DCAEVT1 = TZ_FORCE_LO;
	//pwm_u->TZCTL.bit.DCBEVT1 = TZ_FORCE_LO;

	pwm_u->TZCTL.bit.TZA = TZ_FORCE_LO;
	//pwm_u->TZCTL.bit.TZB = TZ_FORCE_LO;

	pwm_v->TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;
	//pwm_v->TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;

	pwm_v->TZCTL.bit.DCAEVT1 = TZ_FORCE_LO;
	//pwm_v->TZCTL.bit.DCBEVT1 = TZ_FORCE_LO;

	pwm_v->TZCTL.bit.TZA = TZ_FORCE_LO;
	//pwm_v->TZCTL.bit.TZB = TZ_FORCE_LO;

	pwm_w->TZCTL.bit.DCAEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;
	//pwm_w->TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;

	pwm_w->TZCTL.bit.DCAEVT1 = TZ_FORCE_LO;
	//pwm_w->TZCTL.bit.DCBEVT1 = TZ_FORCE_LO;

	pwm_w->TZCTL.bit.TZA = TZ_FORCE_LO;
	//pwm_w->TZCTL.bit.TZB = TZ_FORCE_LO;

	if( CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_LOWSIDE_REVERSE ||
        CG_BLDC_Drive_M0.GateDriver_Type == GATEDRIVER_TYPE_PWM_FREE ){

	    pwm_u->TZCTL.bit.DCBEVT2 = TZ_FORCE_HI;
        pwm_u->TZCTL.bit.DCBEVT1 = TZ_FORCE_HI;
        pwm_u->TZCTL.bit.TZB = TZ_FORCE_HI;

        pwm_v->TZCTL.bit.DCBEVT2 = TZ_FORCE_HI;
        pwm_v->TZCTL.bit.DCBEVT1 = TZ_FORCE_HI;
        pwm_v->TZCTL.bit.TZB = TZ_FORCE_HI;

        pwm_w->TZCTL.bit.DCBEVT2 = TZ_FORCE_HI;
        pwm_w->TZCTL.bit.DCBEVT1 = TZ_FORCE_HI;
        pwm_w->TZCTL.bit.TZB = TZ_FORCE_HI;

    }else{

        pwm_u->TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;
        pwm_u->TZCTL.bit.DCBEVT1 = TZ_FORCE_LO;
        pwm_u->TZCTL.bit.TZB = TZ_FORCE_LO;

        pwm_v->TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;
        pwm_v->TZCTL.bit.DCBEVT1 = TZ_FORCE_LO;
        pwm_v->TZCTL.bit.TZB = TZ_FORCE_LO;

        pwm_w->TZCTL.bit.DCBEVT2 = TZ_FORCE_LO;//TZ_FORCE_LO;
        pwm_w->TZCTL.bit.DCBEVT1 = TZ_FORCE_LO;
        pwm_w->TZCTL.bit.TZB = TZ_FORCE_LO;

    }

	pwm_u->TZDCSEL.bit.DCAEVT2 = 2;			//DCAH = high, DCAL = don't care
	pwm_u->TZDCSEL.bit.DCBEVT2 = 2;			//DCBH = high, DCBL = don't care

	pwm_v->TZDCSEL.bit.DCAEVT2 = 2;
	pwm_v->TZDCSEL.bit.DCBEVT2 = 2;

	pwm_w->TZDCSEL.bit.DCAEVT2 = 2;
	pwm_w->TZDCSEL.bit.DCBEVT2 = 2;

	pwm_u->DCACTL.bit.EVT2FRCSYNCSEL = 1; 	// Source Is Asynchronous Signal
	pwm_u->DCACTL.bit.EVT2SRCSEL = 0;		// Source Is DCAEVT2 Signal ( No filter )

	pwm_v->DCACTL.bit.EVT2FRCSYNCSEL = 1; 	// Source Is Asynchronous Signal
	pwm_v->DCACTL.bit.EVT2SRCSEL = 0;		// Source Is DCAEVT2 Signal ( No filter )

	pwm_w->DCACTL.bit.EVT2FRCSYNCSEL = 1; 	// Source Is Asynchronous Signal
	pwm_w->DCACTL.bit.EVT2SRCSEL = 0;		// Source Is DCAEVT2 Signal ( No filter )

	pwm_u->DCBCTL.bit.EVT2FRCSYNCSEL = 1; 	// Source Is Asynchronous Signal
	pwm_u->DCBCTL.bit.EVT2SRCSEL = 0;		// Source Is DCAEVT2 Signal ( No filter )

	pwm_v->DCBCTL.bit.EVT2FRCSYNCSEL = 1; 	// Source Is Asynchronous Signal
	pwm_v->DCBCTL.bit.EVT2SRCSEL = 0;		// Source Is DCAEVT2 Signal ( No filter )

	pwm_w->DCBCTL.bit.EVT2FRCSYNCSEL = 1; 	// Source Is Asynchronous Signal
	pwm_w->DCBCTL.bit.EVT2SRCSEL = 0;		// Source Is DCAEVT2 Signal ( No filter )

#endif

	EDIS;    // This is needed to disable write to EALLOW protected registers
}

/*===========================================================================================
    Function Name    : il_Setup_ADCTrigger_PWM
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Set up ADC trigger src = PWM
//==========================================================================================*/
__inline void il_Setup_ADCTrigger_PWM( void )
{
    // Time-base registers
    EALLOW;  // This is needed to write to EALLOW protected registers

    // Event trigger ( ADC trigger src )

    PWM_M0_U.ETSEL.bit.SOCAEN  = 1;                // Enable SOC on A group
    PWM_M0_U.ETSEL.bit.SOCASEL = ET_CTR_PRD;       // Enable event time-base counter equal to period (TBCTR = TBPRD)
    PWM_M0_U.ETPS.bit.SOCAPRD  = ET_1ST;               // Generate pulse on 1st event

    PWM_M0_U.ETSEL.bit.SOCBEN  = 1;                // Enable SOC on A group
    PWM_M0_U.ETSEL.bit.SOCBSEL = ET_CTR_ZERO;              // Enable event time-base counter equal to zero. (TBCTR = 0x0000)
    PWM_M0_U.ETPS.bit.SOCBPRD  = ET_1ST;               // Generate pulse on 1st event

    PWM_M0_U.ETSEL.bit.INTEN = 1;
    PWM_M0_U.ETSEL.bit.INTSEL = ET_CTR_PRD;
    PWM_M0_U.ETPS.bit.INTPRD = ET_1ST;

    EDIS;    // This is needed to disable write to EALLOW protected registers
}

/*===========================================================================================
    Function Name    : il_Setup_PWM_Trip
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : PWM Trip is used for HWOCP
//==========================================================================================*/
__inline void il_Setup_PWM_Trip( void )
{
    EALLOW;  // This is needed to write to EALLOW protected registers
    // M0
    PWM_M0_U.DCTRIPSEL.bit.DCAHCOMPSEL = 3;   // Trip4
    PWM_M0_U.DCTRIPSEL.bit.DCBHCOMPSEL = 3;

    PWM_M0_V.DCTRIPSEL.bit.DCAHCOMPSEL = 3;
    PWM_M0_V.DCTRIPSEL.bit.DCBHCOMPSEL = 3;

    PWM_M0_W.DCTRIPSEL.bit.DCAHCOMPSEL = 3;
    PWM_M0_W.DCTRIPSEL.bit.DCBHCOMPSEL = 3;

    EDIS;    // This is needed to disable write to EALLOW protected registers
}

/*===========================================================================================
    Function Name    : setupInitial_BLDCDrive
    Input            :
					   1.mode: To decide the BLDC drive mode.
							0 = 6step commutation slow decay.
							1 = 6step commutation fast decay.
							2 = 6step commutation sabs
							3 = 6step commutation sabs
							4 = Sine wave drive.
					   2.freq: PWM frequency.
					   3.deadtime: It must be set with a non-zero value in mode 2, 3 and 4.
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : BLDC drive mode setup. Here EPWM was used as the main tool for the drive.
					   More info. please read user manu at EPWM setting.
//==========================================================================================*/
void setupInitial_BLDCDrive( uint8_t mode, uint32_t freq, uint32_t deadtime )
{

    variableInitial_BLDCDrive ( (Struct_BLDC_Drive*)&CG_BLDC_Drive_M0, mode, freq, deadtime );

    CG_BLDC_Drive_M0.Commutation_Out = &commutation_6Step_sabs_voltage_M0;
    CG_BLDC_Drive_M0.Duty_Out = &bldcDrive_OutputDuty_M0;
    CG_BLDC_Drive_M0.StepToSineWave = &changeDriveMode_6stepToSineWave_M0;
    CG_BLDC_Drive_M0.SineWaveToStep = &changeDriveMode_SineWaveTo6step_M0;

	il_SetUp_PWMPin();

	il_PWM_Synchronize();

	il_SetUp_PWMReg( (Struct_BLDC_Drive*)&CG_BLDC_Drive_M0,
                     (struct EPWM_REGS*) &PWM_M0_U,
                     (struct EPWM_REGS*) &PWM_M0_V,
                     (struct EPWM_REGS*) &PWM_M0_W,
                     CG_BLDC_Drive_M0.Mode );

	il_Setup_PWM_Trip();

	il_Setup_ADCTrigger_PWM();


}


/*===========================================================================================
    Function Name    : bldcDrive_OutputDuty_M0
    Input            : 1.duty_u
                       2.duty_v
                       3.duty_w
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      :
//==========================================================================================*/
void bldcDrive_OutputDuty_M0( int32_t duty_u, int32_t duty_v, int32_t duty_w )
{

    CG_BLDC_Drive_M0.Duty_U = duty_u;
    CG_BLDC_Drive_M0.Duty_V = duty_v;
    CG_BLDC_Drive_M0.Duty_W = duty_w;

#if(!TEST_DUTY_UPDATE_FROM_ADC)
    PWM_M0_U.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - duty_u;
    PWM_M0_V.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - duty_v;
    PWM_M0_W.CMPA.bit.CMPA = CG_BLDC_Drive_M0.Period - duty_w;
#endif

}

/*===========================================================================================
    Function Name    : changeDriveMode_6stepToSineWave_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : From 6step to Sinewave
//==========================================================================================*/
void changeDriveMode_6stepToSineWave_M0( void )
{

	//DINT;
	EALLOW;  // This is needed to write to EALLOW protected registers

	/*
	GPIO_M0_UT_OFF;
	GPIO_M0_VT_OFF;
	GPIO_M0_WT_OFF;

	GPIO_M0_UB_OFF;
	GPIO_M0_VB_OFF;
	GPIO_M0_WB_OFF;
	*/

	PWM_M0_UT_OFF;
	PWM_M0_VT_OFF;
	PWM_M0_WT_OFF;
	PWM_M0_UB_OFF;
	PWM_M0_VB_OFF;
	PWM_M0_WB_OFF;

	bldcDrive_OutputDuty_M0( 0, 0, 0 );

	PWM_M0_UT_ON;
	PWM_M0_VT_ON;
	PWM_M0_WT_ON;
	PWM_M0_UB_ON;
	PWM_M0_VB_ON;
	PWM_M0_WB_ON;

	CG_BLDC_Drive_M0.FOC_Start_Flag = YES;

	EDIS;    // This is needed to disable write to EALLOW protected registers
	//EINT;   // Enable Global interrupt INTM


}


/*===========================================================================================
    Function Name    : changeDriveMode_SineWaveTo6step_M0
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : From 6step to Sinewave
//==========================================================================================*/
void changeDriveMode_SineWaveTo6step_M0( void )
{

	//DINT;
	EALLOW;  // This is needed to write to EALLOW protected registers
	/*
	GPIO_M0_UT_OFF;
	GPIO_M0_VT_OFF;
	GPIO_M0_WT_OFF;

	GPIO_M0_UB_OFF;
	GPIO_M0_VB_OFF;
	GPIO_M0_WB_OFF;
	*/

	PWM_M0_UT_OFF;
	PWM_M0_VT_OFF;
	PWM_M0_WT_OFF;
	PWM_M0_UB_OFF;
	PWM_M0_VB_OFF;
	PWM_M0_WB_OFF;

	bldcDrive_OutputDuty_M0( 0, 0, 0 );

	CG_BLDC_Drive_M0.FOC_Start_Flag = NO;

	EDIS;    // This is needed to disable write to EALLOW protected registers
	//EINT;   // Enable Global interrupt INTM

}

/*===========================================================================================
    Function Name    : commutation_6Step_sabs_voltage_M0 ( single abs )
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 6 step commutation function with top switch, when duty off doing motor short brake.
    				   commutation from 'B' to normal commutation, it needs a 'C' to make all PWM_X.DBCTL.bit.IN_MODE = DBA_ALL;
//==========================================================================================*/
void commutation_6Step_sabs_voltage_M0 ( uint8_t commutation )
{
    uint8_t dummy_commutation;

	//DINT;
	EALLOW;  // This is needed to write to EALLOW protected registers

	dummy_commutation = commutation;

	if( CG_BLDC_Drive_M0.EBrake_Flag == YES && commutation != 'C' ){
		dummy_commutation = 'B';
	}

	if( CG_BLDC_Drive_M0.Commutation_Enable == YES &&
		CG_BLDC_Drive_M0.FOC_Start_Flag == NO ){

        GPIO_M0_UT_OFF;
        GPIO_M0_VT_OFF;
        GPIO_M0_WT_OFF;

        GPIO_M0_UB_OFF;
        GPIO_M0_VB_OFF;
        GPIO_M0_WB_OFF;

        CG_BLDC_Drive_M0.Commutation = dummy_commutation;

        switch( dummy_commutation ){
            case 0:															// W->V

                PWM_M0_UT_OFF;
                PWM_M0_UB_OFF;
                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_WT_ON;
                PWM_M0_WB_ON;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_VT_OFF;
                PWM_M0_VB_ON;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_LOW;

                //CG_ADC.Motor_0.Shunt_I_Pointer = ADC_Index_Shunt_V;

                break;
            case 1:	 														// U->V

                PWM_M0_WT_OFF;
                PWM_M0_WB_OFF;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_UT_ON;
                PWM_M0_UB_ON;
                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_VT_OFF;
                PWM_M0_VB_ON;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_LOW;

                //CG_ADC.Motor_0.Shunt_I_Pointer = ADC_Index_Shunt_V;

                break;
            case 2:															// U->W

                PWM_M0_VT_OFF;
                PWM_M0_VB_OFF;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_UT_ON;
                PWM_M0_UB_ON;
                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_WT_OFF;
                PWM_M0_WB_ON;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_LOW;

                //CG_ADC.Motor_0.Shunt_I_Pointer = ADC_Index_Shunt_W;

                break;
            case 3:															// V->W

                PWM_M0_UT_OFF;
                PWM_M0_UB_OFF;
                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_VT_ON;
                PWM_M0_VB_ON;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_WT_OFF;
                PWM_M0_WB_ON;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_LOW;

                //CG_ADC.Motor_0.Shunt_I_Pointer = ADC_Index_Shunt_W;

                break;
            case 4:															// V->U

                PWM_M0_WT_OFF;
                PWM_M0_WB_OFF;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_VT_ON;
                PWM_M0_VB_ON;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_UT_OFF;
                PWM_M0_UB_ON;
                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_LOW;

                //CG_ADC.Motor_0.Shunt_I_Pointer = ADC_Index_Shunt_U;

                break;
            case 5:															// W->U

                PWM_M0_VT_OFF;
                PWM_M0_VB_OFF;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_WT_ON;
                PWM_M0_WB_ON;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                PWM_M0_UT_OFF;
                PWM_M0_UB_ON;
                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_LOW;

                //CG_ADC.Motor_0.Shunt_I_Pointer = ADC_Index_Shunt_U;

                break;
            case 'B':

                PWM_M0_UT_OFF;
                PWM_M0_VT_OFF;
                PWM_M0_WT_OFF;
                PWM_M0_UB_OFF;
                PWM_M0_VB_OFF;
                PWM_M0_WB_OFF;

                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                //il_Delay( SMALL_DELAY );

                PWM_M0_UB_ON;
                PWM_M0_VB_ON;
                PWM_M0_WB_ON;

                CG_BLDC_Drive_M0.EBrake_Flag = YES;

                break;
            case 'C':
            default:

                PWM_M0_UT_OFF;
                PWM_M0_VT_OFF;
                PWM_M0_WT_OFF;
                PWM_M0_UB_OFF;
                PWM_M0_VB_OFF;
                PWM_M0_WB_OFF;

                PWM_M0_U.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;
                PWM_M0_V.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;
                PWM_M0_W.AQCSFRC.bit.CSFA = AQ_FORCE_DISABLE;

                CG_BLDC_Drive_M0.EBrake_Flag = NO;

                break;

        }
	}

	//if( CG_ADC.Motor_0.Shunt_I_Pointer >= ADC_Index_Shunt_NUM ){
	//	CG_ADC.Motor_0.Shunt_I_Pointer = 0;
	//}


	EDIS;    // This is needed to disable write to EALLOW protected registers
	//EINT;   // Enable Global interrupt INTM


}


/*===========================================================================================
    Function Name    : commutation_6Step_sabs_voltage_PWM_ON ( single abs )
    Input            : Null
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : 6 step commutation function with Sabs PWM-On.
//==========================================================================================*/
void commutation_6Step_sabs_voltage_PWM_ON ( uint8_t commutation )
{

}

/*===========================================================================================
    Function Name    : swOutputDuty_ByADC
    Input            : 1.bldc_drive
                       2.is_ctrl_iq
                       3.target
    Return           : Null
    Programmer       : Chaim.Chen@trumman.com.tw
    Description      : Sine wave functions.
//==========================================================================================*/
void swOutputDuty_ByADC( Struct_BLDC_Drive *bldc_drive, int8_t is_ctrl_iq, int32_t target )
{

	//int32_t angle = 0;
	Struct_FOC	*foc;
	int32_t vd_limit;

	//CG_MD.Test_tp1			= FREE_RUN_TIMER.TIM.all;

	foc = ( Struct_FOC* ) &bldc_drive->FOC;

	// Iq
	if( is_ctrl_iq ){
	    foc->Iq_Controller.Input = target;
        foc->Iq_Controller.Feedback = foc->Shunt_Iq;
        il_PID_Run_PI ( ( Struct_PID* ) &foc->Iq_Controller );
        foc->Vq = foc->Iq_Controller.Output;
	}else{
	    foc->Vq = target;
	}

	// Id

	vd_limit = foc->Vq;
    if( vd_limit < 0 ){
        vd_limit *= -1;
    }
    vd_limit = ( vd_limit * 1773 ) >> 10;   // 3^0.5
    /*
    if( vd_limit > foc->Iq_Controller.Output_Restraint_Max ){
        vd_limit = foc->Iq_Controller.Output_Restraint_Max;
    }*/
    if( vd_limit > foc->SVM_T_Max ){
        vd_limit = foc->SVM_T_Max;
    }

	foc->Id_Controller.Feedback = foc->Shunt_Id;
	foc->Id_Controller.Output_Restraint_Max = vd_limit;
	foc->Id_Controller.Output_Restraint_Min = -vd_limit;

	il_PID_Run_PI ( ( Struct_PID* ) &foc->Id_Controller );
	foc->Vd = foc->Id_Controller.Output;

	il_FOC_IPark_Run ( foc );
	//il_SVPWM_Run ( foc );
	il_SVPWM_RunSimple ( foc );

	bldc_drive->Duty_Out( foc->Va,
	                      foc->Vb,
	                      foc->Vc );


	//CG_MD.Test_tp2			= FREE_RUN_TIMER.TIM.all;
	//CG_MD.Test_time 		= CG_MD.Test_tp1 - CG_MD.Test_tp2;

}


/************************** <END OF FILE> *****************************************/


