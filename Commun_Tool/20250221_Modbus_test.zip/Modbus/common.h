/*
 * common.h
 *
 *  Created on: Mar 1, 2024
 *      Author: User
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "board.h"

#include "HwConfig.h"
#include "timetask.h"
#include "c28math.h"
#include "c28param.h"
#include "initHRPWM.h"
#include "cdebug.h"
//#include "cla/initCLA.h"




#endif /* COMMON_H_ */
