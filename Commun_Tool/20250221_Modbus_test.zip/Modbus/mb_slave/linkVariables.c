/*
 *  File Name: linkVariables.c
 *
 *  Created on: 2/21/2025
 *  Author: POWER-532A86
 */

#include "ModbusCommon.h"
#include "ModbusSlave.h"


void initRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	p->pReg->u16COMmonHEAder = 2423; 
	p->pReg->u16COMmonLENgth = 4; 
	p->pReg->u16MAChineINFOrmationOFFSet = 6; 
	p->pReg->u16USERPARameterOFFSet = 14; 
	p->pReg->u16ADVAncePARameterOFFSet = 28; 
	p->pReg->u16COMmonCHEcksum = 2475; 
	p->pReg->u16MAChineLENgth = 8; 
	p->pReg->u16COUntryCODe = 886; 
	p->pReg->u16VENderid = 2423; 
	p->pReg->u16PROductid = 1; 
	p->pReg->u16PARtid = 3; 
	p->pReg->u16MODuleid = 0; 
	p->pReg->u16USERPARameterLENgth = 14; 
	p->pReg->s16VOLtageREFerence = MB_SFtoQ15(0); 
	p->pReg->u16ADVAncePARameterLENgth = 34; 
	p->pReg->u16ADVAncePASsword = 0; 
	p->pReg->f32HARdwareSLEwrate = 100000; 
}

void readRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
}

void writeReg(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
	switch(p->info.rwfrom) {
	default:
	    break;
	}
}

void writeRegN(void *v){ 

	SCI_MODBUS *p = (SCI_MODBUS *) v;
}

