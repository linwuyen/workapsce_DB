/*
 *  File Name: linkEeprom.h
 *
 *  Created on: 2/21/2025
 *  Author: POWER-532A86
 */

typedef struct {
    uint16_t size;
    void *ptr;
} EE_REG;
typedef EE_REG * HAL_EEREG;

#define _BLK16_USERPARAMS	9
uint16_t blkUserParams[_BLK16_USERPARAMS];
const EE_REG regUserParams[5] = {
              {2, (void*)&},
              {2, (void*)&},
              {2, (void*)&},
              {2, (void*)&},
              {1, (void*)&blkUserParams[8]}};
#define _TABLE_USERPARAMS	5

#define _BLK16_ADVPARAMS	21
uint16_t blkAdvParams[_BLK16_ADVPARAMS];
const EE_REG regAdvParams[6] = {
              {4, (void*)&},
              {4, (void*)&},
              {4, (void*)&},
              {4, (void*)&},
              {4, (void*)&},
              {1, (void*)&blkAdvParams[20]}};
#define _TABLE_ADVPARAMS	6

