
//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "c2000ware_libraries.h"
#include "mb_slave/ModbusSlave.h"


char *msg= "Hello\n";
SCI_RxFIFOLevel  LEVEL;
//
// Main
//
void main(void)
{

    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // PinMux and Peripheral Initialization
    //
    Board_init();

    //
    // C2000Ware Library initialization
    //
    C2000Ware_libraries_init();

    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    while(1)
    {

//        LEVEL  = SCI_getRxFIFOStatus(mySCI0_BASE);
//
//      if( 1< SCI_getRxFIFOStatus(mySCI0_BASE))
//      {
//          SCI_writeCharArray(mySCI0_BASE, (uint16_t*)msg, 8);
//          uint16_t data = SCI_readCharBlockingFIFO(mySCI0_BASE);
//      }


          exeModbusSlave((SCI_MODBUS *)&mbcomm);

    }
}

//
// End of File
//
