/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

#define GPIO_PIN_EPWM1A 0
#define GPIO_PIN_EPWM1B 1
#define GPIO_PIN_SDAA 91
#define GPIO_PIN_SCLA 92
#define GPIO_PIN_SCIRXDA 64
#define GPIO_PIN_SCITXDA 65
#define GPIO_PIN_SPISIMOA 58
#define GPIO_PIN_SPISOMIA 59
#define GPIO_PIN_SPICLKA 60
#define GPIO_PIN_SPISTEA 61

#define AD_A_BASE ADCA_BASE
#define AD_A_RESULT_BASE ADCARESULT_BASE
#define AD_B_BASE ADCB_BASE
#define AD_B_RESULT_BASE ADCBRESULT_BASE
#define AD_C_BASE ADCC_BASE
#define AD_C_RESULT_BASE ADCCRESULT_BASE
#define AD_D_BASE ADCD_BASE
#define AD_D_RESULT_BASE ADCDRESULT_BASE

#define IO_SENSE_BASE CMPSS1_BASE
#define IO_SHARE_BASE CMPSS2_BASE
#define VIN_SENSE_BASE CMPSS3_BASE
#define IL_SENSE_BASE CMPSS4_BASE
#define OVP_SENSE_BASE CMPSS5_BASE
#define VO_SENSE_BASE CMPSS6_BASE
#define VO_SHARE_BASE CMPSS7_BASE
#define IEL_SENSE_BASE CMPSS8_BASE

#define SWTIRMER_BASE CPUTIMER2_BASE

#define DACA_TP209_BASE DACA_BASE
#define DACB_TP208_BASE DACB_BASE
#define DACC_TP210_BASE DACC_BASE

#define BUCK_PWM1_BASE EPWM1_BASE

#define DEBUG_0 19
#define DEBUG_1 20
#define DEBUG_2 21
#define LEO_0 22
#define LEO_1 23
#define LED_2 24
#define EL_UnReg_STATUS 42
#define EL_OTP_STATUS 47
#define EL_ON_OFF 46
#define DEBUG_3 99
#define SNDBDR_BOOT1 72

#define EEPROM_BASE I2CA_BASE
#define EEPROM_BITRATE 400000
#define EEPROM_SLAVE_ADDRESS 0
#define EEPROM_OWN_SLAVE_ADDRESS 0


// Interrupt Setings for INT_AD_A_1
#define INT_AD_A_1 INT_ADCA1
#define INT_AD_A_1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP1
extern __interrupt void INT_ADC_EOC_ISR(void);


#define DEBUG_SCI_BASE SCIA_BASE
#define DEBUG_SCI_BAUDRATE 115200
#define DEBUG_SCI_CONFIG_WLEN SCI_CONFIG_WLEN_8
#define DEBUG_SCI_CONFIG_STOP SCI_CONFIG_STOP_ONE
#define DEBUG_SCI_CONFIG_PAR SCI_CONFIG_PAR_EVEN

#define DAC8812_BASE SPIA_BASE
#define DAC8812_BITRATE 10000000

void	Board_init();
void	ADC_init();
void	CMPSS_init();
void	CPUTIMER_init();
void	DAC_init();
void	EPWM_init();
void	GPIO_init();
void	I2C_init();
void	INTERRUPT_init();
void	SCI_init();
void	SPI_init();
void	PinMux_init();

#endif  // end of BOARD_H definition
