/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"

void Board_init()
{
	EALLOW;

	PinMux_init();
	ASYSCTL_init();
	ADC_init();
	CPUTIMER_init();
	DAC_init();
	EPWM_init();
	EPWMXBAR_init();
	GPIO_init();
	SCI_init();
	INTERRUPT_init();

	EDIS;
}

void PinMux_init()
{
	//
	// EPWM1 -> BUCK_PWM1 Pinmux
	//
	GPIO_setPinConfig(GPIO_0_EPWM1_A);
	GPIO_setPinConfig(GPIO_1_EPWM1_B);
	// GPIO13 -> DEBUG_CLA Pinmux
	GPIO_setPinConfig(GPIO_13_GPIO13);
	// GPIO12 -> DEBUG_C28 Pinmux
	GPIO_setPinConfig(GPIO_12_GPIO12);
	//
	// SCIA -> DEBUG_SCI Pinmux
	//
	GPIO_setPinConfig(GPIO_28_SCIA_RX);
	GPIO_setPinConfig(GPIO_29_SCIA_TX);

}

void ADC_init(){
	//AD_A initialization

	// ADC Initialization: Write ADC configurations and power up the ADC
	// Configures the ADC module's offset trim
	ADC_setOffsetTrimAll(ADC_REFERENCE_INTERNAL,ADC_REFERENCE_3_3V);
	// Configures the analog-to-digital converter module prescaler.
	ADC_setPrescaler(AD_A_BASE, ADC_CLK_DIV_1_0);
	// Sets the timing of the end-of-conversion pulse
	ADC_setInterruptPulseMode(AD_A_BASE, ADC_PULSE_END_OF_CONV);
	// Powers up the analog-to-digital converter core.
	ADC_enableConverter(AD_A_BASE);
	// Delay for 1ms to allow ADC time to power up
	DEVICE_DELAY_US(5000);

	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	// Disables SOC burst mode.
	ADC_disableBurstMode(AD_A_BASE);
	// Sets the priority mode of the SOCs.
	ADC_setSOCPriority(AD_A_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	// Start of Conversion 0 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 11 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(AD_A_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN3, 11U);
	ADC_setInterruptSOCTrigger(AD_A_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 1 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN2
	//	 	Sample Window	: 11 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(AD_A_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN2, 11U);
	ADC_setInterruptSOCTrigger(AD_A_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);
	// ADC Interrupt 1 Configuration
	// 		SOC/EOC number	: 1
	// 		Interrupt Source: enabled
	// 		Continuous Mode	: disabled
	ADC_setInterruptSource(AD_A_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER1);
	ADC_enableInterrupt(AD_A_BASE, ADC_INT_NUMBER1);
	ADC_clearInterruptStatus(AD_A_BASE, ADC_INT_NUMBER1);
	ADC_disableContinuousMode(AD_A_BASE, ADC_INT_NUMBER1);

	//AD_C initialization

	// ADC Initialization: Write ADC configurations and power up the ADC
	// Configures the ADC module's offset trim
	ADC_setOffsetTrimAll(ADC_REFERENCE_INTERNAL,ADC_REFERENCE_3_3V);
	// Configures the analog-to-digital converter module prescaler.
	ADC_setPrescaler(AD_C_BASE, ADC_CLK_DIV_1_0);
	// Sets the timing of the end-of-conversion pulse
	ADC_setInterruptPulseMode(AD_C_BASE, ADC_PULSE_END_OF_CONV);
	// Powers up the analog-to-digital converter core.
	ADC_enableConverter(AD_C_BASE);
	// Delay for 1ms to allow ADC time to power up
	DEVICE_DELAY_US(5000);

	// SOC Configuration: Setup ADC EPWM channel and trigger settings
	// Disables SOC burst mode.
	ADC_disableBurstMode(AD_C_BASE);
	// Sets the priority mode of the SOCs.
	ADC_setSOCPriority(AD_C_BASE, ADC_PRI_ALL_ROUND_ROBIN);
	// Start of Conversion 0 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 0
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN5
	//	 	Sample Window	: 11 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(AD_C_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN5, 11U);
	ADC_setInterruptSOCTrigger(AD_C_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_NONE);
	// Start of Conversion 1 Configuration
	// Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
	// 	  	SOC number		: 1
	//	  	Trigger			: ADC_TRIGGER_EPWM1_SOCA
	//	  	Channel			: ADC_CH_ADCIN3
	//	 	Sample Window	: 11 SYSCLK cycles
	//		Interrupt Trigger: ADC_INT_SOC_TRIGGER_NONE
	ADC_setupSOC(AD_C_BASE, ADC_SOC_NUMBER1, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN3, 11U);
	ADC_setInterruptSOCTrigger(AD_C_BASE, ADC_SOC_NUMBER1, ADC_INT_SOC_TRIGGER_NONE);

}
void ASYSCTL_init(){
	// asysctl initialization
	// Disables the temperature sensor output to the ADC.
	ASysCtl_disableTemperatureSensor();
	// Set the analog voltage reference selection to internal.
	ASysCtl_setAnalogReferenceInternal( ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC );
	// Set the internal analog voltage reference selection to 1.65V.
	ASysCtl_setAnalogReference1P65( ASYSCTL_VREFHIA | ASYSCTL_VREFHIB | ASYSCTL_VREFHIC );
}
void CPUTIMER_init(){
	//SWTIRMER initialization 
	CPUTimer_setEmulationMode(SWTIRMER_BASE, CPUTIMER_EMULATIONMODE_RUNFREE);
	CPUTimer_selectClockSource(SWTIRMER_BASE, CPUTIMER_CLOCK_SOURCE_SYS, CPUTIMER_CLOCK_PRESCALER_2);
	CPUTimer_setPreScaler(SWTIRMER_BASE, 1U);
	CPUTimer_setPeriod(SWTIRMER_BASE, 50000000U);
	CPUTimer_disableInterrupt(SWTIRMER_BASE);
	CPUTimer_stopTimer(SWTIRMER_BASE);

	CPUTimer_reloadTimerCounter(SWTIRMER_BASE);
	CPUTimer_startTimer(SWTIRMER_BASE);
}
void DAC_init(){
	// DAC1 initialization
	// Set DAC reference voltage.
	DAC_setReferenceVoltage(DAC1_BASE, DAC_REF_ADC_VREFHI);
	// Set DAC gain mode.
	DAC_setGainMode(DAC1_BASE, DAC_GAIN_TWO);
	// Set DAC load mode.
	DAC_setLoadMode(DAC1_BASE, DAC_LOAD_SYSCLK);
	// Enable the DAC output
	DAC_enableOutput(DAC1_BASE);
	// Set the DAC shadow output
	DAC_setShadowValue(DAC1_BASE, 0U);

	// DAC2 initialization
	// Set DAC reference voltage.
	DAC_setReferenceVoltage(DAC2_BASE, DAC_REF_ADC_VREFHI);
	// Set DAC gain mode.
	DAC_setGainMode(DAC2_BASE, DAC_GAIN_TWO);
	// Set DAC load mode.
	DAC_setLoadMode(DAC2_BASE, DAC_LOAD_SYSCLK);
	// Enable the DAC output
	DAC_enableOutput(DAC2_BASE);
	// Set the DAC shadow output
	DAC_setShadowValue(DAC2_BASE, 0U);

	// Delay for buffered DAC to power up.
	DEVICE_DELAY_US(5000);

}

void EPWM_init(){
	//BUCK_PWM1 initialization
}
void EPWMXBAR_init(){
	//PCMC_EPWMXBAR0 initialization
		
	XBAR_setEPWMMuxConfig(XBAR_TRIP4, XBAR_EPWM_MUX00_CMPSS1_CTRIPH);
	XBAR_enableEPWMMux(XBAR_TRIP4, XBAR_MUX00);

}
void GPIO_init(){
		
	//DEBUG_CLA initialization
	GPIO_setDirectionMode(DEBUG_CLA, GPIO_DIR_MODE_OUT);
	GPIO_setPadConfig(DEBUG_CLA, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(DEBUG_CLA, GPIO_CORE_CPU1_CLA1);
	GPIO_setQualificationMode(DEBUG_CLA, GPIO_QUAL_SYNC);
		
	//DEBUG_C28 initialization
	GPIO_setDirectionMode(DEBUG_C28, GPIO_DIR_MODE_OUT);
	GPIO_setPadConfig(DEBUG_C28, GPIO_PIN_TYPE_STD);
	GPIO_setMasterCore(DEBUG_C28, GPIO_CORE_CPU1);
	GPIO_setQualificationMode(DEBUG_C28, GPIO_QUAL_SYNC);
}
void INTERRUPT_init(){
	
	// Interrupt Setings for INT_AD_A_1
	Interrupt_register(INT_AD_A_1, &INT_ADC_EOC_ISR);
	Interrupt_enable(INT_AD_A_1);
}

void SCI_init(){
	
	//DEBUG_SCI initialization
	SCI_clearInterruptStatus(DEBUG_SCI_BASE, SCI_INT_RXFF | SCI_INT_TXFF | SCI_INT_FE | SCI_INT_OE | SCI_INT_PE | SCI_INT_RXERR | SCI_INT_RXRDY_BRKDT | SCI_INT_TXRDY);
	SCI_clearOverflowStatus(DEBUG_SCI_BASE);

	SCI_resetTxFIFO(DEBUG_SCI_BASE);
	SCI_resetRxFIFO(DEBUG_SCI_BASE);
	SCI_resetChannels(DEBUG_SCI_BASE);

	SCI_setConfig(DEBUG_SCI_BASE, DEVICE_LSPCLK_FREQ, DEBUG_SCI_BAUDRATE, (SCI_CONFIG_WLEN_8|SCI_CONFIG_STOP_ONE|SCI_CONFIG_PAR_EVEN));
	SCI_disableLoopback(DEBUG_SCI_BASE);
	SCI_performSoftwareReset(DEBUG_SCI_BASE);
	SCI_enableFIFO(DEBUG_SCI_BASE);
	SCI_enableModule(DEBUG_SCI_BASE);
}
