/*
 * linkPeripheral.h
 *
 *  Created on: 2022�~3��17��
 *      Author: cody_chen
 */

#ifndef PERIPHERALS_LINKPERIPHERAL_H_
#define PERIPHERALS_LINKPERIPHERAL_H_

#include "initCLA.h"
#include "initPWM.h"
#include "PowerSequence.h"

#endif /* PERIPHERALS_LINKPERIPHERAL_H_ */
