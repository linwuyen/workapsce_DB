//###########################################################################
// FILE:    Example_2837xSI2c_eeprom.c
// TITLE:   I2C EEPROM Example
//
//! \addtogroup cpu01_example_list
//! <h1>I2C EEPROM Example (i2c_eeprom)</h1>
//!
//! This program will write 1-14 words to EEPROM and read them back.
//! The data written and the EEPROM address written to are contained
//! in the message structure, I2cMsgOut1. The data read back will be
//! contained in the message structure I2cMsgIn1.
//!
//! \b External \b Connections \n
//! - This program requires an external I2C EEPROM connected to
//!   the I2C bus at address 0x50.
//
//###########################################################################
// $TI Release: F2837xS Support Library v190 $
// $Release Date: Mon Feb  1 16:59:09 CST 2016 $
// $Copyright: Copyright (C) 2014-2016 Texas Instruments Incorporated -
//             http://www.ti.com/ ALL RIGHTS RESERVED $
//###########################################################################

#include "F28x_Project.h"     // Device Headerfile and Examples Include File

// Note: I2C Macros used in this example can be found in the
// F2837xS_I2C_defines.h file

// Prototype statements for functions found within this file.

#define	  SetData	GpioDataRegs.GPCDAT.bit.GPIO91 = 1
#define	  ClrData   GpioDataRegs.GPCDAT.bit.GPIO91 = 0
#define	  SetClk	GpioDataRegs.GPCDAT.bit.GPIO92 = 1
#define	  ClrClk	GpioDataRegs.GPCDAT.bit.GPIO92 = 0


Uint16 	ReadData(Uint16  *RamAddr, Uint16	RomAddress, Uint16 number);
Uint16 	WriteData(Uint16	*Wdata, Uint16	RomAddress, Uint16	number);
void   I2CA_Init(void);
Uint16	I2C_xrdy();
Uint16	I2C_rrdy();

Uint16  i;
void main(void)
{
	Uint16   dat1[8]={0,0,0,0,0,0,0,0};
	Uint16   dat[]={ 0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88};

// Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the F2837xS_SysCtrl.c file.
   InitSysCtrl();

// Step 2. Initialize GPIO:
// This example function is found in the F2837xS_Gpio.c file and
// illustrates how to set the GPIO to it's default state.
   InitGpio();

// For this example, only init the pins for the SCI-A port.
// These functions are found in the F2837xS_Gpio.c file.
//   GPIO_SetupPinMux(32, GPIO_MUX_CPU1, 1);
//   GPIO_SetupPinMux(33, GPIO_MUX_CPU1, 1);
   EALLOW;
	/* Enable internal pull-up for the selected I2C pins */
	GpioCtrlRegs.GPAPUD.bit.GPIO0 = 0;
	GpioCtrlRegs.GPAPUD.bit.GPIO1 = 0;

	/* Set qualification for the selected I2C pins */
	GpioCtrlRegs.GPAQSEL1.bit.GPIO0 = 3;
	GpioCtrlRegs.GPAQSEL1.bit.GPIO1 = 3;

	/* Configure which of the possible GPIO pins will be I2C_A pins using GPIO regs*/

	GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 1;
	GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 2;//SDAA
	GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 1;
	GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 2;//SCLA

	EDIS;

// Step 3. Clear all __interrupts and initialize PIE vector table:
// Disable CPU __interrupts
   DINT;

// Initialize PIE control registers to their default state.
// The default state is all PIE __interrupts disabled and flags
// are cleared.
// This function is found in the F2837xS_PieCtrl.c file.
   InitPieCtrl();

// Disable CPU __interrupts and clear all CPU __interrupt flags:
   IER = 0x0000;
   IFR = 0x0000;

// Initialize the PIE vector table with pointers to the shell Interrupt
// Service Routines (ISR).
// This will populate the entire table, even if the __interrupt
// is not used in this example.  This is useful for debug purposes.
// The shell ISR routines are found in F2837xS_DefaultIsr.c.
// This function is found in F2837xS_PieVect.c.
   InitPieVectTable();

// Step 4. Initialize the Device Peripherals:
   I2CA_Init();
	WriteData(dat,0x60,8);
	DELAY_US(10000);
	ReadData(dat1,0x60,8);
   // Application loop
   for(;;)
   {
	   asm(" ESTOP0");
   }   // end of for(;;)
}   // end of main

void I2CA_Init(void)
{
   // Initialize I2C
	I2caRegs.I2CMDR.bit.IRS =0;
   I2caRegs.I2CSAR.all = 0x0050;		// Slave address - EEPROM control code

   I2caRegs.I2CPSC.all = 9;		    // Prescaler - need 7-12 Mhz on module clk
   I2caRegs.I2CCLKL = 15;			// NOTE: must be non zero
   I2caRegs.I2CCLKH = 15;			// NOTE: must be non zero
   I2caRegs.I2CIER.all = 0x00;		// Enable SCD & ARDY __interrupts

   I2caRegs.I2CMDR.all = 0x0020;	// Take I2C out of reset
   									// Stop I2C when suspended

  // I2caRegs.I2CFFTX.all = 0x6000;	// Enable FIFO mode and TXFIFO
   //I2caRegs.I2CFFRX.all = 0x2040;	// Enable RXFIFO, clear RXFFINT,

   return;
}

Uint16 WriteData(Uint16	*Wdata, Uint16	RomAddress, Uint16	number)
{
   Uint16 i;
   if (I2caRegs.I2CSTR.bit.BB == 1)
   {
      return I2C_BUS_BUSY_ERROR;
   }
   while(!I2C_xrdy());
   I2caRegs.I2CSAR.all = 0x50;
   I2caRegs.I2CCNT = number + 1;
   I2caRegs.I2CDXR.all = RomAddress;
   I2caRegs.I2CMDR.all = 0x6E20;
   for (i=0; i<number; i++)
   {
      while(!I2C_xrdy());
      I2caRegs.I2CDXR.all = *Wdata;
      Wdata++;
	  if (I2caRegs.I2CSTR.bit.NACK == 1)
   		  return	I2C_BUS_BUSY_ERROR;
   }
   return I2C_SUCCESS;
}

Uint16 ReadData(Uint16  *RamAddr, Uint16	RomAddress, Uint16 number)
{
   Uint16  i,Temp;

   if (I2caRegs.I2CSTR.bit.BB == 1)
   {
       return I2C_BUS_BUSY_ERROR;
   }
   while(!I2C_xrdy());
   I2caRegs.I2CSAR.all = 0x50;
   I2caRegs.I2CCNT = 1;
   I2caRegs.I2CDXR.all = RomAddress;
   I2caRegs.I2CMDR.all = 0x6620;
   if (I2caRegs.I2CSTR.bit.NACK == 1)
   		return	I2C_BUS_BUSY_ERROR;
   DELAY_US(50);
   while(!I2C_xrdy());
   I2caRegs.I2CSAR.all = 0x50;
   I2caRegs.I2CCNT = number;
   I2caRegs.I2CMDR.all = 0x6C20;
   if (I2caRegs.I2CSTR.bit.NACK == 1)
   		return	I2C_BUS_BUSY_ERROR;
   for(i=0;i<number;i++)
   {
      while(!I2C_rrdy());
   	  Temp = I2caRegs.I2CDRR.all;
	  if (I2caRegs.I2CSTR.bit.NACK == 1)
   		  return	I2C_BUS_BUSY_ERROR;
   	  *RamAddr = Temp;
   	  RamAddr++;
   }
   return I2C_SUCCESS;
}


Uint16	I2C_xrdy()
{
	Uint16	t;
	t = I2caRegs.I2CSTR.bit.XRDY;
	return t;
}

Uint16	I2C_rrdy()
{
	Uint16	t;
	t = I2caRegs.I2CSTR.bit.RRDY;
	return t;
}

//===========================================================================
// No more.
//===========================================================================

